﻿/*[config]
<plugin name="全国违章查询" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid"  icon="/icons/cheyooh.png"  app="com.android.cheyooh" description="全国违章查询"  data="$data,ComplexTreeDataSource" version="3.0.10">
<source>
<value>/data/data/com.android.cheyooh/databases/cheyouhui</value>
</source>
<data type="Cheyooh" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="信息" code="Info" type="string" width="600" format="" ></item>
</data>

<data type="Accident" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="地点" code="Address" type="string" width="" format = "" ></item>
<item name="参保公司" code="Company" type="string" width="" format = "" ></item>
<item name="备忘" code="Memo" type="string" width="" format = "" ></item>
<item name="报案号" code="Num" type="string" width="" format = "" ></item>
<item name="是否处理" code="State" type="string" width="" format = "" ></item>
<item name="数据路径" code="Path" type="string" width="" format="" ></item>
</data>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="消费类型" code="Type" type="string" width="" format = ""></item>
<item name="消费金额" code="Amount" type="string" width="" format = "" ></item>
<item name="备注" code="Remark" type="string" width="" format = "" ></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd"></item>
</data>
<data type="Car" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="车牌" code="Licence" type="string" width="" format = ""></item>
<item name="查询地点" code="Address" type="string" width="" format = ""></item>
<item name="车架号后六位" code="Num" type="string" width="" format = "" ></item>
<item name="添加时间" code="Time" type="datetime" width="" format = "yyyy-MM-dd"></item>
</data>
<data type="WeiZhang" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="车牌" code="Licence" type="string" width="" format = ""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd"></item>
<item name="地点" code="Location" type="string" width="" format = ""></item>
<item name="原因" code="Reason" type="string" width="" format = "" ></item>
<item name="要点" code="Points" type="string" width="" format = "" ></item>
<item name="费用" code="Fee" type="string" width="" format = "" ></item>
</data>
</plugin>
[config]*/

//******************************************定义数据结构******************************************
//定义天天动听数据结构
function Cheyooh()
{
    this.Info="";
    this.DataState="Normal";
}

//事故数据结构
function Accident(){
    this.Time = "";
    this.Address = "";
    this.Company = "";
    this.Memo = "";
    this.State = "";
    this.Path = "";
    this.Num= "";
    this.DataState="Normal";
}

//随手记数据结构
function Account(){
    this.Type = "";
    this.Amount = "";
    this.Remark = "";
    this.Time = "";
    this.DataState="Normal";
}

//车辆信息
function Car(){
    this.Licence = "";
    this.Address = "";
    this.Num = "";
    this.Time = "";
    this.DataState="Normal";
}

//违章信息
function WeiZhang(){
    this.Licence = "";
    this.Time = "";
    this.Location = "";
    this.Reason = "";
    this.Points = "";
    this.Fee = "";
    this.DataState="Normal";
}

//定义树结构
function TreeNode() 
{
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

//******************************************定义处理数据的方法******************************************
function bindTree()
{
    var recoverydb = XLY.Sqlite.DataRecovery(db,charactor,"AccidentRecordTB,accounting,UserCarTB,WeizhangTB,WZQueryTimeTB");
    var dbaccident = eval('(' + XLY.Sqlite.FindByName(recoverydb, 'AccidentRecordTB') + ')');
    var dbaccount = eval('(' + XLY.Sqlite.FindByName(recoverydb, 'accounting') + ')');
    var dbcar = eval('('+ XLY.Sqlite.Find(recoverydb,"select a.*,b.VAO,b.vfn from WZQueryTimeTB as a left join UserCarTB as b on a.lpn=b.lpn") +')');
    var cheyooh = new TreeNode();
    cheyooh.Text = "全国违章查询";
    cheyooh.Type = "Cheyooh";
    cheyooh.Items = getCheyooh();
    var accident= new TreeNode();
    accident.Text = "事故报案";
    accident.Type = "Accident";
    accident.Items = getAccident(recoverydb,dbaccident);
    cheyooh.TreeNodes.push(accident);
    var account= new TreeNode();
    account.Text = "随手记";
    account.Type = "Account";
    account.Items = getAccount(recoverydb,dbaccount);
    cheyooh.TreeNodes.push(account);
    var Carinfo= new TreeNode();
    Carinfo.Text = "车辆信息";
    Carinfo.Type = "Car";
    var carinfo = getCar(recoverydb,dbcar);
    Carinfo.Items = carinfo;
    cheyooh.TreeNodes.push(Carinfo);
    for(var i in carinfo){
        if((/[A-Z]/).test(carinfo[i].Licence)){
            var car = new TreeNode();
            car.Type = "WeiZhang";
            car.Text = carinfo[i].Licence;
            car.Items = getWeiZhang(recoverydb,carinfo[i]);
            car.DateState = carinfo[i].DateState;
            Carinfo.TreeNodes.push(car);
        }
    }
    return cheyooh;
}

//车辆违章子功能
function getCheyooh(){
    var list = new Array();
    var arr = ["事故报案","随手记","车辆信息"];
    for(var i in arr){
        var obj = new Cheyooh();
        obj.Info = arr[i];
        obj.DataState = "Normal";
        list.push(obj);
    }
    return list;
}

//获取事故信息
function getAccident(path,data){
    var list = new Array();
    for(var i in data){
        var obj = new Accident();
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].accident_time);
        obj.Address =data[i].accident_scene;
        obj.Company = data[i].insurance_company;
        obj.Memo = data[i].accident_memo;
        if(data[i].accident_disposal_state==1){
            obj.State ="已处理，无责任";
        }else{
            obj.State ="未处理";
        }
        obj.Num= data[i].report_number;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
    
//获取随手记信息
function getAccount(path,data){
    var list = new Array();
    for(var i in data){
        var obj = new Account();
        switch(data[i].type){
            case 0: obj.Type = "加油费";break;
            case 1: obj.Type = "停车费";break;
            case 2: obj.Type = "罚款";break;
            case 3: obj.Type = "洗车美容";break;
            case 4: obj.Type = "保险";break;
            case 5: obj.Type = "车贷";break;
            case 6: obj.Type = "维修保养";break;
            case 7: obj.Type = "过路费";break;
            case 8: obj.Type = "其他";break;
        }
        obj.Amount = data[i].amount;
        obj.Remark = data[i].remark;
        obj.Time = data[i].date;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取车辆信息
function getCar(path,data){
    var list = new Array();
    for(var i in data){
        if((/[A-Z]+/).test(data[i].lpn)){
            var obj = new Car();
            obj.Licence = data[i].lpn;
            obj.Address = data[i].VAO;
            obj.Num = data[i].vfn;
            obj.Time = data[i].time;
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
    } 
    return list;
}

//获取违章信息
function getWeiZhang(path,data){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select * from WeizhangTB where WeizhangTB.lpn='"+data.Licence+"'") +')');
    for(var i in info){
        if((/[A-Z]/).test(info[i].Licence)){
            var obj = new Car();
            obj.Licence = info[0].lpn;
            if((/-/).test(info[0].time)){
                obj.Time =info[0].time; 
            }else{
                obj.Time = XLY.Convert.LinuxToDateTime(info[0].time);   
            }
            obj.Location = info[0].location;
            obj.Reason = info[0].reason;
            obj.Points = info[0].points;
            obj.Fee = info[0].fee;
            obj.DataState = XLY.Convert.ToDataState( info[0].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

var result = new Array();
var source = $source;
var db = source[0];
//var db = "D:\\temp\\data\\data\\com.android.cheyooh\\databases\\cheyouhui";
var charactor="\\chalib\\Android_Cheyooh_V3.0.10\cheyouhui.charactor";
result.push(bindTree());
var res = JSON.stringify(result);
res;
