﻿/*[config]
<plugin name="SuperVPN,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/supervpnJRzheng.png" app="com.jrzheng.supervpnfree" version="2.0.5" description="SuperVPN" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.jrzheng.supervpnfree/shared_prefs/admob.xml</value>
    <value>/data/data/com.jrzheng.supervpnfree/shared_prefs/SDKIDFA.xml</value>
    <value>/data/data/com.jrzheng.supervpnfree/shared_prefs/com.jrzheng.supervpnfree_preferences.xml</value>
    <value>/data/data/com.jrzheng.supervpnfree/shared_prefs/com.jrzheng.supervpnfree_service_preferences.xml</value>
    <value>/data/data/com.jrzheng.supervpnfree/shared_prefs/com.google.android.gms.analytics.prefs.xml</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="当前访问服务器ip" code="PreferGateways" type="string" width = "80"></item>
    <item name="当前用户所有服务器ip" code="VPNGateways" type="string" width = "120"></item>
    <item name="最后一次请求服务器时间" code="LastLoadTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="首次运行时间" code="FirstRunTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="运行计数" code="RunCount" type="string" width = "80"></item>
    <item name="是否VIP" code="IsVip" type="string" width = "80"></item>
    <item name="是否使用HTTPS" code="IsUserHttp" type="string" width = "80"></item>
    <item name="是否限制广告跟踪" code="LimitAdTracking" type="string" width = "80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.PreferGateways = "";
    this.VPNGateways = "";
    this.LastLoadTime = null;
    this.FirstRunTime = null;
    this.RunCount = "";
    this.IsVip = "否";
    this.IsUserHttp = "否";
    this.LimitAdTracking = "否";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var admobPath = source[0];
var sdkPath = source[1];
var perPath = source[2];
var perSerPath = source[3];
var googlePath = source[4];

//测试数据
//var admobPath = "D:\\temp\\data\\data\\com.jrzheng.supervpnfree\\shared_prefs\\admob.xml";
//var sdkPath = "D:\\temp\\data\\data\\com.jrzheng.supervpnfree\\shared_prefs\\SDKIDFA.xml";
//var perPath = "D:\\temp\\data\\data\\com.jrzheng.supervpnfree\\shared_prefs\\com.jrzheng.supervpnfree_preferences.xml";
//var perSerPath = "D:\\temp\\data\\data\\com.jrzheng.supervpnfree\\shared_prefs\\com.jrzheng.supervpnfree_service_preferences.xml";
//var googlePath = "D:\\temp\\data\\data\\com.jrzheng.supervpnfree\\shared_prefs\\com.google.android.gms.analytics.prefs.xml";
//定义特征库文件
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "SuperVPN(jizheng)";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    if(XLY.File.IsValid(admobPath)){
        var admData = eval('('+ XLY.File.ReadXML(admobPath) +')');
        if(admData!=""&&admData!=null){
            var aa = admData.map.boolean;
            if(aa!=""&&aa!=null){
                if(aa["@value"]=="true"){
                    obj.IsUserHttp = "是";
                }
            }
        }
    }
    if(XLY.File.IsValid(sdkPath)){
        var sdkData = eval('('+ XLY.File.ReadXML(sdkPath) +')');
        if(sdkData!=""&&sdkData!=null){
            var bb = sdkData.map.boolean;
            if(bb!=""&&bb!=null){
                if(bb["@value"]=="true"){
                    obj.LimitAdTracking = "是";
                }
            }
        }
    }
    if(XLY.File.IsValid(perPath)){
        var perData = eval('('+ XLY.File.ReadXML(perPath) +')');
        if(perData!=""&&perData!=null){
            var cc = perData.map.boolean;
            var dd = perData.map.int;
            if(cc!=""&&cc!=null){
                for(var c in cc){
                    if(cc[c]["@name"]=="is_vip"){
                        if(cc[c]["@value"]=="true"){
                            obj.IsVip = "是";
                        }
                    }
                }
            }
            if(dd!=""&&dd!=null){
                for(var d in dd){
                    if(dd[d]["@name"]=="run_count"){
                        obj.RunCount = dd[d]["@value"];
                    }
                }
            }
        }
    }
    if(XLY.File.IsValid(perSerPath)){
        var perSerData = eval('('+ XLY.File.ReadXML(perSerPath) +')');
        if(perSerData!=""&&perSerData!= null){
            if(perSerData.map!=""&&perSerData.map!=null){
                var ee = perSerData.map.string;
                if(ee!=""&&ee!=null){
                    for(var e in ee){
                        if(ee[e]["@name"]=="vpn_gateways"){
                            obj.VPNGateways = ee[e]["@value"];
                        }
                        if(ee[e]["@name"]=="prefer_gateway"){
                            obj.PreferGateways = ee[e]["@value"];
                        }
                    }
                }
            }
        }
    }
    if(XLY.File.IsValid(googlePath)){
        var googleData = eval('('+ XLY.File.ReadXML(googlePath) +')');
        if(googleData!=""&&googleData!=null){
            var ff = googleData.map.long;
            if(ff!=""&&ff!=null){
                for(var f in ff){
                    if(ff[f]["@name"]=="last_dispatch"){
                        obj.LastLoadTime = XLY.Convert.LinuxToDateTime(ff[f]["@value"]);
                    }
                    if(ff[f]["@name"]=="first_run"){
                        obj.FirstRunTime = XLY.Convert.LinuxToDateTime(ff[f]["@value"]);
                    }
                }
            }
        }
    }
    if(obj.IsVip=="否"){
        usernode.Text = "免费用户";
    }
    else
    {
        usernode.Text = "VIP";
    }
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}