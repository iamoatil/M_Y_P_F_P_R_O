﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="com.baidu.BaiduMap" description="百度地图" data="$data,LocationInfoDataSource" >
<source>
<value>/data/data/com.baidu.BaiduMap/files/route_his.sdb</value>
<value>/data/data/com.baidu.BaiduMap/files/fav_route.sdb</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "";
    this.Source = "百度地图";
    this.StartDate = null;
}

//坐标转换（墨卡托坐标）
function LocationInfo(x,y){
    var a = x / 20037508.34 * 180;
    var b = y / 20037508.34 * 180; 
    var c = 180 / Math.PI * (2 * Math.atan(Math.pow(Math.E, b * Math.PI / 180)) - Math.PI / 2);
    var info = [a,c+0.1675];
    return info;
}

//获取路线搜索
function getSearch(path,root) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(value as text)as poi,* from route_his")+ ')');
    if(data!=null){
        for(var i in data){
            //创建起点
            var objstart = new Position();
            var info = eval('('+ data[i].poi +')');
            var info1 = eval('('+ info.Fav_Content +')');
            var start = info1.sfavnode;
            var loc = LocationInfo(start.geoptx,start.geopty);
            objstart.Longitude = loc[0];
            objstart.Latitude = loc[1];
            objstart.Remark = start.name+"(搜索起点)";
            objstart.StartDate = XLY.Convert.LinuxToDateTime(info1.addtimesec);
            root.push(objstart);
            //创建终点
            var objend = new Position();
            var info = eval('('+ data[i].poi +')');
            var info1 = eval('('+ info.Fav_Content +')');
            var end = info1.efavnode;
            var loc = LocationInfo(end.geoptx,end.geopty);
            objend.Longitude = loc[0];
            objend.Latitude = loc[1];
            objend.Remark = end.name+"(搜索终点)";
            objend.StartDate = XLY.Convert.LinuxToDateTime(info1.addtimesec);
            root.push(objend); 
        }
    }
    return root;
}
//获取导航
function getNavi(path,root) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(value as text)as poi,* from fav_route")+ ')');
    if(data!=null){
        for(var i in data){
            //创建起点
            var objstart = new Position();
            var info = eval('('+ data[i].poi +')');
            var start = info.Fav_Sync.startnode;
            var loc = LocationInfo(start.x,start.y);
            objstart.Longitude = loc[0];
            objstart.Latitude = loc[1];
            objstart.Remark = start.usname+"(导航起点)";
            objstart.StartDate = XLY.Convert.LinuxToDateTime(info.Fav_Sync.addtimesec);
            root.push(objstart);
            //创建终点
            var objend = new Position();
            var info = eval('('+ data[i].poi +')');
            var end = info.Fav_Sync.endnode;
            var loc = LocationInfo(end.x,end.y);
            objend.Longitude = loc[0];
            objend.Latitude = loc[1];
            objend.Remark = end.usname+"(导航终点)";
            objend.StartDate = XLY.Convert.LinuxToDateTime(info.Fav_Sync.addtimesec);
            root.push(objend);  
        }
    }
    return root;
}

var result = new Array();
//源文件路径
var source = $source;
var routehispath = source[0];
var navipath = source[1];
//var routehispath = "D:\\temp\\data\\data\\com.baidu.BaiduMap\\files\\route_his.sdb";
//var navipath = "D:\\temp\\data\\data\\com.baidu.BaiduMap\\files\\fav_route.sdb";
getSearch(routehispath,result);
getNavi(navipath,result);
var res = JSON.stringify(result);
res;
