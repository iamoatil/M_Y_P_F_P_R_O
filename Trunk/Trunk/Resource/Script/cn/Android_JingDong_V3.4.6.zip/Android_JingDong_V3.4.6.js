﻿/*[config]
<plugin name="京东,6" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="/icons/JingDong.png" app="com.jingdong.app.mall" version="3.4.6" description="京东" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.jingdong.app.mall/databases/jd.db</value>
</source>
<data type="SearchKeyword" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="关键字" code="Keyword" type="string" width="100" format=""></item>
<item name="时间" code="Time" type="datetime" width="400" format="yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="BrowseGoods" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="商品" code="Goods" type="string" width="100" format=""></item>
<item name="时间" code="Time" type="datetime" width="400" format="yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="Cart" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="商品" code="Goods" type="string" width="100" ></item>
<item name="商品编号" code="ID" type="string" width="400"  ></item>
</data>
<data type="Account" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="名称" code="Name" type="string"></item>
</data>
</plugin>
[config]*/

//定义数据结构
function SearchKeyword() {
	this.Keyword = "";
	this.Time = null;
	this.DataState = "Normal";
}

function BrowseGoods() {
	this.Goods = "";
	this.Time = null;
	this.DataState = "Normal";
}

function Cart() {
	this.Goods = "";
	this.ID = "";
	this.DataState = "Normal";
}

function Account() {
	this, Name = "";
	this.DataState = "Normal";
}
//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}

//创建历史搜索的子树节点并获取信息
function BuildSearchChildNode(tree, path) {
	//创建关键字搜索子树
	var keywrod = new TreeNode();
	keywrod.Text = "关键字搜索";
	keywrod.Type = "SearchKeyword";
	var keyworddata = GetSearchKeyword(path);
	keywrod.Items = keyworddata;

	//创建浏览商品子树
	var goods = new TreeNode();
	goods.Text = "历史浏览商品";
	goods.Type = "BrowseGoods";
	var goodsdata = GetBrowseGoods(path);
	goods.Items = goodsdata;

	//根节点树push子树
	tree.TreeNodes.push(keywrod);
	tree.TreeNodes.push(goods);
}

//获取搜索过的关键字信息
function GetSearchKeyword(path) {
	var data = eval('('+XLY.Sqlite.Find(path, "select *,cast(search_time as text)as time from search_history")+')');
	var arr = new Array();
	for (var index in data) {
		var obj = new SearchKeyword();
		obj.Keyword = data[index].word;
		obj.Time = XLY.Convert.LinuxToDateTime(data[index].time);
		obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
		arr.push(obj);
	}
	return arr;
}

//获取浏览商品信息
function GetBrowseGoods(path){
	var data = eval('(' + XLY.Sqlite.Find(path, "select *,cast(browseTime as text)as time from BrowseHistoryTable") + ')');
	var arr=new Array();
	for(var index in data){
		var obj=new BrowseGoods();
		obj.Goods=data[index].productCode;
		obj.Time = data[index].time;
		obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
		arr.push(obj);
	}
	return arr;
}

//获取购物车信息
function GetCart(path) {
	var data = eval('(' + XLY.Sqlite.FindByName(path, "CartTable") + ')');
	var arr = new Array();
	for (var index in data) {
		var obj = new Cart();
		obj.Goods = data[index].name;
		obj.ID = data[index].productCode;
		obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
		arr.push(obj);
	}
	return arr;
}

//获取账号信息
function GetAccount(path) {
	var data = eval('(' + XLY.Sqlite.FindByName(path, "usernames") + ')');
	var arr = new Array();
	for (var index in data) {
		var obj = new Account();
		obj.Name = data[index].name;
		obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
		arr.push(obj);
	}
	return arr;
}
var result = new Array();
//源文件
var source = $source;
var path = source[0];

//特征库
var charactor = "\\chalib\\Android_JingDong_V3.4.6\\jd.db.charactor";

//恢复处理
var repath = XLY.Sqlite.DataRecovery(path, charactor, "search_history,BrowseHistoryTable,CartTable,usernames");
//创建历史搜索树
var search = new TreeNode();
search.Text = "历史搜索";
BuildSearchChildNode(search, repath);

//创建购物车树
var cart = new TreeNode();
cart.Text = "购物车";
cart.Type = "Cart";
var cartdata = GetCart(repath);
cart.Items = cartdata;

//获取帐号信息
var account = new TreeNode();
account.Text = "登录过的帐号";
account.Type = "Account";
var accdata = GetAccount(repath);
account.Items = accdata;

result.push(search);
result.push(cart);
result.push(account);
var res = JSON.stringify(result);
res;
