﻿/*[config]
<plugin name="同花顺,6" group="生活旅游,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/TongHuaShun.png" app="com.hexin.plat.android" version="8.10.01" description="同花顺" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.hexin.plat.android/databases/#F</value>
<value>/data/data/com.hexin.plat.android/cache/user_info_cache.xml</value>
<value>/data/data/com.hexin.plat.android/files/passport.dat</value>
</source>

<data type="History" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="股票代码" code="Code" type="string" width="" format=""></item>
<item name="股票名称" code="Name" type="string" width="" format=""></item>
<item name="查询时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="Account">
<item name="帐号名称" code="Name" type="string" width="" format=""></item>
<item name="邮箱" code="Email" type="string" width="" format=""></item>
<item name="帐号ID" code="ID" type="string" width="" format=""></item>
<item name="密码" code="Password" type="string" width="" format=""></item>
<item name="登录时间" code="Time" type="string" width="" format=""></item>
<item name="关联手机号" code="Mobile" type="string" width="" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义History数据结构
function History() {
    this.Code = "";
    this.Name = "";
    this.Time = null;
    this.DataState = "Normal";
}

//定义Account数据结构
function Account() {
    this.ID = "";
    this.Name = "";
    this.Time = "";
    this.Mobile = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dataPath1 = source[0];
var dataPath2 = source[1];
var dataPath3 = source[2];
var path1 = dataPath1 + "\\hexin.db";
var path2 = dataPath2;
var path3 = dataPath3;
//测试数据
//var dataPath = "E:\\app_data\\Android\\com.hexin.plat.android";


//定义特征库文件
var charactor = "chalib\\Android_TongHuaShun_V8.10.01\\favorites.db.charactor";

//恢复数据库中删除的数据
var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "hx_searchlog,hx_stocklist");

//创建历史搜索树结构
var history = new TreeNode();
history.Text = "历史搜索";
history.Type = "History";
history.Items = getHistoryInfo(recoverypath1);

//创建历史帐号树结构
var account = new TreeNode();
account.Text = "历史帐号";
account.Type = "Account";
account.Items.push(getAccountInfo(path2,path3));

result.push(history);
result.push(account);
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
//获取历史浏览记录
function getHistoryInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select *,cast(last_time as text)as xly_time from hx_searchlog") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new History();
        obj.Code = data[index].code;
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].xly_time);
        var name = eval('(' + XLY.Sqlite.Find(path, "select name from hx_stocklist where code='" + data[index].code + "'") + ')');
        if (name.length != 0) {
            obj.Name = name[0].name;
        }
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

function getAccountInfo(path,accfile) {
    var flag = XLY.File.IsValid(path);
    if (flag) {
        var data = eval('(' + XLY.File.ReadXML(path) + ')');
        var info = data.query_account.item;
        var obj = new Account();
        obj.Email = info["@ckemail"];
        obj.ID = info["@userid"];
        obj.Mobile = info["@ckmobile"];
        obj.Time = info["@regtime"];

        var con = XLY.File.ReadFile(accfile);
        var reg = eval("/" + info["@userid"] + "/");
        if (reg.test(con)) {
            var accinfo = con.split("\r\n");
            for (var index in accinfo) {
                if ((/account/i).test(accinfo[index])) {
                    obj.Name = accinfo[index].substring(8);
                }
                if ((/PWD/i).test(accinfo[index])) {
                    obj.Password = accinfo[index].substring(4);
                }
            }
        }
        return obj;
    }
}
