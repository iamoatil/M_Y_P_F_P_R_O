﻿/*[config]
<plugin name="和地图,10" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\HeMap.png" app="com.autonavi.cmccmap" version="5.2.23.3.5.20161118" description="和地图" data="$data,ComplexTreeDataSource" >
<source>
 <value>/data/data/com.autonavi.cmccmap/#F</value>
  <value>/data/data/com.autonavi.cmccmap/files/homeCookie</value>
  <value>/data/data/com.autonavi.cmccmap/files/saveCookie</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="关键字" code="Word" type="string" width = "150"></item>
<item name="搜索时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Site" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="常用位置" code="Company" type="string" width = "150"></item>
</data>

<data type="FavSite" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="收藏地点" code="position" type="string" width = "150"></item>
</data>
<data type="Navi" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点" code="Start" type="string" width = "150"></item>
<item name="终点" code="End" type="string" width = "150"></item>
<item name="起点X" code="StartX" type="string" width = "200"></item>
<item name="起点Y" code="StartY" type="string" width = "200"></item>
<item name="终点X" code="EndX" type="string" width = "200"></item>
<item name="终点Y" code="EndY" type="string" width = "200"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
</data>

<include>    
<script>Script/XLYTemplate/cmccmap.js </script>
</include>
</plugin>
[config]*/

// js content

//定义数据结构
function News(){
    this.List = "";
}
function Search() {
    this.Word = "";
    this.Time = "";
    this.DataState="Normal";
}
function Site() {
    this.Company = "";
    // this.Home = "";
    this.DataState="Normal";
}
function FavSite() {
    this.position = "";
    this.DataState="Normal";
}
function Navi() {
    this.Start = "";
    this.End = "";
    this.StartX = "";
    this.StartY = "";
    this.EndX = "";
    this.EndY = "";
    this.Time = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
     var news = new TreeNode();
     news.Text = "和地图";
     news.Type = "News";
     news.Items = getNews();
     news.DataState = "Normal";
    
     newTreeNode("常用地址","Site",getSite(db4),news);
     newTreeNode("导航","Navi",getNavi(db2),news);
     newTreeNode("搜索","Search",getSearch(db3),news);
     //newTreeNode("收藏地点","FavSite",getFavSite(db7),news);
     result.push(news);
} 
 function getNews(){
    var list = new Array();
    data = ["常用地址","导航","搜索","收藏地点"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}
function getSite(path){
    var list = new Array();
    var data = path;
    for(var i in data){  
    var obj = new Site;     
        obj.Company = data[i].addr + " : "+ data[i].name;      
        // obj.Home = data[1].name + " : "+ data[1].addr;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }

    return list;
}
function getFavSite(path){
    var list = new Array();
    var data = path;
    for(var i in data){  
    var obj = new FavSite;     
        obj.position = "名称："+data[i].name + "\n定位: "+ data[i].addr;      
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);    
         list.push(obj);
    }
    return list;
}
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from HISTORY_WORD" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Word = data[i].WORD;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].DATE);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getNavi(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from NAVI_FROM_TO_BEAN" ) +')');
    for(var i in data){
        var obj = new Navi();
        obj.Start = data[i].START_NAME;
        obj.End = data[i].END_NAME;
        obj.StartX = data[i].START_X;
        obj.StartY = data[i].START_Y;
        obj.EndX = data[i].END_X;
        obj.EndY = data[i].END_Y;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].GENTIME);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
 //********************************************************
var source = $source;
var db1 = source[1];
var db8 = source[2];
var db5 = source[0]+"\\databases\\navifromtohistory";
var db6 = source[0]+"\\databases\\searchhistory";
var charactor1 = "\\chalib\\Android_HeMap_V5.2.23.3.5.20161118\\navifromtohistory.charactor";
var charactor2 = "\\chalib\\Android_HeMap_V5.2.23.3.5.20161118\\searchhistory.charactor";


//var db1 = "D:\\temp\\data\\data\\com.autonavi.cmccmap\\files\\homeCookie";
//var db5 = "D:\\temp\\data\\data\\com.autonavi.cmccmap\\databases\\navifromtohistory";
//var db6 = "D:\\temp\\data\\data\\com.autonavi.cmccmap\\databases\\searchhistory";
//var db8 = "D:\\temp\\data\\data\\com.autonavi.cmccmap\\files\\saveCookie";               
//var charactor1 = "D:\\temp\\data\\data\\com.autonavi.cmccmap\\databases\\navifromtohistory.charactor";
//var charactor2 = "D:\\temp\\data\\data\\com.autonavi.cmccmap\\databases\\searchhistory.charactor";
//
var db4 = analysisCCMCMAPSettingInfo(db1);

var db2 = XLY.Sqlite.DataRecovery(db5,charactor1,"NAVI_FROM_TO_BEAN");
var db3 = XLY.Sqlite.DataRecovery(db6,charactor2,"HISTORY_WORD");


var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
