﻿/*[config]
<plugin name="淘宝,7" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="/icons/TaoBao.png" app="com.taobao.taobao" version="4.2.2" description="淘宝" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.taobao.taobao/databases#F</value>
<value>/data/data/com.taobao.taobao/shared_prefs/allspark_create_account.xml</value>
<value>/data/data/com.taobao.taobao/shared_prefs/NearbyRecord.xml</value>
</source>

<data type="Search">
<item name="关键字" code="Word" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss" ></item>
<item name="地址" code="Address" type="string" width="100" format=""></item>
<item name="价格" code="Price" type="string" width="100" format=""></item>
<item name="商品图片" code="Pic" type="string" width="400" format=""></item>
</data>
<data type="Account">
<item name="登录过的帐号名" code="Name" type="string" width="" ></item>
</data>
<data type="Location">
<item name="城市名" code="City" type="string" width="" ></item>
<item name="时间" code="Time" type="datetime" width="300" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="经度" code="Longitude" type="string" width="" ></item>
<item name="纬度" code="Latitude" type="string" width="" ></item>
</data>

</plugin>
[config]*/

//定义数据结构
function Search() {
    this.Pic = "";
    this.Word = "";
    this.Time = null;
    this.Address = "";
    this.Price = "";
}

function Account() {
    this.Name = "";
}

function Location() {
    this.City = "";
    this.Time = null;
    this.Longitude = "";
    this.Latitude = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//获取历史搜索树的信息
function getSearchInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select word,gmt_create,title,address,fee,picUrl from history") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Search();
        if (data[index].word != null) {
            obj.Word = data[index].word;
        } else {
            obj.Word = data[index].title;
            obj.Address = data[index].address;
            obj.Price = data[index].fee;
            obj.Pic = data[index].picUrl;
        }
        obj.Time = data[index].gmt_create;
        info.push(obj)
    }
    return info;
}

//获取历史登录帐号信息
function getAccountInfo(path) {
    var data = eval('(' + XLY.File.ReadXML(path) + ')');
    var obj = new Account();
    var info = new Array();
    var accdata = data.map.string;
    if(accdata.length>=2){
        for (var index in accdata) {
            obj.Name = accdata[index]['@name'];
            info.push(obj);
        }
    }else{
        obj.Name = accdata['@name'];
        info.push(obj);
    }
return info;
}

//获取地理位置信息
function getLocationInfo(path) {
    var data = eval('(' + XLY.File.ReadXML(path) + ')');

    if (data.map.string != null) {
	    var obj = new Location();
        var info = eval('(' + data.map.string['#text'] + ')');
        obj.City = info[0].cityName;
        obj.Longitude = info[0].longitude;
        obj.Latitude = info[0].latitude;
        obj.Time = XLY.Convert.LinuxToDateTime(data.map.long['@value']);
		    return obj;
    }
return null;
}
var result = new Array();
//源文件路径
var source = $source;
var searchPath = source[0]+"\\data";
var accPath = source[1];
var locationPath = source[2];
//var searchPath = "E:\\app data\\Android\\com.taobao.taobao\\databases\\data"
//var accPath = "E:\\app data\\Android\\com.taobao.taobao\\shared_prefs\\allspark_create_account.xml";
//var locationPath = "E:\\app data\\Android\\com.taobao.taobao\\shared_prefs\\NearbyRecord.xml";

//创建历史搜索树
var search = new TreeNode();
search.Text = "历史搜索";
search.Type = "Search";
search.Items = getSearchInfo(searchPath);

//创建所有登录帐号树
var account = new TreeNode();
account.Text = "历史登录帐号";
account.Type = "Account";
account.Items = getAccountInfo(accPath);

//创建位置信息树
var location = new TreeNode();
location.Text = "位置信息";
location.Type = "Location";

var locationInfo = getLocationInfo(locationPath);
if(locationInfo != null)
{
location.Items.push(locationInfo);
}


result.push(search);
result.push(account);
result.push(location);
var res = JSON.stringify(result);
res;
