﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="com.tencent.mtt" version="5.5.2.1240" description="QQ浏览器" data="$data,LocationInfoDataSource" >
<source>
    <value>/data/data/com.tencent.mtt/databases/webview_x5.db</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "";
    this.Source = "QQ浏览器";
    this.StartDate = null;
}

//获取历史搜索树的信息
function getPosition(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies ") + ')');
    var info = new Array();
    if(data!=null&&data.length>0){
        for (var i in data) {
            if(data[i].name == "locallat"){
                for(var j in data){
                    if(data[j].name=="locallng"&&data[j].domain==data[i].domain&&data[j].expires==data[j].expires){
                        var obj = new Position();
                        obj.Longitude = XLY.Convert.ToDouble(data[j].value);
                        obj.Latitude = XLY.Convert.ToDouble(data[i].value);
                        obj.Remark = data[i].domain;
                        obj.StartDate = XLY.Convert.LinuxToDateTime(data[j].expires);
                        info.push(obj);
                    }
                }
            }   
        }
    }
    return info;
}

var result = new Array();
//源文件路径
var source = $source;
var db = source[0];
//var db = "C:\\Users\\Administrator\\Desktop\\com.tencent.mtt\\databases\\webview_x5.db";
result=getPosition(db);
var res = JSON.stringify(result);
res;
