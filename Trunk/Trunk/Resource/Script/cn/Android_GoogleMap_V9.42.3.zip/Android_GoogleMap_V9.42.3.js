﻿/*[config]
<plugin name="谷歌地图,4" group="地图公交,7,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/GoogleMap.png" app="com.google.android.apps.maps" version="9.42.3" description="谷歌地图" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.google.android.apps.maps#F</value>
</source>

<data type="RootNode" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="AppName" type="string" width="120" format=""></item>
    <item name="版本" code="Version" type="string" width="120" format=""></item>
</data>
<data type="List" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账户列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="120" format = ""></item>
    <item name="用户名" code="UserName" type="string" width="120" format=""></item>
    <item name="登录状态" code="IsActive" type="string" width="120" format = ""></item>
</data>
<data type="UserAddress" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="地址" code="Address" type="string" width="120" format=""></item>
</data>
<data type="Collection" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="语料库" code="Corpus" type="string" width="120" format=""></item>
    <item name="链接" code="Url" type="string" width="120" format = ""></item>
    <item name="保存时间" code="SaveTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="纬度" code="Latitude" type="string" width="120" format=""></item>
    <item name="经度" code="Longtitude" type="string" width="120" format=""></item>
    <item name="地点详情" code="SyncItem" type="string" width="120" format=""></item>
</data>
<data type="RecentNavigation" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="导航地点名称" code="Name" type="string" width="120" format=""></item>
    <item name="最近导航时间" code="LastRNTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义RootNode数据结构
function RootNode() {
    this.AppName = "";
    this.Version = "";
    this.DataState = "Normal";
}

function List(){
    this.List = "";
    this.DataState = "Normal";
}
//定义UserInfo数据结构
function UserInfo() {
    this.DataState = "Normal";
    this.ID = "";
    this.UserName = "";
    this.IsActive = "";
}
function UserAddress(){
    this.DataState = "Normal";
    this.Address = "";
}
//定义Collection数据结构
function Collection(){
    this.DataState = "Normal";
    this.Corpus = "";
    this.Url = "";
    this.SaveTime = null;
    this.Latitude = "";
    this.Longtitude = "";
    this.SyncItem = "";
}
//定义RecentNavigation数据结构
function RecentNavigation(){
    this.DataState = "Normal";
    this.Name = "";
    this.LastRNTime = null;
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path1 = source[0]+"\\databases\\gmm_myplaces.db";
var dpath2 = source[0]+"\\databases\\gmm_storage.db";
var upath = source[0]+"\\shared_prefs\\settings_preference.xml";
var charactor1 = "\\chalib\\Android_GoogleMap_V9.42.3\\gmm_myplaces.db.charactor";
var dpath1 = XLY.Sqlite.DataRecovery(path1,charactor1,"sync_item");

//测试数据

//恢复数据库中删除的数据
//var charactor1 = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_GoogleMap_V9.42.3\\gmm_myplaces.db.charactor";
//var path1 = "C:\\Users\\Administrator\\Desktop\\谷歌地图\\谷歌地图\\com.google.android.apps.maps\\databases\\gmm_myplaces.db";
//var dpath2 = "C:\\Users\\Administrator\\Desktop\\谷歌地图\\谷歌地图\\com.google.android.apps.maps\\databases\\gmm_storage.db";
//var upath = "C:\\Users\\Administrator\\Desktop\\谷歌地图\\谷歌地图\\com.google.android.apps.maps\\shared_prefs\\settings_preference.xml";
//var dpath1 = XLY.Sqlite.DataRecovery(path1,charactor1,"sync_item");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "谷歌地图";
    root.Type = "RootNode";
    root.Items.push(getRoot(root,dpath1,dpath2,upath));
    result.push(root);
}
//获取APP信息
function getRoot(root,path1,path2,path3){
    var robj = new RootNode();
    robj.AppName = "谷歌地图";
    robj.Version = "9.42.3";
    var latrntime = null;
    var usernode = new TreeNode();
    usernode.Text = "账户信息";
    usernode.Type = "List";
    if(XLY.File.IsValid(path3)){
        var udata = eval('('+ XLY.File.ReadXML(path3) +')');
        var data = udata.map.string;
        var ldata = udata.map.long;
        if(ldata!=""&&ldata!=null){
            for(var j in ldata){
                if(ldata[j]['@name']=="navigation_session_creation_timestamp"){
                    latrntime = ldata[j]['@value'];
                }
            }
        }
        if(data!=""&&data!=null){
            var arr = new Array();
            for(var i in data){
                var con = data[i]['@name'];
                if((/^aid#/).test(con)){
                    var userchobj = new UserInfo();
                    userchobj.ID = data[i]['#text'];
                    userchobj.UserName = data[i]['@name'].split("#")[1];
                    for(var j in data){
                        if(data[j]['@name']=="current_account_id"){
                            if(data[j]["#text"]==data[i]["#text"]){
                                userchobj.IsActive = "是";
                            }
                            else
                            {
                                userchobj.IsActive = "否";
                            }
                        }
                    }
                    var userchnode = new TreeNode();
                    userchnode.Text = data[i]['@name'].split("#")[1];
                    userchnode.Type = "UserInfo";
                    userchnode.Items.push(getUserChildInfo(data[i],userchobj.IsActive));
                    usernode.TreeNodes.push(userchnode);
                    
                    var dd = new List();
                    dd.List = userchobj.UserName;
                    usernode.Items.push(dd);
                }
            }
        }
    }
    
    var colnode = new TreeNode();
    colnode.Text = "收藏";
    colnode.Type = "Collection";
    colnode.Items = getCollection(path1);
    
    var rnnode = new TreeNode();
    rnnode.Text = "最近导航";
    rnnode.Type = "RecentNavigation";
    rnnode.Items.push(getRN(path2,latrntime));
    
    root.TreeNodes.push(usernode);
    root.TreeNodes.push(colnode);
    root.TreeNodes.push(rnnode);
    return robj;
}

//获取用户信息
function getUserChildInfo(info,status){
    if(info!=""&&info!=null){
        var obj = new UserInfo();
        obj.UserName = info['@name'].split("#")[1];
        obj.ID = info['#text'];
        obj.IsActive = status;
        return obj;
    }
}
//获取航程列表信息
function getCollection(path){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var a = analysisGoogleMapFavAddressInfo(path);
        var coldata = eval('('+ XLY.Sqlite.Find(path,"select * from sync_item") +')');
        if(coldata!=""&&coldata!=null){
            for(var i in coldata){
                var colobj = new Collection();
                colobj.DataState = XLY.Convert.ToDataState(coldata[i].XLY_DataStae);
                colobj.Corpus = coldata[i].corpus;
                if(coldata[i].key_string=="0:0"){
                    colobj.Url = "家";
                }
                else if(coldata[i].key_string=="1:0"){
                    colobj.Url = "公司";
                }
                else
                {
                    colobj.Url = coldata[i].key_string;
                }
                colobj.SaveTime = XLY.Convert.LinuxToDateTime(coldata[i].timestamp);
                colobj.Latitude = coldata[i].latitude/1000000;
                colobj.Longtitude = coldata[i].longitude/1000000;
                colobj.SyncItem = "名称："+a[i].name+"\r\n"+"备注："+a[i].mark+"\r\n"+"地址："+a[i].key;
                arr.push(colobj);
            }
        }
        return arr;
    }
}

function getRN(path,time){
    if(XLY.File.IsValid(path)){
        var rndata = eval('('+ XLY.Sqlite.Find(path,"select _data from gmm_storage_table where _key_pri='uri' and _key_sec = '0'") +')');
        if(rndata!=""&&rndata!= null){
            var rnobj = new RecentNavigation();
            rnobj.Name = analysisGoogleMapSearchInfo(rndata);
            rnobj.LastRNTime = XLY.Convert.LinuxToDateTime(time);
        }
        return rnobj;
    }
}

function analysisGoogleMapFavAddressInfo(path){
    try
    {
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from sync_item") +')');
        var info = new Array();
        if(data.length>0&&data!=null){
            for(var i in data){
                var syncinfo = XLY.Blob.ToBytes(data[i].sync_item,"base64");
                if(data[i].corpus==8){
                    var flaginfo = getSubFlagInfo(syncinfo,[0x32]);
                    if(flaginfo!= -1){

                        var favinfo = {};
                        var sub12flaginfo = getSubFlagInfo(flaginfo.data,[0x12]);
                        if(sub12flaginfo!=-1){
                            favinfo.name = XLY.Blob.ToString(sub12flaginfo.data);
                        }
                        var sub3Aflaginfo = getSubFlagInfo(flaginfo.data,[0x3A]);
                        if(sub3Aflaginfo!=-1){
                            favinfo.mark = XLY.Blob.ToString(sub3Aflaginfo.data);
                        }
                        favinfo.key = data[i].key_string;
                        info.push(favinfo);
                    }
                }
                if(data[i].corpus==1){
                    var con = getBlobContent(syncinfo);
                    con.key = data[i].key_string;
                    info.push(con);
                }
            }
        }
        return info;
    }
    catch(err)
    {
        return err;
    }
}


//读取byte数据中包含的所有的标记+长度+内容的存储方式的结构，并获取其偏移位置(offset)、标记值(flag)、记录长度信息使用的字节数(countByte)、长度真实值(len)、数据内容(data)
function getSubFlagInfo(data,flag){
    var pos = 0;
    var flaginfo = {};
    var dsize = data.length;
    while(pos<dsize){
        flaginfo.offset = pos;
        flaginfo.flag = XLY.Blob.GetBytes(data,pos,1);
        if(XLY.Blob.ToString([0x28])==XLY.Blob.ToString(flaginfo.flag)){
            pos += 7;
            continue;
        }
        pos += 1;
        var flagleninfo = getVariableIntLength(data,pos);
        flaginfo.countByte = flagleninfo.count;
        pos += flagleninfo.count;
        flaginfo.len = flagleninfo.size;
        flaginfo.data = XLY.Blob.GetBytes(data,pos,flaginfo.len);
        if(XLY.Blob.ToString(flag)==XLY.Blob.ToString(flaginfo.flag)){
            return flaginfo;
        }
        //else
        //{
        //    return -1;
        //}
        
        
        pos += flagleninfo.size;
    }
    return -1;
}


//获取可变长整数的位数和转换后的值
function getVariableIntLength(data,pos){
    var info = {};
    var subdata = XLY.Blob.GetBytes(data,pos,data.length-pos);
    //log(data[pos]);
    var count = 0;

    for(var i = 0; i<4 ;i++){
        if(128==(subdata[i]&128)){
            count++;
            continue;
        }
        count++;
        break;
    }
    info.count = count;
    info.size = XLY.Bit.ToVariableInt(subdata,false);
    return info;
}


//   corpus类型为1的结构：3byte+OA标记+2byte+1A标记+2A标记+10byte+52标记+5A标记+12标记+nbyte
//   其中1A标记为name，52标记为mark
function getBlobContent(data){
    
    var pos = 3;
    //log(data[pos]==10);
    var con = {};
    if(data[pos]==10){
        pos += 1;
        var tmp = getVariableIntLength(data,pos);
        pos += tmp.count;
        pos += tmp.size;
        pos += 2;
        if(data[pos]==26){
            pos += 1;
            tmp = getVariableIntLength(data,pos);
            pos += tmp.count;
            con.name = XLY.Blob.ToString(XLY.Blob.GetBytes(data,pos,tmp.size));
            pos += tmp.size;
            if(data[pos]==42){
                pos += 1;
                tmp = getVariableIntLength(data,pos);
                pos += tmp.count;
                pos += tmp.size;
                pos += 16;
                //log(data[pos]);
                if(data[pos]==82){
                    pos += 1;
                    tmp = getVariableIntLength(data,pos);
                    pos += tmp.count;
                    con.mark = XLY.Blob.ToString(XLY.Blob.GetBytes(data,pos,tmp.size));
                }
            }
        }
        
    }
    return con;
}
function analysisGoogleMapSearchInfo(data){
    try
    {
       
       var magic = [0x45, 0x4E, 0x54, 0x49, 0x54, 0x59, 0x5F, 0x54, 0x59, 0x50, 0x45, 0x5F, 0x44, 0x45, 0x46, 0x41, 0x55, 0x4C, 0x54];
       if(data.length>0&&data!=null){
           for(var i in data){
               var dinfo = XLY.Blob.ToBytes(data[i].xly_data,"base64");
               //log(dinfo);
               var pos = XLY.Blob.FindBytes(dinfo,0,magic);
               pos += magic.length+1;
               var len = XLY.Blob.GetBytes(dinfo,pos,2);
               len = XLY.Bit.ToInt(len,true);
               pos += 2;
               var searchinfo = XLY.Blob.GetBytes(dinfo,pos,len);
               
               return XLY.Blob.ToString(searchinfo);
               
               
           }
       }
    }
    catch(err)
    {
        return err;
    }
   
}