﻿/*[config]
<plugin name="Google地图,3" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\Android_GoogleMap.png" view="$data" app="com.google.android.apps.maps" description="google地图" data="$data,ComplexTreeDataSource" version="7.6.0">
<source>
<value>/data/data/com.google.android.apps.maps/databases/gmm_myplaces.db</value>
</source>
<data type="Fav" contract="DataState,Map" datefilter="Date"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="地标的详细地址" code="HttpsAddress" type="URl" width="" ></item> 
<item name="时间" code="Desc" type="string" width="" show="false"></item> 
<item name="定位的时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="经度" code="Longitude" type="double" format="F6" width="" ></item> 
<item name="纬度" code="Latitude" type="double" format="F4"    width="" ></item> 
</data>
</plugin>
[config]*/

//收藏信息节点定义
function Fav() {
	this.Desc="";
	this.Time = null; //时间
	this.Longitude = 0; //经度
	this.Latitude = 0; // 纬度
	this.HttpsAddress = ""; //网页链接形式的地址
	this.DataState = "Normal";
}
//获取收藏信息
function getFav(info) {
	var list = new Array();
	try{
		for (var index in info) {
			var obj = new Fav();
			obj.DataState = XLY.Convert.ToDataState(info[index].XLY_DataType); 
			obj.Desc=XLY.Convert.LinuxToDateTime(info[index].Timestamp);
			obj.Latitude = info[index].latitude / 1000000;
			obj.Longitude = info[index].longitude / 1000000;
			obj.Date=XLY.Convert.LinuxToDateTime(info[index].Timestamp);
			obj.HttpsAddress = info[index].key_string;
			list.push(obj);
		}
		return list;
	}
	catch(e){
		return list;
	}
}
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}

var result = new Array();
//源文件
var source = $source;
var db = source[0];

//数据恢复库的生成
var charactor="chalib\\Android_GoogleMap_V7.6.0\\gmm_myplaces.db.charactor";
db=XLY.Sqlite.DataRecovery( db,charactor ,"sync_item");
var dblist = eval('(' + XLY.Sqlite.Find(db, "select XLY_DataType,cast(timestamp as TEXT) as Timestamp,latitude,longitude,key_string from sync_item")+ ')');

//创建收藏夹树
var favTree = new TreeNode();
favTree.Text = "收藏夹";
favTree.Type = "Fav";
var info = getFav(dblist);
favTree.Items = info;

//打印数据
result.push(favTree);
var res = JSON.stringify(result);
res;
