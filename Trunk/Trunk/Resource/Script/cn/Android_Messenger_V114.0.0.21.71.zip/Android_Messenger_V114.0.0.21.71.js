﻿/*[config]
<plugin name="Messenger,3" group="社交聊天,5" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/messenger.png" app="com.facebook.orca" version="114.0.0.21.71" description="Messenger" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.facebook.orca/databases/threads_db2</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="昵称" code="Name" type="string" width="120" format=""></item>
    <item name="用户名" code="UserName" type="string" width="120" format = ""></item>
    <item name="头像" code="UserHeadL" type="url" width="120" format = ""></item>
    <item name="最近使用时间" code="LoadingCreaTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="GroupInfo"  contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="群名称" code="GroupName" type="string" width="120" format = "" ></item>
    <item name="成员" code="GroupMember" type="string" width="120" format = "" ></item>
    <item name="最近读取信息时间" code="Time" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="Message" contract = "DataState" detailfield="Contents">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="发送者" code="Sender" type="string" width="120" format = "" ></item>
    <item name="接收者" code="Receiver" type="string" width="120" format = "" ></item>
    <item name="消息内容" code="Contents" type="string" width="120" format = "" ></item>
    <item name="消息类型" code="MType" type="string" width="120" format = "" ></item>
    <item name="消息发送时间" code="SendTime" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
</plugin>
[config]*/
//定义并初始化News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义并初始化UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.Name = "";
    this.UserName = "";
    this.UserHeadL = "";
    this.LoadingCreaTime = null;
}
//定义并初始化GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupName = "";
    this.GroupMember = "";
    this.Time = null;
}
//定义并初始化Message数据结构
function Message(){
    this.DataState = "Normal";
    this.MType = "";
    this.Sender = "";
    this.Receiver = "";
    this.Contents = "";
    this.SendTime = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//*************************************程序入口****************************************
var result = new Array();
//源文件
var source = $source;
var upath1 = source[0];
//测试数据
//var upath1 = "D:\\temp\\data\\data\\com.facebook.orca\\databases\\threads_db2";
var charactor1 = "\\chalib\\Android_Messenger_V114.0.0.21.71\\threads_db2.charactor";
var upath = XLY.Sqlite.DataRecovery(upath1,charactor1,"thread_users,folders,threads,thread_participants,messages");

BuildNode();
var res = JSON.stringify(result);
res;
//++++++++++++++++++++++++++++++++++自定义函数部分++++++++++++++++++++++++++++++++++++++
//根节点函数
function BuildNode(){
    var root = new TreeNode();
    root.Text = "Messenger";
    root.Type = "News";
    getRootChildNode(root);
    result.push(root);
}
function getRootChildNode(root){
    if(XLY.File.IsValid(upath)){
        var data = eval('('+ XLY.Sqlite.Find(upath,"select * from thread_users where is_partial = '1'") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = data[0].name;
            node.Type = "UserInfo";
            getUserChildNode(node,data[0]);
            root.TreeNodes.push(node);
        }
    }
}
function getUserChildNode(root,info){
    var yy = info.user_key.split(":")[1];
    var obj = new UserInfo();
    //obj.DataState = XLY.Convert.ToDataState(info.XLY_DataType);
    obj.Name = info.name;
    obj.UserName = info.username;
    var aa = eval('('+ info.profile_pic_square +')');
    obj.UserHeadL = aa[0].url;
    obj.LoadingCreaTime = XLY.Convert.LinuxToDateTime(info.last_fetch_fbid);
    root.Items.push(obj);
    if(XLY.File.IsValid(upath)){
        var contactdata = eval('('+ XLY.Sqlite.Find(upath,"select * from thread_users where is_partial <> '1'") +')');
        if(contactdata!=""&&contactdata!=null){
            var cnode = new TreeNode();
            cnode.Text = "联系人";
            cnode.Type = "UserInfo";
            getContactInfo(cnode,contactdata);
            root.TreeNodes.push(cnode);
        }
        var data = eval('('+ XLY.Sqlite.Find(upath,"select * from folders where timestamp_ms <>'0'") +')');
        if(data!=""&&data!= null){
            var gggnode = new TreeNode();
            gggnode.Text = "群组信息";
            gggnode.Type = "News";
            root.TreeNodes.push(gggnode);
            
            var ccnode = new TreeNode();
            ccnode.Text = "聊天记录";
            ccnode.Type = "News";
            root.TreeNodes.push(ccnode);
            
            var gccnode = new TreeNode();
            gccnode.Text = "群组聊天记录";
            gccnode.Type = "News";
            ccnode.TreeNodes.push(gccnode);
            
            var fccnode = new TreeNode();
            fccnode.Text = "好友聊天记录";
            fccnode.Type = "News";
            ccnode.TreeNodes.push(fccnode);
            for(var i in data){
                if(data[i].thread_key.substr(0,5)=="GROUP"){
                    var gname = eval('('+ XLY.Sqlite.Find(upath,"select name from threads where thread_key = '"+data[i].thread_key+"'") +')');
                    var ggname = eval('('+ XLY.Sqlite.Find(upath,"select user_key from thread_participants where thread_key = '"+data[i].thread_key+"'") +')');
                    var aa = "";
                    if(ggname!=""&&ggname!=null){
                        for(var a in ggname){
                            ggusername = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+ggname[a].user_key+"'") +')');
                            if(ggusername!=""&&ggusername!= null){
                                if(a<ggname.length-1){
                                    aa+= ggusername[0].name+",";
                                }
                                else
                                {
                                    aa+= ggusername[0].name;
                                }
                            }
                        }
                    }
                    var gnode = new TreeNode();
                    var gobj = new GroupInfo();
                    var grcnode = new TreeNode();
                    if(gname[0].name!=""&&gname[0].name!=null){
                        gnode.Text = gname[0].name;
                        gobj.GroupName = gname[0].name;
                        grcnode.Text = gname[0].name;
                    }
                    else
                    {
                        gnode.Text = aa;
                        gobj.GroupName = aa;
                        grcnode.Text = aa;
                    }
                    gnode.Type = "GroupInfo";
                    gggnode.TreeNodes.push(gnode);
                    
                    //gobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    
                    gobj.GroupMember = aa;
                    gobj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp_ms);
                    gnode.Items.push(gobj);
                    
                    
                    grcnode.Type = "Message";
                    
                    var groupdata = eval('('+ XLY.Sqlite.Find(upath,"select text,sender,timestamp_ms,cast(timestamp_sent_ms as int) as time,attachments,shares,sticker_id,msg_type,pending_send_media_attachment,XLY_DataType from messages where thread_key='"+data[i].thread_key+"'") +')');
                    if(groupdata!=""&&groupdata!=null){
                        for(var p in groupdata){
                            if(groupdata[p].msg_type!="-1"){
                                var pobj = new Message();
                                pobj.DataState = XLY.Convert.ToDataState(groupdata[p].XLY_DataType);
                                if(groupdata[p].sender!=""&&groupdata[p].sender!=null){
                                    var ff = eval('('+ groupdata[p].sender +')');
                                    pobj.Sender = ff.name;
                                }
                                else
                                {
                                    pobj.Sender = "系统";
                                }
                                pobj.Receiver = gnode.Text;
                                if(groupdata[p].text!=""&&groupdata[p].text!=null){
                                    pobj.Contents = groupdata[p].text;
                                    pobj.MType = "文本";
                                }
                                else
                                {
                                    var rbracket = groupdata[p].attachments[0];
                                    var lbracket = groupdata[p].attachments[groupdata[p].attachments.length-1];
                                    if(rbracket=="["&&lbracket=="]"){
                                        if(groupdata[p].attachments!="[]"&&groupdata[p].attachments!=null){
                                            var att = eval('('+ groupdata[p].attachments +')');
                                            pobj.MType = att[0].mime_type;
                                            if(att[0].mime_type=="audio/mpeg"){
                                                pobj.Contents = "文件名：\r"+att[0].filename+"\r"+"文件大小：\r"+att[0].file_size;
                                            }
                                            else if(att[0].mime_type=="image/jpeg")
                                            {
                                                var iop = eval('('+ att[0].urls +')');
                                                var oop = eval('('+ iop.MEDIUM_PREVIEW +')');
                                                pobj.Contents = "文件名：\r"+att[0].filename+"\r"+"文件大小：\r"+att[0].image_data_width+"*"+att[0].image_data_height+"\r"+"链接：\r"+oop.src;
                                            }
                                            else
                                            {}
                                        }
                                        else
                                        {
                                            var rbracket = groupdata[p].shares[0];
                                            var lbracket = groupdata[p].shares[groupdata[p].shares.length-1];
                                            if(rbracket=="["&&lbracket=="]"){
                                                if(groupdata[p].shares!="[]"&&groupdata[p].shares!=null){
                                                    var ert = eval('('+ groupdata[p].shares +')');
                                                    pobj.MType = "share";
                                                    pobj.Contents = "名称：\r"+ert[0].name+"\r"+"描述：\r"+ert[0].description+"\r"+"补充:\r"+ert[0].href;
                                                }
                                            }
                                        }
                                    }
                                }
                                if(groupdata[p].time!=""&&groupdata[p].time!=null){
                                    pobj.SendTime = XLY.Convert.LinuxToDateTime(groupdata[p].time);
                                }
                                else
                                {
                                    pobj.SendTime = XLY.Convert.LinuxToDateTime(groupdata[p].timestamp_ms);
                                }
                                //pobj.SendTime = XLY.Convert.LinuxToDateTime(groupdata[p].timestamp_sent_ms);
                                grcnode.Items.push(pobj);
                            }
                        }
                    }
                    gccnode.TreeNodes.push(grcnode);
                }
                else
                {
                    var cc = data[i].thread_key.split(":");
                    var fcnode = new TreeNode();
                    if(cc[1]== yy){
                        var der = "FACEBOOK:"+cc[2];
                        var yyname = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+der+"'") +')');
                        if(yyname!=""&&yyname!=null){
                            fcnode.Text = yyname[0].name;
                        }
                    }
                    if(cc[2]==yy){
                        var der = "FACEBOOK:"+cc[1];
                        var yyname = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+der+"'") +')');
                        if(yyname!=""&&yyname!=null){
                            var fcnode = new TreeNode();
                            fcnode.Text = yyname[0].name;
                        }
                    }
                    fcnode.Type = "Message";
                    //log(data[i].thread_key);
                    var fmessage = eval('('+ XLY.Sqlite.Find(upath,"select text,sender,timestamp_ms,cast(timestamp_sent_ms as int) as time,attachments,shares,sticker_id,msg_type,pending_send_media_attachment,XLY_DataType from messages where thread_key = '"+data[i].thread_key+"'") +')');
                    if(fmessage!=""&&fmessage!= null){
                        for(var q in fmessage){
                            if(fmessage[q].msg_type!="-1"){
                                var qobj = new Message();
                                qobj.DataState = XLY.Convert.ToDataState(fmessage[q].XLY_DataType);
                                //qobj.MType = fmessage[q].msg_type;
                                
                                var uu = "";
                                var rbracket1 = fmessage[q].sender[0];
                                var lbracket1 = fmessage[q].sender[fmessage[q].sender.length-1];
                                if(rbracket1=="{"&&lbracket1=="}"){
                                    if(fmessage[q].sender!=""&&fmessage[q].sender!=null){
                                        var ff = eval('('+ fmessage[q].sender +')');
                                        qobj.Sender = ff.name;
                                        uu = ff.user_key.split(":")[1];
                                    }
                                    else
                                    {
                                        qobj.Sender = "系统";
                                        var u1 = "FACEBOOK:"+data[i].thread_key.split(":")[1];
                                        var u11 = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+u1+"'") +')');
                                        var u2 = "FACEBOOK:"+data[i].thread_key.split(":")[2];
                                        var u21 = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+u2+"'") +')');
                                        if(u11!=""&&u11!=null){
                                            if(u21!=""&&u21!=null){
                                                qobj.Receiver = u11[0].name+","+u21[0].name;
                                            }
                                            else
                                            {
                                                qobj.Receiver = u11[0].name;
                                            }
                                        }
                                        else
                                        {
                                            if(u21!=""&&u21!=null){
                                                qobj.Receiver = u21[0].name;
                                            }
                                        }
                                    }
                                }
                                if(cc[1]==uu){
                                    var dre = "FACEBOOK:"+cc[2];
                                    var yyname = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+dre+"'") +')');
                                    if(yyname!=""&&yyname!=null){
                                        qobj.Receiver = yyname;
                                    }
                                }
                                
                                if(cc[2]==uu){
                                    var fer = "FACEBOOK:"+cc[1];
                                    var yyname = eval('('+ XLY.Sqlite.Find(upath,"select name from thread_users where user_key = '"+fer+"'") +')');
                                    if(yyname!=""&&yyname!=null){
                                        qobj.Receiver = yyname[0].name;
                                    }
                                }
                                if(fmessage[q].text!=""&&fmessage[q].text!=null){
                                    qobj.Contents = fmessage[q].text;
                                    qobj.MType = "文本";
                                }
                                else
                                {
                                    var rbracket = fmessage[q].attachments[0];
                                    var lbracket = fmessage[q].attachments[fmessage[q].attachments.length-1];
                                    if(rbracket=="["&&lbracket=="]"){
                                        if(fmessage[q].attachments!="[]"&&fmessage[q].attachments!=null){
                                            var att = eval('('+ fmessage[q].attachments +')');
                                            qobj.MType = att[0].mime_type;
                                            if(att[0].mime_type=="audio/mpeg"){
                                                qobj.Contents = "文件名：\r"+att[0].filename+"\r"+"文件大小：\r"+att[0].file_size;
                                            }
                                            else if(att[0].mime_type=="image/jpeg")
                                            {
                                                var iop = eval('('+ att[0].urls +')');
                                                var oop = eval('('+ iop.MEDIUM_PREVIEW +')');
                                                qobj.Contents = "文件名：\r"+att[0].filename+"\r"+"文件大小：\r"+att[0].image_data_width+"*"+att[0].image_data_height+"\r"+"链接：\r"+oop.src;
                                            }
                                            else
                                            {
                                            }
                                        }
                                        else
                                        {
                                            var rbracket = fmessage[q].shares[0];
                                            var lbracket = fmessage[q].shares[fmessage[q].shares.length-1];
                                            if(rbracket=="["&&lbracket=="]"){
                                                if(fmessage[q].shares!="[]"&&fmessage[q].shares!=null){
                                                    var ert = eval('('+ fmessage[q].shares +')');
                                                    qobj.MType = "share";
                                                    qobj.Contents = "名称：\r"+ert[0].name+"\r"+"描述：\r"+ert[0].description+"\r"+"补充:\r"+ert[0].href;
                                                }
                                            }
                                        }
                                    }
                                }
                                if(fmessage[q].time!=""&&fmessage[q].time!=null){
                                    qobj.SendTime = XLY.Convert.LinuxToDateTime(fmessage[q].time);
                                }
                                else
                                {
                                    qobj.SendTime = XLY.Convert.LinuxToDateTime(fmessage[q].timestamp_ms);
                                }
                                fcnode.Items.push(qobj);
                            }
                        }
                    }
                    fccnode.TreeNodes.push(fcnode);
                }
            }
        }
    }
}
function getContactInfo(root,info){
    for(var i in info){
        var obj = new UserInfo();
        //obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
        obj.Name = info[i].name;
        obj.UserName = info[i].username;
        var aa = eval('('+ info[i].profile_pic_square +')');
        obj.UserHeadL = aa[0].url;
        obj.LoadingCreaTime = XLY.Convert.LinuxToDateTime(info[i].last_fetch_fbid);
        root.Items.push(obj);
    }
}