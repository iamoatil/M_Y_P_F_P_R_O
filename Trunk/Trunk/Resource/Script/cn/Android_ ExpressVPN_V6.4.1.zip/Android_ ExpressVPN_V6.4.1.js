﻿/*[config]
<plugin name="ExpressVPN,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/expressvpn.png" app="com.expressvpn.vpn" version="6.4.1" description="ExpressVPN" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.expressvpn.vpn/shared_prefs#F</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width = "100"></item>
    <item name="当前连接状态" code="UserServer" type="string" width = "80"></item>
    <item name="用户过期时间" code="Expiration" type="string" width = "100"></item>
    <item name="邮箱" code="Email" type="string" width = "100"></item>
    <item name="最后连接服务器名称" code="LastConnect" type="string" width = "80"></item>
    <item name="最后请求服务器ip及使用协议" code="LastServerIPAndPro" type="string" width = "100"></item>
    <item name="用户状态" code="Subscription" type="string" width="100"></item>
    <item name="最后请求时间" code="LastReqTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="首次运行时间" code="FirstRun" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="首次请求服务器时间" code="FirstLunchTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="用户状态最后更新时间" code="LastUpdateSubscription" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.UserServer = "";
    this.Expiration = "";
    this.Email = "";
    this.LastConnect = "";
    this.LastServerIPAndPro = "";
    this.Subscription = "";
    this.LastReqTime = null;
    this.FirstRun = null;
    this.FirstLunchTime = null;
    this.LastUpdateSubscription = null;
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];

//测试数据
//var allPath = "F:\\temp\\data\\data\\com.expressvpn.vpn\\shared_prefs";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "ExpressVPN";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Text = "账户信息";
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    
    var gmsPath = allPath+"\\com.google.android.gms.analytics.prefs.xml";
    
    if(XLY.File.IsValid(gmsPath)){
        var gmsData = eval('('+ XLY.File.ReadXML(gmsPath) +')');
        if(gmsData!=""&&gmsData!=null){
            if(gmsData.map!=""&&gmsData.map!=null){
                var gmsLongData = gmsData.map.long;
                for(var a in gmsLongData){
                    if(gmsLongData[a]["@name"]=="last_dispatch"){
                        obj.LastReqTime = XLY.Convert.LinuxToDateTime(gmsLongData[a]["@value"]);
                    }
                    if(gmsLongData[a]["@name"]=="first_run"){
                        obj.FirstRun = XLY.Convert.LinuxToDateTime(gmsLongData[a]["@value"]);
                    }
                }
            }
        }
    }
    var conPath = allPath+"\\connstate.xml";
    if(XLY.File.IsValid(conPath)){
        var conData = eval('('+ XLY.File.ReadXML(conPath)+')');
        if(conData!=""&&conData!=null){
            var conStrData = conData.map.string;
            if(conStrData!=""&&conStrData!=null){
                for(var b in conStrData){
                    if(conStrData[b]["@name"]=="USER_INTENTION"){
                        if(conStrData[b]["#text"]=="BeDisconnected"){
                            obj.UserServer = "已断开连接";
                        }
                    }
                }
            }
        }
    }
    var aevPath = allPath+"\\ApplicationExpressVpn.xml";
    if(XLY.File.IsValid(aevPath)){
        var aevData = eval('('+ XLY.File.ReadXML(aevPath) +')');
        if(aevData!=""&&aevData!=null){
            var aevStrData = aevData.map.string;
            if(aevStrData!=""&&aevStrData!=null){
                for(var c in aevStrData){
                    if(aevStrData[c]["@name"]=="subscription_status"){
                        obj.Subscription = aevStrData[c]["#text"];
                    }
                    if(aevStrData[c]["@name"]=="last_used_server_uid"){
                        obj.LastServerIPAndPro = aevStrData[c]["#text"];
                    }
                    if(aevStrData[c]["@name"]=="email"){
                        obj.Email = aevStrData[c]["#text"];
                    }
                    if(aevStrData[c]["@name"]=="preferences_subscription_id"){
                        obj.UserId = aevStrData[c]["#text"];
                    }
                    if(aevStrData[c]["@name"]=="preferences_expiration_date"){
                        obj.Expiration = aevStrData[c]["#text"];
                    }
                    if(aevStrData[c]["@name"]=="pref_last_cluster_selected"){
                        obj.LastConnect = aevStrData[c]["#text"];
                    }
                }
            }
            var aevLongData = aevData.map.long;
            if(aevLongData!=""&&aevLongData!= null){
                for(var d in aevLongData){
                    if(aevLongData[d]["@name"]=="first_launch_time"){
                        obj.FirstLunchTime = XLY.Convert.LinuxToDateTime(aevLongData[d]["@value"]);
                    }
                    if(aevLongData[d]["@name"]=="subscription_last_updated"){
                        obj.LastUpdateSubscription = XLY.Convert.LinuxToDateTime(aevLongData[d]["@value"]);
                    }
                }
            }
        }
    }
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}