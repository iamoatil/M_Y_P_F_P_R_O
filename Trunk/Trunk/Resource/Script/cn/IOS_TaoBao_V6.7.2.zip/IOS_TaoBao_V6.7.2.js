﻿/*[config]
<plugin name="淘宝,7" group="生活旅游,6" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/TaoBao.png" app="com.taobao.taobao4iphone" version="6.7.2" description="淘宝" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.taobao.taobao4iphone</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width = "100"></item>
    <item name="登录名" code="UserInputName" type="string" width = "150"></item>
    <item name="淘宝昵称" code="NickName" type="string" width="120"></item>
    <item name="电话号码" code="Mobile" type="string" width="150"></item>
    <item name="头像" code="HeadUrl" type="url" width = "120"></item>
    <item name="是否最后登录" code="IsLastLoading" type="string" width = "120"></item>
</data>
<data type="Log" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="时间" code="Time" type="string" width="150"></item>
    <item name="内容" code="Content" type="string" width="150"></item>
</data>
<data type = "Search" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="名称" code="Name" type="string" width = "80" ></item>
</data>
</plugin>
[config]*/
function Log(){
    this.DataState = "Normal";
    this.Time = "";
    this.Content = "";
}
function Search() {
    this.Name = "";
    this.DataState = "Normal";
}
//定义数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserInputName = "";
    this.NickName = "";
    this.Mobile = "";
    this.UserId = "";
    this.HeadUrl = "";
    this.IsLastLoading = "";
}

function News(){
    this.DataState = "Normal";
    this.List = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var upath = source[0]+"\\com.taobao.taobao4iphone\\Documents\\FE75BAA4-5FE2-461C-8CDD-41C8B11A3DA5";
var searchPath = source[0]+"\\com.taobao.taobao4iphone\\Library\\Preferences\\com.taobao.taobao4iphone.plist";
//测试数据
//var upath = "C:\\XLYSFTasks\\任务-2017-06-02-14-53-22\\source\\IosData\\2017-06-02-14-53-36\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.taobao.taobao4iphone\\Documents\\FE75BAA4-5FE2-461C-8CDD-41C8B11A3DA5";
//var searchPath = "C:\\XLYSFTasks\\任务-2017-06-02-14-53-22\\source\\IosData\\2017-06-02-14-53-36\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.taobao.taobao4iphone\\Library\\Preferences\\com.taobao.taobao4iphone.plist";
//定义特征库文件
var charactor = "chalib\\Android_Chelaile_V3.24.2\\com.ygkj.chelaile.db.charactor";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "淘宝";
    root.Type = "";
    getNews(root);
    
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(upath)){
        var data = eval('('+ XLY.PList.MacReadToJsonString(upath) +')');
        var aur = "";
        if(XLY.File.IsValid(searchPath)){
            var data1 = eval('('+ XLY.PList.ReadToJsonString(searchPath) +')');
            if(data1!=""&&data1!=null){
                for(var d in data1){
                    if(data1[d].WXLogUtils_lastUsernick!=""&&data1[d].WXLogUtils_lastUsernick!=null){
                        aur = data1[d].WXLogUtils_lastUsernick;
                    }
                }
            }
        }
        if(data!=""&&data!= null){
            for(var i in data){
                if(i=="$objects"){
                    var aa = data[i];
                    for(var a in aa){
                        if(aa[a]!="$null"){
                            var bb = eval('('+ aa[a] +')');
                            if(bb.users!=""&&bb.users!= null){
                                var usernode = new TreeNode();
                                usernode.Text = "账号信息";
                                usernode.Type = "UserInfo";
                                var cc = bb.users;
                                for(var c in cc){
                                    var obj = new UserInfo();
                                    obj.UserInputName = cc[c].userInputName;
                                    obj.NickName = cc[c].taobaoNick;
                                    obj.Mobile = cc[c].mobile;
                                    obj.UserId = cc[c].userId;
                                    obj.HeadUrl = cc[c].headImg;
                                    if(aur!=""&&aur == cc[c].userInputName){
                                        obj.IsLastLoading = "是";
                                    }
                                    else
                                    {
                                        obj.IsLastLoading = "否";
                                    }
                                    usernode.Items.push(obj);
                                }
                                root.TreeNodes.push(usernode); 
                                getUserChildNode(root);   
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        
    }
}
function getUserChildNode(root){
    if(XLY.File.IsValid(searchPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(searchPath) +')');
        var reg = new RegExp("fdcb5fb92c1a4d616cdb9ac092e78f38");
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].fdcb5fb92c1a4d616cdb9ac092e78f38!=""&&data[i].fdcb5fb92c1a4d616cdb9ac092e78f38!=null){
                    var aa = data[i].fdcb5fb92c1a4d616cdb9ac092e78f38;
                    var node = new TreeNode();
                    node.Text = "搜索关键字";
                    node.Type = "Search";
                    if(aa!=""&&aa!=null){
                        for(var a in aa){
                            var searchobj = new Search();
                            searchobj.Name = aa[a][0];
                            node.Items.push(searchobj);
                        }
                    }
                    if(node.Items!=""&&node.Items!=null){
                        root.TreeNodes.push(node);
                    }
                }
            }
        }
    }
}