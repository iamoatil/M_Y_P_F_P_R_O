﻿
//descritpion:配置模板

/*[config]
<plugin name="快牙,10" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/kuaiya.png" app="com.dewmobile.kuaiya" version="3.7.2" description="快牙" data="$data,ComplexTreeDataSource"  >
<source>
    <value>/data/data/com.dewmobile.kuaiya/databases#F</value>
    
</source>
<data type = "User">
    <item name="ID" code="userID" type="int" width = "" ></item>
    <item name="昵称" code="nick" type="string" width="" format=""></item>
    <item name="最后一次登录时间" code="lastDate" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>

<data type = "Message" detailfield = "body" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="消息发送者" code="sender" type="string" width="150" format = ""></item>
    <item name="消息接收者" code="receiver" type="string" width="150" format = ""></item>
    <item name="消息内容" code="body" type="string" width="700" format = ""></item>
    <item name="消息类型" code="type" type="string" width="80" format = "" order="desc"></item>
    <item name="发送时间" code="time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>

<data type = "Transfer" detailfield = "" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="文件发送者" code="sender" type="string" width="150" format = ""></item>
    <item name="文件接收者" code="receiver" type="string" width="150" format = ""></item>
    <item name="传输文件信息" code="body" type="string" width="700" format = ""></item>
    <item name="传输文件类型" code="type" type="string" width="80" format = "" order="desc"></item>
    <item name="发送时间" code="time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>

</plugin>
[config]*/

// js content

//<item name="备注" code="remark" type="string" width="120" format = ""></item>

function User() {
    this.userID = 0;    //ID
    this.nick = ""; //昵称
    this.lastDate = null;   //最后一次登录时间
}

function Message() {
    this.DataState = "Normal";  //数据状态
    this.sender = "";   //消息发送者
    this.receiver = ""; //消息接收者
    this.body = ""; //消息内容
    this.type = ""; //消息类型
    this.time = null;   //发送时间
}

function Transfer() {
    this.DataState = "Normal";  //数据状态
    this.sender = "";   //消息发送者
    this.receiver = ""; //消息接收者
    this.body = ""; //消息内容
    this.type = ""; //消息类型
    this.time = null;   //发送时间
}

function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

function creatTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

function bindTree(path){
    var filePath = eval('('+ XLY.File.FindFiles(path) +')');
    var root = creatTreeNode("本地帐号","User")
    for(var i in filePath){
        var userReg = /_emmsg.db$/;
        var fileName = XLY.File.GetFileName(filePath[i]);
        if(userReg.test(fileName)){
            userNum = fileName.substr(0,fileName.indexOf("_"));
            var userInfo = getAccountInfo(userNum,path+"\\im_user.db");
            root.Items.push(userInfo);
            if(userInfo.nick==""){
                var accountTree = creatTreeNode(userNum,"User");
            }else{
                var accountTree = creatTreeNode(userInfo.nick,"User");
            }
            root.TreeNodes.push(accountTree);
            buildAccountTreeNodes(filePath[i],accountTree,userInfo);
        }
    }
    return root;
}

function getAccountInfo(id,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select p_uid,p_tm,p_pf from profiles where p_uid = '"+id+"'") +')');
    var obj = new User();
    obj.userID = id;
    if(data.length >0){  
      obj.lastDate = XLY.Convert.LinuxToDateTime(data[0].p_tm);
      var nickInfo = eval('('+ data[0].p_pf +')');
      obj.nick = nickInfo.nick;
    }
  return obj;
}


function buildAccountTreeNodes(path,root,uinfo){
    var friendList = eval('('+ XLY.Sqlite.Find(path,"select username from conversation_list") +')');
    if(friendList.length >0){
        for(var i in friendList){
            //装入入帐号信息
            var friendInfo = getAccountInfo(friendList[i].username,path.substr(0,path.indexOf("databases")+9)+"\\im_user.db");
            root.Items.push(friendInfo);
            
            //创建好友节点，并写入帐号节点中
            if(friendInfo.nick==null){
                var friendTree = creatTreeNode(friendList[i].username,"User");
            }
            var friendTree = creatTreeNode(friendInfo.nick,"Message")
            root.TreeNodes.push(friendTree);
            //装入好友聊天信息
            var friendInfo = getFriendMessage(path,friendInfo,root.Text);
            friendTree.Items = friendInfo;
            
            
           
        }
    }
    //创建文件传输节点，并写入帐号节点中
    var fileTransfer = creatTreeNode("文件传输","Transfer");
    root.TreeNodes.push(fileTransfer);
     //装入文件传输节点信息
    var fileTransferInfo = getFileTransfer(uinfo,path.substr(0,path.indexOf("databases")+9)+"\\transfer20.db");
    fileTransfer.Items = fileTransferInfo;
    
    
}


function getFriendMessage(path,finfo,userName){
    var data = eval('('+ XLY.Sqlite.Find(path,"select msgtime,msgbody from chat  where participant = '"+finfo.userID+"'") +')');
    var arr = new Array();
    if(data.length>0){
        for(var i in data){
            var obj = new Message();
            var info = eval('('+ data[i].msgbody +')');
            if(info.from==finfo.userID){
                obj.sender = finfo.nick;
                obj.receiver = userName;
            }
            else{
                obj.sender = userName;
                obj.receiver = finfo.nick;
            }

            switch(info.ext.z_msg_type){
                case 1: 
                obj.body = "文件名称:"+info.ext.z_msg_name+"\n文件路径:"+info.ext.z_msg_s_path+"\n文件大小:"+info.ext.z_msg_size+"Byte\n文件URL:"+info.ext.z_msg_t_url+"\n文件到期时间:"+ XLY.Convert.LinuxToDateTime(info.ext.z_msg_exp);
                obj.type = "图片";
                break;
                
                case 2: 
                obj.body = "文件名称:"+info.ext.z_msg_name+"\n文件路径:"+info.ext.z_msg_s_path+"\n文件大小:"+info.ext.z_msg_size+"Byte\n文件URL:"+info.ext.z_msg_t_url+"\n文件到期时间:"+ XLY.Convert.LinuxToDateTime(info.ext.z_msg_exp);
                obj.type = "音乐";
                break;
                
                case 3:
                obj.body = "文件名称:"+info.ext.z_msg_name+"\n文件路径:"+info.ext.z_msg_s_path+"\n文件大小:"+info.ext.z_msg_size+"Byte\n文件URL:"+info.ext.z_msg_t_url+"\n文件到期时间:"+ XLY.Convert.LinuxToDateTime(info.ext.z_msg_exp);
                obj.type = "视频";
                break;
                
                case 4:
                obj.body = "文件名称:"+info.ext.z_msg_name+"\n文件路径:"+info.ext.z_msg_s_path+"\n文件大小:"+info.ext.z_msg_size+"Byte\n文件URL:"+info.ext.z_msg_t_url+"\n文件到期时间:"+ XLY.Convert.LinuxToDateTime(info.ext.z_msg_exp);
                obj.type = "文件";
                break;
                
                case 5:
                obj.body = "文件名称:"+info.ext.z_msg_name+"\n文件路径:"+info.ext.z_msg_s_path+"\n文件大小:"+info.ext.z_msg_size+"Byte\n文件URL:"+info.ext.z_msg_t_url+"\n文件版本信息:"+info.ext.z_msg_apk_info+"\n文件到期时间"+ XLY.Convert.LinuxToDateTime(info.ext.z_msg_exp);
                obj.type = "应用";
                break;
                
                case 21:
                obj.body = "推荐文件:"+info.ext.z_msg_recommend_req_info.a+"\n文件路径:"+info.ext.z_msg_recommend_req_info.d+"\n索要内容:"+info.bodies.msg+"\n文件到期时间"+XLY.Convert.LinuxToDateTime(info.ext.z_msg_recommend_req_info.e);
                obj.type = "索要文件";
                break;
                
                case 20:
                obj.body = "推荐文件名:"+info.ext.z_msg_name.msg+"\n推荐内容:"+info.bodies[0].msg;
                obj.type = "推荐文件";
                break;
                
                case 31:
                obj.body = "联系人:"+info.ext.z_msg_name;
                obj.type = "联系人";
                break;
                
                default:
                obj.body = info.bodies[0].msg;
                obj.type = "文本";
                break;
            }
            obj.time = XLY.Convert.LinuxToDateTime(data[i].msgtime);      
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            arr.push(obj);
        }
    }
    return arr;
}

function getFileTransfer(uinfo,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select exc_cat,device,direction,createtime,category,path,totalbytes,title from transfer where exc_cat = '"+uinfo.userID+"'") +')');
    var arr = new Array();    
    if(data.length>0){
        for(var i in data){
            var obj = new Transfer();
                obj.DataState = "Normal";
                if(data[i].direction==3){
                    obj.sender = uinfo.nick;
                    obj.receiver = getUserNick(data[i].device,pPath+"\\im_user.db");
                }else{
                    obj.receiver = uinfo.nick;
                    obj.sender = getUserNick(data[i].device,pPath+"\\im_user.db");
                }
                obj.body = "文件名称："+data[i].title+"\n文件大小"+data[i].totalbytes+"\n文件路径"+data[i].path;
                if(data[i].category=="image"){
                    obj.type = "图片";
                }
                else if(data[i].category=="video")
                {
                    obj.type = "视频";
                }
                else if(data[i].category=="folder")
                {
                    obj.type = "文件";
                }else
                {
                    obj.type = data[i].category;
                }
                //obj.type = data[i].category;
                obj.time = XLY.Convert.LinuxToDateTime(data[i].createtime);
                arr.push(obj);
        }
    }
    return arr;
}
    
//获取用户昵称
function getUserNick(uid,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select p_pf from profiles where p_uid = '"+uid+"'") +')');
    if(data.length>0){
          var nickInfo = eval('('+ data[0].p_pf +')');
          if(nickInfo.nick.length>0){
              return nickInfo.nick;
          }
    }
    return uid;
}

var source = $source;
var pPath = source[0];
//var pPath = "D:\\temp\\data\\data\\com.dewmobile.kuaiya1\\databases";
//var charactor = "\\chalib\\Android_Skype_5.0.99\\main.db.charactor";
var result = new Array();

result.push(bindTree(pPath));
var res  = JSON.stringify(result);
res;

