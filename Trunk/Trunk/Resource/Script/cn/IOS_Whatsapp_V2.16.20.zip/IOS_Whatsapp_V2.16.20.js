﻿/*[config]
<plugin name="Whatsapp,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/whatsapp.png" app="WhatsApp" version="2.16.20" description="net.whatsapp.WhatsApp" data="$data,ComplexTreeDataSource" >
<source>
    <value>AppDomainGroup-group.net.whatsapp.WhatsApp.shared</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="Name" type="string" width = "120" format=""></item>
    <item name="版本" code="Version" type="string" width = "120" format=""></item>
    <item name="平台" code="Platform" type="string" width = "120" format=""></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="AccountNumber" type="string" width="120" format = "" ></item>
    <item name="昵称" code="UserName" type="string" width="120" format = "" ></item>
    <item name="当前状态" code="CurrentCondition" type="string" width="120" format=""></item>
    <item name="头像路径" code="HeadUrlPath" type="string" width="200" format=""></item>
</data>
<data type="List" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List1" type="string" width="120" format = "" ></item>
</data>
<data type="Contact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="AccountNumber" type="string" width="120" format = ""></item>
    <item name="昵称" code="UserName" type="string" width="120" format = ""></item>
    <item name="电话号码" code="PhoneNumbr" type="string" width="120" format = ""></item>
    <item name="电话类型" code="PhoneType" type="string" width="120" format = ""></item>
</data>
<data type="FriendInfo" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="AccountNumber" type="string" width="100" format="" ></item>
    <item name="昵称" code="UserName" type="string" width="120" format = ""></item>
    <item name="号码" code="PhoneNumbr" type="string" width="120" format=""></item>
    <item name="当前状态" code="CurrentCondition" type="string" width="200" format=""></item>
    <item name="头像路径" code="HeadUrlPath" type="string" width="120" format=""></item>
</data>
<data type="GroupInfo" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群组账号" code="GroupAccountNumber" type="string" width="120" format=""></item>
    <item name="群组昵称" code="GroupName" type="string" width="120" format = ""></item>
    <item name="创建者账号" code="CreateAccountNumber" type="string" width="100" format = ""></item>
    <item name="头像路径" code="HeadUrlPath" type="string" width="100" format = ""></item>
</data>
<data type="BroadCast" contract="DataState" datefilter="LastTime">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="广播账号" code="AccountNumber" type="string" width="120" format=""></item>
    <item name="广播名称" code="Name" type="string" width="160" format=""></item>
    <item name="广播创建者账号" code="CreateAccountNumber" type="string" width="120" format=""></item>
    <item name="广播创建者名称" code="CreateName" type="string"  width="150" format=""></item>
</data>
<data type="BroadCastMem" contract="DataState" datefilter="LastTime">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="ID" code="MemID" type="string" width="120" format=""></item>
    <item name="名称" code="Name" type="string" width="160" format=""></item>
    <item name="账号" code="AccountNumber" type="string" width="120" format=""></item>
    <item name="是否被移除" code="IsDelete" type="string"  width="150" format=""></item>
</data>
<data type="GroupMember" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="成员昵称" code="MemberName" type="string" width="120" format = ""></item>
    <item name="成员账号" code="MemberAccountNumber" type="string" width="120" format = ""></item>
    <item name="是否被移除" code="IsDelete" type="string" width="120" format = ""></item>
    <item name="是否是管理员" code="IsAdmin" type="string" width="120" format = ""></item>
</data>
<data type="FriendChatLog" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者账号" code="SenderAccountNumber" type="string" width="120" format = ""></item>
    <item name="发送者昵称" code="SenderNickName" type="string" width="120" format = "" ></item>
    <item name="接收者账号" code="ReceiveAccountNumber" type="string" width="120" format = ""></item>
    <item name="接收者昵称" code="ReceiveNickName" type="string" width="100" format = "" ></item>
    <item name="时间" code="Time" type="string" width="100" format = "" ></item>
    <item name="内容" code="Body" type="string" width="100" format = "" ></item>
    <item name="类型" code="Type" type="string" width="100" format = "" ></item>
</data>
<data type="GroupChatLog" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者账号" code="SenderAccountNumber" type="string" width="120" format = ""></item>
    <item name="发送者昵称" code="SenderNickName" type="string" width="100" format = "" ></item>
    <item name="接收者账号" code="ReceiveAccountNumber" type="string" width="120" format = ""></item>
    <item name="接收者昵称" code="ReceiveNickName" type="string" width="100" format = "" ></item>
    <item name="时间" code="Time" type="string" width="100" format = "" ></item>
    <item name="内容" code="Body" type="string" width="100" format = "" ></item>
    <item name="类型" code="Type" type="string" width="100" format = "" ></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.Name = "";
    this.Version = "";
    this.Platform = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.AccountNumber = "";
    this.UserName = "";
    this.CurrentCondition = "";
    this.HeadUrlPath = "";
}
function List(){
    this.DataState = "Normal";
    this.List1 = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.AccountNumber = "";
    this.UserName = "";
    this.PhoneNumbr = "";
    this.PhoneType = "";
}
//定义FriendInfo数据结构
function FriendInfo(){
    this.DataState = "Normal";
    this.AccountNumber = "";
    this.UserName = "";
    this.PhoneNumbr = "";
    this.CurrentCondition = "";
    this.HeadUrlPath = "";
}
//定义GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupAccountNumber = "";
    this.GroupName = "";
    this.CreateAccountNumber = "";
    this.HeadUrlPath = "";
}
//定义BroadCast数据结构
function BroadCast(){
    this.DataState = "Normal";
    this.AccountNumber = "";
    this.Name = "";
    this.CreateAccountNumber = "";
    this.CreateName = "";
}
//定义BroadCastMem数据结构
function BroadCastMem(){
    this.DataState = "Normal";
    this.MemID = "";
    this.Name = "";
    this.AccountNumber = "";
    this.IsDelete = "";
}
//定义GroupMember数据结构
function GroupMember(){
    this.DataState = "Normal";
    this.MemberName = "";
    this.MemberAccountNumber = "";
    this.IsDelete = "";
    this.IsAdmin = "";
}
//定义FriendChatLog数据结构
function FriendChatLog(){
    this.DataState = "Normal";
    this.SenderAccountNumber = "";
    this.SenderNickName = "";
    this.ReceiveAccountNumber = "";
    this.ReceiveNickName = "";
    this.Time = "";
    this.Body = "";
    this.Type = "";
}
//定义GroupChatLog数据结构
function GroupChatLog(){
    this.DataState = "Normal";
    this.SenderAccountNumber = "";
    this.SenderNickName = "";
    this.ReceiveAccountNumber = "";
    this.ReceiveNickName = "";
    this.Time = "";
    this.Body = "";
    this.Type = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userInfoPath = source[0]+"\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\Library\\Preferences\\group.net.whatsapp.WhatsApp.shared.plist";
var chatStoragePath1 = source[0]+"\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\ChatStorage.sqlite";
var contactsPath1 = source[0]+"\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\Contacts.sqlite";

//测试数据
//var userInfoPath = "C:\\XLYSFTasks\\任务-2017-01-20-14-30-23\\source\\IosData\\2017-01-20-14-31-06\\1f9e8c508b38659f075e2936aa6662a4c8761eaf\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\Library\\Preferences\\group.net.whatsapp.WhatsApp.shared.plist";
//var chatStoragePath1 = "C:\\XLYSFTasks\\任务-2017-01-20-14-30-23\\source\\IosData\\2017-01-20-14-31-06\\1f9e8c508b38659f075e2936aa6662a4c8761eaf\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\ChatStorage.sqlite";
//var contactsPath1 = "C:\\XLYSFTasks\\任务-2017-01-20-14-30-23\\source\\IosData\\2017-01-20-14-31-06\\1f9e8c508b38659f075e2936aa6662a4c8761eaf\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\Contacts.sqlite";

//定义特征库文件
//var chatStorageCharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\IOS_Whatsapp_V2.16.20\\ChatStorage.sqlite.charactor";
//var contactsCharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\IOS_Whatsapp_V2.16.20\\Contacts.sqlite.charactor";
var chatStorageCharactor = "\\chalib\\IOS_Whatsapp_V2.16.20\\ChatStorage.sqlite.charactor";
var contactsCharactor = "\\chalib\\IOS_Whatsapp_V2.16.20\\Contacts.sqlite.charactor";


//恢复数据库中删除的数据
var chatStoragePath = XLY.Sqlite.DataRecovery(chatStoragePath1,chatStorageCharactor,"ZWAPROFILEPICTUREITEM,ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAMESSAGE,ZWAPROFILEPUSHNAME,ZWAMEDIAITEM,ZWAGROUPMEMBERSCHANGE");
var contactsPath = XLY.Sqlite.DataRecovery(contactsPath1,contactsCharactor,"ZWACONTACT,ZWAPHONE,ZWASTATUS,ZWAJIDCAPABILITIES");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "Whatsapp";
    news.Type = "News";
    news.Items.push(getNews());

    var userNode = new TreeNode();
    userNode.Text = "账户信息";
    userNode.Type = "UserInfo";
    userNode.Items = getUserInfo(userInfoPath,chatStoragePath);
    
    var contactNode = new TreeNode();
    contactNode.Text = "联系人";
    contactNode.Type = "Contact";
    contactNode.Items = getContactNode(contactsPath);
    
    var broadcastNode = new TreeNode();
    broadcastNode.Text = "广播";
    broadcastNode.Type = "BroadCast";
    broadcastNode.Items = getBroadcastNode(chatStoragePath,userNode.Items,broadcastNode);
    
    var friendNode = new TreeNode();
    friendNode.Text = "好友";
    friendNode.Type = "FriendInfo";
    friendNode.Items = getFriendNode(contactsPath,chatStoragePath);

    var groupNode = new TreeNode();
    groupNode.Text = "群组";
    groupNode.Type = "GroupInfo";
    groupNode.Items = getGroupNode(chatStoragePath,groupNode,userNode.Items);
    
    var chatNode = new TreeNode();
    chatNode.Text = "会话";
    chatNode.Type = "List";
    chatNode.Items = getChatNode(chatStoragePath,chatNode,userNode.Items);
    
    news.TreeNodes.push(userNode);
    news.TreeNodes.push(contactNode);
    news.TreeNodes.push(friendNode);
    news.TreeNodes.push(broadcastNode);
    news.TreeNodes.push(groupNode);
    news.TreeNodes.push(chatNode);
    result.push(news);
}

//获取功能列表
function getNews(){
    var obj = new News();
    obj.Name = "Whatsapp";
    obj.Version = "2.16.20";
    obj.Platform = "IOS";
    return obj;
}

//获取账户信息
function getUserInfo(path,cpath){
    if(XLY.File.IsValid(path)&&XLY.File.IsValid(cpath)){
        var list = new Array();
        var data = eval('('+ XLY.PList.ReadToJsonString(path) +')');
        var user = new UserInfo();
        for(var i in data){
            user.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            if(data[i].CurrentStatusText!=""&&data[i].CurrentStatusText!=null){
                user.CurrentCondition = data[i].CurrentStatusText;
            }
            if(data[i].OwnJabberID!=""&&data[i].OwnJabberID!=null){
                user.AccountNumber = data[i].OwnJabberID;
                var cdata = eval('('+ XLY.Sqlite.Find(cpath,"select ZPATH from ZWAPROFILEPICTUREITEM where ZJID = '"+user.AccountNumber+"'") +')');
                user.HeadUrlPath = cdata[0].ZPATH;
            }
            if(data[i].FullUserName!=""&&data[i].FullUserName!=null){
                user.UserName = data[i].FullUserName;
            }
        }
        list.push(user);
        return list;
    }
}

//获取ContactNode
function getContactNode(path){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select Z_PK,ZFULLNAME,ZTOKENS,XLY_DataType from ZWACONTACT") +')');
        var data1 = eval('('+ XLY.Sqlite.Find(path,"select Z_PK,ZLABEL,ZPHONE,ZWHATSAPPID,XLY_DataType from ZWAPHONE") +')');
        if(data!=""&&data!= null){
            for(var i in data){
                if(data[i].Z_PK!=""&&data[i].Z_PK!=null){
                    var obj = new Contact();
                    obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    obj.UserName = data[i].ZFULLNAME;
                    for(var j in data1){
                        if(data[i].Z_PK==data1[j].Z_PK){
                            obj.AccountNumber = data1[j].ZWHATSAPPID+"@s.whatsapp.net";
                            obj.PhoneNumbr = data1[j].ZPHONE;
                            obj.PhoneType = data1[j].ZLABEL;
                        }
                    }
                    arr.push(obj);
                }
            }
        }
        return arr;
    }
}

//获取FriendNode信息
function getFriendNode(path1,path2){
    if(XLY.File.IsValid(path1)){
        if(XLY.File.IsValid(path2)){
            var list = new Array();
            var data = eval('('+ XLY.Sqlite.Find(path1,"select Z_PK,ZWHATSAPPID,ZTEXT,ZPHONE,XLY_DataType from ZWASTATUS") +')');
            var data1 = eval('('+ XLY.Sqlite.Find(path1,"select Z_PK,ZFULLNAME,XLY_DataType from ZWACONTACT") +')');
            var data2 = eval('('+ XLY.Sqlite.Find(path1,"select Z_PK,ZCONTACT,ZLABEL,ZPHONE,ZWHATSAPPID,XLY_DataType from ZWAPHONE") +')');
            var data3 = eval('('+ XLY.Sqlite.Find(path2,"select ZPATH,ZJID,XLY_DataType from ZWAPROFILEPICTUREITEM") +')');
            var data4 = eval('('+ XLY.Sqlite.Find(path1,"select Z_PK,ZJID,XLY_DataType from ZWAJIDCAPABILITIES") +')');
            if(data!=""&&data!= null){
                for(var i in data){
                    if(data2!=""&&data2!= null){
                        for(var j in data2){
                            if(data[i].ZPHONE==data2[j].Z_PK){
                                var obj = new FriendInfo();
                                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                                obj.AccountNumber = data2[j].ZWHATSAPPID;
                                obj.PhoneNumbr = data2[j].ZPHONE;
                                //obj.Label = data2[j].ZLABEL;
                                for(var m in data1){
                                    if(data1[m].Z_PK==data2[j].ZCONTACT){
                                        obj.UserName = data1[m].ZFULLNAME;
                                    }
                                }
                                obj.CurrentCondition = data[i].ZTEXT;
                                if(data4!=""&&data4!= null){
                                    for(var t in data4){
                                        if(data[i].Z_PK==data4[t].Z_PK){
                                            if(data3!=""&&data3!= null){
                                                for(var n in data3){
                                                    if(data3[n].ZJID==data4[t].ZJID){
                                                        obj.HeadUrlPath = data3[n].ZPATH;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                list.push(obj);
                            }
                        }
                    }
                }
            }
            return list;
        }
    }
}
//获取GroupNode信息
function getGroupNode(path,root,user){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select Z_PK,ZGROUPINFO,ZCONTACTJID,ZPARTNERNAME,XLY_DataType from ZWACHATSESSION") +')');
        var data1 = eval('('+ XLY.Sqlite.Find(path,"select ZCHATSESSION,ZCREATORJID,XLY_DataType from ZWAGROUPINFO") +')');
        var data2 = eval('('+ XLY.Sqlite.Find(path,"select ZCHATSESSION,ZISADMIN,ZCONTACTNAME,ZMEMBERJID,XLY_DataType from ZWAGROUPMEMBER") +')');
        var data3 = eval('('+ XLY.Sqlite.Find(path,"select ZPATH,ZJID,XLY_DataType from ZWAPROFILEPICTUREITEM") +')');
        if(data!=""&&data!= null){
            for(var i in data){
                if(data[i].ZGROUPINFO!=""&&data[i].ZGROUPINFO!=null){
                    var grouplist = new GroupInfo();
                    grouplist.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    grouplist.GroupAccountNumber = data[i].ZCONTACTJID;
                    grouplist.GroupName = data[i].ZPARTNERNAME;
                    if(data1!=""&&data1!= null){
                        for(var j in data1){
                            if(data[i].Z_PK==data1[j].ZCHATSESSION){
                                grouplist.CreateAccountNumber = data1[j].ZCREATORJID;
                            }
                        }
                    }
                    if(data3!=""&&data3!= null){
                        for(var n in data3){
                            if(data3[n].ZJID==data[i].ZCONTACTJID){
                                grouplist.HeadUrlPath = data3[n].ZPATH;
                            }
                        }
                    }
                    list.push(grouplist);
                    
                    var node = new TreeNode();
                    node.Text = data[i].ZPARTNERNAME;
                    node.Type = "GroupMember";
                    if(data2!=""&&data2!= null){
                        for(var m in data2){
                            if(data[i].Z_PK==data2[m].ZCHATSESSION){
                                node.Items.push(getGroupMemInfo(data2[m],user,path,grouplist.GroupAccountNumber));
                            }
                        }
                    }
                    root.TreeNodes.push(node);
                }
            }
        }        
        return list;
    }
}
//获取GroupMemInfo信息
function getGroupMemInfo(info,user,path,groupid){
    var data = eval('('+ XLY.Sqlite.Find(path,"select ZCHANGETYPE,ZGROUPJID from ZWAGROUPMEMBERSCHANGE where ZMEMBERJIDS = '"+info.ZMEMBERJID+"'") +')');
    var groupmember = new GroupMember();
    groupmember.DataState = XLY.Convert.ToDataState(info.XLY_DataType);
    if(info.ZMEMBERJID==user[0].AccountNumber){
        groupmember.MemberName = user[0].UserName;
    }
    else
    {
        groupmember.MemberName = info.ZCONTACTNAME;
    }
    groupmember.MemberAccountNumber = info.ZMEMBERJID;
    var aa = 0;
    var bb = 0;
    for(var i in data){
        if(data[i].ZCHANGETYPE==1&&data[i].ZGROUPJID==groupid){
            aa+=1;
        }
        if(data[i].ZCHANGETYPE==0&&data[i].ZGROUPJID==groupid){
            bb+= 1;
        }
    }
    if(aa<bb){
        groupmember.IsDelete = "否";
    }
    else
    {
        groupmember.IsDelete = "是";
    }
    if(info.ZISADMIN==1){
        groupmember.IsAdmin = "是";
    }
    else
    {
        groupmember.IsAdmin = "否";
    }
    return groupmember;
}
//获取ChatNode信息
function getChatNode(path,root,user){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        //
        var data = eval('('+ XLY.Sqlite.Find(path,"select distinct(ZSESSIONTYPE),XLY_DataType from ZWACHATSESSION") +')');
        //var data1 = eval('('+ XLY.Sqlite.Find(path,"select ZCHATSESSION,ZMESSAGEDATE,ZFROMJID,ZTEXT,ZTOJID from ZWAMESSAGE") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].ZSESSIONTYPE==1){
                    var node = new TreeNode();
                    node.Text = "群组聊天记录";
                    node.Type = "List";
                    node.Items = getGroupChatLog(1,path,node,user);
                    root.TreeNodes.push(node);
                    var aa = new List();
                    aa.List1 = node.Text;
                    list.push(aa);
                }
                if(data[i].ZSESSIONTYPE==0){
                    var node = new TreeNode();
                    node.Text = "好友聊天记录";
                    node.Type = "List";
                    node.Items = getGroupChatLog(null,path,node,user);
                    root.TreeNodes.push(node);
                    var aa = new List();
                    aa.List1 = node.Text;
                    list.push(aa);
                }
                if(data[i].ZSESSIONTYPE==2){
                    var node = new TreeNode();
                    node.Text = "广播记录";
                    node.Type = "List";
                    node.Items = getGroupChatLog(2,path,node,user);
                    root.TreeNodes.push(node);
                    var aa = new List();
                    aa.List1 = node.Text;
                    list.push(aa);
                }
            }
        }
        return list;
    }
}
//获取GroupChatLog信息
function getGroupChatLog(info,path,root,user){
    var list = new Array();
    if(info==""||info==0||info==null){
        var data = eval('('+ XLY.Sqlite.Find(path,"select Z_PK,ZCONTACTJID,ZPARTNERNAME,XLY_DataType from ZWACHATSESSION where ZSESSIONTYPE = '"+0+"'") +')');
    }
    if(info==1){
        var data = eval('('+ XLY.Sqlite.Find(path,"select Z_PK,ZCONTACTJID,ZPARTNERNAME,XLY_DataType from ZWACHATSESSION where ZSESSIONTYPE = '"+info+"'") +')');
    }
    if(info==2){
        var data = eval('('+ XLY.Sqlite.Find(path,"select Z_PK,ZCONTACTJID,ZPARTNERNAME,XLY_DataType from ZWACHATSESSION where ZSESSIONTYPE = '"+info+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var node = new TreeNode();
                if(data[i].ZPARTNERNAME!=""&&data[i].ZPARTNERNAME!=null){
                    node.Text = data[i].ZCONTACTJID+"("+data[i].ZPARTNERNAME+")";
                }
                else
                {
                    node.Text = data[i].ZCONTACTJID;
                }
                node.Type = "GroupChatLog";
                node.Items = getChatLogToBroadCast(path,data[i],user);
                root.TreeNodes.push(node);
                var obj = new List();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.List1 = node.Text;
                
                list.push(obj);
            }
        }
    }
    else
    {
        if(data!=""&&data!=null){
            for(var i in data){
                var node = new TreeNode();
                node.Text = data[i].ZPARTNERNAME;
                node.Type = "GroupChatLog";
                node.Items = getChatLogTo(path,data[i].ZCONTACTJID,data[i].Z_PK,data[i].ZPARTNERNAME,user);
                root.TreeNodes.push(node);
                var obj = new List();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.List1 = node.Text;
                
                list.push(obj);
            }
        }
    }
    return list;
}

function getChatLogTo(path,info,zpk,name,user){
    var arr = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select ZPARENTMESSAGE,ZCHATSESSION,ZFROMJID,ZPUSHNAME,ZTEXT,ZTOJID,ZMEDIAITEM,cast(ZSENTDATE as int) as time,ZMESSAGETYPE,XLY_DataType from ZWAMESSAGE where ZCHATSESSION = '"+zpk+"' and ZMESSAGETYPE!='10' and ZMESSAGETYPE!='6'") +')');
    if(data!=""&&data!= null){
        for(var i in data){
            var obj = new GroupChatLog();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            if(data[i].ZFROMJID==info){
                if(data[i].ZPUSHNAME!=""&&data[i].ZPUSHNAME!=null){
                    obj.SenderNickName = data[i].ZPUSHNAME;
                    var aa = eval('('+ XLY.Sqlite.Find(path,"select ZJID from ZWAPROFILEPUSHNAME where ZPUSHNAME = '"+data[i].ZPUSHNAME+"'") +')');
                    if(aa!=""&&aa!=null){
                        obj.SenderAccountNumber = aa[0].ZJID;
                    }
                }
                else
                {
                    obj.SenderNickName = name;
                    obj.SenderAccountNumber = data[i].ZFROMJID;
                }
            }
            else
            {
                obj.SenderNickName = user[0].UserName;
                obj.SenderAccountNumber = user[0].AccountNumber;
            }
            
            if(data[i].ZTOJID==info){
                obj.ReceiveNickName = name;
                obj.ReceiveAccountNumber = data[i].ZTOJID;
            }
            else
            {
                obj.ReceiveNickName = user[0].UserName;
                obj.ReceiveAccountNumber = user[0].AccountNumber;
            }
            
            obj.Time = data[i].time;
            if(data[i].ZMESSAGETYPE==1){
                if(data[i].ZPARENTMESSAGE!=""&&data[i].ZPARENTMESSAGE!=null){
                    obj.Type = "图片(广播)";
                }
                else
                {
                    obj.Type = "图片";
                }
            }
            if(data[i].ZMESSAGETYPE==3){
                if(data[i].ZPARENTMESSAGE!=""&&data[i].ZPARENTMESSAGE!=null){
                    obj.Type = "音频(广播)";
                }
                else
                {
                    obj.Type = "音频";
                }
            }
            if(data[i].ZMESSAGETYPE==11){
                if(data[i].ZPARENTMESSAGE!=""&&data[i].ZPARENTMESSAGE!=null){
                    obj.Type = "视频(广播)";
                }
                else
                {
                    obj.Type = "视频";
                }
            }
            if(data[i].ZMESSAGETYPE==5){
                if(data[i].ZPARENTMESSAGE!=""&&data[i].ZPARENTMESSAGE!=null){
                    obj.Type = "地理位置(广播)";
                }
                else
                {
                    obj.Type = "地理位置";
                }
            }
            if(data[i].ZMESSAGETYPE==4){
                if(data[i].ZPARENTMESSAGE!=""&&data[i].ZPARENTMESSAGE!=null){
                    obj.Type = "名片(广播)";
                }
                else
                {
                    obj.Type = "名片";
                }
            }
            if(data[i].ZTEXT!=""&&data[i].ZTEXT!=null){
                obj.Body = data[i].ZTEXT;
                if(data[i].ZPARENTMESSAGE!=""&&data[i].ZPARENTMESSAGE!=null){
                    obj.Type = "text(广播)";
                }
                else
                {
                    obj.Type = "text";
                }
            }
            else
            {
                if(data[i].ZMEDIAITEM!=""&&data[i].ZMEDIAITEM!=null){
                    var aa = eval('('+ XLY.Sqlite.Find(path,"select ZLATITUDE,ZLONGITUDE,ZMEDIALOCALPATH,ZMEDIAURL,ZVCARDSTRING,Z_OPT from ZWAMEDIAITEM where Z_PK = '"+data[i].ZMEDIAITEM+"'") +')');
                    if(obj.Type == "名片"){
                        obj.Body = aa[0].ZVCARDSTRING;
                    }
                    else if(obj.Type == "地理位置")
                    {
                        obj.Body = "纬度："+aa[0].ZLATITUDE+"\r"+"经度："+aa[0].ZLONGITUDE;
                    }
                    else
                    {
                        if(aa[0].ZMEDIALOCALPATH!=""&&aa[0].ZMEDIALOCALPATH!=null){
                            obj.Body = "媒体文件本地路径：net.whatsapp.WhatsApp\\Library\\"+aa[0].ZMEDIALOCALPATH+"\r"+"媒体文件下载链接："+aa[0].ZMEDIAURL;
                        }
                    }
                }
            }
            arr.push(obj);
        }
    }
    return arr;
}

//广播
function getBroadcastNode(path,user,root){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from ZWACHATSESSION where ZCONTACTJID like '%@broadcast'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new BroadCast();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataTpe);
                obj.AccountNumber = data[i].ZCONTACTJID;
                obj.Name = data[i].ZPARTNERNAME;
                obj.CreateAccountNumber = user[0].AccountNumber;
                obj.CreateName = user[0].UserName;
                arr.push(obj);
                
                var node = new TreeNode();
                node.Text = obj.AccountNumber;
                node.Type = "BroadCastMem";
                node.Items = getBroadCastMember(data[i].Z_PK,path,obj.AccountNumber);
                root.TreeNodes.push(node);
            }
        }
        return arr;
    }
}
//获取广播成员信息
function getBroadCastMember(info,path,broadcastid){
    if(info!=""&&info!=null){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from ZWAGROUPMEMBER where ZCHATSESSION = '"+info+"'") +')');
        if(data!=""&&data!= null){
            for(var i in data){
                var data1 = eval('('+ XLY.Sqlite.Find(path,"select ZCHANGETYPE,ZGROUPJID from ZWAGROUPMEMBERSCHANGE where ZMEMBERJIDS = '"+data[i].ZMEMBERJID+"'") +')');
                var obj = new BroadCastMem();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.MemID = data[i].Z_PK;
                obj.Name = data[i].ZCONTACTNAME;
                obj.AccountNumber = data[i].ZMEMBERJID;
                var aa = 0;
                var bb = 0;
                for(var j in data1){
                    if(data1[j].ZCHANGETYPE==1&&data1[j].ZGROUPJID==broadcastid){
                        aa+=1;
                    }
                    if(data1[j].ZCHANGETYPE==0&&data1[j].ZGROUPJID==broadcastid){
                        bb+= 1;
                    }
                }
                if(aa<bb){
                    obj.IsDelete = "否";
                }
                else
                {
                    obj.IsDelete = "是";
                }
                arr.push(obj);
            }
        }
        return arr;
    }
}

function getChatLogToBroadCast(path,info,user){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select ZMESSAGETYPE,ZTEXT,ZMEDIAITEM,cast(ZSENTDATE as int) as time from ZWAMESSAGE where ZTOJID = '"+info.ZCONTACTJID+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new GroupChatLog();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.SenderAccountNumber = user[0].AccountNumber;
                obj.SenderNickName = user[0].UserName;
                obj.ReceiveAccountNumber = info.ZCONTACTJID;
                obj.ReceiveNickName = info.ZPARTNERNAME;
                obj.Time = data[i].time;
                if(data[i].ZMESSAGETYPE==1){
                    obj.Type = "图片";
                }
                if(data[i].ZMESSAGETYPE==3){
                    obj.Type = "音频";
                }
                if(data[i].ZMESSAGETYPE==11){
                    obj.Type = "视频";
                }
                if(data[i].ZMESSAGETYPE==5){
                    obj.Type = "地理位置";
                }
                if(data[i].ZMESSAGETYPE==4){
                    obj.Type = "名片";
                }
                if(data[i].ZTEXT!=""&&data[i].ZTEXT!=null){
                    obj.Type = "text";
                    obj.Body = data[i].ZTEXT;
                }
                else
                {
                    if(data[i].ZMEDIAITEM!=""&&data[i].ZMEDIAITEM!=null){
                        var aa = eval('('+ XLY.Sqlite.Find(path,"select ZLATITUDE,ZLONGITUDE,ZMEDIALOCALPATH,ZMEDIAURL,ZVCARDSTRING,Z_OPT from ZWAMEDIAITEM where Z_PK = '"+data[i].ZMEDIAITEM+"'") +')');
                        if(obj.Type == "名片"){
                            obj.Body = aa[0].ZVCARDSTRING;
                        }
                        else if(obj.Type == "地理位置")
                        {
                            obj.Body = "纬度："+aa[0].ZLATITUDE+"\r"+"经度："+aa[0].ZLONGITUDE;
                        }
                        else
                        {
                            if(aa[0].ZMEDIALOCALPATH!=""&&aa[0].ZMEDIALOCALPATH!=null){
                                obj.Body = "媒体文件本地路径：net.whatsapp.WhatsApp\\Library\\"+aa[0].ZMEDIALOCALPATH+"\r"+"媒体文件下载链接："+aa[0].ZMEDIAURL;
                            }
                        }
                    }
                }
                arr.push(obj);
            }
        }
        return arr;
    }
}