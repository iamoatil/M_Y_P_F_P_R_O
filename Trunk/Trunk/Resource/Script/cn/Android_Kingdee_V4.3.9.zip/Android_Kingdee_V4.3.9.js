﻿//本程序是针对三星的特别版
/*[config]
<plugin name="快递100" group="Web痕迹,16" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/kuaidi100.png" app="com.Kingdee.Express" version="4.3.9" description="快递100" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.Kingdee.Express/databases/kuaidi100.db</value>
    <value>/data/data/com.Kingdee.Express/shared_prefs/auto_update_tag.xml</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="用户ID" code="UserId" type="string" width="200" format = ""></item>
    <item name="账号" code="UserCode" type="string" width="200" format = ""></item>
    <item name="密码" code="UserPwd" type="string" width="200" format = ""></item>
    <item name="昵称" code="UserName" type="string" width="200" format=""></item>
    <item name="头像" code="UserHead" type="string" width="200" format = ""></item>
    <item name="手机" code="Phone" type="string" width="200" format = ""></item>
    <item name="生日" code="Birth" type="string" width="200" format = ""></item>
</data>
<data type="UsualAddress" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="地址ID" code="AddressId" type="string" format = "200"></item>
    <item name="详细地址" code="DetailAddress" type="string" width="200" format = ""></item>
    <item name="区域编号" code="ZoneNumber" type="string" format = "200"></item>
    <item name="区域名称" code="ZoneName" type="string" format = "200"></item>
    <item name="联系人姓名" code="ContactName" type="string" width="200" format=""></item>
    <item name="联系人电话" code="ContactNumber" type="string" width="200" format=""></item>
    <item name="经度" code="Long" type="string" width="200" format = ""></item>
    <item name="纬度" code="Lati" type="string" width="200" format=""></item>
</data>
<data type="SearchExpress" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="快递公司" code="Company" type="string" width="200" format = ""></item>
    <item name="订单号" code="ExNumber" type="string" width="200" format = ""></item>
    <item name="订单详情" code="OrderDetail" type="string" width="200" format = ""></item>
    <item name="备注" code="Remark" type="string" width="200" format = ""></item>
    <item name="订单状态" code="OrderSta" type="string" width="200" format = ""></item>
    <item name="搜索者Id" code="SearchId" type="string" width="200" format = ""></item>
    <item name="搜索者名字" code="SearchName" type="string" width="200" format = ""></item>
    <item name="搜索时间" code="SearchTime" type="datetime" width="" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="更新时间" code="UpTime" type="datetime" width="" format = "yyyy-MM-dd HH:mm:ss"></item>   
</data>
</plugin>
[config]*/
function News() {
    this.DataState = "Normal";  //数据状态
    this.List = ""; //列表

}
function UserInfo() {
    this.DataState = "Normal";  //数据状态
    this.UserId = "";   //用户ID
    this.UserCode = ""; //账号
    this.UserPwd = "";  //密码
    this.UserName = ""; //昵称
    this.UserHead = ""; //头像
    this.Phone = "";    //手机
    this.Birth = "";    //生日

}
function UsualAddress() {
    this.DataState = "Normal";  //数据状态
    this.AddressId = "";    //地址ID
    this.DetailAddress = "";    //详细地址
    this.ZoneNumber = "";   //区域编号
    this.ZoneName = ""; //区域名称
    this.ContactName = "";  //联系人姓名
    this.ContactNumber = "";    //联系人电话
    this.Long = ""; //经度
    this.Lati = ""; //纬度

}
function SearchExpress() {
    this.DataState = "Normal";  //数据状态
    this.Company = "";  //快递公司
    this.ExNumber = ""; //订单号
    this.OrderDetail = "";  //订单详情
    this.Remark = "";   //备注
    this.OrderSta = ""; //订单状态
    this.SearchId = ""; //搜索者Id
    this.SearchName = "";   //搜索者名字
    this.SearchTime = null; //搜索时间
    this.UpTime = null; //更新时间

}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
var result = new Array();
//配置文件路径全局共用

//*************************************程序入口****************************************
//源数据
var source = $source;
var Path1 = source[0];
var charactor = "\\chalib\\Android_Kingdee_V4.3.9\\kuaidi100.db.charactor";
var Path = XLY.Sqlite.DataRecovery(Path1,charactor,"addressbook,my_express");
var Path2 = source[1];
//测试数据
//var Path1 = "D:\\temp\\data\\data\\com.Kingdee.Express\\databases\\kuaidi100.db";
//var charactor = "F:\手机软件分析和工具\脚本\快递100\\kuaidi100.db.charactor";
//var Path = XLY.Sqlite.DataRecovery(Path1,charactor,"addressbook,my_express");
//var Path2 = "D:\\temp\\data\\data\\com.Kingdee.Express\\shared_prefs\\auto_update_tag.xml";
BuildNode();
var res = JSON.stringify(result);
res;
//*************************************程序结束****************************************




//++++++++++++++++++++++++++++++++++自定义函数部分++++++++++++++++++++++++++++++++++++++
//自定义数据库读取函数  
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}
//主函数
function BuildNode(){
 //**********************************根节点建立**************************************  
    var RootNode = new TreeNode();
    RootNode.Text = "快递100";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(RootNode);
    result.push(RootNode);
}
function GetRootInfo(Node){
    var My_String = ["用户信息","常用地址","搜索订单详情"];
    var temp1 = new Array();
    for(var i in My_String){
        var temp2 = new News();
        temp2.List = My_String[i];
        temp1.push(temp2);
    }
    //获得用户信息
    var UserInfoNode = new TreeNode();
    UserInfoNode.Text = My_String[0];
    UserInfoNode.Type = "UserInfo";
    UserInfoNode.Items = GetUserInfo();
    Node.TreeNodes.push(UserInfoNode);

    //常用地址信息
    var UsualAddressNode = new TreeNode();
    UsualAddressNode.Text = My_String[1];
    UsualAddressNode.Type = "UsualAddress";
    UsualAddressNode.Items = GetUsualAddress();
    Node.TreeNodes.push(UsualAddressNode);

    //搜索订单详情
    var SearchExpressNode = new TreeNode();
    SearchExpressNode.Text = My_String[2];
    SearchExpressNode.Type = "SearchExpress";
    SearchExpressNode.Items = GetSearchExpress();
    Node.TreeNodes.push(SearchExpressNode);

    return temp1;
}
//用户信息获取函数
function GetUserInfo(){
    var temp1 = new Array();
    var temp2 = new UserInfo();
    var temp3 = eval('('+ XLY.File.ReadXML(Path2) +')');
    if(temp3 != null && temp3.length != 0){
        for(var i in temp3.map.string){
            //log(temp3.map.string);
            switch(temp3.map.string[i]["@name"]){
                case "user_id": temp2.UserId = temp3.map.string[i]["#text"];
                break;
                case "user_name": temp2.UserCode = temp3.map.string[i]["#text"]; 
                break;
                case "user_pwd": temp2.UserPwd = temp3.map.string[i]["#text"];
                break;
                case "user_nick_name": temp2.UserName = temp3.map.string[i]["#text"];
                break;
                case "user_avatar_url": temp2.UserHead = temp3.map.string[i]["#text"];
                break;
                case "user_phone": temp2.Phone = temp3.map.string[i]["#text"];
                break;
                case "user_birth": temp2.Birth = temp3.map.string[i]["#text"];
                break;
            }
        }
    }

    temp1.push(temp2)
    return temp1;
}

function GetUsualAddress(){
    var temp1 = new Array();
    var temp3 = ExecSql(Path,"select guid,address,xzqNumber,xzqName,name,phone,longitude,latitude from addressbook");
    if(temp3 != null && temp3.length != 0){
        for(var i in temp3){
            var temp2 = new UsualAddress();
            temp2.DataState = XLY.Convert.ToDataState( temp3[i].XLY_DataType);
            temp2.AddressId = temp3[i].guid;    //地址ID
            temp2.DetailAddress = temp3[i].address;    //详细地址
            temp2.ZoneNumber = temp3[i].xzqNumber;   //区域编号
            temp2.ZoneName = temp3[i].xzqName; //区域名称
            temp2.ContactName = temp3[i].name;  //联系人姓名
            temp2.ContactNumber = temp3[i].phone;    //联系人电话
            temp2.Long = temp3[i].longitude; //经度
            temp2.Lati = temp3[i].latitude; //纬度
            temp1.push(temp2);
        }
        
    }
    return temp1;    
}

function GetSearchExpress(){
    var temp1 = new Array();
    var temp3 = ExecSql(Path,"select companyNumber,number,lastestJson,remark,signed,isDel,userId,userName,addTime,updateTime from my_express");
    //log(temp3[0]);
    if(temp3 != null && temp3.length != 0){   
        for(var i in temp3){
            
            var temp2 = new SearchExpress();
            temp2.DataState = XLY.Convert.ToDataState( temp3[i].XLY_DataType);        
            temp2.Company = temp3[i].companyNumber;  //快递公司
            temp2.ExNumber = temp3[i].number;   //订单号
            if(temp3[i].lastestJson != null && temp3[i].lastestJson.length != 0 && temp3[i].lastestJson)
            {
                try{
                    var temp4 = eval('('+ temp3[i].lastestJson +')');;
                    temp2.OrderDetail = "当前城市:"+temp4.routeInfo.cur.name + "___" + "出发城市:" + temp4.routeInfo.from.name;
                    for(var j in temp4.data)
                    {
                        temp2.OrderDetail = temp2.OrderDetail + "              " + temp4.data[j].context + "(" + temp4.data[j].time + ";" + "快递状态:" + temp4.data[j].status + ")";
                    } 
                }
                catch(e)
                {
                    temp2.OrderDetail = temp3[i].lastestJson;
                }
                
            }
            //log("+++++++++++++++++++++++++++++++++++");
            temp2.Remark = temp3[i].remark; //备注
            if(temp3[i].isDel == 1){
                temp2.OrderSta = "回收站";
            }
            if(temp3[i].isDel == 0)
            {
                if(temp3[i].signed != 0){
                    temp2.OrderSta = "已签收";
                }
                else
                {
                    temp2.OrderSta = "未签收";
                }
            }
            temp2.SearchId = temp3[i].userId; //搜索者Id
            temp2.SearchName = temp3[i].userName;   //搜索者名字
            temp2.SearchTime = XLY.Convert.LinuxToDateTime(temp3[i].addTime); //搜索时间
            temp2.UpTime = XLY.Convert.LinuxToDateTime(temp3[i].updateTime); //更新时间
            temp1.push(temp2)
        }
    }
    return temp1;    
}

