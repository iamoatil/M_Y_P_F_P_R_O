﻿/*[config]
<plugin name="腾讯地图,3" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\TencentMap.png" app="com.tencent.map" version="4.1.1" description="腾讯地图" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.tencent.map/databases/#F</value>
</source>

<data  type="Search">
<item name="搜索关键字" code="Name" type="string" width="200" format=""></item>
<item name="搜索地址" code="Addr" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="string" width="200" format=""></item>
<item name="纬度" code="Latitude" type="string" width="200" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>

<data  type="Favorite">
<item name="收藏地点" code="Addr" type="string" width="200" format=""></item>
<item name="类型" code="Type" type="string" width="140" format="" ></item>    
</data>

<data  type="Favpoi">
<item name="类别" code="Type" type="string" width="100" format=""></item>
<item name="搜索地点" code="Name" type="string" width="150" format=""></item>
<item name="搜索地点详细地址" code="Addr" type="string" width="300" format=""></item>
<item name="经度" code="Longitude" type="string" width="100" format=""></item>
<item name="纬度" code="Latitude" type="string" width="100" format=""></item>
</data>

<data  type="Favroute">
<item name="收藏路线" code="Line" type="string" width="120" format=""></item>
<item name="收藏起点" code="Start" type="string" width="300" format=""></item>
<item name="收藏终点" code="Dest" type="string" width="300" format=""></item>
</data>

<data  type="Favstreet">
<item name="收藏街景街名" code="Addr" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>

</plugin>
[config]*/

//定义数据结构
function Search() {
    this.Addr = "";
    this.Name = ""
    this.Time = null;
    this.Longitude = "";
    this.Latitude = "";
}

function Favorite() {
    this.Addr = "";
    this.Type = "";
}

function Favpoi() {
    this.Name = "";
    this.Addr = ""
    this.Longitude = "";
    this.Latitude = "";
    this.Type = "";
}

function Favroute() {
    this.Line = "";
    this.Start = "";
    this.Dest = "";
}

function Favstreet() {
    this.Addr = "";
    this.Time = null;
}
//获取搜索点的信息
function getSearch(path, sql) {
    var hisdata = execSql(path, sql);
    var arr = new Array();
    for (var index in hisdata) {
        var data = execEval(hisdata[index].xly_data);
        var list = new Search();
        list.Name = data.name;
        if (data.address != "") {
            list.Addr = data.address;
        }
        list.Time = XLY.Convert.LinuxToDateTime(data.lastedUse);
        if (data.geopoint != "") {
            var poi = data.geopoint.split(",")
            list.Latitude = poi[0] / 1000000;
            list.Longitude = poi[1] / 1000000;
        }
        arr[index] = list;
    }
    return arr;
}

//获取收藏地点信息
function getFavpoi(path, sql) {
    var poidata = execSql(path, sql);
    var arr = new Array();
    for (var index in poidata) {
        var data = execEval(poidata[index].obj);
        var list = new Favpoi();
        if (data.classes != null) {
            list.Type = data.classes;
        }
        list.Name = poidata[index].name;
        if (data.addr != "") {
            list.Addr = data.addr;
        }
        list.Longitude = data.lon / 1000000;
        list.Latitude = data.lat / 1000000;
        arr.push(list);
    }
    return arr;
}

//获取收藏路线信息
function getFavroute(path, sql) {
    var routedata = execSql(path, sql);
    var arr = new Array();
    for (var index in routedata) {
        var startdata = execEval(routedata[index].fromPoi);
        var destdata = execEval(routedata[index].toPoi);
        var list = new Favroute();
        list.Line = routedata[index].name;
        list.Start = startdata.addr + startdata.name + "(" + "经度" + startdata.lon / 1000000 + ";" + "纬度" + startdata.lat / 1000000 + ")";
        if (destdata.addr != "") {
            list.Dest = destdata.addr + destdata.name + "(" + "经度" + destdata.lon / 1000000 + ";" + "纬度" + destdata.lat / 1000000 + ")";
        } else {
            list.Dest = destdata.name + "(" + "经度" + destdata.lon / 1000000 + ";" + "纬度" + destdata.lat / 1000000 + ")";
        }
        arr.push(list)
    }
    return arr;
}

//获取收藏街景信息
function getFavstreet(path, sql) {
    var streetdata = execSql(path, sql);
    var arr = new Array();
    for (var index in streetdata) {
        var data = streetdata[index];
        var list = new Favstreet();
        list.Addr = data.name;
        list.Time = XLY.Convert.LinuxToDateTime(data.time);
        arr.push(list);
    }
    return arr;
}

//获取收藏夹信息
function getFavorite(path, psql, rsql, ssql) {
    var arr = new Array();
    var pname = execSql(path, psql);
    var parr = new Array();
    for (var p in pname) {
        var listp = new Favorite();
        listp.Addr = pname[p].name;
        listp.Type = "收藏地点";
        parr.push(listp);
    }
    var rname = execSql(path, rsql);
    var rarr = new Array();
    for (var r in rname) {
        var destdata = execEval(rname[r].toPoi);
        var listr = new Favorite();
        listr.Addr = destdata.name + "(" + "经度" + destdata.lon / 1000000 + ";" + "纬度" + destdata.lat / 1000000 + ")";
        listr.Type = "收藏路线";
        rarr.push(listr);
    }
    var sname = execSql(path, ssql);
    var sarr = new Array();
    for (var s in sname) {
        var lists = new Favorite();
        lists.Addr = sname[s].name;
        lists.Type = "收藏街景";
        sarr.push(lists);
    }
    var obj = new Array();
    obj = objConcat(rarr, parr);
    arr = objConcat(obj, sarr);
    return arr;
}

//json化字符串
function execEval(object) {
    var infos = eval('(' + object + ')');
    return infos;
}
//处理通过SQL语句查询
function execSql(path, sql) {
    var infos = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    return infos;
}

//合并两条json数组
function objConcat(a1, a2) {
    var newarr = new Array();
    var p = 0;
    for (var k1 in a1) {
        newarr[k1] = a1[k1];
        p = k1;
    }
    p = parseInt(p) + 1;
    for (var k2 in a2) {
        newarr[p + parseInt(k2)] = a2[k2];
    }
    return newarr;
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

var result = new Array();
var source = $source;
var dataRoot = source[0];
//定义信息路径
//var dataRoot = "D:\\temp\\data\\data\\com.tencent.map\\databases";
//创建历史搜索树
var hispath = dataRoot + "/search_history.db";
var hissql = "select _data from search_history_tab";
var hisTree = new TreeNode();
hisTree.Text = "历史搜索";
hisTree.Type = "Search";
var hisinfo = getSearch(hispath, hissql);
hisTree.Items = hisinfo;

//创建收藏树
var favpath = dataRoot + "/favorite.db";
var favoriteTree = new TreeNode();
favoriteTree.Text = "收藏地点";
favoriteTree.Type = "Favorite";

//创建收藏树子树收藏地点树
var favpoisql = "select name,obj from FavoritePOIEntity";
var favpoiTree = new TreeNode();
favpoiTree.Text = "收藏地点";
favpoiTree.Type = "Favpoi";
var favpoiinfo = getFavpoi(favpath, favpoisql);
favpoiTree.Items = favpoiinfo;

//创建收藏树子树收藏路线树
var favroutesql = "select name,fromPoi,toPoi from FavoriteRouteEntity";
var favrouteTree = new TreeNode();
favrouteTree.Text = "收藏路线";
favrouteTree.Type = "Favroute";
var favrouteinfo = getFavroute(favpath, favroutesql);
favrouteTree.Items = favrouteinfo;

//创建收藏树子树收藏街景树
var favstreetsql = "select lastEditTime as time,name from FavoriteStreetEntity";
var favstreetTree = new TreeNode();
favstreetTree.Text = "收藏街景";
favstreetTree.Type = "Favstreet";
var favstreetinfo = getFavstreet(favpath, favstreetsql);
favstreetTree.Items = favstreetinfo;

//返回收藏夹信息
var favoriteinfo = getFavorite(favpath, favpoisql, favroutesql, favstreetsql);
favoriteTree.Items = favoriteinfo;
favoriteTree.TreeNodes.push(favpoiTree);
favoriteTree.TreeNodes.push(favrouteTree);
favoriteTree.TreeNodes.push(favstreetTree);

//返回各级树的信息
result.push(hisTree);
result.push(favoriteTree);

//返回该APP的所有信息
var res = JSON.stringify(result);
res;
