﻿/*[config]
<plugin name="携程旅行,3" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/Ctrip.png" app="Ctrip" version="7.1.0" description="携程旅行" data="$data,ComplexTreeDataSource" >
<source>
    <value>ctrip.com</value>
</source>
<data type = "Ctrip" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="app名称" code="AppName" type="string" width = "150"></item>
    <item name="app版本" code="AppVersion" type="string" width = "150"></item>
    <item name="设备信息" code="Device" type="string" width = "150"></item>
    <item name="是否最新版本" code="IsAppNeedUpdate" type="string" width = "150"></item>
</data>
<data type = "List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="列表" code="List1" type="string" width = "150"></item>
</data>
<data type = "History" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="数据ID" code="DataKey" type="string" width = "150"></item>
    <item name="酒店ID" code="HotelID" type="string" width = "150"></item>
    <item name="酒店名称" code="HotelName" type="string" width = "150"></item>
    <item name="城市ID" code="CityID" type="string" width = "150"></item>
    <item name="城市名称" code="CityName" type="string" width = "150"></item>
    <item name="国内与否" code="CountryEnum" type="string" width = "150"></item>
    <item name="记录时间" code="QueryDate" type="string" width = "150"></item>
    <item name="详细时间" code="SortFlag"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type = "SearchWord" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="搜索关键字" code="DataKey" type="string" width = "150"></item>
    <item name="搜索时间" code="DataDate"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type = "ChatConfig" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="组名" code="MsgServiceTitle" type="string" width = "120"></item>
    <item name="组ID" code="MsgServiceID"  type="string" width="120" format = ""></item>
    <item name="消息ID" code="MsgID"  type="string" width="120" format = ""></item>
    <item name="批号" code="BatchCode"  type="string" width="120" format = ""></item>
    <item name="标题" code="Title"  type="string" width="120" format = ""></item>
    <item name="消息类型" code="MsgType"  type="string" width="120" format = ""></item>
    <item name="状态" code="Status"  type="string" width="120" format = ""></item>
    <item name="发布时间" code="PostTime"  type="string" width="120" format = ""></item>
    <item name="过期时间" code="ExpiredTime"  type="string" width="120" format = ""></item>
    <item name="内容" code="Content"  type="string" width="120" format = ""></item>
    <item name="渠道" code="ChannelType"  type="string" width="120" format = ""></item>
</data>
<data type = "OfflineOrder" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="订单状态" code="OrderStatus" type="string" width = "120"></item>
    <item name="是否需要绑定" code="IsNeedBind"  type="string" width="120" format = ""></item>
    <item name="乘客" code="Passager"  type="string" width="120" format = ""></item>
    <item name="订单ID" code="OrderID"  type="string" width="120" format = ""></item>
    <item name="订单时间" code="BookingDate"  type="string" width="120" format = ""></item>
    <item name="联系人姓名" code="ContactName"  type="string" width="120" format = ""></item>
    <item name="总价" code="OrderTotalPrice"  type="string" width="120" format = ""></item>
    <item name="交通类别" code="BizType"  type="string" width="120" format = ""></item>
    <item name="路线" code="Route"  type="string" width="120" format = ""></item>
    <item name="航班" code="Flight"  type="string" width="120" format = ""></item>
    <item name="出发时间" code="DepartureDateTime"  type="string" width="120" format = ""></item>
    <item name="到达时间" code="ArrivalDateTime"  type="string" width="120" format = ""></item>
    <item name="类型" code="TripType"  type="string" width="120" format = ""></item>
    <item name="联系电话" code="ContactMobile"  type="string" width="120" format = ""></item>
    <item name="联系电话" code="Currency"  type="string" width="120" format = ""></item>
</data>
<data type="UserList" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="用户ID" code="UserID" type="string" width="120" format = ""></item>
    <item name="昵称" code="UserName" type="string" width="150" format = ""></item>
    <item name="性别" code="Gender" type="string" width="100" format=""></item>
    <item name="头像" code="HedIcon" type="URL" width="100" format=""></item>
    <item name="积分" code="Expeience" type="string" width="100" format=""></item>
    <item name="出生年月" code="Birthday" type="string" width="100" format=""></item>
    <item name="邮箱" code="Email" type="string" width="100" format=""></item>
    <item name="邮政编码" code="PostCode" type="string" width="100" format=""></item>
    <item name="地址" code="Address" type="string" width="100" format=""></item>
    <item name="电话" code="Mobile" type="string" width="100" format=""></item>
    <item name="手机绑定" code="BindMobile" type="string" width="100" format=""></item>
    <item name="用户级别" code="VipGradeRemrk" type="string" width="100" format=""></item>
    <item name="会员过期时间" code="ExpiredTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function List(){
    this.DataState = "Normal";
    this.List1 = "";
}
function OfflineOrder(){
    this.DataState = "Normal";
    this.OrderStatus = "";
    this.IsNeedBind = "";
    this.Passager = "";
    this.OrderID = "";
    this.BookingDate = "";
    this.ContactName = "";
    this.OrderTotalPrice = "";
    this.BizType = "";
    this.Route = "";
    this.Flight = "";
    this.DepartureDateTime = "";
    this.ArrivalDateTime = "";
    this.TripType = "";
    this.ContactMobile = "";
    this.Currency = "";
}
function UserList() {
    this.DataState = "Normal";  
    this.UserID = "";    
    this.UserName = ""; 
    this.Gender = "";  
    this.HedIcon = "";   
    this.Expeience = ""; 
    this.Birthday = "";   
    this.Email = "";   
    this.PostCode = "";  
    this.Address = "";  
    this.Mobile = "";   
    this.BindMobile = "";  
    this.VipGradeRemrk = ""; 
    this.ExpiredTime = null;
}
function SearchWord(){
    this.DataState = "Normal";
    this.DataKey = "";
    this.DataDate = null;
}
function ChatConfig(){
    this.DataState = "Normal";
    this.MsgServiceTitle = "";
    this.MsgServiceID = "";
    this.MsgID = "";
    this.BatchCode = "";
    this.Title = "";
    this.MsgType = "";
    this.Status = "";
    this.PostTime = "";
    this.ExpiredTime = "";
    this.Content = "";
    this.ChannelType = "";
}
function History(){
    this.DataState = "Normal";
    this.DataKey = "";
    this.HotelID = "";
    this.HotelName = "";
    this.CityID = "";
    this.CityName = "";
    this.QueryDate = "";
    this.SortFlag = null;
    this.CountryEnum = "";
}
function Ctrip() {
    this.DataState = "Normal";
    this.AppName = "";
    this.AppVersion = "";
    this.Device = "";
    this.IsAppNeedUpdate = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var upath = source[0]+"\\ctrip.com\\Library\\Caches\\file__0.localstorage";
//var hpath1 = source[1]+"\\ctrip_hotel.db";
//var searchpath = source[2]+"\\global_search_history.xml";
var opath = source[0]+"\\ctrip.com\\Documents\\webapp_work_7.1.0\\wb_cache\\myctrip\\myctrip_offlineorder.txt";
//var cpath = source[2]+"\\chat_config.xml";
//测试数据

//var upath = "C:\\Users\\Administrator\\Desktop\\139ios\\0002\\Library\\Caches\\file__0.localstorage";
//var hpath1 = "D:\\temp\\data\\data\\ctrip.android.view\\databases\\ctrip_hotel.db";
//var searchpath = "D:\\temp\\data\\data\\ctrip.android.view\\shared_prefs\\global_search_history.xml";
//var opath = "C:\\Users\\Administrator\\Desktop\\139ios\\0002\\Documents\\webapp_work_7.1.0\\wb_cache\\myctrip\\myctrip_offlineorder.txt"
//var cpath = "D:\\temp\\data\\data\\ctrip.android.view\\shared_prefs\\chat_config.xml"

//定义特征库文件
//var charactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Ctrip_V7.1.0\\ctrip_hotel.db.charactor";
//var charactor = "\\chalib\\Android_Ctrip_V7.1.0\\ctrip_hotel.db.charactor";
//恢复数据库中删除的数据
//var hpath = XLY.Sqlite.DataRecovery(hpath1,charactor,"hotel_browse_query_history");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var ctrip = new TreeNode();
    ctrip.Text = "携程旅行";
    ctrip.Type = "Ctrip";
    ctrip.Items.push(getCtripInformation(ctrip));
    
    result.push(ctrip);
}
//获取app信息
function getCtripInformation(root){
    if(XLY.File.IsValid(upath)){
        var data = eval('('+ XLY.Sqlite.Find(upath,"select value from ItemTable where key = 'CINFO'") +')');
        var syncinfo = "";
        syncinfo = eval('('+ XLY.Convert.Encode(data[0].value,"base64","Unicode") +')');
        if(syncinfo!=""&&syncinfo!=null){
            var ctrip = new Ctrip();
            ctrip.AppName = "携程旅行";
            ctrip.AppVersion = syncinfo.version;
            ctrip.Device = syncinfo.device;
            if(!syncinfo.isAppNeedUpdate){
                ctrip.IsAppNeedUpdate = "是";
            }
            else
            {
                ctrip.IsAppNeedUpdate = "否";
            }
            if(syncinfo.userInfo!=""&&syncinfo.userInfo!=null){
                var node = new TreeNode();
                node.Text = syncinfo.userInfo.data.UserName;
                node.Type = "UserList";
                node.Items.push(getUserInfo(node,syncinfo.userInfo.data));
                root.TreeNodes.push(node);
            }
        }
        //if(XLY.File.IsValid(searchpath)){
        //    if(XLY.File.IsValid(searchpath)){
        //        var cc = eval('('+ XLY.Sqlite.Find(hpath,"select * from hotel_keyword_query_history") +')');
        //    }
        //    var bb = eval('('+ XLY.File.ReadXML(searchpath) +')').map.string["#text"];
        //    if((bb!=""&&bb!=null)||(cc!=""&&cc!=null)){
        //        var snode = new TreeNode();
        //        snode.Text = "搜索";
        //        snode.Type = "SearchWord";
        //        getSearch(snode,eval('('+ bb +')'),cc);
        //        root.TreeNodes.push(snode);
        //    }
        //}
        //if(XLY.File.IsValid(hpath)){
        //    var data = eval('('+ XLY.Sqlite.Find(hpath,"select * from hotel_browse_query_history") +')');
        //    if(data!=""&&data!= null){
        //        var hnode = new TreeNode();
        //        hnode.Text = "浏览历史";
        //        hnode.Type = "History";
        //        hnode.Items = getHistory(data);
        //        root.TreeNodes.push(hnode);
        //    }
        //}
        return ctrip;
    }
}
//获取用户信息
function getUserInfo(root,info){
    if(info!=""&&info!=null){
        var userinfo = new UserList();
        userinfo.UserID = info.UserID;    
        userinfo.UserName = info.UserName; 
        if(info.Gender=='1'){
            userinfo.Gender = "男";
        }
        else if(info.Gender=='0')
        {
            userinfo.Gender = "女";
        }
        else
        {
            userinfo.Gender = "未指定";
        }
        userinfo.HedIcon = info.headIcon;   
        userinfo.Expeience = info.Experience; 
        userinfo.Birthday = info.Birthday;   
        userinfo.Email = info.Email;   
        userinfo.PostCode = info.PostCode;  
        userinfo.Address = info.Address; 
        if((info.Mobile==""||info.Mobile==null)&&(info.BindMobile!=""&&info.BindMobile!=null)){
            userinfo.Mobile = info.BindMobile;
        }
        else
        {
            userinfo.Mobile = info.Mobile;
        }
        userinfo.BindMobile = info.BindMobile;  
        userinfo.VipGradeRemrk = info.VipGradeRemark; 
        userinfo.ExpiredTime = XLY.Convert.LinuxToDateTime(info.ExpiredTime);
        
        
        if(XLY.File.IsValid(opath)){
            var odata = eval('('+ XLY.File.ReadFile(opath) +')').OrderEnities;
            if(odata!=""&&odata!=null){
                var onode = new TreeNode();
                onode.Text = "订单信息";
                onode.Type = "OfflineOrder";
                onode.Items = getOfflineOrder(odata);
                root.TreeNodes.push(onode);
            }
        }
        //if(XLY.File.IsValid(cpath)){
        //    var cdata = eval('('+ XLY.File.ReadXML(cpath) +')').map.string;
        //    if(cdata!=""&&cdata!=null){
        //        for(var c in cdata){
        //            if(cdata[c]["@name"]=="message_center_info"){
        //                if(cdata[c]["#text"]!=""&&cdata[c]["#text"]!=null){
        //                    var cnode = new TreeNode();
        //                    cnode.Text = "消息";
        //                    cnode.Type = "List";
        //                    cnode.Items = getChatConfig(cnode,eval('('+ cdata[c]["#text"] +')'));
        //                    root.TreeNodes.push(cnode);
        //                }
        //            }
        //        }
        //    }
        //}
        return userinfo;
    }
}
//获取历史记录信息
function getHistory(info){
    var arr = new Array();
    for(var i in info){
        var hobj = new History();
        //hobj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
        hobj.DataKey = info[i].dataKey;
        hobj.HotelID = eval('('+ info[i].dataValue +')').hotelID;
        hobj.HotelName = eval('('+ info[i].dataValue +')').hotelName;
        hobj.CityID = eval('('+ info[i].dataValue +')').cityID;
        hobj.CityName = eval('('+ info[i].dataValue +')').cityName;
        hobj.QueryDate = info[i].queryDate;
        hobj.SortFlag = XLY.Convert.LinuxToDateTime(info[i].sortFlag);
        if(eval('('+ info[i].dataValue +')').countryEnum=='Domestic'){
            hobj.CountryEnum = "是";
        }
        else
        {
            hobj.CountryEnum = "否";
        }
        arr.push(hobj);
    }
    return arr;
}
//获取搜索信息
function getSearch(root,info,temp){
    if(info!=""&&info!=null){
        for(var i in info){
            var obj = new SearchWord();
            //obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
            obj.DataKey = info[i].keyword;
            obj.DataDate = null;
            root.Items.push(obj);
        }
    }
    if(temp!=""&&temp!=null){
        for(var j in temp){
            var obj = new SearchWord();
            //obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
            obj.DataKey = temp[j].dataKey;
            obj.DataDate = XLY.Convert.LinuxToDateTime(temp[j].date);
            root.Items.push(obj);
        }
    }
    return;
}
//获取收藏信息
function getOfflineOrder(info){
    var arr = new Array();
    for(var i in info){
        var obj = new OfflineOrder();
        obj.OrderStatus = info[i].OrderStatusName;
        obj.IsNeedBind = info[i].IsNeedBind;
        if(info[i].Passagers!=""&&info[i].Passagers!=null){
            for(var j in info[i].Passagers){
                obj.Passager+= info[i].Passagers[j]+" ";
            }
        }
        obj.OrderID = info[i].OrderID;
        obj.BookingDate = XLY.Convert.LinuxToDateTime(info[i].BookingDate.substr(6,13))+"+08:00";
        
        obj.ContactName = info[i].ContactName;
        obj.OrderTotalPrice = info[i].OrderTotalPrice;
        obj.BizType = info[i].BizType;
        obj.Route = info[i].OrderName;
        if(info[i].FlightInfo!=""&&info[i].FlightInfo!=null){
            obj.Flight = info[i].FlightInfo.Items[0].FlightNo;
            obj.DepartureDateTime = info[i].FlightInfo.Items[0].DepartureDateTime;
            obj.ArrivalDateTime = info[i].FlightInfo.Items[0].ArrivalDateTime;
            obj.TripType = info[i].FlightInfo.TripType;
        }
        obj.ContactMobile = info[i].ContactMobile;
        obj.Currency = info[i].Currency;
        arr.push(obj);
    }
    return arr;
}
//
function getChatConfig(root,info){
    if(info!=""&&info!=null){
        var arr = new Array();
        for(var i in info){
            if(info[i].Items!=""&&info[i].Items!= null){
                var node = new TreeNode();
                node.Text = info[i].MsgServiceTitle;
                node.Type = "ChatConfig";
                node.Items = getChatLog(info[i].Items,info[i]);
                root.TreeNodes.push(node);
                
                var obj = new List();
                obj.List1 = node.Text;
                arr.push(obj);
            }
        }
        return arr;
    }
}
//
function getChatLog(info,temp){
    var arr = new Array();
    for(var i in info){
        var obj = new  ChatConfig();
        obj.MsgServiceTitle = temp.MsgServiceTitle;
        obj.MsgServiceID = temp.MsgServiceID;
        obj.MsgID = info[i].MsgID;
        obj.BatchCode = info[i].BatchCode;
        obj.Title = info[i].Title;
        obj.MsgType = info[i].MsgType;
        obj.Status = info[i].Status;
        obj.PostTime = XLY.Convert.LinuxToDateTime(info[i].PostTime.substr(6,13))+"+08:00";
        obj.ExpiredTime = XLY.Convert.LinuxToDateTime(info[i].ExpiredTime.substr(6,13))+"+08:00";
        obj.Content = info[i].Content;
        obj.ChannelType = info[i].ChannelType;
        arr.push(obj);
    }
    return arr;
}