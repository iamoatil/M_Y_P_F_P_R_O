﻿/*[config]
<plugin name="易信,15" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="icons/yixin.png" app="im.yixin" version="3.8.0.216" description="易信聊天" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/im.yixin/#F</value>
</source>

<data type = "UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="nickname" type="string" width="100" format = ""></item>
    <item name="帐号" code="userid" type="string" width="100" format = ""></item>
    <item name="手机号" code="phone" type="string" width="80" format = ""></item>
    <item name="头像" code="photourl" type="string" width="200" format = ""></item>
    <item name="联系方式" code="contacts" type="string" width="150" format = ""></item>
    <item name="性别" code="gender" type="string" width="150" format = ""></item>
    <item name="生日" code="birthday" type="datetime" width="150" format = "yyyy-MM-dd"></item>
    <item name="地址" code="address" type="string" width="120" format = ""></item>
    <item name="签名" code="signature" type="string" width="200" format = ""></item>
    <item name="新浪微博" code="sinaweibo" type="datetime" width="150" format = "yyyy-MM-dd"></item>
    <item name="腾讯微博" code="tencentweibo" type="string" width="" format = "200"></item>
    <item name="人人网" code="renren" type="string" width="" format = "200"></item>
</data>

<data type = "GroupInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群名" code="tname" type="string" width="100" format = ""></item>
    <item name="创建者" code="creator" type="string" width="100" format = ""></item>
    <item name="时间" code="createtime" type="datetime" width="150" format = "yyyy-MM-dd"></item>
    <item name="成员数" code="membercount" type="string" width="200" format = ""></item>
    <item name="成员列表" code="member" type="string" width="150" format = ""></item>
</data>

<data type = "Message" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者" code="sender" type="string" width="100" format = ""></item>
    <item name="接受者" code="receiver" type="string" width="100" format = ""></item>
    <item name="时间" code="time" type="datetime" width="150" format = "yyyy-MM-dd"></item>
    <item name="消息类型" code="msgtype" type="string" width="200" format = ""></item>
    <item name="内容" code="content" type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

function UserInfo(){
    this.DataState = "Normal";
    this.nickname = "";
    this.userid = "";
    this.phone = "";
    this.photourl = "";
    this.contacts = "";
    this.gender = "";
    this.birthday = null;
    this.address = "";
    this.signature = "";
    this.sinaweibo = "";
    this.tencentweibo = "";
    this.renren = "";
}

function GroupInfo() {
    this.DataState = "Normal";  //数据状态
    this.id = "";
    this.tname = "";    //群名
    this.creator = "";  //创建者
    this.createtime = null; //时间
    this.membercount = "";  //成员数
    this.member = "";   //成员列表
}

function Message(){
    this.DataState = "Normal";
    this.sender = "";
    this.receiver = "";
    this.time = null;
    this.msgtype = "";
    this.content = "";
}

function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

function creatTreeNode(text,type,id){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Id = id;
    tree.Type = type;
    return tree;
}

String.prototype.format = function (args) {
    var result = this;
    if (arguments.length > 0) {
        var reg;
        if (arguments.length == 1 && typeof (args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    reg = new RegExp("({" + key + "})", "g");
                    result = result.replace(reg, args[key]);
                }
            }
        }
        else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    reg = new RegExp("({)" + i + "(})", "g");
                    result = result.replace(reg, arguments[i]);
                }
            }
        }
    }
    return result;
};

function bindTree(){
    var root = creatTreeNode("本地账户信息","");
    // 获取用户数据文件夹
    var files = eval('('+ XLY.File.FindDirectories(source) +')');
    
    for(var i in files){
        var file = files[i];
        var fileName = XLY.File.GetFileName(file);
        var re = new RegExp("^[0-9]*$");
        var rs = re.exec(fileName);
        if(rs == null){
            continue;
        }
        
        dbPath = file;
        var accountDb = dbPath+"\\main.db";
        
        var sql =  "select * from yixin_contact where uid = {0}".format(fileName);
        var user = eval('('+ XLY.Sqlite.Find(accountDb,sql) +')');
        if(user.length > 1){
            continue;
        }
       var account = creatTreeNode(user[0].nickname,"UserInfo",user[0].uid);
       nAccount = CreateUserInfo(user[0]);
       account.Items.push(nAccount);
       
       // 构建当前帐号下的树结构
       buildAccountTree(account);
       root.TreeNodes.push(account);
    }
    return root;
}

function CreateUserInfo(user){
    var _user = new UserInfo();
    _user.DataState = "Normal";
    _user.nickname = user.nickname;
    _user.userid = user.uid;
    _user.phone = user.mobile;
    _user.photourl = user.photourl;
    _user.contacts = user.phone;
    _user.gender = (user.gender = 1)?"男":"女";
    _user.birthday = user.birthday;
    _user.address = user.address;
    _user.signature = user.signature;
    _user.sinaweibo = user.sinaweibo;
    _user.tencentweibo = user.qqweibo;
    _user.renren = user.renren;
    return _user;
}

function buildAccountTree(accountTree){
    var friendTree = buildFriendTree(accountTree.Id);
    accountTree.TreeNodes.push(friendTree);
    
    var groupTree = buildGroupTree();
    accountTree.TreeNodes.push(groupTree);
}

function buildFriendTree(id){
    var tree = creatTreeNode("好友","UserInfo","");
    var sql = "select * from yixin_contact where uid != {0}";
    var friendDb = dbPath+"\\main.db";
    var allFriends = eval('('+ XLY.Sqlite.Find(friendDb,sql.format(id)) +')');;
    for(var i in allFriends){
        var friend = allFriends[i];
        var user = CreateUserInfo(friend);
        tree.Items.push(user);
        var fTree = creatTreeNode(user.nickname,"Message",user.userid);
        // 加载聊天信息;
        buildFriendMessage(fTree,user);
        tree.TreeNodes.push(fTree);
    }
    return tree;
}

function buildFriendMessage(tree,user){
    var sql = "select * from msghistory where id = {0}";
    var msgDb = dbPath+"\\msg.db";
    if(!XLY.File.IsValid(msgDb)){
        return;
    }
    var allMsg = eval('('+ XLY.Sqlite.Find(msgDb,sql.format(user.userid)) +')');
    for(var i in allMsg){
       var msg = createFriendMessage(allMsg[i],user);
       tree.Items.push(msg);
    }
}

function createFriendMessage(msg,user){
    var _msg = new Message();
    if(msg==null){
        return _msg;
    }
    _msg.DataState = "Normal";
    if(msg.fromid == msg.id)
    {
        _msg.sender = user.nickname;   
        _msg.receiver = nAccount.nickname;
    }
    else
    {
        _msg.sender = nAccount.nickname;
        _msg.receiver = user.nickname;
    }
    _msg.time = XLY.Convert.LinuxToDateTime(msg.time);
    _msg.msgtype = getMessageType(msg.msgtype);
    _msg.content = analysisMessageContent(msg);
    return _msg
}

function getMessageType(type){
    switch(type){
      case 0:
       return "文本"; 
      case 1:
       return "图片";
     case 3:
       return "视频";
     case 2:
       return "语音";
     case 4:
       return "地理位置";
     case 7:
       return "表情";
     default:
       return "系统消息";
    }
   return "";
}

function analysisMessageContent(msg){
    var msgContent = msg.content;
    if(msg.msgtype==0 || msg.attachstr=="")
    {
        return msgContent;
    }
    var atta = eval('('+ msg.attachstr +')');
    if(msg.msgtype == 4){
        msgContent = "地理位置:"+atta.desc+"\n位置截图:"+atta.url;
    }else{
        msgContent = "链接地址:"+atta.url;
    }
    return msgContent;
}

function buildGroupTree(){
    var tree = creatTreeNode("群组","GroupInfo","");
    var db = dbPath+"\\main.db";
    if(!XLY.File.IsValid(db))
    {
        return tree;
    }
    
    // 获取所有群组
    var allGroup = eval('('+ XLY.Sqlite.FindByName(db, "tinfo") +')');
    for(var i in allGroup){
        var _group = allGroup[i];
        var group = createGroupInfo(_group);
        var gTree = creatTreeNode(group.tname,"Message",group.id);
        creatGroupMessage(gTree,group);
        tree.Items.push(group);
        tree.TreeNodes.push(gTree);
    }
    return tree;
}

function createGroupInfo(group){
    var _group = new GroupInfo();
    _group.DataState = "Normal";  //数据状态
    _group.id = group.tid;
    _group.tname = (group.tname=="")?group.defaultname:group.tname;
    var sql = "select y.nickname from yixin_contact y where y.uid = {0}";
    var un = eval('('+ XLY.Sqlite.Find(dbPath+"\\main.db",sql.format(group.creator)) +')');
    XLY.Debug.WriteLine(un.length);
    if(un.length > 0){
        _group.creator = un[0].nickname+"("+group.creator+")";
    }else{
        _group.creator = group.creator;
    }
    _group.createtime = XLY.Convert.LinuxToDateTime(group.createtime); //时间
    _group.membercount = group.membercount;  //成员数
    _group.member = getGroupMenmbers(group.tid);   //成员列表
    return _group;
}

function getGroupMenmbers(tid){
    var members = "";
    var sql = "select * from tuser where tid = {0}";
    var aUser = eval('('+ XLY.Sqlite.Find(dbPath+"\\main.db",sql.format(tid)) +')');
    for(var i in aUser){
        var sql = "select y.nickname from yixin_contact y where y.uid = {0}";
        var un = eval('('+ XLY.Sqlite.Find(dbPath+"\\main.db",sql.format(aUser[i].uid)) +')');
        if(un.length>0){
            members += un[0].nickname+"("+aUser[i].uid+")";
        }else{
            members += aUser[i].uid;
        }
        if(i+1<aUser.length){
            members += "\n";
        }
    }
    return members;
}

function creatGroupMessage(gTree,group){
    var sql = "select * from msghistory where id = {0}";
    var allMsg = eval('('+ XLY.Sqlite.Find(dbPath+"\\msg.db",sql.format(group.id)) +')');
    for(var i in allMsg){
        var msg = allMsg[i];
        var _msg = new Message();
        _msg.DataState = "Normal";
        _msg.sender = msg.fromid;
        _msg.receiver = group.tname;
        _msg.time = XLY.Convert.LinuxToDateTime(msg.time);
        _msg.msgtype = getMessageType(msg.msgtype);
        _msg.content = analysisMessageContent(msg);
        gTree.Items.push(_msg);
    }
}
//var source = "D:\\temp\\data\\data\\im.yixin";

var source = $source[0];

//var db = source[0];
//var db = "D:\\debug_files\\files";
//var charactor = "\\chalib\\Android_Skype_5.0.99\\main.db.charactor";
var dbPath = "";
var nAccount = new UserInfo();
var result = new Array();
result.push(bindTree());
var res  = JSON.stringify(result);
res;
