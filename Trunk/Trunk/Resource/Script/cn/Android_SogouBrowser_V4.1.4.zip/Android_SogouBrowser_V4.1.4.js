﻿/*[config]
<plugin name="搜狗浏览器,4" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="\icons\SogouBrowser.png" app="sogou.mobile.explorer" version="4.1.4" description="搜狗浏览器"  data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/sogou.mobile.explorer/app_webview/Cookies</value>
<value>/data/data/sogou.mobile.explorer/databases/#F</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Download" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="网址" code="Url" type="url" width = "200"></item>
<item name="名字" code="Name" type="string" width = "200"></item>
<item name="路径" code="Dir" type="string" width = "150"></item>
<item name="类型" code="Type" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "150"></item>
<item name="Cookies" code="Cookies" type="string" width = "150"></item>
<item name="代理" code="Agent" type="string" width = "150"></item>
<item name="总大小" code="TotalSize" type="string" width = "150"></item>
<item name="已下载大小" code="CurrentSize" type="string" width = "150"></item>
<item name="描述" code="Description" type="string" width = "150"></item> 
</data>
<data type="Cookies" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="主键" code="Key" type="string" width = "150"></item>
<item name="名字" code="Name" type="string" width = "200"></item>
<item name="值" code="Value" type="string" width = "200"></item>
</data>
<data type="Favorite" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="ID" code="Id" type="url" width = "150"></item>
<item name="修改时间" code="Time" type="string" width = "200"></item>
</data>
<data type="History" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="ID" code="Id" type="url" width = "150"></item>
<item name="修改时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Quicklaunch" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="MD5值" code="MD5" type="string" width = "200"></item>
</data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function Download() {
    this.DataState = "Normal";
    this.Url = "";
    this.Name = "";
    this.Dir = "";
    this.Type = "";
    this.Time = "";
    this.Cookies = "";
    this.Agent = "";
    this.TotalSize = "";
    this.CurrentSize = "";
    this.Description = "";
}
function Favorite() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Id = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Id = "";
    this.Time = "";
}
function Quicklaunch() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Id = "";
    this.MD5 = "";
}
//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}

function bindTree() {
    newTreeNode("Cookies", "Cookies", getCookies(db5));
    newTreeNode("收藏", "Favorite", getFavorite(db7));
    newTreeNode("浏览记录", "History", getHistory(db7));
    newTreeNode("下载文件", "Download", getDownload(db6));
    newTreeNode("主页", "Quicklaunch", getQuicklaunch(db8));
}

function getNews() {
    var list = new Array();
    data = ["Cookies", "收藏", "浏览记录", "主页", "下载文件"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}

function getCookies(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies") + ')');
    for (var i in data) {
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from downloads") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Url = data[i].uri;
        obj.Name = data[i].hint;
        obj.Dir = data[i]._data;
        obj.Type = data[i].mimetype;
        obj.Cookies = data[i].cookiedata;
        obj.Agent = data[i].useragent;
        obj.TotalSize = data[i].total_bytes + " bytes";
        obj.CurrentSize = data[i].current_bytes + " bytes";
        obj.Description = data[i].uid;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].lastmod);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getFavorite(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cloud_favorite") + ')');
    for (var i in data) {
        var obj = new Favorite();
        obj.Title = data[i].f_title;
        obj.Url = data[i].f_url;
        obj.Id = data[i].f_server_id;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].f_last_modify);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cloud_history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].h_title;
        obj.Url = data[i].h_url;
        obj.Id = data[i].h_server_id;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].h_last_modify);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getQuicklaunch(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from quicklaunch") + ')');
    for (var i in data) {
        var obj = new Quicklaunch();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.MD5 = data[i].md5_lastupdate;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1] + "\\downloads.db";
var db2 = source[1];
var db3 = source[1] + "\\sogou_mobile_browser.db";
var b = eval('(' + XLY.File.FindFileNames(db2) + ')');
for (var i in b) {
    var reg = /^sogou_cloud_/;
    var c = b[i].match(reg);
    if (c != null) {
        path = db2 + b[i] + ".db";
        break;
    }
}

var charactor = "\\chalib\\Android_SogouBrowser_V4.1.4\\Cookies.charactor";
var charactor1 = "\\chalib\\Android_SogouBrowser_V4.1.4\\downloads.db.charactor";
var charactor2 = "\\chalib\\Android_SogouBrowser_V4.1.4\\sogou.db.charactor";
var charactor3 = "\\chalib\\Android_SogouBrowser_V4.1.4\\sogou_mobile_browser.db.charactor";

var db5 = XLY.Sqlite.DataRecovery(db, charactor, "cookies");
var db6 = XLY.Sqlite.DataRecovery(db1, charactor1, "downloads");
var db7 = XLY.Sqlite.DataRecovery(path, charactor2, "cloud_favorite,cloud_history");
var db8 = XLY.Sqlite.DataRecovery(db3, charactor3, "quicklaunch");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
