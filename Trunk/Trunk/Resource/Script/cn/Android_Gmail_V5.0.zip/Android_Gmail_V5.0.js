﻿/*[config]
<plugin name="Gmail邮箱,3" group="主流邮箱,4"  devicetype="android" pump="USB,Mirror,Wifi,Bluetooth,chip,Raid,LocalData" app="com.google.android.gm" version="5.0" icon = "\icons\gmail.png" description="提取Gmail邮箱信息" data="$data,ComplexTreeDataSource">
   <source>
       <value>/data/data/com.google.android.gm/databases#F</value>
   </source>
   <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="邮箱所属人名称" code="Name" type="string" width="180" format = ""></item>
        <item name="昵称" code="NickName" type="string" width="100" format = ""></item>
        <item name="邮箱地址" code="Address" type="string" width="180" format=""></item>
   </data>

   <data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="发件人" code="Sender" type="string" width="300" format=""></item>
        <item name="收件人" code="Receiver" type="string" width="300" format=""></item>
        <item name="发送时间" code="SendTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="接收时间" code="ReceiveTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
        <item name="主题" code="Subject" type="string" width="300" format=""></item>
        <item name="邮件内容" code="Content" type="string" width="300" format = ""></item>
        <item name="附件信息" code="Attach" type="string" width="300" format=""></item>
   </data>
</plugin>
[config]*/
//********************************************* 定义数据结构*********************************************

//定义Account数据结构
function Account() {
    this.Address = "";
    this.Name = "";
    this.NickName = "";
    this.ID = "";
    this.DataState = "Normal";
}

//定义Message数据结构
function Message() {
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.Content = "";
    this.Attach = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

var result = new Array();

//源文件
var source = $source;
//测试文件
//var source = ["C:\\Users\\Administrator\\Desktop\\com.google.android.gm\\databases"]
var path = source[0];
var ch1 = "\\chalib\\Android_Gmail_V5.0\\EmailProvider.db.charactor";
var path1 = XLY.Sqlite.DataRecovery(path+"\\EmailProvider.db",ch1, "Account,Attachment,Message,Mailbox"); 

var files = eval('(' + XLY.File.FindFiles(path) + ')');
var gpaths = new Array();
var ch2 = "\\chalib\\Android_Gmail_V5.0\\mailstore.charactor";
for(var index in files){
    var str = files[index];
    if(str.indexOf("mailstore.")>= 0&&str.charAt(str.length-1)=="b"&&str.indexOf("recovery")==-1){        
        str = XLY.Sqlite.DataRecovery(str,ch2, "messages");
        gpaths.push(str);
    }
}

//主界面函数
function ParesCore(){
    //定义gmail节点
    var gNode = BuildNode("gmail邮箱","",[])
    //定义gmail账户节点
    for(var i in gpaths){
        var gdb =  XLY.File.GetFileName(gpaths[i]);
        var index = gdb.indexOf(".")
        var accName = gdb.slice(index+1,gdb.length-12);
        var gaccNode = BuildNode(accName,"Message",getGmailMessage(gpaths[i]));
        gNode.TreeNodes.push(gaccNode);  
    }
    //定义其他邮箱节点
    var acc = getAccount()
    var emailNode = BuildNode("其他邮箱","Account",acc);
    for(var j in acc){
        //定义其他邮箱账户节点
        var accNode = BuildNode(acc[j].Name,"",[]); //getMessage(acc[i].ID)
        var emailFiles = getFiles(acc[j].ID);
        if(emailFiles!=null&&emailFiles.length>0){
            //定义邮箱分类节点
            for(var m in emailFiles){
                var msg = getMessage(acc[j].ID,emailFiles[m].xly_id)
                var msgNode = BuildNode(emailFiles[m].displayName,"Message",msg);
                accNode.TreeNodes.push(msgNode);
            }
        }
        emailNode.TreeNodes.push(accNode);
    }
    result.push(gNode);
    result.push(emailNode);
}

//创建节点
function BuildNode(text,type,items){
    var node = new TreeNode();
    node.Text = text;
    node.Type = type;
    node.Items = items;
    return node;
}

//获取gmail邮件信息
function getGmailMessage(dbpath){
    var db = eval('('+ XLY.Sqlite.Find(dbpath,"select * from messages") +')');
    var Items = new Array();
    for(var i in db){
        var msg = new Message();
        msg.Sender = db[i].fromAddress;
        msg.Receiver = db[i].toAddresses;
        msg.SendTime = XLY.Convert.LinuxToDateTime(db[i].dateSentMs);
        msg.ReceiveTime = XLY.Convert.LinuxToDateTime(db[i].dateReceivedMs);
        msg.Subject = db[i].subject;
        msg.Content = db[i].snippet;
        msg.Attach = db[i].joinedAttachmentInfos;
        msg.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(msg);
    }
    return Items;
}

//获取其他邮箱账户信息
function getAccount(){
    var db = eval('('+ XLY.Sqlite.Find(path1,"select * from Account") +')');
    var Items = new Array();
    for(var i in db){
        var acc = new Account();
        acc.Address = db[i].emailAddress;
        acc.Name = db[i].displayName;
        acc.NickName = db[i].senderName;
        acc.ID = db[i].xly_id;
        acc.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(acc);
    }
    return Items;
}

//获取其他邮箱分类
function getFiles(ID){
    var db = eval('('+ XLY.Sqlite.Find(path1,"select distinct displayName,_id from Mailbox where accountKey = '"+ID+"'") +')');
    return db;   
}

//获取其他邮件信息
function getMessage(accID,boxID){
    var db = eval('('+ XLY.Sqlite.Find(path1,"select * from Message where accountKey = '"+accID+"' and mailboxKey = '"+boxID+"'") +')');
    var Items = new Array();
    if(db!=null&&db.length>0){
        for(var i in db){
            var msg = new Message();
            msg.Sender = db[i].fromList;
            msg.Receiver = db[i].toList;
            msg.ReceiveTime = XLY.Convert.LinuxToDateTime(db[i].timeStamp);
            msg.Subject = db[i].subject;
            msg.Content = db[i].snippet;
            var strAttach = "";
            if(db[i].flagAttachment==1){
                var db1 = eval('('+ XLY.Sqlite.Find(path1,"select cast(contentUri as text)as contentUri from Attachment where accountKey = '"+accID+"' and messageKey = '"+db[i].xly_id+"'") +')');
                if(db1!=null&&db1.length>0){
                    for(var j in db1){
                        strAttach+=db1[j].contentUri+"    ";
                    }
                }
            } 
            msg.Attach = strAttach;
            msg.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(msg);
        }
    }
    return Items;
}

ParesCore();
var res = JSON.stringify(result);
res;
