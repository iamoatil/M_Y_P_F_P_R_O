﻿/*[config]
<plugin name="淘宝,6" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/TaoBao.png" app="com.taobao.taobao4iphone" version="3.4.1" description="Test-导航树" data="$data,TreeDataSource">
<source>
<value>com.taobao.taobao4iphone</value>
</source>
<data type="Cart">
<item name="购物车商品" code="Name" type="string" width="" ></item>
</data>
<data type="ValidCart">
<item name="店铺名称" code="Name" type="string" width="100" ></item>
<item name="商品介绍" code="Title" type="string" width="350" ></item>
<item name="商品图片" code="Picture" type="string" width="200" ></item>
<item name="选购商品属性" code="Property" type="string" width="150" ></item>
<item name="选购数量" code="Quantity" type="string" width="80" ></item>
<item name="商品单价" code="Price" type="string" width="100" ></item>
<item name="备注" code="Remark" type="string" width="150" ></item>
</data>
<data type="InvalidCart">
<item name="店铺名称" code="Name" type="string" width="100" ></item>
<item name="商品介绍" code="Title" type="string" width="400" ></item>
<item name="商品图片" code="Picture" type="string" width="200" ></item>
<item name="选购商品属性" code="Property" type="string" width="150" ></item>
<item name="选购数量" code="Quantity" type="string" width="100" ></item>
<item name="备注" code="Remark" type="string" width="150" ></item>
</data>
<data type="Search">
<item name="关键字" code="Word" type="string" width="100" ></item>
<item name="时间" code="Date" type="datetime" width="300" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>
<data type="Account">
<item name="历史登录账号" code="Name" type="string" width="" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Cart() {
    this.Name = "";
}

function ValidCart() {
    this.Name = "";
    this.Title = "";
    this.Picture = "";
    this.Property = "";
    this.Quantity = "";
    this.Price = "";
    this.Remark = "";
}

function InvalidCart() {
    this.Name = "";
    this.Title = "";
    this.Picture = "";
    this.Property = "";
    this.Quantity = "";
    this.Remark = "";
}

function Search() {
    this.Word = "";
    this.Date = "";
}

function Account() {
    this.Name = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//创建购物车子树节点
function buildChildNodeForCart(tree, path) {
    //创建有效商品子节点
    var ValidGoods = new TreeNode();
    ValidGoods.Text = "有效商品";
    ValidGoods.Type = "ValidCart";
    var valid = getValidCartInfo(path);
    ValidGoods.Items = valid;

    //创建失效商品子节点
    var InvalidGoods = new TreeNode();
    InvalidGoods.Text = "失效商品";
    InvalidGoods.Type = "InvalidCart";
    var invalid = getInvalidCartInfo(path);
    InvalidGoods.Items = invalid;

    //获取根节点（购物车）的信息
    var cart = new Array();
    var arr1 = new Array();
    var arr2 = new Array();
    for (var index in valid) {
        var obj = new Cart();
        obj.Name = valid[index].Title;
        arr1.push(obj)
    }
    for (var num in invalid) {
        var obj = new Cart();
        obj.Name = invalid[num].Title;
        arr2.push(obj)
    }
    cart = arrayConcat(arr1, arr2);
    tree.Items = cart;
    tree.TreeNodes.push(ValidGoods);
    tree.TreeNodes.push(InvalidGoods);
}

//合并两个数组的元素
function arrayConcat(a1, a2) {
    var newarr = new Array();
    var p = 0;
    for (var k1 in a1) {
        newarr[k1] = a1[k1];
        p = k1;
    }
    ++p;
    for (var k2 in a2) {
        newarr[p] = a2[k2];
        p++;
    }
    return newarr;
}

//获取购物车商品信息
function getValidCartInfo(path) {
    var filepath = eval('(' + XLY.File.FindFiles(path) + ')');
    var arr = new Array();
    for (var index in filepath) {
        if ((/\.do/).test(filepath[index])) {
            var data = eval('(' + XLY.File.ReadFile(filepath[index]) + ')');
            var info = data.data.bagList.validGroupList;
            for (var num in info) {
                var obj = new ValidCart();
                obj.Name = info[num].itemList[0].shop.shopName + "(" + info[num].itemList[0].shop.sellerId + ")";
                obj.Title = info[num].itemList[0].itemDisplayPart.title;
                obj.Picture = info[num].itemList[0].itemDisplayPart.pic;
                obj.Property = info[num].itemList[0].itemDisplayPart.skuInfo;
                obj.Quantity = info[num].itemList[0].itemDisplayPart.quantity;
                obj.Price = info[num].itemList[0].price.unitPrice;
                obj.Remark = info[num].itemList[0].additionalDisplayPart.优惠方式;
                arr.push(obj);
            }
        }
    }
    return arr;
}

//获取购物车中失效商品信息
function getInvalidCartInfo(path) {
    var filepath = eval('(' + XLY.File.FindFiles(path) + ')');
    var arr = new Array();
    for (var index in filepath) {
        if ((/\.do/).test(filepath[index])) {
            var data = eval('(' + XLY.File.ReadFile(filepath[index]) + ')');
            if (data.data.bagList.invalidGroup != null) {
                var info = data.data.bagList.invalidGroup.itemList;
                for (var num in info) {
                    var obj = new InvalidCart();
                    obj.Name = info[num].shop.shopName + "(" + info[num].shop.sellerId + ")";
                    obj.Title = info[num].itemDisplayPart.title;
                    obj.Picture = info[num].itemDisplayPart.pic;
                    obj.Property = info[num].itemDisplayPart.skuInfo;
                    obj.Quantity = info[num].itemDisplayPart.quantity;
                    obj.Remark = info[num].additionalDisplayPart.优惠方式;
                    arr.push(obj);
                }
            }
        }
    }
    return arr;
}

//获取历史搜索信息
function getSearchInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(save_date as text)as t,* from [2]") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Search();
        var keyword = eval('(' + data[index].key + ')');
        obj.Word = keyword.search_keyword;
        obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data[index].t));
        info.push(obj);
    }
    return info;
}

//获取历史登陆账号
function getAccountInfo(path){
var filepath=eval('('+XLY.File.FindDirectories( path  )+')');
var info=new Array();
for(var index in filepath){
    var filename=XLY.File.GetFileName( filepath[index]);
		if((/^cntaobao/gi).test(filename)){
			var obj=new Account();
			obj.Name=filename.slice(filename.indexOf("bao")+3,filename.length)
			info.push(obj);
		}
	}
	return info;
}
var result = new Array();
//源文件
var source = $source;
var path = source[0] + "\\com.taobao.taobao4iphone\\Library\\Caches\\ASIHTTPRequestCache\\SessionStore";
var keywordpath = source[0] + "\\com.taobao.taobao4iphone\\Documents\\local_storage.sqlite";
var accpath=source[0] + "\\com.taobao.taobao4iphone\\Library\\Caches";

//创建购物车树
//var path = "E:\\app_data\\IOS\\com.taobao.taobao4iphone\\Library\\Caches\\ASIHTTPRequestCache\\SessionStore";
var cart = new TreeNode();
cart.Text = "购物车";
cart.Type = "Cart";
buildChildNodeForCart(cart, path);

//创建历史搜索树
//var keywordpath = "E:\\app_data\\IOS\\com.taobao.taobao4iphone\\Documents\\local_storage.sqlite";
var search = new TreeNode();
search.Text = "历史搜索";
search.Type = "Search";
search.Items = getSearchInfo(keywordpath);

//创建历史账号
//var accpath="E:\\app_data\\IOS\\com.taobao.taobao4iphone\\Library\\Caches";
var account = new TreeNode();
account.Text = "历史登录账号";
account.Type = "Account";
account.Items = getAccountInfo(accpath);

result.push(cart);
result.push(search);
result.push(account);
var res = JSON.stringify(result);
res;
