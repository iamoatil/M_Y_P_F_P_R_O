﻿//descritpion:Test-复杂导航树

/*[config]
<plugin name="陌陌,5" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="icons\icon_momo.png" app="com.immomo.momo" version="4.9" description="Test-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.immomo.momo/#F</value>
</source>

<data type="Group" contract="DataState"  datefilter="CreateTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群名称" code="Name" type="string" width="120" alignment="center"></item>
<item name="群号" code="Id" type="string" width="80" format=""></item>
<item name="群创建时间" code="CreateTime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="" format=""></item>
<item name="群介绍" code="Introduce" type="string" width="" format="200"></item>
<item name="群成员数" code="Number" type="string" width="" format="60"></item>
<item name="群创建地" code="CreatePlace" type="string" width="120" format=""></item>
<item name="群状态" code="State" type="string" width="60" format=""></item>
</data>

<data type="Discussion" contract="DataState"  datefilter="CreateTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="讨论名称" code="Name" type="string" width="120" alignment="center"></item>
<item name="讨论组号" code="Id" type="string" width="" format=""></item>
<item name="创建时间" code="CreateTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="" format=""></item>
<item name="讨论组人数" code="Number" type="string" width="60" format=""></item>
</data>

<data type="User" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="120" ></item>
<item name="帐号ID" code="Id" type="string" width="100" ></item>
<item name="性别" code="Gender" type="string" width="60" ></item>
<item name="年龄" code="Age" type="string" width="60" ></item>
<item name="生日" code="BrithDay" type="string" width="140" ></item>
<item name="个性签名" code="Signature" type="string" width="180" ></item>
<item name="注册时间" code="RegisterDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
<item name="手机号码" code="TelephoneNumber" type="string" width="120" ></item>
<item name="兴趣爱好" code="Hobby" type="string" width="" ></item>
<item name="职业" code="Profession" type="string" width="" ></item>
<item name="星座" code="Constellation" type="string" width="" ></item>
<item name="最近联系时间" code="StartDate" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="距离(米)" code="Distance" type="string" width="60" ></item>
</data>

<data detailfield="Content" type="Message"  datefilter="Date" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="160" alignment="center" ></item>
<item name="发送者头像" code="SenderImage" type="string" width="120" alignment="center" format="" show="false"></item>
<item name="接收人" code="Receiver" type="string" width="160" alignment="center"></item>
<item name="内容" code="Content" type="string" width="" format="260"></item>
<item name="时间" code="Date" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width="140"></item>
<item name="类别" code="Type" type="string" width="60" show="false"></item>
<item name="消息类别" code="MessageType" type="string" width="60"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

</plugin>
[config]*/

// js content

function Group() {
    this.Id = "";
    this.Name = "";
    this.CreateTime = null;
    this.Creator = "";
    this.Introduce = "";
    this.Number = "";
    this.CreatePlace = "";
    this.State = "";
    this.DataState = "Normal";
}

function Discussion() {
    this.Id = "";
    this.Name = "";
    this.CreateTime = null;
    this.Creator = "";
    this.Number = "";
    this.DataState = "Normal";
}

function User() {
    this.Name = "";
    this.Id = "";
    this.Gender = "";
    this.Age = "";
    this.BrithDay = "";
    this.Signature = "";
    this.RegisterDate = null;
    this.TelephoneNumber = "";
    this.Hobby = "";
    this.Profession = "";
    this.Constellation = "";
    this.StartDate = null;
    this.Distance = "";
    this.DataState = "Normal";
}

//定义数据结构
function Message() {
    this.SenderName = "";
    this.SenderImage = "";
    this.Receiver = "";
    this.Date = null;
    this.Content = "";
    this.MessageType = "";
    this.Type = "";
    this.SendState = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

// string.format
String.prototype.format = function (args) {
    var result = this;
    if (arguments.length > 0) {
        var reg;
        if (arguments.length == 1 && typeof (args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    reg = new RegExp("({" + key + "})", "g");
                    result = result.replace(reg, args[key]);
                }
            }
        }
        else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    reg = new RegExp("({)" + i + "(})", "g");
                    result = result.replace(reg, arguments[i]);
                }
            }
        }
    }
    return result;
};

var result = new Array();
//源文件
var source = $source;

//var source = "C:\\XLYSFTasks\\ 未命名-55\\source\\data\\data\\com.immomo.momo";


var sqlStr = "select {0} from {1} ";

function GetSql(parm, tablename, where) {
    if (!isNewDb) {
        // 旧数据库SQL
        var sql = sqlStr.format(parm, tablename);
        if (where != "") {
            sql += where;
        }
        return sql;
    } else {
        var sql = sqlStr.format(parm + ",XLY_DataType", tablename);
        if (where != "") {
            sql += where;
        }
        return sql;
    }
}



var isNewDb = true;

// 特征库文件路径
var chailb = "chalib\\Android_Momo_V4.9\\72005989.charactor";

// 表集合
var tableList = "users2,bothfollow,friends,fans,messages,groups,gmessages,discuss,discussmessages";

ParesCore();
var res = JSON.stringify(result);
res;

//数据提取方法。
function ParesCore() {
    var accounts = eval('(' + XLY.File.FindFileNames(source + "\\files\\sync") + ')');
    var databaseRoot = source + "\\databases\\";
    for (var acc in accounts) {
        var oldDbpath = databaseRoot + accounts[acc];
        // 特征库文件处理;
        //chailb=chailb.format(accounts[acc]);
        var dbpath = XLY.Sqlite.DataRecovery(oldDbpath, chailb, tableList);
        if (dbpath == oldDbpath) {
            isNewDb = false;
        }

        var sql = GetSql("u_momoid as Id,cast(u_name as nvarchar) as Name,cast(u_loctime as nvarchar) as StartDate,cast(u_distance as nvarchar) as Distance,cast(field8 as nvarchar) as TelephoneNumber,cast(field9 as nvarchar)as Gender,cast(field10 as nvarchar)as Age,cast(field11 as nvarchar) as RegisterDate,cast(field12 as nvarchar) as BrithDay,cast(field13 as nvarchar)as Signature,cast(field25 as nvarchar) as Constellation,cast(field26 as nvarchar) as Hobby,cast(field27 as nvarchar) as Profession", "users2", "");
        var users = ExecSql(dbpath, sql);

        //帐户信息。
        var account = GetUserInfo(users, accounts[acc]);
        var accountTree = new TreeNode();
        accountTree.Text = account.Name + "(" + accounts[acc] + ")";
        accountTree.DataType = XLY.Convert.ToDataState(account.XLY_DataType);
        accountTree.Type = "User";
        accountTree.Items.push(GetUserDetailMsg(account));

        //Build好友树结构
        var firendTree = new TreeNode();
        firendTree.Text = "好友";
        firendTree.Type = "User";
        var firendSql = GetSql("bf_momoid as momoid,f_followtime", "bothfollow", "");
        var allFriends = ExecSql(dbpath, firendSql);
        BuildFriendTree(accountTree, firendTree, allFriends, users, dbpath);

        //构建关注列表树结构。
        var guanzhuTree = new TreeNode();
        guanzhuTree.Text = "关注";
        guanzhuTree.Type = "User";
        var guanzhusql = GetSql(" f_momoid as momoid,f_followtime", "friends", "");
        var guanzhuFriends = ExecSql(dbpath, guanzhusql);
        BuildFriendTree(accountTree, guanzhuTree, guanzhuFriends, users, dbpath);

        //构建粉丝树结构
        var fansTree = new TreeNode();
        fansTree.Text = "粉丝";
        fansTree.Type = "User";
        var fanssql = GetSql("f_momoid as momoid,f_followtime", "fans", "");
        var allfansFriends = ExecSql(dbpath, fanssql);
        BuildFriendTree(accountTree, fansTree, allfansFriends, users, dbpath);

        //构建群组树结构
        var grounpTree = new TreeNode();
        grounpTree.Text = "群组";
        grounpTree.Type = "Group";
        BuildGroupTree(grounpTree, dbpath, users);

        //构建讨论组树结构。
        var discussTree = new TreeNode();
        discussTree.Text = "讨论组";
        discussTree.Type = "Discussion";
        BuildDiscussTree(discussTree, dbpath, users);

        //把各个分支书节点装载入当前帐号树结构中。
        accountTree.TreeNodes.push(firendTree);
        accountTree.TreeNodes.push(guanzhuTree);
        accountTree.TreeNodes.push(fansTree);
        accountTree.TreeNodes.push(grounpTree);
        accountTree.TreeNodes.push(discussTree);
        result.push(accountTree);
    }
}

//执行SQL信息。
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}

//获取用户标识信息。
function GetUserInfo(users, momoId) {
    for (var index in users) {
        if (users[index].Id == momoId) {
            return users[index];
        }
    }
    return null;
}

//获取小心类型。
function GetMsgType(mstype) {
    switch (mstype) {
        case 0:
            return "文本";
        case 1:
            type = "Image";
            return "图片";
        case 2:
            return "地理位置";
        case 3:
            return "被关注";
        case 4:
            type = "Audio";
            return "语音";
        case 5:
            return "系统提示";
        case 6:
            return "特殊表情";
        case 7:
            return "系统消息";
        default:
            return "位置";
    }
}

// 数据类型
function GetType(type) {
    switch (type) {
        case "图片":
            return "Image";
        case "语音":
            return "Audio";
        default:
            return "";
    }
}

//构建好友，关注，粉丝树结构。
function BuildFriendTree(accountTree, firendTree, allFriends, users, dbpath) {
    for (var index in allFriends) {
        var friend = allFriends[index];
        var oneFriendTree = new TreeNode();
        oneFriendTree.Type = "Message";
        oneFriendTree.DataState = XLY.Convert.ToDataState(friend.XLY_DataType);
        var userInfo = GetUserInfo(users, friend.momoid);
        if (userInfo == null) {
            oneFriendTree.Text = "Null";
            return oneFriendTree;
        }
        oneFriendTree.Text = userInfo.Name + "(" + userInfo.Id + ")";
        var msgSql = GetSql("m_status,m_receive as receiveFlag,m_time as Time,m_type as MessageType,m_msginfo as Content", "messages", "where m_remoteid == '" + friend.momoid + "'"); // "select XLY_DataType, m_status,m_receive as receiveFlag,m_time as Time,m_type as MessageType,m_msginfo as Content from messages where m_remoteid == '" + friend.momoid + "'";
        var msgList = ExecSql(dbpath, msgSql);
        SetPrivateChatMsg(accountTree, oneFriendTree, msgList);

        firendTree.Items.push(GetUserDetailMsg(userInfo));
        firendTree.TreeNodes.push(oneFriendTree);
    }
}

//获取私聊（好友，关注，粉丝）信息。
function SetPrivateChatMsg(accountTree, tree, msgList) {
    for (var index in msgList) {
        var msgInfo = msgList[index];
        var msg = new Message();
        //发送
        if (msgInfo.receiveFlag == 0) {
            msg.Receiver = tree.Text;
            msg.SenderName = accountTree.Text;
            msg.SendState = "Send";
        } else { //接收
            msg.SenderName = tree.Text;
            msg.Receiver = accountTree.Text;
            msg.SendState = "Receive";
        }

        var obj = eval('(' + msgInfo.Content + ')');
        msg.Content = obj.content;
        msg.DataState = XLY.Convert.ToDataState(msgInfo.XLY_DataType);
        msg.Date = XLY.Convert.LinuxToDateTime(parseInt(msgInfo.Time));
        msg.MessageType = GetMsgType(msgInfo.MessageType);
        msg.Type = GetType(msg.MessageType);
        tree.Items.push(msg);
    }
}

//获取讨论组和群组信息。
function SetGroupAndDiscussMsg(groupTree, msgList, users) {

    for (var index in msgList) {
        var msgInfo = msgList[index];
        var msg = new Message();
        msg.Receiver = groupTree.Text;
        var sender = msgInfo.SenderId;
        var userInfo = GetUserInfo(users, msgInfo.SenderId);
        if (userInfo != null) {
            sender = userInfo.Name + "(" + userInfo.Id + ")";
        }

        msg.SenderName = sender;
        if (msg.Sender == "") {
            msg.SenderName = "系统消息";
            msg.SendState = "Receive";
        }

        if (msgInfo.receiveFlag == 0) {
            msg.SendState = "Send";
        } else {
            msg.SendState = "Receive";
        }

        var obj = eval('(' + msgInfo.Content + ')');
        msg.Content = obj.content;
        msg.DataState = XLY.Convert.ToDataState(msgInfo.XLY_DataType);
        msg.Date = XLY.Convert.LinuxToDateTime(parseInt(msgInfo.Time));
        msg.MessageType = GetMsgType(msgInfo.MessageType);
        msg.Type = GetType(msg.MessageType);
        groupTree.Items.push(msg);
    }
}

//构建群组树
function BuildGroupTree(grounpTree, dbpath, users) {
    var groupsql = GetSql("field1 as Id,cast(field2 as nvarchar) as Name,cast(field3 as nvarchar) as CreateTime,cast(field4 as nvarchar) as CreatorId,cast(field6 as nvarchar) as Introduce,cast(field9  as nvarchar)as Number,cast(field19 as nvarchar) as State,cast(field21 as nvarchar) as CreatePlace", "groups", "");
    //var groupsql = "select XLY_DataType, field1 as Id,cast(field2 as nvarchar) as Name,cast(field3 as nvarchar) as CreateTime,cast(field4 as nvarchar) as CreatorId,cast(field6 as nvarchar) as Introduce,cast(field9  as nvarchar)as Number,cast(field19 as nvarchar) as State,cast(field21 as nvarchar) as CreatePlace from groups";
    var allgroups = ExecSql(dbpath, groupsql);

    for (var index in allgroups) {
        var group = allgroups[index];
        var oneGroupTree = new TreeNode();
        oneGroupTree.Type = "Message";
        oneGroupTree.Text = group.Name + "(" + group.Id + ")";
        oneGroupTree.DataState = XLY.Convert.ToDataState(group.XLY_DataType);
        //获取群组信息。
        var groupmsgSql = GetSql("m_msginfo as Content,m_remoteid as SenderId,m_receive as receiveFlag,m_time as Time,m_type as MessageType", "gmessages", "where field4 = '" + group.Id + "'");
        //var groupmsgSql = "select XLY_DataType, m_msginfo as Content,m_remoteid as SenderId,m_receive as receiveFlag,m_time as Time,m_type as MessageType from gmessages where field4 = '" + group.Id + "'";
        var msgList = ExecSql(dbpath, groupmsgSql);
        SetGroupAndDiscussMsg(oneGroupTree, msgList, users);
        grounpTree.TreeNodes.push(oneGroupTree);

        var groupInfo = new Group();
        groupInfo.Id = group.Id;
        groupInfo.DataState = XLY.Convert.ToDataState(group.XLY_DataType);
        groupInfo.Name = group.Name;
        groupInfo.CreateTime = XLY.Convert.LinuxToDateTime(parseInt(group.CreateTime));

        if (group.CreatorId == null) {
            groupInfo.Creator = group.CreatorId;
        }
        else {
            var creator = GetUserInfo(users, group.CreatorId);
            if (creator != null) {
                groupInfo.Creator = creator.Name + "(" + group.CreatorId + ")";
            }
            else {
                groupInfo.Creator = group.CreatorId;
            }
        }

        groupInfo.Introduce = group.Introduce;
        groupInfo.Number = group.Number;
        groupInfo.CreatePlace = group.CreatePlace;

        if (group.State == 1) {
            groupInfo.State = "加入的群";
        } else {
            groupInfo.State = "附近的群";
        }

        grounpTree.Items.push(groupInfo);
    }
}

//构建讨论树。
function BuildDiscussTree(discussTree, dbpath, users) {
    var discusssql = GetSql("did as Id, cast(field1 as nvarchar) as Name,field2 as CreatorId,field7 as CreateTime,field8 as Number", "discuss", "");
    //var discusssql = "select XLY_DataType, did as Id, cast(field1 as nvarchar) as Name,field2 as CreatorId,field7 as CreateTime,field8 as Number from discuss";
    var alldiscusses = ExecSql(dbpath, discusssql);

    for (var index in alldiscusses) {
        var discuss = alldiscusses[index];
        var oneDiscussTree = new TreeNode();
        oneDiscussTree.Type = "Message";
        oneDiscussTree.Text = discuss.Name + "(" + discuss.Id + ")";
        oneDiscussTree.DataState = XLY.Convert.ToDataState(discuss.XLY_DataType);
        //构建讨论组信息。
        var discussmsgSql = GetSql("m_msginfo as Content,m_remoteid as SenderId,m_receive as receiveFlag,m_time as Time,m_type as MessageType", "discussmessages", "where field4 = '" + discuss.Id + "'");
        //var discussmsgSql = "select XLY_DataType, m_msginfo as Content,m_remoteid as SenderId,m_receive as receiveFlag,m_time as Time,m_type as MessageType from discussmessages  where field4 = '" + discuss.Id + "'";
        var msgList = ExecSql(dbpath, discussmsgSql);
        SetGroupAndDiscussMsg(oneDiscussTree, msgList, users);
        discussTree.TreeNodes.push(oneDiscussTree);

        var discussInfo = new Discussion();
        discussInfo.Id = discuss.Id;
        discussInfo.Name = discuss.Name;
        discussInfo.DataState = XLY.Convert.ToDataState(discuss.XLY_DataType);
        discussInfo.CreateTime = XLY.Convert.LinuxToDateTime(parseInt(discuss.CreateTime));

        if (discuss.CreatorId == null) {
            discussInfo.Creator = discuss.CreatorId;
        }
        else {
            var creator = GetUserInfo(users, discuss.CreatorId);
            discussInfo.Creator = creator.Name + "(" + discuss.CreatorId + ")";
        }

        discussInfo.Number = discuss.Number;
        discussTree.Items.push(discussInfo);
    }
}

//获取用户详细信息。
function GetUserDetailMsg(userInfo) {
    var accountInfo = new User();
    accountInfo.Id = userInfo.Id;
    accountInfo.Name = userInfo.Name;
    accountInfo.BrithDay = userInfo.BrithDay;
    accountInfo.Age = userInfo.Age;
    accountInfo.RegisterDate = XLY.Convert.LinuxToDateTime(parseInt(userInfo.RegisterDate));
    accountInfo.StartDate = XLY.Convert.LinuxToDateTime(parseInt(userInfo.StartDate));
    accountInfo.Constellation = userInfo.Constellation;

    if (userInfo.Gender == "F") {
        accountInfo.Gender = "女";
    }
    else {
        accountInfo.Gender = "男";
    }

    accountInfo.Hobby = userInfo.Hobby;
    accountInfo.TelephoneNumber = userInfo.TelephoneNumber;
    accountInfo.Profession = userInfo.Profession;
    accountInfo.Signature = userInfo.Signature;
    accountInfo.Distance = userInfo.Distance;
    accountInfo.DataState = XLY.Convert.ToDataState(userInfo.XLY_DataType);
    return accountInfo;
}

