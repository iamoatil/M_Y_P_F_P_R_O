﻿/*[config]
<plugin name="LanTern,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/lantern.png" app="org.getlantern.lantern" version="3.7.3" description="Lantern" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/org.getlantern.lantern/shared_prefs/LanternSession.xml</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width = "100"></item>
    <item name="账号" code="AccountId" type="string" width = "100"></item>
    <item name="是否开启蓝灯" code="PrefVpn" type="string" width = "80"></item>
    <item name="是否代理全部流量" code="ProxyAll" type="string" width = "80"></item>
    <item name="是否专业版" code="ProUser" type="string" width = "80"></item>
    <item name="过期时间" code="ExpiryDate" type="string" width = "120"></item>
    <item name="邮箱地址" code="EmailAddress" type="string" width = "100"></item>
    <item name="设备动态授权码" code="DeviceLinkingCode" type="string" width="100"></item>
    <item name="设备动态授权码过期时间" code="DeviceCodeExp" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="地理国家代码" code="GeoCountry" type="string" width = "80"></item>
    <item name="设备ID" code="DeviceID" type="string" width = "80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.AccountId = "";
    this.PrefVpn = "否";
    this.ProxyAll = "否";
    this.ProUser = "否";
    this.ExpiryDate = "";
    this.EmailAddress = "";
    this.DeviceLinkingCode = "";
    this.DeviceCodeExp = null;
    this.GeoCountry = "";
    this.DeviceID = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath = source[0];

//测试数据
//var userPath = "D:\\temp\\data\\data\\org.getlantern.lantern\\shared_prefs\\LanternSession.xml";
//定义特征库文件
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "蓝灯(Lantern)";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userdata = eval('('+ XLY.File.ReadXML(userPath) +')');
        if(userdata!=""&&userdata!=null){
            var aa = userdata.map.string;
            var bb = userdata.map.boolean;
            var cc = userdata.map.long;
            var obj = new UserInfo();
            if(aa!=""&&aa!= null){
                for(var i in aa){
                    if(aa[i]["@name"]=="accountid"){
                        obj.AccountId = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="deviceid"){
                        obj.DeviceID = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="userid"){
                        obj.UserId = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="devicelinkingcode"){
                        obj.DeviceLinkingCode = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="expirydate"){
                        obj.ExpiryDate = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="emailAddress"){
                        obj.EmailAddress = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="geo_country"){
                        obj.GeoCountry = aa[i]["#text"];
                    }
                }
            }
            if(bb!=""&&bb!=null){
                for(var j in bb){
                    if(bb[j]["@name"]=="pref_vpn"){
                        if(bb[j]["@value"]=="true"){
                            obj.PrefVpn = "是";
                        }
                    }
                    if(bb[j]["@name"]=="proxyAll"){
                        if(bb[j]["@value"]=="true"){
                            obj.ProxyAll = "是";
                        }
                    }
                    if(bb[j]["@name"]=="prouser"){
                        if(bb[j]["@value"]=="true"){
                            obj.ProUser = "是";
                        }
                    }
                }
            }
            if(cc!=""&&cc!=null){
                if(cc["@name"]=="devicecodeexp"){
                    obj.DeviceCodeExp = XLY.Convert.LinuxToDateTime(cc["@value"]);
                }
            }
            var userNode = new TreeNode();
            userNode.Text = obj.UserId;
            userNode.Type = "UserInfo";
            userNode.Items.push(obj);
            if(userNode.Items!=""&&userNode.Items!=null){
                root.TreeNodes.push(userNode);
            }
        }
    }
}