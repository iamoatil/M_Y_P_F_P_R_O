﻿/*[config]
<plugin name="Opera浏览器,3" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/OperaBrowser.png" app="com.opera.browser" version="26.0.1656.87080" description="Opera浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.opera.browser/app_opera/favorites.db</value>
<value>/data/data/com.opera.browser/shared_prefs/recently_closed_tabs.xml</value>
<value>/data/data/com.opera.browser/app_opera/Bookmarks</value>
</source>

<data type="Quicklink" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="" format=""></item>
<item name="快速链接地址" code="Link" type="string" width="" format=""></item>
</data>

<data type="History" >
<item name="标题" code="Title" type="string" width="" format=""></item>
<item name="历史浏览地址" code="Url" type="string" width="" format=""></item>
</data>

<data type="UrlGather" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="集合名称" code="Name" type="string" width="" format=""></item>
</data>

</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义Quicklink数据结构
function Quicklink() {
    this.Title = "";
    this.Link = "";
    this.DataState = "Normal";
}

//定义History数据结构
function History() {
    this.Title = "";
    this.Url = "";
}

//定义UrlGather数据结构
function UrlGather() {
    this.Name = "";
    this.DataState = "Normal";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path1 = source[0];
var path2 = source[1];
var path3 = source[2]

//定义特征库文件
var charactor = "chalib\\Android_OperaBrowser_V20.0.1396\\favorites.db.charactor";

//恢复数据库中删除的数据
var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
var quicklink = new TreeNode();
quicklink.Text = "快速链接";
quicklink.Type = "Quicklink";
var sql = "select * from favorites where type=0";
quicklink.Items = getQuicklinkInfo(recoverypath1, sql);
buildChildNodeForQuicklink(recoverypath1, quicklink);

result.push(quicklink);
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
//创建快速链接的子节点
function buildChildNodeForQuicklink(path, node) {
    var urlAddress = new TreeNode();
    urlAddress.Text = "网页链接";
    urlAddress.Type = "Quicklink";
    var addrsql = "select * from favorites where parent_guid='' AND type=0";
    var url = getQuicklinkInfo(path, addrsql);
    urlAddress.Items = url;

    var urlGather = new TreeNode();
    urlGather.Text = "网址集合";
    urlGather.Type = "UrlGather";
    var info = eval('(' + XLY.Sqlite.Find(path, "select * from favorites where type=1") + ')');
    var arr = new Array();
    for (var index in info) {
        if(info[index].name!="保存的页面"){
            //获取网址集合的信息
            var obj = new UrlGather();
            obj.Name = info[index].name;
            obj.DataState = XLY.Convert.ToDataState(info[index].XLY_DataType);
            arr.push(obj);

            //创建网址集合的子节点
            var gather = new TreeNode(); 
            gather.Type = "Quicklink";
            gather.DataState = XLY.Convert.ToDataState(info[index].XLY_DataType);
            if(info[index].name=="书签"){
                gather.Text = info[index].name;
                var gatherInfo = GetBookmark();
            }
            else if(info[index].name=="")
            {
                gather.Text = "默认网站";
                var gathersql = "select * from favorites where parent_guid ='" + info[index].guid + "'";
                var gatherInfo = getQuicklinkInfo(path, gathersql);
            }
            
            gather.Items = gatherInfo;
            urlGather.TreeNodes.push(gather);
        }      
    }
    urlGather.Items = arr;
    node.TreeNodes.push(urlAddress);
    node.TreeNodes.push(urlGather);
}

//提取书签信息
function GetBookmark(){
    var data = eval('(' + XLY.File.ReadFile(path3) + ')'); 
    var Items = new Array();
    var info = data.roots.custom_root.unsorted.children;
    for(var i in info){
        var bm = new Quicklink();
        bm.Title = info[i].name;
        bm.Link = XLY.Convert.UrlDecode(info[i].url);
        Items.push(bm)
    }
    return Items;
}

//获取快速链接地址
function getQuicklinkInfo(path,sql ) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Quicklink();
        obj.Link = data[index].url;
        obj.Title = data[index].name;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取历史浏览记录
function getHistoryInfo(path2) {
    if(XLY.File.IsValid(path2)){
        var data = eval('(' + XLY.File.ReadXML(path2) + ')');
        if (data.map != null) {
            var con = data.map.string;
            var info = new Array();
            for (var index in con) {
                var obj = new History();
                if ((/_title_/).test(con[index]["@name"])) {
                    obj.Title = con[index]["#text"];
                    var url = con[index]["@name"].replace("title", "url");
                    obj.Url = findurl(url, con);
                    info.push(obj);
                }
            }
            function findurl(key, datasource) {
                for (var num in datasource) {
                    if (datasource[num]['@name'] == key) {
                        return datasource[num]['#text'];
                    }
                }
            }
        }
        return info;
    }
}
