﻿/*[config]
<plugin name="ICQ,6" group="社交聊天,2" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/ICQ.png" app="com.icq.icqfree" version="6.13.5" description="ICQ" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.icq.icqfree</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="AccountID" type="string" width="100" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="100" format = "" ></item>
    <item name="姓名" code="FullName" type="string" width="100" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="100" format = "" ></item>
    <item name="生日" code="Birthday" type="string" width="100" format = "" ></item>
    <item name="学校" code="Education" type="string" width="100" format = "" ></item>
    <item name="工作" code="Job" type="string" width="100" format = "" ></item>
    <item name="邮箱" code="Email" type="string" width="100" format = "" ></item>
    <item name="电话号码" code="MobileNumber" type="string" width="100" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="100" format = "" ></item>
    <item name="国家" code="Country" type="string" width="100" format = "" ></item>
    <item name="关于我" code="AboutMe" type="string" width="100" format = "" ></item>
    <item name="城市" code="City" type="string" width="100" format = "" ></item>
</data>
<data type="GroupList" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="群组ID" code="GroupID" type="string" width = "100"></item>
    <item name="群组名称" code="GroupName" type="string" width = "100"></item>
    <item name="主题" code="Title" type="string" width = "100"></item>
    <item name="群头像链接" code="GroupUrl" type="url" width = "100"></item>
</data>
<data type="GroupMember" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="ID" code="ID" type="string" width = "100"></item>
    <item name="昵称" code="NickName" type="string" width = "100"></item>
    <item name="头像链接" code="HeadUrl" type="url" width = "100"></item>
</data>
<data type="Message" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="100" format = "" ></item>
    <item name="发送者昵称" code="SenderName" type="string" width="100" format = "" ></item>
    <item name="接收者ID" code="ReceiveID" type="string" width="100" format=""></item>
    <item name="接收者昵称" code="ReceiveName" type="string" width="100" format=""></item>
    <item name="消息内容" code="Content" type="string" width="100" format=""></item>
    <item name="发送时间" code="SendTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    <item name="消息类型" code="ContentType" type="string" width="100" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义GroupList数据结构
function GroupList(){
    this.DataState = "Normal";
    this.GroupID = "";
    this.GroupName = "";
    this.Title = "";
    this.GroupUrl = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.AccountID = "";
    this.FullName = "";
    this.NickName = "";
    this.Sex = "";
    this.Birthday = "";
    this.MobileNumber = "";
    this.HeadUrl = "";
    this.Country = "";
    this.AboutMe = "";
    this.City = "";
    this.Email = "";
    this.Job = "";
    this.Education = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReceiveID = "";
    this.ReceiveName = "";
    this.Content = "";
    this.SendTime = null;
    this.ContentType = "";
}
function GroupMember(){
    this.DataState = "Normal";
    this.ID = "";
    this.NickName = "";
    this.HeadUrl = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var agentPath1 = source[0]+"\\com.icq.icqfree\\Documents\\Agent.sqlite";
var clPath1 = source[0]+"\\com.icq.icqfree\\Documents\\cl.sqlite";
var userPath = source[0]+"\\com.icq.icqfree\\Library\\Preferences\\com.icq.icqfree.plist";
//测试数据
//var agentPath1 = "C:\\XLYSFTasks\\任务-2017-08-31-13-37-19\\source\\IosData\\2017-08-31-13-37-51\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.icq.icqfree\\Documents\\Agent.sqlite";
//var clPath1 = "C:\\XLYSFTasks\\任务-2017-08-31-13-37-19\\source\\IosData\\2017-08-31-13-37-51\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.icq.icqfree\\Documents\\cl.sqlite";
//var userPath = "C:\\XLYSFTasks\\任务-2017-08-31-13-37-19\\source\\IosData\\2017-08-31-13-37-51\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.icq.icqfree\\Library\\Preferences\\com.icq.icqfree.plist";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_ICQ_V6.15.3\\Agent.sqlite.charactor";
var charactor2 = "\\chalib\\iOS_ICQ_V6.15.3\\cl.sqlite.charactor";
//恢复数据库中删除的数据
var agentPath = XLY.Sqlite.DataRecovery(agentPath1,charactor1,"ZMRCONVERSATION,ZMRFILE,ZMRMESSAGE,ZMRPROFILE");
var clPath = XLY.Sqlite.DataRecovery(clPath1,charactor2,"anketa,chat_info,contact,contact_order,groupchat_composition");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "ICQ";
    news.Type = "";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(agentPath)){
        var userdata = eval('('+ XLY.Sqlite.Find(agentPath,"select cast(ZBIRTHDATE as text) as time,ZFIRSTNAME,ZLASTNAME,ZNICKNAME,ZPID,ZUID,ZWIMFETCHURL from ZMRPROFILE") +')');
        if(userdata!=""&&userdata!= null){
            for(var i in userdata){
                var usernode = new TreeNode();
                usernode.Text = userdata[i].ZUID+"_"+userdata[i].ZNICKNAME;
                usernode.Type = "UserInfo";
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(userdata[i].XLY_DataType);
                obj.AccountID = userdata[i].ZUID;
                obj.FullName = userdata[i].ZFIRSTNAME+" "+userdata[i].ZLASTNAME;
                obj.NickName = userdata[i].ZNICKNAME;
                obj.Birthday = XLY.Convert.LinuxToDateTime(userdata[i].time);
                obj.HeadUrl = userdata[i].ZWIMFETCHURL;
                //log(userdata[i].time);
                var aa = "loginPhoneNumber_"+userdata[i].ZPID;
                if(XLY.File.IsValid(userPath)){
                    var userPlistData = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
                    if(userPlistData!=""&&userPlistData!=null){
                        for(var j in userPlistData){
                            if(userPlistData[j][aa]!=""&&userPlistData[j][aa]!=null){
                                obj.MobileNumber = userPlistData[j][aa];
                            }
                        }
                    }
                }
                if(XLY.File.IsValid(clPath)){
                    var dataRowId = eval('('+ XLY.Sqlite.Find(clPath,"select rowid from contact where uid = '"+userdata[i].ZUID+"'") +')');
                    if(dataRowId!=""&&dataRowId!= null){
                        var dataRowId = eval('('+ XLY.Sqlite.Find(clPath,"select about,birthdate,city,country,education,emails,gender,job from anketa where contactID = '"+dataRowId[0].rowid+"'") +')');
                        if(dataRowId!=""&&dataRowId!=null){
                            obj.Country = dataRowId[0].country;
                            obj.AboutMe = dataRowId[0].about;
                            if(dataRowId[0].gender==1){
                                obj.Sex = "男";
                            }
                            else if(dataRowId[0].gender==2){
                                obj.Sex = "女";
                            }
                            else if(dataRowId[0].gender==3){
                                obj.Sex = "任何";
                            }
                            else
                            {
                                obj.Sex = "未指定";
                            }
                            
                            obj.City = dataRowId[0].city;
                            obj.Email = dataRowId[0].emails;
                            obj.Job = dataRowId[0].job;
                            obj.Education = dataRowId[0].education;
                        }
                    }
                }
                getChildNode(usernode,userdata[i].ZPID,userdata[i].ZNICKNAME);
                usernode.Items.push(obj);
                root.TreeNodes.push(usernode);
            }
        }
    }
    if(XLY.File.IsValid(clPath)){
        var nodeContact = new TreeNode();
        nodeContact.Text = "联系人";
        nodeContact.Type = "";
        
        var statusPhone = eval('('+ XLY.Sqlite.Find(clPath,"select XLY_DataType,contactID from contact_order where sectionOrderKey = '40'") +')');
        if(statusPhone!=""&&statusPhone!=null){
            var nodePhoneContact = new TreeNode();
            nodePhoneContact.Text = "手机联系人";
            nodePhoneContact.Type = "UserInfo";
            for(var i in statusPhone){
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(statusPhone[i].XLY_DataType);
                var data = eval('('+ XLY.Sqlite.Find(clPath,"select XLY_DataType,about,birthdate,city,country,education,emails,gender,job,birthdate,firstName,lastName,smsNumber from anketa where contactID = '"+statusPhone[i].contactID+"'") +')');
                if(data!=""&&data!=null){
                    obj.Country = data[0].country;
                    obj.AboutMe = data[0].about;
                    if(data[0].gender==1){
                        obj.Sex = "男";
                    }
                    else if(data[0].gender==2){
                        obj.Sex = "女";
                    }
                    else if(data[0].gender==3){
                        obj.Sex = "任何";
                    }
                    else
                    {
                        obj.Sex = "未指定";
                    }
                    
                    obj.City = data[0].city;
                    obj.Email = data[0].emails;
                    obj.Job = data[0].job;
                    obj.Education = data[0].education;
                    obj.Birthday = XLY.Convert.LinuxToDateTime(data[0].birthdate);
                    if(data[0].firstName!=""&&data[0].firstName!=null){
                        if(data[0].lastName!=""&&data[0].lastName!=null){
                            obj.FullName = data[0].firstName+" "+data[0].lastName;
                        }
                        else
                        {
                            obj.FullName = data[0].firstName;
                        }
                    }
                    else
                    {
                        if(data[0].lastName!=""&&data[0].lastName!=null){
                            obj.FullName = dataRowId[0].lastName;
                        }
                        else
                        {
                            obj.FullName = "123";
                        }
                    }
                    obj.FullName = data[0].firstName+" "+data[0].lastName;
                    obj.MobileNumber = data[0].smsNumber;
                }
                var dataContact = eval('('+ XLY.Sqlite.Find(clPath,"select uid,displayName from contact where rowid = '"+statusPhone[i].contactID+"'") +')');
                if(dataContact!=""&&dataContact!=null){
                    obj.AccountID = dataContact[0].uid;
                    obj.NickName = dataContact[0].displayName;
                }
                obj.HeadUrl = "";
                nodePhoneContact.Items.push(obj);
            }
            nodeContact.TreeNodes.push(nodePhoneContact);
        }
        var statusPhoneICQ = eval('('+ XLY.Sqlite.Find(clPath,"select XLY_DataType,contactID from contact_order where sectionOrderKey = '1' or sectionOrderKey = '30' or sectionOrderKey = '10'") +')');
        if(statusPhoneICQ!=""&&statusPhoneICQ!=null){
            var nodePhoneContactICQ = new TreeNode();
            nodePhoneContactICQ.Text = "ICQ";
            nodePhoneContactICQ.Type = "UserInfo";
            for(var i in statusPhoneICQ){
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(statusPhoneICQ[i].XLY_DataType);
                var data = eval('('+ XLY.Sqlite.Find(clPath,"select about,birthdate,city,country,education,emails,gender,job,birthdate,firstName,lastName,smsNumber from anketa where contactID = '"+statusPhoneICQ[i].contactID+"'") +')');
                if(data!=""&&data!=null){
                    obj.Country = data[0].country;
                    obj.AboutMe = data[0].about;
                    if(data[0].gender==1){
                        obj.Sex = "男";
                    }
                    else if(data[0].gender==2){
                        obj.Sex = "女";
                    }
                    else if(data[0].gender==3){
                        obj.Sex = "任何";
                    }
                    else
                    {
                        obj.Sex = "未指定";
                    }
                    
                    obj.City = data[0].city;
                    obj.Email = data[0].emails;
                    obj.Job = data[0].job;
                    obj.Education = data[0].education;
                    obj.Birthday = XLY.Convert.LinuxToDateTime(data[0].birthdate);
                    if(data[0].firstName!=""&&data[0].firstName!=null){
                        if(data[0].lastName!=""&&data[0].lastName!=null){
                            obj.FullName = data[0].firstName+" "+data[0].lastName;
                        }
                        else
                        {
                            obj.FullName = data[0].firstName;
                        }
                    }
                    else
                    {
                        if(data[0].lastName!=""&&data[0].lastName!=null){
                            obj.FullName = dataRowId[0].lastName;
                        }
                        else
                        {
                            obj.FullName = "123";
                        }
                    }
                    obj.FullName = data[0].firstName+" "+data[0].lastName;
                    obj.MobileNumber = data[0].smsNumber;
                }
                var dataContact = eval('('+ XLY.Sqlite.Find(clPath,"select uid,displayName from contact where rowid = '"+statusPhoneICQ[i].contactID+"'") +')');
                if(dataContact!=""&&dataContact!=null){
                    obj.AccountID = dataContact[0].uid;
                    obj.NickName = dataContact[0].displayName;
                }
                obj.HeadUrl = "";
                nodePhoneContactICQ.Items.push(obj);
            }
            nodeContact.TreeNodes.push(nodePhoneContactICQ);
        }
        root.TreeNodes.push(nodeContact);
    }
}
function getChildNode(root,pid,nickname){
    if(XLY.File.IsValid(clPath)){
        var nodeGroupInfo = new TreeNode();
        nodeGroupInfo.Text = "群组列表";
        nodeGroupInfo.Type = "GroupList";
        var groupList = eval('('+ XLY.Sqlite.Find(clPath,"select XLY_DataType,contactID,chatDescription from chat_info") +')');
        if(groupList!=""&&groupList!=null){
            for(var i in groupList){
                var groupInfo = eval('('+ XLY.Sqlite.Find(clPath,"select uid,displayName from contact where rowid='"+groupList[i].contactID+"' and profilePID = '"+pid+"'") +')');
                if(groupInfo!=""&&groupInfo!=null){
                    var nodeChildGroup = new TreeNode();
                    nodeChildGroup.Text = groupInfo[0].uid+"_"+groupInfo[0].displayName;
                    nodeChildGroup.Type = "GroupList";
                    var objGroup = new GroupList();
                    objGroup.DataState = XLY.Convert.ToDataState(groupList[i].XLY_DataType);
                    objGroup.GroupID = groupInfo[0].uid;
                    objGroup.GroupName = groupInfo[0].displayName;
                    objGroup.Title = groupList[i].chatDescription;
                    objGroup.GroupUrl = "https://api.icq.net/expressions/get?t="+groupInfo[0].uid+"&f=native&type = buddyIcon";
                    nodeChildGroup.Items.push(objGroup);
                    nodeGroupInfo.TreeNodes.push(nodeChildGroup);
                    
                    var groupInfoContactID = eval('('+ XLY.Sqlite.Find(clPath,"select contactID from groupchat_composition where chatID = '"+groupList[i].contactID+"'") +')');
                    if(groupInfoContactID!=""&&groupInfoContactID!=null){
                        var groupMember = new TreeNode();
                        groupMember.Text = "群成员";
                        groupMember.Type = "GroupMember";
                        for(var a in groupInfoContactID){
                            var groupdata = eval('('+ XLY.Sqlite.Find(clPath,"select XLY_DataType,uid,displayName from contact where rowid = '"+groupInfoContactID[a].contactID+"'") +')');
                            var ggroupMember = new GroupMember();
                            ggroupMember.DataState = XLY.Convert.ToDataState(groupdata[0].XLY_DataType);
                            ggroupMember.ID = groupdata[0].uid;
                            ggroupMember.NickName = groupdata[0].displayName;
                            ggroupMember.HeadUrl = "https://api.icq.net/expressions/get?t="+groupdata[0].uid+"&f=native&type = buddyIcon";
                            groupMember.Items.push(ggroupMember);
                        }
                        nodeChildGroup.TreeNodes.push(groupMember);
                    }
                }
            }
        }
        if(nodeGroupInfo.TreeNodes!=""&&nodeGroupInfo.TreeNodes!=null){
            root.TreeNodes.push(nodeGroupInfo);
        }
    }
    if(XLY.File.IsValid(agentPath)){
        var chatNode = new TreeNode();
        chatNode.Text = "聊天记录";
        chatNode.Type = "";
        var conversationPersonInfo = eval('('+ XLY.Sqlite.Find(agentPath,"select  Z_PK,ZPID from ZMRCONVERSATION where ZPROFILEPID = '"+pid+"' and ZPID not like '%@chat.agent'") +')');
        if(conversationPersonInfo!=""&&conversationPersonInfo!=null){
            var chatPersonNode = new TreeNode();
            chatPersonNode.Text = "好友聊天记录";
            chatPersonNode.Type = "Message";
            for(var i in conversationPersonInfo){
                var userId = conversationPersonInfo[i].ZPID.substr(pid.length+1,conversationPersonInfo[i].ZPID.length);
                var userNode = new TreeNode();
                
                if(XLY.File.IsValid(clPath)){
                    var username = eval('('+ XLY.Sqlite.Find(clPath,"select displayName from contact where uid = '"+userId+"'") +')');
                    if(username!=""&&username!=null){
                        userNode.Text = userId+"_"+username[0].displayName;
                    }
                    else
                    {
                        userNode.Text = userId;
                    }
                }
                userNode.Type = "Message";
                var messageInfo = eval('('+ XLY.Sqlite.Find(agentPath,"select cast(ZTIME as int) as time,ZPARTICIPANTUID,ZFILE,ZTEXT,ZTYPE,Z_PK,XLY_DataType from ZMRMESSAGE where ZCONVERSATION = '"+conversationPersonInfo[i].Z_PK+"'") +')');
                if(messageInfo!=""&&messageInfo!=null){
                    for(var j in messageInfo){
                        var messageObj = new Message();
                        messageObj.DataState = XLY.Convert.ToDataState(messageInfo[j].XLY_DataType);
                        
                        messageObj.Content = messageInfo[j].ZTEXT;
                        
                        var aaaaaaaaaaaaaa = XLY.Convert.LinuxToDateTime(messageInfo[j].time);
                        messageObj.SendTime = parseInt(aaaaaaaaaaaaaa.substr(0,4))+31+aaaaaaaaaaaaaa.substr(4,aaaaaaaaaaaaaa.length);
                        if(messageInfo[j].ZTYPE=="100"){
                            messageObj.ContentType = "文本";
                        }
                        else if(messageInfo[j].ZTYPE=="719"){
                            messageObj.ContentType = "系统提示";
                        }
                        else if(messageInfo[j].ZTYPE=="709"){
                            messageObj.ContentType = "表情";
                        }
                        else if(messageInfo[j].ZTYPE=="510"){
                            var attachmentInfo = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE,ZDOWNLOADSOURCEFILEPATH from ZMRFILE where ZPARENT = '"+messageInfo[j].Z_PK+"'") +')');
                            if(attachmentInfo!=""&&attachmentInfo!= null){
                                if(attachmentInfo[0].ZMIMETYPE!=""&&attachmentInfo[0].ZMIMETYPE!=null){
                                    if(attachmentInfo[0].ZMIMETYPE=="video/mp4" || attachmentInfo[0].ZMIMETYPE=="audio/x-m4a"){
                                        messageObj.ContentType = "视频";
                                    }
                                    else if(attachmentInfo[0].ZMIMETYPE=="image/jpeg" || attachmentInfo[0].ZMIMETYPE=="image/png")
                                    {
                                        messageObj.ContentType = "图片";
                                    }
                                    else if(attachmentInfo[0].ZMIMETYPE=="audio/aac")
                                    {
                                        messageObj.ContentType = "语音";
                                    }
                                    else
                                    {
                                        messageObj.ContentType = "媒体";
                                    }
                                    messageObj.Content = attachmentInfo[0].ZDOWNLOADSOURCEFILEPATH;
                                }
                                else
                                {
                                    messageObj.ContentType = "媒体";
                                }
                                
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                            
                        }
                        else if(messageInfo[j].ZTYPE=="712"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageInfo[j].ZTYPE=="706"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageInfo[j].ZTYPE=="702"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageInfo[j].ZTYPE=="704"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageInfo[j].ZTYPE=="703"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageInfo[j].ZTYPE=="707"){
                            messageObj.ContentType = "系统提示";
                        }
                        else if(messageInfo[j].ZTYPE=="710"){
                            messageObj.ContentType = "通话";
                        }
                        else
                        {
                            messageObj.ContentType = "未知";
                        }
                        if(messageInfo[j].ZPARTICIPANTUID!=""&&messageInfo[j].ZPARTICIPANTUID!=null){
                            messageObj.SenderID = userId;
                            if(XLY.File.IsValid(clPath)){
                                var userInfoName = eval('('+ XLY.Sqlite.Find(clPath,"select displayName from contact where uid = '"+userId+"'") +')');
                                if(userInfoName!=""&&userInfoName!=null){
                                    messageObj.SenderName = userInfoName[0].displayName;
                                }
                            }
                            messageObj.ReceiveID = pid.substr(0,pid.length-4);
                            messageObj.ReceiveName = nickname;
                        }
                        else
                        {
                            messageObj.SenderID = pid.substr(0,pid.length-4);
                            messageObj.SenderName = nickname;
                            messageObj.ReceiveID = userId;
                            if(XLY.File.IsValid(clPath)){
                                var userInfoName = eval('('+ XLY.Sqlite.Find(clPath,"select displayName from contact where uid = '"+userId+"'") +')');
                                if(userInfoName!=""&&userInfoName!=null){
                                    messageObj.ReceiveName = userInfoName[0].displayName;
                                }
                            }
                        }
                        userNode.Items.push(messageObj);
                    }
                }
                chatPersonNode.TreeNodes.push(userNode);
            }
            chatNode.TreeNodes.push(chatPersonNode);
        }
        var conversationGroupInfo = eval('('+ XLY.Sqlite.Find(agentPath,"select  Z_PK,ZPID from ZMRCONVERSATION where ZPROFILEPID = '"+pid+"' and ZPID like '%@chat.agent'") +')');
        if(conversationGroupInfo!=""&&conversationGroupInfo!=null){
            var chatGroupNode = new TreeNode();
            chatGroupNode.Text = "群组聊天记录";
            chatGroupNode.Type = "Message";
            for(var i in conversationGroupInfo){
                var userGroupId = conversationGroupInfo[i].ZPID.substr(pid.length+1,conversationGroupInfo[i].ZPID.length);
                var userGroupNode = new TreeNode();
                
                if(XLY.File.IsValid(clPath)){
                    var userGroupname = eval('('+ XLY.Sqlite.Find(clPath,"select displayName from contact where uid = '"+userGroupId+"'") +')');
                    if(userGroupname!=""&&userGroupname!=null){
                        userGroupNode.Text = userGroupId+"_"+userGroupname[0].displayName;
                    }
                    else
                    {
                        userGroupNode.Text = userGroupId;
                    }
                }
                userGroupNode.Type = "Message";
                var messageGroupInfo = eval('('+ XLY.Sqlite.Find(agentPath,"select Z_PK,cast(ZTIME as int) as time,ZPARTICIPANTUID,ZFILE,ZTEXT,ZTYPE,XLY_DataType from ZMRMESSAGE where ZCONVERSATION = '"+conversationGroupInfo[i].Z_PK+"'") +')');
                if(messageGroupInfo!=""&&messageGroupInfo!=null){
                    for(var j in messageGroupInfo){
                        var messageObj = new Message();
                        messageObj.DataState = XLY.Convert.ToDataState(messageGroupInfo[j].XLY_DataType);
                        
                        messageObj.Content = messageGroupInfo[j].ZTEXT;
                        var aaaaaaaaaaaaaa = XLY.Convert.LinuxToDateTime(messageGroupInfo[j].time);
                        messageObj.SendTime = parseInt(aaaaaaaaaaaaaa.substr(0,4))+31+aaaaaaaaaaaaaa.substr(4,aaaaaaaaaaaaaa.length);
                        if(messageGroupInfo[j].ZTYPE=="100"){
                            messageObj.ContentType = "文本";
                        }
                        else if(messageGroupInfo[j].ZTYPE=="719"){
                            messageObj.ContentType = "系统提示";
                        }
                        else if(messageGroupInfo[j].ZTYPE=="709"){
                            messageObj.ContentType = "表情";
                        }
                        else if(messageGroupInfo[j].ZTYPE=="510"){
                            var attachmentInfo = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE,ZDOWNLOADSOURCEFILEPATH from ZMRFILE where ZPARENT = '"+messageGroupInfo[j].Z_PK+"'") +')');
                            if(attachmentInfo!=""&&attachmentInfo!= null){
                                if(attachmentInfo[0].ZMIMETYPE!=""&&attachmentInfo[0].ZMIMETYPE!=null){
                                    if(attachmentInfo[0].ZMIMETYPE=="video/mp4" || attachmentInfo[0].ZMIMETYPE=="audio/x-m4a"){
                                        messageObj.ContentType = "视频";
                                    }
                                    else if(attachmentInfo[0].ZMIMETYPE=="image/jpeg" || attachmentInfo[0].ZMIMETYPE=="image/png")
                                    {
                                        messageObj.ContentType = "图片";
                                    }
                                    else if(attachmentInfo[0].ZMIMETYPE=="audio/aac")
                                    {
                                        messageObj.ContentType = "语音";
                                    }
                                    else
                                    {
                                        messageObj.ContentType = "媒体";
                                    }
                                    messageObj.Content = attachmentInfo[0].ZDOWNLOADSOURCEFILEPATH;
                                }
                                else
                                {
                                    messageObj.ContentType = "媒体";
                                }
                                //log(attachmentInfo[0].ZMIMETYPE);
                                
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                            
                        }
                        else if(messageGroupInfo[j].ZTYPE=="712"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageGroupInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "媒体";
                            }
                        }
                        else if(messageGroupInfo[j].ZTYPE=="706"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageGroupInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageGroupInfo[j].ZTYPE=="702"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageGroupInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageGroupInfo[j].ZTYPE=="704"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageGroupInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageGroupInfo[j].ZTYPE=="703"){
                            var temp = eval('('+ XLY.Sqlite.Find(agentPath,"select ZMIMETYPE from ZMRFILE where ZPARENT = '"+messageGroupInfo[j].Z_PK+"'") +')');
                            if(temp!=""&&temp!=null){
                                messageObj.ContentType = "语音";
                            }
                            else
                            {
                                messageObj.ContentType = "未知";
                            }
                        }
                        else if(messageGroupInfo[j].ZTYPE=="707"){
                            messageObj.ContentType = "系统提示";
                        }
                        else if(messageGroupInfo[j].ZTYPE=="710"){
                            messageObj.ContentType = "通话";
                        }
                        else
                        {
                            messageObj.ContentType = "未知";
                        }
                        
                        if(messageGroupInfo[j].ZPARTICIPANTUID!=""&&messageGroupInfo[j].ZPARTICIPANTUID!=null){
                            messageObj.SenderID = messageGroupInfo[j].ZPARTICIPANTUID;
                            if(XLY.File.IsValid(clPath)){
                                var userInfoName = eval('('+ XLY.Sqlite.Find(clPath,"select displayName from contact where uid = '"+messageGroupInfo[j].ZPARTICIPANTUID+"'") +')');
                                if(userInfoName!=""&&userInfoName!=null){
                                    messageObj.SenderName = userInfoName[0].displayName;
                                }
                            }
                            messageObj.ReceiveID = userGroupNode.Text.split("_")[0];
                            messageObj.ReceiveName = userGroupNode.Text.split("_")[1];
                        }
                        else
                        {
                            messageObj.SenderID = pid.substr(0,pid.length-4);
                            messageObj.SenderName = nickname;
                            messageObj.ReceiveID = userGroupNode.Text.split("_")[0];
                            messageObj.ReceiveName = userGroupNode.Text.split("_")[1];
                        }
                        userGroupNode.Items.push(messageObj);
                    }
                }
                chatGroupNode.TreeNodes.push(userGroupNode);
            }
            chatNode.TreeNodes.push(chatGroupNode);
        }
        root.TreeNodes.push(chatNode);
    }
}