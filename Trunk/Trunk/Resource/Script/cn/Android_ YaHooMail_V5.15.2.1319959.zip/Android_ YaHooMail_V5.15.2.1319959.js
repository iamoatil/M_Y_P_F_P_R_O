﻿/*[config]
<plugin name="yahoo邮箱,3" group="主流邮箱,4" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/yahoo.png" app="com.yahoo.mobile.client.android.mail" version="5.15.2.1319959" description="YaHoo邮箱" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.yahoo.mobile.client.android.mail/app_webview#F</value>
    <value>/data/data/com.yahoo.mobile.client.android.mail/databases#F</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="Entry" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width="120" format=""></item>
    <item name="用户名" code="UserName" type="string" width="120" format=""></item>
    <item name="昵称" code="NickName" type="string" width="120" format=""></item>
    <item name="性别" code="Sex" type="string" width="120" format=""></item>
    <item name="出生年日" code="Birthday" type="string" width="120" format=""></item>
    <item name="电话号码" code="PhoneNumber" type="string" width="120" format=""></item>
    <item name="创建时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发件人" code="Sender" type="string" width="120" format=""></item>
    <item name="收件人" code="Receiver" type="string" width="120" format=""></item>
    <item name="抄送" code="Copy" type="string" width="120" format=""></item>
    <item name="密送" code="BCC" type="string" width="120" format=""></item>
    <item name="主题" code="Title" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="附件" code="Add" type="string" width="120" format=""></item>
    <item name="附件路径" code="AddPath" type="string" width="120" format=""></item>
    <item name="接收时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="发送时间" code="SendTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="是否为星标邮件" code="StarEmail" type="string" width="120" format=""></item>
    <item name="已读" code="IsRead" type="string" width="120" format=""></item>
</data>
<data type="Contact" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Guid" type="string" width="80" format=""></item>
    <item name="名称" code="Name" type="string" width="120" format=""></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format=""></item>
    <item name="是否真实姓名" code="IsRealName" type="string" width="80" format=""></item>
    <item name="公司名称" code="CompanyName" type="string" width="80" format=""></item>
    <item name="过期时间" code="ExpireTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item> 
    <item name="邮箱" code="Email" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.Name = "";
    this.Guid = "";
    this.Email = "";
    this.IsRealName = "";
    this.CompanyName = "";
    this.ExpireTime = null;
    this.HeadUrl = "";
}
//定义List数据结构
function List(){
    this.DataState = "Normal";
    this.Entry = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.UserName = "";
    this.NickName = "";
    this.Sex = "";
    this.Birthday = "";
    this.PhoneNumber = "";
    this.Time = null;
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Copy = "";
    this.BCC = "";
    this.Title = "";
    this.Content = "";
    this.Add = "";
    this.AddPath = "";
    this.Time = null;
    this.SendTime = null;
    this.StarEmail = "否";
    this.IsRead = "否";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath2 = source[0];
var contactInfoPath = source[1];
var userPath1 = userPath2 +"\\Web Data";
var maillInfoPath1 = contactInfoPath+"\\mailsdk.db";
//测试数据
//var userPath1 = "C:\\XLYSFTasks\\任务-2017-06-22-09-33-27\\source\\data\\data\\com.yahoo.mobile.client.android.mail\\app_webview\\Web Data";
//var contactInfoPath = "C:\\XLYSFTasks\\任务-2017-06-22-09-33-27\\source\\data\\data\\com.yahoo.mobile.client.android.mail\\databases";
//var maillInfoPath1 = contactInfoPath+"\\mailsdk.db";
//定义特征库文件
var charactor1 = "\\chalib\\Android_YaHooMail_V5.15.2.1319959\\Web Data.charactor";
var charactor2 = "\\chalib\\Android_YaHooMail_V5.15.2.1319959\\mailsdk.db.charactor";
var charactor3 = "\\chalib\\Android_YaHooMail_V5.15.2.1319959\\smart_contacts_b3mhf5thf7ocysm5gju73rmuvy7o4at6gyawqo25.db.charactor";


//恢复数据库中删除的数据
var userPath = XLY.Sqlite.DataRecovery(userPath1,charactor1,"autofill,unmasked_credit_cards");
var maillInfoPath = XLY.Sqlite.DataRecovery(maillInfoPath1,charactor2,"accounts,folders,messages");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "YaHoo邮箱";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var data = eval('('+ XLY.Sqlite.Find(userPath,"select distinct(date_created) from autofill") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var userData = eval('('+ XLY.Sqlite.Find(userPath,"select value from autofill where date_created = '"+data[i].date_created+"'") +')');
                if(userData!=""&&userData!= null){
                    if(userData.length==7){
                        var node = new TreeNode();
                        node.Text = userData[4].value+"_"+userData[6].value+userData[5].value;
                        node.Type = "UserInfo";
                        var obj = new UserInfo();
                        //obj.DataState = XLY.Convert.ToDataState();
                        obj.UserId = userData[4].value;
                        obj.UserName = userData[4].value+"@yahoo.com";
                        obj.NickName = userData[6].value+" "+userData[5].value;
                        obj.Sex = userData[0].value;
                        obj.Birthday = userData[1].value+"年"+userData[2].value+"日";
                        obj.PhoneNumber = userData[3].value;
                        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date_created);
                        node.Items.push(obj);
                        getUserChildInfomation(obj.UserName,node);
                        if(node.Items!=""&&node.Items!=null){
                            root.TreeNodes.push(node);
                        }
                    }
                }
            }
        }
    }
    var dbFileName = eval('('+ XLY.File.FindFileNamesWithExtension(contactInfoPath) +')');
    var reg1 = new RegExp("smart_contacts_");
    var reg2 = new RegExp("recover");
    if(dbFileName!=""&&dbFileName!= null){
        var nodeContact = new TreeNode();
        nodeContact.Text = "联系人";
        nodeContact.Type = "Contact";
        for(var d in dbFileName){
            if(reg1.test(dbFileName[d])){
                if(!reg2.test(dbFileName[d])){
                    var contactPath1 = contactInfoPath+"\\"+dbFileName[d];
                    if(XLY.File.IsValid(contactPath1)){
                        var contactPath = XLY.Sqlite.DataRecovery(contactPath1,charactor3,"smartcontacts");
                        if(XLY.File.IsValid(contactPath)){
                            var dataContact = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,guid,name,companyName,editToken,contactImageUrl,expiration_time,isRealName from smartcontacts") +')');
                            if(dataContact!=""&&dataContact!=null){
                                for(var b in dataContact){
                                    var obj = new Contact();
                                    obj.DataState = XLY.Convert.ToDataState(dataContact[b].XLY_DataType)
                                    obj.Name = dataContact[b].name;
                                    obj.Guid = dataContact[b].guid;
                                    obj.Email = dataContact[b].editToken;
                                    obj.HeadUrl = dataContact[b].companyName;
                                    if(dataContact[b].isRealName==1){
                                        obj.IsRealName = "是";
                                    }
                                    obj.CompanyName = dataContact[b].companyName;
                                    obj.ExpireTime = XLY.Convert.LinuxToDateTime(dataContact[b].expiration_time);
                                    nodeContact.Items.push(obj);
                                }
                            }
                        }
                    }
                }
            }
        }
        if(nodeContact.Items!=""&&nodeContact.Items!=null){
            root.TreeNodes.push(nodeContact);
        }
    }
}
function getUserChildInfomation(email,root){
    if(XLY.File.IsValid(maillInfoPath)){
        var dataId = eval('('+ XLY.Sqlite.Find(maillInfoPath,"select _id as id from accounts where email = '"+email+"'") +')');
        if(dataId!=""&&dataId!=null){
            for(var i in dataId){
                var data = eval('('+ XLY.Sqlite.Find(maillInfoPath,"select name,types,message_count,_id as id from folders where account_row_index = '"+dataId[i].id+"'") +')');
                if(data!=""&&data!=null){
                    for(var j in data){
                        if(data[j].types=="USER"){
                            var nodeUserCreateFolder = new TreeNode();
                            nodeUserCreateFolder.Text = data[j].name;
                            nodeUserCreateFolder.Type = "Message";
                            getMaillMessage(nodeUserCreateFolder,data[j].id,dataId[i].id);
                            if(nodeUserCreateFolder.Items!=""&&nodeUserCreateFolder.Items!=null){
                                root.TreeNodes.push(nodeUserCreateFolder);
                            }
                        }
                        else
                        {
                            if(data[j].name=="Inbox"){
                                var nodeInboxFolder = new TreeNode();
                                nodeInboxFolder.Text = "收件箱";
                                nodeInboxFolder.Type = "Message";
                                
                                getMaillMessage(nodeInboxFolder,data[j].id,dataId[i].id);
                                if(nodeInboxFolder.Items!=""&&nodeInboxFolder.Items!=null){
                                    root.TreeNodes.push(nodeInboxFolder);
                                }
                            }
                            if(data[j].name=="Draft"){
                                var nodeDraftFolder = new TreeNode();
                                nodeDraftFolder.Text = "草稿箱";
                                nodeDraftFolder.Type = "Message";
                                getMaillMessage(nodeDraftFolder,data[j].id,dataId[i].id);
                                if(nodeDraftFolder.Items!=""&&nodeDraftFolder.Items!=null){
                                    root.TreeNodes.push(nodeDraftFolder);
                                }
                            }
                            if(data[j].name=="Sent"){
                                var nodeSentFolder = new TreeNode();
                                nodeSentFolder.Text = "发送箱";
                                nodeSentFolder.Type = "Message";
                                getMaillMessage(nodeSentFolder,data[j].id,dataId[i].id);
                                if(nodeSentFolder.Items!=""&&nodeSentFolder.Items!=null){
                                    root.TreeNodes.push(nodeSentFolder);
                                }
                            }
                            if(data[j].name=="Trash"){
                                var nodeTrashFolder = new TreeNode();
                                nodeTrashFolder.Text = "垃圾箱";
                                nodeTrashFolder.Type = "Message";
                                getMaillMessage(nodeTrashFolder,data[j].id,dataId[i].id);
                                if(nodeTrashFolder.Items!=""&&nodeTrashFolder.Items!=null){
                                    root.TreeNodes.push(nodeTrashFolder);
                                }
                            }
                            if(data[j].name=="Archive"){
                                var nodeArchiveFolder = new TreeNode();
                                nodeArchiveFolder.Text = "归档";
                                nodeArchiveFolder.Type = "Message";
                                getMaillMessage(nodeArchiveFolder,data[j].id,dataId[i].id);
                                if(nodeArchiveFolder.Items!=""&&nodeArchiveFolder.Items!=null){
                                    root.TreeNodes.push(nodeArchiveFolder);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
function getMaillMessage(root,folderId,accountId){
    if(XLY.File.IsValid(maillInfoPath)){
        var data = eval('('+ XLY.Sqlite.Find(maillInfoPath,"select XLY_DataType,folder_row_index,received_ms,subject,snippet,to_address,sent_ms,from_address,cc,bcc,is_read,is_starred from messages where account_row_index = '"+accountId+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].folder_row_index==folderId){
                    var obj = new Message();
                    obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    obj.Sender = data[i].from_address;
                    obj.Receiver = data[i].to_address;
                    obj.Copy = data[i].cc;
                    obj.BCC = data[i].bcc;
                    obj.Title = data[i].subject;
                    obj.Content = data[i].snippet;
                    obj.Add = "";
                    obj.AddPath = "";
                    obj.Time = XLY.Convert.LinuxToDateTime(data[i].received_ms)
                    obj.SendTime = XLY.Convert.LinuxToDateTime(data[i].sent_ms)
                    if(data[i].is_starred==1){
                        obj.StarEmail = "是";
                    }
                    if(data[i].is_read==1){
                        obj.IsRead = "是";
                    }
                    root.Items.push(obj);
                }
            }
        }
    }
}