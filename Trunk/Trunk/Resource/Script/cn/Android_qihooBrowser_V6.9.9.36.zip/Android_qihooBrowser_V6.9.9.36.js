﻿/*[config]
<plugin name="360浏览器,4" group="Web痕迹,4" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\qihooBrowser.png" app="com.qihoo.browser" version="6.9.9.36" description="360浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.qihoo.browser/app_bookmark/#F</value>
<value>/data/data/com.qihoo.browser/app_webview/Cookies</value>
<value>/data/data/com.qihoo.browser/databases/browser.db</value>
<value>/data/data/com.qihoo.browser/databases/downloads.db</value>
</source>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="姓名" code="Name" type="string" width = "150"></item>
</data>
<data type="MobileBookmark" contract="DataState" datefilter="Created">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="300" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format=""></item>
<item name="创建时间" code="Created" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="修改时间" code="Modified" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="OnlineBookmark" contract="DataState" datefilter="Created">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="300" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format=""></item>
<item name="创建时间" code="Created" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="修改时间" code="Modified" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Cookies" contract="DataState" datefilter="Created">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主键" code="Key" type="string" width="300" format=""></item>
<item name="键名" code="Name" type="url" width="500" format = ""></item>
<item name="值" code="Value" type="string" width="300" format=""></item>
</data>
<data type="FrequentVisit" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="200" format = ""></item>
<item name="图标" code="Icon" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format = ""></item>
<item name="创建时间" code="Time" type="datetime" order="asc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Visits" type="string" width="100" format=""></item>
</data>
<data type="History" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="400" format=""></item>
<item name="URL地址" code="Url" type="url" width="200" format=""></item>
<item name="访问时间" code="Time"  type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Visits" order="desc" type="string" width="100" format=""></item>
</data>
<data type="SerachWords" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="KeyWords" type="string" width="100" format=""></item>
<item name="搜索时间" code="Time" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="DownloadFile" contract="DataState" datefilter="Title">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="200" format=""></item>
<item name="文件地址" code="Url" type="url" width="400" format = ""></item>
<item name="总大小" code="ToalBytes" type="string" width="100" format=""></item>
<item name="当前大小" code="CurrentBytes" type="string" width="100" format=""></item>
<item name="存储路径" code="SaveFile" type="string" width="200" format=""></item>
<item name="文件类型" code="FileType" type="string" width="240" format = ""></item>
<item name="修改时间" code="Time" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="文件名" code="Name" type="string" width="100" format = ""></item>
<item name="用户ID" code="Id" type="string" width="100" format=""></item>
<item name="描述" code="Description" type="string" width="150" format=""></item>
</data>
</plugin>
[config]*/
//定义数据结构
function Account(){
    this.DataState = "Normal";
    this.Name = "";
}
function MobileBookmark() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Created = "";
    this.Modified = "";
}
function OnlineBookmark() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Created = "";
    this.Modified = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function FrequentVisit() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Icon = "";
}
function History() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Visits = "";
}

function SerachWords() {
    this.DataState = "Normal";
    this.KeyWords = "";
    this.Time = null;
}
function DownloadFile() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.ToalBytes = "";
    this.CurrentBytes = "";
    this.SaveFile = "";
    this.FileType = "";
    this.Time = "";
    this.Name = "";
    this.Description = "";
    
}
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
function bindTree(){
    var acc = new TreeNode();
    acc.Text = "360浏览器";
    acc.Type = "Account";
    acc.Items = getAccount();
    acc.DataState = "Normal";

    newTreeNode("手机书签","MobileBookmark",getMobileBookmark(db9),acc);
    newTreeNode("电脑书签","OnlineBookmark",getOnlineBookmark(db10),acc);
    newTreeNode("Cookies","Cookies",getCookies(db11),acc);
    newTreeNode("最常访问","FrequentVisit",getFrequentVisit(db12),acc);
    newTreeNode("历史","History",getHistory(db12),acc);
    newTreeNode("搜索","SerachWords",getSerachWords(db12),acc);
    newTreeNode("下载文件","DownloadFile",getDownloadFile(db13),acc);
    result.push(acc);
}
function getAccount(){
    var list = new Array();
    data = ["手机书签","电脑书签","Cookies","最常访问","历史","搜索","下载文件"];
    for(var i in data){
        var obj = new Account();
        obj.Name = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}

function getMobileBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from tb_fav" ) +')');
    for(var i in data){
        var obj = new MobileBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Created = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Modified = XLY.Convert.LinuxToDateTime(data[i].last_modify_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getOnlineBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from tb_fav" ) +')');
    for(var i in data){
        var obj = new OnlineBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Created = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Modified = XLY.Convert.LinuxToDateTime(data[i].last_modify_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCookies(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cookies" ) +')');
    for(var i in data){
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFrequentVisit(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from frequent_visit" ) +')');
    for(var i in data){
        var obj = new FrequentVisit();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Icon = data[i].logo;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSerachWords(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from searches" ) +')');
    for(var i in data){
        var obj = new SerachWords();
        obj.KeyWords = data[i].search;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getDownloadFile(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from downloads" ) +')');
    for(var i in data){
        var obj = new DownloadFile();
        obj.Title = data[i].title;
        obj.Url = data[i].uri;
        obj.ToalBytes = data[i].total_bytes+" bytes";
        obj.CurrentBytes = data[i].cyrrent_bytes+" bytes";
        obj.SaveFile = data[i].hint;
        obj.FileType = data[i].mimetype;
        obj.Name = data[i].title;
        obj.Id = data[i].uid;
        obj.Description = data[i].description;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].lastmod);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;

var db = source[0];
var db1 = source[1];
var db2 = source[2];
var db3 = source[3];
var b = eval('('+ XLY.File.FindFileNamesWithExtension(db) +')');
for(var i in b){
    var reg = /^qihoo_mobile_bookmark.[0-9a-zA-Z]*.db$/;
    var c = b[i].match(reg);
    if(c!=null){
        path = db+"\\"+b[i];
    }
}
var c = eval('('+ XLY.File.FindFileNamesWithExtension(db) +')');
for(var i in b){
    var reg = /^qihoo_online_bookmark.[0-9a-zA-Z]*.db$/;
    var c = b[i].match(reg);
    if(c!=null){
        path1 = db+"\\"+b[i];
    }
}
var charactor1 = "\\chalib\\Android_360Browser_V6.9.9.36\\qihoo_mobile_bookmark.db.charactor";
var charactor2 = "\\chalib\\Android_360Browser_V6.9.9.36\\qihoo_online_bookmark.db.charactor";
var charactor3 = "\\chalib\\Android_360Browser_V6.9.9.36\\Cookies.charactor";
var charactor4 = "\\chalib\\Android_360Browser_V6.9.9.36\\browser.db.charactor";
var charactor5 = "\\chalib\\Android_360Browser_V6.9.9.36\\downloads.db.charactor";

var db9 = XLY.Sqlite.DataRecovery(path,charactor1,"tb_fav");
var db10 = XLY.Sqlite.DataRecovery(path1,charactor2,"tb_fav");
var db11 = XLY.Sqlite.DataRecovery(db1,charactor3,"cookies");
var db12 = XLY.Sqlite.DataRecovery(db2,charactor4,"frequent_visit,history,searches");
var db13 = XLY.Sqlite.DataRecovery(db3,charactor5,"downloads");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;

