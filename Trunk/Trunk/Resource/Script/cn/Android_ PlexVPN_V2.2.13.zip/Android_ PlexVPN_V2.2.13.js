﻿/*[config]
<plugin name="Plexvpn,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/plexVpn.png" app="com.shoplex.plex" version="2.2.13" description="Plexvpn" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.shoplex.plex/databases/tray.db</value>
    <value>/data/data/com.shoplex.plex/shared_prefs/com.shoplex.plex_preferences.xml</value>
    <value>/data/data/com.shoplex.plex/files/ss-local-vpn.conf</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width = "100"></item>
    <item name="用户名" code="AccountId" type="string" width = "100"></item>
    <item name="邮箱" code="Email" type="string" width = "80"></item>
    <item name="会员过期时间" code="ExpireTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="允许设备数目" code="DeviceCount" type="string" width = "80"></item>
    <item name="本地端口" code="LocalPort" type="string" width = "100"></item>
    <item name="路由" code="Route" type="string" width = "100"></item>
    <item name="是否第一次登陆" code="IsFirstStart" type="string" width="80"></item>
    <item name="邀请码" code="InvitationCode" type="string" width="80"></item>
    <item name="是否自动连接" code="IsAutoConnect" type="string" width = "100"></item>
    <item name="是否账号已过期" code="IsAccountExpire" type="string" width = "100"></item>
    <item name="是否打开TcpFastOpen" code="TcpFastOpen" type="string" width = "100"></item>
    <item name="当前链接服务器IP" code="ServeIP" type="string" width="80"></item>
    <item name="当前链接服务器端口" code="ServePort" type="string" width="80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.AccountId = "";
    this.Email = "";
    this.ExpireTime = null;
    this.DeviceCount = "";
    this.LocalPort = "";
    this.Route = "";
    this.IsFirstStart = "否";
    this.InvitationCode = "";
    this.IsAutoConnect = "否";
    this.TcpFastOpen = "否";
    this.ServeIP = "";
    this.ServePort = "";
    this.IsAccountExpire = "否";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userDbPath = source[0];
var userXmlPath = source[1];
var userFilePath = source[2];

//测试数据
//var userDbPath = "D:\\temp\\data\\data\\com.shoplex.plex\\databases\\tray.db";
//var userXmlPath = "D:\\temp\\data\\data\\com.shoplex.plex\\shared_prefs\\com.shoplex.plex_preferences.xml";
//var userFilePath = "D:\\temp\\data\\data\\com.shoplex.plex\\files\\ss-local-vpn.conf";
//定义特征库文件
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "PlexVPN";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userDbPath)){
        var userdata = eval('('+ XLY.Sqlite.Find(userDbPath,"select KEY,VALUE from TrayPreferences") +')');
        if(userdata!=""&&userdata!=null){
            var obj = new UserInfo();
            for(var i in userdata){
                if(userdata[i].KEY=="isFirstStart"){
                    if(userdata[i].VALUE=="true"){
                        obj.IsFirstStart = userdata[i].VALUE;
                    }
                }
                if(userdata[i].KEY=="accountName"){
                    obj.AccountId = userdata[i].VALUE;
                }
                if(userdata[i].KEY=="email"){
                    obj.Email = userdata[i].VALUE;
                }
                if(userdata[i].KEY=="deviceCount"){
                    obj.DeviceCount = userdata[i].VALUE;
                }
                if(userdata[i].KEY=="userId"){
                    obj.UserId = userdata[i].VALUE;
                }
                if(userdata[i].KEY=="expireTime"){
                    obj.ExpireTime = XLY.Convert.LinuxToDateTime(userdata[i].VALUE);
                }
                if(userdata[i].KEY=="invitationCode"){
                    obj.InvitationCode = userdata[i].VALUE;
                }
                if(userdata[i].KEY=="isAccountExpired"){
                    if(userdata[i].VALUE=="true"){
                        obj.IsAccountExpire = "是";
                    }
                }
                if(userdata[i].KEY=="route"){
                    obj.Route = userdata[i].VALUE;
                }
            }
            if(XLY.File.IsValid(userXmlPath)){
                var xmldata = eval('('+ XLY.File.ReadXML(userXmlPath) +')');
                if(xmldata!=""&&xmldata!=null){
                    var abc = xmldata.map.boolean;
                    if(abc!=""&&abc!=null){
                        for(var y in abc){
                            if(abc[y]["@name"]=="isAutoConnect"){
                                if(abc[y]["@value"]=="true"){
                                    obj.IsAutoConnect = "是";
                                }
                            }
                            if(abc[y]["@name"]=="tcp_fastopen"){
                                if(abc[y]["@value"]=="true"){
                                    obj.TcpFastOpen = "是";
                                }
                            }
                        }
                    }
                    var bac = xmldata.map.int;
                    if(bac!=""&&bac!=null){
                        if(bac["@value"]!=""&&bac["@value"]!=null){
                            obj.LocalPort = bac["@value"];
                        }
                    }
                }
            }
            if(XLY.File.IsValid(userFilePath)){
                var filedata = eval('('+ XLY.File.ReadFile(userFilePath) +')');
                obj.ServeIP = filedata.server;
                obj.ServePort = filedata.server_port;
            }
            var node = new TreeNode();
            node.Text = obj.AccountId;
            node.Type = "UserInfo";
            node.Items.push(obj);
            if(node.Items!=""&&node.Items!=null){
                root.TreeNodes.push(node);
            }
        }
    }
}