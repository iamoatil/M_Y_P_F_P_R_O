﻿/*[config]
<plugin name="腾讯手机管家" group="生活旅游,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/txsjgj.png" app="com.tencent.qqpimsecure" version="5.1.0" description="腾讯手机管家" data="$data,ComplexTreeDataSource"  >
<source>
    <value>data/data/com.tencent.qqpimsecure/databases/qqsecure.db</value>

</source>
<data type="BindAccount" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="帐号" code="account" type="String" width="150" ></item>
</data>
<data type="SecContact" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="名称" code="name" type="String" width="150" ></item>
    <item name="电话" code="phone" type="String" width="150" ></item>
</data>
<data type="SecMessage" datefilter="Date" contract="DataState,Conversion"> 
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item> 
    <item name="发送" code="SenderName" type="string" width = "100"></item>
    <item name="接收" code="recev" type="string" width = "100"></item>
    <item name="电话" code="phone" type="string" width = "300" show="false"></item>
    <item name="内容" code="Content" type="string" width = "300"></item>
    <item name="名称" code="name" type="string" width = "300" show="false"></item>
    <item name="类型1" code="type" type="string" width = "300" show = "false"></item>
    <item name="类型2" code="Type" type="Enum" format="EnumColumnType" width="60" show = "false" ></item>
    <item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
    <item name="时间" code="Date" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="SecFile" datefilter="time" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="原路径" code="sfilepath" type="string" width = "300"></item>
    <item name="现路径" code="dfilepath" type="string" width = "300"></item>
    <item name="文件大小" code="filesize" type="string" width="300"></item>
</data>
<data type="Softsock" datefilter="time" contract = "DataState">   
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="系统名称" code="sysid" type="String" width="300" ></item>
    <item name="名称" code="name" type="String" width="300" ></item>
</data>

</plugin>
[config]*/

// js content

//定义数据结构
function BindAccount() {
    this.account = "";  
    this.DataState = "Normal";  
}
function SecContact() {
    this.name = ""; 
    this.phone = "";  
    this.DataState = "Normal";  
}
function SecMessage() {
    this.SenderName = "";
    this.recev = "";
    this.phone = ""; 
    this.Content = ""; 
    this.name = ""; 
    this.type = ""; 
    this.Date = ""; 
    this.Type = "String"; 
    this.SendState = "Send"; 
    this.DataState = "Normal";  
}

function SecFile() {
    this.sfilepath = "";  
    this.dfilepath = "";  
    this.filesize = "";  
    this.DataState = "Normal";  
}
function Softsock() {
    this.sysid = "";  
    this.name = "";  
    this.DataState = "Normal";  
}

//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}

//获取绑定帐号
function GetBindAccount(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from single_sign_on_table") + ')');
for(var index in data)
{
    var obj=new BindAccount();
    obj.account = data[index].a;  
    //obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取隐私联系人
function GetSecContact(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from secure_contact") + ')');
for(var index in data)
{
    var obj=new SecContact();
    obj.name = data[index].name;  
    obj.phone = data[index].number;
    //obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取隐私短信
function GetSecMessage(path,name)
{
var arr = new Array();
try{
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from secure_sms_log where displayName ='"+name+"'") + ')');
for(var index in data)
{
    var obj=new SecMessage();
    obj.phone = data[index].address;  
    obj.Content = data[index].body;  
    obj.name = data[index].displayName;  
    obj.type = data[index].type;  
    obj.Date = StrToUnix(data[index].date); 
    if(obj.type==2)
    {
        obj.SenderName  = "本机";
        obj.recev = obj.name;
       obj.SendState = "Send"; 
        
    }
    else
    {
        
        obj.SenderName  = obj.name;
        obj.recev = "本机";
       obj.SendState = "Receive"; 
    }
    //obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}
//获取隐私文件
function GetSecFile(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from file_safe_backup_file_info") + ')');
for(var index in data)
{
    var obj=new SecFile();
    obj.sfilepath = data[index].mFileSrcPath;  
    obj.dfilepath = data[index].mFileDstPath;
    obj.filesize = data[index].mFileLength;
    //obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取软件锁
function GetSoftsock(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from software_lock_table") + ')');
for(var index in data)
{
    var obj=new Softsock();
    obj.sysid = data[index].pkg_name;  
    obj.name = data[index].app_name;  
    //obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}


function StrToUnix(str)
{
   
    return XLY.Convert.LinuxToDateTime(str);
    
}


function CreateNode(type,text,dbInfo,root)
{
    var childNode =new TreeNode();
    childNode.Type=type;
    childNode.Text = text;
    if(dbInfo)
    childNode.Items = dbInfo;
    root.push(childNode);
}

function CreateNodeWithChild(root,type,text,dbInfo,childType,childText,childDB)
{
    var Node =new TreeNode();
    Node.Type=type;
    Node.Text=text;
    if(dbInfo)
    Node.Items = dbInfo;
    for(var i in childType)
    {
    var childNode =new TreeNode();
    childNode.Type=childType[i];
    childNode.Text =childText[i];
    if(childDB[i])
    childNode.Items = childDB[i];
    Node.TreeNodes.push(childNode);
    }
    root.push(Node);
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0];
var childText = new Array(); 
var childType = new Array(); 
var childDB = new Array();
//--------------------------------------------------------------------以下为多节点构造（隐私联系人）
var data = eval('(' + XLY.Sqlite.Find(path1, "select * from secure_contact") + ')');
for(var index in data)
{
    childText.push(data[index].name);
    childType.push("SecMessage");
    childDB.push(GetSecMessage(path1,data[index].name));
}
CreateNodeWithChild(result,"SecContact","隐私联系人",GetSecContact(path1),childType,childText,childDB);

//--------------------------------------------------------------------以下为单节点构造（隐私文件，绑定帐号，软件锁）
CreateNode("SecFile","隐私文件",GetSecFile(path1),result);
CreateNode("BindAccount","绑定帐号",GetBindAccount(path1),result);
CreateNode("Softsock","软件锁",GetSoftsock(path1),result);

var res = JSON.stringify(result);
res;
