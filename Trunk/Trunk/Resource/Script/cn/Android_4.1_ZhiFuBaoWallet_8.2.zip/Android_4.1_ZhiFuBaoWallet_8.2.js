﻿/*[config]
<plugin name="支付宝,6" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\ZhiFuBaoWallet.png" app="com.eg.android.AlipayGphone" version="8.1" description="支付宝钱包" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.eg.android.AlipayGphone/shared_prefs/#F</value>
    <value>/data/data/com.eg.android.AlipayGphone/databases/#F</value>
</source>
<data type = "Account">
    <item name="登录帐号" code="Name" type="string" width="" ></item>
    <item name="帐号id" code="ID" type="string" width="" ></item>
    <item name="帐号钱包id" code="WalletID" type="string" width=""></item>
</data>

<data type = "Position" contract="Map">
    <item name="地点描述" code="Desc" type="string" width = "" ></item>
    <item name="时间" code="Date" type="datetime" width="" ></item>
    <item name="经度" code="Longitude" type="double" format="F6" width="" ></item>
    <item name="维度" code="Latitude" type="double" format="F4"  width="" ></item>
</data>

<data type="PaymentRecords" datefilter="Date" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="支付类型" code="Type" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="支出帐号" code="OutAccount" type="string" width="120" ></item>
    <item name="收入帐号" code="InAccount" type="string"  show="true" width="120" ></item>
    <item name="支付金额" code="Amount" type="string" width="150" ></item>
    <item name="支付明细" code="Remark" type="string" width="200" format = ""></item>
    <item name="用户ID" code="UserID" type="string" width="200" format = ""></item>
    <item name="支付时间" code="Date" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
    <item name="支付创建时间" code="CreateDate" type="datetime" format = "yyyy-MM-dd HH:mm:ss" width="140"></item>
</data>

</plugin>
[config]*/

// js content

//定义Account数据结构
function Account() {
    this.Name = "";
    this.ID = "";
    this.WalletID = "";
}

//定义Position数据结构
function Position() {
    this.Desc = "";
    this.Longitude = 0;
    this.Latitude = 0;
    this.Date = null;
}

//定义PaymentRecords数据结构
function PaymentRecords() {
    this.Type = "";
    this.OutAccount = "";
    this.InAccount = "";
    this.Amount = "";
    this.Remark = "";
    this.UserID = "";
    this.DataState = "Normal";
    this.Date = null;
    this.CreateDate = null;
}


//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//创建树结构
function createTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

//创建根节点
function bindTree(){

    var rootTree = createTreeNode("支付宝钱包","");
    buildChildTree(rootTree);
    return rootTree
}

//创建根节点的子节点
function buildChildTree(root){
    //创建历史帐号树
    var historyAccount = createTreeNode("历史帐号","Account");
    historyAccount.Items.push(getAccountInfo());
    root.TreeNodes.push(historyAccount);
    
    //创建地理位置悉信息
    var position = createTreeNode("最近定位","Position");
    position.Items.push(getPositionInfo());
    root.TreeNodes.push(position);
    
    //支付流水
    var payRecord = createTreeNode("支付流水","PaymentRecords");
    var recoveryPath = XLY.Sqlite.DataRecovery(tallyPath,charactor,"accountinfo,systemcategory,tallyflow");
    payRecord.Items = getPaymentRecordsInfo(recoveryPath);
    root.TreeNodes.push(payRecord);
}

//获取历史帐号树的信息
function getAccountInfo(){
    var data = eval('('+ XLY.File.ReadXML(path+"\\secuitySharedDataStore.xml") +')');
    var info = data.map.string;
    var obj = new Account();
    obj.ID=getTargetInfoInXML(info,"currentUserId");
    obj.Name=getTargetInfoInXML(info,"currentLogonId");
    obj.WalletID=getTargetInfoInXML(info,"walletTid")
    return obj;
}

function getPositionInfo() {
    var data = eval('(' + XLY.File.ReadXML(path + "\\last_know_location.xml") + ')');
    var info = data.map.string;
    var time = data.map.long;
    var obj = new Position ();
    obj.Date=XLY.Convert.LinuxToDateTime(time['@value']);
    obj.Desc=getTargetInfoInXML(info,"province")+getTargetInfoInXML(info,"city")+getTargetInfoInXML(info,"district");
    obj.Latitude=getTargetInfoInXML(info,"last_know_lat");
    obj.Longitude=getTargetInfoInXML(info,"last_know_lng");
    return obj;
}

//获取目标节点的value/text
function getTargetInfoInXML(data,target){
    for(var index in data){
        if(data[index]['@name']==target){
            return data[index]['#text'];
        }
    }
}

//处理用户支付信息
function getPaymentRecordsInfo(path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from tallyflow") +')');
    var info = new Array();
    for(var index in data){
        var obj = new PaymentRecords();
        
        //获取支付类型
        var typedata = getColumnInfo(path,"systemcategory",data[index].categoryUuid);
        if(typedata != null){
            obj.Type = typedata[0].name;
        }
        
        //获取支出信息
        var outdata = getColumnInfo(path,"accountinfo",data[index].outAccountUuid);
        if(outdata != null){
            obj.OutAccount = outdata[0].name+","+outdata[0].subName;
        }
        
        //获取收入信息
        if(data[index].inAccountUuidta != ""){
            var indata = getColumnInfo(path,"accountinfo",data[index].inAccountUuid);
            if(indata != null){
                obj.InAccount = indata[0].name+","+indata[0].subName;
            }
        }
        obj.Amount = data[index].amount;
        obj.Remark = data[index].remark;
        obj.UserID = data[index].userId;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].gmtDate);
        obj.CreateDate = XLY.Convert.LinuxToDateTime(data[index].gmtCreate);
        info.push(obj);
    }
    return info;
}

//获取特定列的详细信息
function getColumnInfo(path,table,column){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from '"+table+"' where uuid = '"+column+"'") +')');
    if(data.length>0){
        return data;
    }
}

var result = new Array();

//源文件
var source = $source;
var path = source[0];
var tallyPath = source[1]
//var path = "C:\\Users\\Administrator\\Desktop\\111\\data\\com.eg.android.AlipayGphone\\shared_prefs";
//var tallyPath = "C:\\Users\\Administrator\\Desktop\\111\\data\\com.eg.android.AlipayGphone\\databases\\alipayclient_tally.db";
var charactor = "\\chalib\\Android_4.1_ZhiFuBaoWallet_8.2\\alipayclient_tally.db.charactor";
result.push(bindTree());
// return
var res = JSON.stringify(result);
res;
