﻿/*[config]
<plugin name="Uber,10" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Uber.png" app="com.didi.echo" version="4.8.5" description="Uber" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.didi.echo/shared_prefs/#F</value>
</source>
<data type="Info" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="所在城市" code="City" type="string" width = "120" ></item>
<item name="公司" code="Company" type="string" width = "120" ></item>
<item name="公司地址" code="CAddr" type="string" width = "120" ></item>
<item name="公司经纬度" code="Clatlng" type="string" width="120" ></item>
<item name="家" code="Home" type="string" width="60" format = ""></item>
<item name="家地址" code="HAddr" type="string" width="60" format = ""></item>
<item name="家经纬度" code="Hlatlng" type="string" width="120" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Info() {
    this.ID = "";
    this.DataState = "Normal";
}
function Account() {
    this.ID = "";
    this.City = "";
    this.Company = "";
    this.CAddr = "";
    this.Clatlng = "";
    this.Home = "";
    this.HAddr = "";
    this.Hlatlng = "";
    this.DataState = "Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "Uber";
    news.Type = "Account";
    accountinfo = getAccount(db1);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    var info = new TreeNode() ;
    info.Text = "最后登录帐号";
    info.Type = "Info";
    info.Items = getInfo(db);
    news.TreeNodes.push(info);
     
    
    for(var i in accountinfo){
    }
     result.push(news);
} 
 function getInfo (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');  
     var obj = new Info();   
     var info = data.map.string;
     for(var i in info){
         var obj = new Info();
         if(info[i]['@name']== "id"){
             obj.ID = info[i]["#text"];
         }
          list.push(obj);   
     }
     
    
    return list;
 }
 
 function getAccount (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');     
     var info = data.map.string;
     
     for(var i in info){
         var obj = new Account();
         if(/^company/.test(info[i]['@name'])){
             var info1 = info[i]['@name'].substring(7,info[i]['@name'].length);
             //log(info1);
            obj.ID = info1;
           if(info[i]['@name'] == "company"+info1){
               var accinfo = eval('('+ info[i]["#text"] +')');
               //log(accinfo.displayname);
               obj.Company = accinfo.displayname;
               obj.City = accinfo.city;
               obj.CAddr = accinfo.address;
               obj.Clatlng = accinfo.lng+";"+accinfo.lat;
           }  
           
            list.push(obj);
         }
        if(/^home/.test(info[i]['@name'])){
           var info2 = info[i]['@name'].substring(4,info[i]['@name'].length);
           if(info[i]['@name'] == "home"+info2){
               var accinfo1 = eval('('+ info[i]["#text"] +')');
               log(accinfo1);
               obj.Home = accinfo1.displayname;
               obj.HAddr = accinfo1.address;
               obj.Hlatlng = accinfo1.lng+";"+accinfo1.lat;
           }       
          list.push(obj);
        } 
     } 
    return list;
 }

 //********************************************************
var source = $source;
var db= source[0]+"\\trace_sdk_pref.xml";
var db1= source[0]+"\\sug.xml"; 
//
//var db = "D:\\temp\\data\\data\\com.didi.echo\\shared_prefs\\trace_sdk_pref.xml";
//var db1 = "D:\\temp\\data\\data\\com.didi.echo\\shared_prefs\\sug.xml";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
