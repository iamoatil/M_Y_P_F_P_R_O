﻿/*[config]
<plugin name="58同城,9" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/58.png" app="com.wuba" version="7.6.1" description="58同城" data="$data,ComplexTreeDataSource"  >
<source>
<value>data/data/com.wuba/databases/login_user.db</value>
<value>data/data/com.wuba/shared_prefs/com.wuba.def_sp_file.xml</value>
<value>data/data/com.wuba/shared_prefs/wuba_shareParams.xml</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="登录时间" code="Time" type="string" width="120" ></item>
<item name="电话" code="Phone" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
</data>
<data type="Contact" contract="Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
</data>
<data type="Search" contract="Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="关键字" code="Key" type="string" width = "120" ></item>
</data>
<data type="House" contract="Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="关键字" code="Key" type="string" width = "120" ></item>
<item name="经度" code="Lon" type="string" width = "120" ></item>
<item name="纬度" code="Lat" type="string" width = "120" ></item>
</data>
<data type="Contact" contract="Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
</data>
<data type="Message" contract="Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者ID" code="SenderID" type="string" width = "120" ></item>
<item name="接收者ID" code="ReceiverID" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="阅读状态" code="Status" type="string" width = "120" ></item>
</data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function UserInfo() {
    this.Name = "";  
    this.ID = "";  
    this.Time = "";  
    this.Phone = "";  
    this.Avatar = "";  
    this.DataState = "Normal";
}
function Contact() {
    this.Name = "";  
    this.ID = "";   
    this.Avatar = "";  
    this.DataState = "Normal";
}
function Search() {
    this.Key = "";  
    this.DataState = "Normal";
}
function House() {
    this.Key = "";
    this.Lat = "";
    this.Lon = "";  
    this.DataState = "Normal";
}
function Contact() {
    this.Name = "";  
    this.ID = "";   
    this.Avatar = "";  
    this.DataState = "Normal";
}
function Message() {
    this.Sender = "";  
    this.Receiver = "";   
    this.SenderID = ""; 
    this.ReceiverID = "";  
    this.Content = "";   
    this.Time = "";  
    this.Status = ""; 
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "58同城";
    news.Type = "UserInfo"; 
    accountinfo = getUserInfo(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    var acc = new TreeNode();
    acc.Text = "账号信息";
    acc.Type = "UserInfo";
    var accountinfo = getUserInfo(db);
    acc.Items =  accountinfo;
    
    acc.DataState = "Normal";
    news.TreeNodes.push(acc);
    
    var search = new TreeNode();
    search.Type = "Search";
    search.Text = "搜索记录";
    search.Items = getSearch(db1);
    news.TreeNodes.push(search);
    
     var house = new TreeNode();
     house.Type = "House";
     house.Text = "搜索租房信息";
     house.Items = getHouse(db2);
     news.TreeNodes.push(house);
    
    for(var i in accountinfo ){
         var UserNode =new TreeNode();
         UserNode.Type="UserInfo";
         UserNode.Text = accountinfo[i].Name;
         UserNode.Items = getUserInfo(db);  
         news.TreeNodes.push(UserNode);
         
         
           var contact = new TreeNode();
          contact.Type = "Contact";
          contact.Text = "联系人";
          var contactinfo  = getContact(accPath);
          contact.Items = contactinfo;
          UserNode.TreeNodes.push(contact);
          
          var msg = new TreeNode();
          msg.Type = "Message";
          msg.Text = "消息";
          msg.Items = getMessage(accPath,accountinfo[i],contactinfo);
          UserNode.TreeNodes.push(msg);   
    }    
    result.push(news)
}
     var accPath1 = "D:\\temp\\data\\data\\com.wuba\\cache\\gmacs\\app\\users";
         var accPath2 = eval('('+ XLY.File.FindDirectories(accPath1) +')');
         for(var j in accPath2 ){
            RegExp = /[1-9]\d*_2$/;
            a = accPath2[j].match(RegExp);
            if(a != null && accPath2[j].length<70){
                var accPath = accPath2[j] + "\\dataNew\\data.db";
                 
            }  
         }
function getUserInfo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from user") +')');
    for(var i in data){
        var obj = new UserInfo();
        obj.ID = data[i].user_id;
        obj.Name = data[i].user_name;
        obj.Avatar = data[i].head_url;
        obj.Phone = data[i].remember_un;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].cur_time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);        
    }
    return list
}

function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var info = data.map.string;    
    for(var j in info ){        
        if(info[j]["@name"] == "SearchMainHistoryBean"){        
            var info1 = eval('('+ info[j]["#text"] +')');
            for(var k = 0; k<info1.histroys.length ;k++){
                var obj = new Search();
                obj.Key = info1.histroys[k].c;
                list.push(obj);
            }             
        }       
    }
    return list;
}
function getHouse(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var info = data.map.string;
    var obj = new House();  
    for(var i in info){
        
        if(info[i]["@name"] == "house"){
            obj.Key = info[i]["#text"];
        }
        if(info[i]["@name"] == "lat"){
            obj.Lat = info[i]["#text"];
        }
        if(info[i]["@name"] == "lon"){
            obj.Lon = info[i]["#text"];
        }      
    }
    list.push(obj);
    return list;
}
function getContact(path){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path,"select * from user")+ ')');    
    for(var i in data){
        var obj = new Contact();
        obj.ID = data[i].user_id;
        obj.Name = data[i].user_name;
        obj.Avatar = data[i].avatar;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);        
    }
    return list
} 
function getMessage(path,accountinfo,contactinfo){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path,"select * from message")+ ')');    
    for(var i in data){
        var obj = new Message();
        obj.SenderID = data[i].sender_id;
        obj.ReceiverID = data[i].to_id;
        var a = eval('('+ data[i].content +')');;
        obj.Content = a.msg;
        obj.Time = data[i].create_time;
        obj.Status = (data[i].read_status) ? "已读" : "未读";
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);        
    }
    return list
} 
//********************************************************
var source = $source;
var db3 = source[0];
var db1 = source[1];
var db2 = source[2];

var charactor = "\\chalib\\IOS_NeteaseMail_V4.15.2\\login_user.db.charactor";

//var db3 = "D:\\temp\\data\\data\\com.wuba\\databases\\login_user.db";
//var db1 = "D:\\temp\\data\\data\\com.wuba\\shared_prefs\\com.wuba.def_sp_file.xml";
//var db2 = "D:\\temp\\data\\data\\com.wuba\\shared_prefs\\wuba_shareParams.xml";
//
//var charactor = "D:\\temp\\data\\data\\com.wuba\\databases\\login_user.db.charactor";
//var charactor1 = "D:\\temp\\data\\data\\com.wuba\\databases\\data.db.charactor";

var db = XLY.Sqlite.DataRecovery(db3,charactor ,"user");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
