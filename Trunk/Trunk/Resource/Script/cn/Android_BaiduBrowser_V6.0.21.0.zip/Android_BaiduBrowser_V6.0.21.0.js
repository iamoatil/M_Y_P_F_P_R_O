﻿/*[config]
<plugin name="百度浏览器" group="Web痕迹,7" devicetype="android" icon="\icons\baidubrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.baidu.browser.apps" version="6.0.21.0" description="百度浏览器" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.baidu.browser.apps/databases/dbbrowser.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="MainPage" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="搜索关键字" code="Word" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function MainPage() {
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Time = "";
}
function Search() {
    this.DataState = "Normal";
    this.Word = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}

//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}

function bindTree() {
    newTreeNode("主页信息", "MainPage", getMainPage(db));
    newTreeNode("搜索", "Search", getSearch(db));
    newTreeNode("浏览记录", "History", getHistory(db));
    newTreeNode("书签", "Bookmark", getBookmark(db));
}
function getNews() {
    var list = new Array();
    data = ["主页信息", "搜索", "浏览记录", "书签"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getMainPage(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from mainpage") + ')');
    for (var i in data) {
        var obj = new MainPage();
        obj.Name = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from url_input_record") + ')');
    for (var i in data) {
        var obj = new Search();
        obj.Word = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmark") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
//db="D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\dbbrowser.db";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
