﻿/*[config]
<plugin name="FlyVpn,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/flyvpn.png" app="com.fvcorp.flyclient" version="3.7.3.5" description="FlyVpn" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.fvcorp.flyclient/shared_prefs#F</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "120"></item>
    <item name="最后一个用户名" code="LastUserName" type="string" width = "120"></item>
    <item name="当前所选服务器id" code="SelectedServerId" type="string" width = "80"></item>
    <item name="最初链接时间" code="FirstConnectionTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后链接时间" code="LastConnectionTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="最近使用服务器id" code="RecentServerIds" type="string" width="150"></item>
    <item name="最后使用版本代码" code="lastVersionCodeUsed" type="string" width="100"></item>
    <item name="自定义DNS" code="CustomDns" type="string" width="150"></item>
</data>
<data type="MakeComplaints" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width = "150"></item>
    <item name="创建时间" code="CreateDate" type="string" width="100"></item>
    <item name="标题" code="Title" type="string" width="120"></item>
    <item name="已读" code="IsRead" type="string" width="80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.LastUserName = "";
    this.SelectedServerId = "";
    this.FirstConnectionTime = null;
    this.LastConnectionTime = null;
    this.RecentServerIds = "";
    this.lastVersionCodeUsed = "";
    this.CustomDns = "";
}
function MakeComplaints(){
    this.DataState = "Normal";
    this.ID = "";
    this.CreateDate = "";
    this.Title = "";
    this.IsRead = "否";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];

//测试数据
//var allPath = "D:\\temp\\data\\data\\com.fvcorp.flyclient\\shared_prefs";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "FlyVpn";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var userPath = allPath +"\\PrefCommon.xml";
    if(XLY.File.IsValid(userPath)){
        var userdata = eval('('+ XLY.File.ReadXML(userPath) +')');
        if(userdata!=""&&userdata!=null){
            var aa = userdata.map.string;
            if(aa!=""&&aa!= null){
                var obj = new UserInfo();
                
                for(var i in aa){
                    if(aa[i]["@name"]=="UserName"){
                        obj.UserName = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="LastUserName"){
                        obj.LastUserName = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="SelectedServerId"){
                        obj.SelectedServerId = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="FirstConnectionTime"){
                        obj.FirstConnectionTime = XLY.Convert.LinuxToDateTime(aa[i]["#text"]);
                    }
                    if(aa[i]["@name"]=="LastConnectionTime"){
                        obj.LastConnectionTime = XLY.Convert.LinuxToDateTime(aa[i]["#text"]);
                    }
                }
                var bbPath = allPath +"\\UserServerStorage.xml";
                if(XLY.File.IsValid(bbPath)){
                    var bb = eval('('+ XLY.File.ReadXML(bbPath) +')');
                    if(bb!=""&&bb!=null){
                        var cc = bb.map.string;
                        if(cc["@name"]=="RecentServerIds"){
                            obj.RecentServerIds = cc["#text"];
                        }
                    }
                }
                var ddPath = allPath+"\\Config.sp.xml";
                if(XLY.File.IsValid(ddPath)){
                    var dd = eval('('+ XLY.File.ReadXML(ddPath) +')');
                    if(dd!=""&&dd!=null){
                        var ee = dd.map.string;
                        if(ee["@name"]=="CustomDns"){
                            obj.CustomDns = ee["#text"];
                        }
                    }
                }
                var ffPath = allPath+"\\WebViewChromiumPrefs.xml";
                if(XLY.File.IsValid(ffPath)){
                    var ff = eval('('+ XLY.File.ReadXML(ffPath) +')');
                    if(ff!=""&&ff!=null){
                        var gg = ff.map.int;
                        if(gg["@name"]=="lastVersionCodeUsed"){
                            obj.lastVersionCodeUsed = gg["@value"];
                        }
                    }
                }
                var userNode = new TreeNode();
                userNode.Text = obj.LastUserName;
                userNode.Type = "UserInfo";
                getUserInfo(userNode);
                userNode.Items.push(obj);
                if(userNode.Items!=""&&userNode.Items!=null){
                    root.TreeNodes.push(userNode);
                }
            }
        }
    }
}
function getUserInfo(root){
    var servePath = allPath+"\\FVService.xml";
    if(XLY.File.IsValid(servePath)){
        var dataServe = eval('('+ XLY.File.ReadXML(servePath) +')');
        if(dataServe!=""&&dataServe!=null){
            var node = new TreeNode();
            node.Text = "有待测试。。。。。";
            //root.TreeNodes.push(node);
        }
    }
}