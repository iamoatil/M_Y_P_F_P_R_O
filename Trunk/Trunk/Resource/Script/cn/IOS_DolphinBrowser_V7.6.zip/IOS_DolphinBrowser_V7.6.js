﻿/*[config]
<plugin name="海豚浏览器,4" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\DolphinBrowser.png" app="com.dolphin.browser.iphone.chinese" version="7.6" description="海豚浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>com.dolphin.browser.iphone.chinese</value>
</source>
<data type="Address"  datefilter="Time" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="URL" width="500" format=""></item>
<item name="访问时间" code="Time" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Counts" type="string" width="100" format=""></item>
</data>
<data type="Speeddial" datefilter="Time" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="100" format=""></item>
<item name="URL地址" code="Url" type="URL" width="500" format=""></item>
<item name="访问时间" code="Time" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Bookmark" datefilter="Created" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="100" format=""></item>
<item name="URL地址" code="Url" type="URL" width="500" format=""></item>
<item name="创建时间" code="Created" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="修改时间" code="Modified" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Address() {
	this.Time = null;
	this.Title = "";
	this.Url = "";
	this.Counts = "";
	this.DataState = "Normal";
}

function Speeddial() {
	this.Time = null;
	this.Title = "";
	this.Url = "";
	this.DataState = "Normal";
}

function Bookmark() {
	this.Time = null;
	this.Title = "";
	this.Url = "";
	this.Created = "";
	this.Modified = "";
	this.DataState = "Normal";
}
//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}

//获取历史浏览地址信息
function getAddress(path, sql) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
		var arr = new Array();
		for (var index in data) {
			var list = new Address();
			list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
			list.Title = data[index].title;
			list.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].created));
			list.Url = XLY.Convert.UrlDecode(data[index].url);
			list.Counts = data[index].visits;
			arr.push(list);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//获取快速链接信息
function getSpeeddial(path, sql) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
		for (var index in data) {
			var list = new Speeddial();
			list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
			list.Title = data[index].title;
			list.Url = XLY.Convert.UrlDecode(data[index].url);
			list.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].created));
			arr.push(list);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//获取书签信息
function getBookmark(path, sql) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
		for (var index in data) {
			var list = new Bookmark();
			list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
			list.Title = data[index].title;
			list.Url = XLY.Convert.UrlDecode(data[index].url);
			list.Created = XLY.Convert.LinuxToDateTime(parseInt(data[index].created));
			list.Modified = XLY.Convert.LinuxToDateTime(parseInt(data[index].modified));
			arr.push(list);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();
//源文件
var source = $source
var datapath=source[0]+"\\com.dolphin.browser.iphone.chinese\\Library\\dolphin.db";

//数据恢复库的生成
var charactor="chalib\\IOS_DolphinBrowser_V7.6\\dolphin.db.charactor";
datapath=XLY.Sqlite.DataRecovery( datapath,charactor,"histories,speeddials,bookmarks");

//节点实例化
var hissql = "select title,url,created,visits,XLY_DataType from histories";
var history = new TreeNode();
history.Text = "历史搜索";
history.Type = "Address";
var hisinfo = getAddress(datapath, hissql);
history.Items = hisinfo;
var spsql = "select title,url,created,XLY_DataType from speeddials";
var speeddial = new TreeNode();
speeddial.Text = "快速链接";
speeddial.Type = "Speeddial";
var spinfo = getSpeeddial(datapath, spsql);
speeddial.Items = spinfo;
var bksql = "select title,url,created,modified,XLY_DataType from bookmarks";
var bookmark = new TreeNode();
bookmark.Text = "书签";
bookmark.Type = "Bookmark";
var bkinfo = getBookmark(datapath, bksql);
bookmark.Items = bkinfo;

//打印数据
result.push(history);
result.push(speeddial);
result.push(bookmark);
var res = JSON.stringify(result);
res;
