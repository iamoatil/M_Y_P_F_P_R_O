﻿/*[config]
<plugin name="instagram,6" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/Instagram.png" app="com.oupeng.mini.android" version="12.2.0.11" description="instagram" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.instagram.android/shared_prefs#F</value>
    <value>/data/data/com.instagram.android/cache/direct_thread_store#F</value>
    <value>/data/data/com.instagram.android/app_webview#F</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="List" type="string" width = "150"></item>
    <item name="Version" code="Version" type="string" width = "150"></item>
</data>
<data type="UserInfoNode"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="姓名" code="FullName" type="string" width="200" format = "" ></item>
    <item name="账号" code="UserName" type="string" width="200" format = "" ></item>
    <item name="网站" code="UserUrl" type="url" width="200" format=""></item>
    <item name="个人简介" code="Biography"  type="string" width="200" format = "" ></item>
    <item name="粉丝人数" code="FollowerCout" type="string" width="200" format = "" ></item>
    <item name="关注人数" code="FollowingCout" type="string" width="200" format = "" ></item>
    <item name="媒体计数" code="MediaCount" type="string" width="200" format = "" ></item>
    <item name="头像链接" code="ProfilePicUrl" type="string" width="200" format = "" ></item>
    <item name="访问时间" code="AccessedTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="是否验证" code="IsVerified" type="string" width="100" format="" ></item>
    <item name="是否当前登录" code="IsCurrent" type="string" width="100" format="" ></item>
</data>
<data type="FriendInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="300" format = ""></item>
    <item name="姓名" code="FullName" type="url" width="200" format = ""></item>
    <item name="账号" code="UserName" type="string" width="300" format = ""></item>
    <item name="头像链接" code="ProfiePicUrl" type="string" width="300" format = ""></item>
</data>
<data type="Group" contract="DataState" datefilter="Created" detailfield = "Member">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="150" format = ""></item>
    <item name="名称" code="DisplayName" type="string" width="100" format="" ></item>
    <item name="成员" code="Member" type="string" width="300" format = ""></item>
</data>
<data type="Message" contract="DataState" datefilter = "Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ThreadID" type="string" width="200" format=""></item>
    <item name="发送者名称" code="SenderName" type="string" width="100" format = ""></item>
    <item name="发送者ID" code="SenderID" type="string" width="100" format = ""></item>
    <item name="接收者名称" code="RecName" type="string" width="100" format = ""></item>
    <item name="接收者ID" code="RecID" type="string" width="100" format = ""></item>
    <item name="消息" code="MessageInfo"  type="string" width="150" format=""></item>
    <item name="消息类型" code="MessageType"  type="string" width="150" format=""></item>
    <item name="发送时间" code="SendTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Cookies" contract="DataState" datefilter="LastTime">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="Name" code="Name" type="string" width="200" format=""></item>
    <item name="Key" code="Host_Key" type="string" width="160" format=""></item>
    <item name="Value" code="CookieValue" type="string" width="400" format=""></item>
    <item name="创建时间" code="CreateTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="过期时间" code="ExpireTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后认证时间" code="LastTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="存放路径" code="Path" type="string" width="200" format = ""></item>
</data>
<data type="SearchUser" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="200" format = ""></item>
    <item name="粉丝人数" code="FollowerCount" type="string" width="200" format = ""></item>
    <item name="关注人数" code="FollowingCount" type="string" width="200" format = ""></item>
    <item name="姓名" code="FullName" type="string" width="200" format = ""></item>
    <item name="头像" code="ProfilePicUrl" type="string" width="200" format = ""></item>
    <item name="用户名" code="UserName" type="string" width="200" format = ""></item>
</data>
<data type="SearchPlace" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="200" format = ""></item>
    <item name="地址" code="Address" type="string" width="200" format = ""></item>
    <item name="经纬度" code="LatLng" type="string" width="200" format = ""></item>
</data>
<data type="SearchHash" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="200" format = ""></item>
    <item name="多媒体计数" code="MediaCount" type="string" width="200" format = ""></item>
    <item name="ID" code="Id" type="string" width="200" format = ""></item>
</data>
<data type="Search" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="分类" code="Name" type="string" width="200" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
    this.Version = "";
}

function SearchUser(){
    this.DataState = "Normal";
    this.Id = "";
    this.FollowerCount = "";
    this.FollowingCount = "";
    this.FullName = "";
    this.ProfilePicUrl = "";
    this.UserName = "";
}
function SearchPlace(){
    this.DataState = "Normal";
    this.Name = "";
    this.Address = "";
    this.LatLng = "";
}
function SearchHash(){
    this.DataState = "Normal";
    this.Name = "";
    this.MediaCount = "";
    this.Id = "";
}
function UserInfoNode(){
    this.DataState = "Normal";
    this.UserName = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.FullName = "";
    this.UserName = "";
    this.UserUrl = "";
    this.Biography = "";
    this.FollowerCout = "";
    this.FollowingCout = "";
    this.MediaCount = "";
    this.ProfilePicUrl = "";
    this.AccessedTime = null;
    this.IsVerified = "";
    this.IsCurrent = "";
}
//定义Group数据结构
function Group(){
    this.DataState = "Normal";
    this.ID = "";
    this.DisplayName = "";
    this.Member = "";
}
//定义Bookmark数据结构
function FriendInfo(){
    this.DataState = "Normal";
    this.ID = "";
    this.FullName = "";
    this.UserName = "";
    this.ProfiePicUrl = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.ThreadID = "";
    this.SenderName = "";
    this.SenderID = "";
    this.MessageInfo = "";
    this.MessageType = "";
    this.SendTime = null;
    this.RecName = "";
    this.RecID = "";
}
//定义Cookies数据结构
function Cookies(){
    this.DataState = "Normal";
    this.Name = "";
    this.Host_Key = "";
    this.CookieValue = "";
    this.CreateTime = null;
    this.ExpireTime = null;
    this.LastTime = null;
    this.Path = "";
}
//定义SearchWord数据结构
function Search(){
    this.DataState = "Normal";
    this.Name = "";
}
//定义SavePage数据结构
function SavePage(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.CreateTime = null;
    this.UUID = "";
    this.FileName = "";
    this.FileSize = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath = source[0]+"\\com.instagram.android_preferences.xml";
var messagePath = source[1]+"\\direct_thread_store.clean";
var cookiesPath1 = source[2]+"\\Cookies";

var charactor = "\\chalib\\Android_Instagram_V10.3.2\\Cookies.charactor";
//var charactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Instagram_V10.3.2\\Cookies.charactor";


//测试数据
//var userPath = "F:\\temp3\\data\\data\\com.instagram.android\\shared_prefs\\com.instagram.android_preferences.xml";
//var messagePath = "F:\\temp3\\data\\data\\com.instagram.android\\cache\\direct_thread_store\\direct_thread_store.clean";
//var searchPath = "F:\\temp3\\data\\data\\com.instagram.android\\shared_prefs\\4368308013_USER_PREFERENCES.xml";
//var cookiesPath1 = "F:\\temp3\\data\\data\\com.instagram.android\\app_webview\\Cookies";

var cookiesPath = XLY.Sqlite.DataRecovery(cookiesPath1,charactor,"cookies");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "instagram";
    news.Type = "News";
    news.Items = getNews();

    var data = eval('('+ XLY.File.ReadXML(userPath) +')');
    var data1 = data.map.string;
    for(var j in data1){
        if(data1[j]["@name"]=="current"){
            var a = eval('('+ data1[j]["#text"] +')');
            var mm = a.id;
        }
    }
    var searchPath = source[0]+"\\"+mm+"_USER_PREFERENCES.xml";
    var userNode = new TreeNode();
    userNode.Text = "账户信息";
    userNode.Type = "UserInfoNode";
    userNode.Items = getUserInfoNode(userNode,userPath);
    
    var searchNode = new TreeNode();
    searchNode.Text = "搜索关键字";
    searchNode.Type = "Search";
    searchNode.Items = getSearch(searchPath,searchNode);
    
    var messageNode = new TreeNode();
    messageNode.Text = "会话";
    messageNode.Type = "Group";
    messageNode.Items = getMessageNode(messagePath,messageNode);
    
    
    var cookiesNode = new TreeNode();
    cookiesNode.Text = "Cookies";
    cookiesNode.Type = "Cookies";
    cookiesNode.Items = getCookies(cookiesPath);

    news.TreeNodes.push(userNode);
    news.TreeNodes.push(searchNode);
    news.TreeNodes.push(messageNode);
    news.TreeNodes.push(cookiesNode);
    result.push(news);
}

//获取数据库
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}

//获取功能列表
function getNews(){
    var list = new Array();
    var obj = new News();
    obj.List = "instagram";
    obj.Version = "10.3.2";
    list.push(obj);
    return list;
}

//获取账户信息
function getUserInfoNode(root,path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var data = eval('('+ XLY.File.ReadXML(path) +')');
        var data1 = data.map.string;
        for(var j in data1){
            if(data1[j]["@name"]=="current"){
                var a = eval('('+ data1[j]["#text"] +')');
                var mm = a.full_name;
            }
        }
        for(var i in data1){
            if(data1[i]["@name"]=="user_access_map"){
                var data2 = eval('('+ data1[i]["#text"] +')');
                for(var m in data2){
                    var obj = new UserInfoNode();
                    obj.UserName = data2[m].user_info.username;
                    list.push(obj);
                    var node = new TreeNode();
                    node.Text = data2[m].user_info.username;
                    node.Type = "UserInfo";
                    node.Items.push(getUserInfo(data2[m],mm));
                    root.TreeNodes.push(node);
                }
            }
        }
        return list;
    }
}

function getUserInfo(data,mm){
    if(data!=""&&data!=null){
        var obj = new UserInfo();
        obj.FullName = data.user_info.full_name;
        obj.UserName = data.user_info.username;
        obj.UserUrl = data.user_info.external_url;
        obj.Biography = data.user_info.biography;
        obj.FollowerCout = data.user_info.follower_count;
        obj.FollowingCout = data.user_info.following_count;
        obj.MediaCount = data.user_info.media_count;
        obj.ProfilePicUrl = data.user_info.profile_pic_url;
        obj.AccessedTime = XLY.Convert.LinuxToDateTime(data.time_accessed);
        if(data.user_info.is_verified="false"){
            obj.IsVerified = "否";
        }
        else
        {
            obj.IsVerified = "是";
        }
        
        if(mm!=""&&mm!=null){
            if(data.user_info.full_name==mm){
                obj.IsCurrent = "是";
            }
            else
            {
                obj.IsCurrent = "否";
            }
        }
        else
        {
            obj.IsCurrent = "不能确定";
        }
        
        return obj;
    }
}
//获取消息内容
function getMessageNode(path,root){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.File.ReadFile(path) +')').entries;
        if(data!=""&&data!=null){
            for(var i in data){
                var node = new TreeNode();
                node.Text = data[i].thread_title;
                node.Type = "Message";
                node.Items = getMessageInfo(data[i]);
                root.TreeNodes.push(node);
                
                var obj = new Group();
                obj.Id = data[i].thread_id;
                obj.DisplayName = data[i].thread_title;
                if(data[i].recipients!=""&&data[i].recipients!= null)
                {
                    for(var j in data[i].recipients){
                        if(data[i].recipients.length==1)
                        {
                            obj.Member += "ID:"+data[i].recipients[j].user_id+"\r"+"账户名："+data[i].recipients[j].username+"\r"+"姓名："+data[i].recipients[j].full_name+"\r"+"头像链接："+data[i].recipients[j].profilepic_url+"\r";
                        }
                        else
                        {
                            obj.Member += j+":\r"+"ID:"+data[i].recipients[j].user_id+"\r"+"账户名："+data[i].recipients[j].username+"\r"+"姓名："+data[i].recipients[j].full_name+"\r"+"头像链接："+data[i].recipients[j].profilepic_url+"\r";
                        }
                    }
                }
                arr.push(obj);
            }
        }
        return arr;
    }
}

//获取书签信息
function getMessageInfo(data1){
    if(data1!=""&&data1!= null){
        var arr = new Array();
        var data = data1.cached_messages;
        for(var i in data){
            var obj = new Message();
            obj.ThreadID = data[i].thread_key.thread_id;
            if(data[i].content_type=="ACTION_LOG"){
                obj.MessageInfo = data[i].action_log.description;
                obj.MessageType = "系统提示";
            }
            if(data[i].content_type=="TEXT"){
                obj.MessageInfo = data[i].text;
                obj.MessageType = "文字";
            }
            if(data[i].content_type=="REEL_SHARE"){
                obj.MessageInfo = data[i].reel_share.text;
                obj.MessageType = "快拍回复";
            }
            if(data[i].content_type=="LIKE"){
                obj.MessageInfo = "点赞";
                obj.MessageType = "点赞";
            }
            if(data[i].content_type=="PROFILE"){
                obj.MessageType = "名片";
                obj.MessageInfo = "ID:"+data[i].profile.id+"\r"+"账户名："+data[i].profile.username+"\r"+"姓名:"+data[i].profile.full_name+"\r"+"粉丝人数："+data[i].profile.follower_count+"\r"+"关注人数："+data[i].profile.following_count+"\r"+"头像链接："+data[i].profile.profile_pic_url+"\r";
            }
            if(data[i].content_type=="MEDIA"){
                if(data[i].media.media_type==1){
                    if(data[i].media.image_versions2.candidates!=""&&data[i].media.image_versions2.candidates!= null){
                        obj.MessageType = "多媒体/图片";
                        for(var a in data[i].media.image_versions2.candidates){
                            obj.MessageInfo+= "头像链接："+data[i].media.image_versions2.candidates[a].url+"\r"+"大小："+data[i].media.image_versions2.candidates[a].width+"X"+data[i].media.image_versions2.candidates[a].height+"\r";
                        }
                    }
                }
                if(data[i].media.media_type==2){
                    if(data[i].media.video_versions!=""&&data[i].media.video_versions!= null){
                        obj.MessageType = "多媒体/视频";
                        for(var a in data[i].media.video_versions){
                            obj.MessageInfo += a+":\r"+"头像链接："+data[i].media.video_versions[a].url+"\r"+"大小："+data[i].media.video_versions[a].width+"X"+data[i].media.video_versions[a].height+"\r";
                        }
                    }
                }
            }
            
            if(data[i].content_type=="MEDIA_SHARE"){
                if(data[i].media_share.media_type==1){
                    if(data[i].media_share.image_versions2.candidates!=""&&data[i].media_share.image_versions2.candidates!= null){
                        obj.MessageType = "博文分享/图片";
                        for(var a in data[i].media_share.image_versions2.candidates){
                            obj.MessageInfo+= "头像链接："+data[i].media_share.image_versions2.candidates[a].url+"\r"+"大小："+data[i].media_share.image_versions2.candidates[a].width+"X"+data[i].media_share.image_versions2.candidates[a].height+"\r";
                        }
                    }
                }
                if(data[i].media_share.media_type==2){
                    if(data[i].media_share.video_versions!=""&&data[i].media_share.video_versions!= null){
                        obj.MessageType = "博文分享/视频";
                        for(var a in data[i].media_share.video_versions){
                            obj.MessageInfo += a+":\r"+"头像链接："+data[i].media_share.video_versions[a].url+"\r"+"大小："+data[i].media_share.video_versions[a].width+"X"+data[i].media_share.video_versions[a].height+"\r";
                        }
                    }
                }
            }
            
            if(data[i].content_type=="MEDIA_SHARE"){
                obj.MessageType = "博文分享";
                if(data[i].media_share.image_versions2.candidates!=""&&data[i].media_share.image_versions2.candidates!= null){
                    obj.MessageInfo += "头像链接："+data[i].media_share.image_versions2.candidates[0].url+"\r"+"大小："+data[i].media_share.image_versions2.candidates[0].width+"X"+data[i].media_share.image_versions2.candidates[0].height+"\r";
                }
            }
            
            obj.SendTime = XLY.Convert.LinuxToDateTime(data[i].timestamp.substr(0,13));
            if(data[i].user.username!= data1.thread_title){
                obj.SenderName = data[i].user.username;
                obj.SenderID = data[i].user.id;
                obj.RecName = data1.thread_title;
                obj.RecID = data1.thread_id;
            }
            else
            {
                obj.SenderName = data1.thread_title;
                obj.SenderID = data1.thread_id;
                obj.RecName = data[i].user.username;
                obj.RecID = data[i].user.id;
            }
            arr.push(obj);
        }
        
        return arr;
    }
}
//获取搜索关键字信息
function getSearch(path,root){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var data = eval('('+ XLY.File.ReadXML(path) +')').map.string;
        if(data!=""&&data!=null){
            for(var i in data){
                //人物搜索
                if(data[i]["@name"]=="recent_user_searches_with_ts"){
                    var node1 = new TreeNode();
                    node1.Text = "人物搜索";
                    node1.Type = "SearchUser";
                    node1.Items = getSearchInfoUser(data[i]["#text"]);
                    root.TreeNodes.push(node1);
                    
                    var obj = new Search();
                    obj.Name = "人物搜索";
                    list.push(obj);
                }
                //地点搜索
                if(data[i]["@name"]=="recent_place_searces"){
                    var node2 = new TreeNode();
                    node2.Text = "地点搜索";
                    node2.Type = "SearchPlace";
                    node2.Items = getSearchInfoPlace(data[i]["#text"]);
                    root.TreeNodes.push(node2);
                    
                    var obj = new Search();
                    obj.Name = "地点搜索";
                    list.push(obj);
                }
                //话题搜索
                if(data[i]["@name"]=="recent_hashtag_searches_with_ts"){
                    var node3 = new TreeNode();
                    node3.Text = "话题搜索";
                    node3.Type = "SearchHash";
                    node3.Items = getSearchInfoHash(data[i]["#text"]);
                    root.TreeNodes.push(node3);
                    
                    var obj = new Search();
                    obj.Name = "话题搜索";
                    list.push(obj);
                }
            }
        }
        return list;
    }
}
//
function getSearchInfoUser(data){
    if(data!=""&&data!= null){
        var con = eval('('+ data +')').users;
        var arr = new Array();
        if(con!=""&&con!=null){
            for(var i in con){
                var obj = new SearchUser();
                obj.Id = con[i].user.id;
                obj.FollowerCount = con[i].user.follower_count;
                obj.FollowingCount = con[i].user.following_count;
                obj.FullName = con[i].user.full_name;
                obj.ProfilePicUrl = con[i].user.profile_pic_url;
                obj.UserName = con[i].user.username;
                arr.push(obj);
            }
        }
        return arr;
    }
}
//
function getSearchInfoPlace(data){
    if(data!=""&&data!=null){
        var con = eval('('+ data +')').places;
        var arr = new Array();
        if(con!=""&&con!=null){
            for(var i in con){
                var obj = new SearchPlace();
                obj.Name = con[i].place.location.name;
                obj.Address = con[i].place.location.address;
                obj.LatLng = con[i].place.location.lat+","+con[i].place.location.lng;
                arr.push(obj);
            }
        }
        return arr;
    }
}
//
function getSearchInfoHash(data){
    if(data!=""&&data!=null){
        var con = eval('('+ data +')').hashtags;
        var arr = new Array();
        if(con!=""&&con!=null){
            for(var i in con){
                var obj = new SearchHash();
                obj.Name = con[i].hashtag.name;
                obj.MediaCount = con[i].hashtag.media_count;
                obj.Id = con[i].hashtag.id;
                arr.push(obj);
            }
        }
        return arr;
    }
}
//获取Cookies信息
function getCookies(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from cookies") +')');
        var arr = new Array();
        if(data!=""&&data!= null){
            for(var i in data){
                var obj = new Cookies();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                obj.Name = data[i].name;
                obj.Host_Key = data[i].host_key;
                obj.CookieValue = data[i].value;
                obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].creation_utc);
                obj.ExpireTime = XLY.Convert.LinuxToDateTime(data[i].exires_utc);
                obj.LastTime = XLY.Convert.LinuxToDateTime(data[i].last_access_utc);
                obj.Path = data[i].path;
                arr.push(obj);
            }
        }
        return arr;
    }
}
