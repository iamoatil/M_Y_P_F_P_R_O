﻿/*[config]
<plugin name="手机热点" group="基本信息,9" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/redian.png" app="" version="" description="最近连接该手机热点的设备" data = "$data,ComplexTreeDataSource" >
<source>
    <value>/data/misc/dhcp/dnsmasq.leases</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="HotSpot" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="链接开始时间" code="StartTime" type="string" width="200" format = ""></item>
    <item name="设备MAC地址" code="MACAddress" type="string" width="200" format=""></item>
    <item name="设备IP地址" code="IPAddress" type="string" width="200" format=""></item>
    <item name="设备名称" code="Name" type="string" width="200" format = ""></item>
</data>
</plugin>
[config]*/
function News() {
    this.DataState = "Normal";  //数据状态
    this.List = ""; //列表
    this.MDFString = "";    //MD5
}
function HostPot() {
    this.DataState = "Normal";  //数据状态
    this.StartTime = "";    //链接开始时间
    this.MACAddress = "";   //设备MAC地址
    this.IPAddress = "";    //设备IP地址
    this.Name = ""; //设备名称
    this.MDFString = "";    //MD5
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//再在线数据
var source = $source;
var Path = source[0];
////测试数据
//var Path = "D:\\qqdowloads\\dnsmasq.leases\\dnsmasq.leases";

var result = new Array();
BuildNode();
var res = JSON.stringify(result);
res;

//*****************************************************************************************************************
function BuildNode(){
 //根节点建立
    var RootNode = new TreeNode();
    RootNode.Text = "手机热点分析";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(RootNode);
    result.push(RootNode);
}
//创建根节点
function GetRootInfo(RootNode){
    var temp1 = new Array();
    var temp2 = new News();
    temp2.List = "最近连接该手机热点的设备";
    temp1.push(temp2);
    
    //建立热点节点
    var HotspotNode = new TreeNode();
    HotspotNode.Text = "最近连接该手机热点的设备";
    HotspotNode.Type = "HotSpot";
    HotspotNode.Items = GetHostPot();
    RootNode.TreeNodes.push(HotspotNode);
    
    return temp1;
}
//得到热点信息
function GetHostPot(){
    var temp1 = new Array();
    var fhandle = XLY.Blob.GetFileHandle(Path);
    var flen = XLY.Blob.GetFileSizeFromHandle(fhandle);
    var data = XLY.Blob.GetBytesFromHandle(fhandle,0 ,flen );
    var logo = [10];
    var startpos = new Array();
    startpos = 0;
    while(startpos < flen){
        var temp2 = new HostPot();
        var pos = XLY.Blob.FindBytes(data,startpos , logo);
        var datainfo = XLY.Blob.GetBytes(data,startpos ,pos - startpos);
        startpos = pos + 1;
        var info = XLY.Blob.ToString(datainfo).split(" ");
        temp2.StartTime = XLY.Convert.LinuxToDateTime(eval('('+ info[0] +')'));    //链接开始时间
        temp2.MACAddress = info[1];   //设备MAC地址
        temp2.IPAddress = info[2];    //设备IP地址
        temp2.Name = info[3]; //设备名称  
        temp1.push(temp2);
    }
    return temp1;
}