﻿/*[config]
<plugin name="360手机助手,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/shoujizhushou.png" app="com.qihoo.appstore" version="5.0.92" description="360手机助手" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.qihoo.appstore/databases/download5.db</value>
    <value>/data/data/com.qihoo.appstore/databases/localApkInfo.db</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "150"></item>
    <item name="密码" code="PassWord" type="string" width="120"></item>
    <item name="邮箱" code="Emaill" type="string" width="150"></item>
    <item name="服务器IP" code="CiServer" type="string" width="150"></item>
    <item name="远程主机IP" code="Host" type="string" width="150"></item>
    <item name="本机端口" code="LocalPort" type="string" width="80"></item>
    <item name="远程端口" code="RomotePort" type="string" width="80"></item>
    <item name="是否已连接" code="IsActived" type="string" width="80"></item>
    <item name="地区" code="Region" type="string" width="80"></item>
    <item name="线路" code="Route" type="string" width="80"></item>
    <item name="会员有效日期至" code="Expiration" type="string" width="150"></item>
    <item name="创建时间" code="CreateTime" type="string" width="150"></item>
    <item name="账号类型" code="UserType" type="string" width = "120"></item>
    <item name="账号积分" code="UserScore" type="string" width = "120"></item>
    <item name="今日已用流量" code="TodayReadable" type="string" width = "120"></item>
    <item name="累计已用流量" code="StatReadable" type="string" width = "120"></item>
    <item name="共获赠VIP" code="UserPrize" type="string" width = "120"></item>
</data>
<data type="Download" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="App包名" code="ResId" type="string" width="120" format=""></item>
    <item name="App名称" code="AppName" type="string" width="120" format=""></item>
    <item name="App大小" code="AppSize" type="string" width="80" format=""></item>
    <item name="App版本" code="AppVersion" type="string" width="80" format=""></item>
    <item name="AppLog链接" code="AppLogUrl" type="url" width="120" format=""></item>
    <item name="当前下载大小" code="CurrentByte" type="string" width="80" format=""></item>
    <item name="下载链接" code="DownloadUrl" type="url" width="120" format=""></item>
    <item name="本地路径" code="LocalPath" type="url" width="120" format=""></item>
    <item name="开始下载时间" code="StartDownloadTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="已安装" code="IsInstall" type="string" width="80" format=""></item>
</data>
<data type="ApkInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="包名" code="PackageName" type="string" width="120" format=""></item>
    <item name="Apk名称" code="AppName" type="string" width="120" format=""></item>
    <item name="版本" code="AppVersion" type="string" width="80" format=""></item>
    <item name="安装路径" code="InstallPath" type="url" width="120" format=""></item>
    <item name="文件最后修改时间" code="FileLastModifiedTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="App大小" code="AppSize" type="string" width="80" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function ApkInfo(){
    this.DataState = "Normal";
    this.PackageName = "";
    this.AppName = "";
    this.AppSize = "";
    this.AppVersion = "";
    this.FileLastModifiedTime = null;
    this.InstallPath = "";
}
function Download(){
    this.DataState = "Normal";
    this.ResId = "";
    this.AppName = "";
    this.AppSize = "";
    this.AppVersion = "";
    this.AppLogUrl = "";
    this.CurrentByte = "";
    this.DownloadUrl = "";
    this.LocalPath = "";
    this.StartDownloadTime = null;
    this.IsInstall = "否";
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PassWord = "";
    this.Emaill = "";
    this.CiServer = "";
    this.Host = "";
    this.LocalPort = "";
    this.RomotePort = "";
    this.IsActived = "否";
    this.Region = "";
    this.Route = "";
    this.Expiration = "";
    this.CreateTime = "";
    this.UserType = "";
    this.UserScore = "";
    this.TodayReadable = "";
    this.StatReadable = "";
    this.UserPrize = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var downloadPath1 = source[0];
var apkInfoPath1 = source[1];

//测试数据
//var downloadPath1 = "D:\\资料工作\\赵能嘉\\com.qihoo.appstore\\databases\\download5.db";
//var apkInfoPath1 = "D:\\资料工作\\赵能嘉\\com.qihoo.appstore\\databases\\localApkInfo.db";
//定义特征库文件
var charactor1 = "\\chalib\\Android_360ShouJiZhuShou_V5.0.92\\download5.db.charactor";
var charactor2 = "\\chalib\\Android_360ShouJiZhuShou_V5.0.92\\localApkInfo.db.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var userpathD = XLY.Sqlite.DataRecovery(userpathD1,userpathDcharactor,"preferences_storage");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "360手机助手";
    root.Type = "";
    getNews(root);
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(apkInfoPath1)){
        var apkInfoPath = XLY.Sqlite.DataRecovery(apkInfoPath1,charactor2,"apkInfo");
        var userNode = new TreeNode();
        userNode.Text = "默认账户";
        userNode.Type = "";
        if(XLY.File.IsValid(downloadPath1)){
            var downloadPath = XLY.Sqlite.DataRecovery(downloadPath1,charactor1,"download");
            if(XLY.File.IsValid(downloadPath1)){
                var dataMd5 = eval('('+ XLY.Sqlite.Find(downloadPath,"select XLY_DataType,resId,size,downloadUrl,savedPath,currentBytes,startDownloadTime,name,versionCode,logoUrl,md5 from download") +')');
                if(dataMd5!=""&&dataMd5!= null){
                    var downloadNode = new TreeNode();
                    downloadNode.Text = "下载记录";
                    downloadNode.Type = "Download";
                    for(var i in dataMd5){
                        var obj = new Download();
                        obj.DataState = XLY.Convert.ToDataState(dataMd5[i].XLY_DataType);
                        obj.ResId = dataMd5[i].resId;
                        obj.AppName = dataMd5[i].name;
                        obj.AppSize = dataMd5[i].size+" B";
                        obj.AppVersion = dataMd5[i].versionCode;
                        obj.AppLogUrl = dataMd5[i].logoUrl;
                        obj.CurrentByte = dataMd5[i].currentBytes+" B";
                        obj.DownloadUrl = dataMd5[i].downloadUrl;
                        obj.LocalPath = dataMd5[i].savedPath;
                        obj.StartDownloadTime = XLY.Convert.LinuxToDateTime(dataMd5[i].startDownloadTime);
                        
                        if(XLY.File.IsValid(apkInfoPath)){
                            var apkInfoMd5 = eval('('+ XLY.Sqlite.Find(apkInfoPath,"select apkName from apkInfo where apkMd5 = '"+dataMd5[i].md5+"'") +')');
                            if(apkInfoMd5!=""&&apkInfoMd5!= null){
                                obj.IsInstall = "是";
                            }
                        }
                        downloadNode.Items.push(obj);
                    }
                    if(downloadNode.Items!=""&&downloadNode.Items!=null){
                        userNode.TreeNodes.push(downloadNode);
                    }
                }
            }
        }
        if(XLY.File.IsValid(apkInfoPath)){
            var apkInfoData = eval('('+ XLY.Sqlite.Find(apkInfoPath,"select XLY_DataType,packageName,versionName,apkName,installPath,FileLength,FileLastModifiedTime from apkInfo") +')');
            if(apkInfoData!=""&&apkInfoData!=null){
                var apkInfoNode = new TreeNode();
                apkInfoNode.Text = "手机中已安装的app";
                apkInfoNode.Type = "ApkInfo";
                for(var j in apkInfoData){
                    var objApkInfo = new ApkInfo();
                    objApkInfo.DataState = XLY.Convert.ToDataState(apkInfoData[j].XLY_DataType);
                    objApkInfo.PackageName = apkInfoData[j].packageName;
                    objApkInfo.AppName = apkInfoData[j].apkName;
                    objApkInfo.AppSize = apkInfoData[j].FileLength;
                    objApkInfo.AppVersion = apkInfoData[j].versionName;
                    objApkInfo.FileLastModifiedTime = XLY.Convert.LinuxToDateTime(apkInfoData[j].FileLastModifiedTime);
                    objApkInfo.InstallPath = apkInfoData[j].installPath;
                    apkInfoNode.Items.push(objApkInfo);
                }
                if(apkInfoNode.Items!=""&&apkInfoNode.Items!=null){
                    userNode.TreeNodes.push(apkInfoNode);
                }
            }
        }
    }
    root.TreeNodes.push(userNode);
}