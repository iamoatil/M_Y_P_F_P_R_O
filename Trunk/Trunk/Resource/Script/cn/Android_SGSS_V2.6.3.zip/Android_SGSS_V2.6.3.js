﻿/*[config]
<plugin name="搜狗搜索" group="生活旅游,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/sogousousuo.png" app="com.sogou.activity.src" version="2.6.3" description="搜狗搜索" data="$data,ComplexTreeDataSource"  >
<source>
    <value>data/data/com.sogou.activity.src/databases/sogousearch.db</value>
    <value>data/data/com.sogou.activity.src/databases/sgdownloads.db</value>

</source>
<data type="BrowseHistory" datefilter="Date" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="标题" code="title" type="String" width = "300" ></item>
    <item name="链接" code="url" type="Url" width = "300" ></item>
    <item name="时间" code="Date" type="DateTime" width="300" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="SearchHistory" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="内容" code="content" type="string" width = "300"></item>
</data>
<data type="DownloadHistory" datefilter="Date" contract="DataState,Conversion"> 
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item> 
    <item name="下载链接" code="downloadUrl" type="Url" width = "300"></item>
    <item name="文件路径" code="dataUrl" type="string" width = "300" show="false"></item>
    <item name="时间" code="Date" type="DateTime" width="300" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="BookMark" datefilter="Date" contract = "DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="title" type="String" width = "300" ></item>
    <item name="链接" code="url" type="Url" width = "300" ></item>
    <item name="时间" code="Date" type="DateTime" width="300" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="Location" contract = "DataState">   
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="当前定位" code="gps" type="String" width="300" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function BrowseHistory() {
    this.title = "";  
    this.url = ""; 
    this.Date = ""; 
    this.DataState = "Normal";  
}
function SearchHistory() {
    this.content = ""; 
    this.DataState = "Normal";  
}
function DownloadHistory() {
    this.downloadUrl = "";
    this.dataUrl = "";
    this.Date = ""; 
    this.DataState = "Normal";  
}

function BookMark() {
    this.title = "";  
    this.url = "";  
    this.Date = "";  
    this.DataState = "Normal";  
}
function Location() {
    this.gps = "";   
    this.DataState = "Normal";  
}

//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}

//获取浏览记录
function GetBrowseHistory(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from history_info") + ')');
for(var index in data)
{
    var obj=new BrowseHistory();
    obj.title = data[index].title;  
    obj.url = data[index].url;
    obj.Date = StrToUnix(data[index].date);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取搜索记录
function GetSearchHistory(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from search_info") + ')');
for(var index in data)
{
    var obj=new SearchHistory();
    obj.content = data[index].query;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}

}
//获取下载记录
function GetDownloadHistory(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from sgdownloads") + ')');
for(var index in data)
{
    var obj = new DownloadHistory();
    obj.downloadUrl = data[index].uri;  
    obj.dataUrl = data[index].hint;
    obj.Date = StrToUnix(data[index].lastmod);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}
//获取书签
function GetBookMark(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmark_info") + ')');
for(var index in data)
{
    var obj=new BookMark();
    obj.title = data[index].title;  
    obj.url = data[index].url;
    obj.Date = StrToUnix(data[index].date);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取位置
function GetLocation(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from card_weather") + ')');
for(var index in data)
{
    var obj=new Location();
    obj.gps = data[index].key;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}


function StrToUnix(str)
{
   
    return XLY.Convert.LinuxToDateTime(str);
    
}


function CreateNode(type,text,dbInfo,root)
{
    var childNode =new TreeNode();
    childNode.Type=type;
    childNode.Text = text;
    if(dbInfo)
    childNode.Items = dbInfo;
    root.push(childNode);
}

function CreateNodeWithChild(root,type,text,dbInfo,childType,childText,childDB)
{
    var Node =new TreeNode();
    Node.Type=type;
    Node.Text=text;
    if(dbInfo)
    Node.Items = dbInfo;
    for(var i in childType)
    {
    var childNode =new TreeNode();
    childNode.Type=childType[i];
    childNode.Text =childText[i];
    if(childDB[i])
    childNode.Items = childDB[i];
    Node.TreeNodes.push(childNode);
    }
    root.push(Node);
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0] ;
var path2 = source[1] ;
var charactor1 = "chalib\\Android_SGSS_V2.6.3\\sogousearch.db.charactor";
var charactor2 = "chalib\\Android_SGSS_V2.6.3\\sgdownloads.db.charactor";
//path1  = "C:\\Users\\Administrator\\Desktop\\sogou\\a\\data\\data\\com.sogou.activity.src\\databases\\sogousearch.db"
//path2  = "C:\\Users\\Administrator\\Desktop\\sogou\\a\\data\\data\\com.sogou.activity.src\\databases\\sgdownloads.db"
path1  =XLY.Sqlite.DataRecovery( path1,charactor1 ,"search_info,history_info,bookmark_info,card_weather");
path2  =XLY.Sqlite.DataRecovery( path2,charactor2 ,"sgdownloads");



//--------------------------------------------------------------------以下为多节点构造

//--------------------------------------------------------------------以下为单节点构造（浏览记录，搜索记录，下载记录，书签，位置）
CreateNode("BrowseHistory","浏览记录",GetBrowseHistory(path1),result);
CreateNode("SearchHistory","搜索记录",GetSearchHistory(path1),result);
CreateNode("DownloadHistory","下载记录",GetDownloadHistory(path2),result);
CreateNode("BookMark","书签",GetBookMark(path1),result);
CreateNode("Location","位置",GetLocation(path1),result);

var res = JSON.stringify(result);
res;
