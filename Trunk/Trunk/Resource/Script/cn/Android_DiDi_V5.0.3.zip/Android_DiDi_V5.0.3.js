﻿/*[config]
<plugin name="滴滴打车" group="地图公交,7,7" devicetype="android" icon="\icons\didi.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.sdu.didi.psnger" version="5.0.3" description="滴滴打车" data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/com.sdu.didi.psnger/shared_prefs/com.sdu.didi.psnger_preferences.xml</value>
<value>/data/data/com.sdu.didi.psnger/shared_prefs/lastCenterPoint.xml</value>
<value>/data/data/com.sdu.didi.psnger/shared_prefs/emergency_contacter_db.xml</value>
<value>/data/data/com.sdu.didi.psnger/shared_prefs/bts_sharedPref_file.xml</value>
<value>/data/data/com.sdu.didi.psnger/shared_prefs/COMMON_ADDRESS.xml</value>
</source>
<data type="Info" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="昵称" code="Nick" type="string" width = "200"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="性别" code="Gender" type="string" width = "200"></item>
<item name="头像" code="Avatar" type="string" width = "200"></item>
</data>
<data type="Phone" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="手机号" code="Num" type="string" width = "200"></item>
</data>
<data type="Location" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="经度" code="Lon" type="string" width = "200"></item>
<item name="纬度" code="Lat" type="string" width = "200"></item>
</data>
<data type="Emergency" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="姓名" code="Name" type="string" width = "200"></item>
<item name="号码" code="Num" type="string" width = "200"></item>
</data>
<data type="Address" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="地址" code="Addr" type="string" width = "200"></item>
<item name="类型" code="Type" type="string" width = "200"></item>
<item name="经度" code="Lon" type="string" width = "200"></item>
<item name="纬度" code="Lat" type="string" width = "200"></item>
</data>
</plugin>
[config]*/
function Info(){
    this.DataState = "Normal";
    this.Nick = "";
    this.ID = "";
    this.Gender = "";
    this.Avatar = "";
}
function Phone(){
    this.DataState = "Normal";
    this.Num = "";
}
function Location(){
    this.DataState = "Normal";
    this.Lon = "";
    this.Lat = "";
}
function Emergency(){
    this.DataState = "Normal";
    this.Name = "";
    this.Num = "";
}
function Address(){
    this.DataState = "Normal";
    this.Addr = "";
    this.Type = "";
    this.Lon = "";
    this.Lat = "";
}


//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var didi = new TreeNode();
    didi.Text = "滴滴打车";
    didi.Type = "Info";
    didi.DataState = "Normal";
    
    var user = new TreeNode();
    user.Text = "用户";
    user.Type = "Info";
    user.Items = getInfo(db3);
    didi.TreeNodes.push(user);
    
    var num = new TreeNode();
    num.Text = "登录过的手机";
    num.Type = "Phone";
    num.Items = getPhone(db);
    didi.TreeNodes.push(num);
    
    var location = new TreeNode();
    location.Text = "最后定位";
    location.Type = "Location";
    location.Items = getLocation(db1);
    didi.TreeNodes.push(location);
    
    var emergency = new TreeNode();
    emergency.Text = "紧急联系人";
    emergency.Type = "Emergency";
    emergency.Items = getEmergency(db2);
    didi.TreeNodes.push(emergency);
    
    var addr = new TreeNode();
    addr.Text = "常用地址";
    addr.Type = "Address";
    addr.Items = getAddress(db4);
    didi.TreeNodes.push(addr);
    
      result.push(didi);
}
function getInfo (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')'); 
     var obj = new Info();  
     var info = data.map.string;
     for(var i = 0;i<info.length; i++ ){
         try
         {
             var accinfo = eval('('+ info[i]["#text"] +')');
             obj.Nick = accinfo.user_info.nick;
             obj.ID = accinfo.user_info.uid;
             obj.Avatar = accinfo.user_info.head_url;
              var a = accinfo.user_info.gender;
                 if(a == 1){
                     obj.Gender = "男";
                 }
                 else
                 {
                     obj.Gender = "女"
                 }
             list.push(obj);
         }
         catch(er){
             log("error");
         }
     }
   
    
    return list;
 }
function getPhone (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')'); 
   var obj = new Phone();  
     var info = data.map.string;
     for(var i in info){
         
         if(info[i]["@name"] == "phone_list"){
             obj.Num = info[i]["#text"]; 
         }
     }
    list.push(obj);       
    return list;
 }
function getLocation (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')'); 
     var obj = new Location();  
     var info = data.map.long;
     for(var i in info){        
         if(info[i]["@name"] == "longitude"){
             obj.Lon = info[i]["@value"]/1000/1000; 
         }
        if(info[i]["@name"] == "latitude"){
            obj.Lat = info[i]["@value"]/1000/1000; 
        }
     }
    list.push(obj);     
    return list;
 }
function getEmergency(path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');     
     var info = data.map.string;
     for(var i in info){
    var obj = new Emergency();          
         if(/^contacter/.test(info[i]['@name'])){
            var info1 = info[i]['@name'];
            var accinfo = eval('('+ info[i]["#text"] +')');
            obj.Name = accinfo[i].name;
            obj.Num = accinfo[i].phone;
         }
         list.push(obj);
     }       
        return list;
 }
function getAddress(path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');      
     var info = data.map.string;
     //log(info.length);
     if(info.length !=null){
        for(var i in info){
        var obj = new Address();          
            var info1 = info[i]['@name'];
            var accinfo = eval('('+ info[i]["#text"] +')');
            log(accinfo.addrlist);
            obj.Addr = accinfo.addrlist[0].addr;
            obj.Type = accinfo.addrlist[0].name;
            obj.Lon = accinfo.addrlist[0].lng;
            obj.Lat = accinfo.addrlist[0].lat;
         list.push(obj);
     }
     }
     else
     {
          var obj = new Address();
         var accinfo = eval('('+ info["#text"] +')');
         //log(accinfo);
         //log(accinfo.addrlist[0].addr);
         obj.Addr = accinfo.addrlist[0].addr;
         obj.Type = accinfo.addrlist[0].name;
         obj.Lon = accinfo.addrlist[0].lng;
         obj.Lat = accinfo.addrlist[0].lat;
          list.push(obj);
     }
     
    return list;
 }
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
var db2 = source[2];
var db3 = source[3];
var db4 = source[4];
// db = "E:\\temp\\data\\data\\com.sdu.didi.psnger\\shared_prefs\\com.sdu.didi.psnger_preferences.xml";
// db1 = "E:\\temp\\data\\data\\com.sdu.didi.psnger\\shared_prefs\\lastCenterPoint.xml";
// db2 = "E:\\temp\\data\\data\\com.sdu.didi.psnger\\shared_prefs\\emergency_contacter_db.xml";
// db3 = "E:\\temp\\data\\data\\com.sdu.didi.psnger\\shared_prefs\\bts_sharedPref_file.xml";
// db4 = "E:\\temp\\data\\data\\com.sdu.didi.psnger\\shared_prefs\\COMMON_ADDRESS.xml";
//
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
