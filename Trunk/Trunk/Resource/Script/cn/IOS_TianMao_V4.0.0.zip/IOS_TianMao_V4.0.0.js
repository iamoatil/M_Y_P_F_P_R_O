﻿/*[config]
<plugin name="天猫,8" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/TianMao.png" app="com.taobao.tmall" version="4.0.0" description="天猫" data="$data,ComplexTreeDataSource"  >
<source>
<value>com.taobao.tmall</value>
</source>
<data type="SearchHistory">
<item name="关键字内容" code="key" type="string" width="150"></item>
</data>
<data type="NewCollection">
<item name="图片" code="pic" type="image" width="50"></item>
<item name="店铺名称" code="shopName" type="string" width="300"></item>
<item name="地点" code="location" type="string" width="150"></item>
<item name="价格" code="price" type="string" width="150"></item>
<item name="销量" code="sold" type="string" width="150"></item>
</data>
<data type="ShopCollection">
<item name="店铺" code="title" type="string" width="200" ></item>
<item name="掌柜" code="ownernick" type="string" width="300" ></item>
</data>
<data type="ItemsCollection">
<item name="宝贝标题" code="title" type="string" width="200" ></item>
<item name="店铺" code="ownernick" type="string" width="300" ></item>
</data>
<data type="User">
<item name="用户名" code="name" type="string" width="200" ></item>
</data>
</plugin>
[config]*/

//定义数据结构
function SearchHistory() {
	this.key = "";
}

//最近收藏信息
function NewCollection() {
	this.pic = "";
	this.shopName = "";
	this.location = "";
	this.price = "";
	this.sold = "";
}

//店铺收藏
function ShopCollection() {
	this.title = "";
	this.ownernick = "";
}

//宝贝收藏
function ItemsCollection() {
	this.title = "";
	this.ownernick = "";
}

function User() {
	this.name = "";
}

//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
}

//搜索历史记录
function getSearchHistory(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
		for (var index in data[0].data[0]) {
			var obj = new SearchHistory();
			obj.key = data[0].data[0][index];
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//最近收藏
function getNewCollection(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
		for (var index in data[0].histories[0]) {
			var obj = new NewCollection();
			obj.location = data[0].histories[0][index][2].extend[0].location;
			obj.price = data[0].histories[0][index][2].extend[1].price;
			obj.sold = data[0].histories[0][index][2].extend[4].soldCount;
			obj.pic = data[0].histories[0][index][4].image;
			obj.shopName = data[0].histories[0][index][5].name;
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//店铺收藏
function getShops(path, method) {
	var arr = new Array();
	try{
		if(XLY.PList.ReadToJsonString(path)){
			var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
			for (var index in data[1].$objects[0].NSMutableArray) {
				var obj = new method();
				obj.title = data[1].$objects[0].NSMutableArray[index].TBCollectItemData[10].title;
				obj.ownernick = data[1].$objects[0].NSMutableArray[index].TBCollectItemData[6].ownernick;
				arr.push(obj);
			}}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//用户登录检索
function getUsers(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
		for (var index in data[1].$objects[0].NSMutableDictionary[2].UserIdList.NSMutableArray) {
			var obj = new User();
			obj.name = data[1].$objects[0].NSMutableDictionary[2].UserIdList.NSMutableArray[index]["-1"];
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0] + "//com.taobao.tmall/Documents/localSearchHistory.plist";
var path2 = source[0] + "//com.taobao.tmall/Library/History.plist";
var path3 = source[0] + "//com.taobao.tmall/Documents/CollectShops.data";
var path4 = source[0] + "//com.taobao.tmall/Documents/CollectItemsOnWeb.data";
var path5 = source[0] + "//com.taobao.tmall/Documents/hintNum";


//建立节点
var SearchNode = new TreeNode();
SearchNode.Type = "SearchHistory";
SearchNode.Text = "搜索历史";

var NewNode = new TreeNode();
NewNode.Type = "NewCollection";
NewNode.Text = "最近添加收藏";

var ShopNode = new TreeNode();
ShopNode.Type = "ShopCollection";
ShopNode.Text = "商铺收藏";

var ItemsNode = new TreeNode();
ItemsNode.Type = "ItemsCollection";
ItemsNode.Text = "宝贝收藏";

var LgoinNode = new TreeNode();
LgoinNode.Type = "User";
LgoinNode.Text = "用户登录记录";

//填充节点
SearchNode.Items = getSearchHistory(path1);
NewNode.Items = getNewCollection(path2);
ShopNode.Items = getShops(path3, ShopCollection);
ItemsNode.Items = getShops(path4, ItemsCollection);
LgoinNode.Items = getUsers(path5);

//显示节点
result.push(SearchNode);
result.push(NewNode);
result.push(ShopNode);
result.push(ItemsNode);
result.push(LgoinNode);
var res = JSON.stringify(result);
res;
