﻿/*[config]
<plugin name="UC浏览器,2" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\wifi.png" version="9.8" app="com.android.webbrowse" description="提取IOS设备WIFI信息" data="$data" >
<source>
<value>com.apple.webbrowse</value>
</source>
<data type="UCOriginMsg">
<item name="原始网站记录" code="originInfo" type="string" width="100" ></item>
<item name="本地文件路径(相对)" code="filePath" type="string" width="150" ></item>
</data>
</plugin>
[config]*/

//D:\\temp\\data\\data\\com.UCMobile\\UCMobile\\localstorage\\StorageTracker.db
function UCOriginMsg(){
	this.originInfo = "";
	this.filePath = "";
}



function GetUCHistoryInfo(path){
    var data = eval('(' + XLY.Sqlite.Find(path, " SELECT origin, path from Origins ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new UCOriginMsg();        
        obj.originInfo = data[index].origin;
        obj.filePath = data[index].path;
        info.push(obj)
    }
    return info;
}


var tableList = "Origins";
var source = $source;
var searchPath = source[0];
var searchPath = searchPath + "\\data\\data\\com.UCMobile\\UCMobile\\localstorage\\StorageTracker.db";
//var searchPath = "D:\\temp\\data\\data\\com.UCMobile\\UCMobile\\localstorage\\StorageTracker.db";
var chailb = "chalib\\Android_UC\\UC_V9.8.sqlite.charactor";
var dbpath = XLY.Sqlite.DataRecovery(searchPath, chailb, tableList);
searchPath = dbpath;

var result = GetUCHistoryInfo(searchPath);

var res = JSON.stringify(result);
res;
