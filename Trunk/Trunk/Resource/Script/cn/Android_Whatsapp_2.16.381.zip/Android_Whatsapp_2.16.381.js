﻿/*[config]
<plugin name="Whatsapp,7" group="社交聊天,2" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/whatsapp.png" app="com.whatsapp" version="2.16.381" description="Whatsapp" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.whatsapp/databases#F</value>
    <value>/data/data/com.whatsapp/shared_prefs#F</value>
</source>

<data type="User">
    <item name="用户ID" code="ID" type="string" width="120" format=""></item>
    <item name="用户昵称" code="Nick" type="string" width="120" format = ""></item>
    <item name="在线状态" code="Status" type="string" width="180" format = ""></item>
    <item name="已注册电话号码" code="Phone" type="string" width="120" format=""></item>
    <item name="电话归属国代码" code="CCode" type="string" width="80" format = ""></item>
    <item name="登录时间" code="Time" type="datetime" width="140" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="标签" code="flag" type="int" width="" format= "" show = "false" ></item>
    <item name="SD路径" code="SDpath" type="string" width="" format= "" show="false" ></item>
</data>

<data type = "Friend" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户昵称" code="Nick" type="string" width="120" format = ""></item>
    <item name="电话号码" code="Phone" type="string" width="180" format = ""></item>
    <item name="类型" code="Class" type="string" width="120" format = ""></item>
</data>

<data type = "Contact" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="ID" type="string" width="120" format=""></item>
    <item name="用户昵称" code="Nick" type="string" width="120" format = ""></item>
    <item name="在线状态" code="Status" type="string" width="100" format = ""></item>
    <item name="电话号码" code="Phone" type="string" width="120" format=""></item>
    <item name="登录时间" code="Time" type="datetime" width="140" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type = "Group" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群组ID" code="ID" type="string" width="120" format=""></item>
    <item name="群组名称" code="Nick" type="string" width="120" format = ""></item>
    <item name="群组创建者" code="Author" type="string" width="250" format = ""></item>
    <item name="群组成员" code="Member" type="string" width="250" format=""></item>
    <item name="是否被移除" code="IsDelete" type="string" width="200" format=""></item>
    <item name="创建时间" code="Time" type="datetime" width="140" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type = "SContact" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="名称" code="Nick" type="string" width="100" format = ""></item>
    <item name="账号ID" code="ID" type="string" width="120" format=""></item>
    <item name="电话号码" code="Phone" type="string" width="120" format=""></item>
</data>

<data detailfield="Content" type="Message" datefilter="StartDate" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="消息发送者" code="SenderName" type="string" width="" alignment="center" ></item>
<item name="消息接收者" code="Number" type="string" width="120" ></item>
<item name="内容" code="Content" type="string" width="400" ></item>
<item name="消息发送时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="类型" code="Type" type="string" format="" width = "100" ></item>
<item name="是否收藏" code="Starred" type="string" width="100" show= ""></item>
<item name="发送状态" code="SendState" type="string" width="80" show= "false"></item>
</data>


</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function User() {
    this.ID = "";   //用户ID
    this.Nick = ""; //用户昵称
    this.Status = "";   //在线状态
    this.Phone = "";    //已注册电话号码
    this.CCode = "";    //电话归属国代码
    this.Time = null;   //登录时间
    this.flag = 0;
    this.SDpath = "";
    this.MDFString = "";    //MD5
}

function Friend() {
    this.DataState = "Normal";  //数据状态
    this.Nick = ""; //用户昵称
    this.Phone = "";    //电话号码
    this.Class = "";//类别
}
function Contact() {
    this.DataState = "Normal";  //数据状态
    this.ID = "";   //用户ID
    this.Nick = ""; //用户昵称
    this.Status = "";   //在线状态
    this.Phone = "";    //电话号码
    this.Time = null;   //登录时间
}
function Group() {
    this.DataState = "Normal";  //数据状态
    this.ID = "";   //群组ID
    this.Nick = ""; //群组名称
    this.Author = "";   //群组创建者
    this.Member = "";
    this.IsDelete = "";//成员是否被移除
    this.Time = null;   //登录时间
}
function SContact() {
    this.DataState = "Normal";  //数据状态
    this.Nick = ""; //名称
    this.ID = "";
    this.Phone = "";    //电话号码
}

function Message() {
    this.DataState = "Normal";  //数据状态
    this.Number = "";   //消息发送者
    this.SenderName = "";   //消息接收者
    this.Content = "";  //内容
    this.Date = null;   //消息发送时间
    this.Type = "";   //类型
    this.Starred="" //是否收藏
    this.SendState = "";    //发送状态
}


//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dpath = source[0];
var upath = source[1];
var mch = "\\chalib\\Android_whatsapp_V2.16.381\\msgstore.db.charactor";
var cch = "\\chalib\\Android_whatsapp_V2.16.381\\wa.db.charactor";
//测试数据
//var upath = "C:\\temp45456\\data\\data\\com.whatsapp\\shared_prefs";
//var dpath = "C:\\temp45456\\data\\data\\com.whatsapp\\databases";
//
////定义特征库文件
//var mch = "C:\\Users\\Administrator\\Desktop\\whatsapp\\Android_whatsapp_V2.16.381\\msgstore.db.charactor";
//var cch = "C:\\Users\\Administrator\\Desktop\\whatsapp\\Android_whatsapp_V2.16.381\\wa.db.charactor";

//创建帐号树结构
result.push(buildNode());
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var whatsapp = new TreeNode();
    whatsapp.Text = "Whatsapp";
    //whatsapp.Type = "";
    var userinfo = buildUserNode(upath,whatsapp);
    //result.push(whatsapp);
    buildOtherNode(dpath,whatsapp,userinfo);
    return whatsapp;
}

function buildUserNode(path,node){
    // body...
    var user = new TreeNode();
    user.Text = "登录信息";
    user.Type = "User";
    var uinpath = path+"\\com.whatsapp_preferences.xml";
    var phonepath = path+"\\registration.RegisterPhone.xml";
    var uobj;
    if (XLY.File.IsValid(uinpath)) {
        uobj = new User();
        var udata = eval('('+ XLY.File.ReadXML(uinpath) +')');
        var uinfo = udata.map.string;
        if(uinfo.length>0){
            for(var i in uinfo){
                if(uinfo[i]['@name']=="registration_jid"){
                    uobj.ID = uinfo[i]['#text'];
                    uobj.flag = 1;
                    continue;
                }
                if(uinfo[i]['@name']=="push_name"){
                    uobj.Nick = uinfo[i]['#text'];
                    continue;
                }
                if(uinfo[i]['@name']=="my_current_status"){
                    uobj.Status = uinfo[i]['#text'];
                    continue;
                }
                if(uinfo[i]['@name']=="ph"){
                    uobj.Phone = uinfo[i]['#text'];
                    continue;
                }
                if(uinfo[i]['@name']=="cc"){
                    uobj.CCode = uinfo[i]['#text'];
                    continue;
                }
                if(uinfo[i]['@name']=="data_usage_last_sync_date"){
                    uobj.Time = uinfo[i]['#text'];
                    continue;
                }
                if(uinfo[i]['@name']=="external_file_image"){
                    uobj.SDpath = uinfo[i]['#text'];
                    continue;
                }
            }
            
        }
        var ulong = udata.map.long;
        if(ulong.length>0){
            for(var i in ulong){
                if(ulong[i]['@name']=="phoneid_last_sync_timestamp"){
                    uobj.Time = XLY.Convert.LinuxToDateTime(ulong[i]['@value']);
                    continue;
                }
            }
        }
    }
    if (uobj!=null&&uobj.flag == 0 && XLY.File.IsValid(phonepath)) {
        var pdata = eval('('+ XLY.File.ReadXML(phonepath) +')');
        var pinfo = pdata.map.string;
        if(pinfo){
            for(var i in pinfo){
                if(pinfo[i]['@name']=="com.whatsapp.registration.RegisterPhone.phone_number"){
                    uobj.Phone = pinfo[i]['#text'];
                    continue;
                }
                if(pinfo[i]['@name']=="com.whatsapp.registration.RegisterPhone.country_code"){
                    uobj.CCode = pinfo[i]['#text'];
                    continue;
                }
            }
        }
    }
    user.Items.push(uobj);
    node.TreeNodes.push(user);
    return uobj;
}


function buildOtherNode(path,node,userinfo){
    var mpath = path+"\\msgstore.db";
    var fpath = path+"\\wa.db";
    
    if(XLY.File.IsValid(fpath)&&XLY.File.IsValid(mpath)){
        var friend = new TreeNode();
        friend.Text = "联系人";
        friend.Type = "Friend";
        var recfpath = XLY.Sqlite.DataRecovery(fpath,cch,"wa_contacts");
        var recmpath = XLY.Sqlite.DataRecovery(mpath,mch,"chat_list,group_participants,messages,group_participants_history");
        buildFriendNode(recfpath,recmpath,friend,userinfo);
        node.TreeNodes.push(friend);
        
        
        var conversation = new TreeNode();
        conversation.Text = "对话";
        buildConversationNode(recmpath,recfpath,conversation,userinfo);
        node.TreeNodes.push(conversation);
        
    }
}

function buildFriendNode(fpath,mpath,node,user){
    //提取联系人中的好友信息
    var cdata = eval('('+ XLY.Sqlite.Find(fpath,"select * from wa_contacts where phone_label='' AND is_whatsapp_user = 1") +')');
    if(cdata.length>0&&cdata!=null){
        var contact = new TreeNode();
        contact.Text = "好友列表";
        contact.Type = "Contact";
        for(var i in cdata){
            var cobj = new Contact();
            cobj.DataState = XLY.Convert.ToDataState(cdata[i].XLY_DataType);
            cobj.ID = cdata[i].jid;   //用户ID
            cobj.Nick = cdata[i].display_name; //用户昵称
            cobj.Status = cdata[i].status;   //在线状态
            cobj.Phone = cdata[i].number;    //电话号码
            cobj.Time = XLY.Convert.LinuxToDateTime(cdata[i].status_timestamp);   //登录时间co
            contact.Items.push(cobj);
            var fobj = new Friend();
            fobj.DataState = cobj.DataState;
            fobj.Nick = cobj.Nick;
            fobj.Phone = cobj.Phone;
            fobj.Class =  "好友";
            node.Items.push(fobj)
        }
        node.TreeNodes.push(contact);
    }
    
    //提取联系人中的群组/讨论组信息
    var gdata = eval('('+ XLY.Sqlite.Find(fpath,"select * from wa_contacts where phone_label is not null AND phone_label<>'' AND phone_label<>0 AND is_whatsapp_user='1'") +')');
    if(gdata.length>0&&gdata!=null){
        var group = new TreeNode();
        group.Text = "群/讨论组列表";
        group.Type = "Group";
        for(var num in gdata){
            var gobj = new Group();
            gobj.DataState = XLY.Convert.ToDataState(gdata[num].XLY_DataType);
            gobj.ID = gdata[num].jid;   //用户ID
            gobj.Nick = gdata[num].display_name; //用户昵称
            gobj.Status = gdata[num].status;   //在线状态
            gobj.Author = gdata[num].number;    //电话号码
            gobj.Time = XLY.Convert.LinuxToDateTime(gdata[num].phone_label);   //登录时间
            if(XLY.File.IsValid(mpath)){
                if(gdata[num].XLY_DataType==2){
                    var mdata = eval('('+ XLY.Sqlite.Find(mpath,"select * from group_participants where gjid = '"+gdata[num].jid+"'") +')');
                    var mdata1 = eval('('+ XLY.Sqlite.Find(mpath,"select * from group_participants_history where gjid = '"+gdata[num].jid+"'") +')');
                    if(mdata.length>0&&mdata!=null){
                        for(var j in mdata1){
                            if(mdata1[j].jid !=null && mdata1[j].jid !=""){
                                gobj.IsDelete = "是"+"\r\n"+"移除成员为:"+mdata1[j].jid;
                            }
                            else
                            {
                                gobj.IsDalete = "否";
                            }
                        }
                        for(var j in mdata){
                            if(mdata[j].admin==1){
                                if(mdata[j].jid ==""||mdata[j].jid==null){
                                    var authorid = gdata[num].jid.split("-");
                                    gobj.Author = user.Nick+"("+authorid[0]+"@s.whatsapp.net)";
                                }
                                else
                                {
                                    gobj.Author = getMessagerInfo(fpath,mdata[j].jid);
                                }
                            }
                            if(mdata[j].jid.length>0&&mdata[j].jid != null){
                                var authorid1 = gdata[num].jid.split("-");
                                (j==0)?gobj.Member = authorid1[0]+"@s.whatsapp.net"+";\r\n"+getMessagerInfo(fpath,mdata[j].jid)+";\r\n":gobj.Member += authorid1[0]+"@s.whatsapp.net"+";\r\n"+getMessagerInfo(fpath,mdata[j].jid)+";\r\n";
                            }
                        }
                    }
                }
            }
            group.Items.push(gobj);
            var fobj = new Friend();
            fobj.DataState = gobj.DataState;
            fobj.Nick = gobj.Nick;
            fobj.Phone = gobj.ID;
            fobj.Class =  "群组";
            node.Items.push(fobj)
        }
        node.TreeNodes.push(group);
    }
    //提取联系人中的手机通讯录信息
    var sdata = eval('('+ XLY.Sqlite.Find(fpath,"select * from wa_contacts where is_whatsapp_user = 0") +')');
    if(sdata.length>0&&sdata!=null){
        var group = new TreeNode();
        group.Text = "手机通讯录列表";
        group.Type = "SContact";
        for(var index in sdata){
            var sobj = new SContact();
            sobj.DataState = XLY.Convert.ToDataState(sdata[index].XLY_DataType);
            sobj.Nick = sdata[index].display_name; //用户昵称
            sobj.Phone = sdata[index].number;    //电话号码
            sobj.ID = sdata[index].jid;//账号id
            group.Items.push(sobj);
            var fobj = new Friend();
            //fobj.DataState = gobj.DataState;
            fobj.Nick = sobj.Nick;
            fobj.Phone = sobj.Phone;
            fobj.Class =  "手机通讯录";
            node.Items.push(fobj)
        }
        node.TreeNodes.push(group);
        
    }
}


function buildConversationNode(mpath,fpath,node,userinfo){
    var ccdata = eval('('+ XLY.Sqlite.Find(mpath,"select distinct(key_remote_jid) from messages where  key_remote_jid like '%net' AND status<>6") +')');
    //var ccdata = eval('('+ XLY.Sqlite.Find(mpath,"select distinct m.[key_remote_jid],c.[key_remote_jid] as cid,c.[subject] from messages as m left join chat_list as c on  m.[key_remote_jid] = c.[key_remote_jid] where c.[subject] is null") +')');
    if(ccdata.length>0&& ccdata!= null){
        var cmessage = new TreeNode();
        cmessage.Text = "好友会话";
        cmessage.Type = "Message";
        buildMessageList(mpath,fpath,ccdata,cmessage,userinfo);
        node.TreeNodes.push(cmessage);
    }
    //var gcdata = eval('('+ XLY.Sqlite.Find(mpath,"select distinct m.[key_remote_jid],c.[key_remote_jid] as cid,c.[subject] from messages as m left join chat_list as c on  m.[key_remote_jid] = c.[key_remote_jid] where c.[subject] is not null") +')');
    var gcdata = eval('('+ XLY.Sqlite.Find(mpath,"select distinct(key_remote_jid) from messages where  key_remote_jid like '%us'") +')');
    if(gcdata.length>0&& gcdata!= null){
        var gmessage = new TreeNode();
        gmessage.Text = "群/讨论组会话";
        gmessage.Type = "Message";
        buildMessageList(mpath,fpath,gcdata,gmessage,userinfo);
        node.TreeNodes.push(gmessage);
    }
    var gbcdata = eval('('+ XLY.Sqlite.Find(mpath,"select distinct(key_remote_jid) from messages where  key_remote_jid like '%broadcast'") +')');
    if(gbcdata.length>0&& gbcdata!= null){
        var gbmessage = new TreeNode();
        gbmessage.Text = "广播";
        gbmessage.Type = "Message";
        buildMessageList(mpath,fpath,gbcdata,gbmessage,userinfo);
        node.TreeNodes.push(gbmessage);
    }
}

function buildMessageList(mpath,fpath,data,node,userinfo){
    if(data.length>0&&data != null){
        for(var i in data){
            if(data[i].key_remote_jid==-1){
                continue;
            }
            var childnode  = new TreeNode();
            childnode.Text = getMessagerInfo(fpath,data[i].key_remote_jid,userinfo);
            childnode.Type = "Message";
            childnode.Items = getMessageInfo(mpath,data[i].key_remote_jid,childnode.Text,userinfo);
            node.TreeNodes.push(childnode);
        }
    }
}

function getMessageInfo(path,id,messager,userinfo){
    if(id==-1){
        return;
    }
    var data2 = messager.split("@");
    var data = eval('('+ XLY.Sqlite.Find(path,"select *,cast(media_wa_type as int)as type  from messages where key_remote_jid = '"+id+"' ") +')');
    if(data.length>0&&data!= null){
        var msgs = new Array();
        for(var i in data){
            if(data[i].status != 6||data[i].type==8){
                if(data2[1]=="broadcast"){
                    var data3=eval('('+ XLY.Sqlite.Find(path,"select remote_resource from messages where key_remote_jid = '"+messager+"'") +')');
                    var mobj = new Message();
                    mobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);  //数据状态
                    if(data[i].key_from_me==1){//我发送消息
                        mobj.SenderName = userinfo.Nick;   //消息发送者
                        mobj.Number = data3[2].remote_resource;   //消息接收者
                        mobj.SendState = "发送";
                    }
                    else//我接收消息
                    {
                        mobj.Number = userinfo.Nick;
                        mobj.SenderName = messager;
                        mobj.SendState = "接收";
                    }

                    mobj.Content = data[i].data;  //内容
                    mobj.Date = XLY.Convert.LinuxToDateTime(data[i].timestamp);  //消息发送时间
                    //mobj.Type = "String";   //类型
                    switch(data[i].type){
                        case 0: mobj.Type = "文本";
                        break;
                        case 1: mobj.Type = "图片";
                        
                        mobj.Content = "图片存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n图片大小:"+data[i].media_size+"byte";
                        break;
                        case 2: mobj.Type = "音频";
                        if(data[i].origin==1){
                            mobj.Content = "音频存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n音频大小:"+data[i].media_size+"byte"+";\r\n音频时长:"+data[i].media_duration+"s";
                        }
                        if(data[i].origin==0){
                            mobj.Content = "音频存储路径为:"+getMediaPath(256,0,data[i].media_name,userinfo)+";\r\n音频大小:"+data[i].media_size+"byte";
                        }
                        break;
                        case 3: mobj.Type = "视频";
                        mobj.Content = "视频存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n视频大小:"+data[i].media_size+"byte"+";\r\n视频时长:"+data[i].media_duration+"s";
                        break;
                        case 4: mobj.Type = "个人名片";
                        break;
                        case 5: mobj.Type = "地理位置";
                        mobj.Content = "地理位置经度:"+data[i].longitude+";\r\n地理位置纬度:"+data[i].latitude;
                        break;
                        case 8: 
                        if(data[i].media_caption=="audio"){
                            mobj.Type = "语音通话";
                        }
                        if(data[i].media_caption=="video"){
                            mobj.Type = "视频通话";
                        }
                        mobj.Content = /*"数据文件存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+*/"数据文件大小:"+data[i].media_name+"byte"+";\r\n视频时长:"+data[i].media_duration+"s";
                        break;
                        break;

                        case 9: mobj.Type = "文件";
                        mobj.Content = "文件存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n文件大小:"+data[i].media_size+"byte";
                        break;
                        case 13:
                        mobj.Type = "动态图";
                        mobj.Content = "动态图存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n动态图大小:"+data[i].media_size+"byte";
                        break;
                      default:
                        mobj.Type = "未知类型";
                        break;
                    }
                    //mobj.SendState = "None";    //发送状态
                    data[i].starred==1?mobj.Starred="已收藏":mobj.Starred = "未收藏";
                    msgs.push(mobj);
                }
                else
                {
                    var mobj = new Message();
                    mobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);  //数据状态
                    if(data[i].key_from_me==1){//我发送消息
                        mobj.SenderName = userinfo.Nick;   //消息发送者
                        mobj.Number = messager;   //消息接收者
                        mobj.SendState = "发送";
                    }
                    else//我接收消息
                    {
                        mobj.Number = userinfo.Nick;
                        mobj.SenderName = messager;
                        mobj.SendState = "接收";
                    }

                    mobj.Content = data[i].data;  //内容
                    mobj.Date = XLY.Convert.LinuxToDateTime(data[i].timestamp);  //消息发送时间
                    //mobj.Type = "String";   //类型
                    switch(data[i].type){
                        case 0: mobj.Type = "文本";
                        break;
                        case 1: mobj.Type = "图片";
                        
                        mobj.Content = "图片存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n图片大小:"+data[i].media_size+"byte";
                        break;
                        case 2: mobj.Type = "音频";
                        if(data[i].origin==1){
                            mobj.Content = "音频存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n音频大小:"+data[i].media_size+"byte"+";\r\n音频时长:"+data[i].media_duration+"s";
                        }
                        if(data[i].origin==0){
                            mobj.Content = "音频存储路径为:"+getMediaPath(256,0,data[i].media_name,userinfo)+";\r\n音频大小:"+data[i].media_size+"byte";
                        }
                        break;
                        case 3: mobj.Type = "视频";
                        mobj.Content = "视频存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n视频大小:"+data[i].media_size+"byte"+";\r\n视频时长:"+data[i].media_duration+"s";
                        break;
                        case 4: mobj.Type = "个人名片";
                        break;
                        case 5: mobj.Type = "地理位置";
                        mobj.Content = "地理位置经度:"+data[i].longitude+";\r\n地理位置纬度:"+data[i].latitude;
                        break;
                        case 8: 
                        if(data[i].media_caption=="audio"){
                            mobj.Type = "语音通话";
                        }
                        if(data[i].media_caption=="video"){
                            mobj.Type = "视频通话";
                        }
                        mobj.Content = /*"数据文件存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+*/"数据文件大小:"+data[i].media_name+"byte"+";\r\n视频时长:"+data[i].media_duration+"s";
                        break;
                        break;

                        case 9: mobj.Type = "文件";
                        mobj.Content = "文件存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n文件大小:"+data[i].media_size+"byte";
                        break;
                        case 13:
                        mobj.Type = "动态图";
                        mobj.Content = "动态图存储路径为:"+getMediaPath(data[i].type,data[i].key_from_me,data[i].media_name,userinfo)+";\r\n动态图大小:"+data[i].media_size+"byte";
                        break;
                      default:
                        mobj.Type = "未知类型";
                        break;
                    }
                    //mobj.SendState = "None";    //发送状态
                    data[i].starred==1?mobj.Starred="已收藏":mobj.Starred = "未收藏";
                    msgs.push(mobj);
                }
            }
        }
        return msgs;
    }
}

function getMediaPath(type,flag,name,userinfo){
    //log(userinfo.SDpath);
    var spath = "";
    if(userinfo.SDpath!=null||userinfo.SDpath.length>0){
        var spath = userinfo.SDpath.substr(0,userinfo.SDpath.indexOf("/WhatsApp/Media/"));
    }
    var opath = spath+"/WhatsApp/Media/";
    
    switch(type){
        case 1: opath += "WhatsApp Images/";
        break;
        
        case 2: opath += "WhatsApp Audio/";
        break;
        
        case 3: opath += "WhatsApp Vedio/";
        break;
        
        case 9: opath += "WhatsApp Documents/";
        break;
        case 256: opath += "WhatsApp Voice Notes/";
        break;
        case 13: opath += "WhatsApp Animated Gifs/";
        break;
        case 13: opath += "WallPaper/";
        break;
      default:
        break;
    }
    if(flag==1){
        opath += "Sent/"+name;
    }
    if(flag==0){
        opath += name;
    }
    return opath;
}


function getMessagerInfo(path,id){
    if(id ==null){
        return;
    }
    var data = eval('('+ XLY.Sqlite.Find(path,"select display_name from wa_contacts where jid = '"+id+"'") +')');
    if(data.length>0&&data!= null){
        if(data[0].display_name!=null&&data[0].display_name.length>0){
            return data[0].display_name+"("+id+")";
        }
        return id;
    }else{
        return id;
    }
}