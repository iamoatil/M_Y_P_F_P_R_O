﻿/*[config]
<plugin name="LinkedIn,10" group="社交聊天,2" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\LinkedIn.png" app="com.linkedin.android" version="6.0.19" description="LinkedIn" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.linkedin.android/shared_prefs/auth_library_prefs.xml</value>
    <value>/data/data/com.linkedin.android/databases#F</value>
</source>
<data type="Account" contract = "DataState">
<item name="账号" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
<item name="职业" code="Professional" type="string" width = "120" ></item>
</data>
<data type="Contact" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
<item name="背景图" code="Back" type="string" width = "120" ></item>
</data>
<data type="Fmsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="名称" code="Name" type="string" width = "120" ></item>
<item name="ID" code="ID" type="string"  width = "120" ></item>
</data>
<data type="FrMsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者" code="Sender" type="string" width="120" ></item>
<item name="接收者" code="Receiver" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="附件" code="Attatchment" type="string" width = "120" ></item>
<item name="附件类型" code="Type" type="string" width = "120" ></item>
<item name="链接" code="Url" type="string" width = "120" ></item>
<item name="表情" code="Emoji" type="string" width = "120" ></item>
</data>
</plugin>
[config]*/
function Account() {
    this.Name = "";
    this.ID = "";
    this.Professional = "";
    this.Avatar = "";
}
function Contact() {
    this.Name = "";
    this.ID = "";
    this.Back = "";
    this.Avatar = "";
    this.DataState = "Normal";
}
function Fmsg() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
}
function FrMsg() {
    this.DataState = "Normal";
    this.Sender = "";
    this.Emoji = "";
    this.Receiver = "";
    this.Time = "";
    this.Attatchment = "";
    this.Content = "";
    this.Type = "";
    this.Url = "";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "LinkedIn";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
 for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account"; 
        news.TreeNodes.push(account);
        
        var contact = new TreeNode();
        contact.Text = "联系人";
        contact.Type = "Contact";
        var contactinfo = getContact(db1);   
        contact.Items = contactinfo;
        account.TreeNodes.push(contact); 
        
        var msg = new  TreeNode();
        msg.Text = "消息";
        msg.Type = "Fmsg";
        msginfo = getFmsg(db2);
        msg.Items = msginfo;
        msg.DataState = "Normal";
        account.TreeNodes.push(msg);
        
           for(var k in msginfo){  
                var fmsg = new TreeNode();
                fmsg.Text = msginfo[k].Name;     
                fmsg.Type = "FrMsg";
                fmsg.Items = getFrMsg(db2,msginfo[k],accountinfo);              
                fmsg.DataState = "Normal";    
                msg.TreeNodes.push(fmsg);
           }
        
 }   
      result.push(news);
} 
 function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')'); 
    var obj = new Account();
    var info = data.map.string;
    for(var i in info){        
        if(info[i]["@name"] == "auth_full_name"){
            obj.Name = info[i]["#text"];
        }
         if(info[i]["@name"] == "auth_picture_url"){
            obj.Avatar = info[i]["#text"];
        }
        if(info[i]["@name"] == "auth_username"){
            obj.ID = info[i]["#text"];               
        }
        if(info[i]["@name"] == "auth_headline"){
            obj.Professional = info[i]["#text"];
        }       
    }
    list.push(obj); 
    return list;
}
function getContact(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from connections" ) +')');   
    for(var i in data){
        var obj = new Contact();
        obj.Name = data[i].lastName+data[i].firstName;
        obj.ID = data[i].publicIdentifier;
        obj.Back = data[i].backgroundImage;
        obj.Avatar = data[i].picture;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFmsg(path){
     var list = new Array();
     var data = eval('('+ XLY.Sqlite.Find(path,"select * from conversations_ui") +')'); 
        for(var i in data){
            var obj = new Fmsg();
            obj.Name = data[i].title;
            obj.ID = data[i].conversation_id;
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
        return list;
}
    function getFrMsg(path,msginfo,accountinfo){
      var list = new Array();
      var data = eval('('+ XLY.Sqlite.Find(path,"select * from events e left join message_events m on e.[_id] = m.event_id left join attachments a on a.[message_event_id] = m._id left join\
       sticker_events s on s.[event_id] = e.[_id] left join actors ac on e.actor_id = ac.[_id]  where conversation_id = '"+msginfo.ID+"'" ) +')');
        for(var i in data){
            var obj = new FrMsg();
            var sendpeople = data[i].last_name+data[i].first_name;
            if(sendpeople == msginfo.Name){
                obj.Sender = accountinfo[0].Name;
            }
            else
            {
                obj.Sender = sendpeople;
            } 
            obj.ID = data[i].remote_id;
            obj.Receiver = msginfo.Name;
            obj.Content = data[i].body;
            obj.Attatchment = data[i].file_name;
            obj.Type = data[i].media_type;
            obj.Url = data[i].url;
            obj.Emoji = data[i].media_id;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp)
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
        return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1]+"\\connections.db";
var db2 = source[1]+"\\linkedin_messenger.db";

var charactor = "\\chalib\\Android_LinkedIn_V6.0.19\\connections.db.charactor";
var charactor1 = "\\chalib\\Android_LinkedIn_V6.0.19\\linkedin_messenger.db.charactor";

//var db = "D:\\temp\\data\\data\\com.linkedin.android\\shared_prefs\\auth_library_prefs.xml";
//var db3 = "D:\\temp\\data\\data\\com.linkedin.android\\databases\\connections.db";
//var db2= "D:\\temp\\data\\data\\com.linkedin.android\\databases\\linkedin_messenger.db";
//var charactor = "D:\\temp\\data\\data\\com.linkedin.android\\databases\\connections.db.charactor";
//var charactor1 = "D:\\temp\\data\\data\\com.linkedin.android\\databases\\linkedin_messenger.db.charactor";
//var db1 = XLY.Sqlite.DataRecovery(db3,charactor , "connections");
//var db2 = XLY.Sqlite.DataRecovery(db4,charactor1 , "events,message_events,attachments,sticker_events,actors");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
