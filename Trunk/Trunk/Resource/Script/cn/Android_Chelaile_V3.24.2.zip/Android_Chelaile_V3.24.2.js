﻿/*[config]
<plugin name="车来了,3" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/chelaile.png" app="com.ygkj.chelaile.standard" version="3.24.2" description="车来了" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.ygkj.chelaile.standard#F</value>
</source>

<data type="News" contract = "DataState">Schemedetail
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="AppName" type="string" width="120" format=""></item>
    <item name="版本" code="Version" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="120" format=""></item>
    <item name="昵称" code="NickName" type="string" width="120" format=""></item>
    <item name="头像链接" code="PhotoUrl" type="string" width="120" format=""></item>
    <item name="上次登录时间" code="LastCheckInTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Select" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="120" format=""></item>
    <item name="类型" code="Type" type="string" width="120" format=""></item>
    <item name="查询内容" code="ItemName" type="string" width="120" format=""></item>
    <item name="查询描述" code="ItemDescription" type="string" width="120" format=""></item>
    <item name="查询时间" code="CreatedTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="修改时间" code="UpdateTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="查询地点归属区" code="SelectDetail" type="string" width="120" format=""></item>
</data>
<data type="CommonlyAddress" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="序号" code="Id" type="string" width="120" format=""></item>
    <item name="地点名" code="Name" type="string" width="120" format=""></item>
    <item name="经度" code="Lat" type="string" width="120" format=""></item>
    <item name="纬度" code="Ing" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreatedTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="修改时间" code="UpdateTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="地址" code="Address" type="string" width="120" format=""></item>
</data>
<data type="Search" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="起始位置" code="StartName" type="string" width="120" format=""></item>
    <item name="起始经度" code="StartLat" type="string" width="120" format=""></item>
    <item name="起始纬度" code="SatrtIng" type="string" width="120" format=""></item>
    <item name="终点位置" code="EndName" type="string" width="120" format=""></item>
    <item name="终点经度" code="EndLat" type="string" width="150" format = ""></item>
    <item name="终点纬度" code="EndIng" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreatedTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="修改时间" code="UpdateTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="Start_id" code="StartId" type="string" width="120" format=""></item>
    <item name="End_id" code="EndId" type="string" width="120" format=""></item>
</data>
<data type="LastSearchRoad" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="详细路线" code="SchemeDetail" type="string" width="120" format=""></item>
    <item name="起始位置" code="StartName" type="string" width="120" format=""></item>
    <item name="起始经度" code="StartLat" type="string" width="120" format=""></item>
    <item name="起始纬度" code="SatrtIng" type="string" width="120" format=""></item>
    <item name="终点位置" code="EndName" type="string" width="120" format=""></item>
    <item name="终点经度" code="EndLat" type="string" width="150" format = ""></item>
    <item name="终点纬度" code="EndIng" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreatedTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="修改时间" code="UpdateTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.AppName = "";
    this.DataState = "Normal";
    this.Version = "";
}

//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.Id = "";
    this.NickName = "";
    this.PhotoUrl = "";
    this.LastCheckInTime = null;
}

//定义Select数据结构
function Select(){
    this.DataState = "Normal";
    this.Id = "";
    this.Type = "";
    this.ItemName = "";
    this.ItemDescription = "";
    this.CreatedTime = null;
    this.UpdateTime = null;
    this.SelectDetail = "";
}

//定义CommonlyAddress数据结构
function CommonlyAddress(){
    this.DataState = "Normal";
    this.Id = "";
    this.Name = "";
    this.Lat = "";
    this.Ing = "";
    this.CreatedTime = null;
    this.UpdateTime = null;
    this.Address = "";
}

//定义LastSearchRoad数据结构
function LastSearchRoad(){
    this.DataState = "Normal";
    this.SchemeDetail = "";
    this.StartName = "";
    this.StartLat = "";
    this.SatrtIng = "";
    this.EndName = "";
    this.EndLat = "";
    this.EndIng = "";
    this.CreatedTime = null;
    this.UpdateTime = null;
}
//定义Search数据结构
function Search(){
    this.DataState = "Normal";
    this.StartName = "";
    this.StartLat = "";
    this.SatrtIng = "";
    this.EndName = "";
    this.EndLat = "";
    this.EndIng = "";
    this.CreatedTime = null;
    this.UpdateTime = null;
    this.StartId = "";
    this.EndId = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dpath1 = source[0]+"\\databases\\com.ygkj.chelaile.db";
var upath = source[1]+"\\shared_prefs\\com.yg84.cll.sdk.xml";
//测试数据
//var dpath = "C:\\Users\\Administrator\\Desktop\\何升-车来了脚本分析\\何升-车来了脚本分析\\com.ygkj.chelaile.standard\\databases\\com.ygkj.chelaile.db";
//var upath = "C:\\Users\\Administrator\\Desktop\\何升-车来了脚本分析\\何升-车来了脚本分析\\com.ygkj.chelaile.standard\\shared_prefs\\com.yg84.cll.sdk.xml";
//
//定义特征库文件
var charactor = "chalib\\Android_Chelaile_V3.24.2\\com.ygkj.chelaile.db.charactor";

//恢复数据库中删除的数据
var dpath = XLY.Sqlite.DataRecovery(dpath1, charactor,"cll_query_history,cll_transit_query_history,cll_transit_scheme_history,cll_transit_scheme_detail_history");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "车来了";
    root.Type = "News";
    root.Items.push(getNews(root,upath,dpath));
    
    result.push(root);
}
//获取软件信息
function getNews(root,upath,dpath){
    var robj = new News();
    robj.AppName = "车来了";
    robj.Version = "3.24.2";
    var userobj = new TreeNode();
    userobj.Text = getUserInfoName(upath).NickName;
    userobj.Type = "UserInfo";
    userobj.Items.push(getUserInfo(upath));
    root.TreeNodes.push(userobj);
    
    var childnodeSel = new TreeNode();
    childnodeSel.Text = "查询";
    childnodeSel.Type = "Select";
    childnodeSel.Items = getSelect(dpath);
    
    var childnodeCom = new TreeNode();
    childnodeCom.Text = "常用地址";
    childnodeCom.Type = "CommonlyAddress";
    childnodeCom.Items = getCommonlyAddress(dpath);
    
    var childnodeSearch = new TreeNode();
    childnodeSearch.Text = "搜索路线";
    childnodeSearch.Type = "Search";
    childnodeSearch.Items = getSearch(dpath);
    
    var childnodeLastS = new TreeNode();
    childnodeLastS.Text = "最近查询路线";
    childnodeLastS.Type = "LastSearchRoad";
    childnodeLastS.Items.push(getLastSearch(dpath));
    
    root.TreeNodes.push(childnodeSel);
    root.TreeNodes.push(childnodeCom);
    root.TreeNodes.push(childnodeSearch);
    root.TreeNodes.push(childnodeLastS);
    return robj;    
}
//获取用户昵称
function getUserInfoName(path){
    if(XLY.File.IsValid(upath)){
        try
        {
            var data = eval('(' + XLY.File.ReadXML(upath) + ')');
            var userdata = data.map.string;
            for(var i in userdata){
                if(userdata[i]['@name']=="cache.account"){
                    var uobj = new UserInfo();
                    var ldata = eval('('+ userdata[i]['#text'] +')');
                    uobj.NickName = ldata.nickname;
                    return uobj;
                }
            }
        }
        catch(err)
        {
            return err;
        }
    }
}
//获取用户信息
function getUserInfo(upath) {
    if(XLY.File.IsValid(upath)){
        try
        {
            var data = eval('(' + XLY.File.ReadXML(upath) + ')');
            var userdata = data.map.string;
            for(var i in userdata){
                if(userdata[i]['@name']=="cache.account"){
                    var uobj = new UserInfo();
                    var ldata = eval('('+ userdata[i]['#text'] +')');
                    uobj.DataState = XLY.Convert.ToDataState(ldata.XLY_DataState);
                    uobj.Id = ldata.accountId;
                    uobj.NickName = ldata.nickname;
                    uobj.PhotoUrl = ldata.photoUrl;
                    uobj.LastCheckInTime = XLY.Convert.LinuxToDateTime(ldata.lastCheckInTime);
                    return uobj;
                }
            }
        }
        catch(err)
        {
            return err;
        }
    }
}
//获取查询信息
function getSelect(path){
    if(XLY.File.IsValid(path)){
        try
        {
            var seldata = eval('('+ XLY.Sqlite.Find(path,"select * from cll_query_history") +')');
            if(seldata !=""&&seldata != null){
                var arr = new Array();
                for(var i in seldata){
                    var selobj = new Select();
                    selobj.DataState = XLY.Convert.ToDataState(seldata[i].XLY_DataState);
                    selobj.Id = seldata[i].xly_id;
                    if(seldata[i].type==1){
                        selobj.Type = "公交路线";
                    }
                    else if(seldata.type==2){
                        selobj.Type = "站台名";
                    }
                    else
                    {
                        selobj.Type = "线路";
                    }
                    selobj.ItemName = seldata[i].item_name;
                    if(seldata[i].item_desc_1 ==""||seldata[i].item_desc_1==null&&seldata[i].item_desc_2!=""&&seldata[i].item_desc_2!=null){
                        selobj.ItemDescription = seldata[i].item_desc_2;
                    }
                    else if(seldata[i].item_desc_2 ==""||seldata[i].item_desc_2==null&&seldata[i].item_desc_1!=""&&seldata[i].item_desc_1!=null){
                        selobj.ItemDescription = seldata[i].item_desc_1;
                    }
                    else
                    {
                        selobj.ItemDescription = seldata[i].item_desc_1+","+seldata[i].item_desc_2;
                    }
                    selobj.CreatedTime = XLY.Convert.LinuxToDateTime(seldata[i].create_time);
                    selobj.UpdateTime = XLY.Convert.LinuxToDateTime(seldata[i].update_time);
                    selobj.SelectDetail = seldata[i].item_detail;
                    arr.push(selobj);
                }
                return arr;
            }
        }
        catch(err)
        {
            return err;
        }
    }
}
//获取常用地址信息
function getCommonlyAddress(path){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from cll_transit_query_history") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var comobj = new CommonlyAddress();
                comobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                comobj.Id = data[i].xly_id;
                comobj.Name = data[i].name;
                comobj.Lat = data[i].lat;
                comobj.Ing = data[i].lng;
                comobj.CreatedTime = XLY.Convert.LinuxToDateTime(data[i].create_time);
                comobj.UpdateTime = XLY.Convert.LinuxToDateTime(data[i].update_time);
                comobj.Address = data[i].address;
                arr.push(comobj);
            }
        }
        return arr;
    }
}
//获取搜索路线信息
function getSearch(path){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from cll_transit_scheme_history") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var searobj = new Search();
                searobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                searobj.StartName = data[i].start_name;
                searobj.StartLat = data[i].start_lat;
                searobj.SatrtIng = data[i].start_lng;
                searobj.EndName = data[i].end_name;
                searobj.EndLat = data[i].end_lat;
                searobj.EndIng = data[i].end_lng;
                searobj.CreatedTime = XLY.Convert.LinuxToDateTime(data[i].create_time);
                searobj.UpdateTime = XLY.Convert.LinuxToDateTime(data[i].update_time);
                searobj.StartId = data[i].start_id;
                searobj.EndId = data[i].end_id;
                arr.push(searobj);
            }
        }
        return arr;
    }
}
//获取最后一次查询路线
function getLastSearch(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from cll_transit_scheme_detail_history") +')');
        if(data!=""&&data!=null){
            var lsdata = new LastSearchRoad();
            lsdata.DataState = XLY.Convert.ToDataState(data[0].XLY_DataState);
            lsdata.SchemeDetail = SchemeDetail(data[0].scheme_detail);
            
            lsdata.StartName = data[0].start_name;
            lsdata.StartLat = data[0].start_lat;
            lsdata.SatrtIng = data[0].start_lng;
            lsdata.EndName = data[0].end_name;
            lsdata.EndLat = data[0].end_lat;
            lsdata.EndIng = data[0].end_lng;
            lsdata.CreatedTime = XLY.Convert.LinuxToDateTime(data[0].create_time);
            lsdata.UpdateTime = XLY.Convert.LinuxToDateTime(data[0].update_time);
            return lsdata;
        }
    }
}
//
function SchemeDetail(info){
    var data = "";
    var dat1 = eval('('+ info +')').f;
    for(var i in dat1){
        data+= "从"+dat1[i].a.d+"到"+dat1[i].a.e+",前行"+dat1[i].a.a+"m,预计"+dat1[i].a.b+"秒.";
        //if(dat1[i].b.a[0].b){
        //    data+= dat1[i].b.a[0].c.a+"进";
        //}
        //var data2=new Array();
        //data2 = dat1[i].b.a[0].q;
        //for(var j in data2){
        //    data+= data2[j].b+"("+data2[j].c.lat+","+data2[j].c.lng+")"+"---->";
        //}
        //if(dat1[i].b.a[0].b==0){
        //    data+=dat1[i].b.a[0].d.a+"出";
        //}
    }
    return data;
}
