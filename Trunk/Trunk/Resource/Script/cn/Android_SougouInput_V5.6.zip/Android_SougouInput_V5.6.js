﻿/*[config]
<plugin name=" 搜狗输入法,14" group="基本信息,1" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\SougouInput.png" app="com.sohu.inputmethod.sogou" version="5.6" description="搜狗输入法" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.sohu.inputmethod.sogou/files/dict/#F</value>
</source>

<data type="Group">
    <item name="类别" code="group" type="string" width=""></item>
</data>

<data type="Node">
    <item name="常用字" code="chinese" type="string" width="" ></item>
</data>

</plugin>
[config]*/


//定义Group数据结构
function Group() {
    this.group = "";
}

//定义Node数据结构
function Node() {
    this.chinese = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//创建app的根节点
function bindTree() { 
    var filepath = eval('('+ XLY.File.FindFiles(path) +')');
    var rootNode = new TreeNode();
    rootNode.Text = "搜狗输入法";
    rootNode.Type = "Group";
    buildChildNode(filepath,rootNode);
    //log(rootNode);
    return rootNode;
}

//创建子节点
function buildChildNode(data,parents){
    for(var i in data){
        var flag = XLY.File.GetFileName(data[i]);
        if((/sgim_usrbg.bin/).test(data[i])){
            getTreeInfo(parents,"QQ常用字词",data[i]);
        }
        else if((/usr_map/).test(data[i]))
        {
            getTreeInfo(parents,"导航常用字词",data[i]);
        }
        else if((/usr_jpdata/).test(data[i]))
        {
            getTreeInfo(parents,"wifi状态下常用字词",data[i]);
        }
        else if((/s+[0-9]+_usrbg/).test(data[i]))
        {
            getTreeInfo(parents,"短信常用字词",data[i]);
        }
        else if((/sgim_cm/).test(data[i]))
        {
            getTreeInfo(parents,"联系人常用字词",data[i]);
        }
        else if((/usr_shop/).test(data[i]))
        {
            getTreeInfo(parents,"网购常用字词",data[i]);
        }
        else if((/usr_vedio/).test(data[i]))
        {
            getTreeInfo(parents,"视音频常用字词",data[i]);
        }
        else if((/usr_app/).test(data[i]))
        {
            getTreeInfo(parents,"APP商店常用字词",data[i]);
        }
        else if((/sgim_tr/).test(data[i]))
        {
            getTreeInfo(parents,"微信常用字词",data[i]);
        }
        else if((/sgim_usr.bin/).test(data[i]))
        {
            getTreeInfo(parents,"其他常用字词",data[i]);
        }
    }
}



//获取根节点和子节点的信息
function getTreeInfo(root,name,file){
    
    //获取子节点树状结构
    var node = new TreeNode();
    node.Text = name;
    node.Type = "Node";
    
    //获取根节点信息
    var obj = new Group();
    obj.group = name;
    root.Items.push(obj);
    
    //获取子节点信息
    var data = XLY.File.ReadFile(file,"Unicode");
    var reg = /[\u4E00-\u9FFF]+/g;
    var info = data.match(reg);
    if(info != null){
        var len = info.length;
        for(var index = 1; index<len;index++){
            if(name == "导航常用字词" || name == "网购常用字词") {
                if(info[index].length>1){
                    var obj = new Node();
                    obj.chinese = info[index];
                    node.Items.push(obj);
                }
            }else {
                var obj = new Node();
                obj.chinese = info[index];
                node.Items.push(obj);
            }
        }
    }
    root.TreeNodes.push(node)
}

var result = new Array();
//源文件
var source = $source;
var path= source[0]
//var path = "D:\\debug_files\\com.sohu.inputmethod.sogou\\files\\dict";

// return
result.push(bindTree());
var res = JSON.stringify(result);
res;
