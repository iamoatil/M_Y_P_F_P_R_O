﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="com.sankuai.meituan" version="5.1.2" description="美团" data="$data,LocationInfoDataSource" >
<source>
    <value>/data/data/com.sankuai.meituan/databases/meituan_analyse.db</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "定位信息";
    this.Source = "美团";
    this.StartDate = null;
}

//获取历史搜索树的信息
function getPosition(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from event") + ')');
    var info = new Array();
    try{
    if(data!=null&&data.length>0){
        for (var i in data) {
            var str = eval('(' +data[i].VAL+ ')');
            var loc = str.URL.split("&");
            var arr = [];
            for(var j in loc){
                if(loc[j].indexOf("mypos")>=0){
                    arr = loc[j].replace("mypos = ","").split("%2C");
                    var obj = new Position();
                    obj.Longitude = XLY.Convert.ToDouble(arr[1]);
                    obj.Latitude = XLY.Convert.ToDouble(arr[0]);
                    obj.StartDate = XLY.Convert.LinuxToDateTime(str.endTime);
                    info.push(obj);
                }
                else if(loc[j].indexOf("latlng")>=0){
                    var pos = loc[j].split(",");
                    arr.push(pos[0].split("/")[pos[0].split("/").length-1]);
                    arr.push(pos[1].split("?")[0]);
                    var obj = new Position();
                    obj.Longitude = XLY.Convert.ToDouble(arr[1]);
                    obj.Latitude = XLY.Convert.ToDouble(arr[0]);
                    obj.StartDate = XLY.Convert.LinuxToDateTime(str.endTime);
                    info.push(obj);
                }
               
            }
        }
    }
    return info;
    }
    catch(e){
        return info;
    }
}

var result = new Array();
//源文件路径
var source = $source;
var db = source[0];
//var db = "C:\\Users\\Administrator\\Desktop\\com.sankuai.meituan\\databases\\meituan_analyse.db";
result=getPosition(db);
var res = JSON.stringify(result);
res;
