﻿/*[config]
<plugin name="凯立德导航,10" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Kailide.png" app="cld.navi.mainframe" version="7.5.2" description="凯立德导航" data="$data,ComplexTreeDataSource" >
<source>
 <value>/data/data/cld.navi.mainframe/#F</value>
</source>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="地点" code="POI" type="string" width = "150"></item>
<item name="所属区域" code="District" type="string" width = "200"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
<item name="相对X偏移" code="PoiX" type="string" width = "200"></item>
<item name="凯立德-相对Y偏移" code="NavPoiY" type="string" width = "200"></item>
<item name="相对Y偏移" code="PoiY" type="string" width = "200"></item>
<item name="凯立德-相对X偏移" code="NavPoiX" type="string" width = "200"></item>
<item name="位置ID" code="PoiId" type="string" width = "200"></item>
</data>
<data type="Bus" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点" code="Start" type="string" width = "150"></item>
<item name="终点" code="End" type="string" width = "150"></item>
<item name="起点X" code="StartX" type="string" width = "200"></item>
<item name="起点Y" code="StartY" type="string" width = "200"></item>
<item name="终点X" code="EndX" type="string" width = "200"></item>
<item name="终点Y" code="EndY" type="string" width = "200"></item>
</data>
<data type="Walk" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点" code="Start" type="string" width = "150"></item>
<item name="终点" code="End" type="string" width = "150"></item>
<item name="起点X" code="StartX" type="string" width = "200"></item>
<item name="起点Y" code="StartY" type="string" width = "200"></item>
<item name="终点X" code="EndX" type="string" width = "200"></item>
<item name="终点Y" code="EndY" type="string" width = "200"></item>
</data>
<data type="Contact" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="姓名" code="Name" type="string" width = "150"></item>
<item name="电话" code="Phone" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
</data>
<data type="Trip" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="创建者" code="Creator" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
<item name="内容" code="Content" type="string" width = "200"></item>
<item name="创建者号码" code="Phone" type="string" width = "200"></item>
<item name="加载时间" code="Download" type="string" width = "200"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account() {
    this.ID = "";
}
function Search() {
    this.POI = "";
    this.District = "";
    this.Time = "";
    this.PoiX = "";
    this.NavPoiY = "";
    this.PoiY = "";
    this.NavPoiX = "";
    this.PoiId = "";
    this.DataState="Normal";
}
function Bus() {
    this.Start = "";
    this.End = "";
    this.StartX = "";
    this.StartY = "";
    this.EndX = "";
    this.EndY = "";
    this.DataState="Normal";
}
function Walk() {
    this.Start = "";
    this.End = "";
    this.StartX = "";
    this.StartY = "";
    this.EndX = "";
    this.EndY = "";
    this.DataState="Normal";
}
function Contact() {
    this.Name = "";
    this.Phone = "";
    this.Time = "";
    this.ID = "";
    this.DataState="Normal";
}
function Trip() {
    this.ID = "";
    this.Creator = "";
    this.Time = "";
    this.Content = "";
    this.Phone = "";
    this.Download = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "凯立德导航";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].ID;
        account.Type = "Account";
        account.Items = accountinfo; 
        news.TreeNodes.push(account);
        
        var search = new TreeNode() ;
        search.Text = "搜索";
        search.Type = "Search"; 
        search.Items = getSearch(db1);
        account.TreeNodes.push(search);
        
        var bus = new TreeNode() ;
        bus.Text = "公交搜索";
        bus.Type = "Bus"; 
        bus.Items = getBus(db1);
        account.TreeNodes.push(bus);
        
        var walk = new TreeNode() ;
        walk.Text = "步行搜索";
        walk.Type = "Walk"; 
        walk.Items = getWalk(db1);
        account.TreeNodes.push(walk);
        
        var contact = new TreeNode() ;
        contact.Text = "联系人";
        contact.Type = "Contact"; 
        contact.Items = getContact(db1);
        account.TreeNodes.push(contact);
        
        var trip = new TreeNode() ;
        trip.Text = "结伴出行信息";
        trip.Type = "Trip"; 
        trip.Items = getTrip(db1);
        account.TreeNodes.push(trip);
    }
     result.push(news);
} 

 function getAccount (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');
     var obj = new Account();
     var info = data.map.string;
     for(var i in info){
          if(info[i]["@name"] == "kuid"){
              obj.ID = info[i]["#text"];          
          }
     }
    list.push(obj);
    return list;
 }
function getSearch(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from com_cld_cm_ui_search_util_SearchHistoryBean" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.POI = data[i].poiName;
        obj.District = data[i].districtName;
        obj.PoiX = data[i].poiX;
        obj.NavPoiY = data[i].navPoiY;
        obj.PoiY = data[i].poiY;
        obj.NavPoiX = data[i].navPoiX;
        obj.PoiId = data[i].poiId;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].saveTime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getBus(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from com_cld_cm_util_route_CldBusRouteUtil$BusHistoryBean" ) +')');
    for(var i in data){
        var obj = new Bus();
        obj.Start = data[i].startname;
        obj.End = data[i].endname;
        obj.StartX = data[i].startx;
        obj.StartY = data[i].starty;
        obj.EndX = data[i].endx;
        obj.EndY = data[i].endy;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getWalk(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from com_cld_cm_util_route_CldWalkRouteUtil$WalkHistoryBean" ) +')');
    for(var i in data){
        var obj = new Walk();
        obj.Start = data[i].startname;
        obj.End = data[i].endname;
        obj.StartX = data[i].startx;
        obj.StartY = data[i].starty;
        obj.EndX = data[i].endx;
        obj.EndY = data[i].endy;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getContact(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from com_cld_cm_util_share_CldSysContact" ) +')');
    for(var i in data){
        var obj = new Contact();
        obj.Name = data[i].name;
        obj.Phone = data[i].phone;
        obj.Time = data[i].date;
        obj.ID = data[i].kuid;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getTrip(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from com_cld_ols_module_message_bean_CldKMessage" ) +')');
    for(var i in data){
        var obj = new Trip();
        obj.ID = data[i].dbId;
        obj.Creator = data[i].createuser;
        obj.Time = data[i].createtime;
        obj.Content = data[i].content;
        obj.Phone = data[i].usermobile;
        obj.Download = data[i].downloadtime;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
 //********************************************************
var source = $source;
var db2= source[0]+"\\databases\\E78FAB109909898ED86AF6AAA64E88CA.db"; 
var db= source[0]+"\\shared_prefs\\cld.navi.mainframe.xml";

var charactor = "\\chalib\\Android_5.1_Kailide_7.5.2\\\Kailide.db.charactor";

//var db = "D:\\temp\\data\\data\\cld.navi.mainframe\\shared_prefs\\cld.navi.mainframe.xml";
//var db2 = "D:\\temp\\data\\data\\cld.navi.mainframe\\databases\\E78FAB109909898ED86AF6AAA64E88CA.db";
//
//var charactor = "D:\\temp\\data\\data\\cld.navi.mainframe\\databases\\Kailide.db.charactor";
//
var db1 = XLY.Sqlite.DataRecovery(db2,charactor,"com_cld_cm_ui_search_util_SearchHistoryBean,com_cld_cm_util_route_CldBusRouteUtil$BusHistoryBean,com_cld_cm_util_route_CldWalkRouteUtil$WalkHistoryBean,com_cld_cm_util_share_CldSysContact,com_cld_ols_module_message_bean_CldKMessage");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
