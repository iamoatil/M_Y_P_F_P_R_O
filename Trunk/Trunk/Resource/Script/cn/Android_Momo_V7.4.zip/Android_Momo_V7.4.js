﻿/*[config]
<plugin name="陌陌,5" group="社交聊天,8,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="icons\icon_momo.png" app="com.immomo.momo" version="7.3" description="Test-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.immomo.momo/databases/#F</value>
</source>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="User" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="120" ></item>
<item name="帐号ID" code="Id" type="string" width="100" ></item>
<item name="性别" code="Gender" type="string" width="60" ></item>
<item name="年龄" code="Age" type="string" width="60" ></item>
<item name="生日" code="BrithDay" type="string" width = "140" ></item>
<item name="公司" code="Company" type="string" width = "140" ></item>
<item name="位置" code="City" type="string" width="140" ></item>
<item name="个性签名" code="Signature" type="string" width="180" ></item>
<item name="注册时间" code="RegisterDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
<item name="手机或邮箱" code="TelephoneNumber" type="string" width="120" ></item>
<item name="兴趣爱好" code="Hobby" type="string" width="" ></item>
<item name="职业" code="Profession" type="string" width="" ></item>
<item name="星座" code="Constellation" type="string" width = "" ></item>
<item name="个人简介" code="Introduce" type="string" width="" ></item>
<item name="新浪微博" code="Weibo" type="string" width="" ></item>
<item name="最近联系时间" code="StartDate" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="距离（千米）" code="Distance" type="string" width="120" ></item>
</data>
<data type="Contact" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="120" ></item>
<item name="帐号ID" code="Id" type="string" width="100" ></item>
<item name="性别" code="Gender" type="string" width="60" ></item>
<item name="年龄" code="Age" type="string" width = "60" ></item>
<item name="个人简介" code="Introduce" type="string" width="" ></item>
<item name="新浪微博" code="Weibo" type="string" width="" ></item>
<item name="生日" code="BrithDay" type="string" width = "140" ></item>
<item name="公司" code="Company" type="string" width = "140" ></item>
<item name="位置" code="City" type="string" width="140" ></item>
<item name="个性签名" code="Signature" type="string" width="180" ></item>
<item name="注册时间" code="RegisterDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
<item name="手机或邮箱" code="TelephoneNumber" type="string" width="120" ></item>
<item name="兴趣爱好" code="Hobby" type="string" width="" ></item>
<item name="职业" code="Profession" type="string" width="" ></item>
<item name="星座" code="Constellation" type="string" width="" ></item>
<item name="最近联系时间" code="StartDate" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="距离（千米）" code="Distance" type="string" width="120" ></item>
</data>
<data type="Blacklist"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="拉黑时间" code="StartDate" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>
<data type="Fans"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="关注时间" code="StartDate" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>
<data type="Near"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Discussion" contract="DataState"  datefilter="CreateTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="讨论组名称" code="Name" type="string" width="120" alignment = "center"></item>
<item name="讨论组ID" code="GID" type="string" width="120" alignment="center"></item>
<item name="创建者ID" code="Id" type="string" width="120" format = ""></item>
<item name="成员ID" code="MemberId" type="string" width="120" format=""></item>
<item name="创建时间" code="CreateTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="成员上限" code="Count" type="string" width="" format=""></item>
<item name="讨论组人数" code="Number" type="string" width="60" format = ""></item>
<item name="成员昵称" code="Nick" type="string" width="60" format=""></item>
</data>
<data type="BothFollow"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="关注时间" code="StartDate" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>
<data type="Board"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width="160" alignment="center" ></item>
<item name="时间" code="Time" type="string" width="" format=""></item>
<item name="内容" code="Content" type="string" width="" format=""></item>
<item name="图片" code="Picture" type="string" width="" format="260"></item>
<item name="点赞数" code="ZCount" type="string" width="" format=""></item>
<item name="评论数" code="Count" type="string" width="60" show="false"></item>
<item name="距离（千米）" code="Distance" type="string" width="60"></item>
<item name="发布者陌陌ID" code="MID" type="string" width = "60"></item>
<item name="发布留言位置" code="Place" type="string" width="60"></item>
</data>
<data type="Group" contract="DataState"  datefilter="CreateTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群名称" code="Name" type="string" width="120" alignment="center"></item>
<item name="群号" code="Id" type="string" width="80" format=""></item>
<item name="群创建时间" code="CreateTime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order = "desc"></item>
<item name="加入时间" code="JTime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="" format=""></item>
<item name="群介绍" code="Introduce" type="string" width="" format="200"></item>
<item name="群成员数" code="Number" type="string" width="" format = "60"></item>
<item name="群成员上限" code="Max" type="string" width="" format = "60"></item>
<item name="群经度" code="Lng" type="string" width="" format = "60"></item>
<item name="群维度" code="Lat" type="string" width="" format = "60"></item>
<item name="距离" code="Distance" type="string" width="" format="60"></item>
<item name="群创建地" code="CreatePlace" type="string" width="120" format = ""></item>
</data>
<data type="Message" contract="DataState"  datefilter="CreateTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="160" alignment="center" ></item>
<item name="接收人" code="Receiver" type="string" width="160" alignment="center"></item>
<item name="内容" code="Content" type="string" width="" format = "260"></item>
<item name="发送的文件" code="File" type="string" width="" format="260"></item>
<item name="时间" code="Date" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width="140"></item>
<item name="消息类别" code="MessageType" type="string" width="60"></item>
<item name="发送状态" code="SendState" type="string" width="60"></item>
</data>
<data type="Session"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="聊天类型" code="Type" type="string" width = "150"></item>
<item name="聊天ID" code="ID" type="string" width = "150"></item>
<item name="消息ID" code="MID" type="string" width = "150"></item>
</data>
<data type="Comments"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="评论消息ID" code="ID" type="string" width="160" alignment="center" ></item>
<item name="内容" code="Content" type="string" width="" format=""></item>
<item name="发布者ID" code="FID" type="string" width="" format=""></item>
<item name="时间" code="Time" type="string" width="" format="260"></item>
</data>
</plugin>
[config]*/

// js content

function Info() {
    this.Acc = "";
    this.DataState = "Normal";
}
function Session() {
    this.Type = "";
    this.ID = "";
    this.MID = "";
    this.DataState = "Normal";
}
function User() {
    this.Name = "";
    this.Id = "";
    this.Gender = "";
    this.Age = "";
    this.Introduce = "";
    this.Weibo = "";
    this.BrithDay = "";
    this.Signature = "";
    this.RegisterDate = null;
    this.TelephoneNumber = "";
    this.Hobby = "";
    this.Company = "";
    this.City = "";
    this.Profession = "";
    this.Constellation = "";
    this.StartDate = null;
    this.Distance = "";
    this.DataState = "Normal";
}

function Contact() {
    this.Name = "";
    this.Id = "";
    this.Gender = "";
    this.Age = "";
    this.BrithDay = "";
    this.Signature = "";
    this.RegisterDate = null;
    this.TelephoneNumber = "";
    this.Hobby = "";
    this.Company = "";
    this.City = "";
    this.Introduce = "";
    this.Weibo = "";
    this.Profession = "";
    this.Constellation = "";
    this.StartDate = null;
    this.Distance = "";
    this.DataState = "Normal";
}
function Blacklist() {
    this.ID = "";
    this.StartDate = "";
    this.DataState = "Normal";
}
function Discussion() {
    this.Id = "";
    this.Name = "";
    this.MemberId = "";
    this.CreateTime = null;
    this.Count = "";
    this.Number = "";
    this.Nick = "";
    this.DataState = "Normal";
}
function Board() {
    this.ID = "";
    this.Time = "";
    this.Content = "";
    this.Picture = "";
    this.ZCount = "";
    this.Count = "";
    this.Distance = "";
    this.Place = "";
    this.MID = "";
    this.DataState = "Normal";
}
function Group() {
    this.Id = "";
    this.Name = "";
    this.CreateTime = null;
    this.JTime = null;
    this.Creator = "";
    this.Introduce = "";
    this.Number = "";
    this.Max = "";
    this.Lng = "";
    this.Lat = "";
    this.Type = "";
    this.Distance = "";
    this.CreatePlace = "";
    this.DataState = "Normal";
}
function Comments() {
    this.SenderName = "";
    this.ID = "";
    this.Content = "";
    this.FID = "";
    this.Time = "";
    this.LID = "";
    this.LContent = "";
    this.DataState = "Normal";
}
function Message() {
    this.SenderName = "";
    this.Receiver = "";
    this.Date = null;
    this.Content = "";
    this.MessageType = "";
    this.Type = "";
    this.File = "";
    this.SendState = "";
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}
function bindTree() {
    var news = new TreeNode();
    news.Text = "陌陌";
    news.Type = "Info";
    //accountinfo = getAccount(db1);
    //news.Items = accountinfo;
    news.DataState = "Normal";

    var news1 = new TreeNode();
    news1.Text = "账号";
    news1.Type = "Info";
    accountinfo = getInfo(db);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    for (var i in accountinfo) {
        var account = new TreeNode();
        account.Text = accountinfo[i].Acc;
        account.Type = "Info";
        news1.TreeNodes.push(account);

        var abc = db + "\\" + accountinfo[i].Acc;
        var bcd = db + "\\feed60_" + accountinfo[i].Acc;
        var cde = db + "\\momo_" + accountinfo[i].Acc;

        var user = new TreeNode();
        user.Text = "帐号信息";
        user.Type = "User";
        var userinfo = getUser(abc, accountinfo[i]);
        user.Items = userinfo;
        account.TreeNodes.push(user);

        var blacklist = new TreeNode();
        blacklist.Text = "黑名单";
        blacklist.Type = "Blacklist";
        blacklist.Items = getBlacklist(abc, accountinfo[i]);
        account.TreeNodes.push(blacklist);

        var user = new TreeNode();
        user.Text = "联系人";
        user.Type = "Contact";
        user.Items = getContact(abc, accountinfo[i]);
        account.TreeNodes.push(user);
        buildContactSubNode(user, user.Items, abc, accountinfo[i]);

        var discuss = new TreeNode();
        discuss.Text = "讨论组";
        discuss.Type = "Discussion";

        var discussinfo = getDiscussion(abc, accountinfo[i]);
        discuss.Items = discussinfo;
        account.TreeNodes.push(discuss);

        var group = new TreeNode();
        group.Text = "加入的群";
        group.Type = "Group";
        var groupinfo = getGroup(cde, accountinfo[i]);
        group.Items = groupinfo;
        account.TreeNodes.push(group);

        var session = new TreeNode();
        session.Text = "消息列表";
        //session.Type = "Session";    
        buildMessageNode(abc, userinfo, session, groupinfo[i]);
        account.TreeNodes.push(session);

        var board = new TreeNode();
        board.Text = "留言板";
        board.Type = "Board";
        board.Items = getBoard(bcd, accountinfo[i]);
        account.TreeNodes.push(board);

        var comment = new TreeNode();
        comment.Text = "评论消息";
        comment.Type = "Comments";
        comment.Items = getComments(bcd, accountinfo[i]);
        account.TreeNodes.push(comment);
    }
    result.push(news);
}
function getUser(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * ,cast(field40 as nvarchar) as Weibo,cast(field28 as nvarchar) as Introduce,cast(field29 as nvarchar) as Company,cast(field32 as nvarchar) as City,cast(u_loctime as nvarchar) as StartDate,cast(field26 as nvarchar) as Hobby,cast(field27 as nvarchar) as Profession,cast(field25 as nvarchar) as Constellation,cast(field12 as nvarchar) as BrithDay,cast(field11 as txt) as RegisterDate,cast(field10 as nvarchar)as Age, cast(field8 as nvarchar) as Telephone ,cast(field13 as text)as sign,cast(field9 as text)as gender,cast(u_distance as text)as distance from users2 where u_momoid = '" + accountinfo.Acc + "'") + ')');
    for (var i in data) {
        var obj = new User();
        obj.Name = data[i].u_name;
        obj.Id = data[i].u_momoid;
        obj.Weibo = data[i].Weibo;
        obj.Introduce = data[i].Introduce;
        obj.Signature = data[i].sign;
        if (data[i].distance == 2147483646 || data[i].distance == -1) {
            obj.Distance = "未知";
        }
        else {
            obj.Distance = data[i].distance / 1000;
        }
        if (data[i].gender == 'F') {
            obj.Gender = "女";
        }
        else {
            obj.Gender = "男";
        }
        obj.TelephoneNumber = data[i].Telephone;
        obj.Age = data[i].Age;
        obj.RegisterDate = XLY.Convert.LinuxToDateTime(data[i].RegisterDate);
        obj.BrithDay = data[i].BrithDay;
        obj.Constellation = data[i].Constellation;
        obj.Profession = data[i].Profession;
        obj.Hobby = data[i].Hobby;
        obj.Company = data[i].Company;
        obj.City = data[i].City;
        obj.StartDate = XLY.Convert.LinuxToDateTime(data[i].StartDate);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function buildContactSubNode(node, data, path, accountinfo) {

    // var user = new TreeNode();
    // user.Text = "帐号信息";
    // user.Type = "Contact"; 
    //var udata = eval('('+ XLY.Sqlite.Find(path,"select u_momoid as sub_momoid from users2 where u_momoid = '"+accountinfo.Acc+"'" ) +')'); 
    //user.Items = getUserInfo(data,udata); 
    // node.TreeNodes.push(user);

    var friend = new TreeNode();
    friend.Text = "关注";
    friend.Type = "Contact";
    var frdata = eval('(' + XLY.Sqlite.Find(path, "select f_momoid as sub_momoid from friends") + ')');
    friend.Items = getUserInfo(data, frdata);
    node.TreeNodes.push(friend);

    var mcontact = new TreeNode();
    mcontact.Text = "手机联系人";
    mcontact.Type = "Contact";
    var mdata = eval('(' + XLY.Sqlite.Find(path, "select u_momoid as sub_momoid from users2 where field46 = '2147483647' ") + ')');
    mcontact.Items = getUserInfo(data, mdata);
    node.TreeNodes.push(mcontact);

    var fans = new TreeNode();
    fans.Text = "粉丝";
    fans.Type = "Contact";
    //fans.Type = "Fans"; 
    var fdata = eval('(' + XLY.Sqlite.Find(path, "select f_momoid as sub_momoid from fans") + ')');
    fans.Items = getUserInfo(data, fdata);
    //fans.Items = getFans(abc,accountinfo);
    node.TreeNodes.push(fans);

    var bothfllow = new TreeNode();
    bothfllow.Text = "好友";
    bothfllow.Type = "Contact";
    var bfdata = eval('(' + XLY.Sqlite.Find(path, "select bf_momoid as sub_momoid from bothfollow") + ')');
    bothfllow.Items = getUserInfo(data, bfdata);
    //var bothfllowinfo = getBothFollow(abc,accountinfo);
    //bothfllow.Items = bothfllowinfo;
    node.TreeNodes.push(bothfllow);

    var near = new TreeNode();
    near.Text = "附近的人";
    near.Type = "Contact";
    var ndata = eval('(' + XLY.Sqlite.Find(path, "select n_momoid as sub_momoid from nearybys") + ')');
    near.Items = getUserInfo(data, ndata);
    node.TreeNodes.push(near);
}
function getUserInfo(alluser, subidinfo) {
    if (subidinfo.length > 0 && subidinfo != null) {
        var userlist = new Array();
        //遍历子节点的所有id
        for (var i in subidinfo) {
            for (var num in alluser) {
                if (alluser[num].Id == subidinfo[i].sub_momoid) {
                    userlist.push(alluser[num]);
                }
            }
        }
        return userlist;
    }
}
function getBlacklist(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from blacklist") + ')');
    for (var i in data) {
        var obj = new Blacklist();
        obj.ID = data[i].b_momoid;
        obj.StartDate = XLY.Convert.LinuxToDateTime(data[i].b_blacktime);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getGroup(path, path1, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from (select * from \"group\" g left join groupuser m where g.GID = m.GROUP_ID)") + ')');
    for (var i in data) {
        var obj = new Group();
        obj.Name = data[i].NAME;
        var id = data[i].GID;
        obj.Id = id;
        obj.Creator = data[i].OWNER;
        obj.Introduce = data[i].SIGN;
        obj.Number = data[i].MEMBER_COUNT;
        obj.Max = data[i].MEMBER_MAX;
        obj.Lng = data[i].LOC_LNG;
        obj.Lat = data[i].LOC_LAT;
        obj.Distance = data[i].DISTANCE_STRING;
        obj.CreatePlace = data[i].SITE_NAME;
        obj.JTime = XLY.Convert.LinuxToDateTime(data[i].JOIN_TIME);
        obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].CREATE_TIME);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function buildMessageNode(path, userinfo, node, groupinfo, cde) {

    if (XLY.File.IsValid(path)) {
        var umsgdata = eval('(' + XLY.Sqlite.Find(path, "select * from sessions s left join users2 u where s.s_chatid = u.u_momoid  ") + ')');
        if (umsgdata.length > 0 && umsgdata != null) {
            var umsg = new TreeNode();
            umsg.Text = "好友消息";
            for (var i in umsgdata) {
                var unode = new TreeNode();
                unode.Text = umsgdata[i].u_name;
                unode.Type = "Message";
                var tbl = getChatTableName(umsgdata[i].s_lastmsgid, path);
                var msgdata = eval('(' + XLY.Sqlite.Find(path, "select * from '" + tbl + "'") + ')');
                for (var num in msgdata) {
                    var obj = new Message();
                    if (msgdata[num].m_receive == 1) {
                        obj.SenderName = unode.Text;
                        obj.Receiver = userinfo[0].Name;
                    }
                    else {
                        obj.SenderName = userinfo[0].Name;
                        obj.Receiver = unode.Text;
                    }
                    var b = eval('(' + msgdata[num].m_msginfo + ')');
                    obj.Content = b.content;
                    obj.File == "";
                    if (b.fileName != null) {
                        obj.File = b.fileName;
                    }
                    var a = msgdata[num].m_type;
                    switch (a) {
                        case 0:
                            obj.MessageType = "文本";
                            break;
                        case 1:
                            obj.MessageType = "图片";
                            break;
                        case 2:
                            obj.MessageType = "地理位置";
                            break;
                        case 3:
                            obj.MessageType = "被关注";
                            break;
                        case 4:
                            obj.MessageType = "语音";
                            break;
                        case 5:
                            obj.MessageType = "系统提示";
                            break;
                        case 8:
                            obj.MessageType = "阅后即焚";
                            break;
                        case 9:
                            obj.MessageType = "视频";
                            break;
                        case 11:
                            obj.MessageType = "邀请进入群组的信息";
                            break;
                        case 12:
                            obj.MessageType = "音乐";
                            break;
                        case 15:
                            obj.MessageType = "红包信息";
                            break;
                        default:
                            obj.MessageType = "其他";
                            break;
                    }
                    var b = msgdata[num].m_status;
                    switch (b) {
                        case 2:
                            obj.SendState = "对方未读";
                            break;
                        case 3:
                            obj.SendState = "发送失败";
                            break;
                        case 4:
                            obj.SendState = "己方已读";
                            break;
                        case 5:
                            obj.SendState = "己方未读";
                            break;
                        case 6:
                            obj.SendState = "阅后即焚";
                            break;
                        default:
                            obj.SendState = "其他";
                            break;
                    }
                    obj.Date = XLY.Convert.LinuxToDateTime(msgdata[num].m_time)

                    obj.DataState = "Normal";
                    unode.Items.push(obj);
                }
                umsg.TreeNodes.push(unode);
            }
            node.TreeNodes.push(umsg);
        }
        var dmsgdata = eval('(' + XLY.Sqlite.Find(path, "select * from sessions  where s_remoteid like 'd_%'") + ')');

        if (dmsgdata.length > 0 && dmsgdata != null) {
            var dmsg = new TreeNode();
            dmsg.Text = "讨论组消息";
            for (var i in dmsgdata) {
                var dnode = new TreeNode();
                dnode.Text = dmsgdata[i].s_chatid;
                dnode.Type = "Message";
                var tbl = getChatTableName(dmsgdata[i].s_lastmsgid, path);
                var msgdata = eval('(' + XLY.Sqlite.Find(path, "select * from '" + tbl + "'") + ')');
                for (var num in msgdata) {
                    var obj = new Message();
                    obj.SenderName = msgdata[i].m_remoteid;
                    obj.Receiver = dnode.Text;
                    var b = eval('(' + msgdata[num].m_msginfo + ')');
                    obj.Content = b.content;
                    obj.File == "";
                    if (b.fileName != null) {
                        obj.File = b.fileName;
                    }
                    var a = msgdata[num].m_type;
                    switch (a) {
                        case 0:
                            obj.MessageType = "文本";
                            break;
                        case 1:
                            obj.MessageType = "图片";
                            break;
                        case 2:
                            obj.MessageType = "地理位置";
                            break;
                        case 3:
                            obj.MessageType = "被关注";
                            break;
                        case 4:
                            obj.MessageType = "语音";
                            break;
                        case 5:
                            obj.MessageType = "系统提示";
                            break;
                        case 8:
                            obj.MessageType = "阅后即焚";
                            break;
                        case 9:
                            obj.MessageType = "视频";
                            break;
                        case 11:
                            obj.MessageType = "邀请进入群组的信息";
                            break;
                        case 12:
                            obj.MessageType = "音乐";
                            break;
                        case 15:
                            obj.MessageType = "红包信息";
                            break;
                        default:
                            obj.MessageType = "其他";
                            break;
                    }
                    var b = msgdata[num].m_status;
                    switch (b) {
                        case 2:
                            obj.SendState = "对方未读";
                            break;
                        case 3:
                            obj.SendState = "发送失败";
                            break;
                        case 4:
                            obj.SendState = "己方已读";
                            break;
                        case 5:
                            obj.SendState = "己方未读";
                            break;
                        case 6:
                            obj.SendState = "阅后即焚";
                            break;
                        default:
                            obj.SendState = "其他";
                            break;
                    }
                    obj.Date = XLY.Convert.LinuxToDateTime(msgdata[num].m_time)

                    obj.DataState = "Normal";
                    dnode.Items.push(obj);
                }
                dmsg.TreeNodes.push(dnode);
            }
            node.TreeNodes.push(dmsg);
        }
        var gmsgdata = eval('(' + XLY.Sqlite.Find(path, "select * from sessions  where s_remoteid  like 'g_%'") + ')');
        if (gmsgdata.length > 0 && gmsgdata != null) {
            var gmsg = new TreeNode();
            gmsg.Text = "群组消息";
            for (var i in gmsgdata) {
                var gnode = new TreeNode();
                gnode.Text = gmsgdata[i].s_chatid;
                gnode.Type = "Message";
                var tbl = getChatTableName(gmsgdata[i].s_lastmsgid, path);
                var msgdata = eval('(' + XLY.Sqlite.Find(path, "select * from '" + tbl + "'") + ')');
                for (var num in msgdata) {
                    var obj = new Message();
                    obj.SenderName = msgdata[num].m_remoteid;
                    obj.Receiver = gnode.Text;

                    var b = eval('(' + msgdata[num].m_msginfo + ')');
                    obj.Content = b.content;
                    obj.File == "";
                    if (b.fileName != null) {
                        obj.File = b.fileName;
                    }
                    var a = msgdata[num].m_type;
                    switch (a) {
                        case 0:
                            obj.MessageType = "文本";
                            break;
                        case 1:
                            obj.MessageType = "图片";
                            break;
                        case 2:
                            obj.MessageType = "地理位置";
                            break;
                        case 3:
                            obj.MessageType = "被关注";
                            break;
                        case 4:
                            obj.MessageType = "语音";
                            break;
                        case 5:
                            obj.MessageType = "系统提示";
                            break;
                        case 8:
                            obj.MessageType = "阅后即焚";
                            break;
                        case 9:
                            obj.MessageType = "视频";
                            break;
                        case 11:
                            obj.MessageType = "邀请进入群组的信息";
                            break;
                        case 12:
                            obj.MessageType = "音乐";
                            break;
                        case 15:
                            obj.MessageType = "红包信息";
                            break;
                        default:
                            obj.MessageType = "其他";
                            break;
                    }
                    var b = msgdata[num].m_status;
                    switch (b) {
                        case 2:
                            obj.SendState = "对方未读";
                            break;
                        case 3:
                            obj.SendState = "发送失败";
                            break;
                        case 4:
                            obj.SendState = "己方已读";
                            break;
                        case 5:
                            obj.SendState = "己方未读";
                            break;
                        case 6:
                            obj.SendState = "阅后即焚";
                            break;
                        default:
                            obj.SendState = "其他";
                            break;
                    }
                    obj.Date = XLY.Convert.LinuxToDateTime(msgdata[num].m_time)

                    obj.DataState = "Normal";
                    gnode.Items.push(obj);
                }
                gmsg.TreeNodes.push(gnode);
            }
            node.TreeNodes.push(gmsg);

        }
    }

}
function getContact(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * ,cast(field40 as nvarchar) as Weibo,cast(field28 as nvarchar) as Introduce,cast(field29 as nvarchar) as Company,cast(field32 as nvarchar) as City,cast(u_loctime as nvarchar) as StartDate,cast(field26 as nvarchar) as Hobby,cast(field27 as nvarchar) as Profession,cast(field25 as nvarchar) as Constellation,cast(field12 as nvarchar) as BrithDay,cast(field11 as txt) as RegisterDate,cast(field10 as nvarchar)as Age, cast(field8 as nvarchar) as Telephone ,cast(field13 as text)as sign,cast(field9 as text)as gender,cast(u_distance as text)as distance from  users2 ") + ')');//(select * from users2 left join fans where users2.[u_momoid] = fans.[f_momoid])
    for (var i in data) {
        var obj = new Contact();
        obj.ID = data[i].f_momoid;
        obj.Weibo = data[i].Weibo;
        obj.Introduce = data[i].Introduce;
        obj.Name = data[i].u_name;
        obj.Id = data[i].u_momoid;
        obj.Signature = data[i].sign;
        if (data[i].distance == 2147483646 || data[i].distance == -1) {
            obj.Distance = "未知";
        }
        else {
            obj.Distance = data[i].distance / 1000;
        }
        if (data[i].gender == 'F') {
            obj.Gender = "女";
        }
        else {
            obj.Gender = "男";
        }
        obj.TelephoneNumber = data[i].Telephone;
        obj.Age = data[i].Age;
        obj.RegisterDate = XLY.Convert.LinuxToDateTime(data[i].RegisterDate);
        obj.BrithDay = data[i].BrithDay;
        obj.Constellation = data[i].Constellation;
        obj.Profession = data[i].Profession;
        obj.Hobby = data[i].Hobby;
        obj.Company = data[i].Company;
        obj.City = data[i].City;
        obj.StartDate = XLY.Convert.LinuxToDateTime(data[i].StartDate);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBlacklist(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from blacklist") + ')');
    for (var i in data) {
        var obj = new Blacklist();
        obj.ID = data[i].b_momoid;
        obj.StartDate = XLY.Convert.LinuxToDateTime(data[i].b_blacktime);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getChatTableName(msgid, path) {
    var tblinfo = eval('(' + XLY.Sqlite.Find(path, "select distinct tbl_name from sqlite_master where tbl_name like 'Chat_%' ") + ')');
    var reg = new RegExp("^Chat\_", "");
    if (tblinfo.length > 0 && tblinfo != null) {
        for (var i in tblinfo) {
            if (reg.test(tblinfo[i].tbl_name)) {
                var chat_msginfo = eval('(' + XLY.Sqlite.Find(path, "select m_msgid from '" + tblinfo[i].tbl_name + "' ") + ')');
                if (chat_msginfo.length > 0 && chat_msginfo != null) {
                    for (var num in chat_msginfo) {
                        if (msgid == chat_msginfo[num].m_msgid) {
                            return tblinfo[i].tbl_name;
                        }
                    }
                }
            }
        }
    }

}
function getDiscussion(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * ,cast(field10 as nvarchar) as Nick,cast(field1 as nvarchar) as Name,cast(field4 as nvarchar) as MemberId from discuss") + ')');
    for (var i in data) {
        var obj = new Discussion();
        obj.Name = data[i].Name;
        obj.GID = data[i].did;
        obj.Id = data[i].field2;
        obj.MemberId = data[i].MemberId;
        obj.Count = data[i].f_momoid;
        obj.Number = data[i].field8;
        obj.Nick = data[i].Nick;
        obj.Count = data[i].field9;
        obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].field7);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBoard(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * ,cast(field12 as nvarchar) as Place,cast(field5 as nvarchar) as Content,cast(field6 as nvarchar) as Picture from commonfeed") + ')');
    for (var i in data) {
        var obj = new Board();
        obj.ID = data[i].xly_id;
        obj.Content = data[i].Content;
        obj.Picture = "/storage/emulated/0/immomo/avatar/thumb_250/" + data[i].Picture;
        obj.ZCount = data[i].field7;
        obj.Count = data[i].field8;
        obj.Distance = data[i].field9 / 1000;
        obj.MID = data[i].field10;
        obj.Place = data[i].Place;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].field3);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}


function getInfo(db) {
    var list = new Array();
    var filenames = eval('(' + XLY.File.FindFiles(db) + ')');

    var info = new Array();
    for (var index in filenames) {
        var data = XLY.File.GetFileName(filenames[index]);
        if ((/^-?[0-9]\d*$/g).test(data)) info.push(data);
    }
    for (var i in info) {
        var obj = new Info();
        obj.Acc = info[i];
        list.push(obj);
    }
    return list;
}
function getComments(path, accountinfo) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select *,cast(field4 as nvarchar) as content from basefeedcomments") + ')');
    //log(data);    
    for (var i in data) {
        var obj = new Comments();
        obj.ID = data[i].c_id;
        obj.FID = data[i].field2;
        obj.Content = data[i].content;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].field3);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
//var db = "D:\\temp\\data\\data\\com.immomo.momo\\databases";

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
