﻿/*[config]
<plugin name="360浏览器,4" group="Web痕迹,4" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\qihooBrowser.png" app="com.qihoo.browser" version="8.0.0.124" description="360浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.qihoo.browser/app_chrome/Default/Cookies</value>
<value>/data/data/com.qihoo.browser/databases/browser.db</value>
<value>/data/data/com.qihoo.browser/databases/downloads.db</value>
<value>/data/data/com.qihoo.browser/app_chrome/Default/History</value>
<value>/data/data/com.qihoo.browser/shared_prefs/accout_pref.xml</value>
</source>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="姓名" code="Name" type="string" width = "150"></item>
</data>
<data type="User" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width = "150"></item>
</data>
<data type="MobileBookmark" contract="DataState" datefilter="Created">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="300" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format=""></item>
<item name="创建时间" code="Created" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="修改时间" code="Modified" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Cookies" contract="DataState" datefilter="Created">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主键" code="Key" type="string" width="300" format=""></item>
<item name="键名" code="Name" type="url" width="500" format = ""></item>
<item name="值" code="Value" type="string" width="300" format=""></item>
</data>
<data type="FrequentVisit" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="200" format = ""></item>
<item name="图标" code="Icon" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format = ""></item>
<item name="创建时间" code="Time" type="datetime" order="asc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Visits" type="string" width="100" format=""></item>
</data>
<data type="History" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="400" format=""></item>
<item name="URL地址" code="Url" type="url" width="200" format=""></item>
<item name="访问时间" code="Time"  type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Visits" order="desc" type="string" width="100" format=""></item>
</data>
<data type="SavePage" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="400" format=""></item>
<item name="URL地址" code="Url" type="url" width="200" format = ""></item>
<item name="本地路径" code="Path" type="url" width="200" format=""></item>
<item name="时间" code="Time"  type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="SerachWords" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="KeyWords" type="string" width="100" format=""></item>
</data>
<data type="DownloadFile" contract="DataState" datefilter="Title">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="200" format=""></item>
<item name="文件地址" code="Url" type="url" width="400" format = ""></item>
<item name="总大小" code="ToalBytes" type="string" width="100" format=""></item>
<item name="当前大小" code="CurrentBytes" type="string" width="100" format=""></item>
<item name="存储路径" code="SaveFile" type="string" width="200" format=""></item>
<item name="文件类型" code="FileType" type="string" width="240" format = ""></item>
<item name="修改时间" code="Time" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="文件名" code="Name" type="string" width="100" format = ""></item>
<item name="用户ID" code="Id" type="string" width="100" format=""></item>
<item name="描述" code="Description" type="string" width="150" format=""></item>
</data>
</plugin>
[config]*/
//定义数据结构
function Account(){
    this.DataState = "Normal";
    this.Name = "";
}
function User(){
    this.DataState = "Normal";
    this.Name = "";
}
function MobileBookmark() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Created = "";
    this.Modified = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function FrequentVisit() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Icon = "";
}
function History() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Visits = "";
}
function SavePage() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Path = "";
}
function SerachWords() {
    this.DataState = "Normal";
    this.KeyWords = "";
}

function DownloadFile() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.ToalBytes = "";
    this.CurrentBytes = "";
    this.SaveFile = "";
    this.FileType = "";
    this.Time = "";
    this.Name = "";
    this.Description = "";
    
}
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
function bindTree(){
    var acc = new TreeNode();
    acc.Text = "360浏览器";
    acc.Type = "Account";
    acc.Items = getAccount();
    acc.DataState = "Normal";

    newTreeNode("书签","MobileBookmark",getMobileBookmark(db12),acc);
    if(XLY.File.IsValid(db10)){
       newTreeNode("用户","User",getUser(db10),acc);
    }    
    newTreeNode("保存的网页","SavePage",getSavePage(db12),acc);
    //newTreeNode("Cookies","Cookies",getCookies(db11),acc);
    newTreeNode("最常访问","FrequentVisit",getFrequentVisit(db12),acc);
    newTreeNode("历史","History",getHistory(db4),acc);
    newTreeNode("搜索","SerachWords",getSerachWords(db4),acc);
    newTreeNode("下载文件","DownloadFile",getDownloadFile(db13),acc);
    result.push(acc);
}
function getAccount(){
    var list = new Array();
    data = ["书签","Cookies","最常访问","历史","搜索","下载文件"];
    for(var i in data){
        var obj = new Account();
        obj.Name = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}
function getUser(path){
    var list = new Array;
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var info = data.map.string;
    for(var i in info){
        var obj = new User;
        if(/^LogInLatestUserNickName/.test(info[i]['@name'])){
            var info1 = info[i]['@name'].substring(23,info[i]['@name'].length);
        obj.Name = info1;
        list.push(obj);
        }
    }
return list;
}
function getMobileBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from bookmarks" ) +')');
    for(var i in data){
        var obj = new MobileBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Created = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.Modified = XLY.Convert.LinuxToDateTime(data[i].last_modify_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSavePage(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from save_pages" ) +')');
    for(var i in data){
        var obj = new SavePage();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Path = data[i].local_path;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getOnlineBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from tb_fav" ) +')');
    for(var i in data){
        var obj = new OnlineBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Created = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Modified = XLY.Convert.LinuxToDateTime(data[i].last_modify_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCookies(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cookies" ) +')');
    for(var i in data){
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFrequentVisit(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from frequent_visit" ) +')');
    for(var i in data){
        var obj = new FrequentVisit();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Icon = data[i].logo;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.GoogleChromeToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from urls" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visit_count;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].last_visit_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSerachWords(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from keyword_search_terms" ) +')');
    for(var i in data){
        var obj = new SerachWords();
        obj.KeyWords = data[i].term;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getDownloadFile(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from downloads" ) +')');
    for(var i in data){
        var obj = new DownloadFile();
        obj.Title = data[i].title;
        obj.Url = data[i].uri;
        obj.ToalBytes = data[i].total_bytes+" bytes";
        obj.CurrentBytes = data[i].current_bytes+" bytes";
        obj.SaveFile = data[i].hint;
        obj.FileType = data[i].mimetype;
        obj.Name = data[i].title;
        obj.Id = data[i].uid;
        obj.Description = data[i].description;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].lastmod);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db11 = source[0];
var db12 = source[1];
var db13 = source[2];
var db4 = source[3];
var db10 = source[4];

//var charactor1 = "\\chalib\\Android_qihooBrowser_V8.0.0.124\\Cookies.charactor";
//var charactor2 = "\\chalib\\Android_qihooBrowser_V8.0.0.124\\History.charactor";
//var charactor3 = "\\chalib\\Android_qihooBrowser_V8.0.0.124\\browser.db.charactor";
//var charactor4 = "\\chalib\\Android_qihooBrowser_V8.0.0.124\\downloads.db.charactor";
//
//db1 = "D:\\temp\\data\\data\\com.qihoo.browser\\app_chrome\\Default\\Cookies";
//db6 = "D:\\temp\\data\\data\\com.qihoo.browser\\databases\\browser.db";
//db5 = "D:\\temp\\data\\data\\com.qihoo.browser\\databases\\downloads.db";
//db2 = "D:\\temp\\data\\data\\com.qihoo.browser\\app_chrome\\Default\\History";
//db10 = "D:\\temp\\data\\data\\com.qihoo.browser\\shared_prefs\\accout_pref.xml";
//
//var charactor1 = "D:\\temp\\data\\data\\com.qihoo.browser\\app_chrome\\Default\\Cookies.charactor";
//var charactor2  = "D:\\temp\\data\\data\\com.qihoo.browser\\app_chrome\\Default\\History.charactor";
//var charactor3  = "D:\\temp\\data\\data\\com.qihoo.browser\\app_chrome\\Default\\browser.db.charactor";
//var charactor4 = "D:\\temp\\data\\data\\com.qihoo.browser\\databases\\downloads.db.charactor"; 
//
//var db11 = XLY.Sqlite.DataRecovery(db1,charactor1,"cookies");
//var db4 = XLY.Sqlite.DataRecovery(db2,charactor2,"keyword_search_terms,url");
//var db12 = XLY.Sqlite.DataRecovery(db6,charactor3,"frequent_visit,tb_fav,save_pages");  
//var db13 = XLY.Sqlite.DataRecovery(db5,charactor4,"downloads");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;

