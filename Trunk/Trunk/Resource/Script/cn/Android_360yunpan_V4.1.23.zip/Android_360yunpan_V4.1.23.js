﻿/*[config]
<plugin name="360云盘,9" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\360yunpan.png" app="com.qihoo.yunpan" version="4.1.23" description="360云盘" data="$data,ComplexTreeDataSource"  >
    <source>
        <value>data/data/com.qihoo.yunpan#F</value>
    </source>
    <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="账户名称" code="Name" type="string" width="180" format = ""></item>
        <item name="账户ID" code="ID" type="string" width="180" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="CacheFiles"  datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="string" width="180" format = ""></item>
    </data>
    <data type="Upload"  datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="本地路径" code="Path" type="string" width="400" format = ""></item>
    </data>
</plugin>
[config]*/

function Account() {
    this.Name = "";
    this.ID = "";
    this.Time = null;
    this.DataState = "Normal";
}

function CacheFiles() {
    this.Name = "";
    this.Size = "";
    this.Time = null;
    this.DataState = "Normal";
}

function Upload() {
    this.Name = "";
    this.Size = "";
    this.Path = "";
    this.Time = null;
    this.DataState = "Normal";
}


//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var result = new Array();
//源文件
var source = $source;

//测试文件
//var source = ["C:\\Users\\Administrator\\Desktop\\com.qihoo.yunpan"];
var accpath = source[0]+"\\shared_prefs\\com.qihoo.yunpan_preferences.xml";
var dbpath = source[0]+"\\databases";
var files = eval('(' + XLY.File.FindFiles(dbpath) + ')');
var paths = new Array();
var ch = "\\chalib\\Android_360yunpan_V4.1.23\\main.charactor";
for(var index in files){
    var str = files[index];
    if(str.indexOf("main_")>= 0&&str.charAt(str.length-1)=="b"&&str.indexOf("recovery")==-1){        
        str = XLY.Sqlite.DataRecovery(str,ch,"nodes_v3,upload_disk");
        paths.push(str);
    }
}

//主界面函数
function ParesCore(){
    //创建云盘节点
    var yunpanNode = new BuildNode("360云盘","",[],"Normal");
    for(var i in paths){
        var db =  XLY.File.GetFileName(paths[i]);
        var j = db.indexOf("_");
        var accID = db.slice(j+2,db.length-12);
        //创建账户节点
        var account = getAccount();
        if(accID==account[0].ID){
            var accName = account[0].Name;
        }
        else
        {
            var accName = account[0].ID;
        }
        var accNode = BuildNode(accName,"Account",account,"Normal");
        //创建文件节点
        var infoNode = BuildNode("网盘文件","CacheFiles",getInfo(paths[i]),"Normal");
        accNode.TreeNodes.push(infoNode);
        var uploadNode = BuildNode("上传文件","Upload",getUpload(paths[i]),"Normal");
        accNode.TreeNodes.push(uploadNode);
        yunpanNode.TreeNodes.push(accNode);  
    }
    result.push(yunpanNode);
}

//创建节点
function BuildNode(text,type,items,dataState){
    var node = new TreeNode();
    node.Text = text;
    node.Type = type;
    node.Items = items;
    node.DataState = dataState;
    return node;
}

//提取账户信息
function getAccount(){
    var arr = new Array();
    var acc = new Account();
    var Items = new Array();
    var data = eval('(' + XLY.File.ReadXML(accpath) + ')');
    var info = data.map.string;
    for(var i in info){
        if(info[i]['@name'] == "username"){
            arr.push(info[i]['#text']);
        }
        if(info[i]['@name'] == "usercenterUser.qid"){
            arr.push(info[i]['#text']);
        }
         if(info[i]['@name'] == "yunpanUser.tokenDeadTime"){
            arr.push(info[i]['#text']);
        }
    }
    acc.Name = arr[0];
    acc.ID = arr[2];
    acc.Time = XLY.Convert.LinuxToDateTime(arr[1]);
    Items.push(acc);
    return Items;
}

//获取网盘文件
function getInfo(datapath){
    var db = eval('('+ XLY.Sqlite.FindByName(datapath,"nodes_v3") +')');
    var Items = new Array();
    for(var i in db){
        var file = new CacheFiles();
        file.Name = db[i].name;
        file.Size = db[i].countsize+"/byte";
        file.Time = db[i].uploadtime;
        file.ID = db[i].filehash;
        file.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(file);
    }
    return Items;
}

//获取上传文件信息
function getUpload(datapath){
    var db = eval('('+ XLY.Sqlite.FindByName(datapath,"upload_disk") +')');
    var Items = new Array();
    for(var i in db){
        var file = new Upload();
        file.Name = db[i].fpath;
        file.Size = db[i].fsize+"/byte";
        file.Time = XLY.Convert.LinuxToDateTime(db[i].ctime);
        file.Path = db[i].local_file;
        file.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(file);
    }
    return Items;
}


ParesCore();
var res = JSON.stringify(result);
res;
