﻿/*[config]
<plugin name="百度,6" group="Web痕迹,16" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid"  icon="/icons/baidu.png"  app="com.baidu.searchbox" description="百度"  data="$data,ComplexTreeDataSource" version="6.0">
<source>
<value>/data/data/com.baidu.searchbox/databases/SearchBox.db</value>
</source>
<data type="Baidu" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分组" code="Name" type="string" width="600" format="" ></item>
</data>
<data type="BaiduMsg" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="标题" code="Title" type="string" width="" format = ""></item>
<item name="内容" code="Content" type="string" width="" format = "" ></item>
<item name="图标" code="Icon" type="url" width="" format = "" ></item>
<item name="网址" code="Url" type="url" width="" format = "" ></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Search" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="内容" code="Content" type="string" width="" format = ""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Bookmarks" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="目录" code="Files" type="string" width="" format = ""></item>
<item name="内容" code="Content" type="string" width="" format = ""></item>
<item name="网址" code="Url" type="url" width="" format = "" ></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Visitedlog" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="网址" code="Url" type="url" width="" format = "" ></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Xsearch" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="标题" code="Title" type="string" width="" format = ""></item>
<item name="图标" code="Icon" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//******************************************定义数据结构******************************************
//定义数据结构
function Baidu()
{
    this.Name = "";
    this.DataState="Normal";
}

//百度消息
function BaiduMsg()
{
    this.Title = "";
    this.Content = "";
    this.Icon = "";
    this.Url = "";
    this.Time = "";    
    this.DataState="Normal";
}

//搜索
function Search()
{
    this.Content = "";
    this.Time = "";
    this.DataState="Normal";
}

//书签
function Bookmarks()
{
    this.Files = "";
    this.Content = "";
    this.Url = "";
    this.Time = "";
    this.DataState="Normal";
}

//访问记录
function Visitedlog(){
    this.Url = "";
    this.Time = "";
    this.SendState = "";
}

//订阅
function Xsearch()
{
    this.Title = "";
    this.Icon = "";
    this.DataState="Normal";
}

//定义树结构
function TreeNode() 
{
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

//******************************************定义处理数据的方法******************************************
function bindTree(){
    var baidu = BuildTreeNode("百度","Baidu",getBaidu());
    baidu.TreeNodes.push(BuildTreeNode("百度消息","BaiduMsg",getBaiduMsg(recoverydb)));
    baidu.TreeNodes.push(BuildTreeNode("历史搜索","Search",getSearch(recoverydb)));
    baidu.TreeNodes.push(BuildTreeNode("书签","Bookmarks",getBookmarks(recoverydb)));
    baidu.TreeNodes.push(BuildTreeNode("历史浏览","Visitedlog",getVisitedlog(recoverydb)));
    baidu.TreeNodes.push(BuildTreeNode("订阅","Xsearch",getXsearch(recoverydb)));
    result.push(baidu);
}

//创建树节点
function BuildTreeNode(text,type,item){
    var nodename = new TreeNode();
    nodename.Text = text;
    nodename.Type = type;
    nodename.Items = item;
    return nodename; 
}

//获取分组
function getBaidu(){
    var list = new Array();
    var info = ["百度消息","历史搜索","书签","历史浏览记录","订阅"]; 
    for(var i in info){
        var obj = new Baidu();
        obj.Name = info[i];
        obj.DataState = "Normal";
        list.push(obj);
    }
    return list;
}

//获取百度消息
function getBaiduMsg(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'baidumsg_table' ) +')');
    for(var i in data){
        var obj = new BaiduMsg();
        obj.Title = data[i].title;
        obj.Content = data[i].content;
        obj.Icon = data[i].iconUrl;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取历史搜索
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'clicklog' ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Content = data[i].query;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].hit_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取书签
function getBookmarks(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'bookmarks' ) +')');
    for(var i in data){
        var obj = new Bookmarks();
        obj.Files = data[i].directory;
        obj.Content = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取访问记录
function getVisitedlog(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'visitedlog' ) +')');
    for(var i in data){
        var obj = new Visitedlog();
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取订阅信息
function getXsearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'xsearch_site' ) +')');
    for(var i in data){
        var obj = new Xsearch();
        obj.Title = data[i].title;
        obj.Icon = data[i].icon_url;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }  
    return list;
}

//*****************************************************************
var result = new Array();
var source = $source;
var db = source[0];
//var db = "H:\\XLYSFTask\\任务-2016-11-04-09-57-38\\source\\data\\com.baidu.searchbox\\databases\\SearchBox.db";
var charactor="\\chalib\\Android_Baidu_V6.0\\SearchBox.db.charactor";
var recoverydb = XLY.Sqlite.DataRecovery(db,charactor,"baidumsg_table,clicklog,bookmarks,visitedlog,xsearch_site");
bindTree();
var res = JSON.stringify(result);
res;
