﻿/*[config]
<plugin name="淘宝,6" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/TaoBao.png" app="com.taobao.taobao4iphone" version="5.0.1" description="Test-导航树" data="$data,TreeDataSource">
<source>
<value>com.taobao.taobao4iphone</value>
</source>
<data type = "Search">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item> 
<item name="关键字" code="Word" type="string" width="100" ></item>
<item name="时间" code="Time" type="datetime" width="300" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>
<data type="Account">
<item name="历史登录账号" code="Name" type="string" width="" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Search() {
    this.Word = "";
    this.Date = "";
    this.DataState="Normal";
}

function Account() {
    this.Name = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindtree(){
    //创建历史搜索树
    var search = new TreeNode();
    search.Text = "历史搜索";
    search.Type = "Search";
    search.Items = getSearchInfo(dbsearch);
    //创建所有登录帐号树
    var account = new TreeNode();
    account.Text = "历史登录帐号";
    account.Type = "Account";
    account.Items = getAccountInfo(db);
    result.push(search);
    result.push(account);
}


//获取历史搜索信息
function getSearchInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(save_date as text)as t,* from [2]") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Search();
        var keyword = eval('(' + data[index].key + ')');
        obj.Word = keyword.search_keyword;
        obj.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].t));
        obj.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取历史登陆账号
function getAccountInfo(path){
    var filepath = eval('('+XLY.File.FindFileNames( path  )+')');
    var info=new Array();
    for(var index in filepath){
        var filename=filepath[index];
        if((/^MCRecentContact_/gi).test(filename)){
            var obj=new Account();
            obj.Name = filename.slice(filename.indexOf("Contact_")+8,filename.length);
            info.push(obj);
        }
    }
    return info;
}
var result = new Array();
//源文件
var source = $source;
var db = source[0]+"\\com.taobao.taobao4iphone\\Documents";
//var  db = "D:\\temp\\data\\data\\IOS.taobao\\com.taobao.taobao4iphone\\Documents";
var charactor="\\chalib\\IOS_TaoBao_V5.0.1\\local_storage.sqlite.charactor";
//var dbsearch = db + "\\local_storage.sqlite";
var tbl = eval('('+ XLY.Sqlite.Find(db+"\\local_storage.sqlite","select * from sqlite_master where name = '2'") +')');
var dbsearch = XLY.Sqlite.DataRecovery(db+"\\local_storage.sqlite",charactor,tbl[0].name);
bindtree(result);
var res = JSON.stringify(result);
res;
