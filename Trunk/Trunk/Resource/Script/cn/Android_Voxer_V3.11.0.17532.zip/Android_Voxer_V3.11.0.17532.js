﻿/*[config]
<plugin name="Voxer,15" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/Voxer.png" app="com.rebelvox.voxer" version="3.11.0.17532" description="Voxer" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.rebelvox.voxer#F</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="News1" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群ID" code="ID" type="string" width="200" format=""></item>
    <item name="群名" code="List" type="string" width="200" format=""></item>
    <item name="群创建者" code="Creator" type="string" width="200" format=""></item>
    <item name="群管理者" code="Admins" type="string" width="200" format=""></item>
    <item name="创建时间" code="CreateTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="UserName" type="string" width="200" format=""></item>
    <item name="姓" code="Last" type="string" width="200" format=""></item>
    <item name="名" code="First" type="string" width="200" format=""></item>
    <item name="头像" code="ImageUrl" type="string" width="200" format=""></item>
    <item name="E-mail" code="EMail" type="string" width="200" format=""></item>
    <item name="电话" code="Phone" type="string" width="200" format = ""></item>
    <item name="所在地" code="City" type="string" width="200" format = ""></item>
    <item name="经纬度" code="Geo" type="string" width="200" format = ""></item>
    <item name="最近更新时间" code="LastUpdateTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="消息id" code="MessageId" type="string" width="200" format=""></item>
    <item name="发送者账号" code="SenderId" type="string" width="200" format=""></item>
    <item name="发送者昵称" code="SenderName" type="string" width="200" format=""></item>
    <item name="接收者账号" code="ReaderId" type="string" width="200" format=""></item>
    <item name="接收者昵称" code="ReaderName" type="string" width="200" format=""></item>
    <item name="是否已读" code="IsRead" type="string" width="200" format=""></item>
    <item name="消息内容" code="Body" type="string" width="200" format=""></item>
    <item name="消息类型" code="ContentType" type="string" width="200" format=""></item>
    <item name="时间" code="PostedTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="地理位置" code="Geo" type="string" width="200" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News() {
    this.DataState = "Normal";
    this.List = "";
}//定义News1数据结构
function News1() {
    this.DataState = "Normal";
    this.ID = "";
    this.List = "";
    this.CreateTime = null;
    this.Creator = "";
    this.Admins = "";
}
//定义UserInfo数据结构
function UserInfo() {
    this.DataState = "Normal";
    this.UserName = "";
    this.Last = "";
    this.First = "";
    this.ImageUrl = "";
    this.EMail = "";
    this.Phone = "";
    this.City = "";
    this.Geo = "";
    this.LastUpdateTime = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.MessageId = "";
    this.SenderId = "";
    this.SenderName = "";
    this.ReaderId = "";
    this.ReaderName = "";
    this.IsRead = "";
    this.Body = "";
    this.ContentType = "";
    this.PostedTime = "";
    this.Geo = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var newpath1 = source[0]+"\\databases\\rv.db";
var charactor1 = "\\chalib\\Android_Voxer_V3.11.0.17532\\rv.db.charactor";
var newpath=XLY.Sqlite.DataRecovery(newpath1,charactor1,"conversations,messages,misc,profiles");

//测试数据
//var charactor1 = "F:\\21-Build\\21-Build\\chalib\\Android_Voxer_V3.11.0.17532\\rv.db.charactor";
//var newpath1 = "C:\\XLYSFTasks\\任务-2016-12-12-17-51-23\\source\\data\\data\\com.rebelvox.voxer\\\\databases\\rv.db";
//var newpath=XLY.Sqlite.DataRecovery(newpath1,charactor1,"conversations,messages,misc,profiles");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;


//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var list = new Array();
    var userdatastr="select json from misc where name = 'profile'";
    var userdata = ExecSql(newpath,userdatastr);
    var info = eval('('+userdata[0].json+')').user_identities.usernames;
    var userinfo = eval('('+userdata[0].json+')').to[0];
    var userlistinfo = ["个人信息","好友列表","群组列表","聊天记录"];
    
    var news = new TreeNode();
    news.Text = "Voxer";
    news.Type = "News";
    news.Items = getNews(info[0]);
    
    var usernode = new TreeNode();
    usernode.Text = info[0];
    usernode.Type = "News";
    usernode.Items = getUserNews(newpath,userlistinfo,usernode);
    
    news.TreeNodes.push(usernode);
    result.push(news);
}
//获取数据库
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}
//获取账户功能列表
function getUserNews(path,info,root){
    var list = new Array();
    var chatlistinfo = ["好友聊天记录","群组聊天记录"];
    var userdatastr="select json from misc where name = 'profile'";
    var userdata = ExecSql(newpath,userdatastr);
    if(userdata !=null || userdata !=""){
        var uinfo = eval('('+userdata[0].json+')').user_identities.usernames;
        var userinfo = eval('('+userdata[0].json+')').to[0];
        for(var i in info){
            var obj = new News();
            var node = new TreeNode();
            
            obj.List = info[i];
            list.push(obj);
            
            node.Text = info[i];
            if(info[i]=="群组列表"){
               node.Type = "News";
               node.Items = getGroupList(path,node);
            }
            if(info[i]=="聊天记录"){
                var temp = new Array();
                temp = getUserInfo(path,userinfo);
                node.Type = "News";
                node.Items = getChatNews(path,userinfo,chatlistinfo,node,temp[0].First+" "+temp[0].Last);
            }
            if(info[i]=="个人信息"){
                node.Type = "UserInfo";
                node.Items = getUserInfo(path,userinfo);
                
            }
            if(info[i]=="好友列表"){
                node.Type = "UserInfo";
                node.Items = getFriendInfo(path);
                
            }
            root.TreeNodes.push(node);
        }
    }
    return list;
}
//获取news列表
function getNews(info){
    var list = new Array();
    var obj = new News();
    obj.List = info;
    list.push(obj);
    return list;
}
//获取账号信息
function getUserInfo(path,user){
    var list = new Array();
    var userdatastr = "select * from profiles where username='"+user+"'";
    var userdata = ExecSql(path,userdatastr);
    var obj = new UserInfo();
    obj.DataState = XLY.Convert.ToDataState(userdata[0].XLY_DataType);
    obj.UserName = userdata[0].username;
    obj.Last = userdata[0].last;
    obj.First = userdata[0].first;
    obj.ImageUrl = userdata[0].image_url;
    obj.EMail = userdata[0].email;
    obj.Phone = userdata[0].phone;
    obj.City = userdata[0].city;
    obj.Geo = userdata[0].geo;
    obj.LastUpdateTime = XLY.Convert.LinuxToDateTime(userdata[0].latest_update_ts);
    list.push(obj);
    return list;
}
//获取好友信息
function getFriendInfo(path){
    var list = new Array();
    var frienddatastr = "select * from profiles";
    var frienddata = ExecSql(path,frienddatastr);
    for(var i in frienddata){
        var obj = new UserInfo();
        obj.DataState = XLY.Convert.ToDataState(frienddata[i].XLY_DataType);
        obj.UserName = frienddata[i].username;
        obj.Last = frienddata[i].last;
        obj.First = frienddata[i].first;
        obj.ImageUrl = frienddata[i].image_url;
        obj.EMail = frienddata[i].email;
        obj.Phone = frienddata[i].phone;
        obj.City = frienddata[i].city;
        obj.Geo = frienddata[i].geo;
        obj.LastUpdateTime = XLY.Convert.LinuxToDateTime(frienddata[i].latest_update_ts);
        list.push(obj);
    }
    return list;
}
//获取群组列表信息
function getGroupList(path,root){
    var list = new Array();
    var groupstr = "select  distinct(thread_id) from messages where thread_id like '1%'";
    var groupdata = ExecSql(path,groupstr);
    for(var i in groupdata){
        if(groupdata[i] !=""&& groupdata[i] != null){
            var subjectstr = "select subject,creator,admins from conversations where thread_id='"+groupdata[i].thread_id+"'";
            var sunjectdata = ExecSql(path,subjectstr);
            if(sunjectdata !=""&& sunjectdata!=null){
                var obj = new News();
                obj.List = groupdata[i].thread_id.substr(14,groupdata[i].thread_id.length)+'_'+sunjectdata[0].subject;
                list.push(obj);
                
                var node = new TreeNode();
                node.Text = obj.List.split("_")[0]+"_"+obj.List.split("_")[2];
                node.Type = "News";
                node.Items = getGroupInfo();
                root.TreeNodes.push(node);
                
                var gnodemess = new TreeNode();
                gnodemess.Text = "群组信息";
                gnodemess.Type = "News1";
                gnodemess.Items = getNodeMess(groupdata[i].thread_id+'_'+sunjectdata[0].subject,sunjectdata[0].creator,sunjectdata[0].admins);
                node.TreeNodes.push(gnodemess);
                
                var gchildnode = new TreeNode();
                gchildnode.Text = "群组成员";
                gchildnode.Type = "UserInfo";
                gchildnode.Items = getChildNode(newpath,groupdata[i].thread_id);
                node.TreeNodes.push(gchildnode);
            }
        }
    }
    return list;
}
//获取群组内容列表
function getGroupInfo(){
    var list = new Array();
    var groupdata = ["群组信息","群组成员"];
    for(var i in groupdata){
        var obj = new News();
        obj.List = groupdata[i];
        list.push(obj);
    }
    return list;
}
//获取群组创建信息
function getNodeMess(info1,creator,admins){
    var list = new Array();
    var info = info1.split('_');
    var obj = new News1();
    obj.ID = info[1];
    obj.List = info[3];
    obj.CreateTime = XLY.Convert.LinuxToDateTime(info[0]);
    obj.Creator = creator;
    obj.Admins = admins;
    list.push(obj);
    return list;
}
//获取群组成员
function getChildNode(path,info){
    var list = new Array();
    var childstr="select participants from conversations where thread_id = '"+info+"'";
    var data = ExecSql(path,childstr);
    var childdata = data[0].participants.split(',');
    for(var i in childdata){
        var childstr1="select * from profiles where username = '"+childdata[i]+"'";
        var childlist = ExecSql(path,childstr1);
        for(var j in childlist){
            var obj = new UserInfo();
            obj.DataState = XLY.Convert.ToDataState(childlist[j].XLY_DataType);
            obj.UserName = childlist[j].username;
            obj.Last = childlist[j].last;
            obj.First = childlist[j].first;
            obj.ImageUrl = childlist[j].image_url;
            obj.EMail = childlist[j].email;
            obj.Phone = childlist[j].phone;
            obj.City = childlist[j].city;
            obj.Geo = childlist[j].geo;
            obj.LastUpdateTime = XLY.Convert.LinuxToDateTime(childlist[j].latest_update_ts);
            list.push(obj);
        }
    }
    return list;
}
//获取聊天记录功能列表
function getChatNews(path,userinfo,info,root,temp){
    var list = new Array();
    var friendstr = "select  distinct(thread_id) from messages where thread_id like 'H%'";
    var frienddata = ExecSql(path,friendstr);
    var groupstr = "select  distinct(thread_id) from messages where thread_id like '1%'";
    var groupdata = ExecSql(path,groupstr);
    for(var i in info){
        if(info[i]=="好友聊天记录"){
            if(frienddata!=null && frienddata!=""){
                var obj = new News();
                obj.List = info[i];
                list.push(obj);
                
                var node = new TreeNode();
                node.Text = info[i];
                node.Type = "News";
                node.Items = getFriendChatList(path,userinfo,node,1,frienddata,temp); 
            }
        }
        else
        {
            if(groupdata!=null && groupdata!=""){
                var obj = new News();
                obj.List = info[i];
                list.push(obj);
                
                var node = new TreeNode();
                node.Text = info[i];
                node.Type = "News";
                node.Items = getFriendChatList(path,userinfo,node,0,groupdata,temp);
            }
        }
        root.TreeNodes.push(node);
    }
    return list;
}
//获取好友聊天记录
function getFriendChatList(path,username,root,flag,data,temp){
    var list = new Array();
    if(flag==1){
        for(var i in data){
            var friendinfo = data[i].thread_id.split('_');
            var obj = new News();
            if(friendinfo[friendinfo.length-1]==username){
                var friendnamestr = "select first,last from profiles where username like'%"+friendinfo[friendinfo.length-2]+"'";
                var friendname = ExecSql(path,friendnamestr);
            }
            else
            {
                var friendnamestr = "select first,last from profiles where username like '%"+friendinfo[friendinfo.length-1]+"'";
                var friendname = ExecSql(path,friendnamestr);
            }
            if(friendname !=null && friendname !=""){
                obj.List=friendname[0].first+' '+friendname[0].last;
                var node = new TreeNode();
                node.Text = friendname[0].first+' '+friendname[0].last;
                node.Type = "Message";
                node.Items = getFriendChatLog(path,data[i].thread_id,node.Text,temp,flag);
                root.TreeNodes.push(node);
                list.push(obj);
            }
        }
    }
    else
    {
        for(var i in data){
            var groupnamestr = "select subject,thread_id from conversations where thread_id='"+data[i].thread_id+"'";
            var groupname = ExecSql(path,groupnamestr);
            if(groupname !=null && groupname != ""){
                var obj = new News();
                obj.List = groupname[0].subject;
                list.push(obj);
                
                var node = new TreeNode();
                node.Text = groupname[0].thread_id.split("_")[1]+"_"+groupname[0].subject;
                node.Type = "Message";
                node.Items = getFriendChatLog(path,data[i].thread_id,groupname[0].thread_id.split("_")[1]+"_"+groupname[0].subject,temp,flag);
                root.TreeNodes.push(node);
            }
        }
    }
    return list;
}
//获取好友聊天记录
function getFriendChatLog(path,info,temp1,temp2,flag){
    var list = new Array();
    var friendlogstr = "select * from messages where thread_id='"+info+"'";
    var friendlog = ExecSql(path,friendlogstr);
    if(friendlog!=null&&friendlog!=""){
        for(var i in friendlog){
            var obj = new Message();
            if(friendlog[i].readers==null || friendlog[i].readers==""){
                obj.IsRead = "否";
            }
            else
            {
                var a = friendlog[i].readers.split(',')[0];
                var readernamestr = "select first,last from profiles where username='"+a+"'";
                var readername = ExecSql(path,readernamestr);
                if(readername==null||readername==""){
                    obj.IsRead = "否";
                }
                else
                {
                    obj.IsRead = "是";
                }
            }
            var sendernamestr = "select first,last from profiles where username='"+friendlog[i].sender+"'";
            var sendername = ExecSql(path,sendernamestr);
            
            obj.DataState = XLY.Convert.ToDataState(friendlog[i].XLY_DataType);
            obj.MessageId = friendlog[i].message_id;
            if(sendername ==null||sendername==""){
                obj.SenderName = "";
            }
            else
            {
                obj.SenderName = sendername[0].first+' '+sendername[0].last;
                if(obj.SenderName==temp1){
                    obj.SenderId = friendlog[i].sender;
                    obj.ReaderName = temp2;
                    var restr = "select profile_username from profiles where first='"+temp2.split(" ")[0]+"'";
                    var rename = ExecSql(path,restr);
                    obj.ReaderId = rename[0].profile_username;
                }
                else
                {
                    
                    if(flag==1){
                        obj.ReaderName = temp1;
                        var restr = "select profile_username from profiles where first='"+temp1.split(" ")[0]+"'";
                        var rename = ExecSql(path,restr);
                        var restr1 = "select profile_username from profiles where first='"+temp2.split(" ")[0]+"'";
                        var rename1 = ExecSql(path,restr1);
                        obj.ReaderId = rename[0].profile_username;
                        obj.SenderId = rename1[0].profile_username
                    }
                    else
                    {
                        obj.ReaderId = temp1.split("_")[0];
                        obj.ReaderName = temp1.split("_")[1];
                        var restr1 = "select profile_username from profiles where first = '"+sendername[0].first+"'";
                        var rename1 = ExecSql(path,restr1);
                        obj.SenderId = rename1[0].profile_username;
                    }
                }
            }
            if(friendlog[i].body==null || friendlog[i].body==""){
                if(friendlog[i].content_json==null||friendlog[i].content_json==""){
                    obj.Body = "";
                }
                else
                {
                    obj.Body = eval('('+friendlog[i].content_json+')').location;
                }
            }
            else
            {
                obj.Body = friendlog[i].body;
            }
            obj.ContentType = friendlog[i].content_type;
            obj.PostedTime = XLY.Convert.LinuxToDateTime(friendlog[i].posted_time);
            obj.Geo = friendlog[i].geo;
            list.push(obj);
        }
        return list;
    }
}
