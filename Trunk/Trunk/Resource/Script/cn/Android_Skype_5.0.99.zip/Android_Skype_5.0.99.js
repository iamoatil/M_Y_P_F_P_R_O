﻿/*[config]
<plugin name="Skype,10" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="icons/skype.png" app="com.skype.rover" version="5.0.99.49715" description="Skype聊天" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.skype.rover/files/#F</value>
</source>

<data type = "Users" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="skypename" type="string" width="100" format = ""></item>
    <item name="性别" code="gender" type="string" width="80" format = ""></item>
    <item name="地址" code="address" type="string" width="200" format = ""></item>
    <item name="联系方式" code="contacts" type="string" width="150" format = ""></item>
    <item name="邮箱" code="email" type="string" width="150" format = ""></item>
    <item name="昵称" code="name" type="string" width="120" format = ""></item>
    <item name="个人主页" code="homepage" type="string" width="200" format = ""></item>
    <item name="注册时间" code="regist" type="datetime" width="150" format = "yyyy-MM-dd"></item>
    <item name="生日" code="birthday" type="datetime" width="150" format = "yyyy-MM-dd"></item>
    <item name="其他" code="sign" type="string" width="" format = "200"></item>
</data>
    
<data type="Contacts" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="skypename" type="string" width="" format="" ></item>
    <item name="昵称" code="name" type="string" width="" format = ""></item>
    <item name="地址" code="address" type="string" width="200" format = ""></item>
    <item name="联系方式" code="contacts" type="string" width="150" format = ""></item>
    <item name="邮箱地址" code="emails" type="string" width="" format = ""></item>
    <item name="个人主页" code="homepage" type="string" width="" format = ""></item>
    <item name="生日" code="birthday" type="datetime" width="" format = "yyyy-MM-dd"></item>
    <item name="其他" code="sign" type="string" width="" format = "200"></item>
</data>

<data type = "Messages" detailfield = "body" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="消息发送者" code="sender" type="string" width="150" format = ""></item>
    <item name="消息接收者" code="receiver" type="string" width="150" format = ""></item>
    <item name="消息内容" code="body" type="string" width="200" format = ""></item>
    <item name="消息类型" code="type" type="string" width="120" format = "" order="desc"></item>
    <item name="发送时间" code="time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="备注" code="remark" type="string" width="120" format = ""></item>
</data>
    


</plugin>
[config]*/

function Users(){
    this.regist = null;
    this.skypename = "";
    this.name = "";
    this.birthday = null;
    this.gender = "";
    this.address = "";
    this.contacts = "";
    this.email = "";
    this.homepage = "";
    this.sign = "";
    this.DataState = "Normal";
}

function Contacts() {
    this.skypename = "";
    this.name = "";
    this.birthday = null;
    this.address = "";
    this.contacts = "";
    this.email = "";
    this.homepage = "";
    this.sign = "";
    this.DataState = "Normal";
}

function Messages(){
    this.sender = "";
    this.receiver = "";
    this.time = null;
    this.type = "";
    this.body = "";
    this.remark = "";
    this.DataState = "Normal";
}


function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

function creatTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

//创建帐号节点
function bindTree(){
    var filepath = eval('('+ XLY.File.FindDirectories(db) +')');
    var root = creatTreeNode("本地帐号","")
    for(var index in filepath){
        var filename = XLY.File.GetFileName(filepath[index]);
        if(filename != "shared_httpfe" && filename != "DataRv"){
            var account = creatTreeNode(filename,"Users")
            var recoveryPath = XLY.Sqlite.DataRecovery(filepath[index]+"\\main.db",charactor,"Accounts,Contacts,Messages");
            account.Items = getAccountInfo(recoveryPath);
            root.TreeNodes.push(account);
            buildChildNodeForAccount(recoveryPath,account);
        }
    }
    return root;
}

//获取账号信息
function getAccountInfo(path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from accounts") +')');
    var info = new Array();
    if(data.length>0){
        for(var index in data){
            var obj = new Users();
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            obj.regist = XLY.Convert.LinuxToDateTime(data[index].mood_timestamp);
            obj.skypename = data[index].skypename;
            obj.name = data[index].fullname;
            obj.birthday = data[index].birthday;
            obj.gender = (data[index].gender = 1)?"男":"女";
            obj.address = getAddressInfo(data[index]);
            obj.contacts = "住宅电话:"+data[index].phone_home+"\n办公电话:"+data[index].phone_office+"\n个人电话:"+data[index].phone_mobile;
            obj.email = data[index].emails;
            obj.homepage = data[index].homepage;
            obj.sign = "个人说明:"+data[index].about+"\n心情:"+data[index].mood_text;
            info.push(obj);
        }
    }
    return info;
}

//获取帐号的地址信息
function getAddressInfo(data){
    var info = "";
    switch(data.country.toLowerCase()){
        case "cn": info = "中国"; break;
        case "us": info = "美国"; break;
        case "tw": info = "台湾"; break;
        case "jp": info = "日本"; break;
        case "hk": info = "香港"; break;
        case "it": info = "意大利"; break;
        case "en": info = "英国"; break;
    }
    if(data.province == "" && data.city==""){
        return info;
    }else if(data.province == "" && data.city != ""){
        return info +"•"+ data.city;
    }else{
        return info +"•"+ data.province +"•"+ data.city;
    }
}

//创建帐号子节点
function buildChildNodeForAccount(path,parent){
    if(XLY.File.IsValid(path)){
        //创建陌生联系人子节点
        var strangeContacts = creatTreeNode("陌生联系人","Contacts");
        strangeContacts.Items = getContactsInfo(path,"select * from Contacts where skypename is '' ");
        //log(strangeContacts.Items);
        buildChildNodeForContacts(path,strangeContacts,parent.Items);

        //创建联系人子节点
        var contacts =  creatTreeNode("联系人","Contacts");
        contacts.Items = getContactsInfo(path,"select * from Contacts where skypename<>'"+parent.Text+"'");
        buildChildNodeForContacts(path,contacts,parent.Items);

        //把子节点装入父节点
        parent.TreeNodes.push(contacts);
        parent.TreeNodes.push(strangeContacts);  
    }
}



//获取联系人信息
function getContactsInfo(path,sql){
    var data = eval('('+ XLY.Sqlite.Find(path,sql) +')');
    var info = new Array();
    if(data.length>0){
        for(var index in data){
            var obj = new Contacts();
            if(data[index].skypename != ""){
                obj.skypename = data[index].skypename;
            }else{
                obj.skypename = data[index].pstnnumber;
            }
            obj.name = data[index].displayname;
            obj.birthday = data[index].birthday;
            obj.address = getAddressInfo(data[index]);
            obj.contacts = "住宅电话:"+data[index].phone_home+"\n办公电话:"+data[index].phone_office+"\n个人电话:"+data[index].phone_mobile;
            obj.email = data[index].emails;
            obj.homepage = data[index].homepage;
            obj.sign = "个人说明:"+data[index].about+"\n心情:"+data[index].mood_text;
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            info.push(obj);
        }
    }    
    return info;
}

//创建（陌生）联系人子节点
function buildChildNodeForContacts(path,node,accname){
    var data = node.Items;
    for(var index in data){
        var child = creatTreeNode(data[index].skypename,"Messages");
        child.DataState = data[index].DataState;
        child.Items = getMessageInfo(path,data[index],accname);
        node.TreeNodes.push(child);
    }
}

//获取（陌生）联系人的通讯记录
function getMessageInfo(path,name,accname){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from messages") +')');
    var info = new Array();
    for(var index in data){
        //log(new RegExp("\$"+name+"").test(data[index].chatname));
        if(data[index].chatname.indexOf(name.skypename)>=0){
            var obj = new Messages();
            if(data[index].chatmsg_status == 4){
                obj.sender = name.name;
                obj.receiver = accname[0].name;
            }else{
                obj.sender = accname[0].name;
                obj.receiver = name.name;
            }
            obj.time = XLY.Convert.LinuxToDateTime(data[index].timestamp);
            
            //根据type与chatmsg_type区分消息的类型
            switch(data[index].chatmsg_type){
                case 18: if(data[index].type == 30) obj.type = "通话开始";
                         if(data[index].type == 39) obj.type = "通话结束"; break;
                case 7: switch(data[index].type){
                    case 68: obj.type = "文件传输"; break;
                    case 64: obj.type = "手机短信"; break;
                }break;
                case 3: switch(data[index].type){
                    case 61: obj.type = "文本消息/表情"; break;
                    default :obj.type = "文本";
                }break;
                default: switch(data[index].type){
                    case 50: obj.type = "系统消息"; break;
                    case 68: obj.type = "文件传输"; break;
                    case 30: obj.type = "通话开始"; break;
                    case 39: obj.type = "通话结束"; break;
                    case 70: obj.type = "视频消息"; break;
                    default: obj.type="其他"
                }break;
            }
            obj.body = data[index].body_xml;
            switch(data[index].reason){
                case "no_answer": obj.remark = "无人接听"; break;
                case "no_skypeout_subscription": obj.remark = "通话失败"; break;
                case "unable_to_connect": obj.remark = "无法接通"; break;
                case "error": obj.remark = "通话错误"; break;
                case "insufficient_funds":obj.remark = "通话故障"; break;
                default :obj.remark = data[index].reason; break;
            }
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            info.push(obj);
        }
    }
    return info;s
}

var source = $source;
var db = source[0];
//var db = "D:\\debug_files\\files";
var charactor = "\\chalib\\Android_Skype_5.0.99\\main.db.charactor";
var result = new Array();
result.push(bindTree());
var res  = JSON.stringify(result);
res;
