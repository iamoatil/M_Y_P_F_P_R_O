﻿/*[config]
<plugin name="支付宝,2" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\ZhiFuBaoWallet.png" app="com.alipay.iphoneclient" version="8.2" description="支付宝钱包" data="$data,ComplexTreeDataSource">
<source>
<value>com.alipay.iphoneclient</value>
</source>

<data type="PaymentRecords" datefilter="Date" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="支付类型" code="Type" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="支出帐号" code="OutAccount" type="string" width="120" ></item>
    <item name="收入帐号" code="InAccount" type="string"  show="true" width="120" ></item>
    <item name="支付金额" code="Amount" type="string" width="150" ></item>
    <item name="支付明细" code="Remark" type="string" width="200" format=""></item>
    <item name="支付时间" code="Date" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
    <item name="支付创建时间" code="CreateDate" type="datetime" format = "yyyy-MM-dd HH:mm:ss" width="140"></item>
</data>

<data type="User">
    <item name="支付宝ID" code="UserId" type="string" width=""></item>
</data>

<data type="BillType">
    <item name="帐单类型" code="Bill" type="string" width=""></item>
</data>

<data type = "Bill">
    <item name="帐单标题" code="Title" type="string" width="220"></item>
    <item name="店铺名称" code="Name" type="string" width = "140"></item>
    <item name="购买时间" code="Date" type="String" width = "140" ></item>
    <item name="金额(元)" code="Price" type="string" width = "100"></item>
    <item name="状态" code="Status" type="string" width="100"></item>
</data>

<data type = "CheckBook">
    <item name="月份" code="Month" type="string" width="220"></item>
    <item name="支出金额" code="Pay" type="double" width = "140"></item>
    <item name="收入金额" code="Income" type="double" width = "140" ></item>
</data>

<data type = "TransferContacts">
    <item name="姓名" code="Name" type="string" width="150"></item>
    <item name="联系电话" code="Phone" type="string" width = "200"></item>
</data>
</plugin>
[config]*/

// js content

//定义PaymentRecords数据结构
function PaymentRecords() {
    this.Type = "";
    this.OutAccount = "";
    this.InAccount = "";
    this.Amount = "";
    this.Remark = "";
    this.DataState = "Normal";
    this.Date = null;
    this.CreateDate = null;
}

//定义User数据结构
function User(){
    this.UserId = "";
}

//定义BillType数据结构
function BillType(){
    this.Bill = "";
}

//定义Bill数据结构
function Bill(){
    this.Title = "";
    this.Name = "";
    this.Price = "";
    this.Date = "";
    this.Status = "";
}

//定义CheckBook数据结构
function CheckBook(){
    this.Month = "";
    this.Pay = 0;
    this.Income = 0;
}
//定义TransferContacts数据结构
function TransferContacts(){
    this.Name = "";
    this.Phone = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.Type = ""; //节点[Items]的数据类型
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。 
    this.DataState = "Normal";
}

//创建树结构
function createTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

//创建根节点信息
function bindTree(){
    var rootNode =  createTreeNode("本地帐户信息","User");
    buildChildTreeForRootNode(rootNode);
    return rootNode;
}

//创建根据节点的子节点
function buildChildTreeForRootNode(root){
    
    //获取当前所有帐号
    var filename = eval('('+ XLY.File.FindDirectories(path+"\\Documents\\wealth") +')');
    for(var index  in filename){
        var childNode = createTreeNode(XLY.File.GetFileName(filename[index]),"User");
        var obj = new User();
        obj.UserId = childNode.Text;
        childNode.Items.push(obj);
        
        //获取帐号的支付信息
        var payRecord = createTreeNode("支付流水","PaymentRecords");
        var recoveryPath = XLY.Sqlite.DataRecovery(filename[index]+"\\tally.data",charactor,"ACCOUNT,CATEGORY,TALLY_FLOW");
        payRecord.Items = getPaymentRecordsInfo(recoveryPath);
        
        var bill = createTreeNode("账单信息","BillType");
        getBillInfo(bill,childNode.Text)
        
        //创建转账联系人树结构
        buildTransferContacts(childNode,childNode.Text);
        
        childNode.TreeNodes.push(payRecord);
        childNode.TreeNodes.push(bill);
        root.TreeNodes.push(childNode);
        root.Items.push(obj);
    }
}

//处理用户支付信息
function getPaymentRecordsInfo(path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from TALLY_FLOW") +')');
    var info = new Array();
    for(var index in data){
        var obj = new PaymentRecords();
        
        //获取支付类型
        var typedata = getColumnInfo(path,"CATEGORY",data[index].categoryUuid);
        obj.Type = typedata[0].name;
        
        //获取支出信息
        var outdata = getColumnInfo(path,"ACCOUNT",data[index].outAccountUuid);
        if(outdata != null){
            obj.OutAccount = outdata[0].name+","+outdata[0].subName;
        }
        
        //获取收入信息
        if(data[index].inAccountUuid != ""){
            var indata = getColumnInfo(path,"ACCOUNT",data[index].inAccountUuid);
            obj.InAccount = indata[0].name+","+indata[0].subName;
        }
        obj.Amount = data[index].amount;
        obj.Remark = data[index].remark;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].gmtDate);
        obj.CreateDate = XLY.Convert.LinuxToDateTime(data[index].gmtCreate);
        info.push(obj);
    }
    return info;
}

//获取特定列的详细信息
function getColumnInfo(path,table,column){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from '"+table+"' where uuid = '"+column+"'") +')');
    if(data.length>0){
        return data;
    }
}

//获取帐单信息
function getBillInfo(node,num){
    var data = eval('('+ XLY.PList.ReadToJsonString(path+"\\Library\\Preferences\\com.alipay.iphoneclient.plist") +')');
    for(var index in data){
        for(var key in data[index]){
            if(new RegExp(""+num+"_toBillListALL").test(key)){
                var allbill = createTreeNode("记账本","CheckBook");  
                getAllBillInfo(data[index][key],allbill);
                node.TreeNodes.push(allbill);
                
                //获取帐单的Item
                var obj = new BillType();
                obj.Bill = allbill.Text;
                node.Items.push(obj)
                
            }else if(new RegExp(""+num+"_toBillListPROCESSING").test(key)){
                var processbill = createTreeNode("待处理","Bill");
                processbill.Items = getProcessBillInfo(data[index][key]);
                node.TreeNodes.push(processbill);
                
                //获取帐单的Item
                var obj = new BillType();
                obj.Bill = processbill.Text;
                node.Items.push(obj)
            }
        }
    }
}


//获取记账本的各月订单信息
function getAllBillInfo(data,node){
    var info = data[0];
    for(var index in info){
        var childNode = createTreeNode(getTargetContent(info[index],"month"),"Bill");
        childNode.Items = getProcessBillInfo(info[index]);
        
        node.TreeNodes.push(childNode);               //创建记账本的子节点
        node.Items.push(getInfoForAllBill(info[index]));
    }
}


//获取记账节点的信息
function getInfoForAllBill(data){
    var info = getTargetContent(data,"info");
    var obj = new CheckBook();
    obj.Month = getTargetContent(info,"month");
    obj.Pay = getTargetContent(info,"pay");
    obj.Income = getTargetContent(info,"income");
    return obj;
}

//获取待处理订单的信息
function getProcessBillInfo(data){
    var info = new Array();
    
    //此处默认data节点在数据的第一个元素位置
    var processData = data[0].data[0];
    for(var index in processData){
        var obj = new Bill();
        obj.Title = getTargetContent(processData[index],"title");
        var userinfo = getTargetContent(processData[index],"userInfo");
        obj.Name = userinfo[1]['userName'];                         //userinfo的value是一个仅包含usericon和username的2个元素的数组
        obj.Date = getTargetContent(processData[index],"date");
        obj.Price = getTargetContent(processData[index],"money");
        obj.Status = getTargetContent(processData[index],"status");
        info.push(obj);
    }
    return info;
}

//匹配特定的字符串对象
function getTargetContent(data,target){
    for(var index in data){
        for(var key in data[index]){
            if(key == target){
                return data[index][key];
            }
        }
    }
}

//递归获取特定的字符串对象
//function getTargetContent(data,target){
//    if(target != "userName"){
//        for(var index in data){
//                for(var key in data[index]){
//                    if(key == target){
//                        return data[index][key];
//                    }
//                }
//            }
//    }else{
//        var userinfo = getTargetContent(data,"userInfo");
//        return userinfo[1]["userName"];
//    }
//}

//创建转账联系人
function buildTransferContacts(root,num){
    var filename = eval('('+ XLY.File.FindFiles(path+"\\Documents") +')');
    for(var index in filename){
        if(new RegExp("UploadAdressBook-"+num+"").test(filename[index])){
            var transferContact = createTreeNode("转帐联系人","TransferContacts");
            var data = eval('('+ XLY.PList.ReadToJsonString(filename[index]) +')');
            transferContact.Items = getTransferContactsInfo(data);
            root.TreeNodes.push(transferContact)
        }
    } 
}

//获取转账联系人信息
function getTransferContactsInfo(data){
    var info = new Array();
    var con = data[1]['$objects'][0]['NSMutableDictionary'];
        for (var num in con){
            for(var key in con[num]){
                var contacts = con[num][key]['AdressBookPersonInfo']
                var obj = new TransferContacts();
                obj.Name = contacts[2].n;
                for(var i in contacts[0].c.NSMutableArray){
                    obj.Phone += contacts[0].c.NSMutableArray[i]["-1"]+";";
                }
                info.push(obj);
            }
        }
    return info;
}
var result = new Array();
//源文件
var source = $source;
var path = source[0]+"\\com.alipay.iphoneclient";
//var path = "C:\\XLYSFTasks\\未命名-2\\source\\IosData\\2014-07-28-13-48-23\\com.alipay.iphoneclient";
var charactor = "\\chalib\\IOS_7.1_ZhiFuBaoWallet_8.2\\tally.data.charactor";

// return
result.push(bindTree());
var res = JSON.stringify(result);
res;
