﻿
//descritpion:配置模板

/*[config]
<plugin name="同步账号,22" group="基本信息,1" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="\icons\device.png" app="com.android.providers.contacts" data="$data" description="同步账号" >
<source>
    <value>/data/data/com.android.providers.contacts/databases/#F</value>
</source>
<data>
    <item name="账户名称" code="Name" type="string" width="220" ></item>
    <item name="账户类型" code="Type" type="string" width="240" format=""></item>
</data>
</plugin>
[config]*/

// js content


function Info() {
    this.Name = "";   //账户名称
    this.Type = ""; //账户类型
}

var result = new Array();
//源文件
var source = $source;
var db = source[0] + "\\contacts2.db";
//var db = "D:\\temp\\data\\data\\com.android.providers.contacts\\databases\\contacts2.db";
var list = eval('('+ XLY.Sqlite.FindByName(db,"accounts") +')'); 
for(var i in list){
    var obj = new Info();
    var row = list[i];
    obj.Name = row.account_name;
    obj.Type = row.account_type;
    if(obj.Name !=null){
        result.push(obj);
    }
}


// return
var res = JSON.stringify(result);
res;










