﻿/*[config]
<plugin name="Tango,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/tango.png" app="com.sgiggle.Tango" version="4.0.218442" description="Tango" data = "$data,ComplexTreeDataSource" >
<source>
    <value>com.sgiggle.Tango</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="AccountId" type="string" width="120" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="背景" code="BackGroudUrl" type="url" width="120" format = "" ></item>
    <item name="出生年月" code="Birthday" type="string" width="120" format = "" ></item>
    <item name="电话号码" code="PhoneNumber" type="string" width="120" format = "" ></item>
    <item name="个性签名" code="Sign" type="string" width="120" format = "" ></item>
    <item name="国家" code="Country" type="string" width="120" format = "" ></item>
    <item name="经度" code="Lng" type="string" width="120" format = "" ></item>
    <item name="纬度" code="Lat" type="string" width="120" format = "" ></item>
    <item name="最后登录时间" code="LastLoadingTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="邮箱" code="Email" type="string" width="120" format = "" ></item>
</data>
<data type="Contact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="UserName" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="生日" code="Birthday" type="string" width="120" format=""></item>
    <item name="个性签名" code="PersonSign" type="string" width="120" format=""></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="背景" code="BackGroudUrl" type="url" width="120" format = "" ></item>
    <item name="距离" code="Distence" type="string" width="120" format=""></item>
    <item name="最后登录时间" code="LastLoadingTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="GroupInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群昵称" code="GroupNickName" type="string" width="200" format = "" ></item>
    <item name="群成员" code="GroupMember" type="string" width="200" format = "" ></item>
</data>
<data type="Message" contract="DataState" datefilter="Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format=""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="接收者ID" code="ReciveID" type="string" width="120" format=""></item>
    <item name="接收者姓名" code="ReciveName" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="100" format = ""></item>
    <item name="类型" code="ContentType" type="string" width="100" format = ""></item>
    <item name="附件" code="Attachment" type="string" width="100" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="发送时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="经度" code="Lng" type="string" width="100" format = ""></item>
    <item name="纬度" code="Lat" type="string" width="100" format=""></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.AccountId = "";
    this.NickName = "";
    this.Sex = "";
    this.HeadUrl = "";
    this.BackGroudUrl = "";
    this.Birthday = "";
    this.PhoneNumber = "";
    this.Sign = "";
    this.Country = "";
    this.Lng = "";
    this.Lat = "";
    this.LastLoadingTime = null;
    this.Email = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.HeadUrl = "";
    this.BackGroudUrl = "";
    this.UserName = "";
    this.Birthday = "";
    this.PersonSign = "";
    this.Distence  = "";
    this.Sex = "";
    this.LastLoadingTime = null;
}
//定义GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupNickName = "";
    this.GroupMember = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReciveID = "";
    this.ReciveName = "";
    this.ContentType = "";
    this.StartTime = null;
    this.Content = "";
    this.Attachment = "";
    this.Lng = "";
    this.Lat = "";
}
//Cache数据结构
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allDBPath = source[0]+"\\com.sgiggle.Tango\\Documents\\.sgiggle";
var userPath = source[0]+"\\com.sgiggle.Tango\\Library\\Preferences\\com.sgiggle.Tango.plist";
//测试数据
//var allDBPath = "D:\\Program Files\\MobileMaster\\DC-4501 手机取证系统\\案例\\案例（20170518100802）\\iPhone 5C(4)\\Backup\\Applications\\com.sgiggle.Tango\\Documents\\.sgiggle";
//var cachePath = "D:\\Program Files\\MobileMaster\\DC-4501 手机取证系统\\案例\\案例（20170518100802）\\iPhone 5C(4)\\Backup\\Applications\\com.sgiggle.Tango\\Library\\Cookies\\Cookies.binarycookies";
//var userPath = "D:\\Program Files\\MobileMaster\\DC-4501 手机取证系统\\案例\\案例（20170518100802）\\iPhone 5C(4)\\Backup\\Applications\\com.sgiggle.Tango\\Library\\Preferences\\com.sgiggle.Tango.plist";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_Tango_4.0.218442\\discoveryFavoritesDB_rel_3.db.charactor";
var charactor2 = "\\chalib\\iOS_Tango_4.0.218442\\profilecache.db.charactor";
var charactor3 = "\\chalib\\iOS_Tango_4.0.218442\\tc.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "Tango";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var contactPath1 = allDBPath+"\\profilecache.db";
        var contactPath = XLY.Sqlite.DataRecovery(contactPath1,charactor2,"profiletable");
        var data = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        var a = new Base64();
        if(data!=""&&data!= null){
            var aa = "";
            var bb = "";
            var cc = "";
            for(var i in data){
                if(data[i]["userinfo.xml::AccountId"]){
                    aa = utf16to8(a.decode(data[i]["userinfo.xml::AccountId"])).toString();
                }
                if(data[i]["userinfo.xml::email"]){
                    bb = utf16to8(a.decode(data[i]["userinfo.xml::email"])).toString();
                }
                if(data[i]["userinfo.xml::phonenumber"]){
                    cc = utf16to8(a.decode(data[i]["userinfo.xml::phonenumber"])).toString();
                }
            }
            if(aa!= ""){
                var userNode = new TreeNode();
                userNode.Type = "UserInfo";
                var obj = new UserInfo();
                var userData = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,itemUserId,itemFirstName,itemLastName,itemBirthday,itemGender,itemStatus,itemDistance,itemAvatarUrl,itemBackgroundUrl,itemLastLocalAccessTime from profiletable where itemUserId = '"+aa+"'") +')');
                obj.DataState = XLY.Convert.ToDataState(userData[0].XLY_DataType);
                obj.HeadUrl = userData[0].itemAvatarUrl;
                obj.BackGroudUrl = userData[0].itemBackgroundUrl;
                if(userData[0].itemGender=="male"){
                    obj.Sex = "男";
                }
                else if(userData[0].itemGender=="female")
                {
                    obj.Sex = "女";
                }
                else
                {
                    obj.Sex = "未指定";
                }
                
                try{
                    var lname = XLY.Blob.ToBytes(userData[0].itemLastName,"base64");
                    var fname = XLY.Blob.ToBytes(userData[0].itemFirstName,"base64");
                    obj.NickName = XLY.Blob.ToString(fname)+" "+XLY.Blob.ToString(lname);
                }
                catch(err)
                {
                    var lname = userData[0].itemLastName;
                    var fname = userData[0].itemFirstName;
                    obj.NickName = lname+" "+fname;
                }
                obj.Birthday = userData[0].itemBirthday;
                try{
                    var sign = XLY.Blob.ToBytes(userData[0].itemStatus,"base64");
                    obj.PersonSign = XLY.Blob.ToString(sign);
                }
                catch(err)
                {
                    var sign = userData[0].itemStatus;
                    obj.PersonSign = sign;
                }
                if(userData[0].itemDistance!='-1'){
                    obj.Distence  = contactinfo[0].itemDistance+"千米";
                }
                obj.LastLoadingTime = XLY.Convert.LinuxToDateTime(userData[0].itemLastLocalAccessTime);
                obj.PhoneNumber = cc;
                obj.Email = bb;
                userNode.Text = obj.NickName+"_"+obj.PhoneNumber;
                userNode.Items.push(obj);
                getUserChildNode(userNode,obj,contactPath);
                root.TreeNodes.push(userNode);
            }
        }
    }
}
function Base64() {
 
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
 
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }
 
    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }
 
    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
 
        }
        return utftext;
    }
 
    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}

function utf16to8(str) {
    var out, i, len, c;

    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
    c = str.charCodeAt(i);
    if ((c >= 0x0001) && (c <= 0x007F)) {
        out += str.charAt(i);
    } else if (c > 0x07FF) {
        out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
        out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    } else {
        out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    }
    }
    return out;
}
function getUserChildNode(root,userobj,contactPath){
    
    var gInfoPath1 = allDBPath+"\\tc.db";
    var gInfoPath = XLY.Sqlite.DataRecovery(gInfoPath1,charactor3,"messages,conversations");
    if(XLY.File.IsValid(contactPath)){
        var contactNode = new TreeNode();
        contactNode.Text = "联系人";
        contactNode.Type = "News";
        
        var groupInfoNode = new TreeNode();
        groupInfoNode.Text = "群组信息";
        groupInfoNode.Type = "News";
        
        var messageNode = new TreeNode();
        messageNode.Text = "消息";
        messageNode.Type = "News";
        
        
        var groupMessageNode = new TreeNode();
        groupMessageNode.Text = "群消息";
        groupMessageNode.Type = "News";
        messageNode.TreeNodes.push(groupMessageNode);
        
        var friendMessageNode = new TreeNode();
        friendMessageNode.Text = "好友消息";
        friendMessageNode.Type = "News";
        messageNode.TreeNodes.push(friendMessageNode);
        
        var contactinfo = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,itemUserId,itemFirstName,itemLastName,itemBirthday,itemGender,itemStatus,itemDistance,itemAvatarUrl,itemBackgroundUrl,itemLastLocalAccessTime from profiletable where itemIsFriend = '1'") +')');
        if(contactinfo!=""&&contactinfo!= null){
            var myFriendNode = new TreeNode();
            myFriendNode.Text = "我的好友";
            myFriendNode.Type = "Contact";
            for(var i in contactinfo){
                var obj = new Contact();
                obj.DataState = XLY.Convert.ToDataState(contactinfo[i].XLY_DataType);
                obj.HeadUrl = contactinfo[i].itemAvatarUrl;
                obj.BackGroudUrl = contactinfo[i].itemBackgroundUrl;
                if(contactinfo[i].itemGender=="male"){
                    obj.Sex = "男";
                }
                else if(contactinfo[i].itemGender=="female")
                {
                    obj.Sex = "女";
                }
                else
                {
                    obj.Sex = "未指定";
                }
                try{
                    var lname = XLY.Blob.ToBytes(contactinfo[i].itemLastName,"base64");
                    var fname = XLY.Blob.ToBytes(contactinfo[i].itemFirstName,"base64");
                    obj.UserName = XLY.Blob.ToString(fname)+" "+XLY.Blob.ToString(lname);
                }
                catch(err)
                {
                    var lname = contactinfo[i].itemLastName;
                    var fname = contactinfo[i].itemFirstName;
                    obj.UserName = lname+" "+fname;
                }
                obj.Birthday = contactinfo[i].itemBirthday;
                try{
                    var sign = XLY.Blob.ToBytes(contactinfo[i].itemStatus,"base64");
                    obj.PersonSign = XLY.Blob.ToString(sign);
                }
                catch(err)
                {
                    var sign = contactinfo[i].itemStatus;
                    obj.PersonSign = sign;
                }
                if(contactinfo[i].itemDistance!='-1'){
                    obj.Distence  = contactinfo[i].itemDistance+"千米";
                }
                obj.LastLoadingTime = XLY.Convert.LinuxToDateTime(contactinfo[i].itemLastLocalAccessTime);
                myFriendNode.Items.push(obj);
            }
            contactNode.TreeNodes.push(myFriendNode);
        }
        //var contactinfo = eval('('+ XLY.Sqlite.Find(contactPath,"select itemUserId,itemFirstName,itemLastName,itemBirthday,itemGender,itemStatus,itemDistance,itemAvatarUrl,itemBackgroundUrl,itemLastLocalAccessTime from profiletable where itemIsFriend = '1'") +')');
        var userContactIdPath1 = allDBPath+"\\discoveryFavoritesDB_rel_3.db";
        var userContactIdPath = XLY.Sqlite.DataRecovery(userContactIdPath1,charactor1,"Favorites");
        if(XLY.File.IsValid(userContactIdPath)){
            var usualContactId = eval('('+ XLY.Sqlite.Find(userContactIdPath,"select accountId from Favorites") +')');
            if(usualContactId!=""&&usualContactId!= null){
                var nodeFavorite = new TreeNode();
                nodeFavorite.Text = "关注";
                nodeFavorite.Type = "Contact";
                for(var j in usualContactId){
                    var dataFavorite = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,itemFirstName,itemLastName,itemBirthday,itemGender,itemStatus,itemDistance,itemAvatarUrl,itemBackgroundUrl,itemLastLocalAccessTime from profiletable where itemUserId = '"+usualContactId[j].accountId+"'") +')');
                    if(dataFavorite!=""&&dataFavorite!= null){
                        for(var m in dataFavorite){
                            var obj = new Contact();
                            obj.DataState = XLY.Convert.ToDataState(dataFavorite[m].XLY_DataType);
                            obj.HeadUrl = dataFavorite[m].itemAvatarUrl;
                            obj.BackGroudUrl = dataFavorite[m].itemBackgroundUrl;
                            if(dataFavorite[m].itemGender=="male"){
                                obj.Sex = "男";
                            }
                            else if(dataFavorite[m].itemGender=="female")
                            {
                                obj.Sex = "女";
                            }
                            else
                            {
                                obj.Sex = "未指定";
                            }
                            try{
                                var lname = XLY.Blob.ToBytes(dataFavorite[m].itemLastName,"base64");
                                var fname = XLY.Blob.ToBytes(dataFavorite[m].itemFirstName,"base64");
                                obj.UserName = XLY.Blob.ToString(fname)+" "+XLY.Blob.ToString(lname);
                            }
                            catch(err)
                            {
                                var lname = dataFavorite[m].itemLastName;
                                var fname = dataFavorite[m].itemFirstName;
                                obj.UserName = lname+" "+fname;
                            }
                            obj.Birthday = dataFavorite[m].itemBirthday;
                            try{
                                var sign = XLY.Blob.ToBytes(dataFavorite[m].itemStatus,"base64");
                                obj.PersonSign = XLY.Blob.ToString(sign);
                            }
                            catch(err)
                            {
                                var sign = dataFavorite[m].itemStatus;
                                obj.PersonSign = sign;
                            }
                            if(dataFavorite[m].itemDistance!='-1'){
                                obj.Distence  = dataFavorite[m].itemDistance+"千米";
                            }
                            obj.LastLoadingTime = XLY.Convert.LinuxToDateTime(dataFavorite[m].itemLastLocalAccessTime);
                            nodeFavorite.Items.push(obj);
                        }
                    }
                }
                contactNode.TreeNodes.push(nodeFavorite);
            }
            var contactGeneral = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,itemUserId,itemFirstName,itemLastName,itemBirthday,itemGender,itemStatus,itemDistance,itemAvatarUrl,itemBackgroundUrl,itemLastLocalAccessTime from profiletable where itemIsFriend <> '1'") +')');
            if(contactGeneral!=""&&contactGeneral!= null){
                var generalNode = new TreeNode();
                generalNode.Text = "一般联系人";
                generalNode.Type = "Contact";
                for(var n in contactGeneral){
                    var fur = 0;
                    for(var p in usualContactId){
                        if(contactGeneral[n].itemUserId==usualContactId[p].accountId){
                            fur = 1;
                        }
                    }
                    if(fur==0){
                        var generalObj = new Contact();
                        generalObj.DataState = XLY.Convert.ToDataState(contactGeneral[m].XLY_DataType);
                        generalObj.HeadUrl = contactGeneral[n].itemAvatarUrl;
                        generalObj.BackGroudUrl = contactGeneral[n].itemBackgroundUrl;
                        if(contactGeneral[n].itemGender=="male"){
                            generalObj.Sex = "男";
                        }
                        else if(contactGeneral[n].itemGender=="female")
                        {
                            generalObj.Sex = "女";
                        }
                        else
                        {
                            generalObj.Sex = "未指定";
                        }
                        try{
                            var lname = XLY.Blob.ToBytes(contactGeneral[n].itemLastName,"base64");
                            var fname = XLY.Blob.ToBytes(contactGeneral[n].itemFirstName,"base64");
                            generalObj.UserName = XLY.Blob.ToString(fname)+" "+XLY.Blob.ToString(lname);
                        }
                        catch(err)
                        {
                            var lname = contactGeneral[n].itemLastName;
                            var fname = contactGeneral[n].itemFirstName;
                            generalObj.UserName = lname+" "+fname;
                        }
                        generalObj.Birthday = contactGeneral[n].itemBirthday;
                        try{
                            var sign = XLY.Blob.ToBytes(contactGeneral[n].itemStatus,"base64");
                            generalObj.PersonSign = XLY.Blob.ToString(sign);
                        }
                        catch(err)
                        {
                            var sign = contactGeneral[n].itemStatus;
                            generalObj.PersonSign = sign;
                        }
                        generalObj.Birthday = contactGeneral[n].itemBirthday;
                        if(contactGeneral[n].itemDistance!='-1'){
                            generalObj.Distence  = contactGeneral[n].itemDistance+"千米";
                        }
                        generalObj.LastLoadingTime = XLY.Convert.LinuxToDateTime(contactGeneral[n].itemLastLocalAccessTime);
                        generalNode.Items.push(generalObj);
                    }
                }
                contactNode.TreeNodes.push(generalNode);
            }
        }
        if(XLY.File.IsValid(gInfoPath)){
            var groupData = eval('('+ XLY.Sqlite.Find(gInfoPath,"select conv_id,cast(payload as TEXT) as payload from conversations where conv_type = '1'") +')');
            var friendData = eval('('+ XLY.Sqlite.Find(gInfoPath,"select conv_id from conversations where conv_type = '0'") +')');
            if(friendData!=""&&friendData!= null){
                for(var f in friendData){
                    var friendName = eval('('+ XLY.Sqlite.Find(contactPath,"select itemFirstName,itemLastName from profiletable where itemUserId = '"+friendData[f].conv_id+"'") +')')
                    if(friendName!=""&&friendName!=null){
                        var nodeFr = new TreeNode();
                        var lname = XLY.Blob.ToBytes(friendName[0].itemLastName,"base64");
                        var fname = XLY.Blob.ToBytes(friendName[0].itemFirstName,"base64");
                        nodeFr.Text = XLY.Blob.ToString(fname)+" "+XLY.Blob.ToString(lname);
                        nodeFr.Type = "Message";
                        getGroupMessage(nodeFr,friendData[f].conv_id,nodeFr.Text,gInfoPath,userobj,contactPath);
                        friendMessageNode.TreeNodes.push(nodeFr);
                    }
                }
            }
            if(groupData!=""&&groupData!= null){
                for(var k in groupData){
                    
                    var playd = XLY.Blob.ToBytes(groupData[k].payload,"base64");
                    var noddGroupInfoNode = new TreeNode();
                    noddGroupInfoNode.Type = "GroupInfo";
                    var groupmember = getBinaryGroupMsgPayload(playd,noddGroupInfoNode);
                    var groupNodeObj = new GroupInfo();
                    if(groupmember!=""&&groupmember!= null){
                        var infoMsg = "名称:"+userobj.NickName+"\r"+"ID:"+userobj.AccountId+"\r"+"Email:"+userobj.Email+"\r";
                        var nameMsg = userobj.NickName+",";
                        for(var m in groupmember){
                            infoMsg += "名称:"+groupmember[m].firstname+" "+groupmember[m].lasttname+"\r"+"ID:"+groupmember[m].userid+"\r"+"Email:"+groupmember[m].useremail+"\r";
                            nameMsg += groupmember[m].firstname+" "+groupmember[m].lasttname +",";
                        }
                        groupNodeObj.GroupNickName = noddGroupInfoNode.Text;
                        groupNodeObj.GroupMember = infoMsg;
                        if(noddGroupInfoNode.Text == "a"){
                            noddGroupInfoNode.Text = nameMsg.substr(0,nameMsg.length-2);
                            groupNodeObj.GroupNickName = noddGroupInfoNode.Text;
                        }
                        noddGroupInfoNode.Items.push(groupNodeObj);
                        groupInfoNode.TreeNodes.push(noddGroupInfoNode);
                        
                        var nodeGroupMessage = new TreeNode();
                        nodeGroupMessage.Text = groupNodeObj.GroupNickName;
                        nodeGroupMessage.Type = "Message";
                        groupMessageNode.TreeNodes.push(nodeGroupMessage);
                        getGroupMessage(nodeGroupMessage,groupData[k].conv_id,nodeGroupMessage.Text,gInfoPath,userobj,contactPath);
                    }
                }
                
            }
        }
        root.TreeNodes.push(groupInfoNode);
        root.TreeNodes.push(messageNode);
        root.TreeNodes.push(contactNode);
    }
}
function getBinaryGroupMsgPayload(temp,root){
    var arr = new Array();
    if(temp.length>0&&temp!=null){
        var size = temp.length;
        var a = 0x02;
        var b = 0x02;
        
        if(temp[a]==0x1A){
            a+= 1;
            b = a+1;
            var info1 = XLY.Blob.GetBytes(temp,b,temp[a]);
            a+= temp[a]+1;
            b = a+1;
            if(temp[a]==0x20){
                a+= 5;
                b = a+1;
                var info1 = XLY.Blob.GetBytes(temp,b,temp[a]);
                a+= temp[a]+0x11;
                b = a+1;
            }
            while(a<size){
                if(temp[a]==0x32){
                    a+= 1;
                    b = a+1;
                    var info2 = XLY.Blob.GetBytes(temp,b,temp[a]);
                    arr.push(asfae(info2));
                    a+= temp[a];
                    a+= 1;
                    continue;
                }
                else if(temp[a]==0x38)
                {
                    a+= 4;
                    if(temp[a]==0x4A){
                        a+= 1;
                        b = a+1;
                        var info3 = XLY.Blob.GetBytes(temp,b,temp[a]);
                        root.Text = XLY.Blob.ToString(info3);
                    }
                    else
                    {
                        root.Text = "a";
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }
    return arr;
}
function asfae(temp){
    var info = {};
    var size = temp.length;
    var a = 0;
    var b = 0;
    if(temp[a]==0x0A){
        a+= 1;
        b+= 2;
        //log(b);
        var info1 = XLY.Blob.GetBytes(temp,b,temp[a]);
        info.firstname = XLY.Blob.ToString(info1);
        b+= temp[a]+2;
        a+= temp[a]+1;
        if(temp[a]==0x12){
            a+= 1;
            var info2 = XLY.Blob.GetBytes(temp,b,temp[a]);
            info.lasttname = XLY.Blob.ToString(info2);
            b+= temp[a]+2;
            a+= temp[a]+1;
            if(temp[a]==0x1A){
                a+= 1;
                var info3 = XLY.Blob.GetBytes(temp,b,temp[a]);
                info.userid = XLY.Blob.ToString(info3);
                b+= temp[a]+2;
                a+= temp[a]+1;
                if(temp[a]==0x2A){
                    a+= 1;
                    var info4 = XLY.Blob.GetBytes(temp,b,temp[a]);
                    info.useremail = XLY.Blob.ToString(info4);
                    b+= temp[a]+2;
                    a+= temp[a]+1;
                    if(temp[a]==0x78){
                        a+= 5;
                        b= a+1;
                    }
                }
                else
                {
                    info.useremail = "";
                }
            }
            else
            {
                info.userid = "";
            }
        }
        else
        {
            info.lasttname = "";
        }
    }
    else
    {
        info.firstname = "";
    }
    return info;
}
function getGroupMessage(root,id,name,path,userobj,userpath){
    var data = eval('('+ XLY.Sqlite.Find(path,"select cast(payload as TEXT) as payload,msg_id,type,conv_id,send_time,direction,media_id,XLY_DataType from messages where conv_id = '"+id+"'") +')');
    if(data!=""&&data!=null){
        for(var i in data){
            if(data[i].XLY_DataType==2){
                var obj = new Message();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                if(data[i].payload!=""&&data[i].payload!= null){
                    var playd = XLY.Blob.ToBytes(data[i].payload,"base64");
                    if(data[i].type==0){
                        var temp = getMessageBinary(playd,data[i].direction,data[i].msg_id,data[i].type);
                        if(data[i].direction==1){
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        else if(data[i].direction==2)
                        {
                            obj.SenderID = temp.senderId;
                            obj.SenderName = temp.senderFirstName+" "+temp.senderLastName;
                        }
                        else
                        {
                            
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "讯息";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        if(temp.content!=""){
                            obj.Content = temp.content;
                        }
                        else
                        {
                            obj.Content = "表情";
                        }
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==2)
                    {
                        var temp = getMessagePhotoBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.senderId;
                            obj.SenderName = temp.senderFirstName+" "+temp.senderLastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "语音";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = temp.musicName;
                        obj.Attachment = data[i].media_id;
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==3){
                        var temp = getMessageTruePhotoBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.uId;
                            obj.SenderName = temp.firstName+" "+temp.lastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "图片";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = temp.photoUrl;
                        obj.Attachment = data[i].media_id;
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==1){
                        var temp = getMessageTruePhotoBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.uId;
                            obj.SenderName = temp.firstName+" "+temp.lastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "视频";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = temp.photoUrl;
                        obj.Attachment = data[i].media_id;
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==4)
                    {
                        var temp = getMessageAddressBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.uId;
                            obj.SenderName = temp.firstName+" "+temp.lastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "地理位置";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = "标题：\r"+temp.title+"\r"+"地址：\r"+temp.address+"\r"+"地址链接：\r"+temp.url;
                        obj.Attachment = data[i].media_id;
                        if(temp.url!=""){
                            obj.Lng = temp.url.split("@")[1].split(",")[1];
                            obj.Lat = temp.url.split("@")[1].split(",")[0];
                        }
                        
                    }
                    else if(data[i].type==11){
                        if(data[i].conv_id.split(":")[0]!="FAKE_GROUP"){
                            var temp = getMessageAddMemberBinary(playd,data[i].direction);
                            if(data[i].direction==2){
                                if(temp.creator!=""&&temp.creator!=null){
                                    obj.SenderID = temp.creator.uId1;
                                    obj.SenderName = temp.creator.firstName1+" "+temp.creator.lastName1;
                                    var feru = "";
                                    if(temp.member!=""&&temp.member!=null){
                                        for(var m in temp.member){
                                            if(m==temp.member.length-1){
                                                feru+= temp.member[m].firstName+" "+temp.member[m].lastName;
                                            }
                                            else
                                            {
                                                feru+= temp.member[m].firstName+" "+temp.member[m].lastName+",";
                                            }
                                        }
                                    }
                                    obj.Content = obj.SenderName+" 邀请了 "+feru+"加入群";
                                }
                            }
                            else
                            {
                                var feru = "";
                                if(temp.member!=""&&temp.member!=null){
                                    for(var m in temp.member){
                                        if(m==temp.member.length-1){
                                            feru+= temp.member[m].firstName+" "+temp.member[m].lastName;
                                        }
                                        else
                                        {
                                            feru+= temp.member[m].firstName+" "+temp.member[m].lastName+",";
                                        }
                                    }
                                }
                                obj.SenderID = userobj.AccountId;
                                obj.SenderName = userobj.NickName;
                                
                                obj.Content = "您邀请了 "+feru+"加入群";
                            }
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                            
                            obj.ContentType = "系统提示";
                            obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                            
                            obj.Attachment = data[i].media_id;
                            obj.Lng = "";
                            obj.Lat = "";
                        }
                    }
                    else if(data[i].type==12)
                    {
                        var temp = getMessageSysDelBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            if(temp.senderId!=""){
                                obj.SenderID = temp.senderId;
                                obj.SenderName = temp.senderFirstName+" "+temp.senderLastName;
                                obj.Content = obj.SenderName+"把"+temp.delFirstName+" "+temp.delLastName+"踢出了群聊";
                            }
                            else
                            {
                                obj.SenderID = temp.delId;
                                obj.SenderName = temp.delFirstName+" "+temp.delLastName;
                                obj.Content = obj.SenderName+"离开了群聊";
                            }
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            var aa = eval('('+ XLY.Sqlite.Find(userpath,"select itemFirstName,itemLastName from profiletable where itemUserId = '"+temp.delId+"'") +')');
                            if(aa!=""&&aa!=null){
                                obj.Content = userobj.NickName+"把"+aa[0].itemFirstName+" "+aa[0].itemLastName+"踢出了群聊";
                            }
                            
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "系统提示";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        
                        obj.Attachment = data[i].media_id;
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==13){
                        var temp = getMessageSysBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.senderId;
                            obj.SenderName = temp.lastName+" "+temp.firstName;
                            obj.Content = obj.SenderName+"将群名称更改为"+temp.groupEdit;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.Content = "您将群名称更改为"+temp.groupEdit;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "系统提示";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        
                        obj.Attachment = data[i].media_id;
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==30){
                        var temp = getMessageMusicBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.senderId;
                            obj.SenderName = temp.senderFirstName+" "+temp.senderLastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "音乐";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = temp.musicName;
                        obj.Attachment = data[i].media_id;
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==58)
                    {
                        var temp = getMessageChartletBinary(playd);
                        if(data[i].direction==2){
                            obj.SenderID = temp.senderId;
                            obj.SenderName = temp.senderFirstName+" "+temp.senderLastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.ContentType = "贴图";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = "";
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==36){
                        var temp = getMessageCallChatBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = id;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                            obj.Content = "未接来自"+obj.SenderName+"的电话";
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                            obj.Content = obj.ReciveName+"未接来自您的电话";
                        }
                        
                        obj.ContentType = "系统提示";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==38){
                        var temp = getMessageShareBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = id;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                        }
                        
                        obj.ContentType = "分享";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = obj.SenderName+"分享了："+temp.content;
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                        
                    }
                    else if(data[i].type==33){
                        var temp = getMessageShareBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = id;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                        }
                        
                        obj.ContentType = "分享";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = obj.SenderName+"分享了："+temp.content;
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                        
                    }
                    else if(data[i].type==35){
                        var temp = getMessageCallChatBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = id;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                            obj.Content = "您正与"+obj.SenderName+"通话中 "+temp.time/60+":"+temp.time%60;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                            obj.Content = "您正与"+obj.ReciveName+"通话中 "+temp.time/60+":"+temp.time%60;
                        }
                        
                        obj.ContentType = "系统提示";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                        
                    }
                    else if(data[i].type==37){
                        var temp = getMessageShareBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = id;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                        }
                        
                        obj.ContentType = "分享";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = obj.SenderName+"分享了："+temp.content;
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==61){
                        var temp = getMessagePraiseBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            obj.SenderID = temp.uId;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                            
                        }
                        
                        obj.ContentType = "点赞";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        if(temp.content1!=""){
                            obj.Content = temp.content+" 点赞内容为:"+temp.content1;
                        }
                        else
                        {
                            obj.Content = temp.content;
                        }
                        
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                    else if(data[i].type==67){
                        var temp = getMessageSysChatInviteBinary(playd,data[i].direction);
                        if(data[i].direction==2){
                            //obj.SenderID = temp.senderId;
                            //obj.SenderName = temp.senderFirstName+" "+temp.senderLastName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                        }
                        obj.ReciveID = id;
                        obj.ReciveName = name;
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = temp.content;
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                        obj.ContentType = "系统提示";
                    }
                    else
                    {
                        if(data[i].direction==2){
                            obj.SenderID = temp.uId;
                            obj.SenderName = name;
                            obj.ReciveID = userobj.AccountId;
                            obj.ReciveName = userobj.NickName;
                        }
                        else
                        {
                            obj.SenderID = userobj.AccountId;
                            obj.SenderName = userobj.NickName;
                            obj.ReciveID = id;
                            obj.ReciveName = name;
                            
                        }
                        
                        obj.ContentType = "未知";
                        obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].send_time);
                        obj.Content = "";
                        obj.Attachment = "";
                        obj.Lng = "";
                        obj.Lat = "";
                    }
                }
                root.Items.push(obj);
            }
        }
    }
}
function getMessageBinary(data,flag,msgId,type){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x22){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.content = XLY.Blob.ToString(info);
                    temp.senderLastName = "";
                    temp.senderFirstName = "";
                    temp.senderId = "";
                }
                else
                {
                    temp.content = "";
                    temp.senderLastName = "";
                    temp.senderFirstName = "";
                    temp.senderId = "";
                }
            }
            
        }
    }
    else if(flag==2)
    {
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x22){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.content = XLY.Blob.ToString(info);
                    a+= data[a]+7;
                    b = a+1;
                    if(data[a]==0x0A){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.senderLastName = XLY.Blob.ToString(info1);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x12){
                            a+= 1;
                            b = a+1;
                            var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.senderFirstName = XLY.Blob.ToString(info2);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x1A){
                                a+= 1;
                                b = a+1;
                                var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.senderId = XLY.Blob.ToString(info2);
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        
    }
    return temp;
}
function getMessageChartletBinary(data){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(a<size){
        if(data[a]==0x12){
            a+= 1;
            b = a+1;
            a += data[a]+11;
            b = a+1;
            if(data[a]==0x0A){
                a+= 1;
                b = a+1;
                var info = XLY.Blob.GetBytes(data,b,data[a]);
                temp.senderLastName = XLY.Blob.ToString(info);
                a+= data[a]+1;
                b = a+1;
                if(data[a]==0x12){
                    a+= 1;
                    b = a+1;
                    var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.senderFirstName = XLY.Blob.ToString(info2);
                    a+= data[a]+1;
                    b = a+1;
                    if(data[a]==0x1A){
                        a+= 1;
                        b = a+1;
                        var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.senderId = XLY.Blob.ToString(info2);
                    }
                }
            }
        }
        
    }
    return temp;
}
function getMessageMusicBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x22){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.musicName = XLY.Blob.ToString(info);
                    temp.senderLastName = "";
                    temp.senderFirstName = "";
                    temp.senderId = "";
                }
                else
                {
                    temp.content = "";
                    temp.senderLastName = "";
                    temp.senderFirstName = "";
                    temp.senderId = "";
                }
            }
            
        }
    }
    else if(flag==2)
    {
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x22){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.musicName = XLY.Blob.ToString(info);
                    a+= data[a]+9;
                    b = a+1;
                    if(data[a]==0x52){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.mediaId = XLY.Blob.ToString(info1);
                        a+= data[a]+0x10;
                        b = a+1;
                        if(data[a]==0x0A){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.senderLastName = XLY.Blob.ToString(info1);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x12){
                                a+= 1;
                                b = a+1;
                                var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.senderFirstName = XLY.Blob.ToString(info2);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x1A){
                                    a+= 1;
                                    b = a+1;
                                    var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.senderId = XLY.Blob.ToString(info2);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        
    }
    return temp;
}
function getMessagePhotoBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x2A){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.downloadUrl = XLY.Blob.ToString(info);
                    temp.senderLastName = "";
                    temp.senderFirstName = "";
                    temp.senderId = "";
                }
                else
                {
                    temp.content = "";
                    temp.senderLastName = "";
                    temp.senderFirstName = "";
                    temp.senderId = "";
                }
            }
            
        }
    }
    else if(flag==2)
    {
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+5;
                b = a+1;
                if(data[a]==0x2A){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.downloadUrl = XLY.Blob.ToString(info);
                    a+= data[a]+9;
                    b = a+1;
                    if(data[a]==0x52){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.mediaId = XLY.Blob.ToString(info1);
                        a+= data[a]+0x01;
                        b = a+1;
                        //var aa = XLY.Bit.ToVariableInt(XLY.Blob.GetBytes(data,a,data.length-a),0);
                        if(data[a]==0x0A){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.senderLastName = XLY.Blob.ToString(info1);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x12){
                                a+= 1;
                                b = a+1;
                                var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.senderFirstName = XLY.Blob.ToString(info2);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x1A){
                                    a+= 1;
                                    b = a+1;
                                    var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.senderId = XLY.Blob.ToString(info2);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        
    }
    return temp;
}
function getMessageSysBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x22){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.groupEdit = XLY.Blob.ToString(info);
                    temp.lastName = "";
                    temp.firstName = "";
                    temp.senderId = "";
                }
                else
                {
                    temp.groupEdit = "";
                    temp.lastName = "";
                    temp.firstName = "";
                    temp.senderId = "";
                }
            }
            
        }
    }
    else if(flag==2)
    {
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x22){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.groupEdit = XLY.Blob.ToString(info);
                    a+= data[a]+6;
                    b = a+1;
                    if(data[a]==0x24){
                        a+= 1;
                        b = a+1;
                        if(data[a]==0x0A){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.lastName = XLY.Blob.ToString(info1);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x12){
                                a+= 1;
                                b = a+1;
                                var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.firstName = XLY.Blob.ToString(info1);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x1A){
                                    a+= 1;
                                    b = a+1;
                                    var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.senderId = XLY.Blob.ToString(info1);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        
    }
    return temp;
}
function getMessageSysDelBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+9;
                b = a+1;
                if(data[a]==0x1A){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.delId = XLY.Blob.ToString(info);
                }
                else
                {
                    temp.delId = "";
                }
            }
            
        }
    }
    else if(flag==2)
    {
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+0x0A;
                b = a+1;
                if(data[a]==0x2E){
                    a+= 2;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.delLastName = XLY.Blob.ToString(info);
                    a+= data[a]+1;
                    b = a+1;
                    if(data[a]==0x12){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.delFirstName = XLY.Blob.ToString(info1);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x1A){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.delId = XLY.Blob.ToString(info1);
                            a+= data[a]+0x45;
                            b = a+1;
                            if(data[a]==0x0A){
                                a+= 1;
                                b = a+1;
                                var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.lastName = XLY.Blob.ToString(info1);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x12){
                                    a+= 1;
                                    b = a+1;
                                    var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.firstName = XLY.Blob.ToString(info1);
                                    a+= data[a]+1;
                                    b = a+1;
                                    if(data[a]==0x1A){
                                        a+= 1;
                                        b = a+1;
                                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                        temp.senderId = XLY.Blob.ToString(info1);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    a+= 2;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.delLastName = XLY.Blob.ToString(info);
                    a+= data[a]+1;
                    b = a+1;
                    if(data[a]==0x12){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.delFirstName = XLY.Blob.ToString(info1);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x1A){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.delId = XLY.Blob.ToString(info1);
                            a+= data[a]+0x45;
                            b = a+1;
                            if(data[a]==0x0A){
                                a+= 1;
                                b = a+1;
                                var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.lastName = XLY.Blob.ToString(info1);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x12){
                                    a+= 1;
                                    b = a+1;
                                    var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.firstName = XLY.Blob.ToString(info1);
                                    a+= data[a]+1;
                                    b = a+1;
                                    if(data[a]==0x1A){
                                        a+= 1;
                                        b = a+1;
                                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                        temp.senderId = XLY.Blob.ToString(info1);
                                        
                                    }
                                }
                            }
                            else
                            {
                                temp.lastName = "";
                                temp.firstName = "";
                                temp.senderId = "";
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        
    }
    return temp;
}
function getVariableIntLength(data,pos){
    var info = {};
    var subdata = XLY.Blob.GetBytes(data,pos,data.length-pos);
    //log(data[pos]);
    var count = 0;

    for(var i = 0; i<4 ;i++){
        if(128==(subdata[i]&128)){
            count++;
            continue;
        }
        count++;
        break;
    }
    info.count = count;
    info.size = XLY.Bit.ToVariableInt(subdata,false);
    return info;
}
function getMessageAddressBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+3;
                b = a+1;
                if(data[a]==0x3A){
                    a+= 1;
                    b = a+1;
                    var info1 = getVariableIntLength(data,a);
                    a+= info1.count;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,a,info1.size);
                    a+= info1.size;
                    b = a+1;
                    var data1 = XLY.Blob.GetBytes(data,a,size-a);
                    var aa = XLY.Blob.FindBytes(data1,2,[0x5A,0x40]);
                    if(aa!=-1){
                        a+= aa+2;
                        b = a+1;
                        if(data[a]==0x1A){
                            a+= 1;
                            b = a+1;
                            var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.title = XLY.Blob.ToString(info2);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x22){
                                a+= 1;
                                b = a+1;
                                var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.address = XLY.Blob.ToString(info3);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x2A){
                                    a+= 1;
                                    b = a+1;
                                    var info4 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.url = XLY.Blob.ToString(info4);
                                }
                                else
                                {
                                    temp.url = "";
                                }
                            }
                            else
                            {
                                temp.address = "";
                                temp.url = "";
                            }
                        }
                        else
                        {
                            temp.title = "";
                            temp.address = "";
                            temp.url = "";
                        }
                    }
                }
                else
                {
                    
                }
                
            }
            
        }
    }
    else if(flag==2)
    {
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                a += data[a]+0x09;
                b = a+1;
                if(data[a]==0x3A){
                    a+= 1;
                    b = a+1;
                    var info1 = getVariableIntLength(data,a);
                    a+= info1.count;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,a,info1.size);
                    a+= info1.size+0x15;
                    b = a+1;
                    if(data[a]==0x0A){
                        a+= 1;
                        b = a+1;
                        var info5 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.lastName = XLY.Blob.ToString(info5);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x12){
                            a+= 1;
                            b = a+1;
                            var info6 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.firstName = XLY.Blob.ToString(info6);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x1A){
                                a+= 1;
                                b = a+1;
                                var info7 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.uId = XLY.Blob.ToString(info7);
                                a+= data[a]+1;
                                b = a+1;
                                var data1 = XLY.Blob.GetBytes(data,a,size-a);
                                var aa = XLY.Blob.FindBytes(data1,2,[0x5A,0x40]);
                                if(aa!=-1){
                                    a+= aa+2;
                                    b = a+1;
                                    if(data[a]==0x1A){
                                        a+= 1;
                                        b = a+1;
                                        var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                        temp.title = XLY.Blob.ToString(info2);
                                        a+= data[a]+1;
                                        b = a+1;
                                        if(data[a]==0x22){
                                            a+= 1;
                                            b = a+1;
                                            var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                                            temp.address = XLY.Blob.ToString(info3);
                                            a+= data[a]+1;
                                            b = a+1;
                                            if(data[a]==0x2A){
                                                a+= 1;
                                                b = a+1;
                                                var info4 = XLY.Blob.GetBytes(data,b,data[a]);
                                                temp.url = XLY.Blob.ToString(info4);
                                            }
                                            else
                                            {
                                                temp.url = "";
                                            }
                                        }
                                        else
                                        {
                                            temp.address = "";
                                            temp.url = "";
                                        }
                                    }
                                    else
                                    {
                                        temp.title = "";
                                        temp.address = "";
                                        temp.url = "";
                                    }
                                }
                            }
                            else
                            {
                                temp.title = "";
                                temp.address = "";
                                temp.url = "";
                                temp.uId = "";
                            }
                        }
                        else
                        {
                            temp.firstName = "";
                            temp.title = "";
                            temp.address = "";
                            temp.url = "";
                            temp.uId = "";
                        }
                    }
                    else
                    {
                        temp.lastName = "";
                        temp.firstName = "";
                        temp.title = "";
                        temp.address = "";
                        temp.url = "";
                        temp.uId = "";
                    }
                }
                else
                {
                    
                }
            }
        }
    }
    else
    {
        
    }
    return temp;
}
function getMessageTruePhotoBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info9 = XLY.Blob.GetBytes(data,b,data[a]);
                a+= data[a]+3;
                b = a+1;
                if(data[a]==0x2A){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.photoUrl = XLY.Blob.ToString(info);
                    temp.flag = "2A";
                }
                else if(data[a]==0x3A){
                    a+= 1;
                    b = a+1;
                    var info1 = getVariableIntLength(data,a);
                    a+= info1.count;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,info1.size);
                    temp.photoUrl = XLY.Blob.ToString(info);
                    temp.flag = "3A";
                }
                else{
                    
                }
                
                
            }
        }
    }
    if(flag==2){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info9 = XLY.Blob.GetBytes(data,b,data[a]);
                a+= data[a]+5;
                b = a+1;
                if(data[a]==0x2A){
                    a+= 1;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.photoUrl = XLY.Blob.ToString(info);
                    a+= data[a];
                    b = a+1;
                    var data1 = XLY.Blob.GetBytes(data,a,size-a);
                    var aa = XLY.Blob.FindBytes(data1,2,[0xAA,01]);
                    if(aa!=-1){
                        a+= aa+3;
                        b = a+1;
                        if(data[a]==0x0A){
                            a+= 1;
                            b = a+1;
                            var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.lastName = XLY.Blob.ToString(info2);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x12){
                                a+= 1;
                                b = a+1;
                                var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.firstName = XLY.Blob.ToString(info3);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x1A){
                                    a+= 1;
                                    b = a+1;
                                    var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.uId = XLY.Blob.ToString(info3);
                                }
                                else
                                {
                                    temp.uId = "";
                                }
                            }
                            else
                            {
                                temp.uId = "";
                                temp.firstName = "";
                            }
                        }
                    }
                    else
                    {
                        temp.uId = "";
                        temp.firstName = "";
                        temp.lastName = "";
                    }
                }
                else if(data[a]==0x3A){
                    a+= 1;
                    b = a+1;
                    var info1 = getVariableIntLength(data,a);
                    a+= info1.count;
                    b = a+1;
                    var info = XLY.Blob.GetBytes(data,b,info1.size);
                    temp.photoUrl = XLY.Blob.ToString(info);
                    temp.uId = "";
                    temp.firstName = "";
                    temp.lastName = "";
                }
                else{
                    
                }
            }
        }
    }
    return temp;
}
function getMessageAddMemberBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var arr = new Array();
    var content = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info9 = XLY.Blob.GetBytes(data,b,data[a]);
                a+= data[a]+0x28;
                b = a+1;
                while(data[a]!= 0xD8){
                    var temp = {};
                    if(data[a]==0x0A){
                        a+= 1;
                        b = a+1;
                        var info = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.lastName = XLY.Blob.ToString(info);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x12){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.firstName = XLY.Blob.ToString(info1);
                            a+= data[a]+1;
                            b = a+1;
                            if(data[a]==0x1A){
                                a+= 1;
                                b = a+1;
                                var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.uId = XLY.Blob.ToString(info2);
                                a+= data[a]+1;
                                b = a+1;
                                if(data[a]==0x2A){
                                    a+= 1;
                                    b = a+1;
                                    var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.email = XLY.Blob.ToString(info3);
                                    a+= data[a]+1;
                                    b = a+1;
                                    if(data[a]==0x78){
                                        a+= 0x08;
                                        b = a+1;
                                        arr.push(temp);
                                        continue;
                                    }
                                }
                                else
                                {
                                    temp.email = "";
                                    arr.push(temp);
                                    continue;
                                }
                            }
                            else
                            {
                                temp.email = "";
                                temp.uId = "";
                                arr.push(temp);
                                continue;
                            }
                        }
                        else
                        {
                            temp.firstName = "";
                            temp.email = "";
                            temp.uId = "";
                            arr.push(temp);
                            continue;
                        }
                    }
                    else
                    {
                        temp.firstName = "";
                        temp.lastName = "";
                        temp.email = "";
                        temp.uId = "";
                        arr.push(temp);
                        break;
                    }
                }
            }
        }
    }
    if(flag==2){
        var list = {};
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info9 = XLY.Blob.GetBytes(data,b,data[a]);
                a+= data[a]+0x08;
                b = a+1;
                if(data[a]==0x0A){
                    a+= 1;
                    b = a+1;
                    var info8 = XLY.Blob.GetBytes(data,b,data[a]);
                    list.lastName1 = XLY.Blob.ToString(info8);
                    a+= data[a]+1;
                    b = a+1;
                    if(data[a]==0x12){
                        a+= 1;
                        b = a+1;
                        var info0 = XLY.Blob.GetBytes(data,b,data[a]);
                        list.firstName1 = XLY.Blob.ToString(info0);
                        a+= data[a]+1;
                        b = a+1;
                        content.creator = list;
                        if(data[a]==0x1A){
                            a+= 1;
                            b = a+1;
                            var info0 = XLY.Blob.GetBytes(data,b,data[a]);
                            list.uId1 = XLY.Blob.ToString(info0);
                            a+= data[a]+0x02;
                            b = a+1;
                            if(data[a]==0xFF){
                                a+= 0x32;
                                b = a+1;
                            }
                            else
                            {
                                a+= 0x29;
                                b = a+1;
                            }
                            while(data[a]!= 0xD8){
                                var temp = {};
                                if(data[a]==0x0A){
                                    a+= 1;
                                    b = a+1;
                                    var info = XLY.Blob.GetBytes(data,b,data[a]);
                                    temp.lastName = XLY.Blob.ToString(info);
                                    a+= data[a]+1;
                                    b = a+1;
                                    if(data[a]==0x12){
                                        a+= 1;
                                        b = a+1;
                                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                                        temp.firstName = XLY.Blob.ToString(info1);
                                        a+= data[a]+1;
                                        b = a+1;
                                        if(data[a]==0x1A){
                                            a+= 1;
                                            b = a+1;
                                            var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                                            temp.uId = XLY.Blob.ToString(info2);
                                            a+= data[a]+1;
                                            b = a+1;
                                            if(data[a]==0x2A){
                                                a+= 1;
                                                b = a+1;
                                                var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                                                temp.email = XLY.Blob.ToString(info3);
                                                a+= data[a]+1;
                                                b = a+1;
                                                if(data[a]==0x78){
                                                    a+= 0x08;
                                                    b = a+1;
                                                    arr.push(temp);
                                                    continue;
                                                }
                                            }
                                            else
                                            {
                                                temp.email = "";
                                                arr.push(temp);
                                                continue;
                                            }
                                        }
                                        else
                                        {
                                            temp.email = "";
                                            temp.uId = "";
                                            arr.push(temp);
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        temp.firstName = "";
                                        temp.email = "";
                                        temp.uId = "";
                                        arr.push(temp);
                                        continue;
                                    }
                                }
                                else
                                {
                                    temp.firstName = "";
                                    temp.lastName = "";
                                    temp.email = "";
                                    temp.uId = "";
                                    arr.push(temp);
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        arr.push(list);
                    }
                }
            }
        }
    }
    content.member = arr;
    return content;
}
function getMessageSysChatInviteBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info = XLY.Blob.GetBytes(data,b,data[a]);
                temp.uId = XLY.Blob.ToString(info);
                a+= data[a]+0x2F;
                b = a+1;
                if(data[a]==0x04){
                    a+= 1;
                    b = a+1;
                    var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.content = XLY.Blob.ToString(info1);
                }
                else
                {
                    temp.content = "";
                }
            }
            else
            {
                temp.content = "";
                temp.uId = "";
            }
        }
    }
    if(flag==2){
        temp.content = "";
        temp.uId = "";
    }
    return temp;
}
function getMessageCallChatBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info = XLY.Blob.GetBytes(data,b,data[a]);
                temp.uId = XLY.Blob.ToString(info);
                a+= data[a]+0x05;
                b = a+1;
                if(data[a]==0x48){
                    a+= 1;
                    b = a+1;
                    var info2 = getVariableIntLength(data,a);
                    //var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.time = data[a];
                    a+= data[a]+1;
                    b = a+1;
                    if(data[a]==0x04){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.content = XLY.Blob.ToString(info1);
                    }
                    else
                    {
                        temp.content = "";
                    }
                }
                else
                {
                    temp.time = 0;
                }
            }
            else
            {
                temp.content = "";
                temp.uId = "";
            }
        }
    }
    if(flag==2){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info = XLY.Blob.GetBytes(data,b,data[a]);
                temp.uId = XLY.Blob.ToString(info);
                a+= data[a]+0x05;
                b = a+1;
                if(data[a]==0x48){
                    a+= 1;
                    b = a+1;
                    var info2 = getVariableIntLength(data,a);
                    //var info = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.time = data[a];
                    a+= 0x07;
                    b = a+1;
                    if(data[a]==0x0A){
                        a+= 1;
                        b = a+1;
                        var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                        temp.firstName = XLY.Blob.ToString(info1);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x12){
                            a+= 1;
                            b = a+1;
                            var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.lastName = XLY.Blob.ToString(info1);
                            a+= data[a]+1;
                            b = a+1;
                        }
                        else
                        {
                            temp.lastName = "";
                        }
                    }
                    else
                    {
                        temp.lastName = "";
                        temp.firstName = "";
                    }
                }
                else
                {
                    temp.lastName = "";
                    temp.firstName = "";
                    temp.time = 0;
                }
            }
            else
            {
                temp.lastName = "";
                temp.firstName = "";
                temp.uId = "";
            }
        }
    }
    return temp;
}
function getMessagePraiseBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(flag==1){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info = XLY.Blob.GetBytes(data,b,data[a]);
                temp.uId = XLY.Blob.ToString(info);
                a+= data[a]+0x2F;
                b = a+1;
                if(data[a]==0x04){
                    a+= 1;
                    b = a+1;
                    var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                    temp.content = XLY.Blob.ToString(info1);
                    a+= data[a]+0x13;
                    b = a+1;
                    if(data[a]==0x12){
                        a+= 1;
                        b = a+1;
                        var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                        a+= data[a]+3;
                        b = a+1;
                        if(data[a]==0x22){
                            a+= 1;
                            b = a+1;
                            var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                            temp.content1 = XLY.Blob.ToString(info3);
                        }
                        else
                        {
                            temp.content1 = "";
                        }
                    }
                    else
                    {
                        temp.content1 = "";
                    }
                }
                else
                {
                    temp.content = "";
                    temp.content1 = "";
                }
            }
            else
            {
                temp.content = "";
                temp.content1 = "";
                temp.uId = "";
            }
        }
    }
    if(flag==2){
        if(a<size){
            if(data[a]==0x12){
                a+= 1;
                b = a+1;
                var info = XLY.Blob.GetBytes(data,b,data[a]);
                temp.uId = XLY.Blob.ToString(info);
                a+= data[a]+0x0B;
                b = a+1;
                if(data[a]==0x0A){
                    a+= 1;
                    b = a+1;
                    var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                    a+= data[a]+1;
                    b = a+1;
                    if(data[a]==0x12){
                        a+= 1;
                        b = a+1;
                        var info2 = XLY.Blob.GetBytes(data,b,data[a]);
                        a+= data[a]+1;
                        b = a+1;
                        if(data[a]==0x1A){
                            a+= 1;
                            b = a+1;
                            var info3 = XLY.Blob.GetBytes(data,b,data[a]);
                            a+= data[a]+0x37;
                            b = a+1;
                            if(data[a]==0x04){
                                a+= 1;
                                b = a+1;
                                var info4 = XLY.Blob.GetBytes(data,b,data[a]);
                                temp.content = XLY.Blob.ToString(info4);
                                a+= data[a]+0x13;
                                b = a+1;
                                if(data[a]==0x12){
                                    a+= 1;
                                    b = a+1;
                                    var info5 = XLY.Blob.GetBytes(data,b,data[a]);
                                    a+= data[a]+3;
                                    b = a+1;
                                    if(data[a]==0x22){
                                        a+= 1;
                                        b = a+1;
                                        var info6 = XLY.Blob.GetBytes(data,b,data[a]);
                                        temp.content1 = XLY.Blob.ToString(info6);
                                    }
                                    else
                                    {
                                        temp.content1 = "";
                                    }
                                }
                                else
                                {
                                    temp.content1 = "";
                                }
                            }
                            else
                            {
                                temp.content = "";
                                temp.content1 = "";
                            }
                        }
                        else
                        {
                            temp.content = "";
                            temp.content1 = "";
                        }
                    }
                    else
                    {
                        temp.content = "";
                        temp.content1 = "";
                    }
                }
                else
                {
                    temp.content = "";
                    temp.content1 = "";
                }
            }
            else
            {
                temp.content = "";
                temp.content1 = "";
                temp.uId = "";
            }
        }
    }
    return temp;
}
function getMessageShareBinary(data,flag){
    var size = data.length;
    var a = 0;
    var b = 0;
    var temp = {};
    if(a<size){
        if(data[a]==0x12){
            a+= 1;
            b = a+1;
            var info = XLY.Blob.GetBytes(data,b,data[a]);
            //temp.uId = XLY.Blob.ToString(info);
            a+= data[a]+0x03;
            b = a+1;
            if(data[a]==0x22){
                a+= 1;
                b = a+1;
                var info1 = XLY.Blob.GetBytes(data,b,data[a]);
                temp.content = XLY.Blob.ToString(info1);
            }
            else
            {
                temp.content = "";
            }
        }
        else
        {
            temp.content = "";
            //temp.uId = "";
        }
    }
    return temp;
}