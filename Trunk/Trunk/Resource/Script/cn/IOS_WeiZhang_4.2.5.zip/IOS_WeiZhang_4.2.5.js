﻿/*[config]
<plugin name="车辆查违章,12" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\weizhang.png"  app="cn.autopai.violationquery" description="车辆查违章"  data="$data,ComplexTreeDataSource" version="4.2.5">
<source>
<value>cn.autopai.violationquery</value>
</source>
<data type="WeiZhang" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="车主" code="Name" type="string" width="600" format = "" ></item>
</data>
<data type="Car" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="车主" code="Name" type="string" width="" format = ""></item>
<item name="车牌" code="Licence" type="string" width="" format = ""></item>
<item name="车架号后六位" code="Num" type="string" width="" format = "" ></item>
<item name="添加时间" code="Time" type="datetime" width="" format = "yyyy-MM-dd HH:mm:s"></item>
<item name="ID" code="ID" type="datetime" width="" format = "" show="false"></item>
</data>
<data type="WZinfo" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="违章时间" code="Wtime" type="datetime" width="" format = "yyyy-MM-dd HH:mm:s"></item>
<item name="地点" code="Road" type="string" width="" format = ""></item>
<item name="详情" code="Detail" type="string" width="" format = "" ></item>
<item name="纬度" code="Pos_lat" type="string" width="" format = "" ></item>
<item name="经度" code="Pos_lng" type="string" width="" format = "" ></item>
<item name="查询时间" code="Ctime" type="datetime" width="" format = "yyyy-MM-dd HH:mm:s"></item>
<item name="查询结果" code="Res" type="string" width="" format = "" ></item>
<item name="ID" code="ID" type="datetime" width="" format = "" show="false"></item>
</data>
</plugin>
[config]*/

//定义违章数据结构
function WeiZhang(){
    this.DataState = "Normal";
    this.Name = "";
}

//车辆信息数据结构
function Car(){
    this.DataState = "Normal";
    this.Name = "";
    this.Licence = "";
    this.Num = "";
    this.Time = "";
    this.ID = "";
}

//违章信息
function WZinfo(){
    this.DataState = "Normal";
    this.Wtime = "";
    this.Road = "";
    this.Detail = "";
    this.Pos_lat = "";
    this.Pos_lng = "";
    this.Ctime = "";
    this.Res = "";
    this.ID = "";
}

//定义树数据结构
function TreeNode() {
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

function bindTree(){ 
    var recoverydb = XLY.Sqlite.DataRecovery(db,charactor,"qcp_car_attr,qcp_car_city,qcp_car2,qcp_query_result,qcp_query_status");
    var dblist = eval('('+ XLY.Sqlite.FindByName(db,'qcp_car2' ) +')');
    var dbcar = eval('('+ XLY.Sqlite.Find(recoverydb,"select a.*,b.*,cast(create_time as text)as time from qcp_car_attr as a left join qcp_car2 as b on a.car_id = b.id") +')');
    var weizhang = new TreeNode();
    weizhang.Text = "车辆查违章";
    weizhang.Type = "WeiZhang";
    var carower = getWeiZhang(recoverydb,dblist);
    weizhang.Items = carower;
    for(var i in dbcar){
        var car = new TreeNode();
        car.Text = dbcar[i].name;
        car.Type = "Car";
        car.Items = getCar(dbcar[i]);
        car.DataState = XLY.Convert.ToDataState(dbcar[i].XLY_DataType);
        weizhang.TreeNodes.push(car);
        var licence = new TreeNode();
        licence.Text = dbcar[i].city+dbcar[i].number;
        licence.Type = "WZinfo";
        dbwz = eval('('+ XLY.Sqlite.Find(recoverydb,"select * from qcp_car_city as a where a.id = '"+dbcar[i].id+"'") +')');
        if(dbwz.length>0){
             var wzinfo = getWZinfo(db,dbwz);
             licence.Items = wzinfo;
             car.TreeNodes.push(licence);
        }           
    }
    return weizhang;
}

//获取根节点信息
function getWeiZhang(path,data){
    var list = new Array();
    for(var i in data){
        var obj = new WeiZhang();
        obj.Name = data[i].name;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取车辆信息
function getCar(data){
    var list = new Array();
    var obj = new WeiZhang();
    obj.Name = data.name;
    obj.Licence = data.city+data.number;
    obj.Num = data.value;
    obj.Time = XLY.Convert.LinuxToDateTime(data.time);
    obj.ID = data.car_id;
    obj.DataState = XLY.Convert.ToDataState( data.XLY_DataType);
    list.push(obj);
    return list;
}

//获取违章信息
function getWZinfo(path,data){
    var list = new Array();
    info = eval('('+ XLY.Sqlite.Find(path,"select c.* from (select a.*,b.*,cast(a.time as text)as ctime,cast(b.time as text)as wtime from qcp_query_status as a left join qcp_query_result as b on a.city_in_car_id = b.city_in_car_id)as c where c.city_in_car_id='"+data[0].id+"'") +')');
    for(var i in info){
        var obj = new WZinfo();
        obj.Wtime = XLY.Convert.LinuxToDateTime(info[i].wtime);
        obj.Road = info[i].road;
        obj.Detail = info[i].detail;
        obj.Pos_lat = info[i].pos_lat;
        obj.Pos_lng = info[i].pos_lng;
        obj.Ctime = XLY.Convert.LinuxToDateTime(info[i].ctime);
        obj.Res = info[i].message;
        obj.ID = info[i].city_in_car_id;
        obj.DataState = XLY.Convert.ToDataState( data.XLY_DataType);
        list.push(obj);
    }    
    return list;
}

//********************************************************
var source = $source;
var db = source[0]+"\\cn.autopai.violationquery\\Documents\\db\\weizhang.rdb";
//var db = "C:\\Users\\Administrator\\Desktop\\db\\weizhang.rdb";
//var db = "D:\\temp\\data\\data\\IOS.cn.autopai.violationquery\\Documents\\db\\weizhang.rdb";
var charactor = "\\chalib\\IOS_WeiZhang_V4.2.5\\weizhang.db.charactor";
var result = new Array();
result.push(bindTree());
var res = JSON.stringify(result);
res;
