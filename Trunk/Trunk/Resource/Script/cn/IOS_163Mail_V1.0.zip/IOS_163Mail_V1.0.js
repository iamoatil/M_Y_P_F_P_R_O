﻿/*[config]
<plugin name="Mail163,2" group="主流邮箱,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/Mail163.png" app="com.nextsun.Mail163" version="1.0" description="Mail163" data="$data,ComplexTreeDataSource" >
<source>
<value>com.nextsun.Mail163</value>
</source>

<data type="Account">
<item name="帐号" code="Account" type="string" width="" format=""></item>
</data>
<data detailfield="Content" type="Mail">
<item name="发件人" code="Sender" type="string" width="200" ></item>
<item name="收件人" code="Receiver" type="string" width="200" ></item>
<item name="主题" code="Subject" type="string" width="200" ></item>
<item name="内容" code="Content" type="string" width="400" ></item>
<item name="发送时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss" order="desc" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account() {
    this.Account = "";
}

function Mail() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Subject = "";
    this.Content = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//获取帐号树信息
function getAccount(path) {
    var data = eval('(' + XLY.File.FindDirectories(path) + ')');
    var arr = new Array();
    for (var index in data) {
        var obj = new Account()
        obj.Account = XLY.File.GetFileName(data[index]);
        arr.push(obj);
    }
    return arr;
}

//获取帐号树子节点
function getChildNode(path, acc) {
    var data = eval('(' + XLY.File.FindDirectories(path) + ')');
    var arr = new Array();
    for (var index in data) {
        var filename = XLY.File.GetFileName(data[index]);
        switch (filename) {
            case "INBOX": buildChildTree(acc, "收件箱", data[index]); break;
            case "&g0l6P3ux-": buildChildTree(acc, "草稿箱", data[index]); break;
            case "&XfJT0ZAB-": buildChildTree(acc, "已发送", data[index]); break;
            case "&XfJSIJZk-": buildChildTree(acc, "已删除", data[index]); break;
            case "&V4NXPpCuTvY-": buildChildTree(acc, "垃圾箱", data[index]); break;
            case "&Xn9USpCuTvY-": buildChildTree(acc, "广告邮件", data[index]); break;
            case "&i6KWBZCuTvY-": buildChildTree(acc, "订阅邮件", data[index]); break;
            default: buildChildTree(acc, filename, data[index]); break;
        }
    }
}

//创建帐号子树
function buildChildTree(acc, name, path) {
    var tree = new TreeNode();
    tree.Text = name;
    tree.Type = "Mail";
    var treepath = eval('(' + XLY.File.FindFiles(path) + ')');
    var arr = new Array();
    for (var index in treepath) {
        var info = XLY.File.ReadFile(treepath[index]);
        var obj = new Mail();
        if (info.split("\r").length > 5) {
            var data = info.split("\r");
            for (var i in data) {
                var freg = /\nFrom/;
                if (freg.test(data[i])) {
                    obj.Sender = getAddress(6, data[i]);
                }
                var treg = /\nTo/;
                if (treg.test(data[i])) {
                    obj.Receiver = getAddress(4, data[i]);
                }
                var sreg = /\nSubject/;
                if (sreg.test(data[i])) {
                    obj.Subject = getSubject(data[i]+data[++i]);
                }
                var dreg = /\nDate/;
                if (dreg.test(data[i])) {
                    if ((/\(/).test(data[i])) {
                        obj.Time = data[i].slice(6, data[i].indexOf("("));
                    } else {
                        obj.Time = data[i].slice(6, data[i].length);
                    }
                }
            }
        } else {
            var data = info.split("\n");
            for (var i in data) {
                var freg = /^From/;
                if (freg.test(data[i])) {
                    obj.Sender = getAddress(6, data[i]);
                }
                var treg = /^To/;
                if (treg.test(data[i])) {
                    obj.Receiver = getAddress(4, data[i]);
                }
                var sreg = /^Subject/;
                if (sreg.test(data[i])) {
                    obj.Subject = getSubject(data[i])
                }
                var dreg = /^Date/;
                if (dreg.test(data[i])) {
                    if ((/\(/).test(data[i])) {
                        obj.Time = data[i].slice(6, data[i].indexOf("("));
                    } else {
                        obj.Time = data[i].slice(6, data[i].length);
                    }
                }
            }
        }
        if ((/quoted-printable/ig).test(info)) {
            obj.Content = getContentForQP(info);
        } else if ((/base64/i).test(info)) {
            obj.Content = getContentForBase64(info);
        } else {
            obj.Content = info.slice(info.indexOf("<div"), info.lastIndexOf(">"));
        }
        arr.push(obj);
    }
    tree.Items = arr;
    acc.TreeNodes.push(tree);
}

//获取收发件人信息
function getAddress(num, info) {
    var arr = new Array();
    var obj = "";
    if ((/utf-8/i).test(info)) {
        var data = info.split(",");
        for (var index in data) {
            if ((/B\?/).test(data[index])) {
                var nick = XLY.Convert.Encode(data[index].slice(data[index].indexOf("B?") + 2, data[index].lastIndexOf("?")), "base64", "utf-8");
            } else if ((/b\?/).test(data[index])) {
                var nick = XLY.Convert.Encode(data[index].slice(data[index].indexOf("b?") + 2, data[index].lastIndexOf("?")), "base64", "utf-8");
            } else {
                var nick = XLY.Convert.Encode(data[index].slice(data[index].indexOf("Q?") + 2, data[index].lastIndexOf("?")), "quoted-printable", "utf-8");
            }
            var email = data[index].slice(data[index].lastIndexOf("<"), data[index].lastIndexOf(">") + 1);
            var accinfo = nick + email;
            arr.push(accinfo);
        }
        for (var a in arr) {
            obj = obj + arr[a] + "\n";
        }
    } else if ((/gbk|gb2312|b18030|gb18030/i).test(info)) {
        var data = info.split(",");
        for (var index in data) {
            if ((/B\?/).test(data[index])) {
                var nick = XLY.Convert.Encode(data[index].slice(data[index].indexOf("B?") + 2, data[index].lastIndexOf("?")), "base64", "gbk");
            } else if ((/b\?/).test(data[index])) {
                var nick = XLY.Convert.Encode(data[index].slice(data[index].indexOf("b?") + 2, data[index].lastIndexOf("?")), "base64", "gbk");
            } else {
                var nick = XLY.Convert.Encode(data[index].slice(data[index].indexOf("Q?") + 2, data[index].lastIndexOf("?")), "quoted-printable", "gbk");
            }
            var email = data[index].slice(data[index].lastIndexOf("<"), data[index].lastIndexOf(">") + 1);
            var accinfo = nick + email;
            arr.push(accinfo);
        }
        for (var a in arr) {
            obj = obj + arr[a] + "\n";
        }
    } else {
        obj = info.slice(num, info.length);
    }
    return obj;
}

//获取邮件主题信息
function getSubject(info) {
    var sub = "";
    if ((/utf-8/i).test(info)) {
        if ((/utf-8\?B\?/).test(info)) {
            var data = info.slice(info.indexOf("utf-8?B?") + 8, info.lastIndexOf("?"));
            sub = XLY.Convert.Encode(data, "base64", "utf-8")
        } else if ((/utf-8\?b\?/).test(info)) {
            var data = info.slice(info.indexOf("utf-8?b?") + 8, info.lastIndexOf("?"));
            sub = XLY.Convert.Encode(data, "base64", "gbk")
        } else {
            var data = info.slice(info.indexOf("utf-8?Q?") + 8, info.lastIndexOf("?"));
            sub = XLY.Convert.Encode(data, "quoted-printable", "utf-8");
        }
    } else if ((/gbk|gb2312|b18030|gb18030/i).test(info)) {
        if ((/B\?/).test(info)) {
            var data = info.slice(info.indexOf("B?") + 2, info.lastIndexOf("?"));
            sub = XLY.Convert.Encode(data, "base64", "gbk");
        } else if ((/b\?/).test(info)) {
            var data = info.slice(info.indexOf("b?") + 2, info.lastIndexOf("?"));
            sub = XLY.Convert.Encode(data, "base64", "gbk");
        }else{
            var data = info.slice(info.indexOf("Q?") + 2, info.lastIndexOf("?"));
            sub = XLY.Convert.Encode(data, "quoted-printable", "gbk");
        }
    } else {
        sub = info.slice(9, info.length);
    }
    return sub;
}

//获取base64编码格式的邮件内容
function getContentForBase64(info) {
    var con = info.split("------");
    var arr = new Array();
    var obj = "";
    for (var index in con) {
        if ((/base64/i).test(con[index])) {
            var data = "";
            if (con[index].split("\r\n\r\n").length != 1) {
                data = con[index].split("\r\n\r\n");
            } else {
                data = con[index].split("\n\n");
            }
            if ((/utf-8/i).test(con[index])) {
                content = XLY.Convert.Encode(data[1], "base64", "utf-8")
            } else {
                content = XLY.Convert.Encode(data[1], "base64", "gbk")
            }
            arr.push(content);
        }
    }
    for (var a in arr) {
        obj = obj + arr[a] + "\n";
    }
    return obj;
}

function getContentForQP(info) {
    if ((/\<html/i).test(info)) {
        var con = info.slice(info.indexOf("<html>"), info.lastIndexOf("/html>"));
    } else {
        var con = info.slice(info.indexOf("<table"), info.lastIndexOf(">"));
    }
    if ((/utf\-8/i).test(info)) {
        var obj = XLY.Convert.Encode(con, "quoted-printable", "utf-8");
    }
    if ((/gbk|gb2312|b18030|gb18030/i).test(info)) {
        var obj = XLY.Convert.Encode(con, "quoted-printable", "gbk");
    }
    return obj;
}
var result = new Array();
//源文件
var source = $source;
var path = source[0] + "\\com.nextsun.Mail163\\Documents"
//var path = "C:\\Users\\Administrator\\Desktop\\Documents";
var accinfo = getAccount(path);
for (var index in accinfo) {
    var account = new TreeNode();
    account.Text = accinfo[index].Account;
    account.Type = "Account";
    account.Items.push(accinfo[index]);

    //获取帐号子树节点
    var nodepath = path + "\\" + accinfo[index].Account + "\\Mails";
    getChildNode(nodepath, account);

    result.push(account);
}
var res = JSON.stringify(result);
res;
