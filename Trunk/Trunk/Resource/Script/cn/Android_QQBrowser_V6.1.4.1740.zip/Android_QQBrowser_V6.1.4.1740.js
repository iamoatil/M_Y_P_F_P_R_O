﻿/*[config]
<plugin name="QQ浏览器" group="Web痕迹,7" devicetype="android" icon="\icons\qqbrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.tencent.mtt" version="6.1.4.1740" description="QQ浏览器" data="$data,ComplexTreeDataSource">
    <source>
        <value>/data/data/com.tencent.mtt/databases/#F</value>
    </source>
    <data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
 <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="URL链接" code="Url" type="url" width = "150"></item>
    <item name="ID" code="Id" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="搜索关键字" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
<data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="路径" code="Path" type="string" width = "150"></item>
    <item name="开始时间" code="CreatedTime" type="string" width = "200"></item>
    <item name="结束时间" code="DoneTime" type="string" width = "200"></item>
    <item name="大小" code="Size" type="string" width = "150"></item>
    </data>
<data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="域名" code="Url" type="url" width = "150"></item>
    <item name="属性值" code="Value" type="string" width = "150"></item>
    <item name="过期时间" code="Time" type="string" width = "200"></item>
    
    </data>
<data type="Cache" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="文件路径" code="FilePath" type="string" width = "150"></item>
    <item name="修改时间" code="Modify" type="string" width = "200"></item>
    <item name="失效时间" code="Expire" type="string" width = "200"></item>
    <item name="类型" code="Type" type="string" width = "150"></item>
    <item name="内容长度" code="Length" type="string" width = "150"></item>
    <item name="保存时间" code="SaveTime" type="string" width = "150"></item>
    
    </data>
   
<data type="Navi" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="描述" code="Desc" type="string" width = "150"></item>
    <item name="版本" code="Version" type="string" width = "200"></item>  
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Bookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Id = "";
    this.Time = "";
}
function Search(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}

function Download(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Path = "";
    this.CreatedTime = "";
    this.DoneTime = "";
    this.Size = "";
}
function Cookies(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Value = "";
    this.Time = "";
}
function Cache(){
    this.DataState = "Normal";
    this.FilePath = "";
    this.Url = "";
    this.Modify = "";
    this.Expire = "";
    this.Type = "";
    this.Length = "";
    this.SaveTime = "";
}
function Navi(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Desc = "";
    this.Version = "";
}


//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "QQ浏览器";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
    
    newTreeNode("书签","Bookmark",getBookmark(db5),news);
    newTreeNode("搜索","Search",getSearch(db5),news);
    newTreeNode("历史记录","History",getHistory(db6),news);
    newTreeNode("下载","Download",getDownload(db7),news);
    newTreeNode("Cookies","Cookies",getCookies(db8),news);
    newTreeNode("缓存","Cache",getCache(db9),news);
    newTreeNode("Navi","Navi",getNavi(db6),news);
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["书签","搜索","浏览记录","下载","Cookies","缓存","Navi"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}

function getBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from mtt_bookmarks" ) +')');
    for(var i in data){
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Id = data[i].uuid;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getDownload(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from download" ) +')');
    for(var i in data){
        var obj = new Download();
        obj.Name = data[i].filename;
        obj.Url = data[i].url;
        obj.Path = data[i].filefolderpath;
        obj.Size = data[i].totalsize+" bytes";
        obj.CreatedTime = XLY.Convert.LinuxToDateTime(data[i].createdate);
        obj.DoneTime = XLY.Convert.LinuxToDateTime(data[i].donedate);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
} 
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from search_history" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Title = data[i].NAME;
        obj.Url = data[i].URL;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].DATETIME);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].NAME;
        obj.Url = data[i].URL;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].DATETIME);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCookies(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cookies" ) +')');
    for(var i in data){
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Url = data[i].domain;
        obj.Value = data[i].value;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].expires);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCache(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cache" ) +')');
    for(var i in data){
        var obj = new Cache();
        obj.FilePath = data[i].filepath;
        obj.Url = data[i].url;
        obj.Modify = data[i].lastmodify;
        obj.Expire = data[i].expiresstring;
        obj.Type = data[i].mimetype;
        obj.Length = data[i].contentlength;
        obj.SaveTime = XLY.Convert.LinuxToDateTime(data[i].savedtime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getNavi(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from navi" ) +')');
    for(var i in data){
        var obj = new Navi();
        obj.Name = data[i].title;
        obj.Url = data[i].url;
        obj.Desc = data[i].desc;
        obj.Version = data[i].version;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
var db1 = source[0]+"\\database";
var db2 = source[0]+"\\download_database";
var db3 = source[0]+"\\webview_x5.db";
var db4 = source[0]+"\\webviewCache_x5.db";

var path = eval('('+ XLY.File.FindFileNames(db) +')');
for(var i in path){
    reg = /[0-9]{4,12}/;
    a=path[i].match(reg);
    if(a!=null){
        p = db+"\\"+path[i]+".db";
    }
}

var charactor1 = "\\chalib\\Android_QQBrowser_V6.1.4.1740\\913.charactor";
var charactor2 = "\\chalib\\Android_QQBrowser_V6.1.4.1740\\database.charactor";
var charactor3 = "\\chalib\\Android_QQBrowser_V6.1.4.1740\\download_database.charactor";
var charactor4 = "\\chalib\\Android_QQBrowser_V6.1.4.1740\\webview_x5.db.charactor";
var charactor5 = "\\chalib\\Android_QQBrowser_V6.1.4.1740\\webviewCache_x5.db.charactor";

var db5 = XLY.Sqlite.DataRecovery(p,charactor1,"mtt_bookmarks,search_history");
var db6 = XLY.Sqlite.DataRecovery(db1,charactor2,"history,navi");
var db7 = XLY.Sqlite.DataRecovery(db2,charactor3,"download");
var db8 = XLY.Sqlite.DataRecovery(db3,charactor4,"cookies");
var db9 = XLY.Sqlite.DataRecovery(db4,charactor5,"cache");



var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
