﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="com.autonavi.xmgd.navigator" version="9.2.8803.1308" description="高德导航" data="$data,LocationInfoDataSource" >
<source>
    <value>/data/data/com.autonavi.xmgd.navigator/databases/autonavi.db</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "";
    this.Source = "高德导航";
    this.StartDate = null;
}

//获取历史搜索树的信息
function getPosition(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from RouteRecordTable") + ')');
    var info = new Array();
    if(data!=null&&data.length>0){
        for (var i in data) {
            var startPoi = new Position();
            var startLoc = data[i].start.split(",");
            startPoi.Longitude = XLY.Convert.ToDouble(startLoc[1].replace(/[^0-9]/ig,"")/1000000);
            startPoi.Latitude = XLY.Convert.ToDouble(startLoc[2].replace(/[^0-9]/ig,"")/1000000);
            startPoi.Remark = "导航起点："+startLoc[0].substring(7,startLoc[0].length-1);
            var str = data[i].mOperateTime;
            var StartDate = str.substr(0,4)+"-"+str.substr(4,2)+"-"+str.substr(6,2)+" "+str.substr(8,2)+":"+str.substr(10,2)+":"+str.substr(12,2);
            startPoi.StartDate = StartDate;
            info.push(startPoi);
            var destPoi = new Position();
            var destLoc = data[i].dest.split(",");
            destPoi.Longitude = XLY.Convert.ToDouble(destLoc[1].replace(/[^0-9]/ig,"")/1000000);
            destPoi.Latitude = XLY.Convert.ToDouble(destLoc[2].replace(/[^0-9]/ig,"")/1000000);
            destPoi.Remark = "导航目的地："+destLoc[0].substring(7,destLoc[0].length-1);
            destPoi.StartDate = StartDate;
            info.push(destPoi);
        }
    }
    return info;
}

var result = new Array();
//源文件路径
var source = $source;
var db = source[0];
//var db = "C:\\Users\\Administrator\\Desktop\\com.autonavi.xmgd.navigator\\databases\\autonavi.db";
result=getPosition(db);
var res = JSON.stringify(result);
res;
