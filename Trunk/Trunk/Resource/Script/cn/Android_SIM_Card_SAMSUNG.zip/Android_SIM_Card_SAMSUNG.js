﻿/*[config]
<plugin name="SIM卡信息,5" group="基本信息,1" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/simcard.png" app="com.android.providers.telephony" version="20.0.1396.73172" description="SIM卡信息" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.android.providers.telephony/databases/telephony.db</value>
    <value>/data/data/com.android.phone/shared_prefs/com.android.phone_preferences.xml</value>
</source>

<data type="SIMinfo" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="卡序号" code="num" type="string" width="80" format=""></item>
<item name="IMSI" code="imsi" type="string" width="150" format=""></item>
<item name="ICCID" code="iccid" type="string" width="200" format=""></item>
</data>


</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function SIMinfo() {
    this.DataState = "Normal";  //数据状态
    this.num = "";  //卡序号
    this.imsi = ""; //IMSI
    this.iccid = "";    //ICCID
    this.MDFString = "";    //MD5
}


//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path1 = source[0];
var path2 = source[1];
//测试数据
//var path1 = "D:\\1\\2017-0055-效率源鉴定所2017年能力验证\\com.android.providers.telephony\\databases\\telephony.db";
//var path2 = "D:\\1\\2017-0055-效率源鉴定所2017年能力验证\\com.android.phone\\shared_prefs\\com.android.phone_preferences.xml";

//定义特征库文件
//var charactor = "chalib\\Android_OperaBrowser_V20.0.1396\\favorites.db.charactor";

//恢复数据库中删除的数据
//var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var sim = new TreeNode();
    sim.Text = "SIM卡信息";
    sim.Type = "SIMinfo";
    sim.Items = getSIMInfo(path1,path2);

    result.push(sim);
}
//获取sim卡信息
function getSIMInfo(path1,path2){
    var data = eval('('+ XLY.Sqlite.Find(path1,"select icc_id,sim_id,display_name from siminfo") +')');
    var info = eval('('+ XLY.File.ReadXML(path2) +')');
    var siminfo = new Array();
    if(data.length>0&&data!=null){
        for(var i in data){
            var simobj = new SIMinfo();
            simobj.num = data[i].display_name;
            simobj.iccid = data[i].icc_id;
            simobj.imsi = getIMSIinfo(data[i].sim_id,info);
            siminfo.push(simobj);
        }
    }
    else
    {
        var sinfo = info.map.string;
        var imsikey = "cf_imsikey";
        var iccidkey = "key_iccid"
        for(var i in sinfo){
            //log(sinfo[i]);
            if(/key_iccid/.test(sinfo[i]['@name'])){
                var simobj = new SIMinfo();
                simobj.iccid = sinfo[i]['#text'];
                var id = sinfo[i]['@name'].substr(9,1)
                simobj.imsi = getIMSIinfo(id,info);
                siminfo.push(simobj);
            }
        }
    }
    return siminfo;
}

function getIMSIinfo(id,data){
    var info = data.map.string;
    var simid = "cf_imsikey"+id;
    for(var i in info){
        if(info[i]['@name'] == simid) return info[i]['#text'];

    }
}

