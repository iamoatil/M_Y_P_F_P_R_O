﻿/*[config]
<plugin name="谷歌浏览器" group="Web痕迹,7" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\Chrome.png" app="com.google.chrome.ios" version="56.0.2924.79" description="LANGKEY_GuGeLiuLanQi_06046" data="$data,ComplexTreeDataSource" >
<source>
<value>com.google.chrome.ios</value>
</source>
<data type = "History">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>   
<item name="标题" code="Title" type="string" width="250" format=""></item>
<item name="链接" code="Url" type="string" width="600" format=""></item>
<item name="时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Counts" type="string" width="100" format=""></item>
</data>
<data type = "Search">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="关键字" code="Key" type="string" width="250" format=""></item>
<item name="时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Bookmark">
<item name="LANGKEY_ShuQianMing_06054" code="Title" type="string" width="200" format=""></item>
<item name="LANGKEY_URLDiZhi_06055" code="Url" type="string" width="500" format=""></item>
<item name="LANGKEY_ChuangJianShiJian_06056" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/
function History() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Counts = "";
    this.DataState = "Normal";
}
function Search() {
    this.Time = null;
    this.Key = "";
    this.DataState = "Normal";
}
function Bookmark() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}
function getHistroy(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var object = new History();
        object.Title = data[index].title;
        object.Time = XLY.Convert.GoogleChromeToDateTime(parseInt(data[index].time));
        object.Url = XLY.Convert.UrlDecode(data[index].url);
        object.Counts = data[index].count;
        arr.push(object);
    }
    return arr;
}
function getSearch(path) {
    var data = eval('('+ XLY.Sqlite.Find(hispath1,"select * from keyword_search_terms left join urls on keyword_search_terms.url_id = urls.id " ) +')');
    var arr = new Array();
    for (var index in data) {
        var object = new Search();
        object.Key = data[index].term;
        object.Time = XLY.Convert.GoogleChromeToDateTime(parseInt(data[index].last_visit_time));
        arr.push(object);
    }
    return arr;
}
//获取书签信息
function getBookmark(path) {
    var data = eval('(' + XLY.File.ReadFile(hispath2) + ')');
    var info = data.roots.synced.children;
    var arr = new Array();
    for (var index in info) {
        var object = new Bookmark();
        object.Title = info[index].name;
        object.Time = XLY.Convert.GoogleChromeToDateTime(parseInt(info[index].date_added));
        object.Url = XLY.Convert.UrlDecode(info[index].url);
        arr.push(object);
    }
    return arr;
}
var result = new Array();
//定义数据文件路径
var source = $source;
var hispath = source[0] + "\\com.google.chrome.ios\\Library\\Application Support\\Google\\Chrome\\Default\\History";
var hispath2 = source[0] + "\\com.google.chrome.ios\\Library\\Application Support\\Google\\Chrome\\Default\\Bookmarks";
//var hispath = "D:\\temp\\data\\data\\com.google.chrome.ios\\Library\\Application Support\\Google\\Chrome\\Default\\History";
//var hispath2 = "D:\\temp\\data\\data\\com.google.chrome.ios\\Library\\Application Support\\Google\\Chrome\\Default\\Bookmarks";
var charactor = "chalib\\IOS_Chrome_V56.0.2924.79\\History.charactor"
//var charactor = "D:\\temp\\data\\data\\com.google.chrome.ios\\Library\\Application Support\\Google\\Chrome\\Default\\History.charactor";
var hispath1 = XLY.Sqlite.DataRecovery(hispath, charactor, "urls,keyword_search_terms")

   var chrome = new TreeNode();
   chrome.Text = "谷歌浏览器";

    //创建历史搜索树
    var hissql = "select title,url,last_visit_time as time,visit_count as count from urls";
    var history = new TreeNode();
    history.Text = "历史记录";
    history.Type = "History";
    var hisinfo = getHistroy(hispath1, hissql);
    history.Items = hisinfo;

    var search = new TreeNode();
    search.Text = "搜索";
    search.Type = "Search";    
    search.Items = getSearch(hispath);

    //创建书签树
    var bookmark = new TreeNode();
    bookmark.Text = "LANGKEY_ShuQian_06062";
    bookmark.Type = "Bookmark";
    var bkinfo = getBookmark(hispath2);
    bookmark.Items = bkinfo;

    result.push(chrome);
    chrome.TreeNodes.push(history);
    chrome.TreeNodes.push(search);
    chrome.TreeNodes.push(bookmark);
    var res = JSON.stringify(result);
    res;
