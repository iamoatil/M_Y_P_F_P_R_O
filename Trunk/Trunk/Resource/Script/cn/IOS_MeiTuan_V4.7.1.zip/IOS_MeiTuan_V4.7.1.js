﻿/*[config]
<plugin name="美团,11" group="生活旅游,7" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/meituan.png" app="com.meituan.imeituan" version="4.7.1" description="美团" data = "$data,ComplexTreeDataSource"  >;
<source>
    <value>com.meituan.imeituan</value>
</source>
<data  type="Browse" contract="DataState,Map"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="店铺" code="Desc" type="String" width="150" ></item>
    <item name="地理位置" code="loca" type="String" width = "150" ></item>
    <item name="宣传" code="intra" type="String" width = "150" ></item>
    <item name="内容" code="content" type="String" width="150" ></item>
    <item name="标题" code="title" type="String" width = "150" ></item>
    <item name="原价" code="prepri" type="String" width = "150" ></item>
    <item name="现价" code="newpri" type="String" width="150" ></item>
    <item name="经度" code="Longitude" type="double" format="F6" width=""></item>
    <item name="纬度" code="Latitude" type="double" format="F4"  width=""></item>
    
</data>
<data type="Merchant" contract="DataState,Map"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="评分" code="point" type="String" width="150" ></item>
    <item name="地址" code="loca" type="String" width = "150" ></item>
    <item name="区域" code="area" type="String" width = "150" ></item>
    <item name="类型" code="type" type="String" width="150" ></item>
    <item name="介绍" code="intra" type="String" width = "150" ></item>
    <item name="名称" code="Desc" type="String" width = "150" ></item>
    <item name="联系电话" code="phone" type="String" width="150" ></item>
    <item name="经度" code="Longitude" type="double" format="F6" width=""></item>
    <item name="纬度" code="Latitude" type="double" format="F4"  width=""></item>
</data>
<data type="Location" contract="DataState,Map"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="经度" code="Longitude" type="double" format="F6" width="300"></item>
    <item name="纬度" code="Latitude" type="double" format="F4"  width = "300"></item>
    <item name="名称" code="Desc" type="String" width = "150" show ="false" ></item>
    
</data>
<data type="Mobile" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="手机型号" code="sec" type="string" width="300"></item>
    <item name="系统版本" code="os" type="string" width="300"></item>
</data>
<data type="Web" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="WIFI" code="wifi" type="string" width="300"></item>
    <item name="运营商" code="runner" type="string" width="300"></item>
</data>


</plugin>
[config]*/

// js content

//定义数据结构
function Browse() {
    this.Desc = "";  
    this.loca = "";
    this.intra = "";
    this.content = "";
    this.title = "";  
    this.prepri = "";
    this.newpri = "";
    this.Longitude = 0;
    this.Latitude = 0;
    this.DataState = "Normal";  
}
function Merchant() {
    this.point = "";  
    this.loca = "";
    this.area = "";
    this.type = "";
    this.intra = "";  
    this.Desc = "";
    this.phone = "";
    this.Longitude = 0;
    this.Latitude = 0;
    this.DataState = "Normal";  
}
function Location() {
    this.Longitude = 0;
    this.Latitude = 0; 
    this.Desc = "";
    this.DataState = "Normal";  
}
function Mobile() {
    this.sec = "";  
    this.os = "";  
    this.DataState = "Normal";  
}
function Web() {
    this.wifi = "";  
    this.runner = "";  
    this.DataState = "Normal";  
}

//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}

//获取浏览历史记录
function GetBrowse(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from ZMTMANAGEDDEAL") + ')');
for(var index in data)
{
    var obj=new Browse();
    obj.Desc = data[index].ZMERCHANTNAME;  
    obj.loca = data[index].ZBUSINESSDISTRICT;  
    obj.intra = data[index].ZCOUPONTITLE;  
    obj.content = data[index].ZSMSTITLE;  
    obj.title = data[index].ZTITLE;
    obj.prepri = data[index].ZORIGINALPRICE;
    obj.newpri = data[index].ZPRICE;
     if(data[index].ZBRANCHLOCATIONS.indexOf(";") == -1)
    {
    obj.Latitude = data[index].ZBRANCHLOCATIONS.substr(0,data[index].ZBRANCHLOCATIONS.indexOf(","));
    obj.Longitude = data[index].ZBRANCHLOCATIONS.substr(data[index].ZBRANCHLOCATIONS.indexOf(",")+1,data[index].ZBRANCHLOCATIONS.length-data[index].ZBRANCHLOCATIONS.indexOf(",")-1);
    }    
    //obj.Longitude = data[index].ZBRANCHLOCATIONS;
    //obj.Latitude = data[index].ZBRANCHLOCATIONS;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj)
}
return arr;
}
catch(e){
return arr;
}
}

//获取筛选历史记录
function GetMerchant(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from ZMTMANAGEDMERCHANT") + ')');
for(var index in data)
{
    var obj=new Merchant();
    obj.Longitude = data[index].ZLONGITUDE;  
    obj.Latitude = data[index].ZLATITUDE;  
    obj.point = data[index].ZRATING;  
    obj.loca = data[index].ZADDRESS;  
    obj.area = data[index].ZAREANAME;
    obj.type = data[index].ZCATEGORYNAME;
    obj.intra = data[index].ZINTRODUCTION;
    obj.Desc = data[index].ZNAME;
    obj.phone = data[index].ZPHONE;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);  
    arr.push(obj)
}
return arr;
}
catch(e){
return arr;
}
}
//获取搜索历史记录
function GetLocation(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select distinct * from ZSAKANALYTICSCOREDATAHEADER") + ')');
for(var index in data)
{
    var obj=new Location();
    obj.Longitude = data[index].ZLONGITUDE;  
    obj.Latitude = data[index].ZLATITUDE;  
    obj.Desc = data[index].ZLONGITUDE+","+data[index].ZLATITUDE;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj)
}
return arr;
}
catch(e){
return arr;
}
}
//获取用户信息
function GetMobile(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select distinct * from ZSAKANALYTICSCOREDATAHEADER") + ')');
for(var index in data)
{
    var obj=new Location();
    obj.sec = data[index].ZDEVICEMODEL;  
    obj.os = data[index].ZOSVERSION;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj)
}
return arr;
}
catch(e){
return arr;
}
}

function GetWeb(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select distinct * from ZSAKANALYTICSCOREDATAHEADER") + ')');
for(var index in data)
{
    var obj=new Location();
    obj.wifi  = data[index].ZNETWORK;  
    obj.runner = data[index].ZNETWORKOPERATOR;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj)
}
return arr;
}
catch(e){
return arr;
}
}

function CreateNode(type,text,dbInfo,root)
{
    var childNode =new TreeNode();
    childNode.Type=type;
    childNode.Text = text;
    if(dbInfo)
    childNode.Items = dbInfo;
    root.push(childNode);
}


var result = new Array();

//源文件
var source = $source;
var path1 = source[0];

path1 = source[0]+"\\com.meituan.imeituan\\Documents\\imeituan.sqlite";
path2 = source[0]+"\\com.meituan.imeituan\\Library\\Caches\\com.sankuai.analytics.v1.sqlite";
//path1="C:\\Users\\Administrator\\Desktop\\美团IOS\\meituanios\\imeituan.sqlite"
//path2="C:\\Users\\Administrator\\Desktop\\美团IOS\\meituanios\\com.sankuai.analytics.v1.sqlite"

var charactor1 = "chalib\\IOS_MeiTuan_V4.7.1\\imeituan.sqlite.charactor";
var charactor2 = "chalib\\IOS_MeiTuan_V4.7.1\\com.sankuai.analytics.v1.sqlite.charactor";

path1  =XLY.Sqlite.DataRecovery( path1,charactor1 ,"ZMTMANAGEDDEAL,ZMTMANAGEDMERCHANT");
path2 = XLY.Sqlite.DataRecovery( path2,charactor2 ,"ZSAKANALYTICSCOREDATAHEADER");





//--------------------------------------------------------------------以下为单节点构造（筛选，搜索，用户，会话）

CreateNode("Browse","浏览记录",GetBrowse(path1),result);
CreateNode("Merchant","商圈信息",GetMerchant(path1),result);
CreateNode("Location","位置记录",GetLocation(path2),result);
CreateNode("Mobile","手机信息",GetMobile(path2),result);
CreateNode("Web","网络信息",GetWeb(path2),result);

var res = JSON.stringify(result);
res;
