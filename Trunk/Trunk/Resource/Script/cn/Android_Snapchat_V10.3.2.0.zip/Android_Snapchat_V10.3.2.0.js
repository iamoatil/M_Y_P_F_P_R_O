﻿/*[config]
<plugin name="Snapchat,6" group="社交聊天,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\ZhiFuBaoWallet.png" app="com.snapchat.android" version="10.3.2.0" description="Snapchat" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.snapchat.android/shared_prefs/com.snapchat.android_preferences.xml</value>
    <value>/data/data/com.snapchat.android/databases/tcspahn.db</value>
</source>
<data type = "Account" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="姓名" code="Name" type="string" width = "" ></item>
    <item name="帐号" code="Acc" type="string" width = "" ></item>
    <item name="生日" code="Birthday" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="电话" code="Phone" type="string" width="200" format = ""></item>
    <item name="邮箱" code="Email" type="string" width="200" format = ""></item>
</data>
 <data type ="Chat" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="帐号" code="Acc" type="string" width = "" ></item>
</data>
<data type ="Msg" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者" code="Sender" type="string" width = "" ></item>
    <item name="接收者" code="Receiver" type="string" width = "" ></item>
    <item name="内容" code="Content" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="时间" code="Time" type="string" width="200" format = ""></item>
</data>
<data type ="Friends" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="姓名" code="Name" type="string" width = "" ></item>
    <item name="帐号" code="Acc" type="string" width = "" ></item>
</data>
<data type ="Snaps" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="发送者" code="Sender" type="string" width = "" ></item>
    <item name="接收者" code="Receiver" type="string" width = "" ></item>
    <item name="状态" code="Status" type="string" width = "" ></item>
    <item name="类型" code="Type" type="string" width = "" ></item>
    <item name="时间" code="Time" type="string" width="200" format = ""></item>
</data>
</plugin>
[config]*/
function Account() {
    this.Name = "";
    this.Acc = "";
    this.Birthday = "";
    this.Phone = "";
    this.Email = "";
    this.DataState = "Normal";
}
function Chat() {
    this.Acc = "";
    this.DataState = "Normal";
}
function Msg() {
    this.Sender = "";
    this.Receiver = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
}
function Friends() {
    this.Name = "";
    this.Acc = "";
    this.DataState = "Normal";
}
function Snaps() {
    this.Sender = "";
    this.Status = "";
    this.Type = "";
    this.Receiver = "";
    this.Time = "";
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "Snapchat";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account"; 
        //account.Items = getAccount(db,accountinfo[i],accountinfo) ;
        news.TreeNodes.push(account);
        
        var friend = new TreeNode() ;
        friend.Text = "好友";
        friend.Type = "Friends";
        friend.Items = getFriends(db1,accountinfo[i]);
        account.TreeNodes.push(friend);
        
        var received = new TreeNode() ;
        received.Text = "收到的图片或视频";
        received.Type = "Snaps";
        received.Items = getReceived(db1,accountinfo[i]);
        account.TreeNodes.push(received);
        
        var sent = new TreeNode() ;
        sent.Text = "发出的图片或视频";
        sent.Type = "Snaps";
        sent.Items = getSent(db1,accountinfo[i]);
        account.TreeNodes.push(sent);
  
        var chat = new TreeNode() ;
        chat.Text = "消息";
        chat.Type = "Chat";
        var chatinfo =  getChat(db1,accountinfo[i]);
        chat.Items = getChat(db1,accountinfo[i]);
        account.TreeNodes.push(chat);
        
        for(var j in chatinfo){
            var msg = new TreeNode() ;
            msg.Text = chatinfo[j].Acc;
            msg.Type = "Msg"; 
            msg.Items = getMsg(db1,accountinfo[i],chatinfo[j]);
            chat.TreeNodes.push(msg);
        }
    }
  result.push(news);
}       
function getAccount(path)
{
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var obj = new Account();
    var info = data.map.string;
    for(var i in info){
      if(info[i]["@name"] == "lastSuccessfulLoginUsername"){
          obj.Acc = info[i]["#text"];            
      }
      if(info[i]["@name"] == "display_name"){
          obj.Name = info[i]["#text"];            
      }
         if(info[i]["@name"] == "birthday"){
          obj.Birthday = info[i]["#text"];            
      }
         if(info[i]["@name"] == "phone_number"){
          obj.Phone = info[i]["#text"];            
      }
         if(info[i]["@name"] == "email"){
          obj.Email = info[i]["#text"];            
      }   
    }
   list.push(obj);  
    return list;
}
function getFriends(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from Friends" ) +')');
    for(var i in data){
        var obj = new Friends();
        obj.Name = data[i].DisplayName;
        obj.Acc = data[i].Username;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getChat(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct sender from Chat" ) +')');
    for(var i in data){
        var obj = new Chat();
        obj.Acc = data[i].sender;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getReceived(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ReceivedSnaps" ) +')');
    for(var i in data){
        var obj = new Snaps();
        obj.Sender = data[i].Sender;
        obj.Status = data[i].Status;
        var a = data[i].MediaType;
        if(a == 1){
            obj.Type = "图片" ;
        }
        else
        {
            obj.Type = "视频" ;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].Timestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSent(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from SentSnaps" ) +')');
    for(var i in data){
        var obj = new Snaps();
        obj.Receiver = data[i].Recipient;
        obj.Status = data[i].Status;
        var a = data[i].MediaType;
        if(a == 1){
            obj.Type = "图片" ;
        }
        else
        {
            obj.Type = "视频" ;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].Timestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getMsg(path,accountinfo,chatinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from Chat where sender = '"+chatinfo.Acc+"' " ) +')');
    for(var i in data){
        var obj = new Msg();
        if(data[i].send_receive_status == "SENT"){
              obj.Sender = accountinfo.Name;
              obj.Receiver = data[i].sender;
        }
        else
        {
              obj.Sender = data[i].sender;
              obj.Receiver = accountinfo.Name;
        }
        obj.Content = data[i].text;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db2 = source[1];

var charactor = "\\chalib\\Android_Snapchat_V10.3.2.0\\tcspahn.db.charactor";

//var db = "D:\\temp\\data\\data\\com.snapchat.android\\shared_prefs\\com.snapchat.android_preferences.xml";
//var db2 = "D:\\temp\\data\\data\\com.snapchat.android\\databases\\tcspahn.db";
//var charactor = "D:\\temp\\data\\data\\com.snapchat.android\\databases\\tcspahn.db.charactor";
var db1 = XLY.Sqlite.DataRecovery(db2,charactor,"Friends,Chat,ReceivedSnaps,SentSnaps");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;


