﻿/*[config]
<plugin name="WIFI,9" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\wifi.png" version="7.1" app="com.apple.wifi" description="提取IOS设备WIFI信息" data="$data" >
<source>
<value>com.apple.wifi</value>
</source>
<data type="WifiMsg">
<item name="WIFI名称" code="SSID_STR" type="string" width="100" ></item>
<item name="最后连接时间(自动)" code="lastAutoJoined" type="datetime" width="150" ></item>
<item name="最后连接时间(手动)" code="lastJoined" type="datetime" width="150" ></item>
<item name="物理地址(WIFI)" code="BSSID" type="string" width="150" ></item>
</data>
</plugin>
[config]*/

function WifiMsg() {
    this.SSID_STR = "";
    this.lastAutoJoined = null;
    this.lastJoined = null;
    this.BSSID = "";
}



//时间转化
function GetLocalDate(timeStamp) {
    if (timeStamp == null) {
        return null;
    }
    else {
        return XLY.Convert.ToDateTime(1970, 1, 1, timeStamp);
    }
}

function GetWifiNodeInfo(path) {
    var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
    var arr = new Array();
	var localIndex = 5;
	for (var networksIndex in data){
		if(data[networksIndex]['List of known networks'] != null){
			localIndex = networksIndex;
			break;
		}
	
	}
	
	for(var wifiIndex in data[localIndex]['List of known networks'][0])
	{
		var obj = new WifiMsg();  
		for (var index in data[localIndex]['List of known networks'][0][wifiIndex]){			      

			if(data[localIndex]['List of known networks'][0][wifiIndex][index].SSID_STR != null){
				obj.SSID_STR = data[localIndex]['List of known networks'][0][wifiIndex][index].SSID_STR;
			}

			if(data[localIndex]['List of known networks'][0][wifiIndex][index].lastAutoJoined != null){

			    obj.lastAutoJoined = GetLocalDate(data[localIndex]['List of known networks'][0][wifiIndex][index].lastAutoJoined); // XLY.Convert.ToDateTime(1970, 1, 1, data[localIndex]['List of known networks'][0][wifiIndex][index].lastAutoJoined); //; 
			}

			if(data[localIndex]['List of known networks'][0][wifiIndex][index].lastJoined != null){
			    obj.lastJoined = GetLocalDate(data[localIndex]['List of known networks'][0][wifiIndex][index].lastJoined); //XLY.Convert.ToDateTime(1970, 1, 1, data[localIndex]['List of known networks'][0][wifiIndex][index].lastJoined); //;
			}
			
			if(data[localIndex]['List of known networks'][0][wifiIndex][index].BSSID != null){
				obj.BSSID = data[localIndex]['List of known networks'][0][wifiIndex][index].BSSID;
			}
		}
		arr.push(obj);
	}
   
    return arr;
}

var source = $source;
var searchPath = source[0];
//searchPath = "C:\\XLYSFTasks\\Iphone5c\\source\\IosData\\2014-06-19-17-56-21\\aeb86051f46399722e23cfcfef43feba2be70d61";
searchPath = searchPath + "\\SystemPreferencesDomain\\SystemConfiguration\\com.apple.wifi.plist";


var result = new Array();
result = GetWifiNodeInfo(searchPath);
var res = JSON.stringify(result);
res;
