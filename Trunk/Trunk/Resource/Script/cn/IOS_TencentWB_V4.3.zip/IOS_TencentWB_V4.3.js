﻿/*[config]
<plugin name="腾讯微博,4" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\TencentWBlog.png" app="com.tencent.WeiBo" version="v1813" description="腾讯微博-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tencent.WeiBo</value>
</source>

<data detailfield="Contentinfo" type="Weiboinfo" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="博主ID" code="Aid" type="string" width="" ></item>
<item name="博主" code="Author" type="string" width="" ></item>
<item name="微博内容" code="Contentinfo" type="string" width="" format=""></item>
<item name="发布时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="原作者" code="Rootauthor" type="string" width="" format=""></item>
</data>

<data  type="User" contract="DataState" detailfield="Headimage">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="Id" type="string" width="150" ></item>
<item name="名称" code="Name" type="string" width="100" ></item>
<item name="头像" code="Headimage" type="url" width="200" ></item>
</data>

<data detailfield="Content" type="Message" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="" alignment="center" ></item>
<item name="接收人" code="Receiver" type="string" width="" alignment="center"></item>
<item name="内容" code="Content" type="string" width="" format=""></item>
<item name="时间" code="Date" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width=""></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
</data>

</plugin>
[config]*/

//**************************************************定义数据结构**************************************************
//定义Weiboinfo数据结构
function Weiboinfo() {
    this.Aid = "";
    this.Author = "";
    this.Contentinfo = "";
    this.Time = null;
    this.Rootauthor = "";
    this.DataState = "Normal";
}

//定义User数据结构
function User() {
    this.Name = "";
    this.Id = "";
    this.Headimage = "";
    this.DataState = "Normal";
}

//定义Message数据结构
function Message() {
    this.SenderName = "";
    this.Receiver = "";
    this.Date = null;
    this.Content = "";
    this.DataState = "Normal";
    this.SenderImage = "";
    this.Type = "";
    this.SendState = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
    this.Tag = "";
}

//***********************************************定义处理APP数据方法***********************************************
//定义获取用户信息
function GetUser(userInfo) {
    var info = new User();
    info.Name = XLY.Convert.ToString(userInfo.name);
    info.Id = XLY.Convert.ToString(userInfo.id);
    info.Headimage = XLY.Convert.ToString(userInfo.headimage);
    info.DataState = XLY.Convert.ToDataState(userInfo.XLY_DataType);
    return info;
}

//获取微博信息
function GetWeiboInfo(weiboinfo) {
    var wbinfo = new Weiboinfo();
    wbinfo.Aid = XLY.Convert.ToString(weiboinfo.aid);
    wbinfo.Author = XLY.Convert.ToString(weiboinfo.author);
    wbinfo.Contentinfo = XLY.Convert.ToString(weiboinfo.content);
    wbinfo.Time = XLY.Convert.LinuxToDateTime(parseInt(weiboinfo.time));
    wbinfo.Rootauthor = XLY.Convert.ToString(weiboinfo.rootauthor);
    wbinfo.DataState = XLY.Convert.ToDataState(weiboinfo.XLY_DataType);
    return wbinfo;
}

//获取私信消息
function GetMessage(sxm, data, acc) {
    var sxmessage = new Message();
    var sname = GetName(data, sxm.sid);
    var rname = GetName(data, sxm.rid);
    if (sname.id == acc.id) {
        sxmessage.Receiver = rname.name;
        sxmessage.SenderName = sname.name;
        sxmessage.SenderImage = sname.url;
        sxmessage.SendState = "Send";
    } else {
        sxmessage.Receiver = acc.name;
        sxmessage.SenderName = rname.name; 
        sxmessage.SenderImage = rname.url
        sxmessage.SendState = "Receive";
    }
    sxmessage.Date = XLY.Convert.LinuxToDateTime(sxm.time);
    sxmessage.Content = XLY.Convert.ToString(sxm.content);
    sxmessage.DataState = XLY.Convert.ToDataState(sxm.XLY_DataType);
    return sxmessage;
}

//获取聊天中好友名称
function GetName(data, id) {
    var contactsql = "select distinct f.[ZACCOUNTID]as id,f.[ZNICKNAME]as name,f.[ZFACEURL] as url from ZROOMACCTINFOFORPL f";
    var members = ExecSql(data, contactsql)
    for (var index in members) {
        if (members[index].id == id)
            return members[index];
    }
}

//获取数据库文件数据
function ExecSql(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    return data;
}

//匹配字符串
function search(str) {
    var reg = /\w+_new.sqlite+$/gi;
    var target = reg.test(str);
    if (target) {
        return str;
    }
}

//截取字符串
function cut(str) {
    var end = str.indexOf("_");
    var resource = str.slice(0, end);
    if (resource != null) {
        return resource;
    }
}

//创建收听或听众树结构
function buildNodeForFans(path,sql,name,node) {
    var data = ExecSql(path, sql);
    var tree = new TreeNode();
    tree.Text = name;
    tree.Type = "User";
    for (var index in data) {
        var row = data[index];
        var info = GetUser(row);
        tree.Items.push(info);
    }
    node.TreeNodes.push(tree);
}

//创建帐号树的子节点
function buildChildNodeForAccount(path,node,acc) {
    //微博首页
    var weibosourcesTree = new TreeNode();
    weibosourcesTree.Text = "微博首页";
    weibosourcesTree.Type = "User";
    //提取微博首页数据
    var wbsql = "select distinct m.[ZAUTHOR]as id,f.[ZNICKNAME]as name,f.[ZFACEURL]as headimage,m.XLY_DataType from ZMESSAGE m left join ZFOLLOWERS f on f.[ZACCOUNTID]=m.[ZAUTHOR]";
    var weiboinfos = ExecSql(path, wbsql);
    for (var index in weiboinfos) {
        var wb = weiboinfos[index];
        var weiboinfo = GetUser(wb);
        weibosourcesTree.Items.push(weiboinfo);
        var weiboinfosTree = new TreeNode();
        weiboinfosTree.Text = wb.name + "(" + wb.id + ")";
        weiboinfosTree.Type = "Weiboinfo";
        weiboinfosTree.DataState = XLY.Convert.ToDataState(wb.XLY_DataType);
        weiboinfosTree.Tag = wb.id;
        var wbdatasql = "select m.*,f.[ZNICKNAME]as author from(select ZAUTHOR as aid,ZCONTENT as content,ZTIME as time,ZROOTAUTHOR as rootauthor from ZMESSAGE  union select ZAUTHOR as aid,ZCONTENT as content,ZTIME as time,ZROOTAUTHOR as rootauthor from ZMESSAGEFORATME) as m left join ZFOLLOWERS f on f.[ZACCOUNTID]=m.[aid] where aid='" + weiboinfosTree.Tag + "' ";
        var wbdata = ExecSql(path, wbdatasql);
        for (var i in wbdata) {
            var wbd = wbdata[i];
            var wbmessage = GetWeiboInfo(wbd);
            weiboinfosTree.Items.push(wbmessage);
        }
        weibosourcesTree.TreeNodes.push(weiboinfosTree);
    }

    //收听列表
    var stsql = "select  f.[ZACCOUNTID]as id,f.[ZNICKNAME]as name,f.[ZFACEURL]as headimage,XLY_DataType from ZFOLLOWERS f ";
    buildNodeForFans(path, stsql, "收听列表",node)

    //听众列表
    var tzsql = "select  f.[ZACCOUNTID]as id,f.[ZNICKNAME]as name,f.[ZFACEURL]as headimage,XLY_DataType from ZFANS f ";
    buildNodeForFans(path, tzsql, "听众列表",node)

    //私信
    var sixinTree = new TreeNode();
    sixinTree.Text = "私信";
    sixinTree.Type = "User";
    var sixinsql = "select distinct f.[ZACCOUNTID]as id,f.[ZNICKNAME]as name,f.[ZFACEURL]as headimage,XLY_DataType from ZROOMACCTINFOFORPL f where ZACCOUNTID!='" + acc.id + "' "
    // 读取私信信息
    var sixininfos = ExecSql(path, sixinsql);
    for (var index in sixininfos) {
        var sx = sixininfos[index];
        var sxinfo = GetUser(sx);
        sixinTree.Items.push(sxinfo);
        var sxmessagesTree = new TreeNode();
        sxmessagesTree.Text = sx.name + "(" + sx.id + ")";
        sxmessagesTree.Type = "Message";
        sxmessagesTree.DataState = XLY.Convert.ToDataState(sx.XLY_DataType);
        sxmessagesTree.Tag = sx.id;
        //读取聊天记录
        var sxmessagesql = "select s.[ZAUTHOR]as sid,s.[ZTIME]as time,s.[ZCONTENT]as content,s.[ZROOMSESSIONID]as rid,XLY_DataType from ZSESSIONPAGEMSGDATAFORPL s  where ZROOMSESSIONID='" + sxmessagesTree.Tag + "'"
        var message = ExecSql(path, sxmessagesql);
        for (var i in message) {
            var sxm = message[i];
            var sxmessage = GetMessage(sxm, path, acc);
            sxmessagesTree.Items.push(sxmessage);
        }
        sixinTree.TreeNodes.push(sxmessagesTree);
    }
    node.TreeNodes.push(weibosourcesTree);
//    node.TreeNodes.push(shoutingTree);
//    node.TreeNodes.push(tingzongTree);
    node.TreeNodes.push(sixinTree);
}

//获取帐号id信息
function getAccountID() { 
    var files = eval('(' + XLY.File.FindFiles(dataRoot) + ')');
    var info=new Array();
    for (var findex in files) {
        var filename = XLY.File.GetFileName(files[findex]);
        var t_file = search(filename);
        if (t_file != null) {
            var accountid = cut(t_file);
            info.push(accountid);
        }
    }
    return info;
}
//**************************************************处理APP数据**************************************************
var result = new Array();
//源文件
var source = $source;
var dataRoot = source[0] + "\\com.tencent.WeiBo\\Documents";
//var dataRoot="E:\\app_data\\IOS\\腾讯微博-IOS\\2222\\Documents";

//定义特征库文件
var charactor = "chalib\\IOS_TencentWB_V1813\\dymatic_new.sqlite.charactor"

var accid = getAccountID(dataRoot);
for (var index in accid) {
    var path = dataRoot + "\\" + accid[index] + "_new.sqlite";

    //处理删除数据
    var recoveryPath = XLY.Sqlite.DataRecovery(path, charactor, "ZROOMACCTINFOFORPL,ZSESSIONPAGEMSGDATAFORPL,ZROOMACCTINFOFORPL,ZFANS,ZFOLLOWERS,ZMESSAGEFORATME,ZMESSAGE");
    //账户
    var usersql = "select distinct r.[ZACCOUNTID]as id,r.[ZNICKNAME]as name,r.[ZFACEURL]as headimage from ZROOMACCTINFOFORPL as r where ZACCOUNTID='" + accid[index] + "'";
    var user = ExecSql(recoveryPath, usersql);
    var accinfo = new TreeNode();
    var uinfo = user[0];
    accinfo.Text = uinfo.name + "(" + uinfo.id + ")";
    accinfo.Type = "User";
    var accountInfo = GetUser(uinfo);
    accinfo.Items.push(accountInfo);
    buildChildNodeForAccount(recoveryPath, accinfo, uinfo);

    result.push(accinfo);
}

var res = JSON.stringify(result);
res;
