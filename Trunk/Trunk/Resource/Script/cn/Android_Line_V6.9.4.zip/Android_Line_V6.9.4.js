﻿/*[config]
<plugin name="Line" group="社交聊天,8,6" devicetype="android" icon="\icons\line.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="jp.naver.line.android" version="6.9.4" description=" Line" data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/jp.naver.line.android/databases/naver_line</value>
<value>/data/data/jp.naver.line.android/databases/e2ee</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Info" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="ID" code="ID" type="string"  width = "150"></item>
<item name="注册时间" code="Time" type="string" width = "150"></item>
</data>
<data type="User" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名字" code="Name" type="string" width = "150"></item>
<item name="签名" code="Msg" type="string" width = "200"></item>
<item name="最近更新时间" code="UTime" type="string" width = "150"></item>
<item name="ID" code="ID" type="string"  width = "150"></item>
</data>
<data type="Friend" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名字" code="Name" type="string" width = "150"></item>
<item name="昵称" code="Nick" type="string" width = "150"></item>
<item name="签名" code="Msg" type="string" width = "200"></item>
<item name="添加时间" code="CTime" type="string" width = "150"></item>
<item name="最近更新时间" code="UTime" type="string" width = "150"></item>
<item name="ID" code="ID" type="string"  width = "150"></item>
</data>
<data type="Group" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="群名称" code="Name" type="string" width = "150"></item>
<item name="创建人" code="Creater" type="string" width = "200"></item>
<item name="创建时间" code="CTime" type="string" width = "150"></item>
<item name="ID" code="ID" type="string" show="false" width = "150"></item>
<item name="群成员" code="Member" type="string" width = "150"></item>
</data>
<data type="Message" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="发送者" code="Sender" type="string" width = "150"></item>
<item name="接收者" code="Receiver" type="string" width = "200"></item>
<item name="内容" code="Content" type="string" width = "150"></item>
//<item name="语音聊天" code="Voice" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "150"></item>
<item name="图片路径" code="Path" type="string" width = "150"></item>
<item name="消息类型" code="Type" type="string"  width = "150"></item>
</data>

</plugin>
[config]*/
function News(){
    this.List = "";
}
function Info(){
    this.DataState = "Normal";
    this.Time = "";
    this.ID = "";
}
function User(){
    this.DataState = "Normal";
    this.Name = "";
    this.Msg = "";
    this.UTime = "";
    this.ID = "";
}
function Friend(){
    this.DataState = "Normal";
    this.Name = "";
    this.Msg = "";
    this.Nick = "";
    this.CTime = "";
    this.UTime = "";
    this.ID = "";
}
function Group(){
    this.DataState = "Normal";
    this.Name = "";
    this.Creater = "";
    this.CTime = "";
    this.ID = "";
    this.Member = "";
}
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Content = "";
    this.Voice = "";
    this.Time = "";
    this.Path = "";
    this.Type = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "Line";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
 var news1 = new TreeNode();
    news1.Text = "账号";
    news1.Type = "Info";
    accinfo = getInfo(db2);
    news1.Items = accinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
  
     //var accinfo = getInfo(db2);
     //var infoNode = newTreeNode("账号","Info",accinfo,news);
     for(var i in accinfo){
         var user = new TreeNode() ;
         user.Text = accinfo[i].ID;
        user.Type = "User"; 
        userinfo = getUser(db,accinfo[i]);
        user.Items = userinfo;
        news1.TreeNodes.push(user);
     }
    var oID = userinfo[i].Name;
     //var userinfo = getUser(db);
     //var infoNode = newTreeNode("账号","User",userinfo,accinfo);
    
    var friendinfo = getFriend(db);
    var friendNode = newTreeNode("好友","Friend",friendinfo,news);
       
    for(var i in friendinfo){
        newTreeNode(friendinfo[i].Name,"Message",getMessage(db,friendinfo[i],"好友",oID),friendNode);
    }
    var gourpinfo = getGroup(db);
    var gourpNode = newTreeNode("群组","Group",gourpinfo,news);
    for(var i in gourpinfo){
        newTreeNode(gourpinfo[i].Name,"Message",getMessage(db,gourpinfo[i],"群组",oID),gourpNode);
    }
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["好友","群组"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
function getInfo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from keystore where prikey is not null" ) +')');
    for(var i in data){
        var obj = new Info();
        obj.ID = data[i].mid;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getUser(path,accinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id = '"+accinfo.ID+"'" ) +')'); 
    for(var i in data){
        var obj = new User();
        obj.Name = data[i].name;
        obj.Msg = data[i].status_msg;
        obj.UTime = XLY.Convert.LinuxToDateTime(data[i].updated_time);
        obj.ID = data[i].m_id;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFriend(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from contacts" ) +')');
    for(var i in data){
        var obj = new Friend();
        obj.Name = data[i].name;
        obj.Nick = data[i].server_name;
        obj.Msg = data[i].status_msg;
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].added_time_to_friend);
        obj.UTime = XLY.Convert.LinuxToDateTime(data[i].updated_time);
        obj.ID = data[i].m_id;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from groups" ) +')');
    for(var i in data){
        var obj = new Group();
        var cn = eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id = '"+data[i].creator+"'") +')');
        log(cn);
        var meminfo = eval('('+ XLY.Sqlite.Find(path,"select * from membership where id = '"+data[i].id+"'") +')');
        //log(meminfo);
        var mem = "";
        for(var j in meminfo ){
            var fr=eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id = '"+meminfo[j].m_id+"'" ) +')');
            obj.Member += fr[0].name+"、";
        }
        obj.Name = data[i].name;
        if(cn.length>0){
           obj.Creater = cn[0].name;
        }
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].created_time);
        obj.ID = data[i].id;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getMessage(path,forg,flag,oID){
    //log(forg);
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from chat_history where chat_id = '"+forg.ID+"' order by created_time" ) +')');
    for(var i in data){
        var sender = eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id = '"+data[i].from_mid+"'" ) +')');
        //log(sender);
        var obj = new Message();
        if(flag=="好友"){
            //log(data[i]);
            if(data[i].chat_id==data[i].from_mid){
                //log(data[i].from_mid);
                obj.Sender = forg.Name;
                obj.Receiver = oID;
                //log(forg.Name);              
            }
             else{ 
                obj.Sender=oID;                 
                obj.Receiver = forg.Name;
                //log(obj.Receiver);                
             } 
        }
         else{
            if(data[i].from_mid==null){
                obj.Sender=oID;
            }
            else{
                obj.Sender = sender[0].name;
            }
            obj.Receiver = forg.Name;
         }
        obj.Content = data[i].content;
        obj.Path = data[i].attachement_local_uri;
        obj.Voice = data[i].parameter;
        //log(obj.Voice);
        var a = data[i].attachement_type;
        //log(a);
        switch(a){
          case 0:
           obj.Type = "文本" ;
            break;
          case 1:
            obj.Type = "图片" ;
            break;
          case 3:
            obj.Type = "录音" ;
            break;
          case 6:
            obj.Type = "通话" ;
            break;
          case 7:
            obj.Type = "表情" ;
            break;
          case 13:
            obj.Type = "名片" ;
            break;
          case 15:
            obj.Type = "位置信息";
            break;
          default:
            obj.Type = "其他";
            break; 
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
var db2 = source[1];
//var db = "D:\\temp\\data\\jp.naver.line.android\\databases\\naver_line";
//var db2 = "D:\\temp\\data\\jp.naver.line.android\\databases\\e2ee";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
