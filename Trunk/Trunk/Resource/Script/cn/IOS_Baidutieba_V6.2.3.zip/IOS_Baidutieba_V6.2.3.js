﻿/*[config]
<plugin name="百度贴吧,5" group="社交聊天,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth"  icon="/icons/baidutieba.png"  app="com.baidu.tieba" version="6.2.3" description="百度贴吧"  data="$data,ComplexTreeDataSource">
<source>
<value>com.baidu.tieba</value>
</source>
<data type="Tieba" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分组" code="Name" type="string" width="600" format="" ></item>
</data>
<data type="User" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="ID" code="ID" type="string" width="80" format = ""></item>
<item name="昵称" code="Name" type="string" width="100" format = "" ></item>
</data>
<data type="Contact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="昵称" code="Name" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string" width="" format = ""></item>
</data>
<data type="Group" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="名称" code="Name" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string" width="" format = ""></item>
</data>
<data type="Message" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="发送人" code="Sender" type="string" width="100" format=""></item>
<item name="接收人" code="Target" type="string" width="100" format=""></item>
<item name="会话内容" code="Content" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order = "asc"></item>
<item name="消息类型" code="MsgType" type="string" format="" width="60"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="Enum" format="EnumSendState"  show="false"></item>
</data>
<data type="Search" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="内容" code="Content" type="string" width="" format = ""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Post" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="贴吧名称" code="Name" type="string" width="" format = ""></item>
<item name="主题" code="Theme" type="string" width="300" format = ""></item>
<item name="最后访问时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//******************************************定义数据结构******************************************
//定义数据结构
function Tieba()
{
    this.Name = "";
    this.DataState="Normal";
}

//定义用户信息数据结构
function User()
{
    this.ID = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义好友数据结构
function Contact()
{
    this.ID = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义好友数据结构
function Group()
{
    this.ID = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义会话数据结构
function Message(){
    this.Sender = "";
    this.Target = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
    this.Type = "";
    this.MsgType = "";
    this.SendState = "";
}

//定义搜索数据结构
function Search()
{
    this.Time = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义发帖数据结构
function Post()
{
    this.Theme = "";
    this.Time = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义树结构
function TreeNode() 
{
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

//******************************************定义处理数据的方法******************************************
function bindTree()
{
    var tieba = new TreeNode();
    tieba.Text = "百度贴吧";
    tieba.Type = "User";
    userinfo = getUser(dbuser);
    tieba.Items = userinfo;
    for(var i in userinfo){
        var user = new TreeNode();
        user.Text = userinfo[i].Name;
        user.Type = "Tieba";
        user.Items = getTieba();
        user.DataState = XLY.Convert.ToDataState( userinfo[i].XLY_DataType);
        tieba.TreeNodes.push(user);
        
        //创建好友树节点
        var friend = new TreeNode();
        friend.Text = "好友";
        friend.Type = "Contact";
        var dbcontact = getRecoveryPath(db,userinfo[i]);
        var friendinfo = getContact(dbcontact,userinfo[i]);
        friend.Items = friendinfo;
        user.TreeNodes.push(friend);
        for(var j in friendinfo){
            if(friendinfo[i].ID!=null){         
                var contact = new TreeNode();
                contact.Text = friendinfo[j].Name;
                contact.Type = "Message";
                contact.Items = getMessage(dbcontact,userinfo[i],friendinfo[j],"好友消息");
                contact.DataState = XLY.Convert.ToDataState( friendinfo[j].XLY_DataType);
                friend.TreeNodes.push(contact);
            }
        } 
        //创建群组树节点
        var groupname = new TreeNode();
        groupname.Text = "群组";
        groupname.Type = "Group";
        var groupinfo = getGroup(dbcontact,userinfo[i]);
        groupname.Items = groupinfo;
        user.TreeNodes.push(groupname);
        for(var k in groupinfo){
            var group = new TreeNode();
            group.Text = groupinfo[k].Name;
            group.Type = "Message";
            group.Items = getMessage(dbcontact,userinfo[i],groupinfo[k]);
            group.DataState = XLY.Convert.ToDataState( groupinfo[k].XLY_DataType);
            groupname.TreeNodes.push(group);
        }     
    }
    return tieba;
}

//获取用户信息
function getUser(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'TBCLogin' ) +')');
    for(var i in data){
        var obj = new User();
        obj.ID = data[i].UID;
        obj.Name = data[i].UNAME;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取分组
function getTieba(){
    var list = new Array();
    var info = ["好友","群组"]; 
    for(var i in info){
        var obj = new Tieba();
        obj.Name = info[i];
        obj.DataState = "Normal";
        list.push(obj);
    }
    return list;
}

//获取好友信息
function getContact(path,data){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.FindByName(path,"tb_contacts_list" ) +')');
    if(info!=null){
        for(var i in info){
            var obj = new Contact();
            obj.ID = info[i].uid;
            obj.Name = info[i].uname;
            obj.DataState = XLY.Convert.ToDataState( info[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取群组信息
function getGroup(path,data){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select * from tb_group_list where gtype=2 or gtype=3" ) +')');
    if(info!=null){
        for(var i in info){
            var obj = new Group();
            obj.ID = info[i].gid;
            obj.Name = info[i].gname;
            obj.DataState = XLY.Convert.ToDataState( info[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取恢复路径
function getRecoveryPath(path,data){
    var db = path+"\\contents\\"+data.ID+"\\db.sqlite";
    var tblinfo = eval('('+ XLY.Sqlite.Find(db,"select distinct tbl_name from sqlite_master where tbl_name like 'tb_groupmsg_%' or tbl_name like 'tb_usermsg_%'") +')');    
    var tblname = "";
    for(var index in tblinfo){
        tblname += tblinfo[index].tbl_name+","; 
    }
    var name = tblname.substr(0,tblname.length-1);
    var dbcontact = XLY.Sqlite.DataRecovery(db,charactor2,"tb_contacts_list,tb_group_list,"+name);
    return dbcontact;
}

//获取会话信息
function getMessage(dbmsg,data1,data2,flag){
    var list = new Array();
    if(flag=="好友消息"){
        var info = eval('('+ XLY.Sqlite.Find(dbmsg,"select distinct tbl_name from sqlite_master where tbl_name like 'tb_usermsg_%'") +')');
        if(info.length>0){
            for(var i in info){
                if(info[i].tbl_name=="tb_usermsg_"+data2.ID){
                    var msg = eval('('+ XLY.Sqlite.Find(dbmsg,"select * from "+info[i].tbl_name ) +')');
                    for(var i in msg){
                        var obj = new Message();                       
                        if(msg[i].uid==data1.ID){
                            obj.Sender = data1.Name;
                            obj.Target = data2.Name;
                            obj.SendState = "Send";
                        }else{
                            obj.Sender = data2.Name;
                            obj.Target = data1.Name;
                            obj.SendState = "Receive";
                        }                        
                        getMsgType(msg[i],obj);
                        obj.Time = XLY.Convert.LinuxToDateTime(msg[i].create_time);
                        obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                        list.push(obj);
                    }
                }
            }
        }
    }else{
        var info1 = eval('('+ XLY.Sqlite.Find(dbmsg,"select distinct tbl_name from sqlite_master where tbl_name like 'tb_groupmsg_%'") +')');
        if(info1.length>0){
             for(var i in info1){
                 if(info1[i].tbl_name=="tb_groupmsg_"+data2.ID){
                    var msg = eval('('+ XLY.Sqlite.Find(dbmsg,"select * from "+info1[i].tbl_name ) +')');
                    for(var i in msg){
                        var obj = new Message();
                        var senderinfo = eval('('+ XLY.PList.ConvertBufferToJson(msg[i].user_info) +')');
                        obj.Sender = senderinfo[1].$objects[0].NSMutableDictionary[3].userName;
                        obj.Target = data2.Name;
                        if(obj.Sender==data1.Name){
                            obj.SendState = "Send";
                        }else{
                            obj.SendState = "Receive";
                        }
                        getMsgType(msg[i],obj);
                        obj.Time = XLY.Convert.LinuxToDateTime(msg[i].create_time);
                        obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                        list.push(obj);
                    }
                 }
             } 
        }
    }
    return list;
}

//消息类型
function getMsgType(data,root){
    var cont = data.content;
    var info = eval('('+ cont +')');
    switch(data.msgtype){
        case 1:  root.Type = "HTML";root.MsgType = "文本";root.Content = info[0].text;
        break;
        case 2: root.Type = "Image";root.MsgType = "图片";root.Content = info[0].big_src;
        break;
        case 3: root.Type = "Audio";root.MsgType = "音频";root.Content = info[0].voice_md5;
        break;
        case 11: root.Type = "HTML";root.MsgType = "系统消息";root.Content = info.userMsg;root.Sender=info.eventParam.userName;
        break;
        default: root.Type = "HTML";root.MsgType = "文本"; root.Content = info[0];
    }
}
//*****************************************************************
var result = new Array();
var source = $source;
var db = source[0]+"\\com.baidu.tieba\\Documents";
//var db = "D:\\temp\\data\\data\\IOS.com.baidu.tieba\\Documents";
var charactor1="\\chalib\\IOS_Baidutieba_V6.2.3\\db.sqlite.charactor";
var charactor2 = "\\chalib\\IOS_Baidutieba_V6.2.3\\db(2).sqlite.charactor";
var dbuser = XLY.Sqlite.DataRecovery(db+"\\db.sqlite",charactor1,"TBCLogin");

result.push(bindTree());
var res = JSON.stringify(result);
res;
