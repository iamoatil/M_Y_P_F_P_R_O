﻿/*[config]
<plugin name="DJI GO,8" group="生活旅游,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="/icons/dji.png" app="com.dji.pilot" version="3.1.10" description="DJI GO" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.dji.pilot</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="ID" type="string" width="150"></item>
    <item name="移动设备信息" code="MobileInfo" type="string" width="150"></item>
    <item name="最后一次DPS定位" code="DjiLastAirPoint" type="string" width = "150"></item>
    <item name="国家代码" code="CodeTag" type="string" width = "80"></item>
    <item name="时间" code="Time" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="邮箱" code="AccountEmail" type="string" width = "150"></item>
    <item name="版本" code="FlyVersior" type="string" width = "150"></item>
</data>
<data type="Dynamic" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者昵称" code="SenderName" type="string" width="150"></item>
    <item name="发送者头像" code="SenderUrl" type="url" width="150"></item>
    <item name="标题" code="Title" type="string" width="150"></item>
    <item name="内容链接" code="ContentUrl" type="url" width="150"></item>
    <item name="模型名称" code="ModelName" type="string" width="150"></item>
    <item name="经度" code="Lng" type="string" width="80"></item>
    <item name="纬度" code="Lat" type="string" width = "80"></item>
    <item name="是否公开" code="IsPublic" type="string" width = "80"></item>
    <item name="类型" code="ContentType" type="string" width = "80"></item>
    <item name="定位" code="AccountLocation" type="string" width = "80"></item>
    <item name="标签" code="Tag" type="string" width = "80"></item>
    <item name="发布时间" code="SendTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="更新时间" code="UpdateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="是否VIP" code="IsVip" type="string" width = "80"></item>
    <item name="查看" code="ViewCount" type="string" width = "80"></item>
    <item name="点赞" code="LikeCount" type="string" width = "80"></item>
    <item name="评论" code="CommentCount" type="string" width = "80"></item>
    <item name="收藏" code="FavoriteCount" type="string" width = "80"></item>
    <item name="是否点赞" code="IsLike" type="string" width = "80"></item>
    <item name="是否关注" code="IsFollow" type="string" width = "80"></item>
    <item name="是否收藏" code="IsFavorite" type="string" width = "80"></item>
</data>
<data type="PhotoGraph" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="开始时间" code="PhotoGraphTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="源文件路径" code="SourcePath" type="url" width="150"></item>
    <item name="时长" code="EndTimeMsec" type="string" width="150"></item>
    <item name="文件名" code="FileName" type="url" width="150"></item>
    <item name="经度" code="Lng" type="string" width="300"></item>
    <item name="纬度" code="Lat" type="string" width = "80"></item>
</data>
<data type="Log" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="时间" code="Time" type="string" width="150"></item>
    <item name="内容" code="Content" type="string" width="150"></item>
</data>
<data type="Creation" contract = "DataState" detailfield = "ProjectSource">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="ProjectName" type="string" width="150"></item>
    <item name="描述" code="ProjectDescription" type="string" width = "150"></item>
    <item name="是否最新" code="IsNew" type="string" width = "80"></item>
    <item name="素材" code="ProjectSource" type="string" width = "300"></item>
</data>
</plugin>
[config]*/
function Creation(){
    this.DataState = "Normal";
    this.ProjectName = "";
    this.ProjectDescription = "";
    this.IsNew = "否";
    this.ProjectSource = "";
}
function Log(){
    this.DataState = "Normal";
    this.Time = "";
    this.Content = "";
}
function PhotoGraph(){
    this.DataState = "Normal";
    this.PhotoGraphTime = null;
    this.SourcePath = "";
    this.EndTimeMsec = "";
    this.FileName = "";
    this.Lng = "";
    this.Lat = "";
}
function Dynamic(){
    this.DataState = "Normal";
    this.SenderName = "";
    this.SenderUrl = "";
    this.Title = "";
    this.ContentUrl = "";
    this.ModelName = "";
    this.Lng = "";
    this.Lat = "";
    this.IsPublic = "";
    this.ContentType = "";
    this.AccountLocation = "";
    this.Tag = "";
    this.IsVip = "";
    this.ViewCount = "";
    this.LikeCount = "";
    this.CommentCount = "";
    this.FavoriteCount = "";
    this.IsLike = "";
    this.IsFollow = "";
    this.IsFavorite = "";
    this.SendTime = null;
    this.UpdateTime = null;
}
//定义数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.ID = "";
    this.MobileInfo = "";
    this.DjiLastAirPoint = "";
    this.CodeTag = "";
    this.AccountEmail = "";
    this.FlyVersior = "";
    this.Time = null;
}

function News(){
    this.DataState = "Normal";
    this.List = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var upath = source[0]+"\\com.dji.pilot\\Library\\Preferences\\com.dji.pilot.plist";
var allPath = source[0]+"\\com.dji.pilot\\Documents";
//测试数据
//var upath = "C:\\Users\\liu\\Desktop\\AppDomain-com.dji.pilot\\Library\\Preferences\\com.dji.pilot.plist";
//var allPath = "C:\\Users\\liu\\Desktop\\AppDomain-com.dji.pilot\\Documents";
//
//定义特征库文件
var charactor = "chalib\\Android_Chelaile_V3.24.2\\com.ygkj.chelaile.db.charactor";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "DJI GO";
    root.Type = "";
    getNews(root);
    
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(upath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(upath) +')');
        if(data!=""&&data!= null){
            var obj = new UserInfo();
            
            for(var i in data){
                if(data[i].xg_push_lang_tag!=""&&data[i].xg_push_lang_tag!=null){
                    obj.CodeTag = data[i].xg_push_lang_tag;
                }
                if(data[i].machinePlatForm!=""&&data[i].machinePlatForm!=null){
                    obj.MobileInfo = data[i].machinePlatForm;
                }
                if(data[i].xg_push_lang_tag!=""&&data[i].xg_push_lang_tag!=null){
                    obj.CodeTag = data[i].xg_push_lang_tag;
                }
                if(data[i].kUserDefaultKeyAircraftLocation!=""&&data[i].kUserDefaultKeyAircraftLocation!=null){
                    obj.DjiLastAirPoint = data[i].kUserDefaultKeyAircraftLocation;
                }
                if(data[i].appVersion_pack!=""&&data[i].appVersion_pack!=null){
                    obj.FlyVersior = data[i].appVersion_pack;
                }
                if(data[i].UTDID!=""&&data[i].UTDID!=null){
                    obj.Time = XLY.Convert.LinuxToDateTime(data[i].UTDID[2].UTDID_createdTS);
                }
                if(data[i].LastAccessID!=""&&data[i].LastAccessID!=null){
                    obj.ID = data[i].LastAccessID;
                }
                if(data[i].DJIACCOUNTMANAGER_LASTUSEREMAIL!=""&&data[i].DJIACCOUNTMANAGER_LASTUSEREMAIL!=null){
                    obj.AccountEmail = data[i].DJIACCOUNTMANAGER_LASTUSEREMAIL;
                }
            }
            
            if(obj.ID!=""&&obj.ID!= null){
                var nodeUser = new TreeNode();
                nodeUser.Text = obj.ID;
                nodeUser.Type = "UserInfo";
                nodeUser.Items.push(obj);
                getUserChildNode(nodeUser);
                root.TreeNodes.push(nodeUser);
            }
        }
    }
}
function getUserChildNode(root){
    var nodeLogRoot = new TreeNode();
    nodeLogRoot.Text = "日志";
    nodeLogRoot.Type = "";
    
    var nodeEditor = new TreeNode();
    nodeEditor.Text = "编辑器";
    nodeEditor.Type = "";
    var nodePicture = new TreeNode();
    nodePicture.Text = "图库";
    nodePicture.Type = "";
    var nodeCreation = new TreeNode();
    nodeCreation.Text = "创作";
    nodeCreation.Type = "Creation";
    var nodeVideo = new TreeNode();
    nodeVideo.Text = "视频";
    nodeVideo.Type = "";
    var nodePhoto = new TreeNode();
    nodePhoto.Text = "照片";
    nodePhoto.Type = "";
    var nodeFavorite = new TreeNode();
    nodeFavorite.Text = "收藏";
    nodeFavorite.Type = "";
    var videoPath = allPath + "\\videoCache";
    var videoReg = new RegExp(".info");
    var videoFolderData = eval('('+ XLY.File.FindFileNamesWithExtension(videoPath) +')');
    if(videoFolderData!=""&&videoFolderData!=null){
        for(var i in videoFolderData){
            if(videoReg.test(videoFolderData[i])){
                var videoInfoPath = videoPath+"\\"+videoFolderData[i];
                if(XLY.File.IsValid(videoInfoPath)){
                    var info = eval('('+ XLY.PList.MacReadToJsonString(videoInfoPath) +')');
                    if(info!=""&&info!= null){
                        var obj = new PhotoGraph();
                        var cc = XLY.File.GetFileName(videoInfoPath);
                        var aa = info["$objects"];
                        var cur = XLY.Convert.LinuxToDateTime(aa[5]["NS.time"]);
                        var bb = cur.split("-")[0];
                        obj.PhotoGraphTime = Number(bb)+31+"-"+cur.split("-")[1]+"-"+cur.split("-")[2];
                        obj.SourcePath = videoInfoPath.substr(0,videoInfoPath.length-4)+"mp4";
                        obj.EndTimeMsec = aa[9]+" 秒";
                        obj.FileName = cc.substr(0,cc.length-4)+"mp4";
                        var node = new TreeNode();
                        node.Text = obj.FileName;
                        node.Type = "PhotoGraph";
                        for(var j in aa){
                            if(aa[j]=="DJIPhantom3S"){
                                obj.Lng = aa[j-1];
                                obj.Lat = aa[++j];
                            }
                        }
                        node.Items.push(obj);
                        if(node.Items!=""&&node.Items!=null){
                            nodeVideo.TreeNodes.push(node);
                        }
                    }
                }
            }
        }
    }
    var videoEditProjectsPath = allPath + "\\VideoEditProjects";
    var videoEditProjectsData = eval('('+ XLY.File.FindFileNamesWithExtension(videoEditProjectsPath) +')');
    if(videoEditProjectsData!=""&&videoEditProjectsData!=null){
        for(var v in videoEditProjectsData){
            editProjectsPath = videoEditProjectsPath +"\\"+videoEditProjectsData[v];
            if(XLY.File.IsValid(editProjectsPath)){
                var dataEdit = eval('('+ XLY.PList.ReadToJsonString(editProjectsPath) +')');
                if(dataEdit!=""&&dataEdit!=null){
                    for(var d in dataEdit){
                        if(dataEdit[d]["$objects"]!=""&&dataEdit[d]["$objects"]!= null){
                            for(var z in dataEdit[d]["$objects"]){
                                if(dataEdit[d]["$objects"][z].DJIVideoEditProject!=""&&dataEdit[d]["$objects"][z].DJIVideoEditProject!= null){
                                    var editProject = dataEdit[d]["$objects"][z].DJIVideoEditProject;
                                    var arr = new Array();
                                    var creatObj = new Creation();
                                    
                                    for(var q in editProject){
                                        if(editProject[q].isNew!=""&&editProject[q].isNew!= null){
                                            creatObj.IsNew = "是";
                                        }
                                        if(editProject[q].lightEditDescription!=""&&editProject[q].lightEditDescription!=null){
                                            creatObj.ProjectDescription = editProject[q].lightEditDescription;
                                        }
                                        if(editProject[q].projectName!=""&&editProject[q].projectName!=null){
                                            creatObj.ProjectName = editProject[q].projectName;
                                        }
                                        if(editProject[q].segments!=""&&editProject[q].segments!= null){
                                            for(var e in editProject[q].segments.NSArray){
                                                if(editProject[q].segments.NSArray[e].CSegment[4].filePath!=""&&editProject[q].segments.NSArray[e].CSegment[4].filePath!=null){
                                                    arr.push(editProject[q].segments.NSArray[e].CSegment[4].filePath);
                                                    //log(editProject[q].segments.NSArray[e].CSegment[4].filePath);
                                                }
                                            }
                                        }
                                    }
                                    if(arr!=""&&arr!= null){
                                        var result = new Array();
                                        var hash = {};
                                        for(var r in arr){
                                            if(result.indexOf(arr[r])==-1){
                                                result.push(arr[r]);
                                            }
                                        }
                                        var ator = "";
                                        if(result!=""&&result!=null){
                                            for(var t in result){
                                                if(t==result.length-1){
                                                    ator+= result[t];
                                                }
                                                else
                                                {
                                                    ator+= result[t]+"\n";
                                                }
                                            }
                                            creatObj.ProjectSource = ator;
                                        }
                                    }
                                    nodeCreation.Items.push(creatObj);
                                }
                            }
                        }
                    }
                }
                
            }
        }
    }
    var logPath = allPath + "\\Logs";
    var logData = eval('('+ XLY.File.FindFileNamesWithExtension(logPath) +')');
    var logReg = new RegExp("upgradeLog");
    if(logData!=""&&logData!=null){
        for(var g in logData){
            var logDataPath = logPath+"\\"+logData[g];
            var nodeLog = new TreeNode();
            nodeLog.Text = logData[g].substr(0,logData[g].length-4);
            nodeLog.Type = "Log";
            if(XLY.File.IsValid(logDataPath)){
                var txtData = XLY.File.ReadFile(logDataPath);
                if(txtData!=""&&txtData!= null){
                    var textData1 = txtData.split("\r\n")[0];
                    if(textData1!=""&&textData1!=null){
                        if(logReg.test(logData[g])){
                            var textData2 = textData1.split("[");
                            for(var d in textData2){
                                var logObj = new Log();
                                logObj.Time = textData2[d].split("]")[0];
                                logObj.Content = textData2[d].split("]")[1];
                                if(logObj.Content!=""&&logObj.Content!=null){
                                    nodeLog.Items.push(logObj);
                                }
                            }
                        }
                        else
                        {
                            var textData2 = textData1.split("\n");
                            for(var d in textData2){
                                var logObj = new Log();
                                var txtData = textData2[d].replace(/(^\s*)|(\s*$)/g, "");
                                logObj.Time = txtData.substr(0,25);
                                logObj.Content = txtData.substr(27,txtData.length);
                                if(logObj.Content!=""&&logObj.Content!=null){
                                    nodeLog.Items.push(logObj);
                                }
                            }
                            
                        }
                        
                    }
                }
            }
            if(nodeLog.Items!=""&&nodeLog.Items!=null){
                nodeLogRoot.TreeNodes.push(nodeLog);
            }
        }
    }
    nodePicture.TreeNodes.push(nodeVideo);
    nodePicture.TreeNodes.push(nodePhoto);
    nodePicture.TreeNodes.push(nodeFavorite);
    nodeEditor.TreeNodes.push(nodePicture);
    nodeEditor.TreeNodes.push(nodeCreation);
    root.TreeNodes.push(nodeEditor);
    root.TreeNodes.push(nodeLogRoot);
}