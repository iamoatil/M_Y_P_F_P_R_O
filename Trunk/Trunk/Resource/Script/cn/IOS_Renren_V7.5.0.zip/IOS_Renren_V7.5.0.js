﻿/*[config]
<plugin name="人人网,8" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/renren.png" app="com.xiaonei.xiaonei" version="7.5.0" description="人人网" data="$data,ComplexTreeDataSource" >
<source>
<value>com.xiaonei.xiaonei</value>
</source>
<data type="Account">
<item name="头像地址" code="headUrl" type="Image" width="50" show="false"></item>
<item name="用户名" code="name" type="string" width="150"></item>
<item name="性别" code="gender" type="string" width="150"></item>
<item name="手机" code="mobile" type="string" width="150"></item>
<item name="生日" code="birthDay" type="string" width="150"></item>
<item name="家乡" code="homeTown" type="string" width="300"></item>
<item name="中学" code="highSchool" type="string" width="300"></item>
<item name="大学" code="College" type="string" width="300"></item>
</data>
<data type="Visitors" datefilter="time">
<item name="人人号" code="renrenID" type="string" width="150"></item>
<item name="姓名" code="name" type="string" width="150"></item>
<item name="访问时间" code="time" type="string" width="150"></item>
<item name="头像URL" code="headUrl" type="Image" width="50"></item>
</data>
<data type="RencentFirends" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="人人号" code="renrenID" type="string" width="150"></item>
<item name="姓名" code="name" type="string" width="150"></item>
</data>
<data type="RencentGroups" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="人人号" code="renrenID" type="string" width="150"></item>
<item name="姓名" code="name" type="string" width="150"></item>
</data>
<data type="Feeds" datefilter="time">
<item name="姓名" code="name" type="string" width="150"></item>
<item name="来源" code="source" type="string" width="150"></item>
<item name="动态" code="activity" type="string" width="75"></item>
<item name="内容" code="content" type="string" width="300"></item>
<item name="分享" code="share" type="string" width="75"></item>
<item name="赞" code="like" type="string" width="75"></item>
<item name="赞过的人" code="likePerson" type="string" width="150"></item>
<item name="评论" code="comment" type="string" width="400"></item>
<item name="附件" code="attachement" type="URL" width="150"></item>
<item name="时间" code="time" type="string" width="150"></item>
</data>
<data type="History"  contract="DataState,Conversion" datefilter="Date"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="150"></item>
<item name="接收人" code="to" type="string" width="150"></item>
<item name="内容" code="Content" type="string" width="300"></item>
<item name="类型" code="type" type="string" width="300"></item>
<item name="类型选择" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item> 
<item name="时间" code="Date" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState" show="false"></item>
<item name="头像" code="SenderImage" type="image" width="50" show="false" ></item> 
</data>
</plugin>
[config]*/

//节点的定义
function Account()
{
	this.headUrl="";
	this.name="";
	this.gender="";
	this.mobile="";
	this.birthDay="";
	this.homeTown="";
	this.highSchool="";
	this.College="";
}

function Visitors()
{
	this.renrenID="";
	this.name="";
	this.time="";
	this.headUrl="";
}

function RencentFirends()
{
	this.DataState = "Normal";
	this.renrenID="";
	this.name="";
}

function RencentGroups()
{
	this.DataState = "Normal";
	this.renrenID="";
	this.name="";
}

function Feeds()
{
	this.name="";
	this.source="";
	this.activity="";
	this.content="";
	this.share="";
	this.like="";
	this.likePerson="";
	this.attachement="";
	this.comment="";
	this.time="";
}

function History()
{
	this.DataState = "Normal";
	this.SenderName="";
	this.to="";
	this.Content="";
	this.type="";
	this.Type="";
	this.Date="";
	this.SendState="";
	this.SenderImage="";
}

//ID姓名的转换
function uidToUname(uid,path)
{
	var arr = ""; 
	var filespec= path+uid+"\\userProfile\\";
	var user=eval('('+XLY.File.FindFiles(filespec)+')');
	for(var userIndex in user)
	{
		if(user[userIndex].indexOf("userBaseInfoFile")>0)
		{    
			var userinfo=eval('('+XLY.File.ReadFile( user[userIndex])+')');
			arr=userinfo.user_name;   
		}
	}
	return arr;
}

//获取姓名
function getUserName(userpath)
{
	var filename=eval('('+XLY.File.FindDirectories(userpath)+')');
	var arrName=new Array();
	for(var index in filename)
	{
		var user=XLY.File.GetFileName(filename[index]);
		arrName.push(user);
	}
	return arrName;
}

//获取用户信息
function getUserInfo(arrName,_filespec)
{
	var arr = new Array();    
	try{
		var filespec= _filespec+arrName+"\\userProfile\\";
		var user=eval('('+XLY.File.FindFiles(filespec)+')');
		for(var userIndex in user)
		{
			if(user[userIndex].indexOf("userBaseInfoFile")>0)
			{    
				var userinfo=eval('('+XLY.File.ReadFile( user[userIndex])+')');
				var obj =new Account();  
				obj.name=userinfo.user_name;
				obj.gender=userinfo.gender;
				obj.mobile=userinfo.binded_mobile;
				if(userinfo.birth.year&&userinfo.birth.month&&userinfo.birth.day){
					obj.birthDay=userinfo.birth.year+"年"+userinfo.birth.month+"月"+userinfo.birth.day+"日";}
				else{
					obj.birthDay=""}
				obj.homeTown=userinfo.hometown_info.province+"  "+userinfo.hometown_info.city;
				obj.highSchool=userinfo.highschool_list[0].hight_school_name;
				obj.College=userinfo.university_list[0].university_name+"  "+userinfo.university_list[0].department;
				obj.headUrl=userinfo.large_url;
				arr.push(obj);  
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//最近访问
function getVisitorInfo(arrName,_filespec)
{
	var arr = new Array();    
	try{
		var filespec= _filespec+arrName+"\\userProfile\\";
		var user=eval('('+XLY.File.FindFiles(filespec)+')');
		for(var userIndex in user)
		{
			if(user[userIndex].indexOf("recentVisitor")>0)
			{
				var visitInfo=eval('('+XLY.File.ReadFile(user[userIndex])+')');
				for(var list in visitInfo.visitor_list)
				{
					var obj =new Visitors();
					obj.renrenID= visitInfo.visitor_list[list].user_id;//这里能够取到最近访问信息
					obj.name= visitInfo.visitor_list[list].user_name;
					obj.headUrl=visitInfo.visitor_list[list].user_urls.head_url;
					obj.time= XLY.Convert.LinuxToDateTime(visitInfo.visitor_list[list].time);
					arr.push(obj);  
				}
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//动态
function getFeeds(arrName,feedUrl)
{
	var arr = new Array();
	try{
		var feedUrl= feedUrl+arrName+"\\newsFeed\\";
		var feedData=eval('('+XLY.File.FindFiles(feedUrl)+')');
		for(var friendIndex in feedData)
		{
			if(feedData[friendIndex].indexOf("friendFeed")>0)
			{
				var feedInfo=eval('('+XLY.File.ReadFile( feedData[friendIndex])+')');
				for(var feedindex in feedInfo.feed_list)
				{
					var data=feedInfo.feed_list[feedindex];
					var obj =new Feeds();
					obj.name=data.user_name+"("+data.user_id+")";
					obj.time=XLY.Convert.LinuxToDateTime(data.time);
					obj.source=data.origin_title;
					obj.activity=data.prefix;
					obj.content=data.title;
					obj.share=data.share_count;
					obj.like=data.like.like_count
						if(data.like.like_count!=0)
						{
							for(var index in data.like.like_user)
							{
								obj.likePerson+=data.like.like_user[index].name+"/";
							}
						}
						for(var index in data.attachement_list)
						{
							if(data.attachement_list[index].main_url!=null){
								obj.attachement+=data.attachement_list[index].main_url+" ";
							}
							if(data.attachement_list[index].digest!=null){
								obj.attachement+=data.attachement_list[index].digest+"/";
							}
						}
						for(var index in data.comment_list)
						{
							if(data.comment_list[index].user_name!=null){
								obj.comment+=data.comment_list[index].user_name+" ";
							}
							if(data.comment_list[index].content!=null){
								obj.comment+=data.comment_list[index].content+" ";
							}
							if(data.comment_list[index].time!=null){
								obj.comment+=XLY.Convert.LinuxToDateTime(data.comment_list[index].time+"");
							}
						}
						arr.push(obj);  
				}
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//好友
function getFriends(arrName,chatFriendUrl,Url)
{
	var arr = new Array();    
	try{
		var chatFriendUrl= chatFriendUrl+arrName+"\\chat.sqlite";
		var charactor="chalib\\IOS_Renren_V7.5.0\\chat.sqlite.charactor";
		chatFriendUrl=XLY.Sqlite.DataRecovery( chatFriendUrl,charactor ,"r_s_chat_message_persistence_object,r_s_chat_session");
		var chatFriendData=eval('('+XLY.Sqlite.Find(chatFriendUrl ,"select target_user_id,target_user_name,XLY_DataType from r_s_chat_session where message_type_string ='chat'" )+')');
		for(var index in chatFriendData)
		{
			var friendNode= new TreeNode();
			friendNode.Text=chatFriendData[index].target_user_name;
			friendNode.Type="History";
			friendNode.DataState = XLY.Convert.ToDataState(chatFriendData[index].XLY_DataType); 
			friendNode.Items= getHistory(arrName,chatFriendData[index].target_user_id,chatFriendData[index].target_user_name,chatFriendUrl,Url);
			arr.push(friendNode);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//群组
function getGroups(arrName,chatFriendUrl,Url)
{
	var arr = new Array();
	try{
		var chatFriendUrl= chatFriendUrl+arrName+"\\chat.sqlite";
		var charactor="chalib\\IOS_Renren_V7.5.0\\chat.sqlite.charactor";
		chatFriendUrl=XLY.Sqlite.DataRecovery( chatFriendUrl,charactor ,"r_s_chat_message_persistence_object,r_s_chat_session");
		var chatFriendData=eval('('+XLY.Sqlite.Find(chatFriendUrl ,"select target_user_id,target_user_name,XLY_DataType from r_s_chat_session where message_type_string ='muc'" )+')');
		for(var index in chatFriendData)
		{
			var friendNode= new TreeNode();
			friendNode.Text=chatFriendData[index].target_user_name;
			friendNode.Type="History";
			friendNode.DataState = XLY.Convert.ToDataState(chatFriendData[index].XLY_DataType); 
			friendNode.Items= getHistory(arrName,chatFriendData[index].target_user_id,chatFriendData[index].target_user_name,chatFriendUrl,Url);
			arr.push(friendNode);
		}    
		return arr;
	}
	catch(e){
		return arr;
	}
}

//聊天历史记录
function getHistory(arrName,targetId,targetName,chatFriendUrl,Url)
{
	var arr = new Array();
	try{
		var chatHistory=eval('('+XLY.Sqlite.Find(chatFriendUrl,"select * from r_s_chat_message_persistence_object where target_user_id ="+targetId)+')');
		for(var index in chatHistory)
		{
			var obj =new History();
			obj.DataState = XLY.Convert.ToDataState(chatHistory[index].XLY_DataType); 
			if(chatHistory[index].message_type=="chat")
			{
				if(chatHistory[index].is_send)
				{
					obj.to=targetName;
					obj.SendState="Send";
				}
				else{
					obj.SendState="Receive";
					obj.to=uidToUname(chatHistory[index].to_user_id,Url);
				}
				obj.SenderName=chatHistory[index].from_user_name;
				obj.type=chatHistory[index].class_type;
				switch (obj.type){
				case "dialog":obj.type="会话";obj.Type="String";break;
				case "voip":obj.type="语音";obj.Type="String";break;
				case "location":obj.type="位置";obj.Type="String";break;
				case "secret":obj.type="私密图片";obj.Type="String";break;
				case "publicAccount":obj.type="系统消息";obj.Type="String";break;
				case "name_card":obj.type="明信片";obj.Type="String";break;
				case "image":obj.type="图片";obj.Type="Image";break;
				}
				obj.Date=XLY.Convert.LinuxToDateTime(chatHistory[index].time_stamp);
				obj.Content=chatHistory[index].summary;
				if(obj.type=="位置")
				{
					obj.Content=subStringPoi(chatHistory[index].child_node_string);
				}
				if(obj.Content=="[图片]")
				{
					obj.Content=subStringPic(chatHistory[index].child_node_string);
					obj.Type="Image";
				}
			}
			if(chatHistory[index].message_type=="muc")
			{
				obj.DataState = XLY.Convert.ToDataState(chatHistory[index].XLY_DataType); 
				if(chatHistory[index].is_send)
				{
					obj.SendState="Send";
				}
				else
				{
					obj.SendState="Receive";
				}
				obj.SenderName=chatHistory[index].from_user_name;
				obj.to=targetName;
				obj.type=chatHistory[index].class_type;
				switch (obj.type){
				case "dialog":obj.type="会话";obj.Type="String";break;
				case "voip":obj.type="语音";obj.Type="String";break;
				case "location":obj.type="位置";obj.Type="String";break;
				case "secret":obj.type="私密图片";obj.Type="String";break;
				case "publicAccount":obj.type="系统消息";obj.Type="String";break;
				case "name_card":obj.type="明信片";obj.Type="String";break;
				case "image":obj.type="图片";obj.Type="Image";break;
				}
				obj.Date=XLY.Convert.LinuxToDateTime(chatHistory[index].time_stamp);
				obj.Content=chatHistory[index].summary;
				if(obj.type=="位置")
				{
					obj.Content=subStringPoi(chatHistory[index].child_node_string);
				}
				if(obj.Content=="[图片]")
				{
					obj.Content=subStringPic(chatHistory[index].child_node_string);
					obj.Type="Image";
				}
			}
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//坐标处理
function subStringPoi(s){
	var ss;                         // 声明变量。
	ss = s.substring(s.indexOf("poi "), s.indexOf("mapurl"));   // 取子字符串。
	return(ss);                     // 返回子字符串。
}

//图片处理
function subStringPic(s){
	var ss;                         // 声明变量。
	ss = s.substring(s.indexOf("originalsrc=")+13, s.lastIndexOf("type=")-2);   // 取子字符串。
	return(ss);                     // 返回子字符串。
}

function TreeNode() 
{
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}

//获取最近联系人（单人，群组）
function createRecentNode(arrName,chatFriendUrl,type)
{
	var arr = new Array();
	try{
		var chatFriendUrl= chatFriendUrl+arrName+"\\chat.sqlite";
		var charactor="chalib\\IOS_Renren_V7.5.0\\chat.sqlite.charactor";
		chatFriendUrl=XLY.Sqlite.DataRecovery( chatFriendUrl,charactor ,"r_s_chat_message_persistence_object,r_s_chat_session");
		var chatFriendData=eval('('+XLY.Sqlite.Find(chatFriendUrl ,"select target_user_id,target_user_name,XLY_DataType from r_s_chat_session where message_type_string = '"+type+"' " )+')');
		for(var index in chatFriendData)
		{
			var obj= new TreeNode();
			if(type=="chat")
			{
				obj.Type="RencentFirends";
			}
			else if(type=="muc")
			{
				obj.Type="RencentGroups";
			}
			obj.renrenID=chatFriendData[index].target_user_id;
			obj.name=chatFriendData[index].target_user_name;
			obj.DataState = XLY.Convert.ToDataState(chatFriendData[index].XLY_DataType); 
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}


var result = new Array();

//源文件
var source = $source;
var PATH1 = source[0] + "\\com.xiaonei.xiaonei\\Documents\\DB\\";//username chat
var PATH2 = source[0] + "\\com.xiaonei.xiaonei\\Documents\\";//filespec feedUrl

//取用户名
var userList =new Array();
userList=GetUserName(PATH1);

//用户信息
for(var index in userList)
{
	var accountNode= new TreeNode();
	accountNode.Text=userList[index];
	var infomationNode= new TreeNode();
	infomationNode.Text="用户信息";
	infomationNode.Type="Account";
	infomationNode.Items=getUserInfo(userList[index],PATH2);
	accountNode.TreeNodes.push(infomationNode);

	//最近访问
	var visitorNode= new TreeNode();
	visitorNode.Text="最近访问";
	visitorNode.Type="Visitors";
	visitorNode.Items=getVisitorInfo(userList[index],PATH2);
	accountNode.TreeNodes.push(visitorNode);

	//好友动态信息
	var feedNode= new TreeNode();
	feedNode.Text="好友动态";
	feedNode.Type="Feeds";
	feedNode.Items=getFeeds(userList[index],PATH2);
	accountNode.TreeNodes.push(feedNode);

	//最近联系人(树)
	var recentfNode= new TreeNode();
	recentfNode.Text="最近好友";
	recentfNode.Type="RencentFirends";
	recentfNode.Items=createRecentNode(userList[index],PATH1,"chat");
	recentfNode.TreeNodes=getFriends(userList[index],PATH1,PATH2);
	accountNode.TreeNodes.push(recentfNode);

	//最近联系人(记录)
	var recentgNode= new TreeNode();
	recentgNode.Text="最近群组";
	recentgNode.Type="RencentGroups";
	recentgNode.Items=createRecentNode(userList[index],PATH1,"muc");
	recentgNode.TreeNodes=getGroups(userList[index],PATH1,PATH2);
	accountNode.TreeNodes.push(recentgNode);
	result.push(accountNode);
}

//打印数据
var res = JSON.stringify(result);
res;
