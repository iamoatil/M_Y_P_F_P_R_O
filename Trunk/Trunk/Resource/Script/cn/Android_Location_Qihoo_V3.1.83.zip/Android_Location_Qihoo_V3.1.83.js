﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="com.qihoo.appstore" version="3.1.83" description="360手机助手" data="$data,LocationInfoDataSource" >
<source>
<value>/data/data/com.qihoo.appstore/shared_prefs/last_know_location.xml</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "";
    this.Source = "360手机助手";
    this.StartDate = null;
}

//获取历史搜索树的信息
function getPosition(path) {
    var data = eval('(' + XLY.File.ReadXML(path) + ')');
    var info = new Array();
    if(data != null){
        var obj = new Position();
        var loc = data.map.string;
        for(var i in loc){
            switch(loc[i]['@name']){
                case "last_know_lat":obj.Latitude = loc[i]['#text'];break;
                case "last_know_lng":obj.Longitude = loc[i]['#text'];break;
                case "city":obj.Remark = loc[i]['#text'];break;
                default:break;
            }
        }
        obj.StartDate = XLY.Convert.LinuxToDateTime(data.map.long['@value']);
        info.push(obj);
    }
    return info;
}

var result = new Array();
//源文件路径
var source = $source;
var db = source[0];
//var db = "D:\\temp\\data\\data\\com.qihoo.appstore\\shared_prefs\\last_know_location.xml";
result = getPosition(db);
var res = JSON.stringify(result);
res;
