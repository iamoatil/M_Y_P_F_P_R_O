﻿/*[config]
<plugin name="航旅纵横,4" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/Umetrip.png" app="com.umetrip.android.msky.app" version="4.2.0" description="航旅纵横" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.umetrip.android.msky.app#F</value>
</source>

<data type="RootNode" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="AppName" type="string" width="120" format=""></item>
    <item name="版本" code="Version" type="string" width="120" format=""></item>
</data>
<data type="List" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账户列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="登录名" code="UserName" type="string" width="120" format=""></item>
    <item name="登录时间" code="LoginTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="详细信息" code="ContDate" type="string" width="120" format=""></item>
    <item name="登录状态" code="IsActive" type="string" width="120" format=""></item>
</data>
<data type="UmeActivity" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="航班id" code="PId" type="string" width="120" format=""></item>
    <item name="航班日期" code="Pflydate" type="string" width="120" format=""></item>
    <item name="航班出发时间" code="Pflybegdate" type="string" width="120" format=""></item>
    <item name="航班到达时间" code="Pflyenddate" type="string" width="120" format=""></item>
    <item name="航程信息" code="ContDate" type="string" width="120" format=""></item>
    <item name="状态" code="StatInfo" type="string" width="120" format=""></item>
</data>
<data type="SelectHistory" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="查询航程记录" code="FightCity" type="string" width="120" format=""></item>
    <item name="姓名" code="Name" type="string" width="" format="120"></item>
    <item name="手机号" code="PhoneNumber" type="string" width="120" format=""></item>
    <item name="航程次数" code="TotalFlyCount" type="string" width="120" format=""></item>
    <item name="航程总时间" code="TotalFlyTime" type="string" width="120" format=""></item>
    <item name="航程总距离" code="TotalMileage" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义RootNode数据结构
function RootNode() {
    this.AppName = "";
    this.Version = "";
    this.DataState = "Normal";
}

function List(){
    this.List = "";
    this.DataState = "Normal";
}
//定义UserInfo数据结构
function UserInfo() {
    this.DataState = "Normal";
    this.UserName = "";
    this.LoginTime = null;
    this.ContDate = "";
    this.IsActive = "";
}
//定义UmeActivity数据结构
function UmeActivity(){
    this.DataState = "Normal";
    this.PId = "";
    this.Pflydate = "";
    this.Pflybegdate = "";
    this.Pflyenddate = "";
    this.ContDate = "";
    this.StatInfo = "";
}
//定义SelectHistory数据结构
function SelectHistory(){
    this.DataState = "Normal";
    this.FightCity = "";
    this.Name = null;
    this.PhoneNumber = "";
    this.TotalFlyCount = "";
    this.TotalFlyTime = "";
    this.TotalMileage = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path1 = source[0]+"\\databases\\activitydb4.db";
var path2 = source[0]+"\\databases\\msky6.db";
var upath = source[0]+"\\shared_prefs\\mqc_private.xml";
var charactor1 = "chalib\\Android_Umetrip_V4.2.0\\activitydb4.db.charactor";
var charactor2 = "chalib\\Android_Umetrip_V4.2.0\\msky6.db.charactor";
//测试数据
//var path1 = "C:\\XLYSFTasks\\任务-2016-12-26-15-47-22\\source\\data\\data\\com.umetrip.android.msky.app\\databases\\activitydb4.db";
//var path2 = "C:\\XLYSFTasks\\任务-2016-12-26-15-47-22\\source\\data\\data\\com.umetrip.android.msky.app\\databases\\msky6.db";
//var upath = "C:\\XLYSFTasks\\任务-2016-12-26-15-47-22\\source\\data\\data\\com.umetrip.android.msky.app\\shared_prefs\\mqc_private.xml";
//var charactor1 = "F:\21-Build冯火军2号\21-Build\chalib\Android_Umetrip_V4.2.0\\activitydb4.db.charactor";
//var charactor2 = "F:\21-Build冯火军2号\21-Build\chalib\Android_Umetrip_V4.2.0\\msky6.db.charactor";

//恢复数据库中删除的数据
var dpath1 = XLY.Sqlite.DataRecovery(path1,charactor1,"UME_ACTIVITY");
var dpath2 = XLY.Sqlite.DataRecovery(path2,charactor2,"mskyuserinfo");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "航旅纵横";
    root.Type = "RootNode";
    root.Items.push(getRoot(root,dpath1,dpath2,upath));
    result.push(root);
}
//获取APP信息
function getRoot(root,path1,path2,path3){
    var robj = new RootNode();
    robj.AppName = "航旅纵横";
    robj.Version = "4.2.0";
    
    var usernode = new TreeNode();
    usernode.Text = "账户信息";
    usernode.Type = "List";
    var data = eval('('+ XLY.Sqlite.Find(path2,"select * from mskyuserinfo") +')');
    if(data!=""&&data!= null){
        for(var i in data){
            var unode = new TreeNode();
            unode.Text = data[i].username;
            unode.Type = "UserInfo";
            unode.Items.push(getUserInfo(unode,path2,data[i].username));
            usernode.TreeNodes.push(unode);
            usernode.Items.push(getUserList(data[i].username));
        }
    }
    var umenode = new TreeNode();
    umenode.Text = "航程列表";
    umenode.Type = "UmeActivity";
    umenode.Items = getUmeActivity(path1);
    
    var selnode = new TreeNode();
    selnode.Text = "查询及航班记录";
    selnode.Type = "SelectHistory";
    selnode.Items.push(getSelectHistory(path3));
    
    root.TreeNodes.push(usernode);
    root.TreeNodes.push(umenode);
    root.TreeNodes.push(selnode);
    return robj;
}

//获取账户节点信息
function getUserList(data){
    var obj = new List();
    obj.List = data;
    return obj;
}
//获取用户信息
function getUserInfo(root,path2,user){
    if(XLY.File.IsValid(path2)){
        var data = eval('('+ XLY.Sqlite.Find(path2,"select * from mskyuserinfo where username = '"+user+"'") +')');
        if(data!=""&&data!= null){
            var uobj = new UserInfo();
            uobj.DataState = XLY.Convert.ToDataState(data[0].XLY_DataState);
            uobj.UserName = data[0].username;
            uobj.LoginTime = XLY.Convert.LinuxToDateTime(data[0].logintime);
            var syncinfo = XLY.Blob.ToBytes(data[0].cont_data,"base64");
            var usdata = userContData(syncinfo,syncinfo.length,652);
            for(var i in usdata){
                if(i==0){
                    uobj.ContDate+= "电话："+usdata[i]+"\r\n";
                }
                if(i==1){
                    uobj.ContDate+= "用户名："+usdata[i]+"\r\n";
                }
                if(i==2){
                    uobj.ContDate+= "状态(hello表示登录)："+usdata[i]+"\r\n"; 
                }
                if(i==3){
                    uobj.ContDate+= "姓名："+usdata[i]+"\r\n";
                }
                if(i==4){
                    uobj.ContDate+= usdata[i]+"\r\n";
                }     
            }
            if(data[0].is_active==1){
                uobj.IsActive = "登录";
            }
            else
            {
                uobj.IsActive = "未登录";
            }
            return uobj;
        }
    }
}
//获取航程列表信息
function getUmeActivity(path){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var umedata = eval('('+ XLY.Sqlite.Find(path,"select * from UME_ACTIVITY") +')');
        if(umedata!=""&&umedata!=null){
            for(var i in umedata){
                var umeobj = new UmeActivity();
                umeobj.DataState = XLY.Convert.ToDataState(umedata[i].XLY_DataStae);
                umeobj.PId = umedata[i].pid;
                umeobj.Pflydate = umedata[i].pflydate;
                umeobj.Pflybegdate = umedata[i].pflybegtime;
                umeobj.Pflyenddate = umedata[i].pflyendtime;
                umeobj.StatInfo = umedata[i].statInfo;
                var syncinfo = XLY.Blob.ToBytes(umedata[i].cont_data,"base64");
                var usdata = userContData(syncinfo,syncinfo.length,1357);
                for(var i in usdata){
                    if(usdata.length>13){
                        if(i==0){
                            umeobj.ContDate+= "出发机场："+usdata[i]+"\r\n";
                        }
                        if(i==3){
                            umeobj.ContDate+= "目标机场："+usdata[i]+"\r\n";
                        }
                        if(i==4){
                            umeobj.ContDate+= "出发航站楼："+usdata[i]+"\r\n"; 
                        }
                        if(i==5){
                            umeobj.ContDate+= "出发时间："+usdata[i]+"\r\n";
                        }
                        if(i==6){
                            umeobj.ContDate+= "出发日期："+usdata[i]+"\r\n";
                        } 
                        if(i==7){
                            umeobj.ContDate+= "抵达航站楼："+usdata[i]+"\r\n";
                        }   
                        if(i==8){
                            umeobj.ContDate+= "抵达时间："+usdata[i]+"\r\n";
                        }
                        if(i==9){
                            umeobj.ContDate+= "航空公司："+usdata[i]+"\r\n";
                        }
                        if(i==10){
                            umeobj.ContDate+= "航班："+usdata[i]+"\r\n";
                        } 
                        if(i==13){
                            umeobj.ContDate+= "使用状态："+usdata[i]+"\r\n";
                        } 
                    } 
                }
                arr.push(umeobj);
            }
        }
        return arr;
    }
}
//获取查询及航程历史记录
function getSelectHistory(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.File.ReadXML(path) +')');
        var hisdata = data.map.string;
        var hisobj = new SelectHistory();
        for(var i in hisdata){
            if(hisdata[i]["@name"]=="flight_city"){
                hisobj.FightCity = hisdata[i]["#text"];
            }
            if(hisdata[i]["@name"]=="logined_name"){
                hisobj.Name=hisdata[i]["#text"];
            }
            if(hisdata[i]["@name"]=="logined_phonenumber"){
                hisobj.PhoneNumber=hisdata[i]["#text"];
            }
            if(hisdata[i]["@name"]=="TotalFlyCount"){
                hisobj.TotalFlyCount=hisdata[i]["#text"];
            }
            if(hisdata[i]["@name"]=="TotalFlyTime"){
                hisobj.TotalFlyTime=hisdata[i]["#text"];
            }
            if(hisdata[i]["@name"]=="TotalMileage"){
                hisobj.TotalMileage=hisdata[i]["#text"];
            }
        }
        return hisobj;
    }
}
//解析用户信息中2进制
function userContData(data,len,pos){
    try
    {
        if(pos>=len){
            return ;
        }
        //log(len);
        var info = new Array();
        var magicByte = [0x74,0x00];
        while(pos<len){
            var off = XLY.Blob.FindBytes(data, pos, magicByte);
            var conlen = XLY.Blob.GetBytes(data,off+1 ,2);
            conlen = XLY.Bit.ToInt(conlen,true);
            pos = off+3;
            var con = XLY.Blob.GetBytes(data,pos,conlen);
            info.push(XLY.Blob.ToString(con));
            pos += conlen;
        }
        return info;
    }
    catch(err)
    {
        return err;
    }
}
//解析航程信息中2进制
function umeContData(info){
    //var data = XLY.Blob.GetFileHandle();
    return info;
}
