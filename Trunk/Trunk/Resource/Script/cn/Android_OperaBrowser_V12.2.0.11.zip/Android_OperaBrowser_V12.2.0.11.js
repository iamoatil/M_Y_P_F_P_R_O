﻿/*[config]
<plugin name="Opera浏览器,6" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/OperaBrowser.png" app="com.oupeng.mini.android" version="12.2.0.11" description="欧朋浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.oupeng.mini.android/databases/#F</value>
    <value>/data/data/com.oupeng.mini.android/files/#F</value>
    <value>/data/data/com.oupeng.mini.android/app_webview/Cookies</value>
    <value>/data/data/com.oupeng.mini.android/shared_prefs/user_settings.xml</value>
    <value>/data/data/com.oupeng.mini.android/app_opera/#F</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="200" format = "" ></item>
    <item name="用户昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="头像链接地址" code="UserHeadUrl" type="url" width="200" format=""></item>
    <item name="首次登录时间" code="FirstLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后登录时间" code="LastLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="在线时间" code="TotalUpTime" type="string" width="200" format = "" ></item>
    <item name="退出是否删除数据" code="ExitClearHistory" type="string" width="100" format="" ></item>
</data>
<data type="History" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="300" format = ""></item>
    <item name="历史浏览地址" code="Url" type="url" width="200" format = ""></item>
    <item name="时间" code="Time" type="string" width="300" format = ""></item>
</data>
<data type="Bookmark" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="书签id" code="UUID" type="string" width="100" format="" ></item>
    <item name="主题" code="Title" type="string" width="300" format = ""></item>
    <item name="网址" code="Url" type="url" width="500" format=""></item>
    <item name="创建时间" code="Created" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Download" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="下载链接" code="Url" type="url" width="400" format=""></item>
    <item name="存储路径" code="SavePath" type="string" width="200" format = ""></item>
    <item name="文件类型" code="Mimetype" type="string" width="100" format = ""></item>
    <item name="开始时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="结束时间" code="EndTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后修改时间" code="LastModTime"  type="string" width="150" format=""></item>
    <item name="总大小(byte)" code="TotalBytes" type="string" width="100" format=""></item>
    <item name="IsPaused" code="IsPaused" type="string" width="100" format=""></item>
</data>
<data type="Cookies" contract="DataState" datefilter="LastTime">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="键名" code="Name" type="string" width="200" format=""></item>
    <item name="热键" code="Host_Key" type="string" width="160" format=""></item>
    <item name="键值" code="CookieValue" type="string" width="400" format=""></item>
    <item name="创建时间" code="CreateTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="过期时间" code="ExpireTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后认证时间" code="LastTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="存放路径" code="Path" type="string" width="200" format = ""></item>
</data>
<data type="SearchWords" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="搜索关键字" code="SearchWord" type="string" width="200" format = ""></item>
</data>
<data type="SavePage" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="200" format = ""></item>
    <item name="id" code="UUID" type="string" width="100" format = "" ></item>
    <item name="网页链接" code="Url" type="url" width="200" format = ""></item>
    <item name="创建时间" code="CreateTime" type="datetime" order="desc" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="网页保存路径" code="FileName" type="string" width="100" format = "" ></item>
    <item name="网页大小" code="FileSize" type="string" width="100" format = "" ></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.UserNickName = "";
    this.LastLanchTime = null;
    this.FirstLanchTime = null;
    this.TotalUpTime = "";
    this.ExitClearHistory = "";
    this.UserHeadUrl = "";
}
//定义History数据结构
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
//定义Bookmark数据结构
function Bookmark(){
    this.DataState = "Normal";
    this.UUID = "";
    this.Title = "";
    this.Url = "";
    this.Created = null;
}
//定义Download数据结构
function Download(){
    this.DataState = "Normal";
    this.Url = "";
    this.SavePath = "";
    this.Mimetype = "";
    this.StartTime = null;
    this.EndTime = null;
    this.LastModTime = "";
    this.TotalBytes = "";
    this.IsPaused = "";
}
//定义Cookies数据结构
function Cookies(){
    this.DataState = "Normal";
    this.Name = "";
    this.Host_Key = "";
    this.CookieValue = "";
    this.CreateTime = null;
    this.ExpireTime = null;
    this.LastTime = null;
    this.Path = "";
}
//定义SearchWords数据结构
function SearchWords(){
    this.DataState = "Normal";
    this.SearchWord = "";
}
//定义SavePage数据结构
function SavePage(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.CreateTime = null;
    this.UUID = "";
    this.FileName = "";
    this.FileSize = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var bookmarkPath1 = source[0]+"\\bookmark.db";
var savepagePath1 = source[0]+"\\savedpage.db";
var searchwordPath = source[1]+"\\ds\\4\\search";
var historyPath = source[1]+"\\ds\\4\\all";
var cookiesPath1 = source[2];
var userPath = source[3];
var downloadPath = source[4]+"\\webview_downloads";

var charactor1 = "\\chalib\\Android_OperaBrowser_V12.2.0.11\\bookmark.db.charactor";
var charactor2 = "\\chalib\\Android_OperaBrowser_V12.2.0.11\\savedpage.db.charactor";
var charactor3 = "\\chalib\\Android_OperaBrowser_V12.2.0.11\\Cookies.charactor";

var bookmarkPath = XLY.Sqlite.DataRecovery(bookmarkPath1,charactor1,"bookmark");
var savepagePath = XLY.Sqlite.DataRecovery(savepagePath1,charactor2,"savedpage");
var cookiesPath = XLY.Sqlite.DataRecovery(cookiesPath1,charactor3,"cookies");

//测试数据
//var userPath = "F:\com.oupeng.mini.android\\shared_prefs\\user_settings.xml";
//var bookmarkPath = "F:\\com.oupeng.mini.android\\databases\\bookmark.db";
//var savepagePath = "F:\\com.oupeng.mini.android\\databases\\savedpage.db";
//var downloadPath = "F:\\com.oupeng.mini.android\\app_opera\\webview_downloads";
//var searchwordPath = "F:\\com.oupeng.mini.android\\files\\ds\\4\\search";
//var historyPath = "F:\\com.oupeng.mini.android\\files\\ds\\4\\all";
//var cookiesPath = "F:\\com.oupeng.mini.android\\app_webview\\Cookies";
//定义特征库文件
//var charactor = "chalib\\Android_OperaBrowser_V20.0.1396\\favorites.db.charactor";

//恢复数据库中删除的数据
//var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "欧朋浏览器";
    news.Type = "News";
    news.Items = getNews();

    var userNode = new TreeNode();
    userNode.Text = "账户信息";
    userNode.Type = "UserInfo";
    userNode.Items = getUserInfo(userPath);
    
    var bookmarkNode = new TreeNode();
    bookmarkNode.Text = "书签";
    bookmarkNode.Type = "Bookmark";
    getBookMarkNode(bookmarkPath,bookmarkNode);
    
    var searchwordNode = new TreeNode();
    searchwordNode.Text = "搜索关键字";
    searchwordNode.Type = "SearchWords";
    searchwordNode.Items = getSearchWord(searchwordPath);
    
    var savepageNode = new TreeNode();
    savepageNode.Text = "网页保存";
    savepageNode.Type = "SavePage";
    savepageNode.Items = getSavePage(savepagePath);
    
    var downloadNode = new TreeNode();
    downloadNode.Text = "下载";
    downloadNode.Type = "Download";
    downloadNode.Items = getDownload(downloadPath);
    
    var cookiesNode = new TreeNode();
    cookiesNode.Text = "Cookies";
    cookiesNode.Type = "Cookies";
    cookiesNode.Items = getCookies(cookiesPath);
    
    var historyNode = new TreeNode();
    historyNode.Text = "历史记录";
    historyNode.Type = "History";
    historyNode.Items = getHistory(historyPath);

    news.TreeNodes.push(userNode);
    news.TreeNodes.push(bookmarkNode);
    news.TreeNodes.push(searchwordNode);
    news.TreeNodes.push(savepageNode);
    news.TreeNodes.push(cookiesNode);
    news.TreeNodes.push(downloadNode);
    news.TreeNodes.push(historyNode);
    result.push(news);
}

//获取数据库
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}

//获取功能列表
function getNews(){
    var list = new Array();
    var data = ["账号信息","书签","搜索关键字","网页保存","Cookies","下载","历史记录"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}

//获取账户信息
function getUserInfo(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var obj = new UserInfo();
        var userXml = eval('(' + XLY.File.ReadXML(path) + ')');
        var usernamedata = userXml.map.string;
        var timedata = userXml.map.long;
        var iscleardata = userXml.map.int;
        for(var i in usernamedata){
            if(usernamedata[i]["@name"]=="oupeng_user_nick_name"){
                obj.UserNickName = usernamedata[i]["#text"];
            }
            if(usernamedata[i]["@name"]=="oupeng_user_name"){
                obj.UserName = usernamedata[i]["#text"];
            }
            if(usernamedata[i]["@name"]=="oupeng_user_head_portrait_url"){
                obj.UserHeadUrl = usernamedata[i]["#text"];
            }
            if(usernamedata[i]["@name"]=="first_launch_time"){
                obj.FirstLanchTime = XLY.Convert.LinuxToDateTime(usernamedata[i]["#text"]);
            }
        }
        for(var i in timedata){
            if(timedata[i]["@name"]=="total_up_time"){
                obj.TotalUpTime = timedata[i]["@value"]+"秒";
            }
            if(timedata[i]["@name"]=="LAST_LAUNCH_TIME"){
                obj.LastLanchTime = XLY.Convert.LinuxToDateTime(timedata[i]["@value"]);
            }
        }
        for(var i in iscleardata){
            if(iscleardata[i]["@name"]=="exit_clear_history"){
                if(iscleardata[i]["@value"]=="0"){
                    obj.ExitClearHistory = "否";
                }
                else
                {
                    obj.ExitClearHistory = "是";
                }
            }
        }
        list.push(obj);
        return list;
    }
}

//获取书签文件夹
function getBookMarkNode(path,root){
    if(XLY.File.IsValid(path)){
        var bookmarkstring = "select * from bookmark";
        var bookmarkdata = ExecSql(path,bookmarkstring);
        
        var oupengwenjianjia1 = new TreeNode();
        oupengwenjianjia1.Text = "根目录书签";
        oupengwenjianjia1.Type = "Bookmark";
        oupengwenjianjia1.Items=getBookMark(path,'-1')
        root.TreeNodes.push(oupengwenjianjia1);
                
        //for(var i in bookmarkdata){
        //    if(bookmarkdata[i].isfolder=="1" &&bookmarkdata[i].parent=="-1"){
        //        var oupengwenjianjia = new TreeNode();
        //        oupengwenjianjia.Text = bookmarkdata[i].title;
        //        oupengwenjianjia.Type = "Bookmark";
        //        root.TreeNodes.push(oupengwenjianjia);
        //        log(oupengwenjianjia);
        //        oupengwenjianjia.Items=getBookMark(path,bookmarkdata[i].xly_id);
        //    }
        //}
        for(var i in bookmarkdata){
            if(bookmarkdata[i].isfolder=="1" &&bookmarkdata[i].parent=="-1"){
                if(bookmarkdata[i].title=="欧朋服务"){
                    if(bookmarkdata[i].prev_id=='-1'){
                        var oupengwenjianjia = new TreeNode();
                        oupengwenjianjia.Text = bookmarkdata[i].title;
                        oupengwenjianjia.Type = "Bookmark";
                        root.TreeNodes.push(oupengwenjianjia);
                        oupengwenjianjia.Items=getBookMark(path,bookmarkdata[i].xly_id);
                    }
                }
                else
                {
                    var oupengwenjianjia = new TreeNode();
                    oupengwenjianjia.Text = bookmarkdata[i].title;
                    oupengwenjianjia.Type = "Bookmark";
                    root.TreeNodes.push(oupengwenjianjia);
                    oupengwenjianjia.Items=getBookMark(path,bookmarkdata[i].xly_id);
                }
            }
        }
        return;
    }
}

//获取书签信息
function getBookMark(path,id){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var bookmarkstring = "select * from bookmark";
        var bookmarkdata = ExecSql(path,bookmarkstring);
        for(var i in bookmarkdata){
            if(bookmarkdata[i].parent==id &&bookmarkdata[i].isfolder=='0'){
                var obj = new Bookmark();
                obj.DataState = XLY.Convert.ToDataState(bookmarkdata[i].XLY_DataType);
                obj.UUID = bookmarkdata[i].uuid;
                obj.Title = bookmarkdata[i].title;
                obj.Url = bookmarkdata[i].url;
                obj.Created = XLY.Convert.LinuxToDateTime(bookmarkdata[i].time);
                list.push(obj);
            }
        }
        return list;
    }
}
//获取搜索关键字信息
function getSearchWord(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        //var data = (XLY.File.ReadFile(path,"UTF-8")).substr(3,(XLY.File.ReadFile(path,"UTF-8")).length).split(" ").toString();
        var data = analysisSearchInfo(path);
        if(data !=null&&data !=""){
            for(var i in data){
                var obj = new SearchWords();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.SearchWord = data[i].content;
                list.push(obj);
            }
        }
        return list;
    }
}
//获取SavePage信息
function getSavePage(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var savepagestring = "select * from savedpage";
        var savepagedata = ExecSql(path,savepagestring);
        for(var i in savepagedata){
            var obj = new SavePage();
            obj.DataState = XLY.Convert.ToDataState(savepagedata[i].XLY_DataType);
            obj.Title = savepagedata[i].title;
            obj.Url = savepagedata[i].url;
            obj.CreateTime = XLY.Convert.LinuxToDateTime(savepagedata[i].time);
            obj.UUID = savepagedata[i].uuid;
            obj.FileName = savepagedata[i].filename;
            obj.FileSize = savepagedata[i].filesize;
            list.push(obj);
        }
        return list;
    }
}
//获取Download信息
function getDownload(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var data = eval('('+XLY.File.ReadFile(path)+')').webview_downloads;
        for(var i in data){
            var obj = new Download();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.Url = data[i].url;
            obj.SavePath = data[i].path;
            obj.Mimetype = data[i].mimetype;
            obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].start);
            obj.EndTime = XLY.Convert.LinuxToDateTime(data[i].end);
            obj.LastModTime = data[i].lastModified;
            obj.TotalBytes = data[i].total;
            obj.IsPaused = data[i].paused;
            list.push(obj);
        }
        return list;
    }
}
//获取cookies信息
function getCookies(path){
    if(XLY.File.IsValid(path)){
        var list = new Array(); 
        var cookiesdatastring = "select name,host_key,value,creation_utc,expires_utc,last_access_utc,path from cookies";
        var cookiesdata = ExecSql(path,cookiesdatastring);
        for(var i in cookiesdata){
            var obj = new Cookies();
            obj.Name = cookiesdata[i].name;
            obj.Host_Key = cookiesdata[i].host_key;
            obj.CookieValue = cookiesdata[i].value;
            obj.CreateTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].creation_utc);
            obj.ExpireTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].expires_utc)
            obj.LastTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].last_access_utc);
            obj.Path = cookiesdata[i].path;
            list.push(obj);
        }
        return list;
    }
}
//获取历史记录信息
function getHistory(path){
    var list = new Array();
    var data = analysisHistoryInfo(path);
    if(data !=null &&data!=""){
        for(var i in data){
            var obj = new History();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.Url = data[i].url;
            obj.Title = data[i].title;
            obj.Time = data[i].time;
            list.push(obj);
        }
    }
    return list;
}

//
function analysisHistoryInfo(path){
    try
    {
        var handle = XLY.Blob.GetFileHandle(path);
        var fsize = XLY.Blob.GetFileSizeFromHandle(handle);
        var offset = 3;
        var infoList = new Array();
        while(offset<fsize){
            var con = {};
            
            
            //读取URL信息
            var ulen = XLY.Blob.GetBytesFromHandle(handle,offset ,4);
            offset += 4;
            var usize = XLY.Bit.ToInt(ulen,true);
            var udata = XLY.Blob.GetBytesFromHandle(handle,offset ,usize);
            con.url = XLY.Blob.ToString(udata);
            offset += usize;
            
            

            //读取标题信息
            var dlen = XLY.Blob.GetBytesFromHandle(handle,offset ,2);
            //log(dlen);
            offset += 2;
            var dsize = XLY.Bit.ToInt(dlen,true);
            var ddata = XLY.Blob.GetBytesFromHandle(handle,offset ,dsize);
            con.title = XLY.Blob.ToString(ddata);
            offset += dsize;
            
            
            //读取时间信息
            var tdata = XLY.Blob.GetBytesFromHandle(handle,offset ,4);
            var tvalue = XLY.Bit.ToInt(tdata,true);
            con.time = XLY.Convert.LinuxToDateTime(tvalue);
            offset += 4;
            offset += 12;
            
            infoList.push(con);
        }
        
        XLY.Blob.CloseFileHandle(handle);
        return infoList;
    }
    catch(err)
    {
        XLY.Blob.CloseFileHandle(handle);
    }
}
//
function analysisSearchInfo(path){
    try
    {
        var handle = XLY.Blob.GetFileHandle(path);
        var fsize = XLY.Blob.GetFileSizeFromHandle(handle);
        var offset = 2;
        var infoList = new Array();
        while(offset<fsize){
            var con = {};
            
            //读取URL信息
            var clen = XLY.Blob.GetBytesFromHandle(handle,offset ,2);
            offset += 2;
            var csize = XLY.Bit.ToInt(clen,true);
            var cdata = XLY.Blob.GetBytesFromHandle(handle,offset ,csize);
            con.content = XLY.Blob.ToString(cdata);
            offset += csize;
            
            
            infoList.push(con);
        }
        
        XLY.Blob.CloseFileHandle(handle);
        return infoList;
    }
    catch(err)
    {
        XLY.Blob.CloseFileHandle(handle);
    }
}
