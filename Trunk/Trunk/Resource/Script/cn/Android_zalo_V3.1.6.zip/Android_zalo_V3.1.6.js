﻿/*[config]
<plugin name="Zalo,14" group="社交聊天,2" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/Zalo.png" app="com.zing.zalo" version="3.1.6" description="Zalo" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.zing.zalo/databases#F</value>
</source>
<data type = "User">
<item name="ID" code="userID" type="int" width = "80" ></item>
<item name="昵称" code="nick" type="string" width="100" format = ""></item>
<item name="电话" code="phone" type = "string" width="100"></item>
<item name="头像" code="avt" type = "string" width = "200"></item>
<item name="个新签名" code="Sign" type = "string" width = "200"></item>
<item name="性别" code="Gender" type = "string" width="200"></item>
<item name="最后一次登录时间" code="lastDate" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>
<data type = "Info">
<item name="类别" code="name" type="string" width = "80" ></item>
<item name="数量" code="count" type="int" width="100" format = ""></item>
</data>
<data type = "Contacts">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "80" ></item>
<item name="昵称" code="Name" type="int" width="100" format = ""></item>
<item name="号码" code="Num" type="int" width="100" format = ""></item>
</data>
<data type = "Group">
<item name="ID" code="userID" type="int" width = "80" ></item>
<item name="名称" code="name" type="string" width="100" format = ""></item>
<item name="成员" code="member" type = "string" width = "100"></item>
<item name="创建者ID" code="creatorId" type = "string" width="100"></item>
<item name="头像" code="avt" type = "string" width="200"></item>>
</data>
<data type = "Message" detailfield = "body" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="消息发送者" code="sender" type="string" width="150" format = ""></item>
<item name="消息接收者" code="receiver" type="string" width="150" format = ""></item>
<item name="消息内容" code="body" type="string" width="700" format = ""></item>
<item name="消息类型" code="type" type="string" width="80" format = "" order="desc"></item>
<item name="发送时间" code="time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>
<data type = "TimeLine" detailfield = "body" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者ID" code="ID" type="string" width="150" format = ""></item>
<item name="发送者昵称" code="Nick" type="string" width="150" format = ""></item>
<item name="内容" code="Content" type="string" width="150" format = ""></item>
<item name="位置" code="Location" type="string" width="150" format = "" order="desc"></item>
<item name="发送时间" code="time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>
</plugin>
[config]*/
//********************************************* 定义数据结构*********************************************
//定义User
function User() {
    this.userID = 0;    
    this.nick = ""; 
    this.phone = "";  
    this.avt = "";
    this.Sign = "";
    this.Gender = "";  
    this.lastDate = null;
}
function Info() {
    this.name = ""; //类别
    this.count = 0; //数量
}
//定义Group
function Group() {
    this.userID = 0;    //ID
    this.name = ""; //名称
    this.member = "";   //成员
    this.creatorId = "";    //创建者ID
    this.avt = "";  //头像
}
//定义Message
function Message() {
    this.DataState = "Normal";  //数据状态
    this.sender = "";   //消息发送者
    this.receiver = ""; //消息接收者
    this.body = ""; //消息内容
    this.type = ""; //消息类型
    this.time = null;   //发送时间
}
function TimeLine() {
    this.DataState = "Normal";
    this.ID = ""; 
    this.Nick = "";
    this.Content = "";
    this.File = ""; 
    this.Location = "";
    this.time = "";
}
function Contacts() {
    this.DataState = "Normal";
    this.ID = ""; 
    this.Name = "";
    this.Num = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path = source[0];
var path2 = source[0] + "\\phone_contacts_v2";
//测试数据
//var path = "D:\\com.zing.zalo\\databases";
//var path2 = "D:\\com.zing.zalo\\databases\\phone_contacts_v2";


//定义特征库文件
var charactor = "chalib\\Android_zalo_V3.1.6\\zalo.charactor";
var charactor1 = "chalib\\Android_zalo_V3.1.6\\phone_contacts_v2.charactor";
//var charactor = "D:\\temp\\data\\data\\com.zing.zalo\\databases\\zalo.charactor";
//var charactor1 = "D:\\temp\\data\\data\\com.zing.zalo\\databases\\phone_contacts_v2.charactor";

//恢复数据库中删除的数据
var path1 = XLY.Sqlite.DataRecovery(path2, charactor1, "phone_contacts_v1");

var result = new Array();

result.push(bindTree(path));
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
//创建特定的树形结构
function creatTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

//主体结构
function bindTree(path){
    var root = creatTreeNode("Zalo","User")
    var pPath = path+"\\zalo";
    //var pPath = XLY.Sqlite.DataRecovery(pPath1, charactor, "chat_content,contact_profile_5,user_feed,group_info_v6,contact_profile_zalo,follow_list_1");
    var userid = eval('('+ XLY.Sqlite.Find(pPath,"select distinct currentUserUid from chat_content") +')');
    if(userid.length>0){
        for(var i in userid){
            var userinfo = getUserInfo(userid[i].currentUserUid,pPath);
            var user = creatTreeNode(userinfo.nick,"Info");
            
            //创建好友和群组树形节点并装入信息
            var friend = creatTreeNode("好友列表","User");
            var group = creatTreeNode("群组列表","Group");
            var follow = creatTreeNode("关注","User");
            var timeline = creatTreeNode("TimeLine","TimeLine");
            var finfo = getFriendInfo(pPath,userid[i].currentUserUid);
            var ginfo = getGroupInfo(pPath,userid[i].currentUserUid);
            var followinfo = getFollowInfo(pPath,userid[i].currentUserUid);
            var timelineinfo = getTimeLine(pPath,userid[i].currentUserUid);
            friend.Items = finfo;
            group.Items = ginfo;
            follow.Items = followinfo;
            timeline.Items = timelineinfo;
            buildFriendMessageNode(pPath,finfo,friend,userid[i].currentUserUid);
            buildGroupMessageNode(pPath,ginfo,group,userid[i].currentUserUid);
            buildFollowMessageNode(pPath,followinfo,follow,userid[i].currentUserUid);
            
            var contacts = creatTreeNode("联系人","Contacts");
            contacts.Items = getContacts(path1);
                       
            //装入User节点信息
            user.Items = UserNodeInfo(finfo,ginfo,friend);
            
            
            //装入好友和群组列表
            user.TreeNodes.push(friend);
            user.TreeNodes.push(group);
            user.TreeNodes.push(follow);
            user.TreeNodes.push(timeline);
            user.TreeNodes.push(contacts);
                       
            //帐号节点
            root.Items.push(userinfo);
            root.TreeNodes.push(user);
            
        }
    }
    
    return root;
}

//获取登录帐号信息 
function getUserInfo(id,path){
    var data1 = eval('('+ XLY.Sqlite.Find(path,"select * from contact_profile_5 where uid = '"+id+"' ") +')');
    var data2 = eval('('+ XLY.Sqlite.Find(path,"select content from user_feed where cUid = '"+id+"' ") +')');
    var obj = new User();
    if(data1.length>0){
        obj.userID = data1[0].uid;    
        obj.nick = data1[0].dpn;
        obj.phone = data1[0].phone;
        obj.Sign = data1[0].stt;
        obj.Gender = (data1[0].ged == 1) ? "女" : "男";
        obj.avt = data1[0].avt;
        obj.lastDate = XLY.Convert.LinuxToDateTime(data1[0].timestamp);
    }else if(data2.length>0){
        var info = eval('('+ data2[0].content +')');
        obj.userID = info.item.header.uid;
        obj.nick = info.item.header.dpn;
        obj.avt = info.item.header.avt;
        obj.lastDate = XLY.Convert.LinuxToDateTime(info.item.cts);
    }
    return obj;
}

//获取User节点信息
function UserNodeInfo(finfo,ginfo){
    var arr = new Array();
    if(finfo.length>0){
        var obj = new Info();
        obj.name = "好友";
        obj.count = finfo.length;
        arr.push(obj);
    }
    if(ginfo.length>0){
        var obj = new Info();
        obj.name = "群组";
        obj.count = ginfo.length;
        arr.push(obj);
    }
    return arr;
}
 function getContacts(path,uid){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from phone_contacts_v1" ) +')');
    for(var i in data){        
        var obj = new Contacts();
        obj.Name = data[i].name;
        obj.ID = data[i].xly_id;
        obj.Num = data[i].number;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getTimeLine(path,uid){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from user_feed where cUid = '"+uid+"' " ) +')');
    for(var i in data){        
        var obj = new TimeLine();
        obj.ID = data[i].cUid;
        var info = eval('('+ data[i].content +')');
        obj.Nick = info.item.header.dpn;
        obj.Content = info.item.content.caption;
        if( obj.Location = info.item.content.location != null ){
          obj.Location = info.item.content.location.desc; 
        } 
        obj.time = XLY.Convert.LinuxToDateTime(info.item.cts);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//获取群组和好友数量
function getGroupInfo(path,uid){ 
    var data = eval('('+ XLY.Sqlite.Find(path,"select id,name,creatorId,members,avatar from group_info_v6 where currentUserUid = '"+uid+"' ") +')');
    //var data1 = eval('('+ XLY.Sqlite.Find(path,"select * from contact_profile_5") +')');
    //log(data1);
    var arr = new Array();
    if(data.length>0){
        for(var i in data){
            var obj = new Group();
            obj.userID = data[i].id;    //ID
            obj.name = data[i].name; //名称
            obj.member = data[i].members;   //成员
            obj.creatorId = data[i].creatorId;    //创建者ID
            obj.avt = data[i].avatar_new; 
            var meminfo = eval('('+ XLY.Sqlite.Find(path,"select * from contact_profile_5 where uid = '"+data[i].members+"'") +')');
            arr.push(obj);
        }
    }
    return arr;
}

//获取好友信息 
function getFriendInfo(path,uid){
    var data1 = eval('('+ XLY.Sqlite.Find(path,"select uid,dpn,avt,phone,timestamp from contact_profile_zalo" ) +')');
    var data2 = eval('('+ XLY.Sqlite.Find(path,"select distinct ownerId from chat_content where currentUserUid = '"+uid+"' " ) +')');
    var arr = new Array();
    if(data1.length>0){
        for(var i in data1){
            var obj = new User();
            obj.userID = data1[i].uid;    //ID
            obj.nick = data1[i].dpn; //昵称
            obj.phone = data1[i].phone //电话
            obj.avt = data1[i].avt;  //头像
            obj.lastDate = XLY.Convert.LinuxToDateTime(data1[i].timestamp);   //最后一次登录时间
            arr.push(obj);
        }
    }
    else if(data2.length>0)
    {
        var reg = /^(\d)*$/;
        
        for(var index in data2){
            if(reg.test(data2[index].ownerId)){
                var info = getUserInfo(data2[index].ownerId,path);
                if(info.userID==0){
                    info.userID = data2[index].ownerId;
                }
                arr.push(info);
            }
        }
    }
    return arr;
}
function getFollowInfo(path,uid){
    //var data1 = eval('('+ XLY.Sqlite.Find(path,"select uid,dpn,avt,phone,timestamp from contact_profile_zalo" ) +')');
    var data1 = eval('('+ XLY.Sqlite.Find(path,"select *from follow_list_1 where currentUserUid = '"+uid+"' " ) +')');
    var arr = new Array();
    for(var i in data1){
            var obj = new User();
            obj.userID = data1[i].uid;    //ID
            obj.nick = data1[i].dpn; //昵称
            obj.phone = data1[i].phone //电话
            obj.avt = data1[i].avt;  //头像
            obj.lastDate = XLY.Convert.LinuxToDateTime(data1[i].timestamp);   //最后一次登录时间
            arr.push(obj);
        }
    return arr;
}
//创建好友聊天信息
function buildFriendMessageNode(path,finfo,node,uid){
    if(finfo.length>0){
        for(var i in finfo){
            
            var friend = new TreeNode();
            friend.Type="Message"
            if(finfo[i].nick!=""){
                friend.Text=finfo[i].nick;
            }else{
                friend.Text = finfo[i].userID;
            }
            var fmsg = getMessageInfo(path,uid,finfo[i].userID);
            friend.Items = fmsg;
            node.TreeNodes.push(friend)
            
        }
    }
}

//获取消息列表
function getMessageInfo(path,uid,fid){
    var data = eval('('+ XLY.Sqlite.Find(path,"select currentUserUid,message,url,localpath,timestamp,senderUid,senderName,ownerId,type,minigame from chat_content where ownerId='"+fid+"' AND currentUserUid = '"+uid+"' ") +')');
    var arr = new Array();
    if(data.length>0){
        for(var i in data){
            var obj = new Message();
            obj.DataState = "Normal";  //数据状态
            if(data[i].senderName.length>0){
                obj.sender = data[i].senderName+"("+data[i].senderUid+")";   //消息发送者
            }else{
                obj.sender = data[i].senderUid;   //消息发送者
            }
            
            if(data[i].senderUid == data[i].ownerId){
                obj.receiver = uid; //消息接收者
            }
            else
            {
                obj.receiver = fid; //消息接收者
            }
            //log(data[i].type);
            switch(data[i].type){
                case '0': 
                obj.body = data[i].message; //消息内容
                obj.type = "文本"; //消息类型
                break;
                
                case '2':
                if(data[i].localpath.length>0){
                    obj.body = "手绘图案的本地存储地址:"+data[i].localpath; //消息内容
                }else{
                    obj.body = "手绘图案的URL地址:"+data[i].url; //消息内容
                }
                obj.type = "手绘图案"; //消息类型
                break;
                
                case '3':
                if(data[i].localpath.length>0){
                    obj.body = "图片的本地存储地址:"+data[i].localpath; //消息内容
                }else{
                    obj.body = "图片的URL地址:"+data[i].url; //消息内容
                }
                obj.type = "图片"; //消息类型
                break;
                
                case '4':
                if(data[i].localpath.length>0){
                    obj.body = "音频的本地存储地址:"+data[i].localpath; //消息内容
                }else{
                    obj.body = "音频的URL地址:"+data[i].url; //消息内容
                }
                obj.type = "音频"; //消息类型
                break;
                
                case '11': 
                obj.body = data[i].message+";"+data[i].minigame; //消息内容
                obj.type = "文本"; //消息类型
                break;
                
                case '13':
                if(data[i].message=="Outgoing call"){
                    var info = eval('('+ data[i].minigame +')');
                    obj.body = "呼出通话时长："+info.title; //消息内容
                    obj.type = "音频通话"; //消息类型
                }else if(data[i].message=="Incoming call"){
                    var info = eval('('+ data[i].minigame +')');
                    obj.body = "被叫通话时长："+info.title; //消息内容
                    obj.type = "音频通话"; //消息类型
                }else{
                    var info = eval('('+ data[i].minigame +')');
                    obj.body = "昵称:"+info.title+"ID:"+info.params; //消息内容
                    obj.type = "通讯录"; //消息类型
                }
                break;
                
                case '17': 
                obj.body = data[i].message; //消息内容
                obj.type = "新闻"; //消息类型
                break;
                
                case '19':
                var localinfo = eval('('+ data[i].minigame +')');
                obj.body = "地址是:"+localinfo.description+""+localinfo.title; //消息内容
                var reg = /params/;
                //log(localinfo.params);
                if(localinfo.params.length>0){
                    var param = eval('('+ localinfo.params +')');
                    obj.body += ";地址的经度是:"+param.latitude+"地址的纬度是:"+param.longitude; //+=符号不能分开
                }
                obj.type = "地理位置"; //消息类型
                break;
                
                case '22': 
                obj.body = data[i].message; //消息内容
                obj.type = "系统信息"; //消息类型
                break;
                
                default: 
                obj.body = data[i].message; //消息内容
                obj.type = "其他" //消息类型;
                break;
            }
            
            
            obj.time = XLY.Convert.LinuxToDateTime(data[i].timestamp);   //发送时间
            arr.push(obj);
        }
    }
    return arr;
}

//创建群组聊天信息
function buildGroupMessageNode(path,ginfo,node,uid){
    if(ginfo.length>0){
        for(var i in ginfo){
            
            var group = new TreeNode();
            group.Type="Message"
            if(ginfo[i].nick!=""){
                group.Text = ginfo[i].name;
            }else{
                group.Text = ginfo[i].userID;
            }
            gid = "group_"+ginfo[i].userID;
            var gmsg = getMessageInfo(path,uid,gid);
            group.Items = gmsg;
            node.TreeNodes.push(group)
            
        }
    }
}
//创建关注聊天信息
function buildFollowMessageNode(path,followinfo,node,uid){
    if(followinfo.length>0){
        for(var i in follow){
            
            var follow = new TreeNode();
            follow.Type="Message"
            if(ginfo[i].nick!=""){
                follow.Text = ginfo[i].name;
            }else{
                follow.Text = ginfo[i].userID;
            }
            gid = "group_"+ginfo[i].userID;
            var gmsg = getMessageInfo(path,uid,gid);
            group.Items = gmsg;
            node.TreeNodes.push(group)
            
        }
    }
}