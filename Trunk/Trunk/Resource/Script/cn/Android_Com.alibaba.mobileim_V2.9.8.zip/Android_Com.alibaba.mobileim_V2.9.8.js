﻿//descritpion:Test-复杂导航树

/*[config]
<plugin name="淘宝旺信,6" group="社交聊天,2" devicetype="android" pump="usb,Mirror,chip,Raid"  icon="\icons\com.alibaba.mobileim.png" app="com.alibaba.mobileim" version="2.9.8" description="旺信" data="$data,TreeDataSource" >
<source>
<value>/data/data/com.alibaba.mobileim/databases#F</value>
</source>
<data type="Account" detailfield="Signature" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="用户ID" code="Id" type="string" width="120" alignment="left" ></item>
<item name="用户名" code="Name" type="string" width="140" order="desc" ></item>
<item name="旺旺用户名" code="wwName" type="string" width="120" order="desc" alignment="center"></item>
<item name="签名" code="Signature" type="string" width="300" ></item>
<item name="头像" code="Avatar" type="string" width="80" ></item>
<item name="性别" code="Gender" type="string" width="50" ></item>
<item name="电话号码" code="Number" type="string" width="100" alignment="center"></item>
<item name="店铺名称" code="ShopName" type="string" width="100" ></item>
<item name="店铺地址" code="ShopUrl" type="string" width="100" ></item>
<item name="最后更新时间" code="LastUpdate" type="datetime" width="120" ></item>
<item name="最后联系时间" code="LastContact" type="datetime" width="120" ></item>

</data>

<data type="Message" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送用户" code="SenderName" type="string" width="120" ></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="语音时长" code="Duration" type="string" width="40" ></item>
<item name="消息类型" code="MesType" type="string"  width="60" show="true" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="时间" code="Date" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="经度" code="Longitude" type="string" width="90" alignment="center"></item>
<item name="纬度" code="Latitude" type="string" width="90" alignment="center"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

<data type="User" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="编号" code="Id" type="string" width="100" ></item>
<item name="昵称" code="NickName" type="string" width="110" ></item>
<item name="头像" code="Headpath" type="string" width="100" ></item>
<item name="个性签名" code="Desc" type="string" width="180" ></item>
<item name="性别" code="Gender" type="string" width="40" ></item>

<item name="所在地" code="Region" type="string" width="80" ></item>
<item name="类型" code="Type" type="string" width="85" ></item>
<item name="店铺名称" code="ShopName" type="string" width="85" ></item>
<item name="最后更新时间" code="LastUpdate" type="datetime" width="120" alignment="center"></item>
</data>

<data type="Group"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="编号" code="Id" type="string" width="182" ></item>
<item name="名称" code="Name" type="string" width="280" ></item>
</data>

<data type="RoomChats"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="编号" code="Id" type="string" width="100" ></item>
<item name="名称" code="Name" type="string" width="120" ></item>
<item name="成员列表" code="Users" type="string" width="400" ></item>
<item name="创建日期" code="Date" type="string" width="120" alignment="center"></item>
</data>

<data type="Tribe"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="编号" code="Id" type="string" width="100" ></item>
<item name="名称" code="Name" type="string" width="120" ></item>
<item name="公告" code="Bulletin" type="string" width="300" ></item>
<item name="群签名" code="Desc" type="string" width="300" ></item>
<item name="群主" code="Master" type="string" width="100" ></item>
</data>

<data type="Tribe" detailfiled="Desc"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="编号" code="Id" type="string" width="100" ></item>
<item name="名称" code="Name" type="string" width="120" ></item>
<item name="公告" code="Bulletin" type="string" width="300" ></item>
<item name="群签名" code="Desc" type="string" width="300" ></item>
<item name="群主" code="Master" type="string" width="100" ></item>
</data>

<data type="TribeUser"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群昵称" code="Nick" type="string" width="140" ></item>
<item name="用户名" code="UserName" type="string" width="150" ></item>
<item name="角色" code="Role" type="string" width="100" ></item>
</data>

<data type="Conversation"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="编号" code="Id" type="string" width="120" ></item>
<item name="名称" code="Name" type="string" width="120" ></item>
<item name="最近联系内容" code="Content" type="string" width="250" ></item>
<item name="联系时间" code="Date" type="datetime" width="250" alignment="center" order="desc" ></item>
<item name="类型" code="Type" type="string" width="80" ></item>
<item name="用户列表" code="Users" type="string" width="155" ></item>
</data>

</plugin>
[config]*/

// js content
//<item name="消息状态" code="Status" type="string" width="60" ></item>
//定义数据结构

function Account() {
    this.Id = "";
    this.wwName = "";
    this.Name = "";
    this.Signature = "";
    this.Avatar = "";
    this.Gender = "";
    this.Number = "";
    this.ShopName = "";
    this.ShopUrl = "";
    this.LastUpdate = null;
    this.LastContact = null;
    this.DataState = "Normal";
}

function Message() {
    this.Id = ""; //编号
    this.conversationId = ""; //会话编号
    this.sendId = "";
    this.SenderName = "";
    this.SenderImage = "";
    this.ReceiveUser = "";
    this.Content = "";
    this.Duration = "";
    this.Type = "";
    this.MesType = "";
    this.Status = "";
    this.Date = null;
    this.Longitude = "";
    this.Latitude = "";
    this.SendState = "";
    this.DataState = "Normal";
}

function User() {
    this.Id = "";
    this.NickName = "";
    this.Headpath = "";
    this.Desc = "";
    this.Gender = "";
    this.Region = "";
    this.Type = "";
    this.ShopName = "";
    this.LastUpdate = null;
    this.groupid = "";
    this.DataState = "Normal";

}

function Group() {
    this.Id = "";
    this.Name = "";
    this.DataState = "Normal";
}

function RoomChats() {
    this.Id = "";
    this.Name = "";
    this.Users = "";
    this.Date = null;
    this.DataState = "Normal";
}

function Tribe() {
    this.Id = "";
    this.Name = "";
    this.Bulletin = "";
    this.Desc = "";
    this.Master = "";
    this.DataState = "Normal";
}

function TribeUser() {
    this.tribeid = "";
    this.Nick = "";
    this.UserName = "";
    this.Role = "";
    this.DataState = "Normal";
}

function Conversation() {
    this.Id = "";
    this.Name = "";
    this.Date = null;
    this.Content = "";
    this.Type = "";
    this.Users = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.Key = "";
    this.DataState = "Normal";
}

var result = new Array();
var root = new TreeNode();
root.Text = "旺信帐户";
root.Type = "Account";

//源文件的
var source = $source;
var folder = source[0];
//var folder="C:\\XLYSFTasks\\未命名-33\\source\\data\\data\\com.alibaba.mobileim\\databases";
//特征库
var cha1 = "\\chalib\\Andriod_alibaba_V2.9.8\\allaccounts.charactor";
var cha2 = "\\chalib\\Andriod_alibaba_V2.9.8\\cnhhupan.charactor";

//对账户执行数据恢复
var dbf1 = folder + "\\allaccounts";
var ndbf1 = XLY.Sqlite.DataRecovery(dbf1, cha1, "accounts");
//读取帐户

var db1 = eval('(' + XLY.Sqlite.FindByName(ndbf1, "accounts") + ')');
var acnodes = new Array();
for (var i in db1) {
    var row = db1[i];
    var ac = new Account();
    ac.Id = row.user_id;
    ac.wwName = row.ww_account;
    ac.Name = row.user_name;
    ac.Signature = row.signature;
    ac.Avatar = row.avatar;
    ac.Gender = row.gender >= 0 ? (row.gender == 0 ? "女" : "男") : "";
    ac.Number = row.phone;
    ac.ShopName = row.shop_name;
    ac.ShopUrl = XLY.Convert.UrlDecode(row.shop_url);
    ac.LastUpdate = XLY.Convert.LinuxToDateTime(row.last_update_time);
    ac.LastContact = XLY.Convert.LinuxToDateTime(row.latest_contact_timestamp);
    ac.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
    root.Items.push(ac);
    //node
    var acnode = new TreeNode();
    acnode.Text = "帐户:" + ac.Id;
    acnode.key = ac.Id;
    acnode.DataState = ac.DataState;
    acnodes.push(acnode);
}

//读取消息
function FindMessage(file, accountItem) {
    var db = eval('(' + XLY.Sqlite.FindByName(file, "message") + ')');
    var mess = new Array();
    for (var i in db) {
        var row = db[i];
        var mes = new Message();
        mes.Id = row.messageId;
        mes.SendState = (row.sendId == accountItem.Id) ? "Send" : "Receive";
        mes.conversationId = row.conversationId;
        mes.sendId = row.sendId;
        mes.SenderName = row.sendId;
        mes.SenderImage = accountItem.Avatar;
        mes.Content = row.content;
        mes.Duration = row.duration;
        switch (row.mimeType) {
            case -1: mes.MesType = "系统消息"; break;
            case -3: mes.MesType = "系统消息"; break;
            case 0: mes.MesType = "文本/阿里旺旺表情"; break;
            case 1: mes.MesType = "照片"; mes.Type = "Image"; break;
            case 2: mes.MesType = "语音"; mes.Type = "Audio"; break;
            case 4: mes.MesType = "淘公仔表情"; break;
            case 8: mes.MesType = "位置"; break;
            case 16: mes.MesType = "验证信息"; break;
            case 51: mes.MesType = "语音聊天"; break;
            case 52: mes.MesType = "名片"; break;
            default: mes.MesType = "未知"; break;
        }
        var s = row.conversationId;
        //        var a = s.replace(/cnhhupan/, "");
        mes.conversationId = s;

        mes.Date = XLY.Convert.LinuxToDateTime(row.time);
        mes.Longitude = row.longitude;
        mes.Latitude = row.latitude;
        mes.DataState = row.deleted == "0" ? "Normal" : "Deleted";
        mess.push(mes);
    }
    return mess;
}

//所有好友
function FindUsers(file) {
    var db = eval('(' + XLY.Sqlite.FindByName(file, "user") + ')');
    var users = new Array();
    for (var i in db) {
        var row = db[i];
        var user = new User();
        user.Id = row.userId;
        user.NickName = row.nickName;
        user.Headpath = row.headPath;
        user.Desc = row.selfDesc;
        user.Gender = row.sex >= 0 ? (row.sex == 0 ? "女" : "男") : "";
        user.Region = row.region;
        var type = "";
        switch (row.type) {
            case 0: type = "陌生人"; break;
            case 1: type = "好友"; break;
            case 4: type = "系统用户"; break;
            case 5: type = "黑名单"; break;
        }
        var employee = row.isAliEmployee == 0 ? "" : (row.isAliEmployee == 1 ? "阿里员工" : "");
        user.Type = type + " " + employee;
        user.ShopName = row.shopName;
        user.groupid = row.groupId;
        user.LastUpdate = XLY.Convert.LinuxToDateTime(row.lastUpdateProfile);
        user.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        users.push(user);
    }
    return users;
}

//群
function FindGroups(file) {
    var db = eval('(' + XLY.Sqlite.FindByName(file, "wwGroup") + ')');
    var gs = new Array();
    for (var i in db) {
        var row = db[i];
        var g = new Group();
        g.Id = row.groupId;
        g.Name = row.groupName;
        g.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        gs.push(g);
    }
    return gs;
}

//创建群组树节点
function CreateGroupNode(gs, users) {
    var gg = new TreeNode();
    gg.Text = "好友分组";
    gg.Type = "Group";
    gg.Items = gs;
    for (var i in gs) {
        var gn = new TreeNode();
        var g = gs[i];
        gn.Text = g.Name;
        gn.DataState = g.DataState;
        gn.Type = "User";
        for (var j in users) {
            var u = users[j];
            if (u.groupid == g.Id) {
                gn.Items.push(u);
            }
        }
        gg.TreeNodes.push(gn);
    }
    return gg;
}

//讨论组
function CreateRoomChatNode(file) {
    var node = new TreeNode();
    node.Text = "讨论组";
    node.Type = "RoomChats";
    var db = eval('(' + XLY.Sqlite.FindByName(file, "wxRoomChats") + ')');
    for (var i in db) {
        var row = db[i];
        var rc = new RoomChats();
        rc.Id = row.roomId;
        rc.Name = row.roomName;
        rc.Users = row.roomMemberIds;
        rc.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        var t = row.time + 1342177200;
        rc.Date = XLY.Convert.LinuxToDateTime(t);
        node.Items.push(rc);
    }
    return node;
}


//所有群成员
function FindTribeUsers(file) {
    var tribeusers = new Array();
    var db = eval('(' + XLY.Sqlite.FindByName(file, "wwTribeUser") + ')');
    for (var i in db) {
        var row = db[i];
        var tu = new TribeUser();
        tu.tribeid = row.tribe_id;
        tu.Nick = row.user_tribe_nick;
        tu.UserName = row.user_id;
        switch (row.tribe_role) {
            case 2: tu.Role = "群管理员"; break;
            case 4: tu.Role = "群创始人"; break;
            default: tu.Role = "普通成员";
        }
        tu.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        tribeusers.push(tu);
    }
}

//群信息节点
function CreateTribeNode(file, tribeusers) {
    var node = new TreeNode();
    node.Text = "群分组";
    node.Type = "Tribe";
    var tribes = new Array();
    var db = eval('(' + XLY.Sqlite.FindByName(file, "wwTribe") + ')');
    for (var i in db) {
        var row = db[i];
        var tribe = new Tribe();
        tribe.Id = row.tribeid;
        tribe.Name = row.tribeName;
        tribe.Bulletin = row.tribeBulletin;
        tribe.Desc = row.tribeDesc;
        tribe.Master = row.master;
        tribe.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        //群节点
        var tnode = new TreeNode();
        tnode.Text = tribe.Name;
        tnode.DataState = tribe.DataState;
        tnode.Type = "TribeUser";
        //群成员
        for (var j in tribeusers) {
            var u = tribeusers[j];
            if (u.tribeid == tribe.Id) tnode.Items.push(u);
        }
        node.Items.push(tribe);
        node.TreeNodes.push(tnode);
    }
    return node;
}


//联系记录
function CrateConversationNode(file, mess) {
    var node = new TreeNode();
    node.Text = "联系记录";
    node.Type = "Conversation";
    var db = eval('(' + XLY.Sqlite.FindByName(file, "conversation") + ')');
    var cons = new Array();
    for (var i in db) {
        var row = db[i];
        var con = new Conversation();
        con.Id = row.conversationId;
        con.Name = row.conversationName;
        con.Content = row.content;
        con.Users = row.userIds;
        con.Date = XLY.Convert.LinuxToDateTime(row.messageTime);
        con.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        switch (row.type) {
            case 1: con.Type = "好友"; break;
            case 2: con.Type = "讨论组"; break;
            case 3: con.Type = "群"; break;
            case 4: con.Type = "系统用户"; break;
        }
        cons.push(con);
        //node
        var connode = new TreeNode();
        connode.Text = (con.Name != null && con.Name.length > 0) ? con.Name : con.Id;
        connode.Type = "Message";
        connode.DataState = con.DataState;
        node.TreeNodes.push(connode);
        for (var j in mess) {
            var mes = mess[j];
            if (mes.conversationId == con.Id) connode.Items.push(mes);
        }
    }
    node.Items = cons;
    return node;
}


//帐户内所有信息处理
for (var i in acnodes) {
    var ac = acnodes[i];
    var file = folder + "\\" + ac.key;
    var fcs = XLY.File.IsValid(file);
    var fc = new Boolean(fcs);
    if (fc == false)
        continue;
    //对所有信息进行数据恢复出来
    var nfile = XLY.Sqlite.DataRecovery(file, cha2, "user,wwGroup,wxRoomChats,wwTribeUser,wwTribe,conversation");
    //message
    var accountItem = root.Items[i];

    var mess = FindMessage(file, accountItem);
    var mesnode = new TreeNode();
    mesnode.Text = "所有聊天信息";
    mesnode.Type = "Message";
    mesnode.Items = mess;
    ac.TreeNodes.push(mesnode);
    //conversation
    var connode = CrateConversationNode(nfile, mess);
    ac.TreeNodes.push(connode);
    //user
    var users = FindUsers(nfile);
    var unode = new TreeNode();
    unode.Text = "所有好友/联系人";
    unode.Type = "User";
    unode.Items = users;
    ac.TreeNodes.push(unode);
    //group
    var gs = FindGroups(nfile);
    var ng = CreateGroupNode(gs, users);
    ac.TreeNodes.push(ng);
    //rooms
    var nr = CreateRoomChatNode(nfile);
    ac.TreeNodes.push(nr);
    //tribe
    var tribeusers = FindTribeUsers(nfile);
    var tribenode = CreateTribeNode(nfile, tribeusers);
    ac.TreeNodes.push(tribenode);
}

/////////////////////////////////////////////////////////The end

// return
root.TreeNodes = acnodes;
result.push(root);
var res = JSON.stringify(result);
res;
