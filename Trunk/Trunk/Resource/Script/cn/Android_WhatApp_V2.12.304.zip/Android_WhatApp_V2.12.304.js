﻿/*[config]
<plugin name="Whatsapp" group="社交聊天,8" devicetype="android" icon="\icons\whatsapp.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.whatsapp" version="2.12.304" description="WhatsApp" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.whatsapp/shared_prefs/com.whatsapp_preferences.xml</value>
    <value>/data/data/com.whatsapp/databases/wa.db</value>
    <value>/data/data/com.whatsapp/databases/msgstore.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Account" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="姓名" code="Name" type="string" width = "150"></item>
    <item name="号码" code="Num" type="string" width = "200"></item>
    </data>
    <data type="Friend" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="昵称" code="Name" type="string" width = "150"></item>
    <item name="号码" code="Num" type="string" width = "200"></item>
    <item name="ID" code="Id" type="string" show="false" width = "200"></item>
    </data>
    <data type="Group" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="群ID" code="ID" type="string" width = "150"></item>
    <item name="创建人" code="Creater" type="string" width = "150"></item>
    <item name="群成员" code="Member" type="string" width = "150"></item>
    </data>
    <data type="Message" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="发送者" code="Sender" type="string" width = "150"></item>
    <item name="接收者" code="Receiver" type="string" width = "200"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "150"></item>
    <item name="消息类型" code="Type" type="string" show="false" width = "150"></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account(){
    this.DataState = "Normal";
    this.Name = "";
    this.Num = "";
}
function Friend(){
    this.DataState = "Normal";
    this.Name = "";
    this.Num = "";
    this.ID = "";
}
function Group(){
    this.DataState = "Normal";
    this.Member = "";
    this.ID = "";
    this.Creater = "";
}
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Content = "";
    this.Time = "";
    this.Type = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "WhatsApp";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
    accountinfo = getAccount(db1);
    if (accountinfo.length > 0) {
        var accoutNode = newTreeNode(accountinfo[0].Name, "Account", accountinfo, news);
        var friendinfo = getFriend(db2);
        var friendNode = newTreeNode("好友", "Friend", friendinfo, accoutNode);
        for (var i in friendinfo) {
            newTreeNode(friendinfo[i].Name, "Message", getMessage(db3, friendinfo[i], "好友", accountinfo[0], db2), friendNode);
        }
        var gourpinfo = getGroup(db3, db2, accountinfo[0]);
        var gourpNode = newTreeNode("群组", "Group", gourpinfo, accoutNode);
        for (var i in gourpinfo) {
            newTreeNode(gourpinfo[i].Member, "Message", getMessage(db3, gourpinfo[i], "群组", accountinfo[0], db2), gourpNode);
        }
        result.push(news);
    }
}
function getNews(){
    var list = new Array();
    data = ["好友","群组"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var info = data.map.string;
    var obj = new Friend();
        obj.Name =info[10]['#text'];
        obj.Num = info[7]['#text'];
        list.push(obj);
    return list;
}
function getFriend(path){
    var list = new Array();
    //var data = eval('('+ XLY.Sqlite.Find(path,"select * from wa_contacts" ) +')');
    var data = eval('(' + XLY.Sqlite.FindAndSort(path, "select * from wa_contacts", "display_name asc") + ')');
    for(var i in data){
        var obj = new Friend();
        obj.Name = data[i].display_name;
        obj.Num = data[i].number;
        obj.ID = data[i].jid;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path,pcontact,account){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct gjid from group_participants" ) +')');
    for(var i in data){
        var obj = new Group();
        var id = data[i].gjid;
        obj.ID = id;
        var meminfo= eval('('+ XLY.Sqlite.Find(path,"select * from group_participants where gjid = '"+id+"'" ) +')');
        var mem = "";
        for(var i in meminfo){
            var fr=eval('('+ XLY.Sqlite.Find(pcontact,"select * from wa_contacts where jid = '"+meminfo[i].jid+"'" ) +')');  
            if((meminfo[i].admin==1)&&(fr.length==0)){
                obj.Creater = account.Name;
            }
            else if((meminfo[i].admin==1)&&(fr.length==1)){
                if(fr[0].display_name!=null){
                    obj.Creater = fr[0].display_name;
                }else{
                    obj.Creater = meminfo[i].jid;
                }
            }
            if(fr.length!= 0){
                if(fr[0].display_name!=null){
                    mem=mem+"、"+fr[0].display_name;
                }else{
                    mem = mem+"、"+meminfo[i].jid;
                }
            }else{
                mem = mem+"、"+account.Name;
            } 
        }
        obj.Member = mem.substring(1);
        list.push(obj);
    }
    return list;
}
function getMessage(path,forg,flag,account,pcontact){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from messages where key_remote_jid = '"+forg.ID+"'" ) +')');
    if(flag=="好友"){
        for(var i in data){
            var obj = new Message();
            if(data[i].key_from_me==0){
                obj.Sender = forg.Name;
                obj.Receiver = account.Name;
            }else{
                obj.c = forg.Name;
                obj.Sender = account.Name;
            }
            obj.Content = data[i].data+data[i].media_url;
            obj.Tpye = data[i].media_mime_type;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
            list.push(obj);
        }
    }else if(flag=="群组"){ 
        for(var i in data){
            var obj = new Message();
            obj.Receiver = forg.Member;
            if(data[i].key_from_me==1){
                obj.Sender = account.Name;
            }
            else{
                var fr=eval('('+ XLY.Sqlite.Find(pcontact,"select * from wa_contacts where jid = '"+data[i].remote_resource+"'" ) +')');
                if(fr.length!= 0){
                    if(fr[0].display_name!= null){
                        obj.Sender = fr[0].display_name;
                    }else{
                        obj.Sender = fr[0].jid;
                    } 
                }                                
            }
            obj.Content = data[i].data+data[i].media_url;
            obj.Tpye = data[i].media_mime_type;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
            list.push(obj);
        }
    }
    return list;
}

//********************************************************
var source = $source;
var db1 = source[0];
var db2 = source[1];
var db3 = source[2];
//var db1 = "D:\\temp\\data\\data\\com.whatsapp\\shared_prefs\\com.whatsapp_preferences.xml";
//var db2 = "D:\\temp\\data\\data\\com.whatsapp\\databases\\wa.db";
//var db3 = "D:\\temp\\data\\data\\com.whatsapp\\databases\\msgstore.db";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
