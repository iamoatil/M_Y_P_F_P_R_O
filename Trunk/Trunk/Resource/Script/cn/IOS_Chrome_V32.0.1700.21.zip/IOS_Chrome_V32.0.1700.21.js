﻿/*[config]
<plugin name="谷歌浏览器,2" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\Chrome.png" app="com.google.chrome.ios" version="32.0.1700.21" description="谷歌浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>com.google.chrome.ios</value>
</source>
<data type="Account">
<item name="姓名" code="Name" type="string" width="100" format=""></item>
<item name="邮箱地址" code="Email" type="string" width="120" format=""></item>
<item name="头像地址" code="Picture" type="string" width="300" format=""></item>
</data>
<data type="History">
<item name="主题" code="Title" type="string" width="250" format=""></item>
<item name="URL地址" code="Url" type="string" width="600" format=""></item>
<item name="访问时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Counts" type="string" width="100" format=""></item>
</data>
<data type="Bookmark">
<item name="书签名" code="Title" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="string" width="500" format=""></item>
<item name="创建时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Topsite">
<item name="主题" code="Title" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="string" width="500" format=""></item>
<item name="更新时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Account() {
    this.Name = "";
    this.Email = "";
    this.Picture = "";
}

function History() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Counts = "";
}

function Bookmark() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
}

function Topsite() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//获取帐号信息
function getAccount(path) {
    var pathname = eval('(' + XLY.File.FindFiles(path) + ')');
    var item = new Array();
    for (var index in pathname) {
        var filename = XLY.File.GetFileName(pathname[index]);
        var reg = /Profile_+[0-9]+.plist+$/gi;
        var flag = reg.test(filename);
        if (flag) {
            var data = eval('(' + XLY.PList.ReadToJsonString(pathname[index]) + ')');
            var arr = new Array();
            for (var i in data) {
                if (data[i].email) {
                    arr.push(data[i].email);
                }
                if (data[i].name) {
                    arr.push(data[i].name);
                }
                if (data[i].picture) {
                    arr.push(data[i].picture);
                }
            }
            var object = new Account();
            object.Name = arr[1];
            object.Email = arr[0];
            object.Picture = arr[2];
            item.push(object);
        }
    }
    return item;
}

//获取历史浏览记录信息
function getHistroy(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var object = new History();
        object.Title = data[index].title;
        object.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].time));
        object.Url = XLY.Convert.UrlDecode(data[index].url);
        object.Counts = data[index].count;
        arr.push(object);
    }
    return arr;
}

//获取书签信息
function getBookmark(path) {
    var data = eval('(' + XLY.File.ReadFile(path) + ')');
    var info = data.roots.synced.children;
    var arr = new Array();
    for (var index in info) {
        var object = new Bookmark();
        object.Title = info[index].name;
        object.Time = XLY.Convert.LinuxToDateTime(parseInt(info[index].date_added));
        object.Url = XLY.Convert.UrlDecode(info[index].url);
        arr.push(object);
    }
    return arr;
}

//获取快速连接信息
function getTopsite(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var object = new Topsite();
        object.Title = data[index].title;
        object.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].time));
        object.Url = XLY.Convert.UrlDecode(data[index].url);
        arr.push(object);
    }
    return arr;
}

var result = new Array();
//定义数据文件路径
var source = $source;
var accpath = source[0] + "\\com.google.chrome.ios\\Library\\Caches\\com.google.commmon.SSO";
var datapath = source[0] + "\\com.google.chrome.ios\\Library\\Application Support\\Google\\Chrome\\Default";

//创建帐号信息树
var account = new TreeNode();
account.Text = "登录的所有账户";
account.Type = "Account";
var accinfo = getAccount(accpath);
account.Items = accinfo;

//创建历史搜索树
var hispath = datapath + "\\History";
var hissql = "select title,url,last_visit_time as time,visit_count as count from urls";
var history = new TreeNode();
history.Text = "历史搜索";
history.Type = "History";
var hisinfo = getHistroy(hispath, hissql);
history.Items = hisinfo;

//创建书签树
var bkpath = datapath + "\\Bookmarks";
var bookmark = new TreeNode();
bookmark.Text = "书签";
bookmark.Type = "Bookmark";
var bkinfo = getBookmark(bkpath);
bookmark.Items = bkinfo;

//创建快速链接树
var toppath = datapath + "\\Top Sites";
var topsql = "select url,title,last_updated as time from thumbnails";
var topsite = new TreeNode();
topsite.Text = "快速链接";
topsite.Type = "Topsite";
var topinfo = getTopsite(toppath, topsql);
topsite.Items = topinfo;

//获取所有数据
result.push(account);
result.push(history);
result.push(bookmark);
result.push(topsite);
var res = JSON.stringify(result);
res;
