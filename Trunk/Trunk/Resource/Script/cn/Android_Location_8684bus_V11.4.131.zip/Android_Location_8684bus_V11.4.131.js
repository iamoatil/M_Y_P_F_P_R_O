﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="cn.chinabus.main" version="11.4.131" description="8684公交" data="$data,LocationInfoDataSource" >
<source>
<value>/data/data/cn.chinabus.main/databases/historydb</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "";
    this.Source = "8684公交";
    this.StartDate = null;
}

//获取路线搜索
function getPosition(path) {
    var data = eval('(' + XLY.Sqlite.FindByName(path,'history')+ ')');
    var info = new Array();
    if(data!=null){
        for(var i in data){
            var list = eval('('+ data[i].data +')');
            if(list.length != 2){ 
                var obj = new Position();
                obj.Remark = list.zhan;
                obj.Longitude = list.xzhan;
                obj.Latitude = list.yzhan;
                info.push(obj);
            }else{
                var obj1 = new Position();
                obj1.Remark = list[0].zhan;
                obj1.Longitude = list[0].xzhan;
                obj1.Latitude = list[0].yzhan;
                var obj2 = new Position();
                obj2.Remark = list[1].zhan;
                obj2.Longitude = list[1].xzhan;
                obj2.Latitude = list[1].yzhan;
                info.push(obj1);
                info.push(obj2);
            }
        }
    }
    return info;
}

var result = new Array();
//源文件路径
var source = $source;
var db = source[0];
//var db = "D:\\temp\\data\\data\\cn.chinabus.main\\databases\\historydb";
result = getPosition(db);
var res = JSON.stringify(result);
res;
