﻿/*[config]
<plugin name="百度云盘,9" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\baidunetdisk.png" app="com.baidu.netdisk" version="7.4.1" description="百度云盘" data="$data,ComplexTreeDataSource"  >
    <source>
        <value>data/data/com.baidu.netdisk/databases#F</value>
    </source>
    <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="账户名称" code="Name" type="string" width="180" format = ""></item>
        <item name="账户ID" code="ID" type="string" width="180" format = ""></item>
        <item name="账户昵称" code="NickName" type="string" width="180" format = ""></item>
        <item name="邮箱" code="Email" type="string" width="180" format = ""></item>
        <item name="电话" code="Phone" type="string" width="180" format = ""></item> 
    </data>
    <data type="CacheFiles" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="400" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="Share" detailfield="Uri" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="400" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="文件分享者" code="Shared" type="string" width="180" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="下载地址" code="Uri" type="url" width="400" format = ""></item>
    </data>
</plugin>
[config]*/

function Account() {
    this.Name = "";
    this.NickName= "";
    this.Email = "";
    this.ID = "";
    this.Phone = "";
    this.DataState = "Normal";
}

function CacheFiles() {
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.Time = null;
    this.DataState = "Normal";
}

function Share() {
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.Shared = "";
    this.Time = null;
    this.Uri = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var result = new Array();
//源文件
var source = $source;

var ch1 = "\\chalib\\Android_baidu.netdisk_V7.4.1\\account.db.charactor";
var accpath = XLY.Sqlite.DataRecovery(source[0]+"\\account.db",ch1,"info");

//获取网盘文件路径
function getFilepath(accID){
    var filepath = source[0]+"\\"+accID+"filelist.db";
    var ch = "\\chalib\\Android_baidu.netdisk_V7.4.1\\filelist.charactor";
    var path = XLY.Sqlite.DataRecovery(filepath,ch,"cachefilelist");
    return path;
}
//获取分享文件路径
function getSharepath(accID){
    var sharepath = source[0]+"\\"+accID+"cloudp2p.db";
    var ch ="\\chalib\\Android_baidu.netdisk_V7.4.1\\share.charactor";
    var path = XLY.Sqlite.DataRecovery(sharepath,ch,"people_messages_files,groups_messages_files");
    return path;
}

//主界面函数
function ParesCore(){
    //定义网盘节点
    var acc = getAccount();
    var diskNode = BuildNode("百度云盘","Account",acc,"Normal");
    //定义账户节点
    for(var i in acc){
        var accNode = BuildNode(acc[i].Name,"",[],acc[i].DataState);
        //定义网盘文件节点
        var fileNode = BuildNode("网盘文件","CacheFiles",getFile(acc[i].ID),"Normal");
        accNode.TreeNodes.push(fileNode);
        //定义分享文件节点
        var shareNode = BuildNode("分享文件","Share",getShare(acc[i].ID),"Normal");
        accNode.TreeNodes.push(shareNode);
        diskNode.TreeNodes.push(accNode);
    }
    result.push(diskNode);
}

//创建节点
function BuildNode(text,type,items,dataState){
    var node = new TreeNode();
    node.Text = text;
    node.Type = type;
    node.Items = items;
    node.DataState = dataState;
    return node;
}

//获取账户信息
function getAccount(){
    var db = eval('('+ XLY.Sqlite.FindByName(accpath,"info") +')');
    var Items = new Array();
    for(var i in db){
        var acc = new Account();
        acc.Name = db[i].account_name;
        acc.NickName = db[i].nick_name;
        acc.ID = db[i].account_uid;
        acc.Email = db[i].account_email;
        acc.Phone = db[i].account_phone;
        acc.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(acc);
    }
    return Items;
}

//获取网盘文件
function getFile(accID){
    var filepath = getFilepath(accID);
    var db = eval('('+ XLY.Sqlite.FindByName(filepath,"cachefilelist") +')');
    var Items = new Array();
    for(var i in db){
        var file = new CacheFiles();
        file.Name = db[i].file_name;
        file.Path = db[i].server_path;
        file.Size = db[i].file_size+"/byte";
        file.Time = XLY.Convert.LinuxToDateTime(db[i].server_ctime);
        file.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(file);
    }
    return Items;
}

//获取分享文件
function getShare(accID){
    var sharepath = getSharepath(accID);
    var db1 = eval('('+ XLY.Sqlite.FindByName(sharepath,"groups_messages_files") +')');
    var db2 = eval('('+ XLY.Sqlite.FindByName(sharepath,"people_messages_files") +')');
    var Items = new Array();
    for(var i in db1){
        var share = new Share();
        share.Name = db1[i].server_filename;
        share.Path = db1[i].path;
        share.Size = db1[i].size+"/byte";
        share.Time = XLY.Convert.LinuxToDateTime(db1[i].server_ctime);
        share.Uri = db1[i].dlink;
        share.Shared = db1[i].uname;
        share.DataState = XLY.Convert.ToDataState(db1[i].XLY_DataType);
        Items.push(share);
    }
    for(var j in db2){
        var share = new Share();
        share.Name = db2[j].server_filename;
        share.Path = db2[j].path;
        share.Size = db2[j].size+"/byte";
        share.Time = XLY.Convert.LinuxToDateTime(db2[j].server_ctime);
        share.Shared = db2[j].uname;
        share.Uri = db2[j].dlink;
        share.DataState = XLY.Convert.ToDataState(db2[j].XLY_DataType);
        Items.push(share);
    }
    return Items;
}

ParesCore();
var res = JSON.stringify(result);
res;
