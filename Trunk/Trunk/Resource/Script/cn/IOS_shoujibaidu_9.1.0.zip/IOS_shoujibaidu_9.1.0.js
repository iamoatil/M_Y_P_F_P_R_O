﻿//本程序是针对三星的特别版
/*[config]
<plugin name="手机百度" group="Web痕迹,17" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/baidu.png" app="com.baidu.BaiduMobile" version="9.0.1" description="手机百度" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.baidu.BaiduMobile</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="账号" code="UserCode" type="string" width="200" format=""></item>
    <item name="最后登录位置" code="LastLoca" type="string" width="200" format=""></item>
    <item name="最后登录时间" code="LastTime" type="string" width="200" format = ""></item>
</data>
</plugin>
[config]*/
function News() {
    this.DataState = "Normal";  //数据状态
    this.List = ""; //列表
    this.MDFString = "";    //MD5
}
function UserInfo() {
    this.DataState = "Normal";  //数据状态
    this.UserCode = ""; //账号
    this.LastLoca = ""; //最后登录位置
    this.LastTime = ""; //最后登录时间
    this.MDFString = "";    //MD5
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
var result = new Array();
//配置文件路径全局共用

//*************************************程序入口****************************************
//源数据
var source = $source;
var Path = source[0] + "\\com.baidu.BaiduMobile\\Library\\Preferencescom.baidu.BaiduMobile.plist";

//测试数据
//var Path = "E:\\xlyspf\\任务-2017-08-16-10-21-08\\com.baidu.BaiduMobile.plist"
BuildNode();
var res = JSON.stringify(result);
res;
//*************************************程序结束****************************************
//++++++++++++++++++++++++++++++++++自定义函数部分++++++++++++++++++++++++++++++++++++++
//自定义数据库读取函数  
//主函数
function BuildNode(){
 //**********************************根节点建立**************************************  
    var RootNode = new TreeNode();
    RootNode.Text = "手机百度";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(RootNode);
    result.push(RootNode);
}
function GetRootInfo(Node){
    var temp1 = new Array();
    var temp2 = new News();
    temp2.List = "用户信息";
    temp1.push(temp2)
    //获得用户信息
    var UserInfoNode = new TreeNode();
    UserInfoNode.Text = "用户信息";
    UserInfoNode.Type = "UserInfo";
    UserInfoNode.Items = GetUserInfo();
    Node.TreeNodes.push(UserInfoNode);
    //返回列表
    return temp1;
}
//用户信息获取函数
function GetUserInfo(){
    var temp1 = new Array();
    var temp2 = new UserInfo();
    if(XLY.File.IsValid(Path)){
        var temp3 = eval('('+ XLY.PList.ReadToJsonString(Path) +')');
        for(var i in temp3){
            if(temp3[i].LAST_LOGIN_PHONE_NUMBER_KEY != null){
                temp2.UserCode = temp3[i].LAST_LOGIN_PHONE_NUMBER_KEY;
            }
            if(temp3[i].LatestLocationString != null){
                temp2.LastLoca = temp3[i].LatestLocationString;
            }
            if(temp3[i].BBARefreshTableView_LastRefreshBBAMessageSessionsViewController != null){
                temp2.LastTime = temp3[i].BBARefreshTableView_LastRefreshBBAMessageSessionsViewController;
            }
        }
        
    }
    temp1.push(temp2)
    return temp1;
}
