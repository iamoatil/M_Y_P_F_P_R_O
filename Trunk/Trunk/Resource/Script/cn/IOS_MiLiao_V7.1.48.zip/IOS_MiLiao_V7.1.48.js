﻿//descritpion:米聊(1.0.1167)_Android(4.1.1)

/*[config]
<plugin name="米聊,10" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="icons/AndroidMiLiao.png" app="com.xiaomi.miliao" version="7.1.48" description="Test-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>com.xiaomi.miliao</value>
</source>

// 群
<data type="Group" contract="DataState">
<item name="群名称" code="Name" type="string" width="170" alignment="left"></item>
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群号" code="Account" type="string" width="110" format=""></item>
<item name="群创建时间" code="CreateTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="165" format=""></item>
</data>

// 用户信息
<data type="User" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="130" ></item>
<item name="帐号" code="Account" type="string" width="200" ></item>
<item name="手机号码" code="Phone" type="string" width="250" ></item>
<item name="性别" code="Gender" type="string" width="50" alignment="center"></item>
<item name="生日" code="BrithDay" type="string" width="100" ></item>
<item name="头像" code="Photo" type="string" width="" ></item>
<item name="所在地" code="Location" type="string" width="" ></item>
<item name="学校" code="School" type="string" width="" ></item>
<item name="公司" code="Company" type="string" width=""></item>
<item name="个人简介" code="Bio" type="string" width=""></item>
<item name="个性签名" code="Signature" type="string" width=""></item>
<item name="语音签名" code="VoiceSignature" type="string" width=""></item>
<item name="社交绑定" code="BindValues" type="string" width="450"></item>
<item name="故乡" code="Hometown" type="string" width=""></item>
</data>
 
// 消息
<data detailfield="Content" type="Message" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者头像" code="SenderImage" type="image" format=""  show="false"></item>
<item name="发送人" code="SenderName" type="string" width="300"></item>
<item name="接收人" code="Receiver" type="string" width="300"></item>
<item name="内容" code="Content" type="string" width="350" format=""></item>
<item name="时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
<item name="消息类别" code="MessageType" type="string" width=""></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="设备" code="Device" type="string" width="" format=""></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>
</plugin>
[config]*/

// js content

//************************** 定义数据结构 Star **************************


// 群
function Group() {
    this.Name = "";
    this.Account = "";
    this.CreateTime = null;
    this.Creator = "";
    this.DataState = "Normal";
}

// 用户信息
function User() {
    this.Id = "";
    this.Name = "";
    this.Account = "";
    this.Phone = "";
    this.Gender = "";
    this.BrithDay = "";
    this.Photo = "";
    this.Location = "";
    this.School = "";
    this.Company = "";
    this.Bio = "";
    this.Signature = "";
    this.VoiceSignature = "";
    this.BindValues = "";
    this.Hometown = "";
    this.DataState = "Normal";
}

// 消息
function Message() {
    this.SenderName = "";
    this.SenderImage = "";
    this.Receiver = "";
    this.Device = "";
    this.Content = "";
    this.MessageType = "";
    this.DataState = "Normal";
    this.Date = "";
    this.Type = "";
    this.SendState = "";
}

//************************** 定义数据结构 End **************************


//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点树
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

// SQLITE对象获取
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}
// string.format
String.prototype.format = function (args) {
    var result = this;
    if (arguments.length > 0) {
        var reg;
        if (arguments.length == 1 && typeof (args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    reg = new RegExp("({" + key + "})", "g");
                    result = result.replace(reg, args[key]);
                }
            }
        }
        else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    reg = new RegExp("({)" + i + "(})", "g");
                    result = result.replace(reg, arguments[i]);
                }
            }
        }
    }
    return result;
};

String.prototype.KbToMb = function () {
    var result = (this / 1024).toFixed(2);
    return result;
};

String.prototype.ByteToKb = function () {
    var result = (this / 1024).toFixed(2);
    return result;
};

String.prototype.ByteToMb = function () {
    var kb = this / 1024;
    var mb = kb / 1024;
    return mb.toFixed(2);
};

String.prototype.Sub = function () {
    return this.substr(0, 2);
};

var sqlStr = "select {0} from {1} ";

function GetSql(parm, tablename, where) {
    if (!isNewDb) {
        // 旧数据库SQL
        var sql = sqlStr.format(parm, tablename);
        if (where != "") {
            sql += where;
        }
        return sql;
    } else {
        var sql = sqlStr.format(parm + ",XLY_DataType", tablename);
        if (where != "") {
            sql += where;
        }
        return sql;
    }
}

function ParesCore() {
    var tree = new TreeNode();
    tree.type = "User";
    if (baseUse == null)
        return;
    tree.Text = accountFormat.format(baseUse.Name, baseUse.Account);
    tree.Items.push(baseUse);
    tree.TreeNodes.push(GetUserTree());
    tree.TreeNodes.push(GetGroupTree());
    result.push(tree);
}

// 构建米聊好友树结构  [ 数据状态已接 ]
function GetUserTree() {
    // 构建好友树结构
    var tree = new TreeNode();
    tree.Text = "好友";
    tree.Type = "User";

    // 获取所有好友信息
    var data = GetUserAll();
    for (var o in data) {
        var user = ConvertUser(data[o]);
        // 获取该用户聊天记录
        var userTree = new TreeNode();
        userTree.Type = "Message";
        userTree.DataState = user.DataState;
        userTree.Text = accountFormat.format(user.Name, user.Account);
        var sms = GetUserMessage(user);
        for (var s in sms) {
            var msg = ConvertMessage(sms[s]);
            userTree.Items.push(msg);
        }
        tree.Items.push(user);
        tree.TreeNodes.push(userTree);
    }
    return tree;
}

// 构建群信息树结构 
function GetGroupTree() {
    var tree = new TreeNode();

    tree.Text = "我的群";
    tree.type = "Group";
    // 获取所有群信息;
    var group = GetGroupAll();
    for (var g in group) {
        try {
            var ginfo = ConvertGroup(group[g]);
            var gTree = new TreeNode();
            gTree.Text = accountFormat.format(ginfo.Name, ginfo.Account);
            gTree.Type = "Message";
            gTree.DataState = ginfo.DataState;
            //获取群聊天记录
            var msg = GetGroupMsg(ginfo);
            if (msg != null) {
                for (var m in msg) {
                    gTree.Items.push(ConvertGroupMessage(msg[m]));
                }
                tree.Items.push(ginfo);
                tree.TreeNodes.push(gTree);
            }
        } catch (e) {
        }
    }
    return tree;
}

// 获取指定群消息
function GetGroupMsg(g) {
    if (g == null || g.Account == null) return null;
    var sqlStr = GetSql("ZBODY as Content, ZBODY_TYPE as MessType,ZSENDER_ID as Sender,ZMSG_FROM as SenderUser,ZMSG_TO as ReceiverUser, ZSEND_TIME as SendTime", "ZMUCMESSAGEOBJECT", "where ZMUC_ID = {0}".format(g.Account));
    var data = ExecSql(mucMessagePath,sqlStr);
    return data;
}

// 转换消息
function ConvertGroupMessage(m) {
    var mess = new Message();
    if (m == null) return mess;
    mess.Content = m.Content;
    mess.SenderName = m.SenderUser;
    mess.Receiver = m.ReceiverUser;
    mess.MessageType = GetMsgType(m.MessType, mess);
    mess.Date = XLY.Convert.LinuxToDateTime(m.SendTime);
    mess.DataState = XLY.Convert.ToDataState(m.XLY_DataType);
    
    return mess;
}

// 获取所有群
function GetGroupAll() {
    var sqlStr = GetSql("ZCHAT_NAME as Name,ZMILIAOID as Account,ZCONTENT as BindValues,XLY_DataType", "ZTHREADOBJECT", "where ZMILIAOID like '%.muc%'");
    var data = ExecSql(messagePath,sqlStr);
    return data;
}

// 转换群信息
function ConvertGroup(g) {
    var group = new Group();
    if (g == null) return group;
    group.Name = g.Name;
    group.Account = g.Account.substr(0, g.Account.indexOf(".muc"));
    var groupInfo = GetGroupInfo(group.Account);
    group.Creator = groupInfo.creator;
    group.CreateTime = XLY.Convert.LinuxToDateTime(groupInfo.createtime);
    group.DataState = XLY.Convert.ToDataState(g.XLY_DataType);
    return group;
}

// 获取群组创建信息
function GetGroupInfo(groupid) {
    var group = new Group();
    if (groupid == null || groupid == "") return group;
    var sqlStr =  GetSql("group_id as groupid,member_nick as nick,member_id as creator,join_time as createtime,member_role as role,XLY_DataType", "MLMUCMember2Object", "where group_id = {0} and gm_id=0".format(groupid)); 
    var data = ExecSql(mucMemberPath,sqlStr);
    group.Creator = data.creator;
    group.CreateTime = XLY.Convert.LinuxToDateTime(data.createtime);
    return group;
}

// 获取某一种类型的所有用户
function GetUserAll() {
    var sqlStr =  GetSql("miliaoid as userid,info,XLY_DataType", "MLPersonalInfo2Object", "where 1 = 1");
    var data = ExecSql(personalInfoPath,sqlStr);
    return data;
}

// 获取用户的聊天记录
function GetUserMessage(user) {
    if (user == null || user.Account == null) return null;
    var sqlStr = GetSql("ZBODY as Content, ZSERVER_STATUS as SendState,ZBODY_TYPE as MessType,ZMSG_SENDER as Sender,ZMSG_FROM as SenderUser,ZMSG_TO  as ReceiverUser, ZTIMESTAMP as SendTime,XLY_DataType", "ZMESSAGEV5OBJECT", "where ZTHREAD_ID={0}".format(user.Account));
    var data = ExecuteSql(sqlStr);
    return data;
}

// 聊天信息转换
function ConvertMessage(sms) {
    var msg = new Message();
    if (sms == null || sms == "") return msg;
    msg.Content = sms.Content;
    var use = GetUserInfoByUserId(sms.Sender);
    msg.SendState = sms.SendState == "received" ? "Receive" : "Send";
    msg.SenderName = sms.SenderUser;
    msg.Receiver = sms.ReceiverUser;
    msg.SenderImage = sms.SendState == "received" ? use.Photo : baseUse.Photo;
    msg.Date = XLY.Convert.LinuxToDateTime(sms.SendTime);
    msg.MessageType = GetMsgType(sms.MessType, msg);
    msg.DataState = XLY.Convert.ToDataState(sms.XLY_DataType);
    return msg;
}

// 根据帐户获取信息
function ConvertUser(u) {
    var user = new User();
    if (u == null) return user;
    var userInfo = eval("(" + u.info + ")");
    user.Name = userInfo.nickname;
    user.Phone = GetPhone(u.external_id);
    user.Account = u.userid;
    user.Gender = userInfo.sex;
    user.BrithDay = userInfo.birthday;
    user.Photo = userInfo.icon;
    user.School = GetSchool(userInfo.school);
    user.Company = userInfo.coorp;
    user.Location = userInfo.city;
    user.Bio = userInfo.intro;
    user.Signature = userInfo.signature;
    user.DataState = XLY.Convert.ToDataState(u.XLY_DataType);
    return user;
}

// 根据用户ID获取用户信息
function GetUserInfoByUserId(userid) {
    var user = new User();
    if (userid == null || userid == "") return user;   
    var sqlStr = GetSql("miliaoid as userid,info,XLY_DataType", "MLPersonalInfo2Object", "where miliaoid = '{0}'".format(userid));
    var data = ExecSql(personalInfoPath,sqlStr);
    if (data == null || data.length == 0)
        return null;
    var u = eval("(" + data[0].info + ")");
    user.Name = u.nickname;
    user.Phone = GetPhone(u.external_id);
    user.Account = userid;
    user.Gender = u.sex;
    user.BrithDay = u.birthday;
    user.Photo = u.icon;
    user.School = GetSchool(u.school);
    user.Company = u.coorp;
    user.Location = u.city;
    user.Bio = u.intro;
    user.Signature = u.signature;
    return user;
}

// Sqlite执行
function ExecuteSql(sqlStr) {
    return ExecSql(messagePath, sqlStr);
}

// 电话号码
function GetPhone(external) {
    if(data == null || data.length < 1){
        return "";
    }
    var data = eval("(" + external + ")");
    if(data != null && data.length > 0){
        return data[0].contact_value;
    } 
    else{
        return "";
    }
}

// 学校信息处理
function GetSchool(school) {
    return school;
}

// 获取公司信息
function GetCompany(company) {
    var companyStr = "";
    if (company != null && company.trim() != "") {
        var cpy = eval(company);
        for (var c in cpy) {
            companyStr += "公司:{0}\n".format(cpy[c].name);
        }
    }
    return companyStr;
}

// 获取附件
function GetAccessory(accessory) {
    var sory = "";
    // 附件处理
    if (accessory != null && accessory.trim() != "") {
        // 取出附件对象(可能多个)
        var acc = eval('(' + accessory + ')');
        if (acc == null || acc.length == 0)
            return sory;
        if (acc.length == 1) {
            sory = "文件：{0}".format(acc[0].reallink);
        } else {
            for (var o in acc) {
                sory += "文件:{0} \n".format(acc[o].reallink);
            }
        }
    }
    return sory;
}


// 获取群消息发送者
function GetGroupSender(str) {
    if (str != null && str.trim() != "") {
        var data = eval('[' + str + ']');
        return data[0].senderNick;
    }
    return "";
}


// 获取消息类型。
function GetMsgType(mstype, msg) {
    switch (mstype) {
        case 0:
            msg.Type = "String";
            return "文本";
        case 1:
            msg.Type = "Image";
            return "图片";
        case 23:
            msg.Type = "Video"
            return "视频";
        case 5:
            msg.Type = "Audio";
            return "音频";
        default:
            msg.Type = "String";
            return "文本";
    }
}

// 组建绑定信息
function GetBindType(str) {
    var formatStr = "{0}:{1}\n";
    if (str == null)
        return "";
    switch (str.bind_type) {
        case "PH":
            return formatStr.format("手机", str.contact_value);
        case "OPEN_QQ":
            return formatStr.format("腾讯QQ", str.contact_value);
        case "RE":
            return formatStr.format("人人网", str.contact_value);
        default:
            return "";
    }
}

var result = new Array();
//源文件
var source = $source;
//var source = "C:\\XLYSFTasks\\未命名-67\\source\\IosData\\2015-10-18-15-15-11";
var path0 = source + "\\com.xiaomi.miliao\\Documents";
var path1 = source + "\\com.xiaomi.miliao\\Documents\\692125169\\account\\{0}_PersonalInfo2.sqlite";
var path2 = source + "\\com.xiaomi.miliao\\Documents\\692125169\\account\\{0}_Message.sqlite";
var path3 = source + "\\com.xiaomi.miliao\\Documents\\692125169\\account\\{0}_mucMember2.sqlite";
var path4 = source + "\\com.xiaomi.miliao\\Documents\\692125169\\account\\{0}_MUC.sqlite";
var isNewDb = true;
var accountFormat = "{0}({1})";
var accountStr = "{0}({1}@xiaomi.com)";
var accountStr1 = "{0}@xiaomi.com";
var allGroup = null;

// 循环解析账号
var accountDirs =eval("(" + XLY.File.FindDirectories(path0) + ")");
if(accountDirs.length > 0) {
    var reg = new RegExp("\\d+", "g");
    for(var i in accountDirs){
        var userid = XLY.File.GetFileName(accountDirs[i]);
        if(reg.test(userid))
        {
            personalInfoPath = XLY.Sqlite.DataRecovery(path1.format(userid),"" ,"MLPersonalInfo2Object" );
            messagePath = XLY.Sqlite.DataRecovery(path2.format(userid),"" ,"ZMESSAGEV5OBJECT,ZTHREADOBJECT" );
            mucMemberPath = XLY.Sqlite.DataRecovery(path3.format(userid),"" ,"MLMUCMember2Object" );
            mucMessagePath = XLY.Sqlite.DataRecovery(path4.format(userid),"" ,"ZMUCMESSAGEOBJECT" );
            if (personalInfoPath == path1.format(userid)) {
                isNewDb = false;
            }
            
            baseUse = GetUserInfoByUserId(userid);
            ParesCore();
        }
    }
}

var res = JSON.stringify(result);
res;
