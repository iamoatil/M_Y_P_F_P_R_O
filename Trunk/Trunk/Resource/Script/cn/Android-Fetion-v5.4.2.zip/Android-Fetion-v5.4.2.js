﻿/*[config]
<plugin name="飞信,12" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\fetion.png" app="cn.com.fetion" description="飞信"  data="$data,ComplexTreeDataSource" version="5.4.2">
<source>
<value>/data/data/cn.com.fetion/databases/fetion.db</value>

</source>

<data type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分组名称" code="Name" type="string" width="600" format="" ></item>
</data>

<data type="User" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="账户ID" code="UserId" type="string" width="" format="" ></item>
<item name="手机号" code="Mobile" type="string" width="" format="" ></item>
<item name="飞信号" code="FetionID" type="string" width="" format = "" ></item>
<item name="昵称" code="NickName" type="string" width="" format = "" ></item>
<item name="签名" code="Impresa" type="string" width="" format = "" ></item>
<item name="生日" code="BirthDate" type="string" width="" format="" ></item>
</data>

<data type="ContactGroup" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="联系人分组" code="Name" type="string" width="" format="" ></item>
<item name="分组ID" code="ID" type="string" width="" format="" show = "false"></item>
<item name="用户ID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type="DiscussionGroup" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="讨论组名称" code="Name" type="string" width="" format = "" ></item>
<item name="讨论组成员" code="Member" type="string" width="" format = "" ></item>
<item name="讨论组uri" code="Uri" type="string" width="" format="" show = "false"></item>
<item name="用户ID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type="PgGroup" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="群名称" code="Name" type="string" width="" format = "" ></item>
<item name="群简介" code="Introduce" type="string" width="" format = "" ></item>
<item name="群ID" code="ID" type="string" width="" format="" show = "false"></item>
<item name="群URI" code="Uri" type="string" width="" format="" show = "false"></item>
<item name="用户ID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type = "Contact" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="昵称" code="Name" type="string" width="100" format=""></item>
<item name="好友账号" code="ID" type="string" width="140" format=""></item>
<item name="飞信号" code="FetionID" type="string" width="100" format=""></item>
<item name="备注" code="Local_name" type="string" width="200" format=""></item>
<item name="电话号码" code="Mobile" type="string" width="300" format=""></item>
<item name="签名" code="Impresa" type="string" width="300" format = ""></item>
<item name="用户ID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type = "Discussion" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="昵称" code="Name" type="string" width="100" format=""></item>
<item name="好友账号" code="ID" type="string" width="140" format=""></item>
<item name="飞信号" code="FetionID" type="string" width="100" format=""></item>
<item name="备注" code="Local_name" type="string" width="200" format=""></item>
</data>

<data type="Message" datefilter="Date" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="发送人" code="Sender" type="string" width="100" format=""></item>
<item name="接收人" code="Target" type="string" width="100" format=""></item>
<item name="会话内容" code="Content" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order = "asc"></item>
<item name="消息类型" code="MsgType" type="Enum" format="EnumColumnType" width="60"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="Enum" format="EnumSendState"  show="false"></item>
</data>
</plugin>
[config]*/

//分组情况
function Group(){
    this.Name = "";
    this.DataState = "Normal";
}

//联系人组数据结构
function ContactGroup(){
    this.Name = "";
    this.ID = "";
    this.OwerID = "";
    this.DataState = "Normal";
}

//讨论组数据结构
function DiscussionGroup(){
    this.Name = "";
    this.Uri = "";
    this.Member = "";
    this.OwerID = "";
    this.DataState = "Normal";
}

//群组数据结构
function PgGroup(){
    this.Name = "";
    this.ID = "";
    this.Uri = "";
    this.Introduce = "";
    this.OwerID = "";
    this.DataState = "Normal";
}
    
//定义User数据结构
function User(){  
    this.UserId = "";
    this.Mobile = "";
    this.FetionID = "";
    this.NickName = "";
    this.Impresa = "";
    this.BirthDate = "";
    this.DataState = "Normal";    
}

//定义联系人
function Contact(){
    this.Name = "";
    this.ID = "";
    this.FetionID = "";
    this.OwerID = "";
    this.Local_name = "";  
    this.Mobile = ""; 
    this.Impresa = ""; 
    this.DataState = "Normal";
}

//定义讨论组成员
function Discussion(){
    this.Name = "";
    this.ID = "";
    this.FetionID = "";
    this.Member = "";
    this.Local_name = "";  
    this.DataState = "Normal";
}

//定义会话数据结构
function Message(){
    this.Sender = "";
    this.Target = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
    this.Type = "";
    this.MsgType = "";
    this.SendState = "";
}
//定义树数据结构
function TreeNode() {
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

function bindTree(){
    var dblist = eval('(' + XLY.Sqlite.FindByName(recoverydb, 'user') + ')');
    var dblist1 = eval('(' + XLY.Sqlite.FindByName(recoverydb, 'dgroup ') + ')');
    var fetion = new TreeNode();
    fetion.Text = "账户信息";
    fetion.Type = "User";
    var userinfo = getUser(recoverydb,dblist);
    fetion.Items = userinfo;
    for(var i in userinfo){
        var user = new TreeNode();
        user.Text = userinfo[i].Mobile;
        user.Type = "Group";
        fetion.TreeNodes.push(user);
        group(recoverydb,"联系人分组","ContactGroup","Contact",getContactGroup(recoverydb,userinfo[i]),user,userinfo);
        group(recoverydb,"讨论组","DiscussionGroup","Message",getDiscussionGroup(recoverydb,userinfo[i]),user,userinfo);
        group(recoverydb,"群组","PgGroup","Message",getPgGroup(recoverydb,userinfo[i]),user,userinfo);  
    }
    return fetion;
}

//获取分组
function getGroup(name){
    var obj = new Group();
    obj.Name = name;
    obj.DataState = "Normal";
    return obj;
}

//获取用户信息
function getUser(path,data){
    var list = new Array;
    for(var i in data){
        var obj = new User();
        obj.UserId = data[i].xly_id;
        obj.Mobile = data[i].mobile_no;
        obj.FetionID = data[i].sid;
        if(obj.NickName==""){
            obj.NickName = data[i].mobile_no;
        }else{
            obj.NickName = data[i].nick_name;
        }
        obj.Impresa = data[i].impresa;
        obj.BirthDate = data[i].birth_date;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取好友分组信息
function getContactGroup(path,data){
    var list = new Array();
    var table = eval('('+ XLY.Sqlite.Find(path,"select * from contact_group where ower_id = '"+data.UserId+"'") +')');
    if(table!=null&&table.length>0){
        for(var i in table){
            var obj = new ContactGroup();
            obj.Name = table[i].group_name;
            obj.ID = table[i].group_id;
            obj.OwerID = table[i].ower_id;
            obj.DataState = XLY.Convert.ToDataState(table[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取讨论组信息
function getDiscussionGroup(path,data){
    var list = new Array();
    var table = eval('('+ XLY.Sqlite.Find(path,"select * from dgroup where ower_id = '"+data.UserId+"'") +')');
    if(table!=null&&table.length>0){
        for(var i in table){
            table1 = eval('('+ XLY.Sqlite.Find(path,"select * from dgroup_relationship where group_uri = '"+table[i].group_uri+"'" ) +')');
            var member = "";
            if(table1!=null&&table1.length>0){
                for(var j in table1){
                    var table2 = eval('('+ XLY.Sqlite.Find(path,"select * from dgroup_member where user_id = '"+table1[j].user_id+"'" ) +')');
                    if(table2!=null&&table2.length>0){
                        if(table2[0].nick_name==""){
                            member += table2[0].user_id+"、";
                        }else{
                            member += table2[0].nick_name+"、";
                        }
                    }
                }
            }
            member = member.substring(0,member.length-1);
            var obj = new DiscussionGroup();
            obj.Name = table[i].group_name;
            obj.Uri = table[i].group_uri;
            obj.OwerID = table[i].ower_id;
            obj.Member = member;
            obj.DataState = XLY.Convert.ToDataState(table[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取群组信息
function getPgGroup(path,data){
    var list = new Array();
    var table = eval('('+ XLY.Sqlite.Find(path,"select * from pg_group where ower_id = '"+data.UserId+"'") +')');
    if(table!=null&&table.length>0){
        for(var i in table){
            var obj = new PgGroup();
            obj.Name = table[i].name;
            obj.ID = table[i].group_id;
            obj.Uri = table[i].uri;
            obj.Introduce = table[i].introduce;
            obj.OwerID = table[i].ower_id;
            obj.DataState = XLY.Convert.ToDataState(table[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取联系人信息
function getContact(path,data){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select * from (select * from contact_group_relation where ower_id='"+data.OwerID+"' and group_id='"+data.ID+"')as a left join contact on a.user_id = contact.user_id") +')');
    if(info!=null&&info.length>0){
        for(var i in info){
            var obj = new Contact();
            if(obj.Name==null){
                obj.Name = info[i].mobile_no;;
            }else{
                obj.Name = info[i].nick_name;;
            }
            obj.ID = info[i].user_id;
            obj.FetionID = info[i].sid;
            obj.Local_name = info[i].local_name;  
            obj.Mobile = info[i].mobile_no; 
            obj.Impresa = info[i].impresa; 
            obj.OwerID = info[i].ower_id; 
            obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取会话内容
function getMessage(path,data,rootinfo,flag){
    var list = new Array() ;
    if(flag=="联系人会话"){
        msg = eval('('+ XLY.Sqlite.Find(path,"select * from (select *,cast(target as text) from message where target not like 'sip%') where target = '"+data.ID+"'") +')');
        if(msg!=null&&msg.length>0){
            for(var i in msg){
                var obj = new Message();
                if(msg[i].send_flag==1){
                    obj.Sender = data.Name;
                    obj.Target = rootinfo[0].NickName;
                    obj.SendState = "Receive";
                }else{
                    obj.Target = data.Name;
                    obj.Sender = rootinfo[0].NickName;
                    obj.SendState = "Send";
                }
                obj.Time = msg[i].create_date;
                obj.Content = msg[i].content;
                switch(msg[i].content_type){
                    case "audio":  obj.Type = "Audio";obj.MsgType = "音频";
                    break;
                    case "text/pic": obj.Type = "Image";obj.MsgType = "图片";
                    break;
                    case "text/html-fragment":
                    if(/jpg$|png$|jpeg$/gi.test(msg[i].content)){
                        obj.Type = "Image";obj.MsgType = "图片";;
                    }else{
                        obj.Type = "HTML";obj.MsgType = "文本";
                    }
                    break;
                    default: obj.Type = "HTML";obj.MsgType = "文本";  
                }
                obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                list.push(obj);
            }
        }
    }
    else{
        msg = eval('('+ XLY.Sqlite.Find(path,"select *,cast(target as text) as t from message where t = '"+data.Uri+"'") +')');
        if(msg!=null&&msg.length>0){
            for(var i in msg){
                var obj = new Message();
                //sender_user_id为-100、0时为系统消息
                if(msg[i].sender_user_id <= 0){
                    obj.Sender = "系统消息";
                //sender_user_id为用户id    
                }else if(msg[i].sender_user_id == rootinfo[0].UserId){
                    obj.Sender = rootinfo[0].NickName;
                }
                //sender昵称为空时传入user_id
                else{
                    if(msg[i].sender_nick_name == ""){
                        obj.Sender = msg[i].sender_user_id;
                    }
                    else{
                        obj.Sender = msg[i].sender_nick_name;
                    }
                }
                obj.Target = data.Name;
                obj.Time = msg[i].create_date;
                obj.Content = msg[i].content;
                switch(msg[i].content_type){
                    case "audio":  obj.Type = "Audio";obj.MsgType = "音频";
                    break;
                    case "text/pic": obj.Type = "Image";obj.MsgType = "图片";
                    break;
                    case "text/html-fragment":
                    if(/jpg$|png$|jpeg$/gi.test(msg[i].content)){
                        obj.Type = "Image";obj.MsgType = "图片";;
                    }else{
                        obj.Type = "HTML";obj.MsgType = "文本";
                    }
                    break;
                    default: obj.Type = "HTML";obj.MsgType = "文本";  
                }
                 if(msg[i].send_flag==1){
                    obj.SendState = "Receive";
                }else{
                    obj.SendState = "Send";
                }
                obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                list.push(obj);
            }
        }
    }    
    return list;
}

//获取分组信息
function group(path,name,type,type2,info,root,rootinfo){
    root.Items.push(getGroup(name));
    var childNode = new TreeNode();
    childNode.Text = name;
    childNode.Type = type;
    //info为联系人、讨论组、群组等分组信息
    childNode.Items = info;
    root.TreeNodes.push(childNode);
    for(var i in info){
        var groupinfo = new TreeNode();
        groupinfo.Text = info[i].Name;
        groupinfo.Type = type2,
        groupinfo.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
        if(name=="联系人分组"){
            var friend = getContact(path,info[i]);
            groupinfo.Items = friend;
            childNode.TreeNodes.push(groupinfo);
            for(var j in friend){
                var contactinfo = new TreeNode();
                contactinfo.Text = friend[j].Name;
                contactinfo.Type = "Message";
                contactinfo.DataState = XLY.Convert.ToDataState(friend[j].XLY_DataType);
                contactinfo.Items = getMessage(path,friend[j],rootinfo,"联系人会话"); 
                groupinfo.TreeNodes.push(contactinfo);
            }
        }
        else if(name=="讨论组"){
            groupinfo.Items = getMessage(path,info[i],rootinfo); 
            childNode.TreeNodes.push(groupinfo);
        } 
        else if(name=="群组"){            
            groupinfo.Items = getMessage(path,info[i],rootinfo);
            childNode.TreeNodes.push(groupinfo);
        }
    }
}

//********************************************************
var source = $source;
var db = source[0];
var recoverydb = XLY.Sqlite.DataRecovery( db,"","contact,contact_group,contact_group_relation,dgroup,dgroup_member,dgroup_relationship,message,pg_group,user");
var result = new Array();
result.push(bindTree());
var res = JSON.stringify(result);
res;
