﻿/*[config]
<plugin name="途牛旅游,21" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\TuNiu.png" app="com.tuniu.app.ui" version="8.0.2" description="途牛旅游" data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/com.tuniu.app.ui/databases/groupchat.db</value>
<value>/data/data/com.tuniu.app.ui/shared_prefs/TuniuApp.xml</value>
<value>/data/data/com.tuniu.app.ui/shared_prefs/last_know_location.xml</value>
</source>
<data type="MessageInfo" contract="DataState" datefilter="SendTime"> 
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="接收者ID" code="ContactJid" type="string" width="200" format=""></item>
    <item name="发送者ID" code="SendJid" type="string" width="200"></item>
    <item name="发送时间" code="SendTime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="内容" code="Content" type="string" width="300"></item>
</data>
<data type="ContactInfo"> 
    <item name="联系人ID" code="ContactJid" type="string" width="200" format=""></item>
    <item name="昵称" code="NickName" type="string" width="100"></item>
    <item name="添加时间" code="JoinTime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>
<data type="UserInfo"> 
    <item name="昵称" code="NickName" type="string" width="100"></item>
    <item name="出生日期" code="Birthday" type="datetime" width="100" format = "yyyy-MM-dd"></item>
    <item name="性别" code="Sex" type="string" width = "100"></item>
    <item name="年龄" code="Age" type = "int"></item>
    <item name="联系城市" code="ContactCity" type="string" width = "100"></item>
</data>
<data type="TouristUserInfo">  
    <item name="昵称" code="NickName" type="string" width="100"></item>
    <item name="手机号码" code="PhoneNumber" type="string" width="100" ></item>
    <item name="用户地址" code="Address" type="string" width = "200"></item>
    <item name="注册Email" code="Email" type = "string"  width="200"></item>
    <item name="购票使用Email" code="OnlineEmail" type = "string"  width="200"></item>
    <item name="当前城市" code="CurrentCity" type="string" width = "100"></item>
</data>
<data type="PlaneInfo">  
    <item name="时间" code="departDate" type="datetime" width="100" format = "yyyy-MM-dd"></item>
    <item name="起飞城市" code="fromCity" type="string" width="100" ></item>
    <item name="目标城市" code="destCity" type="string" width = "100"></item>
</data>
<data type = "TouristHistory">  
    <item name="姓名" code="Name" type="string" width = "100"></item>
    <item name="出生日期" code="Birthday" type="datetime" width="100" format = "yyyy-MM-dd"></item>
    <item name="证件类型" code="PsptType" type="string" width="100" ></item>
    <item name="证件号" code="PsptID" type="string" width = "250"></item>
    <item name="性别" code="Sex" type="string" width = "100"></item>
    <item name="年龄" code="Age" type="int" width = "100"></item>
</data>
<data type = "TrainHistory">  
    <item name="出发地点" code="fromCity" type="string" width = "100"></item>
    <item name="目标地点" code="destCity" type="string" width="100" ></item>
</data>
<data type="HotelHistory" contract="Map">  
    <item name="入住时间" code="Date" type="datetime" width="100" format = "yyyy-MM-dd"></item>
    <item name="退房时间" code="checkOutDate" type="datetime" width="100" format = "yyyy-MM-dd"></item>
    <item name="酒店名称" code="Desc" type="string" width = "250"></item>
    <item name="经度" code="Longitude" type="double" width = "100"></item>
    <item name="纬度" code="Latitude" type="double" width = "100"></item>
    <item name="价格(元)" code="Price" type="double" width = "100"></item>
</data>
<data type="LastKnowLocation" contract="Map">  
    <item name="时间" code="Date" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="地点" code="Desc" type="string" width = "200"></item>
    <item name="经度" code="Longitude" type="double" width = "100"></item>
    <item name="纬度" code="Latitude" type="double" width = "100"></item>
</data>

</plugin>
[config]*/

//定义数据结构
function MessageInfo() {
    this.Identity = "";
    this.ContactJid = "";
    this.SendJid = "";
    this.SendTime = null;
    this.Content = "";
    this.DataState = "Normal";  
}

function ContactInfo() {
    this.Identity = "";
    this.ContactJid = "";
    this.NickName = "";
    this.JoinTime = null;  
}

function UserInfo() {
    this.Identity = "";
    this.NickName = "";
    this.Birthday = null;  
    this.Sex = "";  
    this.Age = "";  
    this.ContactCity = "";  
}

function TouristUserInfo() {
    this.NickName = "";
    this.PhoneNumber = "";
    this.Address = null;  
    this.Email = "";  
    this.OnlineEmail = "";  
    this.CurrentCity = "";  
}

function PlaneInfo() {
    this.departDate = null;
    this.fromCity = "";
    this.destCity = "";  
}

function TouristHistory() {
    this.Name = "";
    this.Birthday = null;
    this.PsptType = "";  
    this.PsptID = "";  
    this.Sex = "";  
    this.Age = 0;  
}

function TrainHistory() {
    this.fromCity = "";
    this.destCity = "";  
}

function HotelHistory() {
    this.Date = null;
    this.checkOutDate = null;
    this.Desc = "";  
    this.Longitude = 0;  
    this.Latitude = 0;  
    this.Price = 0;  
}

function LastKnowLocation() {
    this.Date = null;
    this.Desc = "";  
    this.Longitude = 0;  
    this.Latitude = 0;  
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//获取用户信息
function getUserInfo(path, sql) {
    var arr = new Array();
    try{
        var flag = XLY.Sqlite.Find(path, sql);
        if (flag.length > 0) {
            var data = eval('(' + flag + ')');
            for (var index in data) {
                var list = new UserInfo();
                list.Identity = data[index].identity;
                list.NickName = data[index].nickname;
                list.Birthday = XLY.Convert.ToDateTime(data[index].birthday,'yyyy-MM-dd');
                list.Sex = data[index].sex == 1 ? '男' : '女';
                list.Age = data[index].age;
                list.ContactCity = data[index].contact_city;
                arr.push(list);
            }
            return arr;
        }
    }
    catch(e){
        return arr;
    }
}

//获取联系人信息
function getContactInfo(path, sql) {
    var arr = new Array();
    try{
        var flag = XLY.Sqlite.Find(path, sql);
        if (flag.length > 0) {
            var data = eval('(' + flag + ')');
            for (var index in data) {
                var list = new ContactInfo();
                list.Identity = data[index].user_identity;
                list.ContactJid = data[index].contact_jid;
                list.NickName = data[index].nickname;
                list.JoinTime = XLY.Convert.ToDateTime(data[index].join_time,'yyyy-MM-dd HH:mm:ss');
                arr.push(list);
            }
            
            return arr;
        }
    }
    catch(e){
        return arr;
    }
}

//获取消息列表
function getMessageInfo(path, sql) {
    var arr = new Array();
    try{
        var flag = XLY.Sqlite.Find(path, sql);
        if (flag.length > 0) {
            var data = eval('(' + flag + ')');
            for (var index in data) {
                var list = new MessageInfo();
                list.Identity = data[index].user_identity;
                list.ContactJid = data[index].contact_jid;
                list.SendJid = data[index].sender_jid;
                list.SendTime = XLY.Convert.LinuxToDateTime(parseInt(data[index].msg_send_time));
                list.Content = data[index].content;
                list.DataState = XLY.Convert.ToDataState(data[index].deleted);
                arr.push(list);
            }
            
            return arr;
        }
    }
    catch(e){
        return arr;
    }
}

function buildTourTree(path){
    var content = eval('('+ XLY.File.ReadXML(path) +')');
    var data = content.map.string;
    var tree = new TreeNode();
    tree.Text = "出行信息";
    tree.Type = "TouristUserInfo";
    tree.Items = getAppInfo(data);
    
    var treePlane = new TreeNode();
    treePlane.Text = "飞机票";
    treePlane.Type = "PlaneInfo";
    treePlane.Items = getPlaneHistory(data);
    
    var treeTrain = new TreeNode();
    treeTrain.Text = "火车票";
    treeTrain.Type = "TrainHistory";
    treeTrain.Items = getTrainHistory(data);
    
    var treeTourist = new TreeNode();
    treeTourist.Text = "乘车人记录";
    treeTourist.Type = "TouristHistory";
    treeTourist.Items = getTouristHistory(data);
    
    var treeHotel = new TreeNode();
    treeHotel.Text = "酒店查询记录";
    treeHotel.Type = "HotelHistory";
    treeHotel.Items = getHotelHistory(data);
    
    tree.TreeNodes.push(treePlane);
    tree.TreeNodes.push(treeTrain);
    tree.TreeNodes.push(treeTourist);
    tree.TreeNodes.push(treeHotel);
    return tree;
}

//获取当前乘客信息
function getAppInfo(data){
    var arr = new Array();
    try{
        var list = new TouristUserInfo();
        list.NickName = getTargetInfoInXML(data, 'nick_name');
        list.PhoneNumber = getTargetInfoInXML(data, 'phone_number');
        list.Address = getTargetInfoInXML(data, 'user_address');
        list.Email = getTargetInfoInXML(data, 'user_email');
        list.OnlineEmail = getTargetInfoInXML(data, 'online_book_user_email');
        list.CurrentCity = getTargetInfoInXML(data, 'current_city');
        arr.push(list);
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取购买飞机票的记录
function getPlaneHistory(data){
    var arr = new Array();
    try{
        var plane = getTargetInfoInXML(data, 'plane_city');
        var obj = Decode(plane);
        for(var i in obj){
            var list = new PlaneInfo();
           list.departDate = XLY.Convert.ToDateTime(obj[i].departureDate,'yyyy-MM-dd');
           list.fromCity = obj[i].orgCityName;
           list.destCity = obj[i].dstCityName;
           arr.push(list);
        }
        
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取火车票历史记录
function getTrainHistory(data){
    var arr = new Array();
    try{
        var plane = getTargetInfoInXML(data, 'train_history');
        var obj = Decode(plane);
        for(var i in obj){
           var list = new TrainHistory();
           list.fromCity = obj[i].departCity.cityName;
           list.destCity = obj[i].arravalCity.cityName;
           arr.push(list);
        }
        
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取乘车人记录
function getTouristHistory(data){
    var arr = new Array();
    try{
        var plane = getTargetInfoInXML(data, 'tourist_history');
        var obj = Decode(plane);
        for(var i in obj){
           var list = new TouristHistory();
           list.Name = obj[i].touristsDetail.name;
           list.Birthday = XLY.Convert.ToDateTime(obj[i].touristsDetail.birthday,'yyyy-MM-dd');
           list.PsptType = obj[i].touristsDetail.psptName;
           list.PsptID = obj[i].touristsDetail.psptId;
           list.Sex = obj[i].touristsDetail.sex == 1 ? '男':'女';
           list.Age = obj[i].touristsDetail.age;
           arr.push(list);
        }
        
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取酒店查询记录
function getHotelHistory(data){
    var arr = new Array();
    try{
        var plane = getTargetInfoInXML(data, 'hotel_browser_history');
        //var code = '['+XLY.Convert.UrlDecode(plane)+']';
        //code = replaceAll(code, '”', '"');
        //code = replaceAll(code, '#',',');
        //code = replaceAll(code, ',]',']');
        //var obj = eval(code);
        var obj = Decode(plane);
        for(var i in obj){
           var list = new HotelHistory();
           list.Date = XLY.Convert.ToDateTime(obj[i].checkInDate,'yyyy-MM-dd');
           list.checkOutDate = XLY.Convert.ToDateTime(obj[i].checkOutDate,'yyyy-MM-dd');
           list.Desc = obj[i].hotelListItem.chineseName;
           list.Longitude = obj[i].hotelListItem.lng;
           list.Latitude = obj[i].hotelListItem.lat;
           list.Price = obj[i].hotelListItem.price;
           arr.push(list);
        }
        
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取最近一次位置信息
function getLastKnowLocation(path){
    var arr = new Array();
    try{
        var data = eval('('+ XLY.File.ReadXML(path) +')');
        var map = data.map;
    
        var list = new LastKnowLocation();
        list.Date = XLY.Convert.LinuxToDateTime(parseInt(map.long['@value']));
        list.Desc = getTargetInfoInXML(map.string, 'province') + getTargetInfoInXML(map.string, 'city') + getTargetInfoInXML(map.string, 'district');
        list.Longitude = getTargetInfoInXML(map.string, 'last_know_lng') ;
        list.Latitude = getTargetInfoInXML(map.string, 'last_know_lat') ;
        arr.push(list);
       
        return arr;
    }
    catch(e){
        return arr;
    }
}

//将文本内容解析为json对象
function Decode(str){
    var code = '['+XLY.Convert.UrlDecode(str)+']';
    code = replaceAll(code, '”', '"');
    code = replaceAll(code, '#',',');
    code = replaceAll(code, ',]',']');
    var obj = eval(code);
    return obj;
}

//获取目标节点的value/text
function getTargetInfoInXML(data,target){
    for(var index in data){
        if(data[index]['@name']==target){
            return data[index]['#text'];
        }
    }
}

//获取目标节点的value/text
function getTargetValueInXML(data,target){
    for(var index in data){
        if(data[index]['@name']==target){
            return data[index]['@value'];
        }
    }
}

function replaceAll(str, oldchar, newchar){
    return str.split(oldchar).join(newchar);
}

var result = new Array();
//源文件
var source = $source;
var dbpath = source[0];
var apppath = source[1];
var locationpath = source[2];

//数据恢复库的生成
//var charactor1="chalib\\Android_TuNiu_V8.0.2\\groupchat.db.charactor";
//dbpath=XLY.Sqlite.DataRecovery( dbpath,charactor1 ,"t_message_private");

//创建登陆过的帐号信息树
var usersql = "select identity,nickname,birthday,sex,age,contact_city from t_user";
var userinfo = getUserInfo(dbpath,usersql);
var userTree = new TreeNode();
userTree.Text = "登录过的用户信息";
userTree.Type = "UserInfo";
userTree.Items = userinfo;

//创建联系人信息树
var contactsql = "select user_identity,nickname,contact_jid,join_time from t_private_contact";
var contactinfo = getContactInfo(dbpath,contactsql);
var contactTree = new TreeNode();
contactTree.Text = "联系人信息";
contactTree.Type = "ContactInfo";
contactTree.Items = contactinfo;

//最后已知的位置信息
var locationinfo = getLastKnowLocation(locationpath);
var locationTree = new TreeNode();
locationTree.Text = "最后已知的位置信息";
locationTree.Type = "LastKnowLocation";
locationTree.Items = locationinfo;

//创建消息树
var msgsql = "select user_identity,sender_jid,contact_jid,msg_send_time,content,deleted from t_message_private";
var msginfo = getMessageInfo(dbpath,msgsql);
var msgTree = new TreeNode();
msgTree.Text = "消息列表";
msgTree.Type = "MessageInfo";
msgTree.Items = msginfo;

//创建乘客出行树
var tourTree = buildTourTree(apppath);

//打印数据
result.push(userTree);
result.push(contactTree);
result.push(msgTree);
result.push(locationTree);
result.push(tourTree);

var res = JSON.stringify(result);
res;
