﻿/*[config]
<plugin name="易信,9" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/yixin.png" app="com.yixin.yixin" version="2.9.0.1680" description="易信" data="$data,ComplexTreeDataSource" >
<source>
<value>com.yixin.yixin</value>
</source>
<data type="Account" contract="">
<item name="用户ID" code="userId" type="string" width="120" format=""></item>
<item name="昵称" code="nick" type="string" width="120" format=""></item>
<item name="签名" code="sign" type="string" width="200" format = ""></item>
<item name="头像" code="headUrl" type="image" width = "150"></item>
</data>
<data type="AllContact" contract = "" >
<item name="联系人ID" code="userId" type="string" width = "70"></item> 
<item name="易信号" code="yxNumber" type="string" width = "150"></item>
<item name="电话" code="phone" type="string" width = "150"></item>
<item name="昵称" code="nick" type="string" width = "70"></item>    
<item name="签名" code="sign" type="string" width = "70"></item>
<item name="头像" code="headUrl" type="image" width = "150"></item>
<item name="地区" code="area" type="string" width = "70"></item>
</data>
<data type="PublicAccount" contract = "" >
<item name="ID" code="userId" type="string" width = "70"></item> 
<item name="易信号" code="yxNumber" type="string" width = "150"></item>
<item name="昵称" code="nick" type="string" width = "70"></item>    
</data>
<data type="Group" contract="">
<item name="群名称" code="Name" type="string" width="170" alignment="left"></item>
<item name="群号" code="Account" type="string" width="110" format=""></item>
<item name="群创建时间" code="CreateTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="165" format = ""></item>
<item name="群成员数" code="Members" type="string" width="200" format=""></item>
<item name="群成员数" code="MemberCount" type="int" format=""></item>
</data>
<data type="Message" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送用户" code="SenderName" type="string" width="120" ></item>
<item name="接收用户" code="ReceiveName" type="string" width="120" ></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="时间" code="Date" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>
</plugin>
[config]*/

//*******************************************定义数据结构********************************************
//定义Account数据结构
function Account() {
    this.userId = "";
    this.nick="";
    this.sign = "";
    this.headUrl = "";
}

function AllContact() {
    this.userId = "";
    this.phone = "";
    this.nick = "";
    this.sign = "";
    this.headUrl = "";
    this.area = "";
}

function PublicAccount() {
    this.userId = "";
    this.yxNumber = "";
    this.nick = "";
}

function Group() {
    this.Name = "";
    this.Account = "";
    this.CreateTime = null;
    this.Creator = "";
    this.Members = "";
    this.MemberCount = 0;
}

//定义Message数据结构
function Message() {
    this.SenderName = "";
    this.ReceiveName = "";
    this.SenderImage = "";
    this.Content = "";
    this.Type = "";
    this.Date = null;
    this.SendState = "";
    this.dataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState ="Normal";
}

// 根据正则表达式，在数组中查找满足条件的项
function findItemByRegexp(itemList,reg) {
    for(var i = 3;i<itemList.length;i++) {
        if(reg.test(itemList[i])) {
            return  itemList[i];        
        }
    }
    
    return "";
}

// 根据正则表达式，在字符串中查找满足条件的字符串
function findStrByRegexp(item,reg) {
    var res = item.match(reg);
    if(res != null && res.length > 0) {
        return res[0];
        } else {
           return "";
        }
   }   

//******************************************* 处理APP数据*******************************************
//获取账号的详细信息
function getAccountInfo(user) {
    var obj = new Account();
    obj.userId = user.userId;
    obj.nick = user.nick;
    obj.sign = user.sign;
    obj.headUrl = user.headUrl;
    return obj;
}

//获取易信账号文件夹列表
function getAccountFileList(fileList) {
    var returnList = new Array();
    var fileRe = /[0-9]{5,10}/;
    for(var index in fileList) {
        if(fileRe.test(fileList[index])) {
            returnList.push(fileList[index]);
        }
    }
    
    return returnList;
}

function getUserInfo(userList,userId) {
    var obj =  new Account();
    for(var index in userList) {
        if(userList[index].userId == userId) {
            obj = getAccountInfo(userList[index]);
            break;
        }
    }
    
    return obj;
}

//获取好友列表
function createContactNode(data)
{
    var arr = new Array();
    try{
        // 提取用户好友列表
        data = data.substr(data.indexOf("uinfo_v0"));
        //re = /\d{5,10}.+([\r]+.+){0,2}/ig;
        re = /\d{5,10}(|).+([\r]+.+){0,2}/ig;
        var userList = data.match(re);
        
        var specialRe = /[\s\u0001\u0003\b]+/g; // 特殊字符匹配
        var singleChar = /xly_xly\wxly_xly/g; // 分隔符中的单个字符匹配
        var regUrl = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
        var splitStr = "xly_xly";
        var item;
        var itemList;
        for (var index = 0;index < userList.length;index++) {
            if(userList[index])
            {               
                var obj = new AllContact();
                item = userList[index].replace(specialRe,splitStr).replace(singleChar,splitStr);  // 替换特殊字符
                itemList = item.split(splitStr);
                obj.userId = itemList[0];
                if(/\d{11}/.test(itemList[1])) {
                    obj.yxNumber = "" ;
                }
                else {
                   obj.yxNumber = itemList[1];
                   itemList.splice(1,1);
                }
                obj.phone = itemList[1];
                obj.nick = itemList[2];
                obj.headUrl = findItemByRegexp(itemList,regUrl);
                obj.area = findStrByRegexp(userList[index],/[\u4e00-\u9fa5]+\s[\u4e00-\u9fa5]+/);
                obj.sign = (itemList[3] != null && itemList[3] != obj.headUrl && obj.area.indexOf(itemList[3]) < 1) ? itemList[3] : ""; // 签名
                arr.push(obj);
            }  
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

function createPublicAccountNode(data) {
    var arr = new Array();
    
    try {
        // 提取公众号列表
        data = data.substring(0,data.indexOf("public_account_list"));
        var re = /\d{5,10}\s+.*\s+.*/ig;
        var publicList = data.match(re);
        
        var specialRe = /[\s\b\u000f]+/g; // 特殊字符匹配
        var splitStr = "xly_xly";
        var item;
        
        for(var index = 0;index < publicList.length;index++) {
            var obj = new PublicAccount();
            item = publicList[index].replace(specialRe,splitStr);  // 替换特殊字符
            item = item.split(splitStr);
            obj.userId = item[0];
            obj.yxNumber = item.length > 3 ? item[1] : "";
            obj.nick = item.length > 3 ? item[2] : item[1];
            arr.push(obj);
        }
        
        return arr;
    }
    catch(e) {
        return arr;
    }
    
}

function createGroupNode(data) {
    var arr = new Array();
    try {
        // 提取群组列表
        var re = /\s\d{5,10}.+(\n+.+){0,4}new_team/ig;
        var groupList = data.match(re);
        
        var specialRe = /[\s\b\u000f]+/g; // 特殊字符匹配
        var splitStr = "xly_xly";
        var item;
        
        for(var index = 0;index < groupList.length;index++) {
            var obj = new Group();
            item = groupList[index].replace(specialRe,splitStr);  // 替换特殊字符
            item = item.split(splitStr);
            obj.Account = item[1];
            if(/\d{5,10}/.test(item[2])) {
                obj.Creator = item[2];
                obj.Name = "";
            } 
            else {
                obj.Creator = item[3];
                obj.Name = item[2];
            }
            obj.CreateTime = groupList[index].match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/)[0]; // 创建时间
            arr.push(obj);
        }
        return arr;
    }
    catch(e) {
        return arr;
    }
    
}

function getGroupMember(data,groupNode) {   
    try {
        // 提取群组成员列表
        var re = /\s\d{5,10}\s+.\s\d{5,10}/ig;
        var groupMemberList = data.match(re); //群组成员列表
        var contactList = createContactNode(data); // 好友列表
        
        var specialRe = /[\s\b\u000f]+/g; // 特殊字符匹配
        var splitStr = "xly_xly";
        var item;
        var user;

        for(var i = 0;i<groupNode.length;i++) {
            for(var j = 0;j<groupMemberList.length;j++) {
                item = groupMemberList[j].replace(specialRe,splitStr);  // 替换特殊字符
                item = item.split(splitStr);
                    if(groupNode[i].Account == item[1]) {
                        user = getUserInfo(contactList,item[2]);
                        groupNode[i].MemberCount = groupNode[i].MemberCount + 1;
                        groupNode[i].Members = groupNode[i].Members + user.userId + "(" + user.nick + "),";
                }
            }
                
            groupNode[i].Members = groupNode[i].Members.substring(0,groupNode[i].Members.lastIndexOf(","));
        }
                
        return groupNode;
    }
    catch(e) {
        return groupNode;
    }
}

//获取好友聊天信息
function getFriendMessageInfo(data, acc, friend) {
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        if(data[index].id != friend.userId && data[index].msg_from_id != friend.userId) {
            continue;
        }
            
        if (data[index].msg_from_id == acc.userId) {
            obj.SenderName = acc.nick;
            obj.ReceiveName = friend.nick;
            obj.SendState = "Send";
            obj.SenderImage = acc.headUrl;
            } else if(data[index].msg_from_id == friend.userId) {
            obj.SenderName = friend.nick;
            obj.ReceiveName = acc.nick;
            obj.SendState = "Receive";
            obj.SenderImage = friend.headUrl;
        }
        
        obj.Type = GetType(data[index].msg_content_type);
        obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data[index].msg_time));
        obj.Content = getContentByType(data[index].msg_body,data[index].msg_content_type,acc.userId);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);      
        info.push(obj);
    }
    return info;
}

// 获取公众号推送信息
function getPublicMessageInfo(data,receiveName,public) {
    var info = new Array();
    
    for (var h in data) {
        if(data[h].id != public.userId) {
                continue;
        }
        var obj = new Message();
        obj.SenderName = public.nick;
        obj.ReceiveName = receiveName;
        obj.SendState = "Receive";
        obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data[h].msg_time));
        obj.Content = data[h].msg_body;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);      
        info.push(obj);
    }
    
    return info;
}

// 获取群组聊天信息
function getGroupMessageInfo(data, group, contactList, acc) {
    var info = new Array();
    var user;
    for (var index in data) {
        var obj = new Message();
        if(data[index].id != group.Account && data[index].msg_from_id != group.Account) {
            continue;
        }

        if(data[index].msg_from_id != "") {
            user = getUserInfo(contactList,data[index].msg_from_id);
        }
        else {
            user = new Account();
        }
        
        obj.SenderName = user.nick;
        obj.SenderImage = user.headUrl;
        obj.ReceiveName = group.Name;
        obj.SendState = "Receive";
        
        obj.Type = GetType(data[index].msg_content_type);
        obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data[index].msg_time));
        obj.Content = getContentByType(data[index].msg_body,data[index].msg_content_type,acc.userId);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);      
        info.push(obj);
    }
    return info;
}

function GetType(type) {
    switch (type) {
          case 1:
            value = "Image";
            break

          case 2:
            value = "Audio";
            break
            
          case 4:
            value = "Location";
            break
            
          case 6:
            value = "Card";
            break
            
          case 1003:
            value = "VideoChat";
            break

        default:
            value = "";
    }
    return value;
}

function getContentByType(content,contentType,userId) {
     switch (contentType) {
      case 1:
         content = eval('('+ content +')');
         value = source + "\\com.yixin.yixin\\Documents\\" + userId + "\\image\\thumb_" + content.filename;
            break
      case 2:
            content = eval('('+ content +')');
            value = source + "\\com.yixin.yixin\\Documents\\" + userId + "\\audio\\" + content["filename"];
            break
        
      case 7:
            content = eval('('+ content +')');
            var filename = content["filename"].replace("\/","\\");
            value = source + "\\com.yixin.yixin\\易信.app\\Origin\\" + filename;
            break

     default:
       value = content;
    }

    return value;
}

//var source = "C:\\XLYSFTasks\\未命名-18\\source\\IosData\\2014-08-26-14-43-44\\";
var source = $source;
var path = source + "\\com.yixin.yixin\\Documents\\";

var result = new Array();


//创建好友聊天记录树结构
function BindContactTree(contactList, loginUser, msgData) {
    // 好友列表
    var contactNode = new TreeNode();   
    contactNode.Text = "好友列表";
    contactNode.Type = "AllContact";
    contactNode.Items = contactList;
    
    // 好友聊天信息
    for(var i = 0;i < contactList.length; i++) {
        if(loginUser.userId == contactList[i].userId) {
            continue;
        }

        var friendMessageNode = new TreeNode();   
        friendMessageNode.Text = contactList[i].nick + "(" + contactList[i].userId + ")";
        friendMessageNode.Type = "Message";       
        friendMessageNode.Items = getFriendMessageInfo(msgData,loginUser,contactList[i]);
        contactNode.TreeNodes.push(friendMessageNode);
    }

    return contactNode;  
}

//创建群组聊天记录树结构
function BindGroupTree(contactList, loginUser, msgData, data) {
    // 群组列表
    var groupList = createGroupNode(data);
    groupList = getGroupMember(data,groupList);
    var groupNode = new TreeNode();
    groupNode.Text = "群组列表";
    groupNode.Type = "Group";
    groupNode.Items = groupList;
    
    // 群组聊天信息
    for(var h = 0;h < groupList.length; h++) {
        var groupMesssageNode = new TreeNode();
        groupMesssageNode.Text = groupList[h].Name + "(" + groupList[h].Account + ")";
        groupMesssageNode.Type = "Message";      
        groupMesssageNode.Items = getGroupMessageInfo(msgData,groupList[h],contactList,loginUser);
        groupNode.TreeNodes.push(groupMesssageNode);
    }
    
    return groupNode;
}

//创建账号树结构
function BindTree()
{
    var fileList = eval('('+ XLY.File.FindDirectories(path) +')');
    fileList = getAccountFileList(fileList);
    var localTree = new TreeNode();
    localTree.Type = "Account";
    localTree.Text = "本地账户信息";
    for (var index = 0; index < fileList.length; index++) {
        var userPath = fileList[index] + "\\core_user_v1.dat";  // 用户列表文件
        var msgPath =  fileList[index] + "\\msg2.db";  // 用户聊天记录数据文件
        
        var newMsgPath = XLY.Sqlite.DataRecovery(msgPath, "chalib\\IOS_YiXin_2.9.0\\msg2.db.charactor", "msglog");
        
        var userId = XLY.File.GetFileName(fileList[index]);
        var data = XLY.File.ReadFile(userPath);
        var msgData = eval('(' + XLY.Sqlite.Find(newMsgPath, "select *,cast(msg_time as text)as msg_time  from msglog where msg_type = 1") + ')');
        var account = new TreeNode();
        account.Type = "Account";
        var contactList = createContactNode(data);  
        var publicAccountList = createPublicAccountNode(data);
        var loginUser = getUserInfo(contactList,XLY.File.GetFileName(fileList[index])); 
        account.Text = loginUser.nick + "(" + loginUser.userId + ")";
        account.Items.push(loginUser);
        localTree.Items.push(loginUser);
        
        // 好友列表
        var contactNode = BindContactTree(contactList, loginUser, msgData);       
        // 群组列表
        msgData = eval('(' + XLY.Sqlite.Find(newMsgPath, "select *,cast(msg_time as text)as msg_time  from msglog where msg_type = 2") + ')');
        var groupNode = BindGroupTree(contactList, loginUser, msgData, data);      
        
        account.TreeNodes.push(contactNode);
        account.TreeNodes.push(groupNode);
        localTree.TreeNodes.push(account);
    }
    
    return localTree;
}

result.push(BindTree());
var res = JSON.stringify(result);
res;
