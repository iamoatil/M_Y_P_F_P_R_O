function loadjs(page, callback) {
	if(page == "" || page == ".js")
		return;
    var src = './data/' + page;
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = src;
    script.charset ="utf-8";
    var head = document.getElementsByTagName('head').item(0);
    head.appendChild(script);
    script.onload = function () {
        callback();
    }
}


