﻿/*[config]
<plugin name="闹钟,10" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\clock.png" app="com.apple.alarm" description="提取IOS设备闹钟信息" data="$data" >
<source>
<value>com.apple.alarm</value>
</source>
<data type="AlarmMsg">
<item name="闹钟名称" code="AlarmName" type="string" width="100" ></item>
<item name="闹钟日期(重复)" code="daysofweek" type="string" width="350" ></item>
<item name="闹钟时间" code="AlarmTime" type="string" width="100" ></item>
<item name="最后修改时间" code="lastModified" type="datetime" width="100" ></item>
</data>
</plugin>
[config]*/

function AlarmMsg() {
    this.AlarmTime = "";
    this.AlarmName = "";
    this.daysofweek = ""; //下一次提醒时间
    this.lastModified = null;
}



function FormatTime(num){
    var res = '';
    if(num<10){
        res = '0'+num;
    }
    else{
        res = num;
    }
    return res;
}


//计算a的b次方
function pow(a, b) {
    if (b == 0)
        return 1;
    var all = a;
    for (var i = 1; i < b; ++i) {
        all *= a;
    }
    return all;
}

//设置数据
function SetDaysOfWeek(all, i) {
    var cong = pow(2, i - 1);
    var temp = 1;
    var can = false;
    for (var j = 0; j < 127; ++j) {
        if (temp > cong) {
            temp = 1;
        }
        if (temp == cong)
            can = !can;
        all[i - 1][j] = can;
        ++temp;
    }
}

// 获取重复提醒转化列表
function GetDaysOfWeekList() {
    var all = new Array();
    for (var i = 0; i < 7; ++i) {
        all[i] = new Array();
        for (var j = 0; j < 127; ++j) {
            all[i][j] = false;
        }
    }
    for (var i = 1; i <= 7; ++i) {
        SetDaysOfWeek(all, i);
    }
    return all;
}

//时间转化
function GetLocalDate(timeStamp) {
    if (timeStamp == null) {
        return null;
    }
    else {
        return XLY.Convert.ToDateTime(1970, 1, 1, timeStamp);
    }
}

//重提醒复列表
var daysofweekList = GetDaysOfWeekList();
var weekList = new Array('星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期天');



function GetAlarmNodeInfo(path) {
    var strData = XLY.PList.ReadToJsonString(path);
    if(strData == null || strData == ''){        
        return '';
    }

    var data = eval('(' + strData + ')');
    var arr = new Array();

    var localIndex = 5;


    for (var networksIndex in data){
        if(data[networksIndex]['Alarms'] != null){
            localIndex = networksIndex;
            break;
        }
    }
    
    //this.ID = 0;
    //this.AlarmTime = "";
//this.lastModified = null;
    if (data == null || data == '') {
        return;
    }
    
    for(var alarmIndex in data[localIndex]['Alarms'][0])
    {
        var obj = new AlarmMsg();  
        var hour = 0;
        var minute = 0;
        
        var daySetting = 0;
        for (var index in data[localIndex]['Alarms'][0][alarmIndex]){                 

            if(data[localIndex]['Alarms'][0][alarmIndex][index].hour != null){
                obj.AlarmTime = FormatTime(data[localIndex]['Alarms'][0][alarmIndex][index].hour);
            }

            if(data[localIndex]['Alarms'][0][alarmIndex][index].minute != null){ 
                obj.AlarmTime = obj.AlarmTime + ':' +FormatTime(data[localIndex]['Alarms'][0][alarmIndex][index].minute);
            }

            if(data[localIndex]['Alarms'][0][alarmIndex][index].lastModified != null){
                obj.lastModified = GetLocalDate(data[localIndex]['Alarms'][0][alarmIndex][index].lastModified); // XLY.Convert.ToDateTime(1970, 1, 1, data[localIndex]['Alarms'][0][alarmIndex][index].lastModified);
            }

            if(data[localIndex]['Alarms'][0][alarmIndex][index].daySetting != null){
                daySetting = data[localIndex]['Alarms'][0][alarmIndex][index].daySetting;
            }

            if (data[localIndex]['Alarms'][0][alarmIndex][index].title != null) {
                if (data[localIndex]['Alarms'][0][alarmIndex][index].title != '$null') {
                    obj.AlarmName = data[localIndex]['Alarms'][0][alarmIndex][index].title;
                }
                else {
                    obj.AlarmName = '未知';
                }
            }


            //recallSet
        }

        for (var k = 0; k < 7; ++k) {
            //XLY.Debug.WriteLine(daysofweekList[k][row.daysofweek]);
            if (daysofweekList[k][daySetting - 1] == true) {
                obj.daysofweek += weekList[k] + '; ';
            }
        }

        if (obj.daysofweek == '') {
            obj.daysofweek = '从不';
        }

        arr.push(obj);
    }
   
    return arr;
}

var source = $source;
var searchPath = source[0];


var searchPath = searchPath + "\\HomeDomain\\Library\\Preferences\\com.apple.mobiletimer.plist";
//var searchPath = "C:\\XLYSFTasks\\任务-2016-04-26-10-06-43\\source\\IosData\\2016-04-26-10-07-11\\0820f053ae51e5c47fdee145b14bc670b8fe24de\\HomeDomain\\Library\\Preferences\\com.apple.mobiletimer.plist";

var result = new Array();
result=GetAlarmNodeInfo(searchPath);
var res = JSON.stringify(result);
res;
