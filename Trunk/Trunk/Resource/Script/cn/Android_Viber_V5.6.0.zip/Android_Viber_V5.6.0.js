﻿/*[config]
<plugin name="Viber,18" group="社交聊天,7" devicetype="android" icon="\icons\viber.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.viber.voip" version="5.6.0" description="Viber" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.viber.voip/databases/viber_data</value>
    <value>/data/data/com.viber.voip/databases/viber_messages</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Account" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="头像" code="Name" type="string" width = "150"></item>
    <item name="号码" code="Num" type="string" width = "200"></item>
    </data>
    <data type="Friend" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="昵称" code="Name" type="string" width = "150"></item>
    <item name="号码或邮箱" code="Num" type="string" width = "200"></item>
    <item name="添加时间" code="Time" type="string" width = "150"></item>
    </data>
    <data type="Group" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="群ID" code="ID" type="string" width = "150"></item>
    <item name="群名称" code="Name" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "150"></item>
    </data>
    <data type="Message" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="发送者" code="Sender" type="string" width = "150"></item>
    <item name="接收者" code="Receiver" type="string" width = "200"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "150"></item>
    <item name="消息类型" code="Type" type="string" show="false" width = "150"></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account(){
    this.DataState = "Normal";
    this.Name = "";
    this.Num = "";
}
function Friend(){
    this.DataState = "Normal";
    this.Name = "";
    this.Num = "";
    this.Time = "";
}
function Group(){
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
    this.Backgroud = "";
    this.Time = "";
}
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Content = "";
    this.Time = "";
    this.Type = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "Viber";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
    accountinfo = getAccount(db1);
    var accoutNode=newTreeNode(accountinfo[0].Name,"Account",accountinfo,news);
    var friendinfo = getFriend(db);
    
    var friendNode = newTreeNode("好友","Friend",friendinfo,accoutNode);
    for(var i in friendinfo){
        newTreeNode(friendinfo[i].Name,"Message",getMessage(db1,friendinfo[i],"好友",accountinfo[0]),friendNode);
    }
    var gourpinfo = getGroup(db1);
    var gourpNode = newTreeNode("群组","Group",gourpinfo,accoutNode);
    for(var i in gourpinfo){
        newTreeNode(gourpinfo[i].Name+"("+gourpinfo[i].ID+")","Message",getMessage(db1,gourpinfo[i],"群组",accountinfo[0]),gourpNode);
    }
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["好友","群组"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from participants_info where participant_type=0" ) +')');
    for(var i in data){
        var obj = new Friend();
        obj.Name = data[i].display_name;
        obj.Num = data[i].number;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFriend(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from phonebookcontact left join phonebookdata where phonebookcontact.[native_id]=phonebookdata.[contact_id]" ) +')');
    for(var i in data){
        var obj = new Friend();
        obj.Name = data[i].display_name;
        obj.Num = data[i].data1;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].joined_date);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from conversations" ) +')');
    for(var i in data){
        if(data[i].group_id!=0){
            var obj = new Group();
            obj.Name = data[i].name;
            obj.ID = data[i].group_id;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}
function getMessage(path,forg,flag,account){
    var list = new Array();
    if(flag=="好友"){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from messages where address = '"+forg.Num+"'" ) +')');
        for(var i in data){
            var obj = new Message();
            if(data[i].type==1){
                obj.Sender = forg.Name;
                obj.Receiver = account.Name;
            }else{
                obj.Receiver = forg.Name;
                obj.Sender = account.Name;
            }
            obj.Content = data[i].body;
            obj.Tpye = data[i].extra_mime;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
            list.push(obj);
        }
    }else if(flag=="群组"){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from messages" ) +')');
        for(var i in data){
            if(data[i].group_id==forg.ID){
                var obj = new Message();
                obj.Receiver = forg.Name+"("+forg.ID+")";
                if(data[i].type==1){
                    obj.Sender = account.Name;
                }else{
                    var send=eval('('+ XLY.Sqlite.Find(path,"select * from participants_info where number = '"+data[i].address+"'" ) +')');
                    if(send[0]!=null){
                        obj.Sender = send[0].display_name;;
                    }
                }
                obj.Content = data[i].body;
                obj.Tpye = data[i].extra_mime;
                obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
                list.push(obj);
            }
        }
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
//var db = "D:\\temp\\data\\data\\com.viber.voip\\databases\\viber_data";
//var db1 = "D:\\temp\\data\\data\\com.viber.voip\\databases\\viber_messages";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
