﻿//descritpion:短信(SMS)模板

/*[config]
<plugin name="闹钟,13" group="基本信息,1" devicetype="android" pump="usb,Mirror,chip,Raid" icon="\icons\clock.png" app="" description="" data="$data" version="">
    <source>
        <value>/data/data/com.htc.android.worldclock/#F</value>
        <value>/data/data/com.android.alarmclock/databases/#F</value>
        <value>/data/data/com.android.deskclock/databases/#F</value>
	<value>/data/data/com.yulong.android.xtime/databases/#F</value>
    <value>/data/data/cn.nubia.deskclock.preset/databases/#F</value>
    </source>

    <data contract="DataState,Mail">
	<item name="时" code="hour" type="int" width=""></item>
	<item name="分" code="minutes" type="int" width="" format=""></item>
	<item name="重复类型" code="daysofweek" type="string" width="300" format=""></item>
	<item name="重复提醒" code="daysofweek" type="string" width="300" format=""></item>
	<item name="是否启用" code="enabled" type="string" width="" ></item>
	<item name="是否震动" code="vibrate" type="string" width="" ></item>
	<item name="提示铃声" code="alert" type="string" width="" ></item>
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="提示消息" code="message" type="string" width="" ></item> 
    </data>
</plugin>
[config]*/

// js content

function Item() {
    this.hour = 0; //小时
    this.minutes = 0; //分钟
    this.daysofweek = ""; //下一次提醒时间
    this.enabled = "";//是否启用
    this.vibrate = ""; //是否震动
    this.message = ""; //提示消息
    this.alert = ""; //提示铃声
}


var result = new Array();
//源文件
var source = $source;

var db ='';

for (var i in source) {
    var s = source[i];
    if (s != null && s != '') {
        if (XLY.File.FindFiles(s) != '')  //路径存在
        {
            db = s + "\\alarms.db";
        }
    }
}

//var db = "D:\temp\\data\\data\\com.android.deskclock\\databases\\alarms.db";

//计算a的b次方
function pow(a,b){
    if(b==0)
        return 1;
    var all = a;
    for(var i=1;i<b;++i){
        all *= a;
    }
    return all;
}

//设置数据
function SetDaysOfWeek(all,i){
    var cong = pow(2, i -1);
    var temp = 1;
    var can = false;
    for(var j = 0;j<127;++j){
         if(temp>cong){
            temp=1;
        }
        if(temp == cong)
            can = !can;
        all[i-1][j]=can;
        ++temp;
    }
}

// 获取重复提醒转化列表
function GetDaysOfWeekList(){
    var all = new Array();
    for(var i=0;i<7;++i){
        all[i] = new Array();
        for(var j=0;j<127;++j){
            all[i][j] = false;
        }    
    }
    for(var i=1;i<=7;++i){
        SetDaysOfWeek(all,i);
    }
    return all;
}

//重提醒复列表
var daysofweekList = GetDaysOfWeekList();

//XLY.Debug.WriteLine(daysofweekList );
var weekList = new Array('星期一','星期二','星期三','星期四','星期五','星期六','星期天');

var db_recovery = XLY.Sqlite.DataRecovery(db, '', "alarms");
var dblist = eval('(' + XLY.Sqlite.FindByName(db_recovery, 'alarms') + ')');

for (var i in dblist) {
    var row = dblist[i];
    var obj = new Item();
    //do sth
    obj.DataState = XLY.Convert.ToDataState(row.XLY_DataType);

    obj.hour = row.hour;
    obj.minutes = row.minutes;
    
    for(var k=0;k<7;++k){
        //XLY.Debug.WriteLine(daysofweekList[k][row.daysofweek]);
        if(daysofweekList[k][row.daysofweek - 1] == true){
            obj.daysofweek += weekList[k] +'; ';
        }
   }

    if(obj.daysofweek == ''){
        obj.daysofweek = '从不';
    }

    //obj.alarmtime = XLY.Convert.LinuxToDateTime(row.alarmtime);
    obj.enabled = row.enabled == 1 ? '是' : '否';
    obj.vibrate = row.vibrate == 1 ? '是' : '否';
    obj.message = row.message;
    obj.alert = row.alert;
    //add item
    result.push(obj);
}


// return
var res = JSON.stringify(result);
res;
