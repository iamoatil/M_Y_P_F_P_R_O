﻿/*[config]
<plugin name="139邮箱,5" group="主流邮箱,4"  devicetype="android" pump="USB,Mirror,Wifi,Bluetooth,chip,Raid" version="6.3.1" app="cn.cj.pe" icon = "\icons\139mail.png" description="139邮箱" data="$data,TreeDataSource">
   <source>
       <value>/data/data/cn.cj.pe/databases#F</value>
   </source>

   <data type="Message" detailfield="Content">
        <item name="发件人" code="Send" type="string" width="150" format=""></item>
        <item name="收件人" code="Receive" type="string" width="300" format=""></item>
        <item name="发送时间" code="SendTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
        <item name="主题" code="Subject" type="string" width="200" format=""></item>
        <item name="邮件内容" code="Content" type="string" width="200" format=""></item>
        <item name="阅读状态" code="IsRead" type="string" width="150" format=""></item>
   </data>
</plugin>
[config]*/
//********************************************* 定义数据结构*********************************************


//定义Message数据结构
function Message() {
    this.Send = "";
    this.Receive = "";
    
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.IsReply = "";
    this.Content = "";
    this.IsRead = "";
    this.IsMark = "";
    this.IsAttach = "";

}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}


var source = $source;
var path = source[0];
//var path =  "D:\\temp\\data\\data\\cn.cj.pe\\databases\\";
//获取db文件，db文件为MD5加密，暂时处理方法是获取文件名最长的db文件
var fs = eval('('+ XLY.File.FindFiles(path) +')'); 
var mlen = 0;
var index = 0;
var part = new RegExp(".*\.db$");
for(var i in fs){
    var len = fs[i].length;
    if(len>mlen && part.test(fs[i]) ){
        mlen = len;
        index = i;
    }
}
path = fs[index];


var result = new Array();
buildChildNodes(result,path);
var res = JSON.stringify(result);
res;



//创建帐号节点的子节点
function buildChildNodes(nodes,path) {
    var fileInfo = eval('(' + XLY.Sqlite.Find(path, "select * from folders") + ')');
    var len = fileInfo.length;
    
    for(var info in fileInfo){
        var childNode = new TreeNode();
        childNode.Type = "Message";
        childNode.Text = fileInfo[info].name;
        var id = fileInfo[info].id;
        childNode.Items = getMessageInfoForChildNodes(id,path);
        nodes.push(childNode);
    }
}

//获取邮件信息
function getMessageInfoForChildNodes(accid,path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from messages where folder_id='" + accid + "' ") + ')');
    var info = new Array();
    for (var index in data) {

        var obj = new Message();
        obj.Send = data[index].sender_list;
        obj.SendTime = XLY.Convert.LinuxToDateTime(data[index].date);
        obj.Receive = data[index].to_list;
        obj.Subject = data[index].subject;
        obj.IsRead = (data[index].read == 1) ? "已阅" : "未读";
        obj.Content = data[index].preview;
        if(obj.Subject!=null){
            info.push(obj);     
        }
    }
    return info;
}


