﻿/*[config]
<plugin name="360浏览器,4" group="Web痕迹,4" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\qihooBrowser.png" app="com.qihoo.browser" version="5.4.1" description="360浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.qihoo.browser/databases/browser.db</value>
<value>/data/data/com.qihoo.browser/databases/downloads.db</value>
<value>/data/data/com.qihoo.browser/databases/webviewCookiesChromium.db</value>
</source>
<data type="FrequentLink" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format=""></item>
<item name="创建时间" code="Time" type="datetime" order="asc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Visits" type="string" width="100" format=""></item>
</data>

<data type="History" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="400" format=""></item>
<item name="URL地址" code="Url" type="url" width="200" format=""></item>
<item name="访问时间" code="Time"  type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Visits" order="desc" type="string" width="100" format=""></item>
</data>

<data type="Bookmark" contract="DataState" datefilter="Created">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="300" format=""></item>
<item name="URL地址" code="Url" type="url" width="500" format=""></item>
<item name="创建时间" code="Created" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="修改时间" code="Modified" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="SerachWords" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="KeyWords" type="string" width="100" format=""></item>
<item name="搜索时间" code="Time" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="DownloadFile" contract="DataState" datefilter="Title">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="标题" code="Title" type="string" width="200" format=""></item>
<item name="文件地址" code="Url" type="url" width="400" format=""></item>
<item name="总大小" code="ToalBytes" type="string" width="100" format=""></item>
<item name="当前大小" code="CurrentBytes" type="string" width="100" format=""></item>
<item name="存储路径" code="SaveFile" type="string" width="200" format=""></item>
<item name="文件类型" code="FileType" type="string" width="240" format=""></item>
<item name="请求状态" code="Status" type="string" width="100" format=""></item>
<item name="Cookie" code="CookieData" type="string" width="100" format=""></item>
<item name="描述" code="Description" type="string" width="150" format=""></item>
</data>

<data type="Cookies" contract="DataState" datefilter="LastTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="地址" code="Address" type="string" width="100" format=""></item>
<item name="创建时间" code="CreateTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="过期时间" code="ExpireTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="Key" code="CookieName" type="string" width="160" format=""></item>
<item name="Value" code="CookieValue" type="string" width="400" format=""></item>
<item name="最后认证时间" code="LastTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/
//定义数据结构

//***remark***
//*** Author:ljw
//*** DateTime:2014:06:16
//***remark***
//常用链接
function FrequentLink() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Visits = "";
}
//历史记录
function History() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Visits = "";
}
//收藏地址
function Bookmark() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Created = "";
    this.Modified = "";
}
//搜索关键字
function SerachWords() {
    this.DataState = "Normal";
    this.KeyWords = "";
    this.Time = null;
}
//下载文件
function DownloadFile() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.ToalBytes = "";
    this.CurrentBytes = "";
    this.SaveFile = "";
    this.FileType = "";
    this.Status = "";
    this.CookieData = "";
    this.Description = "";
}
//Cookies
function Cookies() {
    this.DataState = "Normal";
    this.CreateTime = null;
    this.LastTime = null;
    this.ExpireTime = null;
    this.Address = "";
    this.CookieName = "";
    this.CookieValue = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//===========================================开始解析内容=================================
var result = new Array();
var source = $source;
var chailb = "chalib\\Android_360Browser_V5.4.1\\browser.db.charactor,chalib\\Android_360Browser_V5.4.1\\downloads.db.charactor,chalib\\Android_360Browser_V5.4.1\\webviewCookiesChromium.db.charactor".split(',');
//var chailb = "D:\\work\\Plugin\\Android_360Browser_V5.4.1\\browser.db.charactor,D:\\work\\Plugin\\Android_360Browser_V5.4.1\\downloads.db.charactor,D:\\work\\Plugin\\Android_360Browser_V5.4.1\\webviewCookiesChromium.db.charactor".split(','); //特征库文件
//var source = "D:\\temp\\HTC\\data\\data\\com.qihoo.browser\\databases\\browser.db,D:\\temp\\HTC\\data\\data\\com.qihoo.browser\\databases\\downloads.db,D:\\temp\\HTC\\data\\data\\com.qihoo.browser\\databases\\webviewCookiesChromium.db".split(',');

var isNewDb = true;
//执行SQL信息。
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}
// string.format
String.prototype.format = function (args) {
    var result = this;
    if (arguments.length > 0) {
        var reg;
        if (arguments.length == 1 && typeof (args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    reg = new RegExp("({" + key + "})", "g");
                    result = result.replace(reg, args[key]);
                }
            }
        }
        else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    reg = new RegExp("({)" + i + "(})", "g");
                    result = result.replace(reg, arguments[i]);
                }
            }
        }
    }
    return result;
};
//初始化SQL
function GetSql(parm, tablename, where) {
    var sqlStr = "select {0} from {1} ";
    if (!isNewDb) {
        // 旧数据库SQL
        var sql = sqlStr.format(parm, tablename);
        if (where != "") {
            sql += " where 1>0 " + where;
        }
        return sql;
    } else {
        if (parm.indexOf("XLY_DataType") < 0)
            parm += ",XLY_DataType";
        var sql = sqlStr.format(parm, tablename);
        if (where != "") {
            sql += " where 1>0 " + where;
        }
        return sql;
    }
}

//Browser分析
function BrowserAnalyse(filepath, chailbpath, qihooTreeChildNode) {
    var tablelist = "bookmarks,frequent_visit,history,searches";
    var dbpath = XLY.Sqlite.DataRecovery(filepath, chailbpath, tablelist);
    if (dbpath == filepath) {
        isNewDb = false;
    }
    //常用链接
    //构造快速链接地址九宫格
    var tmpsql = GetSql("(_id) as id ,title,url,created,visits,type", "frequent_visit", "");
    var frequentdata = ExecSql(dbpath, tmpsql);
    qihooTreeChildNode = new TreeNode();
    qihooTreeChildNode.type = "FrequentLink";
    qihooTreeChildNode.Text = "常用链接";
    for (var entity in frequentdata) {
        var freitem = new FrequentLink();
        freitem.DataState = XLY.Convert.ToDataState(frequentdata[entity].XLY_DataType);
        freitem.Time = XLY.Convert.LinuxToDateTime(parseInt(frequentdata[entity].created));
        freitem.Url = XLY.Convert.ToString(frequentdata[entity].url);
        freitem.Title = XLY.Convert.ToString(frequentdata[entity].title);
        freitem.Visits = frequentdata[entity].visits;
        qihooTreeChildNode.Items.push(freitem);
    }
    //qihooTreeParentNode.TreeNodes.push(qihooTreeChildNode); 去掉一级树节点
    result.push(qihooTreeChildNode);
    //收藏夹
    tmpsql = GetSql("(_id) as id ,title,url,created,last_modify_time as modifydate", "bookmarks", "");
    var bookmarkdata = ExecSql(dbpath, tmpsql);
    qihooTreeChildNode = new TreeNode();
    qihooTreeChildNode.Text = "收藏夹";
    qihooTreeChildNode.type = "Bookmark";
    for (var entity in bookmarkdata) {
        var newitem = new Bookmark();
        newitem.DataState = XLY.Convert.ToDataState(bookmarkdata[entity].XLY_DataType);
        newitem.Created = XLY.Convert.LinuxToDateTime(parseInt(bookmarkdata[entity].created));
        newitem.Url = XLY.Convert.ToString(bookmarkdata[entity].url);
        newitem.Title = XLY.Convert.ToString(bookmarkdata[entity].title);
        newitem.Modified = bookmarkdata[entity].modifydate;
        qihooTreeChildNode.Items.push(newitem);
    }
    //qihooTreeParentNode.TreeNodes.push(qihooTreeChildNode); 去掉一级树节点
    result.push(qihooTreeChildNode);
    //历史记录
    tmpsql = GetSql("(_id) as id ,title,url,created,visits", "history", "");
    var historykdata = ExecSql(dbpath, tmpsql);
    qihooTreeChildNode = new TreeNode();
    qihooTreeChildNode.Text = "历史记录";
    qihooTreeChildNode.type = "History";
    for (var entity in historykdata) {
        var newitem = new History();
        newitem.DataState = XLY.Convert.ToDataState(historykdata[entity].XLY_DataType);
        newitem.Time = XLY.Convert.LinuxToDateTime(parseInt(historykdata[entity].created));
        newitem.Url = XLY.Convert.ToString(historykdata[entity].url);
        newitem.Title = XLY.Convert.ToString(historykdata[entity].title);
        newitem.Visits = historykdata[entity].visits;
        qihooTreeChildNode.Items.push(newitem);
    }
    //qihooTreeParentNode.TreeNodes.push(qihooTreeChildNode);去掉一级树节点
    result.push(qihooTreeChildNode);
    //搜索关键字
    tmpsql = GetSql("(_id) as id ,search,date", "searches", "");
    var historykdata = ExecSql(dbpath, tmpsql);
    qihooTreeChildNode = new TreeNode();
    qihooTreeChildNode.Text = "搜索关键字";
    qihooTreeChildNode.type = "SerachWords";
    for (var entity in historykdata) {
        var newitem = new SerachWords();
        newitem.DataState = XLY.Convert.ToDataState(historykdata[entity].XLY_DataType);
        newitem.Time = XLY.Convert.LinuxToDateTime(parseInt(historykdata[entity].date));
        newitem.KeyWords = XLY.Convert.ToString(historykdata[entity].search);
        qihooTreeChildNode.Items.push(newitem);
    }
    //qihooTreeParentNode.TreeNodes.push(qihooTreeChildNode);去掉一级树节点
    result.push(qihooTreeChildNode);
    //return qihooTreeParentNode;

}

//Download分析
function DownloadAnalyse(filepath, chailbpath, qihooTreeChildNode) {
    //下载文件记录
    var tablelist = "downloads,request_headers";
    var dbpath = XLY.Sqlite.DataRecovery(filepath, chailbpath, tablelist);
    if (dbpath == filepath) {
        isNewDb = false;
    }
    var tmpsql = GetSql("_id id,uri,hint savefile,mimetype filetype,status,total_bytes,current_bytes,title,description,t2.value cookiedata,t1.XLY_DataType", "downloads t1,request_headers t2", " and t1._id=t2.download_id and t2.header='cookie'");
    var downloadfiletdata = ExecSql(dbpath, tmpsql);
    qihooTreeChildNode = new TreeNode();
    qihooTreeChildNode.type = "DownloadFile";
    qihooTreeChildNode.Text = "下载文件";
    for (var entity in downloadfiletdata) {
        var newitem = new DownloadFile();
        newitem.DataState = XLY.Convert.ToDataState(downloadfiletdata[entity].XLY_DataType);
        newitem.CookieData = XLY.Convert.ToString(downloadfiletdata[entity].cookiedata);
        newitem.Url = XLY.Convert.ToString(downloadfiletdata[entity].uri);
        newitem.Title = XLY.Convert.ToString(downloadfiletdata[entity].title);
        newitem.ToalBytes = downloadfiletdata[entity].total_bytes;
        newitem.CurrentBytes = downloadfiletdata[entity].current_bytes;
        newitem.Description = XLY.Convert.ToString(downloadfiletdata[entity].description);
        newitem.SaveFile = downloadfiletdata[entity].savefile;
        newitem.FileType = downloadfiletdata[entity].filetype;
        newitem.Status = downloadfiletdata[entity].status;
        qihooTreeChildNode.Items.push(newitem);
    }
    //qihooTreeParentNode.TreeNodes.push(qihooTreeChildNode);去掉一级树节点
    result.push(qihooTreeChildNode);
    //return qihooTreeParentNode;
}

//Cookies分析
function CookieAnalyse(filepath, chailbpath, qihooTreeChildNode) {
    //浏览器Cookie
    var tablelist = "cookies";
    var dbpath = XLY.Sqlite.DataRecovery(filepath, chailbpath, tablelist);
    if (dbpath == filepath) {
        isNewDb = false;
    }
    var tmpsql = GetSql("creation_utc createtime,host_key address,name key,value, last_access_utc lasttime,expires_utc expiretime", "cookies", "");
    var cookietdata = ExecSql(dbpath, tmpsql);
    qihooTreeChildNode = new TreeNode();
    qihooTreeChildNode.type = "Cookies";
    qihooTreeChildNode.Text = "Cookie";
    for (var entity in cookietdata) {
        var newitem = new Cookies();
        newitem.DataState = XLY.Convert.ToDataState(cookietdata[entity].XLY_DataType);
        newitem.Address = XLY.Convert.ToString(cookietdata[entity].address);
        newitem.CreateTime = XLY.Convert.LinuxToDateTime(parseInt(cookietdata[entity].createtime));
        newitem.LastTime = XLY.Convert.LinuxToDateTime(parseInt(cookietdata[entity].lasttime));
        newitem.ExpireTime = XLY.Convert.LinuxToDateTime(parseInt(cookietdata[entity].expiretime));
        newitem.CookieName = XLY.Convert.ToString(cookietdata[entity].key);
        newitem.CookieValue = XLY.Convert.ToString(cookietdata[entity].value);
        qihooTreeChildNode.Items.push(newitem);
    }
    //qihooTreeParentNode.TreeNodes.push(qihooTreeChildNode);
    result.push(qihooTreeChildNode);
    //return qihooTreeParentNode;
}
function getresult() {
//    var qihooTreeParentNode = new TreeNode(); 去掉一级节点，与系统统一
//    qihooTreeParentNode.Text = "360浏览器";
//    qihooTreeParentNode.Type = "";
    var qihooTreeChildNode;
    BrowserAnalyse(source[0], chailb[0],  qihooTreeChildNode);
    DownloadAnalyse(source[1], chailb[1],  qihooTreeChildNode);
    CookieAnalyse(source[2], chailb[2], qihooTreeChildNode);
}
getresult();
var res = JSON.stringify(result);
res;
