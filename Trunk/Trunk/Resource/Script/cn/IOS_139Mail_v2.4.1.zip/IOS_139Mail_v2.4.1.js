﻿/*[config]
<plugin name="139邮箱,5" group="主流邮箱,4"  devicetype="IOS" pump="USB,Mirror,Wifi,Bluetooth,chip,Raid" version="2.4.1" app="com.leadtone.mig.139pe.iPhone" icon = "\icons\139mail.png" description="139邮箱" data="$data,TreeDataSource">
   <source>
       <value>com.leadtone.mig.139pe.iPhone</value>
   </source>

   <data type="Message" detailfield="Content">
        <item name="发件人" code="Send" type="string" width="150" format=""></item>
        <item name="收件人" code="Receive" type="string" width="300" format=""></item>
        <item name="发送时间" code="SendTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
        <item name="主题" code="Subject" type="string" width="200" format=""></item>
        <item name="邮件内容" code="Content" type="string" width="320" format=""></item>
        <item name="阅读状态" code="IsRead" type="string" width="150" format=""></item>
   </data>
</plugin>
[config]*/
//********************************************* 定义数据结构*********************************************


//定义Message数据结构
function Message() {
    this.Send = "";
    this.Receive = "";
    
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.IsReply = "";
    this.Content = "";
    this.IsRead = "";
    this.IsMark = "";
    this.IsAttach = "";

}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}


var source = $source;
var path = source[0]+"com.leadtone.mig.139pe.iPhone\\Documents\\db";
//var path =  "D:\\temp\\data\\AppDomain-com.leadtone.mig.139pe.iPhone\\Documents\\db\\";

var fs = eval('('+ XLY.File.FindFiles(path) +')'); 
var dbf = fs[0];


var result = new Array();
buildChildNodes(result,dbf);
var res = JSON.stringify(result);
res;


//创建帐号节点的子节点
function buildChildNodes(nodes,path) {
    var fileInfo = eval('(' + XLY.Sqlite.Find(path, "select * from folders") + ')');
    var len = fileInfo.length;
    
    for(var info in fileInfo){
        var childNode = new TreeNode();
        childNode.Type = "Message";
        childNode.Text = fileInfo[info].fname;
        var id = fileInfo[info].folderId;
        childNode.Items = getMessageInfoForChildNodes(id,path);
        nodes.push(childNode);
    }
}

//获取邮件信息
function getMessageInfoForChildNodes(accid,path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from mailhead where folder='" + accid + "' ") + ')');
    var info = new Array();
    for (var index in data) {

        var obj = new Message();
        obj.Send = data[index].Mform;
        obj.SendTime = data[index].date;
        obj.Receive = data[index].Mto;
        obj.Subject = data[index].subject;
        obj.IsRead = (data[index].originalFlags == 1) ? "已阅" : "未读";
        obj.Content = data[index].bodyplainText;
        if(obj.Subject!=null){
            info.push(obj);     
        }
    }
    return info;
}


