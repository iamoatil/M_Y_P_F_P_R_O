﻿/*[config]
<plugin name="Safari,5" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\safari.png" app="com.apple.Safari" version="10.2.1" description="LANGKEY_TiQuIOSSheBeiLiuLanQiXinXi_05201" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.apple.Safari</value>
    HomeDomain\Library\Safari\Bookmarks.db
    com.apple.mobilesafari\Library\Safari\History.db
</source>
<data type="BookMark" contract="DataState">
<item name="LANGKEY_ShuJuZhuangTai_05202" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="LANGKEY_ShuQianMingCheng_05203" code="BookMark" type="string" width = "200" ></item>
<item name="LANGKEY_WangZhi_05204" code="Url" type="string" width="200" ></item>
<item name="LANGKEY_ZuiHouXiuGaiRiQi_05205" code="Data" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="150" ></item>
</data>

<data type="History" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="网站名" code="BookMark" type="string" width = "200" ></item>
<item name="网址" code="Url" type="string" width="200" ></item>
<item name="最后浏览日期" code="Data" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="150" ></item>
</data>
</plugin>
[config]*/

function BookMark(){
    this.BookMark = "";
    this.Url = "";
    this.Data = null;
    this.DataState = "Normal"
}
function History(){
    this.BookMark = "";
    this.Url = "";
    this.Data = null;
    this.DataState = "Normal"
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

var result = new Array();
var source = $source;
var searchPath = source[0];
var path2 = searchPath + "\\HomeDomain\\Library\\Safari\\Bookmarks.db";
var path3 = searchPath + "\\com.apple.mobilesafari\\Library\\Safari\\History.db";
//var path2 = "D:\\temp\\data\\data\\Safari\\Bookmarks.db";
//var path3 = "D:\\temp\\data\\data\\Safari\\History.db";
//var charactor = "D:\\temp\\data\\data\\Safari\\Bookmarks.db.charactor";
//var charactor1 = "D:\\temp\\data\\data\\Safari\\History.db.charactor";
var charactor = "chalib\\IOS_Safari_V10.2.1\\Bookmarks.db.charactor";
var charactor1 = "chalib\\IOS_Safari_V10.2.1\\History.db.charactor";
var path = XLY.Sqlite.DataRecovery(path2,charactor ,"bookmarks" );
var path1 = XLY.Sqlite.DataRecovery(path3,charactor1 ,"history_visits,history_items" );
//var path = XLY.Sqlite.DataRecovery(searchPath, chailb, "bookmarks");


function ParesCore(){
    var safariNode = new TreeNode();
    safariNode.Text = "Safari"
    var bmNode = new TreeNode();
    bmNode.Text = "书签";
    bmNode.Type = "BookMark";
    bmNode.Items = GetBookMark();
    safariNode.TreeNodes.push(bmNode);
    
    var hisNode = new TreeNode();
    hisNode.Text = "历史浏览";
    hisNode.Type = "History";
    hisNode.Items = GetHistory(path1);
    safariNode.TreeNodes.push(hisNode);
    
    result.push(safariNode);
}

//获取书签
function GetBookMark(){
    var db = eval('(' + XLY.Sqlite.FindByName(path, "bookmarks") + ')');
    var Items = new Array();
    for(var i in db){
        var bm = new BookMark();
        bm.BookMark = db[i].title;
        bm.Url = db[i].url;
        bm.Data = XLY.Convert.LinuxToDateTime(db[i].last_modified);
        bm.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(bm);
    }
    return Items;
}
//获取历史记录
function GetHistory(path){
    var db = eval('(' + XLY.Sqlite.Find(path1, "select * from history_visits left join history_items on history_visits.history_item = history_items.id") + ')');
    var Items = new Array();
    for(var i in db){
        var bm = new History();
        bm.BookMark = db[i].title;
        bm.Url = db[i].url;
        bm.Data = XLY.Convert.LinuxToDateTime(db[i].visit_time+978307200);
        bm.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(bm);
    }
    return Items;
}
ParesCore()
var res = JSON.stringify(result);
res;
