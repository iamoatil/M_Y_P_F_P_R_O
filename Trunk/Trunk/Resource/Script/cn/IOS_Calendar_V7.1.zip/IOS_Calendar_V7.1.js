﻿/*[config]
<plugin name="日历,7" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\Calendar.png" app="com.apple.Calendar" version="7.1" description="提取IOS设备日历信息" data="$data,ComplexTreeDataSource" >
<source>
<value>com.apple.Calendar</value>
</source>

<data type="CalendarMsg" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="分类" code="Title" type="string" width="150" ></item>
<item name="备注信息" code="Summary" type="string" width="200" ></item>
<item name="创建日期" code="InDate" type="datetime" width="150" ></item>
<item name="开始日期" code="StartDate" type="datetime" width="150" ></item>
<item name="结束日期" code="EndDate" type="datetime" width="150" ></item>
<item name="最后修改日期" code="LastEditDate" type="datetime" width="150" ></item>
</data>

<data type="CatalogueMsg" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="分类" code="Title" type="string" width="150" ></item>
</data>

</plugin>
[config]*/

/*定义数据结构*/
function CalendarMsg() {
    this.DataState = "Normal";
    this.CalendarID = "";
    this.Summary = "";
    this.Title = "";
    this.InDate = null;
    this.EndDate = null;
    this.StartDate = null;
    this.LastEditDate = null;
}

function CatalogueMsg() {
    this.DataState = "Normal";
    this.Title = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

function GetLocalDate(timeStamp) {
    if (timeStamp == null) {
        return null;
    }
    else {
        return XLY.Convert.ToDateTime(2001, 1, 1, timeStamp);
    }
}

function GetCalendarCatalogue(itemPath) {
    var data = eval('(' + XLY.Sqlite.Find(itemPath, " SELECT CLD.[XLY_DataType],CLD.[title] AS Title FROM Calendar CLD ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new CatalogueMsg();
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.Title = data[index].Title;
        info.push(obj)
    }
    return info;
}

function GetCalendarItemInfo(itemPath) {
    var data = eval('(' + XLY.Sqlite.Find(itemPath, " SELECT CLDI.[XLY_DataType], CLDI.[Calendar_id] AS CalendarID, CLD.[title] AS Title, CLDI.[summary] AS Summary, CAST(CLDI.[start_date] AS Text) AS StartDate, CAST(CLDI.[end_date] AS Text) AS EndDate, CAST(CLDI.[last_modified] AS Text) AS LastEditDate, CAST(CLDI.[creation_date] AS Text) AS InDate FROM CalendarItem CLDI LEFT JOIN Calendar CLD ON CLD.RowID = CLDI.[calendar_id] ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new CalendarMsg();
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.CalendarID = data[index].CalendarID;
        obj.Title = data[index].Title;
        obj.Summary = data[index].Summary;
        obj.StartDate = GetLocalDate(data[index].StartDate);
        obj.EndDate = GetLocalDate(data[index].EndDate);
        obj.InDate = GetLocalDate(data[index].InDate);
        obj.LastEditDate = GetLocalDate(data[index].LastEditDate);
        info.push(obj)
    }
    return info;
}

var basicInfo = null;
var tableList = "Calendar,CalendarItem";
var source = $source;
var searchPath = source[0];
 searchPath = searchPath + "\\HomeDomain\\Library\\Calendar\\Calendar.sqlitedb";

//var searchPath = "D:\\temp\\aeb86051f46399722e23cfcfef43feba2be70d61\\HomeDomain\\Library\\Calendar\\Calendar.sqlitedb";
//var chailb = "D:\\work\\SFProject\\Source\\21-Build\\";
var chailb = chailb + "chalib\\IOS_Calendar\\Calendar_V7.sqlitedb.charactor";
var dbpath = XLY.Sqlite.DataRecovery(searchPath, chailb, tableList);
var searchPath = dbpath;

var result = new Array();


var CatalogueNode = new TreeNode();
CatalogueNode.Text = "日历分类列表";
CatalogueNode.Type = "CatalogueMsg";
CatalogueNode.Items = GetCalendarCatalogue(searchPath);
result.push(CatalogueNode);

var CalendarItemNode = new TreeNode();
CalendarItemNode.Text = "日历";
CalendarItemNode.Type = "CalendarMsg";
CalendarItemNode.Items = GetCalendarItemInfo(searchPath);
result.push(CalendarItemNode);

var res = JSON.stringify(result);
res;
