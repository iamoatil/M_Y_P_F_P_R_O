﻿

/*[config]
<plugin name="Chrome浏览器,4" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Chrome.png" app="com.android.chrome" version="39.0.2171.59" description="Chrome浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>data/data/com.android.chrome/app_chrome/Default/History</value>
<value>data/data/com.android.chrome/app_chrome/Default/Top Sites</value>
<value>data/data/com.android.chrome/shared_prefs/com.android.chrome_preferences.xml</value>
</source>

<data type="Account" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账户名" code="Name" type="string" width="100" format=""></item>
<item name="更新时间" code="Time" type="string" width="100" format=""></item>
</data>

<data type="History" contract="DataState" datefilter = "Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="网站名" code="Title" type="string" width="250" format=""></item>
<item name="网站网址" code="Url" type="Url" width="300" format=""></item>
<item name="访问次数" code="Counts" type="string" width="100" format = ""></item>
</data>

<data type="Bookmark" datefilter="Time" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="书签名" code="Title" type="string" width="200" format=""></item>
<item name="书签网址" code="Url" type="Url" width="300" format=""></item>
</data>

<data type="Topsite" contract="DataState" datefilter = "Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="网站名" code="Title" type="string" width="200" format=""></item>
<item name="网站网址" code="Url" type="Url" width="300" format=""></item>
</data>
</plugin>
[config]*/

function Account() {
    this.Name = "";
    this.Time = "";
    this.DataState = "Normal";
}

function History() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Counts = "";
    this.DataState = "Normal";
}

function Bookmark() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.DataState = "Normal";
}

function Topsite() {
    this.DataState = "Normal";
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.DataState = "Normal";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

var result = new Array();
//源数据
var source = $source;
//测试数据
//var source = ["C:\\com.android.chrome\\app_chrome\\Default\\History","C:\\com.android.chrome\\app_chrome\\Default\\Top Sites","C:\\com.android.chrome\\shared_prefs\\com.android.chrome_preferences.xml"]
var accpath = source[2];
//var bmpath = source[0];
var ch1 = "\\chalib\\Android_Chrome_V39.0.2171.59\\History.charactor";
var hpath = XLY.Sqlite.DataRecovery(source[0],ch1, "urls" );
//var ch2 = "\\chalib\\Android_Chrome_V39.0.2171.59\\TopSites.charactor";
//var tspath = XLY.Sqlite.DataRecovery(source[1],ch2, "thumbnails" );

//主界面函数
function ParesCore(){
    //定义主节点
    var chromeNode = new TreeNode();
    chromeNode.Text = "Chrome浏览器";
    //定义账户节点
    var accNode = new TreeNode();
    var account = GetAccount();
    accNode.Text = "账户信息";
    accNode.Type = "Account";
    accNode.Items.push(account);
    chromeNode.TreeNodes.push(accNode);
    //定义书签节点
    var bmNode = new TreeNode();
    bmNode.Text = "书签";
    bmNode.Type = "Bookmark";
    bmNode.Items = GetBookmark();
    chromeNode.TreeNodes.push(bmNode);
    //定义历史记录节点
    var hNode = new TreeNode();
    hNode.Text = "历史记录";
    hNode.Type = "History";
    hNode.Items = GetHistory();
    chromeNode.TreeNodes.push(hNode);
    //定义首页网站节点
    var tsNode = new TreeNode();
    tsNode.Text = "首页网站";
    tsNode.Type = "Topsite"
    //tsNode.Items = GetTopsite();
    chromeNode.TreeNodes.push(tsNode);
    result.push(chromeNode);
}

//提取账户信息
function GetAccount(){
    var arr = new Array();
    var acc = new Account();
    var data = eval('(' + XLY.File.ReadXML(accpath) + ')');
    var info = data.map.string;
    for(var i in info){
        if(info[i]['@name'] == "google.services.username"){
            arr.push(info[i]['#text']);
        }
        if(info[i]['@name'] == "chrome_to_mobile_last_updated_timestamp"){
            arr.push(info[i]['#text']);
        }
    }
    acc.Name = arr[1];
    acc.Time = arr[0];
    return acc;
}

//提取书签信息
function GetBookmark(){
    // by luochao 20161027 文件无法提取到：data/data/com.android.chrome/app_chrome/Default/Bookmarks
    //var data = eval('(' + XLY.File.ReadFile(bmpath) + ')'); 
    //var Items = new Array();
    //var info = data.roots.synced.children;
    //for(var i in info){
    //    var bm = new Bookmark();
    //    bm.Time = XLY.Convert.LinuxToDateTime(info[i].date_added);
    //    bm.Title = info[i].name;
    //    bm.Url = XLY.Convert.UrlDecode(info[i].url);
    //    Items.push(bm)
    //}
    //return Items;
}

//提取历史记录信息
function GetHistory(){
    var db = eval('(' + XLY.Sqlite.Find(hpath, "select cast(url as text) as url,cast(title as text) as title,visit_count,last_visit_time,XLY_DataType from urls") + ')');
    var Items = new Array();
    for(var i in db){
        var his = new History();
        his.Title = db[i].title;
        his.Url = XLY.Convert.UrlDecode(db[i].url);
        his.Time = XLY.Convert.LinuxToDateTime(parseInt(db[i].last_visit_time));
        his.Counts = db[i].visit_count;
        his.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(his);
    }
    return Items;
}

//提取首页网站信息
function GetTopsite() {
    var data = eval('(' + XLY.Sqlite.Find(tspath, "select distinct cast(url as text) as url,cast(title as text) as title,last_updated,XLY_DataType from thumbnails") + ')');
    var arr = new Array();
    for (var index in data) {
        var object = new Topsite();
        object.Title = data[index].title;
        object.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].last_updated));
        object.Url = XLY.Convert.UrlDecode(data[index].url);
        object.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        arr.push(object);
    }
    return arr;
}


ParesCore();
var res = JSON.stringify(result);
res;
