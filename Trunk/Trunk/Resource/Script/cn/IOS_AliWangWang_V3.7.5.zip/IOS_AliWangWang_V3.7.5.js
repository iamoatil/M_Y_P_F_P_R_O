﻿
/*[config]
<plugin name="淘宝旺信,8" group="社交聊天,2" devicetype="ios" pump="usb,Mirror,chip,Raid"  icon="\icons\com.alibaba.mobileim.png" app="com.taobao.iteam.ios.aliwangwang" version="3.75" description="旺信" data="$data" >
<source>
<value>com.taobao.iteam.ios.aliwangwang</value>
</source>
<data type="Account">
<item name="用户ID" code="Id" type="string" width="120" alignment="left" ></item>
<item name="用户名" code="Name" type="string" width="140" order = "desc" ></item>
<item name="头像" code="Avatar" type="string" width="280" ></item>
</data>

</plugin>
[config]*/

function Account() {
    this.Id = "";   //用户ID
    this.Name = ""; //用户名
    this.Avatar = "";   //头像
}

// js content  //3.7.5

//源文件的
var source = $source;
var path = source[0]+"\\Scom.taobao.iteam.ios.aliwangwang\\Library\\Preferences\\com.taobao.iteam.ios.aliwangwang.plist";

//var path = "C:\\Users\\kuang\\Desktop\\com.taobao.iteam.ios.aliwangwang.plist";

var items = eval('('+ XLY.PList.ReadToJsonString(path) +')'); 
var result = new Array();
for(var i in items){
    //3.7.
    if(items[i]._utmc_lun_ != null){
        var item = new Account();
        item.Id = items[i]._utmc_lun_;
        item.Name = items[i]._utmc_lun_;
        result.push(item);
    }
    //v3.1
    if(items[i].kUserDefaultKeyLoginUsers != null){
        for(var n in items[i].kUserDefaultKeyLoginUsers[0]){
            var a = items[i].kUserDefaultKeyLoginUsers[0][n][0];
            var item = new Account();
            item.Id = a[0];
            item.Name = a[1];
            item.Avatar = a[2];
            result.push(item);
        }
    }
}


var res = JSON.stringify(result);
res;

