﻿/*[config]
<plugin name="WhatsApp" group="社交聊天,20" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/whatsapp.png" app="WhatsApp" version="2.17.22" description="whatsapp" data="$data,ComplexTreeDataSource">
<source>
    <value>net.whatsapp.WhatsApp</value>
    <value>AppDomainGroup-group.net.whatsapp.WhatsApp.shared</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="账号" code="UserCode" type="string" width="200" format=""></item>
    <item name="昵称" code="UserName" type="string" width="200" format = ""></item>
    <item name="当前状态" code="Userstatu" type="string" width="200" format = ""></item>
    <item name="头像" code="UserHead" type="string" width="200" format = ""></item>
</data>
<data type="Contact" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="联系人ID" code="UserId" type="string" width="200" format=""></item>
    <item name="账号" code="UserNumber" type="string" width="200" format = ""></item>
    <item name="名字" code="Name" type="string" width="200" format = ""></item>
    <item name="电话号码" code="PhoneNumber" type="string" width="200" format = ""></item>
</data>
<data type="Friend" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="账号" code="UserNumber" type="string" width="200" format = ""></item>
    <item name="名字" code="Name" type="string" width="200" format = ""></item>
    <item name="电话号码" code="PhoneNumber" type="string" width="200" format = ""></item>
    <item name="当前状态" code="statue" type="string" width="200" format = ""></item>
    <item name="头像" code="UserHead" type="string" width="200" format=""></item>
</data>
<data type="GroupInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="群组账号" code="GroupNumber" type="string" width="200" format = ""></item>
    <item name="群组昵称" code="GroupName" type="string" width="200" format = ""></item>
    <item name="创建者账号" code="CreatorNumber" type="string" width="200" format = ""></item>
    <item name="头像" code="UserHead" type="string" width="200" format=""></item>
</data>
<data type="GroupMember" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="群员编号" code="MeberId" type="string" width="200" format = ""></item>
    <item name="群员昵称" code="MeberName" type="string" width="200" format = ""></item>
    <item name="群员账号" code="MeberNumber" type="string" width="200" format = ""></item>
    <item name="是否被移除" code="Move" type="string" width="200" format=""></item>
</data>
<data type="BroadcastInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="广播账号" code="BroadcastId" type="string" width="200" format = ""></item>
    <item name="广播名字" code="BroadcastName" type="string" width="200" format = ""></item>
    <item name="创建者账号" code="CreatorNumber" type="string" width="200" format = ""></item>
</data>
<data type="BroadcastMessg" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="发送者" code="Sender" type="string" width="200" format = ""></item>
    <item name="发送者昵称" code="SenderName" type="string" width="200" format = ""></item>
    <item name="接收者" code="Accepter" type="string" width="200" format = ""></item>
    <item name="接收者昵称" code="AccepterName" type="string" width="200" format = ""></item>
    <item name="消息类型" code="Type" type="string" width="200" format = ""></item>
    <item name="发送时间" code="SendTime" type="string" width="200" format = ""></item>
    <item name="内容" code="Content" type="string" width="200" format = ""></item>
    <item name="多媒体文件路径" code="Path" type="string" width="200" format = ""></item>
    <item name="多媒体文件Url" code="Url" type="string" width="200" format = ""></item>
    <item name="多媒体文件描述" code="Describe" type="string" width="200" format = ""></item> 
</data>
</plugin>
[config]*/
//定义并初始化News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义并初始化UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserCode = "";
    this.UserName = "";
    this.Userstatu = "";
    this.UserHead = "";
}
function Contact(){
    this.DataState = "Normal";
    this.UserId = "";
    this.UserNumber = "";
    this.Name = "";
    this.PhoneNumber = "";
}
function Friend(){
    this.DataState = "Normal";
    this.UserNumber = "";
    this.Name = "";
    this.PhoneNumber = "";
    this.statue = "";
    this.UserHead = "";
}
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupNumber = "";
    this.GroupName = "";
    this.CreatorNumber = "";
    this.UserHead = "";
}
function GroupMember(){
    this.DataState = "Normal";
    this.MeberId = "";
    this.MeberName = "";
    this.MeberNumber = "";
    this.Move = "";   
}
function BroadcastInfo(){
    this.DataState = "Normal";
    this.BroadcastId = "";
    this.BroadcastName = "";
    this.CreatorNumber = "";    
}
function BroadcastMessg(){
    this.DataState = "Normal";
    this.Sender = "";
    this.SenderName = "";
    this.Accepter = "";
    this.AccepterName = "";
    this.Type = "";
    this.SendTime = "";
    this.Content = ""; 
    this.Path = "";
    this.Url = "";
    this.Describe = "";   
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
var source = $source
var Sqpath = source[1] + "\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared";
var Upath = source[1] + "\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\Library\\Preferences\\group.net.whatsapp.WhatsApp.shared.plist";
var charactor1 = "\\chalib\\chalib\\IOS_Whatsapp_V2.17.22\\ChatStorage.sqlite.charactor";
var charactor2 = "\\chalib\\chalib\\IOS_Whatsapp_V2.17.22\\Contacts.sqlite.charactor";

//var Sqpath = "E:\\xlyspf\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared";
//var Upath = "E:\\xlyspf\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\Library\\Preferences\\group.net.whatsapp.WhatsApp.shared.plist";
//var charactor1 = "F:\\手机软件分析和工具\\脚本\\IOS_Whatsapp_V222\\IOS_Whatsapp_V222\\ChatStorage.sqlite.charactor";
//var charactor2 = "F:\\手机软件分析和工具\\脚本\\IOS_Whatsapp_V222\\IOS_Whatsapp_V222\\Contacts.sqlite.charactor";
var result = new Array();
BuidNode();
var res = JSON.stringify(result);
res;
//测试数据
function BuidNode(){
    var RootNode = new TreeNode();
    RootNode.Text = "WhatsApp";
    RootNode.Type = "News";
    RootNode.Items = GetAllInfo(RootNode);
    result.push(RootNode);
}
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}
function GetAllInfo(Node){
    var string = ["用户信息","联系人","好友","群组","广播","聊天记录"];
    var temp1 = new Array();
    for(var i in string){
        var temp2 = new News();
        temp2.List = string[i];
        temp1.push(temp2)
    }
    var UserInfoNode = new TreeNode();
    UserInfoNode.Text = string[0];
    UserInfoNode.Type = "UserInfo";
    UserInfoNode.Items = GetUserInfo();
    Node.TreeNodes.push(UserInfoNode);
    
    var AdressNode = new TreeNode();
    AdressNode.Text = string[1];
    AdressNode.Type = "Contact";
    AdressNode.Items = GetContact();
    Node.TreeNodes.push(AdressNode);
    
    var FriendNode = new TreeNode();
    FriendNode.Text = string[2];
    FriendNode.Type = "Friend";
    FriendNode.Items = GetFriend();
    Node.TreeNodes.push(FriendNode);

    var GroupNode = new TreeNode();
    GroupNode.Text = string[3];
    GroupNode.Type = "News";
    GroupNode.Items = GetGroup(GroupNode);
    Node.TreeNodes.push(GroupNode);
    
    var BroadcastNode = new TreeNode();
    BroadcastNode.Text = string[4];
    BroadcastNode.Type = "News";
    BroadcastNode.Items = GetBroadcast(BroadcastNode);
    Node.TreeNodes.push(BroadcastNode); 
    
    var ChatNode = new TreeNode();
    ChatNode.Text = string[5];
    ChatNode.Type = "News";
    ChatNode.Items = GetChat(ChatNode);
    Node.TreeNodes.push(ChatNode);
    
    return temp1;
}
function GetUserInfo(){
    var temp1 = new Array();
    var temp2 = new UserInfo();
    var temp3 = eval('('+ XLY.PList.ReadToJsonString(Upath) +')');
    var needpath1 = Sqpath + "\\ChatStorage.sqlite";
    var needpath =  XLY.Sqlite.DataRecovery(needpath1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");   
    var temp4 = ExecSql(needpath,"select ZPATH from ZWAPROFILEPICTUREITEM where ZJID = '" + temp3[13].OwnJabberID+"'" );
    //temp2.DataState = XLY.Convert.ToDataState(temp1[0].XLY_DataType);  
    temp2.UserCode = temp3[13].OwnJabberID;
    temp2.UserName = temp3[7].FullUserName;
    temp2.Userstatu = temp3[3].CurrentStatusText;
    //temp2.UserHead = "本地地址:" + source[0] + "\\AppDomainGroup-group.net.whatsapp.WhatsApp.shared\\" temp4[0].ZPATH;
    if(temp4 != null && temp4.length != 0){
        temp2.UserHead = "本地地址:" + temp4[0].ZPATH;
    }
    temp1.push(temp2);
    return temp1;
}
function GetContact(){
    var pathneed1 = Sqpath + "\\Contacts.sqlite";
    var pathneed =  XLY.Sqlite.DataRecovery(pathneed1,charactor2,"ZWACONTACT,ZWAPHONE,ZWASTATUS");
    var temp1 = new Array();
    var temp3 = ExecSql(pathneed,"select * from ZWAPHONE");
    if(temp3 != null && temp3.length != 0){
        for(var i in temp3){
            var temp2 = new Contact();
            temp2.DataState = XLY.Convert.ToDataState(temp3[i].XLY_DataType);
            temp2.UserId = temp3[i].ZCONTACT;
            temp2.UserNumber = temp3[i].ZWHATSAPPID;
            var temp4 = ExecSql(pathneed,"select ZFULLNAME from ZWACONTACT where Z_PK = '" + temp2.UserId + "'");
            temp2.Name = temp4[0].ZFULLNAME;
            temp2.PhoneNumber = temp3[i].ZPHONE;
            temp1.push(temp2);
        }
    }
    return temp1;
}
function GetFriend(){
    var pathneed12 = Sqpath + "\\Contacts.sqlite";
    var pathneed1 =  XLY.Sqlite.DataRecovery(pathneed12,charactor2,"ZWACONTACT,ZWAPHONE,ZWASTATUS");
    var pathneed13 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed2 =  XLY.Sqlite.DataRecovery(pathneed13,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed1,"select * from ZWASTATUS");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new Friend(); 
            temp3.DataState = XLY.Convert.ToDataState(temp2[i].XLY_DataType);          
            temp3.UserNumber = temp2[i].ZWHATSAPPID + "@s.whatsapp.net";
            var temp4 = ExecSql(pathneed1,"select ZCONTACT from ZWAPHONE where Z_PK = '" + temp2[i].ZPHONE + "'");
            if(temp4 != null && temp4.length != 0){
                var temp5 = ExecSql(pathneed1,"select ZFULLNAME from ZWACONTACT where Z_PK = '" + temp4[0].ZCONTACT + "'");
                if(temp5 != null && temp5.length != 0){
                    temp3.Name = temp5[0].ZFULLNAME;
                }
            }
            temp3.PhoneNumber = temp2[i].ZWHATSAPPID;
            temp3.statue = temp2[i].ZTEXT;
            var temp6 = ExecSql(pathneed2,"select ZPATH from ZWAPROFILEPICTUREITEM where ZJID = '" + temp3.UserNumber + "'");
            if(temp6 != null && temp6.length != 0){
                temp3.UserHead = temp6[0].ZPATH;
            }
            temp1.push(temp3);            
        }
    }
    return temp1;
}
function GetGroup(GroupNode){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select Z_PK,ZCONTACTJID,ZPARTNERNAME from ZWACHATSESSION where ZSESSIONTYPE = 1 ");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new News();
            temp3.List = temp2[i].ZCONTACTJID + "_" + temp2[i].ZPARTNERNAME;
            temp1.push(temp3);
            //创建每个群的节点
            var GroupSonNode = new TreeNode();
            GroupSonNode.Text = temp3.List;
            GroupSonNode.Type = "News";
            GroupSonNode.Items = GetGroupson(GroupSonNode,temp2[i].ZCONTACTJID,temp2[i].Z_PK);
            GroupNode.TreeNodes.push(GroupSonNode);
        }
    }
    return temp1;
}
function GetGroupson(GroupSonNode,JID,PK){
    var temp1 = new Array();
    var string = ["群信息","群成员"];
    for(var i in string){
        var temp2 = new News();
        temp2.List = string[i];
        temp1.push(temp2);
    }
    
    var GroupInfoNode = new TreeNode();
    GroupInfoNode.Text = string[0];
    GroupInfoNode.Type = "GroupInfo";
    GroupInfoNode.Items = GetGroupInfo(JID);
    GroupSonNode.TreeNodes.push(GroupInfoNode);
    
    var GroupMemberNode = new TreeNode();
    GroupMemberNode.Text = string[1];
    GroupMemberNode.Type = "GroupMember";
    GroupMemberNode.Items = GetGroupMember(PK);
    GroupSonNode.TreeNodes.push(GroupMemberNode);
    return temp1;
}
function GetGroupInfo(JID){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select ZGROUPINFO,ZCONTACTJID,ZPARTNERNAME from ZWACHATSESSION where ZCONTACTJID = '"+ JID +"' ");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new GroupInfo();
            temp3.DataState = XLY.Convert.ToDataState(temp2[i].XLY_DataType);
            temp3.GroupNumber = temp2[i].ZCONTACTJID;
            temp3.GroupName = temp2[i].ZPARTNERNAME;
            var temp4 = ExecSql(pathneed,"select ZCREATORJID from ZWAGROUPINFO where Z_PK = '" + temp2[i].ZGROUPINFO + "'");
            if(temp4 != null && temp4.length != 0){
                temp3.CreatorNumber = temp4[0].ZCREATORJID;
            }
            var temp5 = ExecSql(pathneed,"select ZPATH from ZWAPROFILEPICTUREITEM where ZJID = '" + temp3.GroupNumber + "'");
            if(temp5 != null && temp5.length != 0){
                temp3.UserHead = temp5[0].ZPATH;
            }
            temp1.push(temp3);
        }
    }
    return temp1;
}
function GetGroupMember(PK){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select Z_PK,ZMEMBERJID from ZWAGROUPMEMBER where ZCHATSESSION = '"+ PK +"' ");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new GroupMember();
            temp3.DataState = XLY.Convert.ToDataState(temp2[i].XLY_DataType);
            temp3.MeberId = temp2[i].Z_PK;
            var temp4 = GetFriend();
            if(temp4 != null && temp4.length != 0){
                for(var j in temp4){
                    if(temp2[i].ZMEMBERJID == temp4[j].UserNumber){
                        temp3.MeberName = temp4[j].Name;
                    }
                }
            }
            temp3.MeberNumber = temp2[i].ZMEMBERJID;
            var temp5 = ExecSql(pathneed,"select ZCHANGETYPE from ZWAGROUPMEMBERSCHANGE where Z_PK = '"+ temp3.MeberId +"' ");
            if(temp5 != null && temp5.length != 0){
                if(temp5[0].ZCHANGETYPE == 0){
                    temp3.Move = "否";
                }
                else
                {
                    temp3.Move = "是";
                }
            }
            temp1.push(temp3)
        }
        
    }
    return temp1;
}
function GetBroadcast(Node){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select Z_PK,ZSESSIONTYPE,ZCONTACTJID from ZWACHATSESSION where ZSESSIONTYPE = 2 or ZSESSIONTYPE = 3");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new News();
            var BroadcastSonNode = new TreeNode();
            BroadcastSonNode.Text = temp2[i].ZCONTACTJID;
            BroadcastSonNode.Type = "News";
            if(temp2[i].ZCONTACTJID != null && temp2[i].ZCONTACTJID.length != 0){
                BroadcastSonNode.Items = GetBroadSoncast(BroadcastSonNode,temp2[i].ZCONTACTJID,temp2[i].ZSESSIONTYPE,temp2[i].Z_PK);
            }
            Node.TreeNodes.push(BroadcastSonNode);
            temp3.List = BroadcastSonNode.Text;
            temp1.push(temp3);
        }   
    }
    return temp1;
}
function GetBroadSoncast(Node,JID,TYPE,PK){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var BroadcastInfoNode = new TreeNode();
    BroadcastInfoNode.Text = "广播信息";
    BroadcastInfoNode.Type = "BroadcastInfo";
    BroadcastInfoNode.Items = GetBroadcastInfo(JID);
    Node.TreeNodes.push(BroadcastInfoNode);
    var temp2 = new News();
    temp2.List = BroadcastInfoNode.Text;
    temp1.push(temp2);
    
    var BroadcastMemberNode = new TreeNode();
    BroadcastMemberNode.Text = "广播成员";
    BroadcastMemberNode.Type = "GroupMember";
    BroadcastMemberNode.Items = GetGroupMember(PK);
    Node.TreeNodes.push(BroadcastMemberNode);
    var temp2 = new News();
    temp2.List = BroadcastMemberNode.Text;
    temp1.push(temp2);
    
    var BroadcastMessgNode = new TreeNode();
    BroadcastMessgNode.Text = "广播消息";
    BroadcastMessgNode.Type = "BroadcastMessg";
    BroadcastMessgNode.Items = GetBroadcastMessg(PK);
    Node.TreeNodes.push(BroadcastMessgNode);
    var temp2 = new News();
    temp2.List = BroadcastMessgNode.Text;
    temp1.push(temp2);
    return temp1;
}
function GetBroadcastInfo(JID){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select ZSESSIONTYPE,ZCONTACTJID,ZPARTNERNAME from ZWACHATSESSION where ZCONTACTJID = '"+ JID +"'");
    var temp3 = new BroadcastInfo();
    temp3.DataState = XLY.Convert.ToDataState(temp2[0].XLY_DataType);
    temp3.BroadcastId = temp2[0].ZCONTACTJID;
    temp3.BroadcastName = temp2[0].ZPARTNERNAME;
    if(temp2[0].ZSESSIONTYPE == 2){
        temp3.CreatorNumber = GetUserInfo()[0].UserCode; 
    }
    temp1.push(temp3);
    return temp1;
}
function GetBroadcastMessg(PK){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select ZMESSAGETYPE,ZMEDIAITEM,ZFROMJID,ZTEXT,ZTOJID,cast(ZMESSAGEDATE as text) as Time from ZWAMESSAGE where ZCHATSESSION = '" + PK + "'");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new BroadcastMessg();
            temp3.DataState = XLY.Convert.ToDataState(temp2[i].XLY_DataType);
            if(temp2[i].ZFROMJID != null && temp2[i].ZFROMJID.length != 0){
                temp3.Sender = temp2[i].ZFROMJID;
            }
            else
            {
                var temp4 = GetUserInfo();
                temp3.Sender = temp4[0].UserCode;
            }
            if(temp2[i].ZTOJID != null && temp2[i].ZTOJID.length != 0){
                temp3.Accepter = temp2[i].ZTOJID;
            }
            else
            {
                var temp4 = GetUserInfo();
                temp3.Accepter = temp4[0].UserCode;
            }
            var temp6 = GetFriend();
            for(var j in temp6){
                if(temp6[j].UserNumber == temp3.Sender){
                    temp3.SenderName = temp6[j].Name;
                }
                if(temp6[j].UserNumber == temp3.Accepter){
                    temp3.AccepterName = temp6[j].Name;
                }
            }
            switch(temp2[i].ZMESSAGETYPE){
                case 0: temp3.Type = "文本";
                break;
                case 1: temp3.Type = "图片";
                break;
                case 2: temp3.Type = "视频";
                break;
                case 3: temp3.Type = "语音";
                break;
                case 4: temp3.Type = "名片";
                break;
                case 5: temp3.Type = "位置";
                break;
                case 8: temp3.Type = "文本文件";
                break;
                case 10: temp3.Type = "电话";
                break;
                case 11: temp3.Type = "Gif";
                break;
                default: temp3.Type = "未知类型";
                break;
            }     
        if(temp2 != null && temp2.length != 0){
            if(temp2[i].Time != null && temp2[i].Time.length != 0){
                var ttt = XLY.Convert.LinuxToDateTime(temp2[i].Time);
                temp3.SendTime =Number(ttt.split("-")[0]) + 31 + "-" + ttt.split("-")[1] + "-" + ttt.split("-")[2];
            }
            temp3.Content = temp2[i].ZTEXT;
            if(temp2[i].ZMEDIAITEM != null && temp2[i].ZMEDIAITEM.length != 0){
                var temp4 = ExecSql(pathneed,"select ZLATITUDE,ZLONGITUDE,ZVCARDNAME,ZVCARDSTRING,ZMEDIALOCALPATH,ZMEDIAURL,ZTITLE from ZWAMEDIAITEM where Z_PK = '" + temp2[i].ZMEDIAITEM + "'");
                if(temp4 != null && temp4.length != 0){
                    if(temp2[i].ZMESSAGETYPE == 4){
                        temp3.Content = temp4[0].ZVCARDNAME + "_______" + temp4[0].ZVCARDSTRING;
                    }
                    if(temp2[i].ZMESSAGETYPE == 5){
                        temp3.Content = "纬度:" + temp4[0].ZLATITUDE + "      " + "经度:" + temp4[0].ZLONGITUDE + "显示名:" + temp4[0].ZVCARDNAME;
                    }
                    temp3.Path = temp4[0].ZMEDIALOCALPATH;
                    temp3.Url = temp4[0].ZMEDIAURL;
                    temp3.Describe = temp4[0].ZTITLE; 
                }
                
            }
           temp1.push(temp3);
        }                                      
    }
    }
   return temp1; 
}
function GetChat(Node){
    var temp1 = new Array();
    var string = ["个人聊天记录","群组聊天记录"]
    for(var i in string){
        var temp2 = new News();
        temp2.List = string[i];
        var ChatSonNode = new TreeNode();
        ChatSonNode.Text = string[i];
        ChatSonNode.Type = "News";
        ChatSonNode.Items = GetSonChat(ChatSonNode,i);
        Node.TreeNodes.push(ChatSonNode);
        temp1.push(temp2);
    }
    return  temp1;
}
function GetSonChat(Node,n){
    var pathneed1 = Sqpath + "\\ChatStorage.sqlite";
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"ZWACHATSESSION,ZWAGROUPINFO,ZWAGROUPMEMBER,ZWAGROUPMEMBERSCHANGE,ZWAMEDIAITEM,ZWAMESSAGE,ZWAPROFILEPICTUREITEM");
    var temp1 = new Array();
    var temp2 = ExecSql(pathneed,"select Z_PK,ZCONTACTJID,ZPARTNERNAME from ZWACHATSESSION where ZSESSIONTYPE = '"+ n +"' ");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new News();
            temp3.List = temp2[i].ZCONTACTJID + "_" + temp2[i].ZPARTNERNAME;
            var ChatItemNode = new TreeNode();
            ChatItemNode.Text = temp3.List;
            ChatItemNode.Type = "BroadcastMessg";
            ChatItemNode.Items = GetBroadcastMessg(temp2[i].Z_PK);
            Node.TreeNodes.push(ChatItemNode);
            temp1.push(temp3);
        }
    }
    return temp1;
}