﻿/*[config]
<plugin name="新浪微博,10" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\sinaweibo.png" app="com.sina.weibo" version="4.6.1" description="新浪-导航树" data="$data,ComplexTreeDataSource" >
<source>
    <value>data/data/com.sina.weibo/databases#F</value>
</source>

<data type="Account" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="NickName" type="string" width="120" ></item>
<item name="账号ID" code="ID" type="string" width="120" ></item>
<item name="邮箱或电话" code="UserName" type="string" width="150" ></item>
</data>

<data  type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友分组名" code="Name" type="string" width = "100" ></item>
<item name="分组好友数" code="Number" type="string" width = "100" ></item>
<item name="分组ID" code="ID" type="string" width="200"></item>
</data>


<data type="Friend" detailfield="Descrioption" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="string" width="100" ></item>
<item name="好友昵称" code="Name" type="string" width="120" ></item>
<item name="个人签名" code="Description" type="string" width="400" ></item>
</data>

<data detailfield="Contentinfo" type="Weiboinfo" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="微博发布者" code="Name" type="string" width="120" ></item>
<item name="微博发布者ID" code="ID" type="string" width="100" ></item>
<item name="微博动态" code="Contentinfo" type="string" width="400" ></item>
<item name="时间" code="Time" type="string" width="140" ></item>
</data>

<data detailfield="Contentinfo" type="Like" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="我赞的好友" code="Name" type="string" width="200" ></item>
<item name="好友ID" code="ID" type="string" width="100" format=""></item>
<item name="微博动态" code="Contentinfo" type="string" width="400" format=""></item>
<item name="时间" code="Time" type="string" width="140" ></item>
</data> 

<data type="GroupTalk" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群组名" code="Name" type="string" width = "220" ></item>
<item name="发起人" code="StartName" type="string" width = "100" ></item>
<item name="群成员" code="Member" type="string" width = "300" ></item>
<item name="更新时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
<item name="群组ID" code="ID" type="string" width="150"></item>
</data>

<data detailfield="Content" type="Message" contract="DataState,Conversion"  datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width="100"></item>
<item name="接收人" code="Receiver" type="string" width="100"></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
<item name="消息类型" code="MsgType" type="Enum" format="EnumColumnType" width="50"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

</plugin>
[config]*/

function Account() {
    this.NickName = "";
    this.ID = "";
    this.UserName = "";
    this.DataState = "Normal";
}

function Group() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
    this.Number = "";
}

function Friend() {
    this.Name = "";
    this.Description= "";
    this.ID = "";
    this.DataState = "Normal";
}

function Weiboinfo() {
    this.Name = "";
    this.ID = "";
    this.Time = null;
    this.Contentinfo = "";
    this.DataState = "Normal";
}

function Like() {
    this.Name = "";
    this.ID= "";
    this.Time = null;
    this.Contentinfo = "";
    this.DataState = "Normal";
}

function GroupTalk() {
    this.DataState = "Normal";
    this.Name = "";
    this.Member = "";
    this.ID = "";
    this.Time = null;
}

function Message() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Content = "";
    this.MsgType = "";
    this.Type = "";
    this.SendState = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var result = new Array();

//源文件
var source = $source;
var folder = source[0];
//测试数据
//var folder =  "C:\\Users\\Administrator\\Desktop\\com.sina.weibo\\databases";
var path1 = folder + "\\sina_weibo";
var charactor1 = "\\chalib\\Android_SinaWeibo_V4.6.1\\sina_weibo.charactor";
var sinaDB = XLY.Sqlite.DataRecovery( path1,charactor1,"account_table_v3,follow_table,group_table,home_table,like_table");

//获取群聊群组ID
function GetGroTalkId(userId){
    var table = "t_buddy,t_group,t_group_member,t_message,";
    var path2 = folder+"\\message_"+userId+".db";
    var db = ExecSql(path2,"select * from t_group");
    if(db!=null&&db.length!=0){
        for(var i in db){
            if(i==db.length-1){
                table+="t_group_"+db[i].id;
            }
            else
            {
                table+="t_group_"+db[i].id+",";
            }
        } 
        var charactor2 = "\\chalib\\Android_SinaWeibo_V4.6.1\\message.charactor";
        var msgDB = XLY.Sqlite.DataRecovery( path2,charactor2,table);
        return msgDB; 
    }
}


//主界面函数
function ParesCore(){
    //定义主节点
    var sinaNode = new TreeNode();
    sinaNode.Text = "新浪微博";
    sinaNode.Type = "Account";
    var account = GetAccount();
    sinaNode.Items = account;
    for(var i in account){
        //定义账户节点
        var accNode = new TreeNode();
        accNode.Text = account[i].NickName;
        accNode.DataState = account[i].DataState;
        //定义好友分组节点
        var groNode = new TreeNode();
        groNode.Text = "好友分组";
        groNode.Type = "Group";
        var group = GetGroup(account[i].ID);
        groNode.Items = group;
        //定义未分组节点
        var ungroNode = new TreeNode();
        ungroNode.Text = "未分组好友";
        ungroNode.Type = "Friend";
        var ungroup = GetFriend(account[i].ID,-1);
        ungroNode.Items = ungroup;
        groNode.TreeNodes.push(CreateNode(account[i].ID,ungroup,ungroNode));
        //查询分组好友信息
        for(var j in group){
            //定义分组信息节点
            var friNode = new TreeNode();
            friNode.Text = group[j].Name;
            friNode.Type = "Friend";
            var friend = GetFriend(account[i].ID,group[j].ID);
            friNode.Items = friend;
            friNode.DataState = group[j].DataState;
            groNode.TreeNodes.push(CreateNode(account[i].ID,friend,friNode));
        }
        accNode.TreeNodes.push(groNode);
        //定义点赞微博节点
        var likeNode = new TreeNode();
        likeNode.Text = "我赞的微博";
        likeNode.Type = "Like";
        var likeWeibo = GetLikeWeibo(account[i].ID);
        likeNode.Items = likeWeibo;
        accNode.TreeNodes.push(likeNode);
        //定义群聊节点
        var groTalkNode = new TreeNode();
        groTalkNode.Text = "群聊";
        groTalkNode.Type = "GroupTalk";
        var groTalk = GetGroTalk(account[i].ID);
        groTalkNode.Items = groTalk;
        //定义群聊天信息节点
        for(var m in groTalk){
            var groMsgNode = new TreeNode();
            groMsgNode.Text = groTalk[m].Name;
            groMsgNode.Type = "Message";
            groMsgNode.Items = GetMessage(account[i].ID,account[i].NickName,"群组",groTalk[m].ID);
            groMsgNode.DataState = groTalk[m].DataState;
            groTalkNode.TreeNodes.push(groMsgNode);
        }
        accNode.TreeNodes.push(groTalkNode);
        //定义私信节点
        var priMsgNode = new TreeNode();
        priMsgNode.Text = "私信";
        priMsgNode.Type = "Message";
        priMsgNode.Items = GetMessage(account[i].ID,account[i].NickName,"私信");
        accNode.TreeNodes.push(priMsgNode);
        sinaNode.TreeNodes.push(accNode);
    }
    
    result.push(sinaNode);
    
}

//创建好友微博消息节点
function CreateNode(accID,data,dataNode){
    for(var m in data){
        //定义好友微博节点
        var weiboNode = new TreeNode();
        weiboNode.Text = data[m].Name;
        weiboNode.Type = "Weiboinfo";
        var weibo = GetWeibo(accID,data[m].ID);
        weiboNode.Items = weibo;
        weiboNode.DataState = data[m].DataState;
        dataNode.TreeNodes.push(weiboNode);
    }
    return dataNode;
}
            
//处理数据库查询
function ExecSql(path, sql) {
    var info = XLY.Sqlite.Find(path, sql);
    if (info.length > 0) {
        var data = eval('(' + info + ')');
        return data;
    }
}

//提取账户信息
function GetAccount(){
    var db = ExecSql(sinaDB,"select * from account_table_v3");
    var Items = new Array();
    if(db!=null&&db.length!=0){
        for(var i in db){
            var acc = new Account();
            acc.NickName = db[i].usernick;
            acc.ID = db[i].uid;
            acc.UserName = db[i].username;
            acc.DataState = XLY.Convert.ToDataState(parseInt(db[i].XLY_DataType));
            Items.push(acc);
        }
    }
    return Items;
}

//提取好友分组信息
function GetGroup(id){
    var db = ExecSql(sinaDB, "select * from group_table where user_id = '" + id + "'");
    var Items = new Array(); 
    if(db!=null&&db.length!=0){
        for(var i in db){
            var gro = new Group();
            gro.Name = db[i].title;
            gro.ID = db[i].gid;
            gro.Number = db[i].count;
            gro.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(gro);
        }
    }
    return Items;
}

//提取好友信息
function GetFriend(userId,groupId){
    var db = ExecSql(sinaDB,"select * from follow_table where user_id = '" + userId + "'");
    var Items = new Array();
    if(db!=null&&db.length!=0){
        for(var i in db){
            if(db[i].gid.indexOf(groupId)!=-1){
                var fri = new Friend();
                fri.Name = db[i].nick;
                fri.ID = db[i].uid;
                fri.Description = db[i].description;
                fri.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
                Items.push(fri);
            }
        }
    }
    return Items;
}

//提取好友微博信息
function GetWeibo(userId,friendId){
    var db = ExecSql(sinaDB,"select * from home_table where own_uid = '" + userId + "' and uid = '" + friendId + "'");
    var Items = new Array();
    if(db!=null&&db.length!=0){
        for(var i in db){
            var weibo = new Weiboinfo();
            weibo.Name = db[i].nick;
            weibo.ID = db[i].uid;
            weibo.Time = db[i].time;
            weibo.Contentinfo = db[i].content+ "................纬度" + db[i].latitude + "，经度" + db[i].longitude;
            weibo.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(weibo);
        }
    }
    return Items;
}

//提取点赞微博信息
function GetLikeWeibo(userId){
    var db = ExecSql(sinaDB,"select * from like_table where owner_uid = '" + userId + "'");
    var Items = new Array();
    if(db!=null&&db.length!=0){
        for(var i in db){
            var like = new Like();
            like.Name = db[i].nick;
            like.ID = db[i].uid;
            like.Time = db[i].time;
            like.Contentinfo = db[i].content;
            like.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(like);
        }
    }
    return Items;
}

//提取群组信息
function GetGroTalk(userId){
    var Items = new Array();
    var msgDB = GetGroTalkId(userId);
    var db1 = ExecSql(msgDB,"select * from t_group");
    var db2 = ExecSql(msgDB,"select * from t_buddy");
    if(db1!=null&&db1.length!=0){
        for(var j in db1){
            var groTalk = new GroupTalk();
            groTalk.Name = db1[j].name;
            groTalk.Time = XLY.Convert.LinuxToDateTime(db1[j].update_time);
            groTalk.ID = db1[j].id;
            if(db2!=null&&db2.length!=0){
                for(var m in db2){
                    if(db1[j].owner==db2[m].uid)
                        groTalk.StartName = db2[m].nick;
                }
            }
            var db3 = ExecSql(msgDB,"select * from t_group_member where group_id = '" + db1[j].id + "'");
            var memberArr = [];
            if(db3!=null&&db3.length!=0){
                for(var n in db3){
                    for(var x in db2){
                        if(db3[n].uid==db2[x].uid)
                            memberArr.push(db2[x].nick);
                    }
                }
            }
            groTalk.Member = memberArr.join(",") ;
            groTalk.DataState = XLY.Convert.ToDataState(db1[j].XLY_DataType);
            Items.push(groTalk);
        }
    }
    return Items;
}

//提取好友聊天信息
function GetMessage(userId,userName,msgType,groTalkId){
    var Items = new Array();
    var msgDB = GetGroTalkId(userId);
    var db1 = null;
    if(msgType=="群组"){
       db1 = ExecSql(msgDB,"select * from '"+"t_group_"+groTalkId+"'");
    }
    else
    {
       db1 = ExecSql(msgDB,"select * from t_message");
    }  
   if(db1!=null&&db1.length!=0){
        for(var m in db1){
            var msg = new Message();
            msg.Time = XLY.Convert.LinuxToDateTime(db1[m].time);
            msg.Content = db1[m].content+"................纬度" + db1[m].latitude + "，经度" + db1[m].longitude;
            switch(db1[m].content_type){
                case 0 : msg.Type = "String"; msg.MsgType = "文本";break;
                case 1 : msg.Type = "Image"; msg.MsgType = "图片";break;
                //case 2 : msg.Type = "Video"; msg.MsgType = "视频";break;
                //case 4 : msg.Type = "Audio"; msg.MsgType = "音频";break;
                default : msg.Type = "String"; msg.MsgType = "文本";
            }
            var db2 = ExecSql(msgDB,"select * from t_buddy where uid = '" + db1[m].sender_id + "'");
            if(db2!=null&&db2.length!=0){
                msg.Sender = db2[0].nick;
            }
            
            if(db1[m].sender_id==userId){
                msg.SendState = "Send";
                if(msgType=="群组"){
                    msg.Receiver = "群组";
                }
                else
                {
                    var db3 = ExecSql(msgDB,"select * from t_buddy where uid = '" + db1[m].session_id + "'");
                    if(db3!=null&&db3.length!=0){
                        msg.Receiver = db3[0].nick;
                    }
                }   
            }
            else
            {
                msg.SendState = "Receive";
                msg.Receiver = userName;
            }
            msg.DataState = XLY.Convert.ToDataState(db1[m].XLY_DataType);
            Items.push(msg);
        }
    }
    return Items ;    
}
ParesCore();
var res = JSON.stringify(result);
res;
