﻿//本程序是针对三星的特别版
/*[config]
<plugin name="手机百度(三星)" group="Web痕迹,16" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/baidu.png" app="com.baidu.searchbox" version="8.6.5" description="手机百度(三星手机)" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.baidu.searchbox_samsung/databases/SearchBox.db</value>
    <value>/data/data/com.baidu.searchbox_samsung/shared_prefs/box_account.xml</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="用户ID" code="UserId" type="string" width="200" format = ""></item>
    <item name="账号" code="UserCode" type="string" width="200" format=""></item>
    <item name="昵称" code="UserName" type="string" width="200" format=""></item>
    <item name="头像" code="UserHead" type="string" width="200" format = ""></item>
    <item name="手机" code="Phone" type="string" width="200" format=""></item>
</data>
<data type="Search" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="搜索内容" code="SearchList" type="string" width="200" format = ""></item>
    <item name="搜索时间" code="SearchTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Bookmarks" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="目录" code="Files" type="string" width="" format = ""></item>
    <item name="内容" code="Content" type="string" width="" format = ""></item>
    <item name="网址" code="Url" type="url" width="" format = "" ></item>
    <item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="BaiduMsg" contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="标题" code="Title" type="string" width="" format = ""></item>
    <item name="内容" code="Content" type="string" width="" format = "" ></item>
    <item name="图标" code="Icon" type="url" width="" format = "" ></item>
    <item name="网址" code="Url" type="url" width="" format = "" ></item>
    <item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
    <data type="Visitedlog" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="网址" code="Url" type="url" width="" format = "" ></item>
    <item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Xsearch" contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="标题" code="Title" type="string" width="" format = ""></item>
    <item name="图标" code="Icon" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/
//定义并初始化News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义并初始化UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.UserCode = "";
    this.UserName = "";
    this.UserHead = "";
    this.Phone = "";
}
//定义并初始化Search数据结构
function Search(){
    this.DataState = "Normal";
    this.SearchList = "";
    this.SearchTime = "";
}
//定义并初始化Search数据结构
function Bookmarks(){
    this.DataState = "Normal";
    this.Files = "";
    this.Content = "";
    this.Url = "";
    this.Time = "";
}
//定义并初始化BaiduMsg数据结构
function BaiduMsg(){
    this.DataState = "Normal";
    this.Title = "";
    this.Content = "";
    this.Icon = "";
    this.Url = "";
    this.Time = "";    
}
//定义并初始化Visitedlog数据结构
function Visitedlog(){
    this.DataState = "Normal";
    this.Url = "";
    this.Time = "";
}
//定义并初始化Xsearch数据结构
function Xsearch(){
    this.DataState = "Normal";
    this.Title = "";
    this.Icon = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
var result = new Array();
//配置文件路径全局共用

//*************************************程序入口****************************************
//源数据
var source = $source;
var pathold = source[0];
var charactor = "\\chalib\\Android_Baidu_V8.6.5\\SearchBox.db.charactor";
var path1 = XLY.Sqlite.DataRecovery(pathold,charactor,"baidumsg_table,clicklog,bookmarks,visitedlog,xsearch_site");
var path2 = source[1];

//测试数据
//var pathold = "D:\\com.baidu.searchbox_samsung\\databases\\SearchBox.db";
//var charactor = "F:\\李锦祥个人文件\\脚本学习\\SPF20170328\\21-Build\\chalib\\Android_Baidu_V8.6.5\\SearchBox.db.charactor";
//var path1 = XLY.Sqlite.DataRecovery(pathold,charactor,"baidumsg_table,clicklog,bookmarks,visitedlog,xsearch_site");
//var path2 = "D:\\com.baidu.searchbox_samsung\\shared_prefs\\box_account.xml";

BuildNode();
var res = JSON.stringify(result);
res;
//*************************************程序结束****************************************




//++++++++++++++++++++++++++++++++++自定义函数部分++++++++++++++++++++++++++++++++++++++
//自定义数据库读取函数  
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}
//主函数
function BuildNode(){
 //**********************************根节点建立**************************************  
    var RootNode = new TreeNode();
    RootNode.Text = "手机百度";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(RootNode);
    result.push(RootNode);
}
function GetRootInfo(Node){
    var My_String = ["用户信息","搜索信息","书签信息","百度消息信息","浏览历史信息","订阅信息"];
    var temp1 = new Array();
    for(var i in My_String){
        var temp2 = new News();
        temp2.List = My_String[i];
        temp1.push(temp2)
    }
    //获得用户信息
    var UserInfoNode = new TreeNode();
    UserInfoNode.Text = My_String[0];
    UserInfoNode.Type = "UserInfo";
    UserInfoNode.Items = GetUserInfo();
    Node.TreeNodes.push(UserInfoNode);
    //获得搜索信息
    var SearchNode = new TreeNode();
    SearchNode.Text = My_String[1];
    SearchNode.Type = "Search";
    SearchNode.Items = GetSearch();
    Node.TreeNodes.push(SearchNode);
    //获得书签信息
    var BookmarksNode = new TreeNode();
    BookmarksNode.Text = My_String[2];
    BookmarksNode.Type = "Bookmarks";
    BookmarksNode.Items = GetBookmarks();
    Node.TreeNodes.push(BookmarksNode);
    //获得百度消息信息
    var BaiduMsgNode = new TreeNode();
    BaiduMsgNode.Text = My_String[3];
    BaiduMsgNode.Type = "BaiduMsg";
    BaiduMsgNode.Items = GetBaiduMsg();
    Node.TreeNodes.push(BaiduMsgNode);
    //获得浏览历史信息
    var VisitedlogNode = new TreeNode();
    VisitedlogNode.Text = My_String[4];
    VisitedlogNode.Type = "Visitedlog";
    VisitedlogNode.Items = GetVisitedlog();
    Node.TreeNodes.push(VisitedlogNode);
    //获得订阅信息
    var XsearchNode = new TreeNode();
    XsearchNode.Text = My_String[5];
    XsearchNode.Type = "Xsearch";
    XsearchNode.Items = GetXsearch();
    Node.TreeNodes.push(XsearchNode);
    //返回列表
    return temp1;
}
//用户信息获取函数
function GetUserInfo(){
    var temp1 = new Array();
    var temp2 = new UserInfo();
    var temp3 = eval('('+ XLY.File.ReadXML(path2) +')');
    //log(temp3.map.string[0]["@name"]);
    if(temp3 != null && temp3.length != 0){
        for(var i in temp3.map.string){
            switch(temp3.map.string[i]["@name"]){
                case "login_userid": temp2.UserId = temp3.map.string[i]["#text"];
                break;
                case "user_bind_email_key": temp2.UserCode = temp3.map.string[i]["#text"]; 
                break;
                case "login_displayname": temp2.UserName = temp3.map.string[i]["#text"];
                break;
                case "user_login_portrait_key": temp2.UserHead = temp3.map.string[i]["#text"];
                break;
                case "user_bind_phone_key": temp2.Phone = temp3.map.string[i]["#text"];
                break;
            }
        }
    }
    temp1.push(temp2)
    return temp1;
}
//搜索信息获取函数
function GetSearch(){
    var temp1 = new Array();
    var temp3 = ExecSql(path1,"select * from clicklog");
    if(temp3 != null && temp3.length != 0){
        for(var i in temp3){
            var temp2 = new Search();
            temp2.SearchList = temp3[i].intent_key;
            temp2.SearchTime = XLY.Convert.LinuxToDateTime(temp3[i].hit_time);
            temp2.DataState = XLY.Convert.ToDataState( temp3[i].XLY_DataType);
            temp1.push(temp2);
        }
    }
    return temp1;
}
//书签信息获取函数
function GetBookmarks(path){
    var list = new Array();
    var data = ExecSql(path1,"select * from bookmarks");
    if(data != null && data.length != 0){
        for(var i in data){
            var obj = new Bookmarks();
            obj.Files = data[i].directory;
            obj.Content = data[i].title;
            obj.Url = data[i].url;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}
//百度消息信息获取函数
function GetBaiduMsg(){
    var list = new Array();
    var data = ExecSql(path1,"select * from baidumsg_table");
    if(data != null && data.length != 0){
        for(var i in data){
            var obj = new BaiduMsg();
            obj.Title = data[i].title;
            obj.Content = data[i].content;
            obj.Icon = data[i].iconUrl;
            obj.Url = data[i].url;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
    }
    
    return list;
}
//历史记录信息获取函数
function GetVisitedlog(){
    var list = new Array();
    var data = ExecSql(path1,"select * from visitedlog");
    if(data != null && data.length != 0){
        for(var i in data){
            var obj = new Visitedlog();
            obj.Url = data[i].url;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
    } 
    return list;
}
//订阅信息获取函数
function GetXsearch(){
    var list = new Array();
    var data = ExecSql(path1,"select * from xsearch_site");
    if(data != null && data.length != 0){
        for(var i in data){
            var obj = new Xsearch();
            obj.Title = data[i].title;
            obj.Icon = data[i].icon_url;
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }  
    }
    return list;
}