﻿/*[config]
<plugin name="QQ空间,6" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/qzone.jpg" app="com.qzone" version="4.9.6" description="QQ空间" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.qzone/databases/#F</value>
</source>

<data type="Account" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="NickName" type="string" width = "120" ></item>
<item name="年龄" code="Age" type="string" width="120" ></item>
<item name="QQ账号" code="ID" type="string" width = "120" ></item>
<item name="登录时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
</data>

<data type="Album" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="相册名称" code="Name" type="string" width="120" ></item>
<item name="相片张数" code="Number" type="string" width = "120" ></item>
<item name="相册权限" code="Permission" type="string" width = "120" ></item>
<item name="更新时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
</data>

<data type="Visitor" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="访客QQ" code="ID" type="string" width = "120" ></item>
<item name="访客昵称" code="NickName" type="string" width="120" ></item>
<item name="访问内容" code="Info" type="string" width = "120" ></item>
<item name="访问时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
</data>

</plugin>
[config]*/

function Account(){
    this.NickName = "";
    this.ID = "";
    this.Age = "";
    this.Time = null;
    this.DataState = "Normal";
}

function Album(){
    this.Name = "";
    this.Number = "";
    this.Permission = "";
    this.Time = null;
    this.DataState = "Normal";
}

function Visitor(){
    this.NickName = "";
    this.ID = "";
    this.Info = "";
    this.Time = null;
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

var result = new Array();

//源文件
var source = $source;
var folder = source[0];

//测试数据
//var folder =  "C:\\Users\\Administrator\\Desktop\\com.qzone\\databases";
var db = eval('('+XLY.File.FindFileNames(folder)+')');
var path = folder+"\\WnsDBHelper";
var ch1 = "\\chalib\\Android_qzone_V4.9.6\\WnsDBHelper.charactor";
var accdb = XLY.Sqlite.DataRecovery( path,ch1,"UserInfo");
var paths = new Array();
for(var i in db){
    //var reg = new RegExp("^(?!^\d+$)(?!^[a-zA-Z]+$)[0-9a-zA-Z]+$");
    //if(reg.test(db[i])){
        var info = eval('('+ XLY.Sqlite.Find(folder+"\\"+db[i],"select * from sqlite_master where type = 'table' ") +')');
        var flag = 0;
        for(var j in info){
            if(info[j].name=="table_widget_vip"||info[j].name=="TABLE_ALBUMLIST"||info[j].name=="TABLE_MY_VISITOR"){
                flag++;     
            }
            if(flag==3){
                var ch2 = "\\chalib\\Android_qzone_V4.9.6\\QQinfo.charactor";
                var infodb = XLY.Sqlite.DataRecovery( folder+"\\"+db[i],ch2,"table_widget_vip,TABLE_ALBUMLIST,TABLE_MY_VISITOR");
                paths.push(infodb);
                break;
            }   
        }
    //}
}
//主界面函数
function ParesCore(){
    //定义主节点
    var QQNode = new TreeNode();
    QQNode.Text = "QQ空间";
    QQNode.Type = "Account";
    var account = GetAccount();
    QQNode.Items = account;
    for(var i in account){
        //定义账户节点
        var accNode = new TreeNode();
        accNode.Text = account[i].NickName;
        accNode.DataState = account[i].DataState;
        //定义相册节点
        var albumNode = new TreeNode();
        albumNode.Text = "相册";
        albumNode.Type = "Album";
        var album = GetAlbum(account[i].ID);
        albumNode.Items = album;
        accNode.TreeNodes.push(albumNode);
        //定义访客节点
        var visitorNode = new TreeNode();
        visitorNode.Text = "访客";
        visitorNode.Type = "Visitor";
        var visitor = GetVisitor(account[i].ID);
        visitorNode.Items = visitor;
        accNode.TreeNodes.push(visitorNode);
        QQNode.TreeNodes.push(accNode); 
    }
    result.push(QQNode);
} 

//提取账户信息
function GetAccount(){
    var db= eval('(' + XLY.Sqlite.FindByName(accdb, "UserInfo") + ')');
    var Items = new Array();
    if(db!=null&&db.length>0){
        for(var i in db){
            var acc = new Account();
            acc.NickName = db[i].nickName;
            acc.ID = db[i].uin;
            acc.Age = db[i].age;
            acc.Time = XLY.Convert.LinuxToDateTime(db[i].longinTime);
            acc.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(acc);
        }
    }
    return Items;
}

//获取相册信息
function GetAlbum(ID){
    for(var i in paths){
        var db1 = eval('('+ XLY.Sqlite.Find(paths[i],"select * from table_widget_vip ") +')');
        if(db1!=null&&db1.length>0){
            if(db1[0].uin==ID){
                var db2 = eval('(' + XLY.Sqlite.FindByName(paths[i], "TABLE_ALBUMLIST") + ')');
                var Items = new Array();
                for(var j in db2){
                    var album = new Album();
                    album.Name = db2[j].albumname;
                    album.Number = db2[j].albumnum;
                    album.Permission = db2[j].albumpermission;
                    album.Time = XLY.Convert.LinuxToDateTime(db2[j].last_refresh_time);
                    album.DataState = XLY.Convert.ToDataState(db2[j].XLY_DataType);
                    Items.push(album);  
                }
                break;
            }
        }
    }
    return Items
}

//获取访客信息
function GetVisitor(ID){
    for(var i in paths){
        var db1 = eval('('+ XLY.Sqlite.Find(paths[i],"select * from table_widget_vip ") +')');
        if(db1!=null&&db1.length>0){
            if(db1[0].uin==ID){
                var db2 = eval('(' + XLY.Sqlite.FindByName(paths[i], "TABLE_MY_VISITOR") + ')');
                var Items = new Array();
                for(var j in db2){
                    var vis = new Visitor();
                    vis.NickName = db2[j].nickname;
                    vis.ID = db2[j].uin;
                    vis.Info = db2[j].visit_info;
                    vis.Time = XLY.Convert.LinuxToDateTime(db2[j].vtime);
                    vis.DataState = XLY.Convert.ToDataState(db2[j].XLY_DataType);
                    Items.push(vis);  
                }
                break;
            }
        }
    }
    return Items;
}

ParesCore();
var res = JSON.stringify(result);
res;
