﻿//descritpion:Test-复杂导航树

/*[config]
<plugin name="淘宝旺信,6" group="社交聊天,2" devicetype="android" pump="usb,Mirror,chip,Raid,LocalData"  icon="\icons\com.alibaba.mobileim.png" app="com.alibaba.mobileim" version="3.7.0" description="旺信" data="$data,TreeDataSource" >
<source>
<value>/data/data/com.alibaba.mobileim/databases#F</value>
</source>
<data type="Account" detailfield="Signature" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="登录账户" code="loginAccount" type="string" width="120" alignment="left" ></item>
<item name="登录方式" code="loginType" type="string" width="140" order="desc" ></item>
<item name="登录时间" code="loginTime" type="datetime" width="300" ></item>
<item name="头像" code="headImg" type="string" width="80" ></item>
</data>

<data type="FriendInfo" datefilter="Date" detailfield="Content" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称(帐号)" code="nickName" type="string" width="120" ></item>
<item name="头像" code="headPath" type="image"  show="true" ></item>
<item name="最近联系" code="lastMessageTime" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
</data>

<data type="Tribe" datefilter="Date" detailfield="Content" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群昵称" code="tribeName" type="string" width = "120" ></item>
<item name="群ID" code="tribeId" type="string"  show="true" ></item>
<item name="图标" code="Icon" type="image"  show="true" ></item>
</data>

<data detailfield="Content" type="Message" contract="DataState,Conversion"  datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width="100"></item>
<item name="接收人" code="Receiver" type="string" width="100"></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="时间" code="Time" order="asc" type="datetime" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
<item name="消息类型" code="MsgType" type="Enum" format="EnumColumnType" width="50" show = "false" ></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

</plugin>
[config]*/

function Account() {
    this.DataState = "Normal";  //数据状态
    this.loginAccount = ""; //登录账户
    this.loginType = "";    //登录方式
    this.loginTime = null;  //登录时间
    this.headImg = "";  //头像
}
function FriendInfo() {
    this.DataState = "Normal";  //数据状态
    this.nickName = "";   //用户账户
    this.headPath = "";  //昵称
    this.userId = "";
    this.lastMessageTime = ""; //最新一次消息时间
}
function Tribe() {
    this.DataState = "Normal";  //数据状态
    this.tribeName = "";    //群昵称
    this.tribeId = "";  //群ID
    this.Icon = ""; //图标
}
function Message() {
    this.DataState = "Normal";  //数据状态
    this.Sender = "";   //发送人
    this.Receiver = ""; //接收人
    this.Content = "";  //内容
    this.Time = null;   //时间
    this.MsgType = "String";    //消息类型
    this.SendState = "";   //类型
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.Id = "";
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var _key = "cnhhupan";
var source = $source[0];
var result = new Array();
ParesCore();
var res = JSON.stringify(result);
res;

function ParesCore(){
    var tree = new TreeNode();
    var dbPath = source+"\\aliuser";
    var allAccount = eval('('+ XLY.Sqlite.Find(dbPath,"select * from loginHistory") +')');
    
    tree.Text = "本地账户信息";
    tree.Type = "Account";
    tree.Items = getAllAccounts(allAccount);
    tree.TreeNodes = getAllAccountTree(allAccount).TreeNodes;
    result.push(tree);
}

function createTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

function getAllAccounts(accounts){
    if(accounts.length == 0){
        return null;
    }
    var array = new Array();
    for(var i in accounts){
        var acc = accounts[i];
        var at = new Account();
        at.DataState = "Normal";  //数据状态
        at.loginAccount = acc.loginAccount; //登录账户
        at.loginType = acc.loginType;    //登录方式
        at.loginTime = XLY.Convert.LinuxToDateTime(acc.loginTime);  //登录时间
        at.headImg = acc.headImg;  //头像
        _nAccount = at;
        array.push(at);
    }
    return array;
}

function getAllAccountTree(allAccount){
    var tree = new TreeNode();
    for(var i in allAccount){
        var acc = allAccount[i];
        var aTree = createTreeNode(acc.loginAccount,"");
        aTree.TreeNodes.push(getFriendTree(acc));
        aTree.TreeNodes.push(getGroupTree(acc));
        tree.TreeNodes.push(aTree);
    }
    return tree;
}

function getFriendTree(acc){
    var tree = createTreeNode("好友","FriendInfo");
    var fDb = XLY.Convert.CalculateMd5(_key+acc.loginAccount)+"wx";
    var db = source+"\\"+fDb;
    if(!XLY.File.IsValid(db)){
        return tree;
    }
    var sql = "select * from [user]";
    var isExist = eval('('+ XLY.Sqlite.Find(db,"select * from sqlite_master where type = 'table' and tbl_name = 'wwGroup';") +')');
    if(isExist.length>0){
        // 卖家帐号
        sql += " where [type] is null";
    }
    var allFriend = eval('('+ XLY.Sqlite.Find(db,sql) +')');
    for(var i in allFriend){
        var friend = createFriendInfo(allFriend[i]);
        tree.Items.push(friend);
        var fTree = createTreeNode(friend.nickName,"Message");
        // 加载好友的聊天信息;
        fTree.Items = getFriendMessage(db,friend,acc);
        tree.TreeNodes.push(fTree);
    }
    return tree;
}

function getFriendMessage(db,friend,account){
    var array = new Array();
    var sql = "select * from message where conversationid = '"+friend.userId+"'";
    var allMsg = eval('('+ XLY.Sqlite.Find(db,sql) +')');
    if(allMsg.length == 0){
        return array;
    }
    for(var i in allMsg){
        var _msg = getMessage(allMsg[i],account);
        array.push(_msg);
    }
    return array;
}

function getMessage(msg,account){
    var _message = new Message();
    _message.DataState = "Normal";  //数据状态
    var index = msg.conversationId.indexOf(_key);
    var index2 = msg.conversationId.indexOf('tribe')
    var friend = "";
    if(index==0){
        friend = msg.conversationId.replace(_key,'');
        }else if(index2==0){
            friend = msg.conversationId.replace('tribe','');
        }
    if(msg.sendId == "cnhhupan"+account.loginAccount){
        _message.Sender = account.loginAccount;   //发送人
        _message.Receiver = friend; //接收人
        _message.SendState = "Send";
    }else{
        _message.Sender = friend;   //发送人
        _message.Receiver = account.loginAccount; //接收人
        _message.SendState = "Receive";
    }
    _message.Content = msg.content;  //内容
    _message.Time = XLY.Convert.LinuxToDateTime(msg.time);   //时间
    _message.MsgType = "String";    //消息类型
    return _message;
}

function createFriendInfo(friend){
    var _friend = new FriendInfo();
    //XLY.Debug.WriteLine(friend);
    _friend.DataState = "Normal";  //数据状态
    _friend.userId = friend.userId;
    _friend.nickName = friend.nickName;   //用户账户
    _friend.headPath = friend.headPath;  //昵称
    _friend.lastMessageTime = XLY.Convert.LinuxToDateTime(friend.lastUpdateProfile); //最新一次消息时间
    return _friend;
}

function getGroupTree(acc){
    var tree = createTreeNode("群组","Tribe");
    var fDb = XLY.Convert.CalculateMd5(_key+acc.loginAccount)+"wx";
    var db = source+"\\"+fDb;
    var sql = "select * from wwTribe";
    var allTribe = eval('('+ XLY.Sqlite.Find(db,sql) +')');
    for(var i in allTribe){
        var tribe = getTribeInfo(allTribe[i]);
        var tTree = createTreeNode(tribe.tribeName,"Message");
        tTree.Items = getTribeMessage(db,tribe,acc);
        tree.Items.push(tribe);
        tree.TreeNodes.push(tTree);
    }
    return tree;
}

function getTribeInfo(tribe){
    var _tribe = new Tribe();
    _tribe.DataState = "Normal";  //数据状态
    _tribe.tribeName = tribe.tribeName;    //群昵称
    _tribe.tribeId = tribe.tribeid;  //群ID
    _tribe.Icon = tribe.tribeIcon; //图标
    return _tribe;
}

function getTribeMessage(db,tribe,account){
    var array = new Array();
    var sql = "select * from message where conversationid = 'tribe"+tribe.tribeId+"'";
    var allMsg = eval('('+ XLY.Sqlite.Find(db,sql) +')');
    if(allMsg.length == 0){
        return array;
    }
    for(var i in allMsg){
        var _msg = getMessage(allMsg[i],account);
        array.push(_msg);
    }
    return array;
}
