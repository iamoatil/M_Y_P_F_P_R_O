﻿/*[config]
<plugin name="QQ通讯录,10" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/weixinben.png" app="com.tencent.contacts" version="5.4.1" description="QQ通讯录" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tencent.contacts</value>
</source>
<data type="AllContact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="联系人" code="name" type="string" width="70"></item>    
<item name="电话" code="phone" type="string" width="150"></item>   
</data>
<data type="TeleHistory" datefilter="callTime" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="通信对象" code="call" type="string" width="70"></item>    
<item name="通信方式" code="callMode" type="string" width="70"></item>
<item name="通信时间" code="callTime" type="DateTime" width="150"></item>
</data>
<data type="Focus" datefilter="bindTime" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="绑定电话" code="bindMobile" type="string" width="70"></item>    
<item name="绑定时间" code="bindTime" type="DateTime" width="150"></item>
</data>
<data type="FocusContact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="联系人" code="name" type="string" width="150"></item>    
<item name="电话" code="phone" type="string" width="150"></item>
<item name="QQ" code="qq" type="string" width="150"></item>    
<item name="腾讯微博" code="tenlent" type="string" width="150"></item>
<item name="新浪微博" code="sina" type="string" width="150"></item>   
</data>
<data type="SinContact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="联系人" code="name" type="string" width="70"></item>    
<item name="电话" code="phone" type="string" width="70"></item>  
<item name="头像" code="headUrl" type="URL" width="150"></item>  
</data>
<data type="GroupContact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="组号" code="id" type="string" width="70"></item>    
<item name="组名" code="name" type="string" width="70"></item>  
<item name="成员" code="member" type="string" width="150"></item>  
</data>
<data type="SinMessage" datefilter="Date"  contract="DataState,Conversion" > 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="150"></item>  
<item name="接收人" code="reciveName" type="string" width="150"></item>  
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="状态" code="SendState" type="string" width="70" show="false"></item>   
<item name="内容" code="Content" type="string" width="400"></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="时间" code="Date" type="DateTime" width="150"></item> 
</data>
<data type="GroMessage" datefilter="Date"  contract="DataState,Conversion" > 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="150"></item>    
<item name="状态" code="SendState" type="string" width="150"></item>    
<item name="内容" code="Content" type="string" width="600"></item>  
<item name="时间" code="Date" type="DateTime" width="150"></item> 
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="接收人" code="reciveName" type="string" width="150" show="false" ></item>  
</data>
</plugin>
[config]*/

//定义数据结构
function AllContact() {
	this.name = "";
	this.phone ="";
	this.DataState ="Normal";
}

function Focus() {
	this.bindMobile = "";
	this.bindTime ="";
	this.uin="";
	this.DataState ="Normal";
}

function FocusContact() {
	this.name = "";
	this.phone ="";
	this.qq = "";
	this.tenlent ="";
	this.sina ="";
	this.DataState ="Normal";
}

function SinContact() {
	this.name = "";
	this.phone ="";
	this.headUrl = "";
	this.DataState ="Normal";
}

function GroupContact() {
	this.id = "";
	this.name ="";
	this.member = "";
	this.DataState ="Normal";
}
function SinMessage() {
	this.SenderName="";
	this.reciveName="";
	this.SendState = "";
	this.Content ="";
	this.Date = "";
	this.DataState ="Normal";
}

function GroMessage() {
	this.SenderName = "";
	this.SendState = "";
	this.Content ="";
	this.Date = "";
	this.reciveName="";
	this.DataState ="Normal";
}

function TeleHistory(){
	this.call = "";
	this.callMode = "";
	this.callTime ="";
	this.DataState ="Normal";
}

//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState ="Normal";
}

//获取整个通讯录
function createContactNode(path)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select name,mobile,XLY_DataType from tb_records where name !='' ")+ ')');
		var arr = new Array();
		for (var index in data) {
			if(data[0])
			{
				var obj = new AllContact();
				obj.name = data[index].name;
				obj.phone = data[index].mobile;
				obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
				arr.push(obj)
			}  
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//获取绑定信息
function getBindInfo(path)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select mobile,uin,bindtime,XLY_DataType from tb_user where mobile !=''")+ ')');
		for (var index in data) 
		{
			if(data[0])
			{
				var obj = new Focus();
				obj.bindMobile = data[index].mobile;
				obj.bindTime = data[index].bindTime;
				obj.uin=data[index].uin;
				obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
				arr.push(obj)
			}   
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//关注联系人
function getFoucusInfo(path,name)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select name,mobile,qqaccount,txweibo,sinaweibo,XLY_DataType from tb_collectperson where name ='"+name+"'")+ ')');
		var obj=new FocusContact();
		obj.name = data[0].name;
		obj.phone = data[0].mobile;
		obj.qq=data[0].qqaccount;
		obj.tenlent = data[0].txweibo;
		obj.sina=data[0].sinaweibo;
		obj.DataState = XLY.Convert.ToDataState(data[0].XLY_DataType);
		arr.push(obj);
		return arr;
	}
	catch(e){
		return arr;
	}
}

//单人聊天记录
function getSinHistory(path,picpath,mobile,name,uname)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select state,content,time,subType,XLY_DataType from tb_sigmessage where mobile ='"+mobile+"'")+ ')');
		for(var index in data){
			var obj=new SinMessage();
			obj.SendState = data[index].state;
			obj.Content = data[index].content;
			obj.Type=data[index].subType;
			obj.Date=XLY.Convert.LinuxToDateTime(  data[index].time);
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			if(obj.SendState==1)
			{
				obj.SenderName=uname;
				obj.SendState="Send";
			}
			else
			{
				obj.SenderName=name;
				obj.SendState="Receive";
			}
			if(obj.Type==3)
			{
				obj.Type="Image";
				obj.Content=picpath+"detail\\"+obj.Content+".png";
			}
			if(obj.Type==7)
			{
				obj.Type="Image";
				obj.Content=picpath+"pendraw\\"+obj.Content+".png";
			}
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//群组聊天记录
function getGroupHistory(path,picpath,id,uname,name)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select mobile,state,content,time,subType,XLY_DataType from tb_gromessage where groupid ='"+id+"'")+ ')');
		for(var index in data){
			var obj=new GroMessage();
			obj.SenderName = data[index].mobile;
			obj.SendState = data[index].state;
			obj.Content = data[index].content;
			obj.Type=data[index].subType;
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			obj.Date=XLY.Convert.LinuxToDateTime(  data[index].time);
			if(obj.SendState==1)
			{
				obj.SenderName=uname;
				obj.SendState="Send";
			}
			else if(obj.SendState==2)
			{
				obj.SendState="Receive";
				if(obj.Type==120)
				{
					obj.SenderName=name;
				}
			}
			if(obj.Type==3)
			{
				obj.Type="Image";
				obj.Content=picpath+"detail\\"+obj.Content+".png";
			}
			if(obj.Type==7)
			{
				obj.Type="Image";
				obj.Content=picpath+"pendraw\\"+obj.Content+".png";
			}
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//单人信息
function getSinInfo(path)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select name,mobile,XLY_DataType from tb_member where name !=''")+ ')');
		for(var index in data){
			var obj=new SinContact();
			obj.phone = data[index].mobile;
			obj.name = data[index].name;
			obj.headUrl=data[index].faceurl;
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//群组信息
function getGroupInfo(path)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select groupid,name,member,XLY_DataType from tb_qxingroup where groupid !='' ")+ ')');
		for(var index in data){
			var obj=new GroupContact();
			obj.id = data[index].groupid;
			obj.name = data[index].name;
			obj.member=data[index].member;
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//通话记录
function getTeleInfo(path)
{
	var arr = new Array();
	try{
		var data =eval('(' + XLY.Sqlite.Find(path, "select telphone,calltime,calltype,count,XLY_DataType from tb_call  where telphone !=''")+ ')');
		for(var index in data){
			var obj=new TeleHistory();
			obj.call = data[index].telphone;
			obj.callMode=data[index].calltype;
			obj.callTime = XLY.Convert.LinuxToDateTime(data[index].calltime);
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			switch (obj.callMode)
			{
			case 0: obj.callMode="电话";break;
			case 2: obj.callMode="短信";break;
			}
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;

//数据恢复库的生成
var path1=source[0]+"\\com.tencent.contacts\\Documents\\appinfo\\appinfo.db";
var path2=source[0]+"\\com.tencent.contacts\\Documents\\appinfo\\config.db";
var path3=source[0]+"\\com.tencent.contacts\\Documents\\";
var charactor1="chalib\\IOS_QQcontact_V5.4.1\\appinfo.db.charactor";
var charactor2="chalib\\IOS_QQcontact_V5.4.1\\config.db.charactor";
var charactor3="chalib\\IOS_QQcontact_V5.4.1\\message.charactor";
path1=XLY.Sqlite.DataRecovery( path1,charactor1 ,"tb_records,tb_call");
path2=XLY.Sqlite.DataRecovery( path2,charactor2 ,"tb_user");

//节点的实例化
var contactNode = new TreeNode();
contactNode.Text = "电话本";
contactNode.Type = "AllContact";

var focusNode = new TreeNode();
focusNode.Text = "关注联系人";
focusNode.Type = "Focus";

var sinNode = new TreeNode();
sinNode.Text = "聊天记录(单人)";
sinNode.Type = "SinContact";

var groupNode = new TreeNode();
groupNode.Text = "聊天记录(多人)";
groupNode.Type = "GroupContact";

var callNode=new TreeNode();
callNode.Text = "通话记录(发出记录)";
callNode.Type = "TeleHistory";

//通讯录节点
contactNode.Items=createContactNode(path1);

//Q信关注节点
focusNode.Items=getBindInfo(path2);
var uin = new Array();
uin=getBindInfo(path2);
var path4=path3+uin[0].uin+"\\message\\"
	var pathData=eval('('+XLY.File.FindFiles(path4)+')');
pathData=pathData[0];
pathData=XLY.Sqlite.DataRecovery( pathData,charactor3 ,"tb_sigmessage,tb_qxingroup,tb_collectperson,tb_member,tb_gromessage");
var data =eval('(' + XLY.Sqlite.Find(pathData, "select name,XLY_DataType from tb_collectperson where name !=''")+ ')');
for (var index in data) 
{ 
	var focusInfoNode = new TreeNode();
	focusInfoNode.Text = data[index].name;
	focusInfoNode.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
	focusInfoNode.Type = "FocusContact";
	focusInfoNode.Items=getFoucusInfo(pathData,data[index].name);
	focusNode.TreeNodes.push(focusInfoNode);
}

//单人聊天信息节点
var sindata =eval('(' + XLY.Sqlite.Find(pathData, "select name,mobile,XLY_DataType from tb_member where name !=''")+ ')');
for (var index in sindata) 
{ 
	var sinHistoryNode = new TreeNode();
	sinHistoryNode.DataState = XLY.Convert.ToDataState(sindata[index].XLY_DataType);
	sinHistoryNode.Text = sindata[index].name;
	sinHistoryNode.Type = "SinMessage";
	sinHistoryNode.Items=getSinHistory(pathData,path3, sindata[index].mobile, sindata[index].name,uin[0].bindMobile);
	sinNode.TreeNodes.push(sinHistoryNode);
}
sinNode.Items=getSinInfo(pathData);

//多人聊天信息节点
var groupdata =eval('(' + XLY.Sqlite.Find(pathData, "select groupid,name,member,XLY_DataType from tb_qxingroup where name != ''")+ ')');
for (var index in groupdata) 
{ 
	var groupHistoryNode = new TreeNode();
	groupHistoryNode.Text = groupdata[index].name;
	groupHistoryNode.DataState = XLY.Convert.ToDataState(groupdata[index].XLY_DataType);
	groupHistoryNode.Type = "GroMessage";
	groupHistoryNode.Items=getGroupHistory(pathData,path3, groupdata[index].groupid,uin[0].bindMobile, groupdata[index].name);
	groupNode.TreeNodes.push(groupHistoryNode);
}
groupNode.Items=getGroupInfo(pathData);
callNode.Items=getTeleInfo(path1);

//打印数据
result.push(contactNode);
result.push(callNode);
result.push(focusNode);
result.push(sinNode);
result.push(groupNode);
var res = JSON.stringify(result);
res;
