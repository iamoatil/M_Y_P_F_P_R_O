﻿/*[config]
<plugin name="携程旅行,1" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/XieCheng.png" app="ctrip.android.view" version="5.4.2" description="携程旅行" data="$data,ComplexTreeDataSource" >
<source>  
<value>/data/data/ctrip.android.view/databases/ctrip_userinfo.db</value>
<value>/data/data/ctrip.android.view/app_database/localstorage/file__0.localstorage</value>
<value>/data/data/ctrip.android.view/databases/ctrip.db</value>
</source>
<data type="Information">
<item name="帐户" code="id" type="string" width="100" ></item>
<item name="姓名" code="name" type="string" width="100" ></item>
<item name="VIP等级" code="level" type="string" width="100" ></item>
<item name="积分" code="exp" type="string" width="100" ></item>
<item name="生日" code="birthday" type="string" width="100" ></item>
<item name="电子邮件" code="email" type="string" width="200" ></item>
<item name="手机" code="mobile" type="string" width="100" ></item>
<item name="绑定手机" code="bindMobile" type="string" width="100" ></item>
</data>
<data type="Location" contract="Map" datefilter="Date">
<item name="城市" code="city" type="string" width="100" ></item>
<item name="地址" code="Desc" type="string" width="300" ></item>
<item name="经度" code="Longitude" type="double" format="F6" width="" ></item>
<item name="纬度" code="Latitude" type="double" format="F4"  width="" ></item>
<item name="校准时间" code="Date" type="string" width="200" ></item>
</data>
<data type="AirSearch">
<item name="起飞城市" code="depart" type="string" width="100" ></item>
<item name="降落城市" code="arrive" type="string" width="100"></item>   
</data>
<data type="AirCache">
<item name="到达地" code="Aaddress" type="string" width="100" ></item>
<item name="出发地" code="Baddress" type="string" width="100"></item>
<item name="姓名" code="name" type="string" width="100"></item>
<item name="证件编号" code="IDnum" type="string" width="100" ></item>
<item name="证件类型" code="IDtype" type="string" width="100" ></item>
<item name="手机" code="mobile" type="string" width="100" ></item>
<item name="生日" code="birthday" type="string" width="100" ></item>
<item name="电子邮件" code="email" type="string" width="100"></item>
</data>
<data type="TrainSearch" datefilter="departDate">
<item name="出站城市" code="depart" type="string" width="100" ></item>
<item name="入站城市" code="arrive" type="string" width="100"></item>
<item name="出发日期" code="departDate" type="string" width="100"></item>
<item name="车次类型" code="trainType" type="string" width="100"></item>
</data>
<data type="TrainCache">   
<item name="姓名" code="name" type="string" width="100"></item>
<item name="证件编号" code="IDnum" type="string" width="200" ></item>
<item name="证件类型" code="IDtype" type="string" width="100" ></item>
<item name="手机" code="mobile" type="string" width="100" ></item>
<item name="生日" code="birthday" type="string" width="100" ></item>
<item name="电子邮箱" code="email" type="string" width="100"></item>
<item name="到达地" code="Aaddress" type="string" width="100" ></item>
<item name="出发地" code="Baddress" type="string" width="100"></item>
</data>
<data type="HotelSearch" datefilter="checkInDate">
<item name="城市" code="city" type="string" width="100" ></item>
<item name="关键字" code="keyword" type="string" width="100" ></item>
<item name="入住日期" code="checkInDate" type="string" width="100"></item>
<item name="入住天数" code="checkInNo" type="string" width="100"></item>
</data>
<data type="HotelCache">
<item name="姓名" code="name" type="string" width="100" ></item>
<item name="联系电话" code="mobile" type="string" width="100" ></item>
<item name="电子邮箱" code="email" type="string" width="100"></item>
</data>
<data type="Unpoint" datefilter="indate">
<item name="订单号" code="id" type="string" width="100" ></item>
<item name="酒店" code="hotelName" type="string" width="300" ></item>
<item name="入住时间" code="indate" type="string" width="150" ></item>
<item name="退房时间" code="outdate" type="string" width="150" ></item>
<item name="价格" code="price" type="string" width="100" ></item>
<item name="订单状态" code="statusRmk" type="string" width="100" ></item>
</data>
<data type="CollectHotel"  contract="Map">
<item name="酒店" code="Desc" type="string" width="300" ></item>
<item name="经度" code="Longitude" type="double" format="F6" width="" ></item>
<item name="纬度" code="Latitude" type="double" format="F4"  width="" ></item>
<item name="城市" code="cifty" type="string" width="100" ></item>
<item name="时间" code="Date" type="datetime" width="" show="false"></item>
</data>
</plugin>
[config]*/

//定义数据结构

function Information() {
	this.id = "";
	this.name = "";
	this.level = "";
	this.exp = "";
	this.birthday = "";
	this.email = "";
	this.mobile = "";
	this.bindMobile = "";
}

function Location() {
	this.city = "";
	this.Desc = "";
	this.Longitude = "";
	this.Latitude = "";
	this.Date = "";
}

function AirSearch() {
	this.depart = "";
	this.arrive = "";
}

function AirCache() {
	this.Aaddress = "";
	this.Baddress = "";
	this.name = "";
	this.IDnum = "";
	this.IDtype = "";
	this.mobile = "";
	this.birthday = "";
	this.email = "";
}

function TrainSearch() {
	this.depart = "";
	this.arrive = "";
	this.departDate = "";
	this.trainType = "";
}

function TrainCache() {
	this.name = "";
	this.IDnum = "";
	this.IDtype = "";
	this.mobile = "";
	this.birthday = "";
	this.email = "";
	this.Aaddress = "";
	this.Baddress = "";
}

function HotelSearch() {
	this.city = "";
	this.keyword = "";
	this.checkInDate = "";
	this.checkInNo = "";
}

function HotelCache() {
	this.name = "";
	this.mobile = "";
	this.email = "";
}

function Unpoint() {
	this.id = "";
	this.hotelName = "";
	this.indate = "";
	this.outdate = "";
	this.price = "";
	this.statusRmk = "";
}

function CollectHotel() {
	this.Desc = "";
	this.Longitude = "";
	this.Latitude = "";
	this.city = "";
	this.Date="";
}


//树形结构
function TreeNode()
{
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
}


//飞机，火车缓存记录
function atCacheNodeCreate(path, type) 
{
	var arr = new Array();
	try{
		var user = eval('(' + XLY.Sqlite.Find(path, "select option_value from user_settings where option = 'USER_ID'") + ')');
		if(user[0]){
			user = user[0].option_value;
			var arr = new Array();
			if (type == "airplane") {
				var info = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='lastPassengerList' and user ='" + user + "'") + ')');
				if(info[0]){
					for (var i = 0; i < info.length; i++) 
					{
						var data = eval(info[i].item_value);
						for (var index in data) 
						{
							var obj = new AirCache();
							obj.Aaddress = data[index].arrivalAddress;
							obj.Baddress = data[index].localAddress;
							obj.name = data[index].nameCN;
							obj.IDnum = data[index].idCardChildModel.iDCardNo;
							obj.IDtype = data[index].idCardChildModel.idCardName;
							obj.mobile = data[index].mobilephone;
							obj.birthday = XLY.Convert.ToDateTime(data[index].birthday, "yyyyMMdd");
							obj.email = data[index].email;
							arr.push(obj);}
					}
				}
			}
			if (type == "train") {
				var info = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='TRAIN_PASSANGERS' and user ='" + user + "'") + ')');
				if(info[0]){
					for (var i = 0; i < info.length; i++) 
					{
						var data = eval(info[i].item_value);
						for (var index in data) 
						{
							var obj = new TrainCache();
							obj.Aaddress = data[index].arrivalAddress;
							obj.Baddress = data[index].localAddress;
							obj.name = data[index].nameCN;
							obj.IDnum = data[index].idCardChildModel.iDCardNo;
							obj.IDtype = data[index].idCardChildModel.idCardName;
							obj.mobile = data[index].mobilephone;
							obj.birthday = XLY.Convert.ToDateTime(data[index].birthday, "yyyyMMdd");
							obj.email = data[index].email;
							arr.push(obj);}
					}
				}
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}


//酒店缓存记录
function hotelCacheNodeCreate(path)
{
	var arr = new Array();
	try{
		var user = eval('(' + XLY.Sqlite.Find(path, "select option_value from user_settings where option = 'USER_ID'") + ')');
		if(user[0]){
			user = user[0].option_value;
			var info = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='KEY_HOTEL_CONTACT' and user ='" + user + "'") + ')');
			if(info[0]){
				var i = 0;
				for (; i < info.length; i++) {
					var data = eval('(' + info[i].item_value + ')');
					var obj = new HotelCache();
					obj.name = data.contactName;
					obj.mobile = data.contactMobile;
					obj.email = data.contactEMail;
					arr.push(obj);}}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}


//用户信息
function userInfoNodeCreate(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select  value from ItemTable where key='USER'") + ')');
		if(data[0]){
			data = eval('(' + data[0].value + ')');
			var obj = new Information();
			obj.id = data.value.UserID;
			obj.name = data.value.UserName;
			obj.level = data.value.VipGrade;
			obj.exp = data.value.Experience;
			obj.birthday = XLY.Convert.ToDateTime(data.value.Birthday, "yyyyMMdd");
			obj.email = data.value.Email;
			obj.mobile = data.value.Mobile;
			obj.bindMobile = data.value.BindMobile;
			arr.push(obj);}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//用户定位信息
function userLocationNodeCreate(path) 
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select  value from ItemTable where key='POSITION_CITY'") + ')'); 
		if(data[0]){
			data = eval('(' + data[0].value + ')');
			var obj = new Location();
			obj.city = data.value.city;
			obj.Desc = data.value.address;
			obj.Longitude = data.value.lng;
			obj.Latitude = data.value.lat;
			obj.Date = data.savedate;
			arr.push(obj);}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//酒店收藏
function hotelCollectionNodeCreate(path) 
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select  value from ItemTable where key='MYCTRIP_HOTEL_FAV_LIST'") + ')');
		if(data[0]){
			data = eval('(' + data[0].value + ')');
			for (var index in data.value.hotels) {
				var obj = new CollectHotel();
				obj.city = data.value.hotels[index].ctyName;
				obj.Desc = data.value.hotels[index].name;
				obj.Longitude = data.value.hotels[index].coords[0].lon;
				obj.Latitude = data.value.hotels[index].coords[0].lat;
				arr.push(obj);}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//未点评
function unpointNodeCreate(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select  value from ItemTable where key='USER_WAITFORTCOMMENT_ORDER_LIST'") + ')');
		data = eval('(' + data[0].value + ')');
		for (var index in data.value.orders) {
			var obj = new Unpoint();
			obj.id = data.value.orders[index].id;
			obj.hotelName = data.value.orders[index].hotelName;
			obj.indate = data.value.orders[index].indate;
			obj.outdate = data.value.orders[index].outdate;
			obj.price = data.value.orders[index].price;
			obj.statusRmk = data.value.orders[index].statusRmk;
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//航班查询记录
function airSearchNodeCreate(path1, path2) {
	var arr = new Array();
	try{
		var obj = new AirSearch();
		var lastDepartCity = eval('(' + XLY.Sqlite.Find(path1, "select item_value from user_info where item_key='lastDepartCity' AND cachebean = 'FlightInquireCacheBean' ") + ')');
		if( lastDepartCity[0]){
			var lastArriveCity = eval('(' + XLY.Sqlite.Find(path1, "select item_value from user_info where item_key='lastArriveCity' AND cachebean = 'FlightInquireCacheBean' ") + ')');
			var INTlastDepartCity = eval('(' + XLY.Sqlite.Find(path2, "select cityName from flight_city where cityID='" + lastDepartCity[0].item_value + "' ") + ')');
			var INTlastArriveCity = eval('(' + XLY.Sqlite.Find(path2, "select cityName from flight_city where cityID='" + lastArriveCity[0].item_value + "' ") + ')');
			obj.depart = INTlastDepartCity[0].cityName;
			obj.arrive = INTlastArriveCity[0].cityName;
			arr.push(obj);}
		return arr
	}
	catch(e){
		return arr;
	}
}

//火车查询记录
function trainSearchNodeCreate(path1, path2) {
	var arr = new Array();
	try{
		var obj = new TrainSearch();
		var departStationId = eval('(' + XLY.Sqlite.Find(path1, "select item_value from user_info where item_key='departStationId' AND cachebean = 'TrainInquireCacheBean' ") + ')');
		if( departStationId[0]){
			var arriveStationId = eval('(' + XLY.Sqlite.Find(path1, "select item_value from user_info where item_key='arriveStationId' AND cachebean = 'TrainInquireCacheBean' ") + ')');
			var departDate = eval('(' + XLY.Sqlite.Find(path1, "select item_value from user_info where item_key='departDate' AND cachebean = 'TrainInquireCacheBean' ") + ')');
			var trainType = eval('(' + XLY.Sqlite.Find(path1, "select item_value from user_info where item_key='trainType' AND cachebean = 'TrainInquireCacheBean' ") + ')');
			var departStation = eval('(' + XLY.Sqlite.Find(path2, "select stationName from rail_city where stationId='" + departStationId[0].item_value + "' ") + ')');
			var arriveStation = eval('(' + XLY.Sqlite.Find(path2, "select stationName from rail_city where stationId='" + arriveStationId[0].item_value + "' ") + ')');
			obj.depart = departStation[0].stationName;
			obj.arrive = arriveStation[0].stationName;
			obj.departDate = XLY.Convert.ToDateTime(departDate[0].item_value, "yyyyMMdd");
			if (trainType[0].item_value == -1) {
				obj.trainType = "不限";
			}
			else if (trainType[0].item_value == 1) {
				obj.trainType = "高铁/动车";
			}
			else if (trainType[0].item_value == 2) {
				obj.trainType = "普通";
			}
			arr.push(obj);}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//酒店查询记录
function hotelSearchNodeCreate(path) {
	var arr = new Array();
	try{
		var obj = new HotelSearch();
		var city_model = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='city_model' AND cachebean = 'HotelInquireMainCacheBean' ") + ')');
		if( city_model[0]){
			city_model = eval('(' + city_model[0].item_value + ')');
			var hotel_keyword_key = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='hotel_keyword_key' AND cachebean = 'HotelInquireMainCacheBean' ") + ')');
			if( hotel_keyword_key[0].item_value){
				hotel_keyword_key = eval('(' + hotel_keyword_key[0].item_value + ')');
				var checkInDate = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='checkInDate' AND cachebean = 'HotelInquireMainCacheBean' ") + ')');
				var nightCount = eval('(' + XLY.Sqlite.Find(path, "select item_value from user_info where item_key='nightCount' AND cachebean = 'HotelInquireMainCacheBean' ") + ')');
				obj.city = city_model.name;
				obj.keyword = hotel_keyword_key.dataName;
				obj.checkInDate = XLY.Convert.ToDateTime(checkInDate[0].item_value, "yyyyMMdd");
				obj.checkInNo = nightCount[0].item_value;
				arr.push(obj);}}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0];
var path2 = source[1];
var path3 = source[2];

var userNode = new TreeNode();
userNode.Text = "用户信息";

var userInfoNode = new TreeNode();
userInfoNode.Text = "账户信息";
userInfoNode.Type = "Information";

var userLocationNode = new TreeNode();
userLocationNode.Text = "定位信息";
userLocationNode.Type = "Location";

var searchNode = new TreeNode();
searchNode.Text = "最新查询痕迹";

var airplaneNode = new TreeNode();
airplaneNode.Text = "飞机";

var airSearchotelNode = new TreeNode();
airSearchotelNode.Text = "查询记录缓存";
airSearchotelNode.Type = "AirSearch";


var airCacheNode = new TreeNode();
airCacheNode.Text = "用户信息缓存";
airCacheNode.Type = "AirCache";

var trainNode = new TreeNode();
trainNode.Text = "火车";

var trainSearchotelNode = new TreeNode();
trainSearchotelNode.Text = "查询记录缓存";
trainSearchotelNode.Type = "TrainSearch";

var trainCacheNode = new TreeNode();
trainCacheNode.Text = "用户信息缓存";
trainCacheNode.Type = "TrainCache";

var hotelNode = new TreeNode();
hotelNode.Text = "酒店";

var hotelSearchNode = new TreeNode();
hotelSearchNode.Text = "查询记录缓存";
hotelSearchNode.Type = "HotelSearch";

var hotelCacheNode = new TreeNode();
hotelCacheNode.Text = "用户信息缓存";
hotelCacheNode.Type = "HotelCache";

var unpointNode = new TreeNode();
unpointNode.Text = "待点评订单";

var unpointHotelNode = new TreeNode();
unpointHotelNode.Text = "酒店";
unpointHotelNode.Type = "Unpoint";

var collectionNode = new TreeNode();
collectionNode.Text = "收藏";

var hotelCollectionNode = new TreeNode();
hotelCollectionNode.Text = "旅店收藏";
hotelCollectionNode.Type = "CollectHotel";

//填充树
userInfoNode.Items = userInfoNodeCreate(path2);
userLocationNode.Items = userLocationNodeCreate(path2);
airSearchotelNode.Items = airSearchNodeCreate(path1, path3);
trainSearchotelNode.Items = trainSearchNodeCreate(path1, path3);
airCacheNode.Items = atCacheNodeCreate(path1, "airplane");
trainCacheNode.Items = atCacheNodeCreate(path1, "train");
hotelSearchNode.Items = hotelSearchNodeCreate(path1);
hotelCacheNode.Items = hotelCacheNodeCreate(path1);
hotelCollectionNode.Items = hotelCollectionNodeCreate(path2);
unpointHotelNode.Items = unpointNodeCreate(path2);

//打印数据
userNode.TreeNodes.push(userInfoNode);
userNode.TreeNodes.push(userLocationNode);
airplaneNode.TreeNodes.push(airSearchotelNode);
airplaneNode.TreeNodes.push(airCacheNode);
trainNode.TreeNodes.push(trainSearchotelNode);
trainNode.TreeNodes.push(trainCacheNode);
hotelNode.TreeNodes.push(hotelSearchNode);
hotelNode.TreeNodes.push(hotelCacheNode);
searchNode.TreeNodes.push(airplaneNode);
searchNode.TreeNodes.push(trainNode);
searchNode.TreeNodes.push(hotelNode);
collectionNode.TreeNodes.push(hotelCollectionNode);
unpointNode.TreeNodes.push(unpointHotelNode);
result.push(userNode);
result.push(searchNode);
result.push(unpointNode);
result.push(collectionNode);
var res = JSON.stringify(result);
res;
