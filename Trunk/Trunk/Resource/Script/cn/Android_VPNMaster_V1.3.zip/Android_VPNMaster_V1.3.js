﻿/*[config]
<plugin name="VPNMaster,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/vpnmaster.png" app="com.aresmob.mastervpn" version="1.3" description="VPNMaster" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.aresmob.mastervpn/shared_prefs#F</value>
    <value>/data/data/com.aresmob.mastervpn/files/umeng_it.cache</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="当前是否连接服务器" code="IsConnect" type="string" width = "120"></item>
    <item name="设备信息" code="DeviceInfo" type="string" width = "100"></item>
    <item name="设备AndroidID" code="DeviceAndroidID" type="string" width = "100"></item>
    <item name="设备序列号" code="DeviceXLY" type="string" width = "100"></item>
    <item name="设备MAC地址" code="DeviceMAC" type="string" width = "100"></item>
    <item name="是否自动获取位置" code="AutoCollectLocation" type="string" width="100"></item>
    <item name="首次激活时间" code="FirstActivateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后请求服务器时间" code="LastReq" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="成功请求次数" code="SuccessfulCount" type="string" width = "80"></item>
    <item name="失败请求次数" code="FailedCount" type="string" width = "80"></item>
    <item name="最后访问服务器ip" code="LastServerIP" type="string" width = "80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.DeviceInfo = "";
    this.IsConnect = "否";
    this.AutoCollectLocation = "否";
    this.FirstActivateTime = null;
    this.LastReq = null;
    this.SuccessfulCount = "";
    this.FailedCount = "";
    this.LastServerIP = "";
    this.DeviceAndroidID = "";
    this.DeviceXLY = "";
    this.DeviceMAC = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];
var filePath = source[1];

//测试数据
//var allPath = "F:\\temp\\data\\data\\com.aresmob.mastervpn\\shared_prefs";
//var filePath = "F:\\temp\\data\\data\\com.aresmob.mastervpn\\files\\umeng_it.cache";
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "VPNMaster";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Text = "用户信息";
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    var gmsPath = allPath + "\\com.google.android.gms.measurement.prefs.xml";
    if(XLY.File.IsValid(gmsPath)){
        var gmsData = eval('('+ XLY.File.ReadXML(gmsPath) +')');
        if(gmsData!=""&&gmsData!=null){
            var gmsBoolData = gmsData.map.boolean;
            if(gmsBoolData!=""&&gmsBoolData!=null){
                for(var a in gmsBoolData){
                    if(gmsBoolData[a]["@name"]=="has_been_opened"){
                        if(gmsBoolData[a]["@value"]=="true"){
                            obj.IsConnect = "是";
                        }
                    }
                }
            }
        }
    }
    var admPath = allPath + "\\admob_user_agent.xml";
    if(XLY.File.IsValid(admPath)){
        var admData = eval('('+ XLY.File.ReadXML(admPath) +')');
        if(admData!=""&&admData!=null){
            var admStrData = admData.map.string;
            if(admStrData["#text"]!=""&&admStrData["#text"]!= null){
                obj.DeviceInfo = admStrData["#text"];
            }
        }
    }
    var adm1Path = allPath + "\\admob.xml";
    if(XLY.File.IsValid(adm1Path)){
        var adm1Data = eval('('+ XLY.File.ReadXML(adm1Path) +')');
        if(adm1Data!=""&&adm1Data!= null){
            var adm1BoolData = adm1Data.map.boolean;
            if(adm1BoolData!=""&&adm1BoolData!=null){
                for(var b in adm1BoolData){
                    if(adm1BoolData[b]["@name"]=="auto_collect_location"){
                        if(adm1BoolData[b]["@value"]=="true"){
                            obj.AutoCollectLocation = "是";
                        }
                    }
                }
            }
        }
    }
    var umePath = allPath + "\\umeng_general_config.xml";
    if(XLY.File.IsValid(umePath)){
        var umeData = eval('('+ XLY.File.ReadXML(umePath) +')');
        if(umeData!=""&&umeData!= null){
            var umeIntData = umeData.map.int;
            if(umeIntData!=""&&umeIntData!= null){
                for(var c in umeIntData){
                    if(umeIntData[c]["@name"]=="failed_requests"){
                        obj.FailedCount = umeIntData[c]["@value"];
                    }
                    if(umeIntData[c]["@name"]=="successful_request"){
                        obj.SuccessfulCount = umeIntData[c]["@value"];
                    }
                }
            }
            var umeLongData = umeData.map.long;
            if(umeLongData!=""&&umeLongData!= null){
                for(var d in umeLongData){
                    if(umeLongData[d]["@name"]=="last_request_time"){
                        obj.FirstActivateTime = XLY.Convert.LinuxToDateTime(umeLongData[d]["@value"]);
                    }
                    if(umeLongData[d]["@name"]=="first_activate_time"){
                        obj.LastReq = XLY.Convert.LinuxToDateTime(umeLongData[d]["@value"]);
                    }
                }
            }
        }
    }
    var msterPath = allPath + "\\master_vpn_sp.xml";
    if(XLY.File.IsValid(msterPath)){
        var msData = eval('('+ XLY.File.ReadXML(msterPath) +')');
        if(msData!=""&&msData!=null){
            var msStrData = msData.map.string;
            if(msStrData["#text"]!=""&&msStrData["#text"]!= null){
                obj.LastServerIP = msStrData["#text"];
            }
        }
    }
    if(XLY.File.IsValid(filePath)){
        var arr = getFileInfo(usernode,filePath);
        obj.DeviceMAC = arr.mac;
        obj.DeviceXLY = arr.serial;
        obj.DeviceAndroidID = arr.android_id;
    }
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}
function getFileInfo(root,path){
    var handle = XLY.Blob.GetFileHandle(path);
    var aa = [0x73,0x65,0x72,0x69,0x61,0x6C];
    var bb = [0x61,0x6E,0x64,0x72,0x6F,0x69,0x64,0x5F,0x69,0x64];
    var cc = [0x6D,0x61,0x63];
    var a = XLY.Blob.FindBytesFromHandle(handle,0,aa);
    var b = XLY.Blob.FindBytesFromHandle(handle,0,bb);
    var c = XLY.Blob.FindBytesFromHandle(handle,0,cc);
    var arr = {};
    if(a!=-1){
        var aaa = XLY.Blob.GetBytesFromHandle(handle,a+8,XLY.Blob.GetBytesFromHandle(handle,a+7,1)[0]);
        arr.serial = XLY.Blob.ToString(aaa);
    }
    if(b!=-1){
        var bbb = XLY.Blob.GetBytesFromHandle(handle,b+0x0C,XLY.Blob.GetBytesFromHandle(handle,b+0x0B,1)[0]);
        arr.android_id = XLY.Blob.ToString(bbb);
    }
    if(c!=-1){
        var ccc = XLY.Blob.GetBytesFromHandle(handle,c+5,XLY.Blob.GetBytesFromHandle(handle,c+4,1)[0]);
        arr.mac = XLY.Blob.ToString(ccc);
    }
    XLY.Blob.CloseFileHandle(handle);
    return arr;
}