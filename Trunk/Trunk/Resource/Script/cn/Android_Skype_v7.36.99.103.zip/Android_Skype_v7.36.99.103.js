﻿/*[config]
<plugin name="Skype,10" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/skype.png" app="com.skype.rover" version="7.36.99.103" description="Skype" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.skype.rover/files#F</value>
    <value>/data/data/com.skype.rover/shared_prefs/sharedGlobalPreferences.xml</value>
</source>
<data type="UserList" >
    <item name="用户名" code="UName" type="string" width="120" format=""></item>
    <item name="头像" code="Avatar" type="string" width="280" format = ""></item>
    <item name="昵称" code="DName" type="string" width="150" format = ""></item>
    <item name="帐号类型" code="AType" type="string" width="100" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="Skype用户名" code="Skypename" type="string" width="100" format=""></item>
    <item name="全名" code="Fname" type="string" width="100" format = ""></item>
    <item name="性别" code="Gender" type="string" width="80" format = ""></item>
    <item name="生日" code="Birthday" type="string" width="120" format = ""></item>
    <item name="注册地址" code="Addr" type="string" width="200" format = ""></item>
    <item name="个人说明" code="About" type="string" width="240" format = ""></item>
    <item name="签名" code="Mood" type="string" width="200" format=""></item>
    <item name="邮箱地址" code="Emails" type="string" width="200" format = ""></item>
    <item name="联系电话" code="Phones" type="string" width="240" format = ""></item>
    <item name="创建时间" code="Time" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="ConUser" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="Skype用户名" code="Skypename" type="string" width="100" format=""></item>
    <item name="昵称" code="Nick" type="string" width="100" format = ""></item>
    <item name="会话创建时间" code="CTime" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后会话时间" code="LTime" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="GUser" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群组名称" code="GName" type="string" width="100" format=""></item>
    <item name="群组成员" code="GMember" type="string" width="100" format = ""></item>
    <item name="会话创建时间" code="CTime" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后会话时间" code="LTime" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type = "Messages" detailfield = "Body" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="消息发送者" code="Sender" type="string" width="150" format = ""></item>
    <item name="消息接收者" code="Receiver" type="string" width="150" format = ""></item>
    <item name="消息内容" code="Body" type="string" width="200" format = ""></item>
    <item name="消息类型" code="Type" type="string" width="120" format = "" order="desc"></item>
    <item name="发送时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="备注" code="Mark" type="string" width="120" format = ""></item>
</data>

<data type="Call" contract="DataState"  datefilter = "Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="通话拨打方" code="Sender" type="string" width="120" alignment="center"></item>
    <item name="通话接听方" code="Receiver" type="string" width="120" format=""></item>
    <item name="通话时长" code="Duration" type="string" width="100" format = ""></item>
    <item name="通话类型" code="Type" type="string" width="100" format = ""></item>
    <item name="接通时间" code="Time" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="创建时间" code="CreateTime" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="备注" code="Mark" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function UserList() {
    this.UName = "";    //用户名
    this.Avatar = "";   //头像
    this.DName = "";    //昵称
    this.AType = "";    //帐号类型
    this.MDFString = "";    //MD5
}

function UserInfo() {
    this.DataState = "Normal";  //数据状态
    this.Skypename = "";    //Skype用户名
    this.Fname = "";    //全名
    this.Gender = "";   //性别
    this.Birthday = "未指定"; //生日
    this.Addr = "未设置"; //注册地址
    this.About = "未设置";    //个人说明
    this.Mood = "未设置"; //签名
    this.Emails = "未设置";   //邮箱地址
    this.Phones = "未设置";   //联系电话
    this.Time = null;   //创建时间
    this.MDFString = "";    //MD5
}


function ConUser() {
    this.DataState = "Normal";  //数据状态
    this.Skypename = "";    //Skype用户名
    this.Nick = ""; //昵称
    this.CTime = null;  //会话创建时间
    this.LTime = null;  //最后会话时间
    this.MDFString = "";    //MD5
}

function GUser() {
    this.DataState = "Normal";  //数据状态
    this.GName = "";    
    this.GMember = ""; 
    this.CTime = null;  //会话创建时间
    this.LTime = null;  //最后会话时间
    this.MDFString = "";    //MD5
}

function Messages() {
    this.DataState = "Normal";  //数据状态
    this.Sender = "";   //消息发送者
    this.Receiver = ""; //消息接收者
    this.Body = ""; //消息内容
    this.Type = ""; //消息类型
    this.Time = null;   //发送时间
    this.Mark = ""; //备注
    this.MDFString = "";    //MD5
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var fpath = source[0];
var spath = source[1];
//测试数据
//var spath = "C:\\Users\\liu\\Desktop\\com.skype.rover\\shared_prefs\\sharedGlobalPreferences.xml";
//var fpath = "C:\\Users\\liu\\Desktop\\com.skype.rover\\files";

//定义特征库文件
var charactor = "chalib\\Android_Skype_v7.36.99.103\\main.db.charactor";

//恢复数据库中删除的数据
//var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var skype = new TreeNode();
    skype.Text = "Skype";
    skype.Type = "UserList";
    var ulist = getUserList();
    
    var data = eval('('+ XLY.File.FindDirectories(fpath) +')');
    
    skype.Items = ulist;
    for(var i in ulist){
        var dpath;
        if(ulist[i].AType=="SKYPE"){
            dpath  = fpath+"\\"+ulist[i].UName;
            dpath = dpath+"\\main.db";
            if(XLY.File.IsValid(dpath)){
                dpath = XLY.Sqlite.DataRecovery(dpath,charactor ,"Accounts,CallMembers,Contacts,Messages,Conversations,Participants");
                var udata = eval('('+ XLY.Sqlite.Find(dpath,"select * from Accounts") +')');
                if(udata.length>0 && udata!= null){
                    var user = new TreeNode();
                    user.Text = udata[0].fullname +"_"+ udata[0].skypename;
                    user.Type = "UserInfo";
                    user.Items.push(getUserInfo(udata[0]));
                    buildUserSubNode(user,dpath,udata[0].fullname);
                }
                
                skype.TreeNodes.push(user);
            }
        }
        else
        {
            var uid = ulist[i].UName.substr(0,ulist[i].UName.indexOf('@'));
            var reg1 = new RegExp(uid,"i");
            for(var j in data){
                if(reg1.test(data[j])){
                    dpath  = data[j]+"\\main.db";
                    if(XLY.File.IsValid(dpath)){
                        dpath = XLY.Sqlite.DataRecovery(dpath,charactor ,"Accounts,CallMembers,Contacts,Messages,Conversations,Participants");
                        var udata = eval('('+ XLY.Sqlite.Find(dpath,"select * from Accounts") +')');
                        if(udata.length>0 && udata!= null){
                            var user = new TreeNode();
                            user.Text = udata[0].fullname +"_"+ udata[0].skypename;
                            user.Type = "UserInfo";
                            user.Items.push(getUserInfo(udata[0]));
                            buildUserSubNode(user,dpath,udata[0].fullname);
                        }
                        skype.TreeNodes.push(user);
                    }
                }
            }
        }
        
    }
    
    //skype.Items = ulist;
    //for(var i in ulist){
    //    var dpath;
    //    if(ulist[i].AType=="SKYPE"){
    //        dpath  = fpath+"\\"+ulist[i].UName;
    //        dpath = dpath+"\\main.db";
    //    }
    //    else
    //    {
            //var uid = ulist[i].UName.substr(0,ulist[i].UName.indexOf('@'));
            //dpath  = fpath+"\\live#3a"+uid;
            //var data = eval('('+ XLY.File.FindDirectories(fpath) +')');
            //var reg1 = new RegExp("live#","i");
            //for(var j in data){
            //    var dlength = data[j].split("\\").length;
            //    var dinfo = data[j].split("\\")[dlength-1];
            //    if(reg1.test(dinfo)){
            //        dpath = fpath+"\\"+dinfo+"\\main.db";
            //        if(XLY.File.IsValid(dpath)){
            //            dpath = XLY.Sqlite.DataRecovery(dpath,charactor ,"Accounts,CallMembers,Contacts,Messages,Conversations,Participants");
            //            var udata = eval('('+ XLY.Sqlite.Find(dpath,"select * from Accounts") +')');
            //            if(udata.length>0 && udata!= null){
            //                var user = new TreeNode();
            //                user.Text = udata[0].fullname + udata[0].skypename;
            //                user.Type = "UserInfo";
            //                user.Items.push(getUserInfo(udata[0]));
            //                buildUserSubNode(user,dpath,udata[0].fullname);
            //            }
            //            
            //            skype.TreeNodes.push(user);
            //        }
            //    }
            //}
        //}
        
    //}
    //var data = eval('('+ XLY.File.FindDirectories(fpath) +')');
    //var reg1 = new RegExp("live#","i");
    //for(var i in data){
    //    var dlength = data[i].split("\\").length;
    //    var dinfo = data[i].split("\\")[dlength-1];
    //    if(reg1.test(dinfo)){
    //        dpath = fpath+"\\"+dinfo+"\\main.db";
    //        if(XLY.File.IsValid(dpath)){
    //            dpath = XLY.Sqlite.DataRecovery(dpath,charactor ,"Accounts,CallMembers,Contacts,Messages,Conversations,Participants");
    //            var udata = eval('('+ XLY.Sqlite.Find(dpath,"select * from Accounts") +')');
    //            if(udata.length>0 && udata!= null){
    //                var user = new TreeNode();
    //                user.Text = udata[0].fullname + udata[0].skypename;
    //                user.Type = "UserInfo";
    //                user.Items.push(getUserInfo(udata[0]));
    //                buildUserSubNode(user,dpath,udata[0].fullname);
    //            }
    //            skype.TreeNodes.push(user);
    //        }
    //    }
    //}
    result.push(skype);
}

function getUserList(){
    if(XLY.File.IsValid(spath)){
        var data = eval('('+ XLY.File.ReadXML(spath) +')');
        if(data!=null){
            var ul = data.map.string;
            if(ul['@name']=="existingAccounts"){
                var acc = eval('('+ ul['#text'] +')');
                acc = acc.accounts;
                if(acc.length>0&&acc!= null){
                    var info = new Array();
                    for(var i in acc){
                        var uobj = new UserList;
                        uobj.UName = acc[i].username;  //用户名
                        uobj.Avatar = acc[i].avatarUrl;   //头像
                        uobj.DName = acc[i].displayname;    //昵称
                        uobj.AType = acc[i].type;    //帐号类型
                        info.push(uobj);
                    }
                    return info;
                }
            }
        }
        
    }
}


function getUserInfo(data){
    var obj = new UserInfo();
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    obj.Skypename = data.skypename;    //Skype用户名
    obj.Fname = data.fullname;    //全名
    (data.gender==1)?obj.Gender = "男":(data.gender==2)?obj.Gender = "女":obj.Gender = "未指定";     //性别
    if(data.birthday!=null){
        obj.Birthday = data.birthday; //生日
    }
    if(data.country!=null){
        obj.Addr = data.country;
    }
    if(data.province!=null){
        obj.Addr += "·"+data.province;
    }
    if(data.city!=null){
        obj.Addr += "·"+data.city;
    }
    //obj.Addr = data.country+"·"+data.province+"·"+data.city; //注册地址
    if(data.about!=null){
        obj.About = data.about;    //个人说明
    }
    if(data.mood_text!=null){
        obj.Mood = data.mood_text; //签名
    }
    obj.Emails = data.emails;   //邮箱地址
    if(data.phone_mobile!=null){
        obj.Phones = "手机号码:"+data.phone_mobile;
    }
    if(data.phone_home!=null){
        obj.Phones += ";住宅号码:"+data.phone_home;
    }
    if(data.phone_office!=null){
        obj.Phones += ";住宅号码:"+data.phone_office;
    }
    //obj.Phones = "手机号码:"+data.phone_mobile+";住宅号码:"+data.phone_home+";办公室号码:"+data.phone_office;   //联系电话
    if(data.profile_timestamp!=null){
        obj.Time = XLY.Convert.LinuxToDateTime(data.profile_timestamp);
    }
    return obj;
}


function buildUserSubNode(node,path,uname){
    var friend = new TreeNode();
    friend.Text = "好友信息";
    buildFriendSubNode(friend,path);
    node.TreeNodes.push(friend);
    
    var conversation = new TreeNode();
    conversation.Text = "会话记录";
    //conversation.Type = "ConUser";
    buildConversationSubNode(conversation,path,uname)
    node.TreeNodes.push(conversation);
    
    var call = new TreeNode();
    call.Text = "通话记录";
    buildCallSubNode(call,path,uname);
    node.TreeNodes.push(call);
}

function buildFriendSubNode(node,path){
    //联系人信息
    var cdata = eval('('+ XLY.Sqlite.Find(path,"select * from Contacts") +')');
    if(cdata.length>0&&cdata!=null){
        var contact = new TreeNode();
        contact.Text = "联系人";
        contact.Type = "UserInfo";
        for(var i in cdata){
            contact.Items.push(getUserInfo(cdata[i]));
        }
        node.TreeNodes.push(contact);
    }
    
    //skype好友信息
    var sfdata = eval('('+ XLY.Sqlite.Find(path,"select * from Contacts where external_system_id = 'SKYPE'") +')');
    if(sfdata.length>0&&sfdata!=null){
        var skypefriend = new TreeNode();
        skypefriend.Text = "Skype好友";
        skypefriend.Type = "UserInfo";
        for(var i in sfdata){
            skypefriend.Items.push(getUserInfo(sfdata[i]));
        }
        node.TreeNodes.push(skypefriend);
    }
    
    //在线好友信息
    var oldata = eval('('+ XLY.Sqlite.Find(path,"select * from Contacts where availability = 2 ") +')');
    if(oldata.length>0&&oldata!=null){
        var onlinefriend = new TreeNode();
        onlinefriend.Text = "在线好友";
        onlinefriend.Type = "UserInfo";
        for(var i in oldata){
            onlinefriend.Items.push(getUserInfo(oldata[i]));
        }
        node.TreeNodes.push(onlinefriend);
    }
    
    //常用联系人信息
    var fcdata = eval('('+ XLY.Sqlite.Find(path,"select * from Contacts where is_mobile = 0 ") +')');
    if(fcdata.length>0&&fcdata!=null){
        var fcfriend = new TreeNode();
        fcfriend.Text = "常用联系人";
        fcfriend.Type = "UserInfo";
        for(var i in fcdata){
            fcfriend.Items.push(getUserInfo(fcdata[i]));
        }
        node.TreeNodes.push(fcfriend);
    }
}


function buildConversationSubNode(node,path,user){
    if(XLY.File.IsValid(path)){
        try{
            var fdata = eval('('+ XLY.Sqlite.Find(path,"select * from Conversations where type=1 ") +')');
            if(fdata.length>0&&fdata!= null){
                var fmsg = new TreeNode();
                fmsg.Text = "好友会话记录";
                fmsg.Type = "ConUser";
                buildeMessageNode(fmsg,fdata,user,path);
                node.TreeNodes.push(fmsg);
            }
            
            
            var gdata = eval('('+ XLY.Sqlite.Find(path,"select * from Conversations where type=2 ") +')');
            if(gdata.length>0&&gdata!= null){
                var gmsg = new TreeNode();
                gmsg.Text = "群组会话记录";
                gmsg.Type = "GUser";
                for(var i in gdata){
                    var cobj = new GUser();
                    cobj.DataState = XLY.Convert.ToDataState(gdata[i].XLY_DataType);  //数据状态
                    if(gdata[i].displayname!=""&&gdata[i].displayname!=null){
                         cobj.GName = gdata[i].displayname;
                    }
                    else
                    {
                         cobj.GName = gdata[i].identity;
                    }
                    cobj.GMember = getGroupMember(path,gdata[i].id,user);

                    cobj.CTime = XLY.Convert.LinuxToDateTime(gdata[i].creation_timestamp);  //会话创建时间
                    cobj.LTime = XLY.Convert.LinuxToDateTime(gdata[i].last_activity_timestamp);  //最后会话时间
                    gmsg.Items.push(cobj);
                    
                    var idata = eval('('+ XLY.Sqlite.Find(path,"select identity from Participants where convo_id = '"+gdata[i].id+"'") +')');
                    var aa = "";
                    if(idata!=""&&idata!=null){
                        for(var mm in idata){
                            var bb= eval('('+ XLY.Sqlite.Find(path,"select fullname from Contacts where skypename = '"+idata[mm].identity+"'") +')');
                            if(bb!=""&&bb!= null){
                                if(user!=bb[0].fullname){
                                    if(bb[0].fullname!=""&&bb[0].fullname!=null){
                                        if(mm<idata.length-1){
                                            aa+= bb[0].fullname + ",";
                                        }
                                        else
                                        {
                                            aa+= bb[0].fullname;
                                        }
                                    }
                                    else
                                    {
                                        if(mm<idata.length-1){
                                            aa+= idata[mm].identity + ",";
                                        }
                                        else
                                        {
                                            aa+= idata[mm].identity;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(aa!=""&&aa!=null){
                        var message = new TreeNode();
                        message.Text = aa;//cobj.GName;

                        message.Type = "Messages";
                        getMessageInfo(path,user,gdata[i].id,message,gdata[i].type);
                        gmsg.TreeNodes.push(message);
                    }
                }
                node.TreeNodes.push(gmsg);
            }
        }
        catch(err)
        {
            return err;
        }
    }
}

function buildeMessageNode(node,condata,user,path){
    for(var i in condata){
        var cobj = new ConUser();
        cobj.DataState = XLY.Convert.ToDataState(condata[i].XLY_DataType);  //数据状态
        cobj.Skypename = condata[i].identity;    //Skype用户名
        cobj.Nick = condata[i].displayname; //昵称
        //if(condata[i].type==1){
        //    cobj.UType = "个人用户";    //用户类型
        //}
        //if(condata[i].type==2){
        //    cobj.UType = "群组";    //用户类型
        //}
        cobj.CTime = XLY.Convert.LinuxToDateTime(condata[i].creation_timestamp);  //会话创建时间
        cobj.LTime = XLY.Convert.LinuxToDateTime(condata[i].last_activity_timestamp);  //最后会话时间
        node.Items.push(cobj);
        
        
        var message = new TreeNode();
        if(cobj.Nick!=""&&cobj.Nick!=null){
             message.Text = cobj.Nick;
        }
        else
        {
             message.Text = cobj.Skypename;
        }
        message.Type = "Messages";
        getMessageInfo(path,user,condata[i].id,message,condata[i].type);
        node.TreeNodes.push(message);
    }
}


function getGroupMember(path,id,user){
    try
    {
        var data = eval('('+ XLY.Sqlite.Find(path,"select identity from Participants where convo_id = '"+id+"'") +')');
        var info = user;
        if(data.length>0&&data!=null){
            for(var i in data){
                var fullname = eval('('+ XLY.Sqlite.Find(path,"select skypename,fullname from Contacts where skypename = '"+data[i].identity+"'") +')');
                if(fullname[0].fullname!=""&&fullname[0].fullname!=null){
                    if(fullname[0].fullname==user){
                        continue;
                    }
                }
                else
                {
                    fullname[0].fullname = fullname[0].skypename;
                }
                info+= ";"+fullname[0].fullname;
            }
        }
        return info;
    }
    catch(err)
    {
        return err;
    }
}

function getMessageInfo(path,user,id,subnode,type){
    try
    {
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from Messages where convo_id = '"+id+"'" ) +')');
        if(data!=null&& data.length>0){
            var Mlist = new Array();
            for(var i in data){
                var mobj = new Messages();
                mobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);  //数据状态
                mobj.Sender = data[i].from_dispname;   //消息发送者
                if(data[i].sending_status==2||type==2){
                    
                    mobj.Receiver = subnode.Text; //消息接收者
                }
                else
                {
                    mobj.Receiver = user; //消息接收者
                }
                //if(type==2){
                //    mobj.Receiver = subnode.Text; //消息接收者
                //}
                mobj.Body = data[i].body_xml; //消息内容
                
                mobj.Type = ""; //消息类型
                switch(data[i].type){
                    case 30: mobj.Type = "通话开始";//mobj.Body = "";
                    break;
                    case 39: mobj.Type = "通话结束";//mobj.Body = "";
                    break;
                    case 50: mobj.Type = "系统消息";//mobj.Body = "";
                    break;
                    case 61: mobj.Type = "文本";
                    break;
                    case 63: mobj.Type = "名片";//mobj.Body = "";
                    break;
                    case 201: mobj.Type = "图片";mobj.Body = "";
                    var info = data[i].body_xml;
                    if(info.length>0&&info!=null){
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body = info.substr(0,info.indexOf("<"));
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body += info.substr(0,info.indexOf("<"));
                    }
                    
                    break;
                    case 253: mobj.Type = "动态图";mobj.Body = "";
                    var info = data[i].body_xml;
                    if(info.length>0&&info!=null){
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body = info.substr(0,info.indexOf("<"));
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body += info.substr(0,info.indexOf("<"));
                    }
                    break;
                    case 254: mobj.Type = "文件";mobj.Body = "";
                    var info = data[i].body_xml;
                    if(info.length>0&&info!=null){
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body = info.substr(0,info.indexOf("<"));
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body += info.substr(0,info.indexOf("<"));
                    }
                    break;
                    case 255: mobj.Type = "视频";mobj.Body = "";
                    var info = data[i].body_xml;
                    if(info.length>0&&info!=null){
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body = info.substr(0,info.indexOf("<"));
                        while(info.indexOf("<")>= 1){
                            info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                            mobj.Body += info.substr(0,info.indexOf("<"));
                        }
                    }
                    break;
                    case 51: mobj.Type = "视频";mobj.Body = "";
                    var info = data[i].body_xml;
                    if(info.length>0&&info!=null){
                        info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        mobj.Body = info.substr(0,info.indexOf("<"));
                        //info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        //mobj.Body += info.substr(0,info.indexOf("<"));
                        //info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                        //mobj.Body + = info.substr(0,info.indexOf("<"));
                        while(info.indexOf("<")>= 1){
                            //log(info);
                            info = info.substr(info.indexOf(">")+1,info.length-info.indexOf(">"));
                            mobj.Body += info.substr(0,info.indexOf("<"));
                        }
                    }
                    break;
                    default:mobj.Type = "未知类型"+"_"+data[i].type;
                    break;
                }
                mobj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);   //发送时间
                mobj.Mark = ""; //备注
                subnode.Items.push(mobj);
                
            }
        }
        
    }
    catch(err)
    {
        return err;
    }
}


function buildCallSubNode(node,path,user){
    try
    {
        var data = eval('('+ XLY.Sqlite.Find(path,"select distinct dispname from CallMembers") +')');
        if(data.length>0 && data!= null){
            for(var i in data){
                var ucall = new TreeNode();
                ucall.Text = data[i].dispname;
                ucall.Type = "Call";
                var cdata = eval('('+ XLY.Sqlite.Find(path,"select * from CallMembers where dispname = '"+data[i].dispname+"' ") +')');
                if(cdata.length>0&&cdata!=null){
                    for(var num in cdata){
                        var cobj = new Call();
                        cobj.DataState = XLY.Convert.ToDataState(cdata[num].XLY_DataType);  //数据状态
                        //if(cdata[num].type==1){
                        //    cobj.Sender = cdata[num].dispname;   //通话拨打方
                        //    cobj.Receiver = user; //通话接听方
                        //    //cobj.Type = ""; //通话类型
                        //}
                        //else
                        //{
                        //    cobj.Sender = user;   //通话拨打方
                        //    cobj.Receiver = cdata[num].dispname; //通话接听方
                        //    //cobj.Type = ""; //通话类型
                        //}
                        cobj.Duration = cdata[num].call_duration; //通话时长
                        cobj.Time = XLY.Convert.LinuxToDateTime(cdata[num].start_timestamp);   //时间
                        cobj.CreateTime = XLY.Convert.LinuxToDateTime(cdata[num].creation_timestamp);   //创建时间
                        cobj.Mark = "正常通话"; //备注
                        switch(cdata[num].type){
                            case 1: cobj.Sender = cdata[num].dispname;   //通话拨打方
                                    cobj.Receiver = user; //通话接听方
                                    //switch(cdata[num].status){
                                    //    case : break;
                                    //}
                            break;
                            case 2: cobj.Sender = user;   //通话拨打方
                                    cobj.Receiver = cdata[num].dispname; //通话接听方
                            break;
                            default: 
                            break;
                        }
                        if(cdata[num].type==2&&cdata[num].status==7&&(cdata[num].failurereason==""||cdata[num].failurereason==null)){
                            cobj.Type = "未拨通，系统挂断";
                        }
                        if(cdata[num].type==2&&cdata[num].status==8&&cdata[num].failurereason==14){
                            cobj.Type = "未拨通，接听方挂断";
                        }
                        if(cdata[num].type==2&&cdata[num].status==13&&(cdata[num].failurereason==""||cdata[num].failurereason==null)){
                            cobj.Type = "未拨通，拨打方挂断";
                        }
                        if(cdata[num].type==1&&cdata[num].status==7&&(cdata[num].failurereason==""||cdata[num].failurereason==null)){
                            cobj.Type = "未拨通，系统挂断";
                        }
                        if(cdata[num].type==1&&cdata[num].status==7&&cdata[num].failurereason==14){
                            cobj.Type = "未拨通，拨打方挂断";
                        }
                        if(cdata[num].type==1&&cdata[num].status==8&&(cdata[num].failurereason==""||cdata[num].failurereason==null)){
                            cobj.Type = "未拨通，接听方挂断";
                        }
                        if(cdata[num].type==1&&cdata[num].status==6&&cdata[num].failurereason==14){
                            cobj.Type = "拨通，拨打方挂断";
                        }
                        if(cdata[num].type==1&&cdata[num].status==6&&(cdata[num].failurereason==""||cdata[num].failurereason==null)){
                            cobj.Type = "拨通，接听方挂断";
                        }
                        if(cdata[num].type==2&&cdata[num].status==6&&cdata[num].failurereason==14){
                            cobj.Type = "拨通，接听方挂断";
                        }
                        if(cdata[num].type==2&&cdata[num].status==6&&(cdata[num].failurereason==""||cdata[num].failurereason==null)){
                            cobj.Type = "拨通，拨打方挂断";
                        }
                        if(cdata[num].type==2&&cdata[num].status==2&&cdata[num].failurereason==3){
                            cobj.Type = "其他";
                        }
                        ucall.Items.push(cobj);
                    }
                }
                node.TreeNodes.push(ucall);
            }
        }
    }
    catch(err)
    {
        return err;
    }
}
function Call() {
    this.DataState = "Normal";  //数据状态
    this.Sender = "";   //通话拨打方
    this.Receiver = ""; //通话接听方
    this.Duration = ""; //通话时长
    this.Type = ""; //通话类型
    this.Time = null;   //时间
    this.Mark = ""; //备注
    this.MDFString = "";    //MD5
    this.CreateTime = null;
}


