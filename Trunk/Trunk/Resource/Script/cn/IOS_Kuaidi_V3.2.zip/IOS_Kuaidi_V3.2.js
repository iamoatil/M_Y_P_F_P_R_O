﻿/*[config]
<plugin name="快的打车" group="地图公交,6" devicetype="IOS" icon="\icons\kuaidi.png" pump="USB,Mirror,Wifi,Bluetooth" app="com.funcity.taxi" version="3.2"
     description="提取苹果快的打车" data="$data">
    <source>
        <value>com.funcity.taxi</value>
    </source>
    <data>
        <item name="用户名" code="UserName" type="string" width = "150"></item>
        <item name="我的坐标" code="MyLocation" type="string" width="200"></item>
        <item name="联系人" code="DriverName" type="string" width="150"></item>
        <item name="车牌号" code="CarNumber" type="string" width="100"></item>
        <item name="出发地" code="FromLoc" type="string" width="200" ></item>
        <item name="目的地" code="EndLoc" type="string" width="100"></item>
        <item name="创建时间" code="CreatedTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>  
    </data>
</plugin>
[config]*/

//定义数据结构
function Item() {
    this.UserName = "";
    this.MyLocation = "";
    this.DriverName = "";
    this.CarNumber="";
    this.FromLoc="";
    this.EndLoc = "";
    this.CreatedTime = null;
}


var result = new Array();
//源文件
//var source = $source;
//var db=source[0]+"com.funcity.taxi\\Documents\\CoreData\\data.sqlite";
//var plistfile=source[0]+"com.funcity.taxi\\Documents\\persion_680uYokV.plist";
var db = "C:/XLYSFTasks/未命名-20/source/IosData/2014-08-11-11-42-28/com.funcity.taxi/Documents/CoreData/data.sqlite";
var plistfile = "C:/XLYSFTasks/未命名-20/source/IosData/2014-08-11-11-42-28/com.funcity.taxi/Documents/persion_680uYokV.plist";

var username;

var data = eval('(' +  XLY.PList.ReadToJsonString(plistfile) + ')');
username = data[5].name+"("+data[4].mob+")";
var dblist = eval('(' + XLY.Sqlite.FindByName(db, 'ZHISTROYLIST') + ')');
for (var i in dblist) {
    var row = dblist[i];
    var obj = new Item();
    obj.DriverName = XLY.Convert.ToString(row.ZDRIVERNAME)+"("+row.ZDRIVERMOBILE+")";
    obj.MyLocation = "经度:"+XLY.Convert.ToDouble(row.ZLNG)+",纬度:"+XLY.Convert.ToDouble(row.ZLAT)+"";
    obj.CarNumber= XLY.Convert.ToString(row.ZTAXINO);
    obj.CreatedTime = XLY.Convert.LinuxToDateTime(row.ZLASTMODIFYDATE);
    obj.FromLoc= XLY.Convert.ToString(row.ZFROM);
    obj.EndLoc=XLY.Convert.ToString(row.ZTO);
    obj.UserName = username;
    result.push(obj);
}

var res = JSON.stringify(result);
res;
