﻿/*[config]
<plugin name="高德地图,10" group="地图公交,7,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\amap.png" app="com.autonavi.minimap" version="7.7.8.2073" description="高德地图" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.autonavi.minimap/databases/aMap.db</value>
<value>/data/data/com.autonavi.minimap/shared_prefs/route_favorite_busline_data.xml</value>
</source>
<data type="Info" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="头像" code="Avatar" type="string" width = "150"></item>
<item name="姓名" code="Name" type="string" width = "150"></item>
<item name="昵称" code="Nick" type="string" width = "150"></item>
<item name="淘宝昵称" code="Taobao" type="string" width = "150"></item>
</data>
<data type="Search" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="线路" code="Name" type="string" width = "150"></item>
<item name="起点经纬度" code="Start" type="string" width = "150"></item>
<item name="终点经纬度" code="End" type="string" width = "150"></item>
<item name="终点位置" code="EndA" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "150"></item>
</data>
<data type="FavRoute" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点位置" code="SAddr" type="string" width = "150"></item>
<item name="终点点位置" code="EAddr" type="string" width = "150"></item>
</data>
<data type="Location" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="线路" code="Name" type="string" width = "150"></item>
<item name="位置" code="Addr" type="string" width = "150"></item>
<item name="备注" code="TERMINALS" type="string" width = "150"></item>
</data>
</plugin>
[config]*/
function Info(){
    this.Avatar = "";
    this.Name = "";
    this.Taobao = "";
    this.Nick = "";
    this.DataState = "Normal";
}
function Search(){
    this.ID = "";
    this.Name = "";
    this.Start = "";
    this.End = "";
    this.EndA = "";
    this.DataState = "Normal";
}
function FavRoute() {
    this.STart = "";
    this.SAddr = "";
    this.EAddr = "";
    this.End = "";
    this.DataState="Normal";
}
function Location() {
    this.Name = "";
    this.ID = "";
    this.Addr = "";
    this.TERMINALS = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "高德地图";
    news.Type = "Info"; 
    news.DataState = "Normal";
    
    var news1 = new TreeNode();
    news1.Text = "账号";
    news1.Type = "Info";
    accountinfo = getInfo(db);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    
    var search = new TreeNode();
    search.Text = "火车线路搜索";
    search.Type = "Search";
    search.Items = getSearch(db);
    search.DataState = "Normal";
    news.TreeNodes.push(search);
    
     var location = new TreeNode();
     location.Text = "位置搜索";
     location.Type = "Location";
    location.Items = getLocation(db);

    location.DataState = "Normal";
    news.TreeNodes.push(location);
    
     if(XLY.File.IsValid(db1)){ 
    var favroute = new TreeNode() ;
    favroute.Text = "公交路线收藏";
    favroute.Type = "FavRoute"; 
    favroute.Items = getFavRoute(db1);
    news.TreeNodes.push(favroute);
  }
       result.push(news);
} 
function getInfo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from USER_INFO" ) +')');
    for(var i in data){
        var obj = new Info();
        obj.Avatar = data[i].AVATAR;
        obj.Name = data[i].USERNAME;
        obj.Taobao = data[i].TAOBAONAME;
        obj.Nick = data[i].NICK;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }   
    return list;
}
function getLocation(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from tipitem" ) +')');
    for(var i in data){
        var obj = new Location();
        obj.ID = data[i].POIID;
        obj.Name = data[i].NAME;
        obj.Addr = data[i].DISTRICT;
        obj.TERMINALS = data[i].TERMINALS;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }   
    return list;
}
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from RouteHistory" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.ID = data[i].ID;
        obj.Name = data[i].ROUTE_NAME;
        obj.Start = data[i].START_X +";"+data[i].START_Y;
        obj.End = data[i].END_X +","+data[i].END_Y;
        var a = data[i].TO_POI_JSON;
        if(a.length>0 && a !=null){
            var b = eval('('+ a +')'); 
         obj.EndA = b.mAddr;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].UPDATE_TIME);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }   
    return list;
}
function getFavRoute(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var obj = new FavRoute();
    var info = data.map.string;
 
 
    
    if(info.length !=null){
      for(var i in info){
        var obj = new FavRoute();
        var con = eval('('+ info[i]['#text'] +')'); 
        log(con);
        obj.STart = con.buslist[0].spoi.x+";"+con.buslist[0].spoi.y;
        obj.End = con.buslist[0].epoi.x+";"+con.buslist[0].epoi.y;
        obj.SAddr = con.start_desc;
        obj.EAddr = con.end_desc;
        list.push(obj);  
      }  
    }
else{
    var info1 = eval('('+ info['#text'] +')'); 
    log(info1.buslis);
       obj.SAddr = info1.start_desc;
       obj.EAddr = info1.end_desc;
       list.push(obj); 
}

    return list;
}
//源文件路径
var source = $source;
var db2 = source[0];
var db1 = source[1];
var charactor = "\\chalib\\Android_Amap_V7.7.8.2073\\aMap.db.charactor";
//var db2 = "D:\\temp1\\data\\data\\com.autonavi.minimap\\databases\\aMap.db";
//var db1 = "D:\\temp1\\data\\data\\com.autonavi.minimap\\shared_prefs\\route_favorite_busline_data.xml";
//var charactor = "D:\\temp\\data\\data\\com.autonavi.minimap\\databases\\aMap.db.charactor";
var db = XLY.Sqlite.DataRecovery(db2,charactor,"USER_INFO,tipitem,RouteHistory" )
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;