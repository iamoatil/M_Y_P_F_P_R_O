﻿/*[config]
<plugin name="GreenVpn,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/green.png" app="com.evergreen.greendroid" version="1.1.8" description="GreenVpn" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.evergreen.greendroid/shared_prefs/sobot_config.xml</value>
    <value>/data/data/com.evergreen.greendroid/databases/profile.db</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "150"></item>
    <item name="密码" code="PassWord" type="string" width="120"></item>
    <item name="邮箱" code="Emaill" type="string" width="150"></item>
    <item name="服务器IP" code="CiServer" type="string" width="150"></item>
    <item name="远程主机IP" code="Host" type="string" width="150"></item>
    <item name="本机端口" code="LocalPort" type="string" width="80"></item>
    <item name="远程端口" code="RomotePort" type="string" width="80"></item>
    <item name="是否已连接" code="IsActived" type="string" width="80"></item>
    <item name="地区" code="Region" type="string" width="80"></item>
    <item name="线路" code="Route" type="string" width="80"></item>
    <item name="会员有效日期至" code="Expiration" type="string" width="150"></item>
    <item name="创建时间" code="CreateTime" type="string" width="150"></item>
    <item name="账号类型" code="UserType" type="string" width = "120"></item>
    <item name="账号积分" code="UserScore" type="string" width = "120"></item>
    <item name="今日已用流量" code="TodayReadable" type="string" width = "120"></item>
    <item name="累计已用流量" code="StatReadable" type="string" width = "120"></item>
    <item name="共获赠VIP" code="UserPrize" type="string" width = "120"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PassWord = "";
    this.Emaill = "";
    this.CiServer = "";
    this.Host = "";
    this.LocalPort = "";
    this.RomotePort = "";
    this.IsActived = "否";
    this.Region = "";
    this.Route = "";
    this.Expiration = "";
    this.CreateTime = "";
    this.UserType = "";
    this.UserScore = "";
    this.TodayReadable = "";
    this.StatReadable = "";
    this.UserPrize = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath = source[0];
var profilePath1 = source[1];

//测试数据
//var userPath = "D:\\temp\\data\\data\\com.evergreen.greendroid\\shared_prefs\\sobot_config.xml";
//var profilePath1 = "D:\\temp\\data\\data\\com.evergreen.greendroid\\databases\\profile.db";
//定义特征库文件
var charactor = "\\chalib\\Android_ Green_V1.1.8\\profile.db.charactor";
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "GreenVpn";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userNameData = eval('('+ XLY.File.ReadXML(userPath) +')');
        var bb = "";
        if(userNameData!=""&&userNameData!=null){
            var aa = userNameData.map.string;
            for(var i in aa){
                if(aa[i]["@name"]=="sobot_current_sender_name"){
                    bb = aa[i]["#text"];
                }
            }
        }
        if(XLY.File.IsValid(profilePath)){
            var data = eval('('+ XLY.Sqlite.Find(profilePath,"select XLY_DataType,ci_server,createTime,expireTime,host,isActived,localPort,password,region,remotePort,route,total,useTimes,userEmail,userName,userType,userscore,total,useTimes,userprize from profile") +')');
            if(data!=""&&data!= null){
                for(var j in data){
                    var obj = new UserInfo();
                    obj.DataState = XLY.Convert.ToDataState(data[j].XLY_DataType);
                    obj.UserName = data[j].userName;
                    obj.PassWord = data[j].password;
                    obj.Emaill = data[j].userEmail;
                    obj.CiServer = data[j].ci_server;
                    obj.Host = data[j].host;
                    obj.LocalPort = data[j].localPort;
                    obj.RomotePort = data[j].remotePort;
                    if(data[j].isActived==1){
                        obj.IsActived = "是";
                    }
                    obj.Region = data[j].region;
                    obj.Route = data[j].route;
                    obj.Expiration = data[j].expireTime;
                    obj.CreateTime = data[j].createTime;
                    obj.UserType = data[j].userType;
                    obj.UserScore = data[j].userscore;
                    obj.TodayReadable = data[j].total;
                    obj.StatReadable = data[j].useTimes;
                    obj.UserPrize = data[j].userprize;
                    
                    var node = new TreeNode();
                    node.Text = obj.UserName;
                    node.Type = "UserInfo";
                    node.Items.push(obj);
                    root.TreeNodes.push(node);
                }
            }
        }
    }
}