﻿/*[config]
<plugin name="赶集网,11" group="生活旅游,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/ganji.png" app="com.ganji.android" version="7.0.0" description="赶集网" data="$data,ComplexTreeDataSource"  >
<source>
<value>data/data/com.ganji.android/databases/History.db</value>
<value>data/data/com.ganji.android/databases/webim.db</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Account" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="用户ID" code="UserId" type="string" width="100" ></item>
<item name="图片ID" code="ImId" type="string" width = "100" ></item>
<item name="昵称" code="NcickName" type="string" width = "100" ></item>
<item name="头像" code="Avatar" type="string" width = "100" ></item>
<item name="照片" code="Photos" type="string" width = "100" ></item>
<item name="性别" code="Gender" type="string" width = "100" ></item>
<item name="生日" code="Birthday" type="string" width = "100" ></item>
<item name="职位名" code="JobName" type="string" width = "100" ></item>
<item name="电话" code="Phone" type="string" width = "100" ></item>
<item name="恋爱状态" code="LoveStatus" type="string" width = "100" ></item>
<item name="描述" code="Describe" type="string" width = "100" ></item>
<item name="注册时间" code="Time" type="string" width = "200" ></item>
<item name="账号状态" code="AStatus" type="string" width = "200" ></item>
<item name="活跃等级" code="Level" type="string" width = "200" ></item>
<item name="活跃值" code="Value" type="string" width="200" ></item>
<item name="位置" code="Location" type="double" width = "100" > format = "F6"</item>  
<item name="位置更新时间" code="GPSTime" type="DateTime" width="200" ></item>
</data>
<data  type="BrowseHistory" datefilter="ime" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="类别" code="CateName" type="String" width="150" ></item>
<item name="时间" code="Time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="SearchHistory" datefilter="time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关键字" code="KeyWord" type="string" width="300"></item>
<item name="时间" code="Time" type="dateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="Contact" datefilter="time" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="用户ID" code="UserId" type="string" width="100" ></item>
<item name="图片ID" code="Send" type="string" width = "100" ></item>
<item name="昵称" code="NcickName" type="string" width = "100" ></item>
<item name="头像" code="Avatar" type="string" width = "100" ></item>
<item name="照片" code="Photos" type="string" width = "100" ></item>
<item name="性别" code="Gender" type="string" width = "100" ></item>
<item name="生日" code="Birthday" type="string" width = "100" ></item>
<item name="职位名" code="JobName" type="string" width = "100" ></item>
<item name="电话" code="Phone" type="string" width = "100" ></item>
<item name="恋爱状态" code="LoveStatus" type="string" width = "100" ></item>
<item name="描述" code="Describe" type="string" width = "100" ></item>
<item name="注册时间" code="Time" type="string" width = "200" ></item>
<item name="账号状态" code="AStatus" type="string" width = "200" ></item>
<item name="活跃等级" code="Level" type="string" width="200" ></item>
<item name="加入的群名" code="Group" type="string" width = "100" ></item>
<item name="加入的群头像" code="GroupAvatar" type="string" width = "100" ></item>
<item name="加入的群Id" code="GroupId" type="string" width = "100" ></item>
<item name="位置" code="Location" type="string" width = "100" > format = ""</item>  
<item name="位置更新时间" code="GPSTime" type="DateTime" width="200" ></item>
</data>
<data type="GroupMessage" datefilter="time" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width = "100" ></item>
<item name="接收人" code="Receiver" type="string" width = "100" ></item>
<item name="内容" code="Content" type="string" width = "100" ></item>
<item name="消息类型" code="Type" type="string" width = "100" ></item> 
<item name="发送人ID" code="SenderId" type="string" width = "100" ></item>  
<item name="时间" code="Time" type="DateTime" width="200" ></item>
</data> 
<data type="PeopleMessage" datefilter="time" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width = "100" ></item>
<item name="接收人" code="Receiver" type="string" width = "100" ></item>
<item name="内容" code="Content" type="string" width = "100" ></item>
<item name="消息类型" code="Type" type="string" width = "100" ></item> 
<item name="时间" code="Time" type="DateTime" width="200" ></item>
</data> 
<data type="Group" datefilter="time" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="群名" code="Name" type="string" width="100" ></item>
<item name="群ID" code="Id" type="string" width = "100" ></item>
<item name="头像" code="Avatar" type="string" width = "100" ></item>
<item name="照片" code="Photo" type="string" width = "100" ></item>
<item name="等级" code="Level" type="string" width = "100" ></item>
<item name="位置" code="Location" type="string" width = "100" ></item>
<item name="群位置纬度" code="Latitude"  type="double" width = "100" > format = "F6"</item>  
<item name="群位置经度" code="Longitude"  type="double" width = "100" > format = "F6"</item>  
<item name="群标签" code="Labels" type="string" width="100" ></item>
<item name="群简介" code="Introduce" type="string" width = "100" ></item>
<item name="建群时间" code="Time" type="string" width = "100" ></item>
<item name="目前群人数" code="Count" type="string" width = "100" ></item>
<item name="最大成员数" code="Max" type="string" width = "100" ></item>
<item name="更新时间" code="UTime" type="DateTime" width = "100" ></item>
<item name="群类型" code="Type" type="string" width = "100" ></item>
</data> 
<data type="GroupMembers" datefilter="time" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="100" ></item>
<item name="ID" code="Id" type="string" width = "100" ></item>
<item name="头像" code="Avatar" type="string" width = "100" ></item>
<item name="性别" code="Gender" type="string" width = "100" ></item>
<item name="生日" code="Birthday" type="string" width = "100" ></item>
<item name="加入时间" code="Time" type="string" width = "100" ></item>
<item name="更新时间" code="UTime" type="string" width = "100" ></item>
<item name="活跃等级" code="Degree" type="string" width = "200" ></item>
</data> 
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account(){
    this.UserId = "";  
    this.ImId = ""; 
    this.Avatar = "";  
    this.NcickName = "";  
    this.Photos = "";  
    this.Gender = "";  
    this.Birthday = "";  
    this.JobName = "";  
    this.Phone = "";  
    this.LoveStatus = "";  
    this.Describe = "";  
    this.Time = ""; 
    this.AStatus = "";  
    this.Level = "";
    this.Value = "";   
    this.Location = "";  
    this.GPSTime = "";   
    this.DataState = "Normal";  
}
function BrowseHistory() {
    this.CateName = "";  
    this.Time = "";  
    this.DataState = "Normal";  
}
function SearchHistory() {
    this.KeyWord = "";  
    this.Time = "";  
    this.DataState = "Normal";  
}
function Contact() {
    this.UserId = "";  
    this.Send = ""; 
    this.Avatar = "";  
    this.NcickName = "";  
    this.Photos = "";  
    this.Gender = "";  
    this.Birthday = "";  
    this.JobName = "";  
    this.Phone = "";  
    this.LoveStatus = "";  
    this.Describe = "";  
    this.Time = ""; 
    this.AStatus = ""; 
    this.Level = "";  
    this.Group = ""; 
    this.GroupAvatar = "";  
    this.GroupId = "";
    this.Location = "";  
    this.GPSTime = "";   
    this.DataState = "Normal";  
}
function Group() {
    this.Name = "";  
    this.Id = ""; 
    this.Avatar = "";    
    this.Photos = "";  
    this.Level = "";  
    this.Location = "";  
    this.Latitude = "";  
    this.Longitude = "";  
    this.Labels = "";  
    this.Introduce = "";  
    this.Time = "";  
    this.Count = "";  
    this.Max = ""; 
    this.UTime = "";  
    this.Type = "";  
    this.Members = "";  
    this.DataState = "Normal";  
}
function GroupMembers() {
    this.Name = "";  
    this.Id = ""; 
    this.Avatar = "";    
    this.Gender = "";  
    this.Birthday = "";   
    this.Time = "";  
    this.UTime = ""; 
    this.GId = "";   
    this.Degree = "";  
    this.DataState = "Normal";  
}
function PeopleMessage() { 
    this.Content = ""; 
    this.Type = "";    
    this.Sender = "";   
    this.Receiver = "";  
    this.MessageState = ""; 
    this.Time = "";   
    this.DataState = "Normal";  
}
function GroupMessage() {
    this.Content = ""; 
    this.Type = "";    
    this.Sender = "";  
    this.SenderId = "";   
    this.Receiver = "";  
    this.Time = "";   
    this.DataState = "Normal";  
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "赶集网";
    news.Type = "Account"; 
    accountinfo = getAccount(db1);
    news.Items = accountinfo;
    
    news.DataState = "Normal";
     
    for(var i in accountinfo){
        
        var account = new TreeNode() ;
        if(accountinfo[i].NcickName != null){
            account.Text = accountinfo[i].NcickName;
        }
        else
        {
           account.Text = accountinfo[i].UserId;
        }
        account.Type = "Account"; 

        var history = new TreeNode();
        history.Text = "浏览记录";
        history.Type = "BrowseHistory"; 
        history.Items = GetBrowseHistory(db);
        account.TreeNodes.push(history);
        news.TreeNodes.push(account)
        
        var shistory = new TreeNode();
        shistory.Text = "搜索记录";
        shistory.Type = "SearchHistory"; 
        shistory.Items = GetSearchHistory(db);
        account.TreeNodes.push(shistory);
        
        var contact = new TreeNode();
        contact.Text = "联系人";
        contact.Type = "Contact";
        contactinfo = GetContact(db1,accountinfo[i]);   
        contact.Items = contactinfo;
        account.TreeNodes.push(contact);
    
        for(var j in contactinfo ){
        var message = new TreeNode();
        message.Text = contactinfo[j].NcickName;
        message.Type = "PeopleMessage";
        message.Items = GetPeopleMessage(db1,contactinfo[j],accountinfo[i]);
        message.DataState = "Normal";
        contact.TreeNodes.push(message);
        }
      
        var group = new TreeNode() ;
        group.Text = "加入的群";
        group.Type = "Group";
        groupinfo = GetGroup(db1,accountinfo[i]);
        group.Items = groupinfo;
        account.TreeNodes.push(group);
        
        for(var i in groupinfo){
            var person = new TreeNode();
            person.Text = groupinfo[i].Name;
            person.Type = "GroupMessage";
            person.Items = GetGroupMessage(db1,groupinfo[i]);
            person.DataState = "Normal";
            group.TreeNodes.push(person);
            
            var member = new TreeNode();
            member.Text = "群成员";
            member.Type = "GroupMembers"; 
            member.Items = GetGroupMembers(db1,groupinfo[i]);
            person.TreeNodes.push(member);
        }


    }   
   result.push(news);
}

function getAccount(path){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from user ") + ')'); 
    for(var index in data){
        var obj=new Account();
        obj.UserId = data[index].user_id;
        obj.ImId = data[index].im_id;
        obj.NcickName = data[index].nick_name;  
        obj.Avatar = data[index].avatar; 
        obj.Photos = data[index].photos;
        obj.Gender = data[index].gender;
        obj.Birthday = data[index].birthday;  
        obj.JobName = data[index].job_name;
        obj.Phone = data[index].phone;
        var a = data[index].love_status;
        switch(a){
          case 1:
             obj.LoveStatus = "单身";
             break;
          case 2:
             obj.LoveStatus = "求交往";
             break;
          case 3:
             obj.LoveStatus = "暗恋中";
             break;
          case 4:
             obj.LoveStatus = "暧昧中";
             break;
          case 5:
             obj.LoveStatus = "恋爱中";
             break;
          case 6:
             obj.LoveStatus = "已婚";
             break;
          case 7:
             obj.LoveStatus = "分居";
             break;
          case 8:
             obj.LoveStatus = "离异";
             break;
          case 9:
             obj.LoveStatus = "丧偶";
             break;
        }    
        obj.Describe = data[index].describe;
        var a = data[index].account_status;
        switch(a){
          case 1:
           obj.AStatus = "已登录";
           break;
         case 0:
           obj.AStatus = "未登陆";
           break;
        }
        obj.Level = data[index].active_level;
        obj.Value = data[index].active_value;    
        obj.Location = data[index].location;
        obj.GPSTime =XLY.Convert.LinuxToDateTime(data[index].gps_update_time);
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].register_Time);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
        list.push(obj);
    }
    return list;
}

function GetBrowseHistory(path){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from BrowsedHistory ") + ')');
    for(var index in data){
        var obj=new BrowseHistory();
        obj.CateName = data[index].subCategoryName;  
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].time) 
        list.push(obj);
    }
    return list;
}

function GetSearchHistory(path){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from SearchHistory order by time desc") + ')');
    for(var index in data){
        var obj=new SearchHistory();
        obj.KeyWord = data[index].keyword;  
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].time) 
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function GetContact(path,accountinfo){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from contact where ower_id = '"+accountinfo.UserId+"'") + ')');
    for(var index in data){
        var obj=new Contact();
        obj.UserId = data[index].user_id;
        obj.Send = data[index].im_id;
        obj.NcickName = data[index].nick_name;
        obj.Avatar = data[index].avatar;
        obj.Photos = data[index].photos;
        obj.Gender = data[index].gender;
        obj.Birthday = data[index].birthday;
        obj.JobName = data[index].job_name;
        obj.Phone = data[index].phone;
          var a = data[index].love_status;
         switch(a){
           case 1:
             obj.LoveStatus = "单身";
             break;
           case 2:
             obj.LoveStatus = "求交往";
             break;
           case 3:
             obj.LoveStatus = "暗恋中";
             break;
           case 4:
             obj.LoveStatus = "暧昧中";
             break;
           case 5:
             obj.LoveStatus = "恋爱中";
             break;
           case 6:
             obj.LoveStatus = "已婚";
             break;
           case 7:
             obj.LoveStatus = "分居";
             break;
           case 8:
             obj.LoveStatus = "离异";
             break;
           case 9:
             obj.LoveStatus = "丧偶";
             break;
         }  
        obj.Describe = data[index].describe;
        var a = data[index].account_status;
         switch(a){
          case 1:
           obj.AStatus = "已登录";
           break;
          case 0:
           obj.AStatus = "未登陆";
           break;
        }
        obj.Level = data[index].active_level;
        var a = eval('('+ data[index].groups_json +')');  
        var b = abc(a);       
        obj.Group = b[0];
        obj.GroupAvatar = b[1];
        obj.GroupId = b[2];
        obj.Location = data[index].location;     
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].register_Time);
        obj.GPSTime = XLY.Convert.LinuxToDateTime(data[index].gps_update_time); 
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function abc(a){
   var list = new Array();
   var group = "";
   var avatar = "";
   var groupid = "";
   
   for(var i in a){
       group = group+a[i].name + "、";
       avatar = avatar+a[i].avatar+ "、";
       groupid = groupid+a[i].groupId+ "、";
       list.push(group);
       list.push(avatar);
       list.push(groupid);
   }
   return list;
}
function GetGroup(path,accountinfo){
    //log(accountinfo.);
    var list = new Array();
    if(accountinfo!= null){
        //log(accountinfo);
        var data = eval('(' + XLY.Sqlite.Find(path, "select * from pgroup where ower_id = '"+accountinfo.UserId+"'") + ')');;
        for(var index in data){
            var obj=new Group();
            obj.Name = data[index].name;
            obj.Id = data[index].group_id;
            obj.Avatar = data[index].avatar;  
            obj.Photo = data[index].photos; 
            obj.Level = data[index].level;    
            obj.Location = data[index].location;
            obj.Latitude = data[index].latitude;  
            obj.Longitude = data[index].longitude;      
            obj.Labels = data[index].labels;
            obj.Introduce = data[index].introduce;
            obj.Count = data[index].phone;
            obj.Max = data[index].location;
            obj.Count = data[index].current_count;
            obj.Max = data[index].max_count;
            obj.Type = data[index].type_name;      
            obj.Time = XLY.Convert.LinuxToDateTime(data[index].create_time);
            obj.UTime = XLY.Convert.LinuxToDateTime(data[index].update_time);
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

function GetGroupMembers(path,groupinfo){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from pgroup_member where group_id = '"+ groupinfo.Id+"' ") + ')');
    for(var index in data){
        var obj=new GroupMembers();
        obj.Name = data[index].nick_name;
        obj.Id = data[index].user_id;
        obj.Avatar = data[index].avatar;  
        obj.Gender = data[index].gender; 
        obj.Birthday = data[index].birthday;    
        obj.Degree = data[index].active_degree; 
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].join_time);
        obj.UTime = XLY.Convert.LinuxToDateTime(data[index].update_time); 
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 
function GetPeopleMessage(path,contactinfo,accountinfo){         
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from p2p_message  where pair_user_id = '"+ contactinfo.UserId+"' ") + ')');
    for(var index in data){
        var obj=new PeopleMessage();
        obj.UserId = data[index].pair_user_id;
        var a = eval('('+ data[index].msg_content +')');
        obj.Content = a.contents.toString();
        obj.Type = data[index].message_type;
        if(data[index].msg_is_self_send == 1){
            obj.Sender = accountinfo.NcickName;
            obj.Receiver = contactinfo.NcickName; 
        }
        else{ 
            obj.Sender = contactinfo.NcickName; 
            obj.Receiver = accountinfo.NcickName;
        }  
        obj.MessageState = data[index].msg_state;    
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].msg_time);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function GetGroupMessage(path,groupinfo){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from group_message  where pair_user_id = '"+ groupinfo.Id+"' ") + ')');
    for(var index in data){
        var obj = new GroupMessage();
        obj.Content = data[index].msg_content;
        obj.Type = data[index].message_type;  
        obj.Sender = data[index].msg_owner_name; 
        obj.SenderId = data[index].msg_owner_id;    
        obj.Receiver = groupinfo.Name;  
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].msg_time);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];

var charactor1 = "\\chalib\\Android_GanJiWang_V7.0.0\\History.db.charactor";
var charactor2 = "\\chalib\\Android_GanJiWang_V7.0.0\\webim.db.charactor";

var db = XLY.Sqlite.DataRecovery(db,charactor1,"BrowsedHistory,SearchHistory");
var db1 = XLY.Sqlite.DataRecovery(db1,charactor2,"contact,group_message,p2p_message,pgroup,pgroup_member,user");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
