﻿//铁路12306
/*[config]
<plugin name="铁路12306,6" group="生活旅游,23" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\MobileTicket.png" app="AppDomain-cn.12306.rails12306" version="2.3.0" description="铁路12306" data = "$data,ComplexTreeDataSource" >
  <source> 
      <value>/5847256a65fe184761e781be6bf0cc96738e6af6/AppDomain-cn.12306.rails12306/Library/Preferences/cn.12306.rails12306.plist</value>
      <value>/5847256a65fe184761e781be6bf0cc96738e6af6/AppDomain-cn.12306.rails12306/Library/WebKit/LocalStorage/file__0.localstorage</value>
 </source>

 <data type="Account" contract = "DataState">
     <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
     <item name="用户名" code="anPush_UserAccount" type="string" width="150" ></item>
     <item name="账户" code="username" width="200" type="string"></item>
     <item name="购买保险" code="isInsurance" type="string"></item>
     <item name="手机核验" code="userPhoneVerifyCheckIs_mo" type="string" width = "100" ></item>
     <item name="密码本地保存" code="isKeepUserPW" type="string" width = "100" ></item>
     <item name="密码登录时间" code="pwdTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
 </data>
   <data type="RecentSearches" contract = "DataState">
      <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
      <item name="最近常用路线" code="recentStationLine" type="string" width="500" ></item>
      <item name="最近常用站点" code="recentStation" type="string" width="160"></item>
      <item name="出发时间" code="set_train_date_type" type="string" width="120"></item>
      <item name="车站站点版本" code="station_version" type="string" width = "150"></item>
  </data>
 </plugin>
[config]*/

//********************************************* 处理APP数据/过程*********************************************
//源文件
var source = $source;
var db1 = source[0];
var db2 = source[1];


//var db1 = "C:\\XLYSFTasks\\2016-03-23-14-57-03\\source\\IosData\\2016-03-23-14-57-35\\5847256a65fe184761e781be6bf0cc96738e6af6\\AppDomain-cn.12306.rails12306\\Library\\Preferences\\cn.12306.rails12306.plist";
//var db2 = "C:\\XLYSFTasks\\2016-03-23-14-57-03\\source\\IosData\\2016-03-23-14-57-35\\5847256a65fe184761e781be6bf0cc96738e6af6\\AppDomain-cn.12306.rails12306\\Library\\WebKit\\LocalStorage\\file__0.localstorage";

var result = new Array();
result.push(bindTree());
var res = JSON.stringify(result);

res;


//********************************************* 数据结构和方法*********************************************

// js content


//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}


//账号信息
function Account() {
    this.anPush_UserAccount = "";
    this.username = "";
    this.isInsurance = "";
    this.userPhoneVerifyCheckIs_mo = "";
    this.isKeepUserPW = "";
    this.pwdTime = null;
    this.DataState = "Normal";
}

//最近搜素
function RecentSearches(){
    this.recentStationLine = "";
    this.recentStation = "";
    this.set_train_date_type = "";
    this.station_version = "";
  
    this.DataState = "Normal";
}

//创建树结构
function createTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

//创建根节点
function bindTree(){
    var rootTree = createTreeNode("铁路12306","");
    buildChildTree(rootTree);
    return rootTree;
}


//创建根节点的子节点
function buildChildTree(root){
    //登录帐号
    var historyAccount = createTreeNode("登录帐号信息","Account");
    historyAccount.Items.push(getAccountInfo());
    root.TreeNodes.push(historyAccount);
  
    
    //历史搜索
    var researches = createTreeNode("历史搜索车站","RecentSearches");
    researches.Items.push(getResearchesInfo());
    root.TreeNodes.push(researches);
 
}


//获取帐号信息
function getAccountInfo(){
     var obj = new Account();
     var data1 = eval('('+ XLY.PList.ReadToJsonString(db1) +')');
     obj.anPush_UserAccount = getTargetInfoInPlist(data1,"anPush_UserAccount");
    
     
     var data2 = eval('(' + XLY.Sqlite.Find(db2,"select key,cast(value as text) as value from ItemTable") + ')');
     for (var index in data2) 
    {
        switch(data2[index].key)
       {
           case "username":  obj.username = data2[index].value;;break;
           case "isInsurance":  obj.isInsurance = (data2[index].value == "Y")?"有":"无";break;
           case "userPhoneVerifyCheckIs_mo":obj.userPhoneVerifyCheckIs_mo = (data2[index].value == "Y")?"已通过":"未通过"; break;
           case "isKeepUserPW": obj.isKeepUserPW = (data2[index].value == "true")?"已保存":"未保存";break;
           case "pwdTime": obj.pwdTime = XLY.Convert.LinuxToDateTime(data2[index].value);break;
       }
    }
    return obj;
}

//获取站点历史搜索
function getResearchesInfo(){
    var obj = new RecentSearches();
    var Stations=eval('(' + XLY.Sqlite.Find(db2,"select  key,cast(value as text) as value  from ItemTable where key='stations'") + ')');
     
    
    var data = eval('(' + XLY.Sqlite.Find(db2,"select  key,cast(value as text) as value  from ItemTable") + ')');
    for (var index in data) 
    {
       switch(data[index].key)
       {
           case "recentStationLine":  
           obj.recentStationLine = GetChineseStationLines(Stations,data[index].value);
           break;
           case "recentStation":
           obj.recentStation = GetChineseStations(Stations,data[index].value);
          break;
           case "set_train_date_type":obj.set_train_date_type = data[index].value; break;
           case "station_version": obj.station_version = data[index].value;break;
       }
    }
   //log(obj);
    return obj;
}


//获取目标节点的value/text
function getTargetInfoInPlist(data,target){
    for(var index in data)
    {
        for(var key in data[index])
        {
            if(new RegExp(target).test(key))
            {
                return data[index][key];
            }
        }
    }
   return null;
}


//获取车站站点线
function GetChineseStationLines(Stations,lineStationStr){
  
    var ChinneseLine = new Array();
    var tempStations = strToJson(lineStationStr);
    for(var i = 0; i<tempStations.length;i++)
    {
        var lines = tempStations[i].split('-');
        ChinneseLine[i] = GetStationName(Stations,lines[0])+"-"+GetStationName(Stations,lines[1])+" ";
    }
    return ChinneseLine.toString();
}

//获取最近车站站点
function GetChineseStations(Stations,StationsStr){
  
    var ChinneseLine = new Array();
    var tempStations = StationsStr.substr(1,StationsStr.length-2).split(',');
    for(var i = 0; i<tempStations.length;i++)
    {
        ChinneseLine[i] = GetStationName(Stations,tempStations[i].substr(1,tempStations[i].length-2));
    }
    
    return ChinneseLine.toString();
}

//获取车站中文名
function GetStationName(Stations,Station){
    var json = strToJson(Stations[0].value);
    for(var index in json )
    {  
        if(json[index].id ==Station)
        {
            //log( json[index].value);
            return json[index].value;
        }
    }
    
    return Station;
}


//字符串转换成JSON
function strToJson(str){ 
var json = eval('(' + str + ')'); 
return json; 
} 

