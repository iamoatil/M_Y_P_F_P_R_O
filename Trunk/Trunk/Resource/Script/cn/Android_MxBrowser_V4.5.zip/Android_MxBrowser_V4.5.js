﻿/*[config]
<plugin name="遨游浏览器" group="Web痕迹,8" devicetype="android" icon="\icons\mxbrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.mx.browser" version="4.5" description="遨游浏览器" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.mx.browser/databases/mxbrowser_default.db</value>
    <value>/data/data/com.mx.browser/databases/downloads.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="存储路径" code="Path" type="string" width = "150"></item>
    <item name="文件大小" code="Size" type="string" width = "150"></item>
    <item name="下载时间" code="Time" type="string" width = "150"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    <item name="访问次数" code="Num" type="string" width = "200"></item>
    </data>
    <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Download() {
    this.DataState = "Normal";
    this.Content = "";
    this.Url = "";
    this.Path = "";
    this.Size = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
    this.Num = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}

//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}

function bindTree() {
    newTreeNode("下载信息", "Download", getDownload(db0));
    newTreeNode("浏览记录", "History", getHistory(db));
    newTreeNode("书签", "Bookmark", getBookmark(db));
}
function getNews() {
    var list = new Array();
    data = ["下载信息", "浏览记录", "书签"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from downloads") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Content = data[i].hint;
        obj.Url = data[i].uri;
        obj.Path = data[i].xly_data;
        obj.Size = data[i].total_bytes / 1024 / 1024 + "MB";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].lastmod);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Num = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].last_visit);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmark") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
var db0 = source[1];
//var db = "D:\\temp\\data\\data\\com.mx.browser\\databases\\mxbrowser_default.db";
//var db0 = "D:\\temp\\data\\data\\com.mx.browser\\databases\\downloads.db";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
