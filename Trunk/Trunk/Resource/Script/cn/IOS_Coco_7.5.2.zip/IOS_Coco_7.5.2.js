﻿/*[config]
<plugin name="Coco" group="社交聊天,19" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/coco.png" app="com.instanza.CoCo" version="7.5.2" description="Coco" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.instanza.CoCo</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="账号" code="UserCode" type="string" width="200" format=""></item>
    <item name="昵称" code="UserName" type="string" width="200" format=""></item>
    <item name="头像(大)" code="UserHeadB" type="string" width="200" format = ""></item>
    <item name="头像(小)" code="UserHeadL" type="string" width="200" format = ""></item>
    <item name="性别" code="UserGender" type="string" width="200" format=""></item>
    <item name="生日" code="UserBirthday" type="string" width="200" format = ""></item>
    <item name="个性签名" code="UserSign" type="string" width="200" format = ""></item>
    <item name="地区ID" code="ZoneId" type="string" width="200" format = ""></item>
</data>
<data type="GroupInfo"  contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="群号码" code="GroupNumber" type="string" width="200" format = "" ></item>
    <item name="群名称" code="GroupName" type="string" width="200" format = "" ></item>
    <item name="群头像" code="GroupHead" type="string" width="200" format = "" ></item>
    <item name="创建者账号" code="GroupCreatNumber" type="string" width="200" format = "" ></item>
    <item name="创建者昵称" code="GroupCreatName" type="string" width="200" format = "" ></item>
    
</data>
<data type="GroupMember" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="群员账号" code="GroupMemberId" type="string" width="200" format = "" ></item>
    <item name="群员昵称" code="GroupMemberNickName" type="string" width="200" format = "" ></item>
</data>    

<data type="AddressBook" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="联系人姓名" code="Name" type="string" width="200" format = "" ></item>
    <item name="联系人电话" code="PhoneNumber" type="string" width="200" format = "" ></item>
</data>
<data type="ChatMessage" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="消息类型" code="MType" type="string" width="200" format = "" ></item>
    <item name="发送者" code="Sender" type="string" width="200" format = "" ></item>
    <item name="接收者" code="Receiver" type="string" width="200" format = "" ></item>
    <item name="消息内容" code="Contents" type="string" width="200" format = "" ></item>
    <item name="消息发送时间" code="SendTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="Topic" contract = "DataState" detailfield = "Pic">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="朋友圈消息Id" code="SesId" type="string" width="200" format = "" ></item>
    <item name="文字描述" code="Desc" type="string" width="200" format = "" ></item>
    <item name="配图" code="Pic" type="string" width="200" format = "" ></item>
    <item name="点赞" code="liker" type="string" width="200" format = "" ></item>
    <item name="评论" code="discuss" type="string" width="200" format = "" ></item>
    <item name="时间" code="SendTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    <item name="发送者Id" code="Sender" type="string" width="200" format = "" ></item>
    <item name="发送者昵称" code="NickName" type="string" width="200" format = "" ></item>
    <item name="经度" code="Lngt" type="string" width="200" format = "" ></item>
    <item name="纬度" code="Lat" type="string" width="200" format = "" ></item>
</data>
</plugin>
[config]*/
//定义并初始化News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义并初始化UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserCode = "";
    this.UserName = "";
    this.UserHeadB = "";
    this.UserHeadL = "";
    this.UserGender = "";
    this.UserBirthday = "";
    this.UserSign = "";
    this.ZoneId = "";
}
//定义并初始化GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupNumber = "";
    this.GroupName = "";
    this.GroupHead = "";
    this.GroupCreatNumber = "";
    this.GroupCreatName = "";
}
//定义并初始化GroupMember数据结构
function GroupMember(){
    this.DataState = "Normal";
    this.GroupMemberId = "";
    this.GroupMemberNickName = "";
}
//定义并初始化AddressBook数据结构
function AddressBook(){
    this.DataState = "Normal";
    this.Name = "";
    this.PhoneNumber = "";
}
//定义并初始化ChatMessage数据结构
function ChatMessage(){
    this.DataState = "Normal";
    this.MType = "";
    this.Sender = "";
    this.Receiver = "";
    this.Contents = "";
    this.SendTime = "";
}
//定义并初始化topic数据结构
function Topic(){
    this.DataState = "Normal";
    this.SesId = "";
    this.Desc = "";
    this.Pic = "";
    this.liker = "";
    this.discuss = "";
    this.SendTime = "";
    this.Sender = "";
    this.NickName = "";
    this.Lngt = "";
    this.Lat = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//配置文件路径全局共用

//*************************************程序入口****************************************
//设备路径;
var source = $source;
var upath = source[0] + "\\com.instanza.CoCo\\Documents";
var IdPath = source[0] + "\\com.instanza.CoCo\\Library\\Preferences\\com.instanza.CoCo.plist";
var charactor = "\\chalib\\IOSCoCo_V7.5.2\\CoCo.db.charactor";
//


//测试数据
//var upath = "E:\\xlyspf\\com.instanza.CoCo\\Documents";
//var IdPath = "E:\\xlyspf\\com.instanza.CoCo\\Library\\Preferences\\com.instanza.CoCo.plist";
//var charactor = "E:\\xlyspf\\com.instanza.CoCo\\Documents\\60692572\\CoCo.db.charactor";
//主函数
var result = new Array();
BuildNode();
var res = JSON.stringify(result);
res;
//*************************************程序结束****************************************

//++++++++++++++++++++++++++++++++++自定义函数部分+++++++++++++++++++++++++++++++++++++
//自定义数据库读取函数  
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}

//根节点函数
function BuildNode(){
    var UserIdGet = new Array();//用于存储用户Id
    var UserPath = new Array();//用户存储用户数据所在库路径
    IdGet(UserIdGet);//得到用户的id
    PathGet(UserIdGet,UserPath);//得到用户数据库所在路径
 //**********************************根节点建立**************************************  
    var RootNode = new TreeNode();
    RootNode.Text = "Coco";
    RootNode.Type = "News";
    RootNode.Items = CreatRootNode(UserIdGet,RootNode,UserPath);
    result.push(RootNode);
}

//账号提取
function IdGet(UserIdGet){
    var temp1 = eval('('+ XLY.PList.ReadToJsonString(IdPath) +')');
    for(var i in temp1){
        //直接使用i的值无法得到key值，所以需要用下面的循环
        for(var key in temp1[i]){
           if(key.split("_")[0] == "ContactDeviceDataLoaded"){
            UserIdGet.push(key.split("_")[1]);
           }
        }
    }
}

//用户数据库路径提取
function PathGet(UserIdGet,UserPath){
    for(var i in UserIdGet){
        var Path1 = upath+"\\"+UserIdGet[i]+"\\" + "CoCo.db";
        var Path = XLY.Sqlite.DataRecovery(Path1,charactor,"ZCHATMESSAGEENTITY,ZCONTACTENTITY,ZFRIENDENTITY,ZGROUPENTITY,ZGROUPMESSAGEENTITY,ZSESSIONENTITY,ZSNSCOMMENTENTITY,ZSNSTOPICENTITY,ZUSERSIMPLEPROFILEENTITY");
        UserPath.push(Path);
    }
}

//获得根节点信息
function CreatRootNode(UserId,RootNode,UserPath){
    var temp1 = new Array();
    if(UserId.length == 0 || UserId == null){
       var temp2 = new News();
       temp2.List = "未找到用户";
       temp1.push(temp2);
      return temp1; 
    }
    for(var i in UserId){
        var ContentString = ["用户信息","好友信息","手机通讯录","群组信息","聊天信息","朋友圈"];
        var temp2 = new News();
        temp2.List = UserId[i]+"_coco";
        temp1.push(temp2);
        var UserNode = new TreeNode();
        var UserNodeData = GetLoUserInfo(UserId[i]);
        var UserNode = new TreeNode(); 
        if(UserNodeData.length != 0){
            UserNode.Text = UserNodeData[0].uid + "_" + UserNodeData[0].name;
            UserNode.Items = GetUserNews(UserId[i],UserPath[i],ContentString,UserNode);    
        }
        else
        {
            UserNode.Text = "未找到用户信息";   
        }
        UserNode.Type = "News";
        RootNode.TreeNodes.push(UserNode);   
}
    return temp1;
}

function GetUserNews(UserId,UserPath,CotentStr,UserNode){
    var temp1 = new Array();
    for(var i in CotentStr){
      var temp2 = new News();
      temp2.List = CotentStr[i];
      temp1.push(temp2);
    }
  
//获取用户个人信息
    var userinfonode = new TreeNode();
    userinfonode.Text = CotentStr[0];
    userinfonode.Type = "UserInfo";
    userinfonode.Items = GetLoUserInfo2(UserId);
    UserNode.TreeNodes.push(userinfonode);

//获取好友信息
    var FriendStr = ExecSql(UserPath,"select * from ZFRIENDENTITY");
    var friendinfonode = new TreeNode();
    var FriendId = new Array();
    friendinfonode.Text = CotentStr[1];
    friendinfonode.Type = "UserInfo";
    for(var i in FriendStr){
        if(FriendStr[i].ZFRIENDUID.length != 0 && FriendStr[i].ZFRIENDUID != null){
            FriendId.push(FriendStr[i].ZFRIENDUID);
        }
    }
    friendinfonode.Items = GetFrienInfo(FriendId,UserPath);//共用函数GetUserInfo
    UserNode.TreeNodes.push(friendinfonode);
  
//获取通讯录联系人
    var addressbooknode = new TreeNode();
    addressbooknode.Text = CotentStr[2];
    addressbooknode.Type = "AddressBook";
    addressbooknode.Items = GetAddressBook(UserPath);
    UserNode.TreeNodes.push(addressbooknode);
    
//群组信息
    var groupinfonode = new TreeNode();
    groupinfonode.Text = CotentStr[3];
    groupinfonode.Type = "News";
    groupinfonode.Items = GetGroupInfo(UserPath,groupinfonode,UserId); 
    UserNode.TreeNodes.push(groupinfonode);
    
//聊天信息
    var chatmessagenode = new TreeNode();
    chatmessagenode.Text = CotentStr[4];
    chatmessagenode.Type = "News";
    chatmessagenode.Items = GetChatList(UserPath,chatmessagenode,UserId); 
    UserNode.TreeNodes.push(chatmessagenode);
    
//朋友圈信息
    var topicnode = new TreeNode();
    topicnode.Text = CotentStr[5];    
    topicnode.Type = "Topic";
    topicnode.Items = GetTopic(UserPath,UserId); 
    UserNode.TreeNodes.push(topicnode);
    return temp1;
}

//获取登陆用户信息
function GetLoUserInfo(UserId){
    var temp1 = eval('('+ XLY.PList.ReadToJsonString(IdPath) +')');
    var temp2 = new Array();
    var breakvalue = 0;
    for(var i in temp1){
        //直接使用i的值无法得到key值，所以需要用下面的循环
        for(var key in temp1[i]){
            if(key == "kUserDefaultKeyCurrUserJson_" + UserId){
                var temp3 = XLY.Blob.ToBytes(temp1[i][key],"base64");
                temp3 = eval('('+ XLY.Blob.ToString(temp3) +')');
                temp2.push(temp3);
                breakvalue = 1;   
            }
        }
        if( breakvalue == 1){
            break;
        }
    }
    return temp2;
}

function GetLoUserInfo2(UserId){
    var temp0 = new Array();
    var temp1 = GetLoUserInfo(UserId);
    var temp2 = new UserInfo();
    if(temp1.length != 0 && temp1 != null){
        temp2.UserCode = temp1[0].uid;
        temp2.UserName = temp1[0].name;
        temp2.UserHeadB = temp1[0].avatarOriginal;
        temp2.UserHeadL = temp1[0].avatarThum;
        switch(temp1[0].gender){
            case 0:temp2.UserGender = "未描述";
            break;
            case 1:temp2.UserGender = "男";
            break;
            case 2: temp2.UserGender = "女";
            break;
        }
        temp2.UserBirthday = temp1[0].birthYear.toString() + "_" + temp1[0].birthMonth.toString() + "_" + temp1[0].birthDay.toString();
        temp2.UserSign = temp1[0].status;
        temp2.ZoneId = temp1[0].countryCode;  
        temp0.push(temp2);  
    }
    return temp0;
}

//用户信息获取函数
function GetFrienInfo(UserId,UserPath){
    var temp0 = new Array();
    for(var i in UserId ){
    var temp1 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = "+UserId[i]);
    var temp2 = new UserInfo();
    if(temp1.length != 0 && temp1 != null){
    temp2.UserCode = temp1[0].ZUSERID.toString();
    temp2.UserName = temp1[0].ZNICKNAME;
    temp2.UserHeadB = temp1[0].ZIMAGEURL;
    temp2.UserHeadL = temp1[0].ZPREVIMGURL;
    switch(temp1[0].ZGENDER){
        case 0:temp2.UserGender = "未描述";
        break;
        case 1:temp2.UserGender = "男";
        break;
        case 2: temp2.UserGender = "女";
        break;
    }
    temp2.UserBirthday = "没有此项信息";
    temp2.UserSign = temp1[0].ZSIGNATURE;
    temp2.ZoneId = temp1[0].ZCOUNTRY;
    temp2.DataState = XLY.Convert.ToDataState(temp1[0].XLY_DataType);  
    temp0.push(temp2);  
    }
}
    return temp0;
}

//通讯录获取函数
function GetAddressBook(UserPath){
    var temp0 = new Array();
    var temp1 = ExecSql(UserPath,"select * from ZCONTACTENTITY");
    if(temp1.length != 0 && temp1 != null ){
        for(var i in temp1){
            var temp2 = new AddressBook();
            if(temp1[i].ZFIRSTNAME != null && temp1[i].ZFIRSTNAME.length != 0){
                temp2.Name =temp1[i].ZFIRSTNAME + temp1[i].ZLASTNAME;
            }
            else{
                temp2.Name =temp1[i].ZLASTNAME;
            }
            
            var temp3 = XLY.Blob.ToBytes(temp1[i].ZBLOBDATA,"base64");
            var tempx = temp3.length -1;
            if(temp3[tempx] == 125){
                temp3 = eval('('+ XLY.Blob.ToString(temp3) +')');
                for(var j in temp3.phoneArray){
                temp2.PhoneNumber = temp2.PhoneNumber +"[" + temp3.phoneArray[j] + "]";
                }
            }
            temp2.DataState = XLY.Convert.ToDataState(temp1[i].XLY_DataType);
            temp0.push(temp2);
        }
    }
    return temp0;
}

//群组信息获取函数1  
function GetGroupInfo(UserPath,groupinfonode,UserId){
    var temp1 = new Array();
    var temp2 = ExecSql(UserPath,"select ZGROUPID from ZGROUPENTITY");
    if(temp2 != null && temp2.length != 0){
        for(var i in temp2){
            var temp3 = new News();
            temp3.List = temp2[i].ZGROUPID;
            temp1.push(temp3);
            var groupnode = new TreeNode();
            groupnode.Text = temp2[i].ZGROUPID;
            groupnode.Type = "News";
            groupnode.Items = GetGroupInfo2(UserPath,groupnode,temp2[i].ZGROUPID,UserId);
            groupinfonode.TreeNodes.push(groupnode);
        }
    }
 return temp1;   
}

//群组信息获取函数2
function GetGroupInfo2(UserPath,groupnode,id,UserId){
    var temp1 = new Array();
    var temp2 = ["群信息","群成员"];
    var temp3 = new News();
    for(var i in temp2){
        temp3.List = temp2[i];
        temp1.push(temp3);
    }
    var groupstrnode = new TreeNode();
    groupstrnode.Text = temp2[0];
    groupstrnode.Type = "GroupInfo";
    groupstrnode.Items = GetGroupstr(UserPath,id,UserId);
    groupnode.TreeNodes.push(groupstrnode);
    
    var groupmembernode = new TreeNode();
    groupmembernode.Text = temp2[1];
    groupmembernode.Type = "GroupMember";
    groupmembernode.Items = GetGroupmember(UserPath,id,UserId);
    groupnode.TreeNodes.push(groupmembernode);
  
    return temp1;  
}

//群信息获取函数
function GetGroupstr(UserPath,id,UserId){
    var temp1 = new Array();
    var temp2 = new GroupInfo;
    var temp3 = ExecSql(UserPath,"select * from ZGROUPENTITY where ZGROUPID = " + id);
    temp2.DataState = XLY.Convert.ToDataState(temp3[0].XLY_DataType);
    temp2.GroupNumber = temp3[0].ZGROUPID;
    temp2.GroupName = temp3[0].ZGROUPNAME;
    temp2.GroupHead = temp3[0].ZGROUPAVATAR;
    temp2.GroupCreatNumber = temp3[0].ZCREATORID;
    //获取创建者昵称
    if(temp3[0].ZCREATORID == UserId){
        var temptemp = GetLoUserInfo(UserId);
        temp2.GroupCreatName = temptemp[0].name;
        
    }
    else
    {   
        var temptemp1 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = " + temp3[0].ZCREATORID);
        if(temptemp1 != null && temptemp1.length != 0){
            temp2.GroupCreatName = temptemp1[0].ZNICKNAME;
        }
    }
    temp1.push(temp2);
    return temp1;
}

//群组成员获取函数
function GetGroupmember(UserPath,id,UserId){
    var temp1 = new Array();
    var temp3 = ExecSql(UserPath,"select * from ZGROUPENTITY where ZGROUPID = " + id);
    if(temp3[0].ZMEMBERS !=null && temp3[0].ZMEMBERS.length != 0){
        var temp4 = eval('('+ XLY.PList.ConvertBufferToJson(temp3[0].ZMEMBERS) +')');
        var temp5 = temp4[1].$objects[0].NSMutableArray;
        //因为无法获取"-1"标签所以使用如下方法
        for(var i in temp5){
            var temp2 = new GroupMember;
            temp2.DataState = XLY.Convert.ToDataState(temp3[0].XLY_DataType);
            for(var j in temp5[i]){
                temp2.GroupMemberId = temp5[i][j];
                if(temp5[i][j] == UserId){
                    var temptemp = GetLoUserInfo(UserId);
                    temp2.GroupMemberNickName = temptemp[0].name;
                }
                else
                {   
                    var temptemp1 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = " + temp2.GroupMemberId);
                    if(temptemp1 != null && temptemp1.length != 0){
                    temp2.GroupMemberNickName = temptemp1[0].ZNICKNAME;
                    }
                }
                
            }
            temp1.push(temp2);
        }
    }
    return temp1;
} 

//聊天信息获取函数1
function GetChatList(UserPath,chatmessagenode,UserId){
    var chatstr = ["好友聊天记录","群组聊天记录"];
    var temp1 = new Array();
    for(var i in chatstr){
        var temp2 = new News();
        temp2.List = chatstr[i];
        temp1.push(temp2);

        var chatnode = new TreeNode();
        chatnode.Text = chatstr[i];
        chatnode.Type = "News";
        chatnode.Items = GetMessage(i,UserPath,chatnode,UserId); 
        chatmessagenode.TreeNodes.push(chatnode);
    }
   return temp1; 
}

//聊天信息获取函数2
function GetMessage(type,UserPath,chatnode,UserId){
    var temp1 = new Array();
    var temp3 = ExecSql(UserPath,"select * from ZSESSIONENTITY where ZSESSIONTYPE = " + type.toString());
    if(temp3 != null && temp3.length != 0){
        for(var i in temp3){
            var temp2 = new News();
            temp2.List = temp3[i].ZSESSIONID + "_" + temp3[i].ZSESSIONNAME;
            temp1.push(temp2);
            var chatsonnode = new TreeNode();
            chatsonnode.Text = temp2.List;
            chatsonnode.Type = "ChatMessage";
            chatsonnode.Items = GetMessage2(type,UserPath,temp3[i].ZSESSIONID,UserId);
            chatnode.TreeNodes.push(chatsonnode);
        }
    }
    
    return temp1;   
}

//聊天信息获取函数3
function GetMessage2(type,UserPath,seId,UserId){
    if(type == 0){
        var sqlstr = "select * from ZCHATMESSAGEENTITY where ZSESSIONID = " + seId;   
    }
    else
    {
        var sqlstr = "select * from ZGROUPMESSAGEENTITY  where ZSESSIONID = " + seId;
    }
    var chatstr = ExecSql(UserPath,sqlstr);
    var temp1 = new Array();
    if(chatstr.length != 0 && chatstr != null)
    {
        
    for(var i in chatstr)
    {
        var temp2 =  new ChatMessage();
        temp2.DataState = XLY.Convert.ToDataState(chatstr[i].XLY_DataType);
        var leixin = chatstr[i].ZMSGTYPE;
        switch(leixin){
            case 1: temp2.MType = "语音";
            break;
            case 2: temp2.MType = "文本";
            break;
            case 3: temp2.MType = "图片";
            break;
            case 12: temp2.MType = "位置信息";
            break;
            case 13: temp2.MType = "名片";
            break;
            case 21: temp2.MType = "电话";
            break;
            case -201: temp2.MType = "语音信箱";
            break;
            default : temp2.MType = "系统消息";
            break;
        }
        if(chatstr[i].ZFROMUID == UserId){
            var  temptemp = GetLoUserInfo(UserId);
            temp2.Sender =temptemp[0].name + "(" + chatstr[i].ZFROMUID + ")" ;
        }
        else
        {
            var temp111 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = " + chatstr[i].ZFROMUID);
            if(temp111.length != 0 && temp111 != null){
                temp2.Sender = temp111[0].ZNICKNAME + "(" + chatstr[i].ZFROMUID + ")" ;
            }
            else
            {
                temp2.Sender = "未找到昵称" + "(" + chatstr[i].ZFROMUID + ")" ;
            }
        }
        
        if(type == 1){
            temp2.Receiver = "所有群成员";
        }
        else{
            if(chatstr[i].ZTOUID == UserId){
                var  temptemp1 = GetLoUserInfo(UserId);
                temp2.Receiver =temptemp1[0].name + "(" + chatstr[i].ZTOUID + ")" ;
            }
            else
            {
                var temp1111 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = " + chatstr[i].ZTOUID);
                if(temp1111.length != 0 && temp1111 != null){
                    temp2.Receiver = temp1111[0].ZNICKNAME + "(" + chatstr[i].ZTOUID + ")" ;
                }
                else
                {
                    temp2.Receiver = "未找到昵称" + "(" + chatstr[i].ZTOUID + ")" ;
                }
            }
        }
        switch(leixin)
        {
            case 2:temp2.Contents = chatstr[i].ZCONTENT; 
            break;
            
            case 21:
            {
                var temp11 = XLY.Blob.ToBytes(chatstr[i].ZBLOBDATA,"base64");
                temp11 = eval('('+ XLY.Blob.ToString(temp11) +')');
                var ttt = temp11.duration;
                if(ttt == 0){
                    temp2.Contents = "拒绝接听";
                }
                else if(ttt == -1){
                    temp2.Contents = "未接听";
                }
                else
                {
                    temp2.Contents = "通话时长" + ttt + "s";
                }
            }
            break;
            
            case 1: 
            {
                var temp11 = XLY.Blob.ToBytes(chatstr[i].ZBLOBDATA,"base64");
                temp11 = eval('('+ XLY.Blob.ToString(temp11) +')');
                temp2.Contents = "语音地址:" + temp11.fileUrl + "      " + "文件大小:" +temp11.fileSize;
            }
            break;
            
            case 3: 
            {
                var temp11 = XLY.Blob.ToBytes(chatstr[i].ZBLOBDATA,"base64");
                temp11 = eval('('+ XLY.Blob.ToString(temp11) +')');
                temp2.Contents = "图片地址:" + temp11.origImgUrl;
            }
            break;
            
            case 12: 
            {
                var temp11 = XLY.Blob.ToBytes(chatstr[i].ZBLOBDATA,"base64");
                temp11 = eval('('+ XLY.Blob.ToString(temp11) +')');
                temp2.Contents = "经度:" + temp11.longitude + "     " + "纬度:" + temp11.latitude;
            }
            break;
            case 13:
            {
                var temp11 = XLY.Blob.ToBytes(chatstr[i].ZBLOBDATA,"base64");
                temp11 = eval('('+ XLY.Blob.ToString(temp11) +')');
                temp2.Contents = "Uid:" + temp11.uid +"    " + "昵称:" + temp11.name + "头像:" + temp11.avatar;     
            }
            break;
            
            case -201:
            {
                var temp11 = XLY.Blob.ToBytes(chatstr[i].ZBLOBDATA,"base64");
                temp11 = eval('('+ XLY.Blob.ToString(temp11) +')');
                temp2.Contents = "语音信箱地址:" + temp11.fileUrl + "    " + "文件大小:" + temp11.fileSize ;
            }
            break;
            
            default:
            {
                temp2.Contents = "系统消息:" + chatstr[i].ZCONTENT; 
            }
            break; 
        }
        temp2.SendTime = XLY.Convert.LinuxToDateTime(chatstr[i].ZDISPLAYTIME);
        temp1.push(temp2);
    }
}
    return temp1;
}

//朋友圈获取函数
function GetTopic(UserPath,UserId){
    var temp1 = new Array();
    var sqlstr = "select *,cast(ZTOPICID as nchar)as topicid from ZSNSTOPICENTITY";
    var temp2 = ExecSql(UserPath,sqlstr);
    for(var i in temp2){
        var temp001 = XLY.Blob.ToBytes(temp2[i].ZBLOBDATA,"base64");
        var tempx = temp001.length -1;
        var topicmessage = new Topic;
        topicmessage.DataState = XLY.Convert.ToDataState(temp2[i].XLY_DataType);
        if(temp001[tempx] == 125){
            temp001 = eval('('+ XLY.Blob.ToString(temp001) +')');
            topicmessage.Desc = temp001.desc;
            topicmessage.Lngt =  eval('('+ temp001.geo +')').longitude;
            topicmessage.Lat =  eval('('+ temp001.geo +')').latitude;
            var picstr = "";
            for(var j in temp001.images){
                picstr = picstr + "图片地址:" + eval('('+ temp001.images[j] +')').originurl + "     ";
            }
            topicmessage.Pic = picstr;
        }
       topicmessage.SesId = temp2[i].topicid;
       topicmessage.SendTime = XLY.Convert.LinuxToDateTime(temp2[i].ZSRVTIME);
       topicmessage.Sender = temp2[i].ZSENDERUID;
       if(topicmessage.Sender == UserId){
           var temptemp = GetLoUserInfo(UserId);
           topicmessage.NickName = temptemp[0].name;
       }
       else
       {   
           var temptemp1 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = " + topicmessage.Sender);
           if(temptemp1 != null && temptemp1.length != 0){
                topicmessage.NickName = temptemp1[0].ZNICKNAME;
           }
       }
       var likeanddis = ExecSql(UserPath,"select * from ZSNSCOMMENTENTITY where ZTOPICID = " + topicmessage.SesId);
       for(var i in likeanddis){
           switch(likeanddis[i].ZCOMMENTTYPE){
             case 0:
              {
                  var likerperson = Nickname(UserPath,UserId,likeanddis[i].ZSENDERUID);
                  topicmessage.liker = topicmessage.liker  + likerperson + "(" + likeanddis[i].ZSENDERUID + ")" + ",";
              } 
               break;
             case 1:
              {
                 var likerperson = Nickname(UserPath,UserId,likeanddis[i].ZSENDERUID);
                 if(likeanddis[i].ZREPLYTOUID != null && likeanddis[i].ZREPLYTOUID.length != 0 && likeanddis[i].ZREPLYTOUID != 0 ){
                     var likerperson1 = Nickname(UserPath,UserId,likeanddis[i].ZREPLYTOUID);
                     topicmessage.discuss =  topicmessage.discuss + likerperson + "(" + likeanddis[i].ZSENDERUID + ")" + "回复" +likerperson1 + "(" + likeanddis[i].ZREPLYTOUID + ")" + ":" +  likeanddis[i].ZCONTENT + ",  ";
                 }
                 else
                 {
                     topicmessage.discuss =  topicmessage.discuss + likerperson + "(" + likeanddis[i].ZSENDERUID + ")" + ":" + likeanddis[i].ZCONTENT + ",  ";
                 }
                 
              } 
           }
       }
       temp1.push(topicmessage);
       
}
   return temp1;
}
function Nickname(UserPath,UserId,id){
    var nickname = "";
    if(id == UserId){
        var temptemp = GetLoUserInfo(UserId);
        nickname = temptemp[0].name;
    }
    else
    {   
        var temptemp1 = ExecSql(UserPath,"select * from ZUSERSIMPLEPROFILEENTITY where ZUSERID = " + id);
        if(temptemp1 != null && temptemp1.length != 0){
             nickname = temptemp1[0].ZNICKNAME;
        }
        else
        {
             nickname = "未找到昵称";
        }
    }
     return nickname;
}
