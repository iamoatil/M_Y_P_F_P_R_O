﻿/*[config]
<plugin name="HTC邮箱,3" group="主流邮箱,4"  devicetype="android" pump="USB,Mirror,Wifi,Bluetooth,chip,Raid" app="com.htc.android.mail" icon = "\icons\emil.png" description="提取HTC内置邮箱信息" data="$data,ComplexTreeDataSource">
   <source>
      <value>/data/data/com.htc.android.mail/databases/mail.db</value>
   </source>
   <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="邮箱地址" code="Address" type="string" width="" format=""></item>
        <item name="邮箱所属人名称" code="Name" type="string" width="" format=""></item>
   </data>

   <data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="发件人" code="Send" type="string" width="150" format=""></item>
        <item name="收件人" code="Receive" type="string" width="300" format=""></item>
        <item name="发送时间" code="SendTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
        <item name="主题" code="Subject" type="string" width="200" format=""></item>
        <item name="邮件内容" code="Content" type="string" width="200" format=""></item>
        <item name="阅读状态" code="IsRead" type="string" width="150" format=""></item>
   </data>
</plugin>
[config]*/
//********************************************* 定义数据结构*********************************************

//定义Account数据结构
function Account() {
    this.Address = "";
    this.Name = "";
    this.DataState = "Normal";
}

//定义Message数据结构
function Message() {
    this.DataState = "Normal";
    this.Send = "";
    this.Receive = "";
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.IsReply = "";
    this.Content = "";
    this.IsRead = "";
    this.IsMark = "";
    this.IsAttach = "";

}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}


function BindTree(){
    var root = new TreeNode();
    root.Text = "HTC邮箱列表";
    
    var source = $source;
    var path = source[0];
    //var path = "C:\\XLYSFTasks\\未命名-127\\source\\data\\data\\com.htc.android.mail\\databases\\mail.db";
    
    //定义特征库文件
    var charactor = "chalib\Andriod_Localmai\mail.charactor";

    //处理删除的数据
    var recoveryPath = XLY.Sqlite.DataRecovery(path, charactor, "accounts,messages,mailboxs");
    //var mailPath = XLY.Sqlite.DataRecovery(path, charactor, "messages");
    
    //创建帐号树结构
    var accountInfo = eval('(' + XLY.Sqlite.FindByName(recoveryPath, "accounts") + ')');

    for (var index in accountInfo) {
        var account = new TreeNode();
        account.Text = accountInfo[index].xly_name;
        account.Type = "Account";
        var data = getAccountInfo(accountInfo[index]);
        account.DataState = data.DataState;
        account.Items.push(data);
        buildChildNodesForAccount(accountInfo[index],account,recoveryPath);
        root.TreeNodes.push(account);
    }
    result.push(root);
    return result;
}


var result = new Array();
var res = JSON.stringify(BindTree());
res;



//**************************************** 定义处理APP数据的方法****************************************
//获取帐号详细信息
function getAccountInfo(data) {
    var obj = new Account();
    obj.Address = data.xly_name;
    obj.Name = data.xly_name;
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return obj;
}


//创建帐号节点的子节点
function buildChildNodesForAccount(datainfo,tree,path) {
    var fileInfo = eval('(' + XLY.Sqlite.Find(path, "select * from mailboxs where _account = '"+datainfo.xly_id+"'") + ')');
    var len = fileInfo.length;
    
    for(var info in fileInfo){
        var childNode = new TreeNode();
        childNode.Text = fileInfo[info].xly_shortname;
        childNode.Type = "Message";
        childNode.Items = getMessageInfoForChildNodes(datainfo.xly_id, fileInfo[info].xly_id,path);
        tree.TreeNodes.push(childNode);
    }
}

//获取邮件信息
function getMessageInfoForChildNodes(accid,mailid,path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from messages where _account='" + accid + "' and  _mailboxId='"+mailid+"'") + ')');
    var info = new Array();
    for (var index in data) {

        var obj = new Message();
        obj.Send = data[index].xly_from;
        obj.SendTime = XLY.Convert.LinuxToDateTime(data[index].xly_Date);
        obj.Receive = data[index].xly_to;
        obj.Subject = data[index].xly_subject;
        obj.IsRead = (data[index].xly_read == 1) ? "已阅" : "未读";
        obj.Content = data[index].xly_preview;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}


