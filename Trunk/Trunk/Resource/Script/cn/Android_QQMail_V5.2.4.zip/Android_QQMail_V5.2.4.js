﻿/*[config]
<plugin name="QQ邮箱,4" group="主流邮箱,4" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\QQMail.png" app="com.tencent.androidqqmail" version="5.2.4" description="QQ邮箱" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.tencent.androidqqmail/databases/AccountInfo</value>
<value>/data/data/com.tencent.androidqqmail/databases/QMMailDB</value>
</source>
<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" width="100" format="EnumDataState"></item>
<item name="名称" code="Name" type="string" width="100"></item>
<item name="邮箱地址" code="Email" type="string" width="300"></item>
</data>
<data detailfield="TextContent" type="Mail" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" width="100" format="EnumDataState"></item>
<item name="发件人" code="Sender" type="string" width="270" ></item>
<item name="收件人" code="Receiver" type="string" width="270" ></item>
<item name="发送时间" code="StartDate" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="接收时间" code="RecvDataTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="主题" code="Subject" type="string" width="300" ></item>
<item name="内容摘要" code="Abstract" type="string" width="300" ></item>
<item name="内容详细信息" code="TextContent" type="string" width="300" show='false'></item>
<item name="附件信息" code="Attachments" type="list" width="300" show='false'></item>
<item name="附件路径" code="AttachmentPaths" type="list" width="300" show='false'></item>
<item name="阅读状态" code="Status" type="string" width="100" ></item>
<item name="是否为星标邮件" code="Star" type="string" width="100" ></item>
</data>

<data type="Contact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" width="100" format="EnumDataState"></item>
<item name="好友名称" code="Name" type="string" width="200"></item>
<item name="邮箱地址" code="Email" type="string" width="300"></item>
<item name="备注" code="Mark" type="string" width="200"></item>
<item name="VIP会员" code="VIP" type="string" width="400"></item>
</data>
</plugin>
[config]*/



//********************************定义数据结构*************************************
//定义Account数据结构
function Account() {
    this.Name = "";
    this.Email = "";
    this.DataState = "Normal";
}

//定义Mail数据结构
function Mail() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Subject = "";
    this.Abstract = "";
    this.TextContent = "";
    this.Attachments = new Array();
    this.AttachmentPaths = new Array();
    this.Status = "";
    this.Star = "";
    this.DataState = "Normal";
}

//定义Contact数据结构
function Contact() {
    this.Name = "";
    this.Email = "";
    this.Mark = "";
    this.VIP = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//**********************************定义处理APP中数据的方法**********************************

//获取帐号信息
function getAccountInfo(data) {
    var obj = new Account();
    obj.Name = data.name;
    obj.Email = data.email;
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return obj;
}
//获取每个帐号的子节点信息
function buildChildNodeForAccount(path,acc,tree) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from QM_FOLDER where accountId='"+acc.id+"' ") + ')');
    for(var index in data){
        var childNode=new TreeNode();
        childNode.Text=data[index].name;
        childNode.Type="Mail";
        childNode.Items=getMailInfo(path,acc,data[index].id);
        tree.TreeNodes.push(childNode);
    }
    var contact = new TreeNode();
    contact.Text = "通讯录";
    contact.Type = "Contact";
    contact.DataState = "Normal";
    contact.Items = getConatactInfo(path, acc);
    tree.TreeNodes.push(contact);
}

//获取每个文件夹的邮件详细信息
function getMailInfo(path,acc,folderid){
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(id as nvarchar) as mid,* from QM_MAIL_INFO where accountId='" + acc.id + "'AND folderId='" + folderid + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Mail();
        //获取收件人信息
        obj.Sender = data[index].fromAddrName + "(" + data[index].fromAddr + ")";
        if (getReceivedInfo(path, data[index].mid) != "") {
            obj.Receiver = getReceivedInfo(path, data[index].mid);
        } else {
        obj.Receiver = acc.email;
        }
        obj.StartDate = XLY.Convert.LinuxToDateTime(parseInt(data[index].utcSent));
        obj.RecvDataTime = XLY.Convert.LinuxToDateTime(parseInt(data[index].utcReceived));
        obj.Subject = data[index].subject;
        obj.Abstract = data[index].abstract;
        //获取邮件详细内容信息
        var condata = eval('(' + XLY.Sqlite.Find(path, "select * from QM_MAIL_CONTENT where id='" + data[index].mid + "'") + ')');
        if (condata.length != 0 && condata[0].content != null) {
            obj.TextContent = condata[0].content;
        }
        //获取附件信息
        var attachData = eval('(' + XLY.Sqlite.Find(path, "select * from QM_MAIL_ATTACH where mailid='" + data[index].mid + "'") + ')');
        if (attachData.length != 0) {
            for (var attachi in attachData) {
                obj.Attachments.push("附件名称：" + attachData[attachi].name + "；附件大小:" + attachData[attachi].size);
                obj.AttachmentPaths.push(attachData[attachi].downloadurl);
            }
        } 
        obj.Status = (data[index].isUnread == 1) ? "未读" : "已读";
        obj.Star = (data[index].isStar == 1) ? "星标邮件" : "";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取收件人信息
function getReceivedInfo(path,id) {
    var data2 = eval('(' + XLY.Sqlite.Find(path, "select * from QM_REF_MAIL_ADDR where mid='" + id + "' AND roleType=2 ") + ')');
    var obj = ""
    if (data2.length != 0) {
        for (var index in data2) {
            obj = obj + data2[index].address + "(" + data2[index].addrName + ")；";
        }
    }

    //获取抄送人地址
    var data3 = eval('(' + XLY.Sqlite.Find(path, "select * from QM_REF_MAIL_ADDR where mid='" + id + "' AND roleType=3 ") + ')');
    if (data3.length != 0) {
        for (var index in data3) {
            obj = obj + "；抄送:" + data3[index].address + "(" + data3[index].addrName + ")；";
        }
    }

    //获取密送人地址
    var data4 = eval('(' + XLY.Sqlite.Find(path, "select * from QM_REF_MAIL_ADDR where mid='" + id + "' AND roleType=4 ") + ')');
    if (data4.length != 0) {
        for (var index in data4) {
            obj = obj + "；密送:" + data4[index].address + "(" + data4[index].addrName + ")；";
        }
    }

    //获取群邮件地址
    var data5 = eval('(' + XLY.Sqlite.Find(path, "select * from QM_REF_MAIL_ADDR where mid='" + id + "' AND roleType=5 ") + ')');
    if (data5.length != 0) {
        for (var index in data5) {
            obj = obj + "群邮件:" + data5[index].address + "(" + data5[index].addrName + ")";
        }
    }
    return obj;
}

//获取帐号通讯录信息
function getConatactInfo(path, acc) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from QM_CONTACT where accountid='" + acc.id + "' ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Contact();
        obj.Name = data[index].name;
        obj.Email = data[index].address;
        obj.Mark = data[index].mark;
        obj.VIP = (data[index].vip == 1) ? "VIP用户" : "";
        info.push(obj);
    }
    return info;
}

//绑定树形结构
function BindTree(){
    //源文件
    var source = $source;
    //var source =["D:\\temp\\data\\data\\com.tencent.androidqqmail\\databases\\AccountInfo","D:\\temp\\data\\data\\com.tencent.androidqqmail\\databases\\QMMailDB"];
    var accPath = source[0];
    var emailPath = source[1];
    

    //特征库文件
    var charactor1 = "chalib\\Android_QQMail_V5.2.4\\AccountInfo.charactor";
    var charactor2 = "chalib\\Android_QQMail_V5.2.4\\QMMailDB.charactor";

    //恢复删除的数据
    var recoveryAccPath = XLY.Sqlite.DataRecovery(accPath, charactor1, "AccountInfo");
    var recoveryEmailPath = XLY.Sqlite.DataRecovery(emailPath, charactor2, "QM_CONTACT,QM_FOLDER,QM_MAIL_ATTACH,QM_MAIL_CONTENT,QM_MAIL_INFO,QM_REF_CONTACT_EMAIL,QM_REF_MAIL_ADDR");

    //创建帐号树结构
    var data = eval('(' + XLY.Sqlite.FindByName(recoveryAccPath, "AccountInfo") + ')');
    var emil126 = new TreeNode();
    emil126.Text = "126邮箱";

    var qqemil = new TreeNode();
    qqemil.Text = "QQ邮箱";

    var emil163 = new TreeNode();
    emil163.Text = "163邮箱";

    var gemil = new TreeNode();
    gemil.Text = "Gmail邮箱";

    var outlookemil = new TreeNode();
    outlookemil.Text = "outlook邮箱";

    var otheremil = new TreeNode();
    otheremil.Text = "其他邮箱";

    for (var index in data) {
        var account = new TreeNode();
        account.Text = data[index].name;
        account.Type = "Account";
        account.Items.push(getAccountInfo(data[index]));
        buildChildNodeForAccount(recoveryEmailPath, data[index], account)
        if(XLY.Convert.ToString(data[index].email).split('@')[1]=="126.com")
            emil126.TreeNodes.push(account);
        else if(XLY.Convert.ToString(data[index].email).split('@')[1]=="163.com")
            emil163.TreeNodes.push(account);
        else if(XLY.Convert.ToString(data[index].email).split('@')[1]=="gmail.com")
            gemil.TreeNodes.push(account);
        else if(XLY.Convert.ToString(data[index].email).split('@')[1]=="outlook.com")
            outlookemil.TreeNodes.push(account);
        else if(XLY.Convert.ToString(data[index].email).split('@')[1]=="qq.com")
            qqemil.TreeNodes.push(account);
        else 
            otheremil.TreeNodes.push(account);
    }

    var root = new TreeNode();
    root.Text = "本地邮箱列表";

    root.TreeNodes.push(qqemil);
    root.TreeNodes.push(emil163);
    root.TreeNodes.push(emil126);
    root.TreeNodes.push(gemil);
    root.TreeNodes.push(outlookemil);
    root.TreeNodes.push(otheremil);
    result.push(root);
    
    return result;
}
//**********************************处理APP中数据**********************************
var result = new Array();
var res = JSON.stringify(BindTree());
res;