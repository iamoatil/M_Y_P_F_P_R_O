﻿/*[config]
<plugin name="Line,3" group="社交聊天,6" devicetype="android" icon="\icons\line.png" pump="LocalData,USB,Mirror,Wifi,Bluetooth,chip" app="jp.naver.line.android" version="7.1.1" description="Line" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/jp.naver.line.android/databases#F</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="列表" code="Account" type="string" width = "150"></item>
</data>
    <data type="UserInfo" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="ID" code="ID" type="string"  width = "150"></item>
    <item name="昵称" code="NickName" type="string" width = "150"></item>
    <item name="名字" code="ServerName" type="string" width = "150"></item>
    <item name="手机通讯录名字" code="AddressbookName" type="string" width = "150"></item>
    <item name="个性签名" code="Msg" type="string" width = "200"></item>
    <item name="头像本地链接" code="HeadUrl" type="string" width = "200"></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="更新时间" code="UpdateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Group" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="ID" code="ID" type="string"  width = "150"></item>
    <item name="群名称" code="Name" type="string" width = "150"></item>
    <item name="创建人" code="Creater" type="string" width = "200"></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="更新时间" code="UpdateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="GroupMember" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="ID" code="ID" type="string"  width = "150"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="是否接受邀请" code="IsAccepted" type="string" width = "200"></item>
</data>
<data type="Message" contract = "DataState" detailfield = "Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="ID" code="ID" type="string"  width = "150"></item>
    <item name="服务号" code="ServerID" type="string" show="false" width = "150"></item>
    <item name="发送者ID" code="SenderID" type="string" width = "150"></item>
    <item name="发送者" code="Sender" type="string" width = "150"></item>
    <item name="接收者ID" code="ReceiverID" type="string" width = "200"></item>
    <item name="接收者" code="Receiver" type="string" width = "200"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="位置名称" code="LocationName" type="string" width = "150"></item>
    <item name="详细位置" code="LocationAddress" type="string" width = "150"></item>
    <item name="经度" code="Lon" type="string" width = "150"></item>
    <item name="纬度" code="Lat" type="string" width = "150"></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="文件本地路径" code="Path" type="string" width = "150"></item>
    <item name="类型" code="Type" type="string"  width = "150"></item>
</data>

</plugin>
[config]*/
//定义News数据结构
function News(){
    this.Account = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.ID = "";
    this.NickName = "";
    this.ServerName = "";
    this.AddressbookName = "";
    this.Msg = "";
    this.HeadUrl = "";
    this.CreateTime = null;
    this.UpdateTime = null;
}
//定义Group数据结构
function Group(){
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
    this.Creater = "";
    this.CreateTime = null;
    this.UpdateTime = null;
}
//定义GroupMember数据结构
function GroupMember(){
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
    this.IsAccepted = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.ID = "";
    this.ServerID = "";
    this.SenderID = "";
    this.Sender = "";
    this.ReceiverID = "";
    this.Receiver = "";
    this.Content = "";
    this.LocationName = "";
    this.LocationAddress = "";
    this.Lon = "";
    this.Lat = "";
    this.CreateTime = null;
    this.Path = "";
    this.Type = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var naverLinePath1 = source[0]+"\\naver_line";
var e2eePath1 = source[0]+"\\e2ee";
//测试数据
//var naverLinePath1 = "C:\\XLYSFTasks\\任务-2017-03-08-13-54-09\\source\\data\\data\\jp.naver.line.android\\databases\\naver_line";
//var e2eePath1 = "C:\\XLYSFTasks\\任务-2017-03-08-13-54-09\\source\\data\\data\\jp.naver.line.android\\databases\\e2ee";

//定义特征库文件
//var naverLinePathcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Line_V7.1.1\\naver_line.charactor";
//var e2eePathcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Line_V7.1.1\\e2ee.charactor";

var naverLinePathcharactor = "\\chalib\\Android_Line_V7.1.1\\naver_line.charactor";
var e2eePathcharactor = "\\chalib\\Android_Line_V7.1.1\\e2ee.charactor";

//恢复数据库中删除的数据
var naverLinePath = XLY.Sqlite.DataRecovery(naverLinePath1,naverLinePathcharactor,"chat_history,contacts,groups,membership");
var e2eePath = XLY.Sqlite.DataRecovery(e2eePath1,e2eePathcharactor,"keystore");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "Line";
    root.Type = "News";
    getList(root);
    result.push(root);
}
//获取当前用户
function getList(root){
    if(XLY.File.IsValid(e2eePath)){
        var data = eval('('+ XLY.Sqlite.Find(e2eePath,"select * from keystore") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].prikey!=""&&data[i].prikey!= null){
                    if(XLY.File.IsValid(naverLinePath)){
                        var aa = eval('('+ XLY.Sqlite.Find(naverLinePath,"select * from contacts where m_id = '"+data[i].mid+"'") +')');
                        if(aa!=""&&aa!=null){
                            var node = new TreeNode();
                            node.Text = aa[0].m_id+"_"+aa[0].server_name;
                            node.Type = "UserInfo";
                            getUserInfo(node,data[i],aa);
                            root.TreeNodes.push(node);
                            var obj = new News();
                            obj.Account = node.Text;
                            root.Items.push(obj);
                        }
                    }
                }
            }
        }
    }
    return;
}
//获取当前用户信息
function getUserInfo(root,info,temp){
    var obj = new UserInfo();
    obj.DataState = XLY.Convert.ToDataState(info.XLY_DataType);
    obj.ID = info.mid;
    obj.NickName = temp[0].name;
    obj.ServerName = temp[0].server_name;
    obj.AddressbookName = temp[0].addressbook_name;
    obj.Msg = temp[0].status_msg;
    obj.HeadUrl = "存储盘/Android/dtat/jp.naver.android/storage/p/"+info.mid;
    obj.CreateTime = XLY.Convert.LinuxToDateTime(info.created_time);
    obj.UpdateTime = XLY.Convert.LinuxToDateTime(temp[0].updated_time);
    root.Items.push(obj);
    
    var contactNode = new TreeNode();
    contactNode.Text = "联系人";
    contactNode.Type = "UserInfo";
    getContactInfo(contactNode,obj.ID);
    
    var groupNode = new TreeNode();
    groupNode.Text = "群组";
    groupNode.Type = "Group";
    getGroupInfo(groupNode);
    
    var chatNode = new TreeNode();
    chatNode.Text = "聊天记录";
    chatNode.Type = "News";
    getChatNodeInfo(chatNode,info.mid+"_"+temp[0].name);
    
    root.TreeNodes.push(contactNode);
    root.TreeNodes.push(groupNode);
    root.TreeNodes.push(chatNode);
}
//获取联系人信息
function getContactInfo(root,info){
    if(XLY.File.IsValid(naverLinePath)){
        var data = eval('('+ XLY.Sqlite.Find(naverLinePath,"select * from contacts where m_id<>'"+info+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.ID = data[i].m_id;
                obj.NickName = data[i].name;
                obj.ServerName = data[i].server_name;
                obj.AddressbookName = data[i].addressbook_name;
                obj.Msg = data[i].status_msg;
                obj.HeadUrl = "存储盘/Android/dtat/jp.naver.android/storage/p/"+data[i].m_id;
                obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].created_time);
                obj.UpdateTime = XLY.Convert.LinuxToDateTime(data[i].updated_time);
                root.Items.push(obj);
            }
        }
    }
}
//获取群组信息
function getGroupInfo(root){
    if(XLY.File.IsValid(naverLinePath)){
        var data = eval('('+ XLY.Sqlite.Find(naverLinePath,"select * from groups") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new Group();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.ID = data[i].id;
                obj.Name = data[i].name;
                obj.Creater = data[i].creator;
                obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].created_time);
                obj.UpdateTime = XLY.Convert.LinuxToDateTime(data[i].updated_time);
                root.Items.push(obj);
                
                var node = new TreeNode();
                node.Text = obj.ID+"_"+obj.name;
                node.Type = "GroupMember";
                getGroupMember(node,obj.ID);
                root.TreeNodes.push(node);
            }
        }
    }
}
//获取每个群组的成员信息
function getGroupMember(root,info){
    if(XLY.File.IsValid(naverLinePath)){
        var data = eval('('+ XLY.Sqlite.Find(naverLinePath,"select * from membership where id='"+info+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new GroupMember();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.ID = data[i].m_id;
                var aa = eval('('+ XLY.Sqlite.Find(naverLinePath,"select name from contacts where m_id = '"+data[i].m_id+"'") +')');
                if(aa!=""&&aa!=null){
                    obj.Name = aa[0].name;
                }
                if(data[i].is_accepted==1){
                    obj.IsAccepted = "是";
                }
                else
                {
                    obj.IsAccepted = "否";
                }
                root.Items.push(obj);
            }
        }
    }
}
//获取聊天记录节点，好友聊天和群聊天
function getChatNodeInfo(root,user){
    if(XLY.File.IsValid(naverLinePath)){
        //创建群组节点
        var groupChatNode = new TreeNode();
        groupChatNode.Text = "群组聊天记录";
        groupChatNode.Type = "News";
        getGroupChatNode(groupChatNode,user);
        //创建好友聊天记录节点
        var friendChatNode = new TreeNode();
        friendChatNode.Text = "好友聊天记录";
        friendChatNode.Type = "News";
        getFriendChatNode(friendChatNode,user);
        root.TreeNodes.push(groupChatNode);
        root.TreeNodes.push(friendChatNode);
        var data = ["群组聊天记录","好友聊天记录"];
        for(var i in data){
            var obj = new News();
            obj.Account = data[i];
            root.Items.push(obj);
        }
    }
}
//获取所有群组的聊天记录
function getGroupChatNode(root,user){
    if(XLY.File.IsValid(naverLinePath)){
        var data = eval('('+ XLY.Sqlite.Find(naverLinePath,"select distinct(chat_id) from chat_history where chat_id like 'c%' or chat_id like 'r%'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new News();
                
                var node = new TreeNode();
                var info = eval('('+ XLY.Sqlite.Find(naverLinePath,"select name from groups where id = '"+data[i].chat_id+"'") +')');
                if(info!=""&&info!=null){
                    node.Text = data[i].chat_id+"_"+info[0].name;
                }
                else
                {
                    node.Text = data[i].chat_id;
                }
                node.Type = "Message";
                getGroupChatInfo(node,data[i].chat_id,user);
                obj.Account = node.Text;
                root.Items.push(obj);
                root.TreeNodes.push(node);
            }
        }
    }
}

//获取所有参与聊天的好友的节点
function getFriendChatNode(root,user){
    if(XLY.File.IsValid(naverLinePath)){
        var data = eval('('+ XLY.Sqlite.Find(naverLinePath,"select distinct(chat_id) from chat_history where chat_id like 'u%'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new News();
                
                var node = new TreeNode();
                var info = eval('('+ XLY.Sqlite.Find(naverLinePath,"select name from contacts where m_id = '"+data[i].chat_id+"'") +')');
                if(info!=""&&info!=null){
                    node.Text = data[i].chat_id+"_"+info[0].name;
                }
                else
                {
                    node.Text = data[i].chat_id;
                }
                node.Type = "Message";
                getGroupChatInfo(node,data[i].chat_id,user);
                obj.Account = node.Text;
                root.Items.push(obj);
                root.TreeNodes.push(node);
            }
        }
    }
}
//获取每个群组聊天记录
function getGroupChatInfo(root,info,user){
    var data = eval('('+ XLY.Sqlite.Find(naverLinePath,"select * from chat_history where chat_id = '"+info+"'") +')');
    if(data!=""&&data!=null){
        for(var i in data){
            if(data[i].XLY_DataType==2){
                var obj = new Message();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.ID = data[i].id;
                obj.ServerID = data[i].server_id;
                if(data[i].from_id!=""&&data[i].from_id!=null){
                    obj.SenderID = data[i].from_id;
                    var aa = eval('('+ XLY.Sqlite.Find(naverLinePath,"select name from contacts where m_id = '"+data[i].from_id+"'") +')');
                    if(aa!=""&&aa!=null){
                        obj.Sender = aa[0].name;
                    }
                }
                else
                {
                    obj.SenderID = user.toString().split("_")[0];
                    obj.Sender = user.toString().split("_")[1];
                }
                obj.ReceiverID = data[i].chat_id;
                var bb = eval('('+ XLY.Sqlite.Find(naverLinePath,"select name from groups where id = '"+data[i].chat_id+"'") +')');
                var cc = eval('('+ XLY.Sqlite.Find(naverLinePath,"select name from contacts where m_id = '"+data[i].chat_id+"'") +')');
                if(bb!=""&&bb!=null){
                    obj.Receiver = bb[0].name;
                }
                if(cc!=""&&cc!=null){
                    obj.Receiver = cc[0].name;
                }
                obj.LocationName = data[i].location_name;
                obj.LocationAddress = data[i].location_address;
                obj.Lon = data[i].location_longitude;
                obj.Lat = data[i].location_latitude;
                obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].created_time);
                obj.Path = "/Android/dtat/jp.naver.android/storage/mo/"+data[i].chat_id+"/"+data[i].id;
                if(data[i].attachement_type==0){
                    obj.Type = "文本";
                    obj.Content = data[i].content;
                }
                else if(data[i].attachement_type==1){
                    obj.Type = "图片";
                    if(data[i].parameter!=""&&data[i].parameter!=null){
                        
                        var aa = data[i].parameter.indexOf("{");
                        var bb = data[i].parameter.indexOf("}");
                        if(aa!=-1&&bb!=-1){
                            var cc = data[i].parameter.substr(aa,bb);
                            var dd = eval('('+ cc +')');
                            obj.Content = "图片路径："+data[i].attachement_local_uri+"\r"+"参数：\r类型："+dd.category+";\r后缀："+dd.extension+";\r是否为动态的："+dd.animated+";\r宽："+dd.width+";\r高："+dd.height+";\r文件大小："+bb.fileSize;
                        }
                        else
                        {
                            obj.Content = "图片路径："+data[i].attachement_local_uri;
                        }
                    }
                    else
                    {
                        obj.Content = "图片路径："+data[i].attachement_local_uri;
                    }
                }
                else if(data[i].attachement_type==3){
                    obj.Type = "语音";
                    obj.Content = "语音长度："+data[i].parameter+"毫秒";
                }
                else if(data[i].attachement_type==4){
                    obj.Type = "系统消息";
                    var aa = data[i].parameter.split("\t");
                    var size = aa.length;
                    for(var j=0; j<size ;j++){
                        if(aa[j]=="WIDTH_DIP"){
                            var num = j+1;
                            obj.Content += "宽："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="html_cached_portrait_height_dip"){
                            var num = j+1;
                            obj.Content += "高："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="HTML_CONTENT"){
                            var num = j+1;
                            obj.Content += "网页内容："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="ALT_TEXT"){
                            var num = j+1;
                            obj.Content += "标题："+aa[num]+"\r";
                            j = num-1;
                        }
                    }
                }
                else if(data[i].attachement_type==6){
                    obj.Type = "通话";
                    var aa = data[i].parameter.split("\t");
                    var size = aa.length;
                    for(var j=0; j<size ;j++){
                        if(aa[j]=="voipGcMediaType"){
                            var num = j+1;
                            obj.Content += "类型："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="voipGcChatMid"){
                            var num = j+1;
                            obj.Content += "ID："+aa[num]+"\r";
                            j = num-1;
                        }
                    }
                }
                else if(data[i].attachement_type==7){
                    obj.Type = "表情";
                    var aa = data[i].parameter.split("\t");
                    var size = aa.length;
                    for(var j=0; j<size ;j++){
                        if(aa[j]=="STKTXT"){
                            var num = j+1;
                            obj.Content += "标签："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="STKID"){
                            var num = j+1;
                            obj.Content += "ID："+aa[num]+"\r";
                            j = num-1;
                        }
                    }
                }
                else if(data[i].attachement_type==13){
                    obj.Type = "名片";
                    var aa = data[i].parameter.split("\t");
                    obj.Content = "ID："+aa[0].mid+"\r"+"名称："+aa[0].displayName;
                }
                else if(data[i].attachement_type==15){
                    obj.Type = "地理信息";
                    obj.Content = data[i].parameter;
                }
                else if(data[i].attachement_type==16){
                    obj.Type = "群空间消息";
                    var aa = data[i].parameter.split("\t");
                    var size = aa.length;
                    for(var j=0; j<size ;j++){
                        if(aa[j]=="postEndUrl"){
                            var num = j+1;
                            obj.Content += "链接："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="albumName"){
                            var num = j+1;
                            obj.Content += "签名："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="text"){
                            var num = j+1;
                            obj.Content += "内容："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="width"){
                            var num = j+1;
                            obj.Content += "宽："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="height"){
                            var num = j+1;
                            obj.Content += "高："+aa[num]+"\r";
                            j = num-1;
                        }
                    }
                }
                else if(data[i].attachement_type==14)
                {
                    obj.Type = "文件";
                    obj.Content = "文件路径："+data[i].attachement_local_uri+"\r";
                    var aa = data[i].parameter.split("\t");
                    var size = aa.length;
                    for(var j=0; j<size ;j++){
                        if(aa[j]=="FILE_EXPIRE_TIMESTAMP"){
                            var num = j+1;
                            obj.Content += "文件过期时间："+XLY.Convert.LinuxToDateTime(aa[num])+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="FILE_NAME"){
                            var num = j+1;
                            obj.Content += "文件名："+aa[num]+"\r";
                            j = num-1;
                        }
                        if(aa[j]=="FILE_SIZE"){
                            var num = j+1;
                            obj.Content += "文件大小："+aa[num]+"Bytes"+"\r";
                            j = num-1;
                        }
                    }
                }
                else
                {
                    obj.Type = "未知";
                    obj.Content = data[i].parameter;
                }
                root.Items.push(obj);
            }
        }
    }
}