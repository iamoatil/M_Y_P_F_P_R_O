﻿/*[config]
<plugin name="8684公交,2" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\ChinaBus.png" app="cn.chinabus.main" version="10.3.113" description="8684公交" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/cn.chinabus.main/databases/history</value>
<value>/data/data/cn.chinabus.main/databases/new_operate_log</value>
<value>/data/data/cn.chinabus.main/databases/cnbuscity</value>
<value>/data/data/cn.chinabus.main/shared_prefs/common.xml</value>
<value>/data/data/cn.chinabus.main/shared_prefs/cn.chinabus.home.navigationmanager.xml</value>
</source>
<data type="Account">
<item name="ID" code="ID" type="string" width="80" ></item>
<item name="昵称" code="Name" type="string" width="140" ></item>
<item name="头像" code="Photo" type="string" width="140" ></item>
<item name="备注" code="Remark" type="string" width="140" ></item>
</data>

<data type="History" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="100" ></item>
<item name="历史搜索" code="Search" type="string" width="200" ></item>
</data>

<data type="HistoryLine" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="100" ></item>
<item name="路线" code="Line" type="string" width="200" ></item>
</data>

<data type="HistoryStation" contract="DataState,Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="100" ></item>
<item name="描述" code="Desc" type="string" width="100" ></item>
<item name="经度" code="Longitude" type="double" width="200" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="200" format="F4"></item>
<item name="时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="HistoryTransfer" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="100" ></item>
<item name="起点" code="Start" type="string" width="200" ></item>
<item name="终点" code="End" type="string" width="200" ></item>
</data>

<data type="Favorite" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="100" ></item>
<item name="收藏信息" code="Name" type="string" width="200" ></item>
<item name="收藏类型" code="Type" type="string" width="100" ></item>
</data>

<data type="FavoriteLine" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="100" ></item>
<item name="路线名称" code="Name" type="string" width="140" ></item>
<item name="日期" code="Time" type="datetime" width="140" format="yyyy-MM-dd"></item>
</data>

<data type="FavoriteStation" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="城市" code="City" type="string" width="150" ></item>
<item name="站点" code="Station" type="string" width="200" ></item>
</data>

<data type="ShortCut" contract="Map">
<item name="选项" code="Type" type="string" width="100" ></item>
<item name="所属帐号" code="Ower" type="string" width="100" ></item>
<item name="描述" code="Desc" type="string" width="200" ></item>
<item name="经度" code="Longitude" type="double" width="100" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="100" format="F4"></item>
<item name="时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//**************************************************定义APP数据结构**************************************************
//定义Account数据结构
function Account() {
    this.ID = "";
    this.Name = "";
    this.Photo = "";
    this.Remark = "";
}

//定义History数据结构
function History() {
    this.City = "";
    this.Search = "";
    this.DataState = "Normal";
}

//定义HistoryLine数据结构
function HistoryLine() {
    this.City = "";
    this.Line = "";
    this.DataState = "Normal";
}

//定义HistoryStation数据结构
function HistoryStation() {
    this.City = "";
    this.Desc = "";
    this.Date = null;
    this.Longitude = "";
    this.Latitude = "";
    this.DataState = "Normal";
}

//定义HistoryTransfer数据结构
function HistoryTransfer() {
    this.City = "";
    this.Start = "";
    this.End = "";
    this.DataState = "Normal";
}

//定义Favorite数据结构
function Favorite() {
    this.City = "";
    this.Name = "";
    this.DataState = "Normal";
    this.Type = "";
}

//定义FavoriteLine数据结构
function FavoriteLine() {
    this.City = "";
    this.Name = "";
    this.Time = null;
    this.DataState = "Normal";
}

//定义FavoriteStation数据结构
function FavoriteStation() {
    this.City = "";
    this.Station = "";
    this.DataState = "Normal";
}

//定义ShortCut数据结构
function ShortCut() {
    this.Type = "";
    this.Ower = "";
    this.Data = null;
    this.Desc = "";
    this.Longitude = 0;
    this.Latitude = 0;
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//**************************************************处理APP数据的方法**************************************************
//获取帐号信息
function getAccount(path) {
    var flag = XLY.File.IsValid(path);
    if (flag == true) {
        var data = eval('(' + XLY.File.ReadXML(path) + ')');
        var arr = new Array();
        var info = data.map.string
        for (var index in info) {
            if (info[index]['@name'] == "nickName") {
                arr.push(info[index]['#text']);
            }
            if (info[index]['@name'] == "userId") {
                arr.push(info[index]['#text']);
            }
            if (info[index]['@name'] == "userFace") {
                arr.push(info[index]['#text']);
            }
            if (info[index]['@name'] == "gender") {
                arr.push(info[index]['#text']);
            }
            if (info[index]['@name'] == "user_pwd_save") {
                arr.push(info[index]['#text']);
            }
        }
        var object = new Account();
        object.ID = arr[2];
        object.Name = arr[1];
        object.Photo = arr[4];
        object.Remark = "性别：" + (arr[3] >= 0 ? (arr[3] == 0 ? "女" : "男") : "") + " ;\n" + "帐号密码:" + arr[0];
        return object;
    } else {
        return [];
    }
}
//********************************历史搜索树节点的处理******************************
//创建历史搜索子节点树
function buildChildNodeForHistory(path, tbpath, cityPath, node) {
    var historyLine = new TreeNode();
    historyLine.Text = "历史路线查询";
    historyLine.Type = "HistoryLine";
    var lineInfo = getHistoryLineInfo(path, cityPath);
    historyLine.Items = lineInfo;

    var historyStation = new TreeNode();
    historyStation.Text = "历史站点查询";
    historyStation.Type = "HistoryStation";
    var stationInfo = getHistoryStationInfo(path, cityPath);
    historyStation.Items = stationInfo;

    var historyTransfer = new TreeNode();
    historyTransfer.Text = "历史换乘查询";
    historyTransfer.Type = "HistoryTransfer";
    var transferInfo = getHistoryTransferInfo(tbpath);
    historyTransfer.Items = transferInfo;

    node.Items = getHistoryInfo(lineInfo, stationInfo, transferInfo);
    node.TreeNodes.push(historyLine);
    node.TreeNodes.push(historyStation);
    node.TreeNodes.push(historyTransfer);
}

//获取HistoryLine子节点信息
function getHistoryLineInfo(path, cityPath) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from new_operate_log where kind=1") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new HistoryLine();
        var flag = XLY.File.IsValid(cityPath);
        if (flag == true) {
            var cityName = eval('(' + XLY.Sqlite.Find(cityPath, "select * from cnbuscity where ecity='" + data[index].enCity + "' ") + ')');
            obj.City = cityName[0].city;
        } else {
            obj.City = data[index].enCity;
        }
        obj.Line = data[index].name;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取HistoryStation子节点信息
function getHistoryStationInfo(path, cityPath) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from new_operate_log where kind=0") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new HistoryStation();
        if (data[index].name != "") {
            var flag = XLY.File.IsValid(cityPath);
            if (flag == true) {
                var cityName = eval('(' + XLY.Sqlite.Find(cityPath, "select * from cnbuscity where ecity='" + data[index].enCity + "' ") + ')');
                obj.City = cityName[0].city;
            } else {
                obj.City = data[index].enCity;
            }
            obj.Desc = data[index].name;
            obj.Longitude = (data[index].xzhan) / 100000;
            obj.Latitude = data[index].yzhan / 100000;
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            info.push(obj);
        }
    }
    return info;
}

//获取HistoryTransfer结构数据
function getHistoryTransferInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select mCity as city ,startStation as start,endStation as end,lon,lat,XLY_DataType from tb_history where kind='TRANSFER'") + ')');
    var arr = new Array();
    for (var index in data) {
        var object = new HistoryTransfer();
        var lon = data[index].lon.split(",");
        var lat = data[index].lat.split(",");
        object.City = data[index].city;
        object.Start = data[index].start + "(" + "经度:" + lon[0] * 100 + "纬度:" + lat[0] / 100000 + ")";
        object.End = data[index].end + "(" + "经度:" + lon[1] * 100 + "纬度:" + lat[1] / 100000 + ")";
        object.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        arr.push(object);
    }
    return arr;
}

//获取历史搜索节点信息
function getHistoryInfo(data1, data2, data3) {
    var info = new Array();
    for (var index in data1) {
        var obj = new History();
        obj.City = data1[index].City;
        obj.Search = data1[index].Line;
        obj.DataState = data1[index].DataState;
        info.push(obj);
    }
    for (var num in data2) {
        var obj = new History();
        obj.City = data2[num].City;
        obj.Search = data2[num].Desc;
        obj.DataState = data2[num].DataState;
        info.push(obj);
    }
    for (var list in data3) {
        var obj = new History();
        obj.City = data3[list].City;
        obj.Search = data3[list].Start + "至" + data3[list].End;
        obj.DataState = data3[list].DataState;
        info.push(obj);
    }
    return info;
}
//********************************收藏记录树节点的处理******************************
//获取收藏节点信息
function getFavorite(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from tb_collect") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Favorite();
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.City = data[index].mCity;
        if (data[index].kind == "LINE") {
            obj.Name = data[index].busLine;
            obj.Type = "公交路线";
        } else if (data[index].kind == "STATION") {
            obj.Name = data[index].busStation;
            obj.Type = "乘车站点";
        }
        info.push(obj);
    }
    return info;
}

//创建收藏树的子节点
function buildChildNodeForFavorite(path, node) {
    //创建查询路线树结构
    var lineTree = new TreeNode();
    lineTree.Text = "收藏路线";
    lineTree.Type = "FavoriteLine";
    var linsql = "select * from tb_collect where kind='LINE' ";
    var lineinfo = getFavoriteLine(path, linsql);
    lineTree.Items = lineinfo;

    //创建查询站点树结构
    var stationTree = new TreeNode();
    stationTree.Text = "收藏站点";
    stationTree.Type = "FavoriteStation";
    var stasql = "select * from tb_collect where kind='STATION'";
    var stationinfo = getFavoriteStation(path, stasql);
    stationTree.Items = stationinfo;

    node.TreeNodes.push(lineTree);
    node.TreeNodes.push(stationTree);
}

//获取FavoriteLine结构数据
function getFavoriteLine(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var obj = new FavoriteLine();
        obj.City = data[index].mCity;
        obj.Name = data[index].busLine;
        obj.Time = data[index].historydate;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        arr.push(obj);
    }
    return arr;
}

//获取FavoriteStation结构数据
function getFavoriteStation(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var obj = new FavoriteStation();
        obj.City = data[index].mCity;
        obj.Station = data[index].busStation;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        arr.push(obj);
    }
    return arr;
}

//********************************快捷设置树节点的处理******************************
//获取快捷设置节点信息
function getShortcutInfo(path) {
    var flag = XLY.File.IsValid(path);
    if (flag == true) {
        var info = eval('(' + XLY.File.ReadXML(path) + ')');
        var arr = new Array();
        var data = info.map.string;
        for (var index in data) {
            var row = data[index]["@name"].split("&&&");
            var obj = new ShortCut();
            obj.Ower = row[0];
            switch (row[1]) {
                case "COMPANY": obj.Type = "公司"; break
                case "SCHOOL": obj.Type = "学校"; break
                case "HOME": obj.Type = "家"; break
                default: obj.Type = "默认";
            }
            var list = data[index]["#text"].split("-");
            obj.Desc = list[0] + "市" + list[1];
            if (list[3] > 0 && list[3] <= 180) {
                obj.Longitude = list[3];
            } else {
                obj.Longitude = list[3].substring(0, list[3].indexOf("E")) * 100;
            }
            if (list[2] > 0 && list[2] < 90) {
                obj.Latitude = list[2];
            } else {
                obj.Latitude = list[2] / 100000;
            }
            arr.push(obj);
        }
        return arr;
    } else {
        return "";
    }
}
//**************************************************处理APP数据**************************************************
var result = new Array();
var source = $source;
var dataRoot = source[0];
var searchPath = source[1];
var cityPath = source[2];
var accpath = source[3];
var shortcutPath = source[4];
//var dataRoot = "C:\\Users\\Administrator\\Desktop\\cn.chinabus.main\\databases\\history";
//var searchPath = "C:\\Users\\Administrator\\Desktop\\cn.chinabus.main\\databases\\new_operate_log";
//var cityPath="C:\\Users\\Administrator\\Desktop\\cn.chinabus.main\\databases\\cnbuscity";
//var accpath = "C:\\Users\\Administrator\\Desktop\\cn.chinabus.main\\shared_prefs\\common.xml";
//var shortcutPath = "C:\\Users\\Administrator\\Desktop\\cn.chinabus.main\\shared_prefs\\cn.chinabus.home.navigationmanager.xml";

//定义特征库
var charactor1 = "chalib\\Android_8684bus_V10.3.113\\history";
var charactor2 = "chalib\\Android_8684bus_V10.3.113\\new_operate_log";

//处理sqlite格式的数据文件
var recoveryDataPath = XLY.Sqlite.DataRecovery(dataRoot, charactor1, "tb_collect,tb_history");
var recoverySearchPath = XLY.Sqlite.DataRecovery(searchPath, charactor2, "new_operate_log");

//创建帐号信息树
var account = new TreeNode();
account.Text = "最后登陆帐号";
account.Type = "Account";
var accinfo = getAccount(accpath);
account.Items = accinfo;

//创建查询换乘树结构
var historyTree = new TreeNode();
historyTree.Text = "历史查询";
historyTree.Type = "History";
buildChildNodeForHistory(recoverySearchPath, recoveryDataPath, cityPath, historyTree);

var favoriteTree = new TreeNode();
favoriteTree.Text = "收藏记录";
favoriteTree.Type = "Favorite";
favoriteTree.Items = getFavorite(recoveryDataPath);
buildChildNodeForFavorite(recoveryDataPath, favoriteTree);

//创建快捷设置树节点
var shortcutTree = new TreeNode();
shortcutTree.Text = "快捷设置";
shortcutTree.Type = "ShortCut";
shortcutTree.Items = getShortcutInfo(shortcutPath);

//输出每棵树
result.push(account);
result.push(historyTree);
result.push(favoriteTree);
result.push(shortcutTree);
var res = JSON.stringify(result);
res;
