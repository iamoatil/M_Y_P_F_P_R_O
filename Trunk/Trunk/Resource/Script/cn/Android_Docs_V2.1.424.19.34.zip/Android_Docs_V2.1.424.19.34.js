﻿/*[config]
<plugin name="谷歌云端硬盘,9" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/doc.png" app="com.google.android.apps.docs" version="2.1.424.19.34" description="谷歌云端硬盘" data="$data,ComplexTreeDataSource"  >
<source>
    <value>data/data/com.google.android.apps.docs/databases/DocList.db</value>
</source>
    <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="账户名称" code="Name" type="string" width="180" format = ""></item>
        <item name="同步时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="Info" detailfield="HtmlUri" datefilter="CreateTime" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Title" type="string" width="200" format=""></item>
        <item name="创建者" code="Creator" type="string" width="200" format=""></item>
        <item name="所有者" code="Owner" type="string" width="200" format=""></item>
        <item name="创建时间" code="CreateTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="修改时间" code="ModifiedTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
        <item name="文件类型" code="Type" type="string" width="100" format=""></item>
        <item name="文件大小" code="Size" type="string" width="100" format = ""></item>
        <item name="文件地址" code="HtmlUri" type="url" width="400" format=""></item>
   </data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义Account数据结构
function Account() {
    this.Name = "";
    this.Time = null;
    this.DataState = "Normal";
}

//定义Message数据结构
function Info() {
    this.DataState = "Normal";
    this.Title = "";
    this.Creator = "";
    this.Owner = "";
    this.CreateTime = null;
    this.ModifiedTime = null;
    this.Type = "";
    this.Size = "";
    this.HtmlUri = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

var result = new Array();

//源文件
var source = $source;
//测试文件
//var source = ["C:\\Users\\Administrator\\Desktop\\com.google.android.apps.docs\\databases\\DocList.db"];
var names = eval('('+XLY.Sqlite.Find(source[0], "select * from sqlite_master where type = 'table' ")+')');
var accTable = "";
var entry = "";
var document = "";
for(var i in names){
    if(names[i].name.indexOf("Account")>=0&&names[i].name.length<11){
        accTable = names[i].name;
        continue;
    }
    if(names[i].name.indexOf("Entry")>=0&&names[i].name.length<9){
        entry = names[i].name;
        continue;
    }
    if(names[i].name.indexOf("Document")>=0&&names[i].name.length<12){
        document = names[i].name;
        continue;
    }
}
var ch = "\\chalib\\Android_Docs_V2.1.424.19.34\\DocList.db.charactor";;
var table = accTable+","+entry+","+document;
var path = XLY.Sqlite.DataRecovery(source[0],ch,table);

//主界面函数
function ParesCore(){
    //定义网盘节点
    var acc = getAccount();
    var docNode = BuildNode("谷歌云端硬盘","Account",acc,"Normal");
    //定义账户节点
    for(var i in acc){
        var accNode = BuildNode(acc[i].Name,"Info",getInfo(acc[i].ID),acc[i].DataState);
        docNode.TreeNodes.push(accNode);
    }
    result.push(docNode);
}

//创建节点
function BuildNode(text,type,items,dataState){
    var node = new TreeNode();
    node.Text = text;
    node.Type = type;
    node.Items = items;
    node.DataState = dataState;
    return node;
}

//获取账户信息
function getAccount(){
    var db = eval('('+ XLY.Sqlite.FindByName(path,accTable) +')');
    var Items = new Array();
    for(var i in db){
        var acc = new Account();
        acc.Name = db[i].accountHolderName;
        acc.Time = XLY.Convert.LinuxToDateTime(db[i].lastSyncTime);
        acc.ID = db[i].Account_id;
        acc.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(acc);
    }
    return Items;
}

//获取网盘信息
function getInfo(ID){
    var db = eval('('+ XLY.Sqlite.Find(path,"select * from '"+entry+"' where accountId = '"+ID+"'") +')');
    var Items = new Array()
    if(db!=null&&db.length>0){
        for(var i in db){
            var info = new Info();
            info.Title = db[i].title;
            info.Creator = db[i].creator;
            info.Owner = db[i].owner;
            info.CreateTime = XLY.Convert.LinuxToDateTime(db[i].creationTime);
            info.ModifiedTime = XLY.Convert.LinuxToDateTime(db[i].lastModifiedTime);
            info.Type = db[i].mimeType;
            var db1 = eval('('+ XLY.Sqlite.Find(path,"select * from '"+document+"' where entryId = '"+db[i].Entry_id+"'") +')');
            if(db1!=null&&db1.length>0){
                info.Size = db1[0].size+"/byte";
                info.HtmlUri = db1[0].htmlUri;
            }
            info.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(info);
        }
    }
    return Items;
}

ParesCore();
var res = JSON.stringify(result);
res;
