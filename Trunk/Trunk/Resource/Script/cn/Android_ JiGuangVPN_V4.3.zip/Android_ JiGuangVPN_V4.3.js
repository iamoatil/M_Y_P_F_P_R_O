﻿/*[config]
<plugin name="极光Vpn,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/jiguang.png" app="cn.vpn.vpnfree" version="4.3" description="极光Vpn" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/cn.vpn.vpnfree/shared_prefs/account.xml</value>
    <value>/data/data/cn.vpn.vpnfree/databases#F</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "150"></item>
    <item name="密码" code="PassWord" type="string" width="120"></item>
    <item name="邮箱" code="Emaill" type="string" width="150"></item>
    <item name="谷歌当天热搜" code="GoogleTodayHot" type="string" width="150"></item>
    <item name="默认服务器" code="DefaultProfileName" type="string" width="150"></item>
</data>
<data type="MakeComplaints" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width = "150"></item>
    <item name="创建时间" code="CreateDate" type="string" width="100"></item>
    <item name="标题" code="Title" type="string" width="120"></item>
    <item name="已读" code="IsRead" type="string" width="80"></item>
</data>
<data type="OverseasRecommendation" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width = "150"></item>
    <item name="标题" code="Title" type="string" width = "120"></item>
    <item name="链接" code="Url" type="Url" width="120"></item>
    <item name="创建时间" code="CreateDate" type="string" width="100"></item>
    <item name="类型" code="TypeCotent" type="string" width="80"></item>
    <item name="阅读次数" code="PlayTimes" type="string" width="80"></item>
    <item name="来源" code="SourcePath" type="string" width="80"></item>
</data>
<data type="SearchWord" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width = "150"></item>
    <item name="内容" code="SearchName" type="string" width = "100"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function SearchWord(){
    this.DataState = "Normal";
    this.ID = "";
    this.SearchName = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PassWord = "";
    this.Emaill = "";
    this.GoogleTodayHot = "";
    this.DefaultProfileName = "";
}
function MakeComplaints(){
    this.DataState = "Normal";
    this.ID = "";
    this.CreateDate = "";
    this.Title = "";
    this.IsRead = "否";
}
function OverseasRecommendation(){
    this.DataState = "Normal";
    this.ID = "";
    this.Title = "";
    this.Url = "";
    this.CreateDate = "";
    this.TypeCotent = "";
    this.PlayTimes = "";
    this.SourcePath = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath = source[0];
var allPath = source[1];

//测试数据
//var userPath = "D:\\temp\\data\\data\\cn.vpn.vpnfree\\shared_prefs\\account.xml";
//var allPath = "D:\\temp\\data\\data\\cn.vpn.vpnfree\\databases";
//定义特征库文件
var charactor1 = "\\chalib\\Android_JiGuangVPN_V4.3\\vpn.db.charactor";
var charactor2 = "\\chalib\\Android_JiGuangVPN_V4.3\\vpnsearchrecord.db.charactor";
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "极光Vpn";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userinfo = eval('('+ XLY.File.ReadXML(userPath) +')');
        if(userinfo!=""&&userinfo!=null){
            var aa = userinfo.map.string;
            if(aa!=""&&aa!=null){
                var obj = new UserInfo();
                obj.UserName = "";
                obj.PassWord = "";
                obj.Emaill = "";
                obj.GoogleTodayHot = "";
                obj.DefaultProfileName = "";
                for(var i in aa){
                    if(aa[i]["@name"]=="googletodayhot"){
                        obj.GoogleTodayHot = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="emailaddress"){
                        obj.Emaill = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="username"){
                        obj.UserName = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="defaultprofilename"){
                        obj.DefaultProfileName = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="password"){
                        obj.PassWord = aa[i]["#text"];
                    }
                }
                var node = new TreeNode();
                node.Text = obj.UserName;
                node.Type = "UserInfo";
                node.Items.push(obj);
                getUserNode(node);
                if(node.Items!=""&&node.Items!=null){
                    root.TreeNodes.push(node);
                }
            }
        }
    }
}
function getUserNode(root){
    var searchPath1 = allPath+"\\vpnsearchrecord.db";
    if(XLY.File.IsValid(searchPath1)){
        var searchPath = XLY.Sqlite.DataRecovery(searchPath1,charactor2,"searchrecords");
        if(XLY.File.IsValid(searchPath)){
            var dataSearch = eval('('+ XLY.Sqlite.Find(searchPath,"select XLY_DataType,id,name from searchrecords") +')');
            if(dataSearch!=""&&dataSearch!=null){
                var searchNode = new TreeNode();
                searchNode.Text = "搜索关键字";
                searchNode.Type = "SearchWord";
                for(var i in dataSearch){
                    var searchObj = new SearchWord();
                    searchObj.DataState = XLY.Convert.ToDataState(dataSearch[i].XLY_DataType);
                    searchObj.ID = dataSearch[i].id;
                    searchObj.SearchName = dataSearch[i].name;
                    searchNode.Items.push(searchObj);
                }
                if(searchNode.Items!=""&&searchNode.Items!= null){
                    root.TreeNodes.push(searchNode);
                }
            }
        }
    }
    var vpnPath1 = allPath+"\\vpn.db";
    if(XLY.File.IsValid(vpnPath1)){
        var vpnPath = XLY.Sqlite.DataRecovery(vpnPath1,charactor1,"contentdetail,feedback");
        if(XLY.File.IsValid(vpnPath)){
            var dataContent = eval('('+ XLY.Sqlite.Find(vpnPath,"select XLY_DataType,picurl,id,title,weburl,creationdate,type,playtimes,source from contentdetail where id>'800'") +')');
            if(dataContent!=""&&dataContent!=null){
                var contentNode = new TreeNode();
                contentNode.Text = "海外推荐";
                contentNode.Type = "OverseasRecommendation";
                for(var j in dataContent){
                    var contentObj = new OverseasRecommendation();
                    contentObj.DataState = XLY.Convert.ToDataState(dataContent[j].XLY_DataType);
                    contentObj.ID = dataContent[j].id;
                    contentObj.Title = dataContent[j].title;
                    
                    contentObj.CreateDate = dataContent[j].creationdate;
                    if(dataContent[j].type==1){
                        contentObj.TypeCotent = "视频";
                        contentObj.Url = dataContent[j].weburl;
                    }
                    else if(dataContent[j].type==2){
                        contentObj.TypeCotent = "图片";
                        contentObj.Url = dataContent[j].picurl;
                    }
                    else if(dataContent[j].type==3){
                        contentObj.TypeCotent = "文本";
                    }
                    else
                    {
                        contentObj.TypeCotent = "其他";
                    }
                    contentObj.PlayTimes = dataContent[j].playtimes;
                    contentObj.SourcePath = dataContent[j].source;
                    contentNode.Items.push(contentObj);
                }
                if(contentNode.Items!=""&&contentNode.Items!=null){
                    root.TreeNodes.push(contentNode);
                }
            }
            var facebookdata = eval('('+ XLY.Sqlite.Find(vpnPath,"select XLY_DataType,caseid,creationdate,title,unread from feedback") +')');
            if(facebookdata!=""&&facebookdata!=null){
                var faceNode = new TreeNode();
                faceNode.Text = "吐槽";
                faceNode.Type = "MakeComplaints";
                for(var z in facebookdata){
                    var objFace = new MakeComplaints();
                    objFace.DataState = XLY.Convert.ToDataState(facebookdata[z].XLY_DataType);
                    objFace.ID = facebookdata[z].caseid;
                    objFace.CreateDate = facebookdata[z].creationdate;
                    objFace.Title = facebookdata[z].title;
                    if(facebookdata[z].unread==0){
                        objFace.IsRead = "是";
                    }
                    faceNode.Items.push(objFace);
                    if(faceNode.Items!=""&&faceNode.Items!=null){
                        root.TreeNodes.push(faceNode);
                    }
                }
            }
        }
    }
}