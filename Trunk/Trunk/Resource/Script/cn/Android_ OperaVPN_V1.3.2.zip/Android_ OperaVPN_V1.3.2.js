﻿/*[config]
<plugin name="OperaVPN,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/operaVPN.png" app="com.opera.vpn" version="1.3.2" description="OperaVPN" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.opera.vpn/shared_prefs#F</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="最后一个用户id" code="LastSubscriberId" type="string" width = "100"></item>
    <item name="设备信息" code="DeviceInfo" type="string" width = "100"></item>
    <item name="是否连接服务器" code="IsConnect" type="string" width = "100"></item>
    <item name="是否首次登陆" code="IsFirstUser" type="string" width = "80"></item>
    <item name="服务器列表" code="ServeList" type="string" width = "80"></item>
    <item name="邮箱" code="Email" type="string" width = "80"></item>
    <item name="首次运行时间" code="FirstRun" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最近运行时间" code="LastDispatch" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.LastSubscriberId = "";
    this.DeviceInfo = "";
    this.IsConnect = "否";
    this.IsFirstUser = "否";
    this.ServeList = "";
    this.Email = "";
    this.FirstRun = null;
    this.LastDispatch = null;
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];

//测试数据
//var allPath = "D:\\temp\\data\\data\\com.opera.vpn\\shared_prefs";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "OperaVPN";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    var apconPath = allPath+"\\apconfig.xml";
    if(XLY.File.IsValid(apconPath)){
        var apconData = eval('('+ XLY.File.ReadXML(apconPath) +')');
        if(apconData!=""&&apconData!= null){
            var aapconData = apconData.map.string;
            if(aapconData["#text"]!=""&&aapconData["#text"]!=null){
                obj.LastSubscriberId = aapconData["#text"];
                usernode.Text = aapconData["#text"];
            }
        }
    }
    var prePath = allPath+"\\com.opera.vpn_preferences.xml";
    if(XLY.File.IsValid(prePath)){
        var preData = eval('('+ XLY.File.ReadXML(prePath) +')');
        if(preData!=""&&preData!=null){
            var aaPre = preData.map.boolean;
            if(aaPre!=""&&aaPre!=null){
                for(var a in aaPre){
                    if(aaPre[a]["@name"]=="connected"){
                        if(aaPre[a]["@value"]=="true"){
                            obj.IsConnect = "是";
                        }
                    }
                    if(aaPre[a]["@name"]=="is_first_time_user"){
                        if(aaPre[a]["@value"]=="true"){
                            obj.IsFirstUser = "是";
                        }
                    }
                }
            }
        }
    }
    var filename = eval('('+ XLY.File.FindFileNamesWithExtension(allPath) +')');
    var reg = new RegExp("com.mixpanel.android.mpmetrics");
    if(filename!=""&&filename!=null){
        for(var b in filename){
            if(reg.test(filename[b])){
                var mixpanelPath = allPath+"\\"+filename[b];
                if(XLY.File.IsValid(mixpanelPath)){
                    var mixData = eval('('+ XLY.File.ReadXML(mixpanelPath) +')');
                    if(mixData!=""&&mixData!=null){
                        var mmixData = mixData.map.string;
                        if(mmixData!=""&&mmixData!=null){
                            for(var c in mmixData){
                                if(mmixData[c]["@name"]=="events_distinct_id"){
                                    var ccccccc = mmixData[c]["#text"]+".xml";
                                    var emailPath = allPath+"\\"+ccccccc;
                                    if(XLY.File.IsValid(emailPath)){
                                        var emData = eval('('+ XLY.File.ReadXML(emailPath) +')');
                                        if(emData!=""&&emData!=null){
                                            var eemData = emData.map.string;
                                            if(eemData!=""&&eemData!=null){
                                                for(var d in eemData){
                                                    if(eemData[d]["@name"]=="email"){
                                                        obj.Email = eemData[d]["#text"];
                                                    }
                                                    if(eemData[d]["@name"]=="sec_instance"){
                                                        var efr = "";
                                                        var afe = eval('('+ eemData[d]["#text"] +')');
                                                        if(afe.mGeo!=""&&afe.mGeo!=null){
                                                            if(afe.mGeo.mGeos!=""&&afe.mGeo.mGeos!=null){
                                                                var fur = afe.mGeo.mGeos; 
                                                                for(var f in fur){
                                                                    efr += "国家："+fur[f].country+"\n"+"国家代码："+fur[f].country_code+";";
                                                                }
                                                                obj.ServeList = efr;
                                                            }
                                                        }
                                                        var vvv = afe.mCachedDiscovery.auto.mRegions;
                                                        ///&&^&&:D
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if(mmixData[c]["@name"]=="waiting_array"){
                                    var cc = eval('('+ mmixData[c]["#text"] +')');
                                    var ccc = cc[0]["$set"];
                                    obj.DeviceInfo = "设备系统版本："+ccc["$android_os_version"]+"\n"+"设备名称："+ccc["$android_brand"]+"("+ccc["$android_model"]+")";
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    var timePath = allPath+"\\com.google.android.gms.analytics.prefs.xml";
    if(XLY.File.IsValid(timePath)){
        var timeData = eval('('+ XLY.File.ReadXML(timePath) +')');
        if(timeData!=""&&timeData!=null){
            var ttPre = timeData.map.long;
            if(ttPre!=""&&ttPre!=null){
                for(var e in ttPre){
                    if(ttPre[e]["@name"]=="first_run"){
                        obj.FirstRun = XLY.Convert.LinuxToDateTime(ttPre[e]["@value"]);
                    }
                    if(ttPre[e]["@name"]=="last_dispatch"){
                        obj.LastDispatch = XLY.Convert.LinuxToDateTime(ttPre[e]["@value"]);
                    }
                }
            }
        }
    }
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    } 
}