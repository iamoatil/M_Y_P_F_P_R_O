﻿/*[config]
<plugin name="酷狗音乐,3" group="生活旅游,4" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/kugou.png" app="com.kugou.android" version="8.8.0" description="酷狗音乐" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.kugou.android/databases/kugou_music_phone_v7.db</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="Entry" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width="120" format=""></item>
    <item name="用户名" code="UserName" type="string" width="120" format=""></item>
    <item name="昵称" code="NickName" type="string" width="120" format=""></item>
    <item name="性别" code="Sex" type="string" width="120" format=""></item>
    <item name="出生年日" code="Birthday" type="string" width="120" format=""></item>
    <item name="电话号码" code="PhoneNumber" type="string" width="120" format=""></item>
    <item name="创建时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="LocalMusic" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="80" format=""></item>
    <item name="音乐名称" code="Name" type="string" width="120" format=""></item>
    <item name="文件Hash值" code="FileHash" type="string" width="120" format=""></item>
    <item name="文件大小" code="FileSize" type="string" width="80" format=""></item>
    <item name="文件扩展名" code="FileExtName" type="string" width="80" format=""></item>
    <item name="文件路径" code="FilePath" type="url" width="150" format = ""></item> 
    <item name="歌手" code="Singer" type="string" width="100" format=""></item>
    <item name="类型" code="MimeType" type="string" width="100" format=""></item>
    <item name="添加时间" code="AddTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后修改时间" code="LastModifyTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="文件数字名称" code="FileDigitName" type="string" width="100" format=""></item>
    <item name="音乐数字名称" code="SongDigitName" type="string" width="100" format=""></item>
    <item name="歌手数字名称" code="SingerDigitName" type="string" width="100" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义LocalMusic数据结构
function LocalMusic(){
    this.DataState = "Normal";
    this.Id = "";
    this.Name = "";
    this.FileHash = "";
    this.FileSize = "";
    this.FileExtName = "";
    this.FilePath = "";
    this.Singer = "";
    this.MimeType = "";
    this.AddTime = null;
    this.LastModifyTime = null;
    this.FileDigitName = "";
    this.SongDigitName = "";
    this.SingerDigitName = "";
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.Name = "";
    this.Guid = "";
    this.Email = "";
    this.IsRealName = "";
    this.CompanyName = "";
    this.ExpireTime = null;
    this.HeadUrl = "";
}
//定义List数据结构
function List(){
    this.DataState = "Normal";
    this.Entry = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.UserName = "";
    this.NickName = "";
    this.Sex = "";
    this.Birthday = "";
    this.PhoneNumber = "";
    this.Time = null;
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var kgSongPath1 = source[0];
//测试数据
//var kgSongPath1 = "D:\\temp2\\data\\data\\com.kugou.android\\databases\\kugou_music_phone_v7.db";
//var contactInfoPath = "D:\\temp\\data\\data\\com.yahoo.mobile.client.android.mail\\databases";
//var maillInfoPath1 = contactInfoPath+"\\mailsdk.db";
//定义特征库文件
var charactor = "\\chalib\\Android_KuGou_V8.8.0\\kugou_music_phone_v7.db.charactor";


//恢复数据库中删除的数据
var kgSongPath = XLY.Sqlite.DataRecovery(kgSongPath1,charactor,"file_holder,file");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "酷狗音乐";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(kgSongPath)){
        var data = eval('('+ XLY.Sqlite.Find(kgSongPath,"select fileid from file_holder where holdertype='16'") +')');
        if(data!=""&&data!= null){
            var node = new TreeNode();
            node.Text = "本地加载音乐";
            node.Type = "LocalMusic";
            for(var i in data){
                var userData = eval('('+ XLY.Sqlite.Find(kgSongPath,"select XLY_DataType,fileid,filehash,filesize,extname,filepath,musicname,singer,mimetype,file_digit_name,singer_digit_name,song_digit_name,addedtime,lastmotifytime from file where fileid = '"+data[i].fileid+"'") +')');
                if(userData!=""&&userData!= null){
                    var obj = new LocalMusic();
                    obj.DataState = XLY.Convert.ToDataState(userData[0].XLY_DataType);
                    obj.Id = userData[0].fileid;
                    obj.Name = userData[0].musicname;
                    obj.FileHash = userData[0].filehash;
                    obj.FileSize = userData[0].filesize + " B";
                    obj.FileExtName = userData[0].extname;
                    obj.FilePath = userData[0].filepath;
                    obj.Singer = userData[0].singer;
                    obj.MimeType = userData[0].mimetype;
                    obj.AddTime = XLY.Convert.LinuxToDateTime(userData[0].addedtime);
                    obj.LastModifyTime = XLY.Convert.LinuxToDateTime(userData[0].lastmotifytime);
                    obj.FileDigitName = userData[0].file_digit_name;
                    obj.SongDigitName = userData[0].singer_digit_name;
                    obj.SingerDigitName = userData[0].song_digit_name;
                    
                    node.Items.push(obj);
                }
            }
            if(node.Items!=""&&node.Items!=null){
                root.TreeNodes.push(node);
            }
        }
    }
}