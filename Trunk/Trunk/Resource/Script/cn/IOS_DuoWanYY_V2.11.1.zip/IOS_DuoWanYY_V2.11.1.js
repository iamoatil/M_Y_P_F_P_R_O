﻿/*[config]
<plugin name="YY语音,2" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\YY.png" app="yyvoice" version="2.11.1" description="YY语音" data="$data,ComplexTreeDataSource" >
<source>
<value>yyvoice</value>
</source>

<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="YY号" code="ID" type="string" width="120" format=""></item>
<item name="用户名称" code="Name" type="string" width="150" format=""></item>
<item name="昵称" code="NickName" type="string" width="120" format=""></item>
<item name="别名" code="PassPort" type="string" width="100" format=""></item>
<item name="签名" code="Signature" type="string" width="200" format=""></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="生日" code="Birthday" type="string" width="150" format=""></item>
<item name="最后登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" ></item>
<item name="自动登录状态" code="AntoLogin" type="string" width="150" format=""></item>
</data>

<data type="BuddyGroup" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="组名" code="Name" type="string" width="" format=""></item>
</data>

<data type="Friend" detailfield="HeadImage" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="int" width="140" ></item>
<item name="昵称" code="Name" type="string" width="150" format=""></item>
<item name="签名" code="Sign" type="string" width="150" format=""></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="头像地址" code="HeadImage" type="string" width="100" format=""></item>
<item name="最后登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="生日" code="Birthday" type="string" width="100" format=""></item>
</data>

<data type="Message" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送用户" code="SenderName" type="string" width="120" ></item>
<item name="接收用户" code="ReceiveName" type="string" width="120" ></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="时间" code="Date" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

<data type="Forum" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群组名称" code="Name" type="string" width="150" format=""></item>
<item name="群组ID" code="ForumID" type="int" width="140" ></item>
<item name="创建者ID" code="ParentID" type="string" width="150" format=""></item>
<item name="最后消息时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="群组图标地址" code="Logo " type="url" width="100" format=""></item>
</data>

<data type="Channel" detailfield="Icon" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="频道ID" code="ChannelID" type="int" width="140" ></item>
<item name="频道名称" code="ChannelName" type="string" width="200" format=""></item>
<item name="频道Logo" code="Icon" type="url" width="150" format=""></item>
<item name="我的身份" code="Role" type="string" width="100" format=""></item>
<item name="关注状态" code="Guild" type="string" width="100" format=""></item>
<item name="收藏状态" code="Favorite" type="string" width="100" format=""></item>
<item name="最近访问状态" code="Recent" type="string" width="100" format=""></item>
<item name="最后消息时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type="History" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="搜索关键字" code="Word" type="string" width="200" format=""></item>
<item name="时间" code="Date" type="datetime" width="300" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//*******************************************定义数据结构********************************************
//定义Account数据结构
function Account() {
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
    this.PassPort = "";
    this.Time = null;
    this.Gender = "";
    this.AntoLogin = "";
    this.NickName="";
    this.Signature="";
    this.Birthday="";
}

//定义BuddyGroup数据结构
function BuddyGroup() {
    this.DataState = "Normal";
    this.Name = "";
}

//定义User数据结构
function Friend() {
    this.DataState = "Normal";
    this.Name = "";
    this.Time = null;
    this.Sign = "";
    this.ID = 0;
    this.Gender = "";
    this.HeadImage = "";
    this.Birthday = "";
}

//定义Message数据结构
function Message() {
    this.SenderName = "";
    this.ReceiveName = "";
    this.SenderImage = "";
    this.Content = "";
    this.Type = "";
    this.Date = null;
    this.SendState = "";
    this.DataState = "Normal";
}

//定义Forum数据结构
function Forum() {
    this.Name = "";
    this.ForumID = "";
    this.ParentID = "";
    this.Logo = "";
    this.Time = null;
    this.DataState = "Normal";
}

//定义Channel数据结构
function Channel() {
    this.DataState = "Normal";
    this.ChannelID = "";
    this.ChannelName = "";
    this.Icon = "";
    this.Role = "";
    this.Guild = "";
    this.Favorite = "";
    this.Recent = "";
    this.Time = null;
}

//定义History数据结构
function History() {
    this.DataState = "Normal";
    this.Word = "";
    this.Date = null;
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//******************************************* 处理APP数据*******************************************
var result = new Array();
//源文件
var source = $source;
var path = source[0] + "\\yyvoice\\Library\\Caches";
//var path = "E:\\app_data\\IOS\\yyvoice\\Library\\Caches";

//定义特征库
var charactor1 = "chalib\\IOS_DuoWanYY_V2.11.1\\public.db.charactor";
var charactor2 = "chalib\\IOS_DuoWanYY_V2.11.1\\dymatic.db.charactor";
var charactor3 = "chalib\\IOS_DuoWanYY_V2.11.1\\dymatic_Others.db.charactor";

//创建账号树结构
var usersInfos = getAccount(path+"\\dbs");
for (var index in usersInfos) {
    var account = new TreeNode();
    var userPath = path + "\\dbs\\public.db";
    var recoveryUserPath = XLY.Sqlite.DataRecovery(userPath, charactor1, "Accounts");
    var userData = eval('(' + XLY.Sqlite.Find(userPath, "select * ,cast(last_login_time as text )as login from Accounts where uid='" + usersInfos[index].uid + "'") + ')');
    if (userData.length != 0) {
        account.Type = "Account";
        var accinfo = getAccountInfo(userData, usersInfos[index]);
        account.Text = accinfo.NickName;
        account.Items.push(accinfo);
        buildChildNodeForAccount(account,accinfo,path)
        result.push(account);
    }
}

var res = JSON.stringify(result);
res;

//************************************定义处理APP数据的方法*****************************************
//获取登录过的账号
function getAccount(path) {
    var filepath = eval('(' + XLY.File.FindFiles(path) + ')');
    var info = new Array();
    for (var index in filepath) {
        var filename = XLY.File.GetFileName(filepath[index]);
        if ((/\d+.db$/i).test(filename)) {
            var acc = filename.substring(0, filename.indexOf("."));
            var userData = eval('(' + XLY.Sqlite.Find(filepath[index], "select * ,cast(birthday as text )as birthday from Users where uid='" + acc + "'") + ')');
            info.push(userData[0])
        }
    }
    return info;
}

//获取账号的详细信息
function getAccountInfo(info,user) {
    var obj = new Account;
    obj.ID = info[0].uid;
    obj.Name = info[0].username;
    obj.PassPort = info[0].passport;
    obj.Gender = (info[0].gender == 1) ? "男" : "女";
    obj.Time = XLY.Convert.LinuxToDateTime(parseInt(info[0].login));
    obj.AntoLogin = (info[0].auto_login == 1) ? "该帐号为自动登录" : "";
    obj.DataState = XLY.Convert.ToDataState(info[0].XLY_DataType);
    obj.Birthday = XLY.Convert.LinuxToDateTime(parseInt(user.birthday));
    obj.NickName = user.nickname;
    obj.Signature = user.signature;
    return obj;
}

//创建帐号子节点树
function buildChildNodeForAccount(tree,user,path) {
    //创建账号好友子节点
    var buddyGroup = new TreeNode();
    buddyGroup.Text = "好友分组"
    buddyGroup.Type = "BuddyGroup";
    var buddyGroupPath = path + "\\dbs\\" + user.ID + ".db";
    var recoveryBuddyGroupPath = XLY.Sqlite.DataRecovery(buddyGroupPath, charactor2, "Buddies,BuddyGroups,ImMessages,ImMsgAttachments,QunInfos,QunMessages,QunMsgAttachments,UserPortraits,Users");
    var buddyGroupData = eval('(' + XLY.Sqlite.FindByName(recoveryBuddyGroupPath, "BuddyGroups") + ')');
    for (var index in buddyGroupData) {
        var obj = new BuddyGroup();
        obj.Name = buddyGroupData[index].name;
        obj.DataState = XLY.Convert.ToDataState(buddyGroupData[index].XLY_DataType);
        buddyGroup.Items.push(obj);

        //创建好友分组的各节点
        var friendGroup = new TreeNode();
        friendGroup.Text = buddyGroupData[index].name;
        friendGroup.Type = "Friend";
        var friendGroupInfo = getUserInfo(recoveryBuddyGroupPath, buddyGroupData[index].gid);
        friendGroup.Items = friendGroupInfo;
        buddyGroup.TreeNodes.push(friendGroup);

        //创建好友聊天信息节点
        for (var num in friendGroupInfo) {
            var friendMessage = new TreeNode();
            friendMessage.Text = friendGroupInfo[num].Name;
            friendMessage.Type = "Message";
            friendMessage.Items = getFriendMessageInfo(recoveryBuddyGroupPath, user, friendGroupInfo[num],path);
            friendGroup.TreeNodes.push(friendMessage);
        }
    }

    //创建账号群组子节点
    var forum = new TreeNode();
    forum.Text = "群组";
    forum.Type = "Forum";
    var forumInfo = getForumInfo(recoveryBuddyGroupPath);
    forum.Items = forumInfo;
    for (var number in forumInfo) {
        var forumMessage = new TreeNode();
        forumMessage.Text = forumInfo[number].Name;
        forumMessage.Type = "Message";
        forumMessage.Items = getForumMessageInfo(recoveryBuddyGroupPath,forumInfo[number]);
        forum.TreeNodes.push(forumMessage);
    }

    //创建我的频道子节点
    var channelPath = path + "\\dbs\\" + user.ID + "_Others.db";
    var recoveryChannelPath = XLY.Sqlite.DataRecovery(channelPath, charactor3, "channel_info,channel_search_keywords");
    var channel = new TreeNode();
    channel.Text = "我的频道";
    channel.Type = "Channel";
    channel.Items = getChannelInfo(recoveryChannelPath);

    //创建历史搜索关键字子节点
    var history = new TreeNode();
    history.Text = "历史搜索";
    history.Type = "History";
    history.Items = getHistoryInfo(recoveryChannelPath);

    //获取根节点的各子节点
    tree.TreeNodes.push(buddyGroup);
    tree.TreeNodes.push(forum);
    tree.TreeNodes.push(channel);
    tree.TreeNodes.push(history);
}

//获取好友信息
function getUserInfo(path,id) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from Buddies where group_id='" + id + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var userData = eval('(' + XLY.Sqlite.Find(path, "select * from Users where uid='" + data[index].uid + "'") + ')');
        for (var num in userData) {
            var obj = new Friend();
            obj.Name = userData[num].nickname;
            obj.ID = userData[num].uid;
            obj.Time = XLY.Convert.LinuxToDateTime(userData[num].timestamp);
            obj.Gender = (userData[num].gender == 1) ? "男" : "女";
            var headimage = eval('(' + XLY.Sqlite.Find(path, "select * from UserPortraits where uid='" + userData[num].uid + "' AND portrait_type=0 ") + ')');
            if (headimage.length != 0) {
                obj.HeadImage = headimage[0].portrait;
            }
            obj.Sign = userData[num].signature;
            if (userData[num].birthday != null) {
                obj.Birthday = XLY.Convert.ToDateTime(userData[num].birthday, "yyyyMMdd");
            }
            obj.DataState = XLY.Convert.ToDataState(userData[num].XLY_DataType);
            info.push(obj);
        }
    }
    return info;
}

//获取好友聊天信息
function getFriendMessageInfo(path, acc, friend,filepath) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select *,cast(send_time as text)as send_time,cast(recv_time as text)as recv_time  from ImMessages where peer_id='" + friend.ID + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        if (data[index].msg_state == 203) {
            obj.SenderName = acc.NickName;
            obj.ReceiveName = friend.Name;
        } else {
            obj.SenderName = friend.Name;
            obj.ReceiveName = acc.NickName;
            obj.SenderImage = friend.HeadImage;
        }
        obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data[index].send_time));
        obj.Content = data[index].msg_text;
        obj.SendState = (data[index].msg_state == 203) ? "Send" : "Receive";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        switch (data[index].msg_sub_type) {
            case 101: obj.Type = "Image"; var imagepath = eval('(' + XLY.Sqlite.Find(path, "select * from ImMsgAttachments where msg_id='" + data[index].msg_id + "'") + ')'); obj.Content = filepath + "\\attachments\\" + imagepath[0].local_file.substring(imagepath[0].local_file.lastIndexOf("/")+1); break;
            case 102: obj.Type = "Audio"; var audiopath = eval('(' + XLY.Sqlite.Find(path, "select * from ImMsgAttachments where msg_id='" + data[index].msg_id + "'") + ')'); obj.Content = filepath + "\\attachments\\" + audiopath[0].local_file.substring(audiopath[0].local_file.lastIndexOf("/") + 1); break;
        }
        info.push(obj);
    }
    return info;
}

//获取群组信息
function getForumInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select *,cast(last_msg_time as text)as last_msg_time from QunInfos") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Forum();
        obj.Name = data[index].name;
        obj.ForumID = data[index].qun_id;
        obj.ParentID = data[index].parent_id;
        obj.Logo = data[index].icon_url;
        obj.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].last_msg_time));
        info.push(obj);
    }
    return info;
}
 
//获取群组聊天消息
function getForumMessageInfo(path,forum) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select *,cast(send_time as text)as send_time from QunMessages where qun_id='" + forum.ForumID + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        obj.SenderName = data[index].sender_name + "(" + data[index].sender_uid + ")";
        obj.ReceiveName = forum.Name + "(" + forum.ForumID + ")";
        obj.Content = data[index].msg_text;
        obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data[index].send_time));
        obj.SendState = (data[index].state == 201) ? "Send" : "Receive";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

function getChannelInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from channel_info ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Channel();
        obj.ChannelID = data[index].sid;
        obj.ChannelName = data[index].desc;
        obj.Icon = data[index].iconurl;
        switch (data[index].role) {
            case 255: obj.Role = "频道创建者"; break;
            case 200: obj.Role = "全频管理员"; break;
            case 150: obj.Role = "子频道管理员"; break;
            case 100: obj.Role = "会员"; break;
            case 88: obj.Role = "嘉宾"; break;
            case 0: obj.Role = "游客"; break;
            default: obj.Role = "游客"; break;
        }
        obj.Favorite = (data[index].is_favorite == 1) ? "已收藏" : "";
        obj.Guild = (data[index].is_guild == 1) ? "已关注" : "";
        obj.Recent = (data[index].is_recent == 1) ? "最近访问" : "";
        obj.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].updateTime));
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取历史搜索信息
function getHistoryInfo(path) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from channel_search_keywords ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new History();
        obj.Word = data[index].keywords;
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].updateTime);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}
