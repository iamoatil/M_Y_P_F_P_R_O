﻿/*[config]
<plugin name="QQ邮箱,4" group="主流邮箱,4" devicetype="ios" pump="usb,wifi,mirror,bluetooth,LocalData" icon="\icons\QQMail.png" app="com.tencent.qqmail" version="2.2" description="QQ邮箱" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tencent.qqmail</value>
</source>
<data  type="Account" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="登录帐号" code="Account" type="string" width="150" ></item>
<item name="昵称" code="Nick" type="string" width="150" ></item>
<item name="创建时间" code="Time" type="datetime" width="400" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data detailfield="Content" type="Mail" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发件人" code="Sender" type="string" width="270" ></item>
<item name="收件人" code="Receiver" type="string" width="270" ></item>
<item name="接收时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="主题" code="Subject" type="string" width="300" ></item>
<item name="内容摘要" code="Abstract" type="string" width="300" ></item>
<item name="内容详细信息" code="Content" type="string" width="300" ></item>
<item name="附件信息" code="Attach" type="string" width="300" ></item>
<item name="阅读状态" code="Status" type="string" width="100" ></item>
<item name="是否为星标邮件" code="Star" type="string" width="100" ></item>
</data>
</plugin>
[config]*/

//*****************************************************定义数据结构*********************************************************
function Account() {
    this.Account = "";
    this.Nick = "";
    this.Time = "";
    this.DataState = "Normal";
}

function Mail() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Subject = "";
    this.Abstract = "";
    this.Content = "";
    this.Attach = "";
    this.Status = "";
    this.Star = "";
    this.DataState = "Normal";
}

function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//*****************************************************定义处理数据的方法*********************************************************
//获取邮箱帐户信息
function getAccount(data){
    var obj=new Account();
    obj.Account = data.name;
    obj.Nick = data.alias;
    obj.Time = XLY.Convert.LinuxToDateTime(parseInt(data.time));
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return obj;
}

//获取帐号子节点的邮件信息
function getMail(path, accinfo, folderid) {
    var sql = "select * from(select e.*,a.[name] as name,a.[size] as attsize,a.[downloadUtc] as atttime from (select m.[accountId],m.[folderId],m.[mailId],m.[subject],m.[abstract],m.[fromEmail],m.[fromNick],m.[tos],m.[ccs],m.[size],m.[isStar],m.[receivedUtc],c.[content] from FM_MailInfo m left join FM_Mail_Content c on c.[mailId]=m.[mailId]) as e left join FM_Mail_Attach a on a.[mailId]=e.[mailId]) where accountId='" + accinfo.id + "' AND folderId='" + folderid + "'"
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr=new Array();
    for (var index in data) {
        var obj = new Mail();
        obj.Sender = "\"" + data[index].fromNick + "\"<" + data[index].fromEmail + ">";
        if (data[index].tos == "") {
            obj.Receiver = accinfo.name;
        }else if (data[index].ccs == "") {
            obj.Receiver = data[index].tos;
        } else {
            obj.Receiver = data[index].tos +"\n"+ "抄送：" + data[index].ccs;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[index].receivedUtc);
        obj.Subject = data[index].subject;
        if (data[index].size != 0) {
            obj.Abstract = "邮件大小(B)" + data[index].size + "；摘要：" + data[index].abstract;
        } else {
            obj.Abstract = data[index].abstract;
        }
        if (data[index].content != null) {
            obj.Content = data[index].content;
        } else {
            obj.Content = "发件人：" + obj.Sender + "；收件人：" + obj.Receiver + "\n邮件发送时间：" + obj.Time + "\n内容概要:" + obj.Abstract;
        }
        if (data[index].name != null) {
            obj.Attach = "附件名称：" + data[index].name + "；附件大小(B)：" + data[index].attsize + "；附件下载时间：" + XLY.Convert.LinuxToDateTime(parseInt(data[index].atttime));
        }
        obj.Status = (data[index].isRead == 1) ? "已读" : "未读";
        obj.Star = (data[index].isStar == 1) ? "星标邮件" : "";
        obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
        arr.push(obj);
    }
    return arr;
}

//*****************************************************处理APP数据*********************************************************
var result = new Array();
var source = $source;
var path = source[0] + "\\com.tencent.qqmail\\\\Documents\\FMailDB.db"
//var path = "E:\\app_data\\IOS\\QQ邮箱v3.0.1\\Documents\\FMailDB.db";

//定义特征库
var charactor = "chalib\\IOS_QQMail_V3.0.1\\FMailDB.db.charactor";
var recoveryPath = XLY.Sqlite.DataRecovery(path, charactor, "FM_Account,FM_Folder,FM_Mail_Attach,FM_Mail_Content,FM_MailInfo");

//创建帐号树节点，并获取其子节点信息
var accsql = "select id,name,alias,syncUtc as time,XLY_DataType from FM_Account";
var data = eval('(' + XLY.Sqlite.Find(recoveryPath, accsql) + ')');
for (var index in data) {
    var account = new TreeNode();
    var accinfo = getAccount(data[index]);
    account.Text = accinfo.Account;
    account.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    account.Type = "Account";
    account.Items.push(accinfo);
    var acc_child_info = eval('(' + XLY.Sqlite.Find(recoveryPath, "select id,showName as name,XLY_DataType from FM_Folder where accountId='" + data[index].id + "'") + ')');
    for (var child in acc_child_info) {
        var acc_children = new TreeNode();
        acc_children.Text = acc_child_info[child].name;
        acc_children.DataState = XLY.Convert.ToDataState(acc_child_info[child].XLY_DataType);
        acc_children.Type = "Mail";
        var childinfo = getMail(recoveryPath, data[index], acc_child_info[child].id);
        acc_children.Items = childinfo;
        account.TreeNodes.push(acc_children);
    }
    result.push(account);
}

// return结果
var res = JSON.stringify(result);
res;
