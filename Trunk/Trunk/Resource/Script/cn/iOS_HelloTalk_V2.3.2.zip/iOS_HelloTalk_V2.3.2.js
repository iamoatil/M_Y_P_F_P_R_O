﻿/*[config]
<plugin name="HelloTalk,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/hellotalk.png" app="com.helloTalk.helloTalk" version="2.3.2" description="HelloTalk" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.helloTalk.helloTalk</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="UserAccount" type="string" width="120" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="用户名" code="UserName" type="string" width="150" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="string" width="120" format = "" ></item>
    <item name="出生年月" code="Birthday" type="string" width="120" format = "" ></item>
    <item name="文字签名" code="WordSign" type="string" width="120" format = "" ></item>
    <item name="声音签名" code="SoundSign" type="string" width="120" format = "" ></item>
    <item name="所在地" code="Address" type="string" width="120" format = "" ></item>
    <item name="地区" code="AddressCode" type="string" width="120" format = "" ></item>
    <item name="经度" code="Lng" type="string" width="120" format = "" ></item>
    <item name="纬度" code="Lat" type="string" width="120" format = "" ></item>
    <item name="邮箱" code="Email" type="string" width="120" format = "" ></item>
    <item name="时间" code="DynamicTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="GroupMember" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width="120" format=""></item>
    <item name="用户名" code="UserName" type="string" width="120" format=""></item>
    <item name="组内名称" code="UserGroupName" type="string" width="120" format=""></item>
</data>
<data type="Dynamic" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="评论人ID" code="UserID" type="string" width="200" format = "" ></item>
    <item name="评论人昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="类型" code="DynamicType" type="string" width="200" format=""></item>
    <item name="评论ID" code="DynamicID" type="string" width="200" format=""></item>
    <item name="评论内容" code="DynamicContent" type="string" width="200" format=""></item>
    <item name="时间" code="DynamicTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format=""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="接收者ID" code="ReciveID" type="string" width="120" format=""></item>
    <item name="接收者姓名" code="ReciveName" type="string" width="120" format=""></item>
    <item name="发送时间" code="StartTime" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="100" format = ""></item>
    <item name="补充" code="TargetContent" type="string" width="100" format=""></item>
    <item name="类型" code="ContentType" type="string" width="100" format = ""></item>
    <item name="语言" code="SourceLanguage" type="string" width="100" format=""></item>
    <item name="附件名称" code="AttachmentName" type="string" width="100" format=""></item>
    <item name="附件信息" code="AttachmentMsg" type="string" width="100" format=""></item>
    <item name="附件路径" code="AttachmentPath" type="url" width="100" format=""></item>
    <item name="已读" code="IsRead" type="string" width="100" format=""></item>
</data>
<data type="MessageGroup" contract="DataState" datefilter="Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format=""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="接收者ID" code="ReciveID" type="string" width="120" format=""></item>
    <item name="接收者姓名" code="ReciveName" type="string" width="120" format=""></item>
    <item name="发送时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="内容" code="Content" type="string" width="100" format = ""></item>
    <item name="类型" code="ContentType" type="string" width="100" format=""></item>
    <item name="等级" code="Rank" type="string" width="100" format=""></item>
</data>
<data type="GroupInfo" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群ID" code="GroupID" type="string" width="120" format=""></item>
    <item name="群名称" code="GroupName" type="string" width="120" format=""></item>
    <item name="群人数上限" code="GroupLimit" type="string" width="120" format=""></item>
    <item name="群头像" code="GroupHeadUrl" type="url" width="120" format=""></item>
    <item name="群主ID" code="GroupOwnerID" type="string" width="120" format=""></item>
    <item name="群主姓名" code="GroupOwner" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreateTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="NotePad" contract="DataState" datefilter="GroupMember">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="FavoriteID" type="string" width="120" format=""></item>
    <item name="发送者ID" code="UserID" type="string" width="120" format = ""></item>
    <item name="发送者姓名" code="UserName" type="string" width="120" format=""></item>
    <item name="接收者ID" code="ReceiveID" type="string" width="120" format = ""></item>
    <item name="接收者姓名" code="ReceiveName" type="string" width="120" format=""></item>
    <item name="语言" code="SourceLanguage" type="string" width="120" format=""></item>
    <item name="内容" code="SourceText" type="string" width="120" format=""></item>
    <item name="补充" code="TargetText" type="string" width="120" format=""></item>
    <item name="类型" code="ContentType" type="string" width="120" format=""></item>
    <item name="附件名" code="FileName" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreateTime" type="string" width="180" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function NotePad(){
    this.DataState = "Normal";
    this.FavoriteID = "";
    this.SourceLanguage = "";
    this.SourceText = "";
    this.TargetText = "";
    this.UserID = "";
    this.UserName = "";
    this.ReceiveID = "";
    this.ReceiveName = "";
    this.FileName = "";
    this.CreateTime = "";
    this.ContentType = "";
}
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupID = "";
    this.GroupName = "";
    this.GroupLimit = "";
    this.GroupHeadUrl = "";
    this.GroupOwnerID = "";
    this.GroupOwner = "";
    this.CreateTime = null;
}
function Dynamic(){
    this.DataState = "Normal";
    this.UserID = "";
    this.UserNickName = "";
    this.DynamicType = "";
    this.DynamicID = "";
    this.DynamicContent = "";
    this.DynamicTime = null;
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserAccount = "";
    this.NickName = "";
    this.DynamicTime = "";
    this.UserName = "";
    this.Sex = "";
    this.HeadUrl = "";
    this.Birthday = "";
    this.Address = "";
    this.AddressCode = "";
    this.WordSign = "";
    this.SoundSign = "";
    this.Lng = "";
    this.Lat = "";
    this.Email = "";
}
//定义Contact数据结构
function GroupMember(){
    this.DataState = "Normal";
    this.UserName = "";
    this.UserId = "";
    this.UserGroupName = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReciveID = "";
    this.ReciveName = "";
    this.StartTime = "";
    this.Content = "";
    this.ContentType = "";
    this.TargetContent = "";
    this.SourceLanguage = "";
    this.AttachmentName = "";
    this.AttachmentPath = "";
    this.AttachmentMsg = "";
    this.IsRead = "";
}
//定义MessageGroup数据结构
function MessageGroup(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReciveID = "";
    this.ReciveName = "";
    this.StartTime = null;
    this.Content = "";
    this.ContentType = "";
    this.Rank = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.helloTalk.helloTalk\\Documents";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-05-12-15-50-28\\source\\IosData\\2017-05-12-15-50-53\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.helloTalk.helloTalk\\Documents";
//定义特征库文件
var charactor = "\\chalib\\iOS_HelloTalk_2.3.2\\HelloTalk.sqlite.charactor";
//var charactor2 = "\\chalib\\iOS_Momo_V7.6.0\\u.474432438.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "HelloTalk";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var aa = eval('('+ XLY.File.FindDirectories(allPath) +')');
    if(aa!=""&&aa!=null){
        for(var i in aa){
            if(/^\d+$/.test(aa[i].substr(allPath.length+1,aa[i].length-1)))
            {
                var uid = aa[i].substr(allPath.length+1,aa[i].length-1);
                var path1 = aa[i]+"\\HelloTalk.sqlite";
                var path = XLY.Sqlite.DataRecovery(path1,charactor,"HTUSERBASE,HTUSERLOCATION,HTROOM,HTFOLLOWIDS,HTFOLLOWERIDS,HTMOMENTCOMMENTS,HTTRANSLATEFAVORITE,HTMESSAGES,HTROOMMEMBER");
                if(XLY.File.IsValid(path)){
                    var data = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID,USERNAME,NICKNAME,SEX,BIRTHDAY,HEADURL,SIGNATURE,VOICEURL,USERINFOTIMESTAMP,NATIONALITY from HTUSERBASE where USERID = '"+uid+"'") +')');
                    var dataLocation = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,LATITUDE,COUNTRY,CITY,LONGITUDE from HTUSERLOCATION where USERID = '"+uid+"'") +')');
                    if(data!=""&&data!= null){
                        var nodeUser = new TreeNode();
                        nodeUser.Text = uid+"_"+data[0].NICKNAME;
                        nodeUser.Type = "UserInfo";
                        var obj = new UserInfo();
                        obj.DataState = XLY.Convert.ToDataState(data[0].XLY_DataType);
                        obj.UserAccount = data[0].USERID;
                        obj.NickName = data[0].NICKNAME;
                        obj.DynamicTime = XLY.Convert.LinuxToDateTime(data[0].USERINFOTIMESTAMP);
                        obj.UserName = data[0].USERNAME;
                        if(data[0].SEX==0){
                            obj.Sex = "女";
                        }
                        else if(data[0].SEX==1){
                            obj.Sex = "男";
                        }
                        else
                        {
                            obj.Sex = "未指定";
                        }
                        obj.HeadUrl = data[0].HEADURL;
                        obj.Birthday = data[0].BIRTHDAY;
                        if(dataLocation!=""&&dataLocation!=null){
                            obj.Address = dataLocation[0].CITY+" "+dataLocation[0].COUNTRY;
                            obj.Lng = dataLocation[0].LONGITUDE;
                            obj.Lat = dataLocation[0].LATITUDE;
                        }
                        obj.AddressCode = data[0].NATIONALITY;
                        obj.WordSign = data[0].SIGNATURE;
                        obj.SoundSign = data[0].VOICEURL;
                        obj.Email = "";
                        nodeUser.Items.push(obj);
                        getUserChildNode(nodeUser,path,obj.UserAccount,obj.NickName);
                        root.TreeNodes.push(nodeUser);
                    }       
                }
            }
        }
    }
}
function getUserChildNode(root,path,uid,uname){
    var aPath = path.substr(0,path.length-16)+"images\\";
    var dataFriend = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID from HTUSERFRIENDS") +')');
    var dataGroupForm = eval('('+ XLY.Sqlite.Find(path,"select * from HTROOM") +')');
    var dataFollow = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID from HTFOLLOWIDS") +')');
    var dataFollowing = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID from HTFOLLOWERIDS") +')');
    var dataComment = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID,MOMENTID,CTYPE,CONTENT,TIME from HTMOMENTCOMMENTS") +')');
    var dataNotePad = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,FAVORITEID,SOURCETEXT,SOURCELANGUAGE,TARGETTEXT,FAVORITETYPE,FILENAME,USERID,TOID,TIME,FAVORITEOOB from HTTRANSLATEFAVORITE") +')');
    var dataMessage = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,ID from HTMESSAGES") +')');
    var friendParent = new TreeNode();
    friendParent.Text = "好友列表";
    root.TreeNodes.push(friendParent);
    if(dataFriend!=""&&dataFriend!=null){
        var node = new TreeNode();
        node.Text = "好友";
        node.Type = "UserInfo";
        getMyFriend(node,dataFriend,path);
        friendParent.TreeNodes.push(node);
    }
    if(dataFollow!=""&&dataFollow!=null){
        var node = new TreeNode();
        node.Text = "关注";
        node.Type = "UserInfo";
        getMyFollow(node,dataFollow,path);
        friendParent.TreeNodes.push(node);
    }
    if(dataFollowing!=""&&dataFollowing!=null){
        var node = new TreeNode();
        node.Text = "粉丝";
        node.Type = "UserInfo";
        getMyFollow(node,dataFollowing,path);
        friendParent.TreeNodes.push(node);
    }
    if(dataComment!=""&&dataComment!=null){
        var node = new TreeNode();
        node.Text = "评论";
        node.Type = "Dynamic";
        getMyComment(node,dataComment,path);
        root.TreeNodes.push(node);
    }
    if(dataNotePad!=""&&dataNotePad!=null){
        var node = new TreeNode();
        node.Text = "记事本";
        node.Type = "NotePad";
        getMyNotePad(node,dataNotePad,path);
        root.TreeNodes.push(node);
    }
    if(dataGroupForm!=""&&dataGroupForm!=null){
        var node = new TreeNode();
        node.Text = "群组信息";
        node.Type = "GroupInfo";
        getMyGroup(node,dataGroupForm,path);
        root.TreeNodes.push(node);
    }
    if(dataMessage!=""&&dataMessage!=null){
        var node = new TreeNode();
        node.Text = "聊天记录";
        node.Type = "";
        getMyMessage(node,path,uid,uname,aPath);
        root.TreeNodes.push(node);
    }
}
function getMyFriend(root,data,path){
    for(var i in data){
        var info = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID,USERNAME,NICKNAME,SEX,BIRTHDAY,HEADURL,SIGNATURE,VOICEURL,USERINFOTIMESTAMP,NATIONALITY from HTUSERBASE where USERID = '"+data[i].USERID+"'") +')');
        var infoLocation = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,LATITUDE,COUNTRY,CITY,LONGITUDE from HTUSERLOCATION where USERID = '"+data[i].USERID+"'") +')');
        if(info!=""&&info!=null){
            var obj = new UserInfo();
            obj.DataState = XLY.Convert.ToDataState(info[0].XLY_DataType);
            obj.UserAccount = info[0].USERID;
            obj.NickName = info[0].NICKNAME;
            obj.DynamicTime = XLY.Convert.LinuxToDateTime(info[0].USERINFOTIMESTAMP);
            obj.UserName = info[0].USERNAME;
            if(info[0].SEX==0){
                obj.Sex = "女";
            }
            else if(info[0].SEX==1){
                obj.Sex = "男";
            }
            else
            {
                obj.Sex = "未指定";
            }
            obj.HeadUrl = info[0].HEADURL;
            obj.Birthday = info[0].BIRTHDAY;
            if(infoLocation!=""&&infoLocation!=null){
                obj.Address = infoLocation[0].CITY+" "+infoLocation[0].COUNTRY;
                obj.Lng = infoLocation[0].LONGITUDE;
                obj.Lat = infoLocation[0].LATITUDE;
            }
            obj.AddressCode = info[0].NATIONALITY;
            obj.WordSign = info[0].SIGNATURE;
            obj.SoundSign = info[0].VOICEURL;
            obj.Email = "";
            root.Items.push(obj);
        }
    }
}
function getMyGroup(root,data,path){
    for(var i in data){
        var obj = new GroupInfo();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.GroupID = data[i].ROOMID;
        obj.GroupName = data[i].ROOMNAME;
        obj.GroupLimit = data[i].ROOMLIMIT;
        obj.GroupHeadUrl = path.substr(0,path.length-16)+"images\\group\\"+data[i].HEADPATH;
        obj.GroupOwnerID = data[i].CREATERID;
        var info = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].CREATERID+"'") +')');
        if(info!=""&&info!=null){
            obj.GroupOwner = info[0].NICKNAME;
        }
        else
        {
            var info1 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTMOMENTSUSERS where USERID = '"+data[i].CREATERID+"'") +')');
            if(info1!=""&&info1!=null){
                obj.GroupOwner = info1[0].NICKNAME;
            }
        }
        
        obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].ROOMTIMESTAMP);
        root.Items.push(obj);
        var node = new TreeNode();
        node.Text = obj.GroupID+"_"+obj.GroupName;
        node.Type = "GroupMember";
        var groupMemberId = eval('('+ XLY.Sqlite.Find(path,"select USERID from HTROOMMEMBER where ROOMID = '"+obj.GroupID+"'") +')');
        if(groupMemberId!=""&&groupMemberId!=null){
            for(var j in groupMemberId){
                var info3 = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,NICKNAME,FULLPY,USERID from HTUSERBASE where USERID = '"+groupMemberId[j].USERID+"'") +')');
                if(info3!=""&&info3!= null){
                    var objMem = new GroupMember();
                    objMem.DataState = XLY.Convert.ToDataState(info3[0].XLY_DataType);
                    objMem.UserName = info3[0].NICKNAME;
                    objMem.UserId = info3[0].USERID;
                    objMem.UserGroupName = info3[0].FULLPY;
                    node.Items.push(objMem);
                }
            }
        }
        root.TreeNodes.push(node);
    }
}
function getMyFollow(root,data,path){
    for(var i in data){
        var info = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID,USERNAME,NICKNAME,SEX,BIRTHDAY,HEADURL,SIGNATURE,VOICEURL,USERINFOTIMESTAMP,NATIONALITY from HTUSERBASE where USERID = '"+data[i].USERID+"'") +')');
        var infoLocation = eval('('+ XLY.Sqlite.Find(path,"select LATITUDE,COUNTRY,CITY,LONGITUDE from HTUSERLOCATION where USERID = '"+data[i].USERID+"'") +')');
        if(info!=""&&info!=null){
            var obj = new UserInfo();
            obj.DataState = XLY.Convert.ToDataState(info[0].XLY_DataType);
            obj.UserAccount = info[0].USERID;
            obj.NickName = info[0].NICKNAME;
            obj.DynamicTime = XLY.Convert.LinuxToDateTime(info[0].USERINFOTIMESTAMP);
            obj.UserName = info[0].USERNAME;
            if(info[0].SEX==0){
                obj.Sex = "女";
            }
            else if(info[0].SEX==1){
                obj.Sex = "男";
            }
            else
            {
                obj.Sex = "未指定";
            }
            obj.HeadUrl = info[0].HEADURL;
            obj.Birthday = info[0].BIRTHDAY;
            if(infoLocation!=""&&infoLocation!=null){
                obj.Address = infoLocation[0].CITY+" "+infoLocation[0].COUNTRY;
                obj.Lng = infoLocation[0].LONGITUDE;
                obj.Lat = infoLocation[0].LATITUDE;
            }
            obj.AddressCode = info[0].NATIONALITY;
            obj.WordSign = info[0].SIGNATURE;
            obj.SoundSign = info[0].VOICEURL;
            obj.Email = "";
            root.Items.push(obj);
        }
        else
        {
            var info1 = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,USERID,USERNAME,NICKNAME,SEX,BIRTHDAY,HEADURL,SIGNATURE,VOICEURL,USERINFOTIMESTAMP,NATIONALITY,LATITUDE,COUNTRY,CITY,LONGITUDE from HTMOMENTSUSERS where USERID = '"+data[i].USERID+"'") +')');
            if(info1!=""&&info1!=null){
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(info1[0].XLY_DataType);
                obj.UserAccount = info1[0].USERID;
                obj.NickName = info1[0].NICKNAME;
                obj.DynamicTime = XLY.Convert.LinuxToDateTime(info1[0].USERINFOTIMESTAMP);
                obj.UserName = info1[0].USERNAME;
                if(info1[0].SEX==0){
                    obj.Sex = "女";
                }
                else if(info1[0].SEX==1){
                    obj.Sex = "男";
                }
                else
                {
                    obj.Sex = "未指定";
                }
                obj.HeadUrl = info1[0].HEADURL;
                obj.Birthday = info1[0].BIRTHDAY;
                obj.Address = info1[0].CITY+" "+info1[0].COUNTRY;
                obj.Lng = info1[0].LONGITUDE;
                obj.Lat = info1[0].LATITUDE;
                obj.AddressCode = info1[0].NATIONALITY;
                obj.WordSign = info1[0].SIGNATURE;
                obj.SoundSign = info1[0].VOICEURL;
                obj.Email = "";
                root.Items.push(obj);
            }
        }
    }
}
function getMyComment(root,data,path){
    for(var i in data){
        var obj = new Dynamic();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.UserID = data[i].USERID;
        var info = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].USERID+"'") +')');
        if(info!=""&&info!=null){
            obj.UserNickName = info[0].NICKNAME;
        }
        else
        {
            var info1 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTMOMENTSUSERS where USERID = '"+data[i].USERID+"'") +')');
            if(info1!=""&&info1!=null){
                obj.UserNickName = info1[0].NICKNAME;
            }
        }
        if(data[i].CTYPE==1){
            obj.DynamicType = "点评";
        }
        else
        {
            obj.DynamicType = "点赞";
        }
        obj.DynamicID = data[i].MOMENTID;
        obj.DynamicContent = data[i].CONTENT;
        obj.DynamicTime = XLY.Convert.LinuxToDateTime(data[i].TIME);
        root.Items.push(obj);
    }
}
function getMyNotePad(root,data,path){
    for(var i in data){
        var obj = new NotePad();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.FavoriteID = data[i].FAVORITEID;
        obj.SourceLanguage = data[i].SOURCELANGUAGE;
        if(data[i].FAVORITETYPE==3){
            if(data[i].FAVORITEOOB!=""&&data[i].FAVORITEOOB!= null){
                var fur = eval('('+ data[i].FAVORITEOOB +')');
                if(fur.body!=""&&fur.body!= null){
                    var aa = fur.body;
                    var bb = "";
                    var cc = "";
                    for(var j in aa){
                        bb+= aa[j].source+"\r";
                        cc+= aa[j].target+"\r";
                    }
                    obj.SourceText = bb;
                    obj.TargetText = cc;
                }
            }
        }
        else
        {
            obj.SourceText = data[i].SOURCETEXT;
            obj.TargetText = data[i].TARGETTEXT;
        }
        
        obj.UserID = data[i].USERID;
        if(data[i].USERID=="104"){
            obj.UserName = "Notepad";
        }
        else
        {
            var info = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].USERID+"'") +')');
            if(info!=""&&info!= null){
                if(info[0].NICKNAME!=""){
                    obj.UserName = info[0].NICKNAME;
                }
                else
                {
                    var info1 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTMOMENTSUSERS where USERID = '"+data[i].USERID+"'") +')');
                    //log(info1);
                    if(info1!=""&&info1!=null){
                        obj.UserName = info1[0].NICKNAME;
                    }
                }
            }
        }
        obj.ReceiveID = data[i].TOID;
        if(data[i].TOID=="104"){
            obj.ReceiveName = "Notepad";
        }
        else
        {
            var info2 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].TOID+"'") +')');
            if(info2!=""&&info2!= null){
                if(info2[0].NICKNAME!=""){
                    obj.ReceiveName = info2[0].NICKNAME;
                }
                else
                {
                    var info12 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTMOMENTSUSERS where USERID = '"+data[i].TOID+"'") +')');
                    if(info12!=""&&info12!=null){
                        obj.ReceiveName = info12[0].NICKNAME;
                    }
                }
            }
        }
        if(data[i].FAVORITETYPE==0){
            obj.ContentType = "文本";
        }
        else if(data[i].FAVORITETYPE==2){
            obj.ContentType = "文件";
        }
        else if(data[i].FAVORITETYPE==3){
            obj.ContentType = "音频";
        }
        else
        {
            obj.ContentType = "其他";
        }
        obj.FileName = data[i].FILENAME;
        obj.CreateTime = data[i].TIME;
        root.Items.push(obj);
    }
}
function getMyMessage(root,path,uid,uname,aPath){
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct(ROOMID) from HTMESSAGES") +')');
    if(data!=""&&data!= null){
        var pNum = 0;
        var gNum = 0;
        for(var i in data){
            if(data[i].ROOMID==0){
                pNum += 1;
            }
            else
            {
                gNum += 1;
            }
        }
        if(pNum!=0){
            var nodePer = new TreeNode();
            nodePer.Text = "个人聊天记录";
            nodePer.Type = "";
            var info = eval('('+ XLY.Sqlite.Find(path,"select distinct(FRIENDID) from HTMESSAGES where ROOMID = '0'") +')');
            if(info!=""&&info!= null){
                var childFNode = new TreeNode();
                childFNode.Text = "好友聊天记录";
                childFNode.Type = "";
                
                var childMNode = new TreeNode();
                childMNode.Text = "陌生人聊天记录";
                childMNode.Type = "";
                
                
                
                
                for(var j in info){
                    var info2 = eval('('+ XLY.Sqlite.Find(path,"select USERID from HTUSERFRIENDS where USERID = '"+info[j].FRIENDID+"'") +')');
                    if(info2!=""&&info2!=null){
                        var info3 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+info[j].FRIENDID+"'") +')');
                        if(info3!=""&&info3!=null){
                            var child1Node = new TreeNode();
                            child1Node.Text = info3[0].NICKNAME;
                            child1Node.Type = "Message";
                            getMessage(child1Node,info[j].FRIENDID,path,0,uid,uname,aPath);
                            childFNode.TreeNodes.push(child1Node);
                        }
                    }
                    else
                    {
                        if(info[j].FRIENDID=="104"){
                            var child2Node = new TreeNode();
                            child2Node.Text = "Notepad";
                            child2Node.Type = "Message";
                            getMessage(child2Node,"104",path,0,uid,uname,aPath);
                            childMNode.TreeNodes.push(child2Node);
                        }
                        else
                        {
                            var info4 = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+info[j].FRIENDID+"'") +')');
                            if(info4!=""&&info4!=null){
                                var child2Node = new TreeNode();
                                child2Node.Text = info4[0].NICKNAME;
                                child2Node.Type = "Message";
                                getMessage(child2Node,info[j].FRIENDID,path,0,uid,uname,aPath);
                                childMNode.TreeNodes.push(child2Node);
                            }
                        }
                    }
                }
                
            }
            if(childFNode.TreeNodes!=""&&childFNode.TreeNodes!=null){
                nodePer.TreeNodes.push(childFNode);
            }
            if(childMNode.TreeNodes!=""&&childMNode.TreeNodes!=null){
                nodePer.TreeNodes.push(childMNode);
            }
            if(nodePer.TreeNodes!=""&&nodePer.TreeNodes!=null){
                root.TreeNodes.push(nodePer);
            }
        }
        if(gNum!= 0){
            var node = new TreeNode();
            node.Text = "群组聊天记录";
            node.Type = "";
            //getMessage(node,data[i].ROOMID,path);
            for(var m in data){
                var info = eval('('+ XLY.Sqlite.Find(path,"select ROOMNAME from HTROOM where ROOMID = '"+data[m].ROOMID+"'") +')');
                if(info!=""&&info!=null){
                    var nodeGroupChild = new TreeNode();
                    nodeGroupChild.Text = info[0].ROOMNAME;
                    nodeGroupChild.Type = "Message";
                    getMessage(nodeGroupChild,data[m].ROOMID,path,1,data[m].ROOMID,info[0].ROOMNAME,aPath);
                    node.TreeNodes.push(nodeGroupChild);
                }
            }
            if(node.TreeNodes!=""&&node.TreeNodes!=null){ 
                root.TreeNodes.push(node);
            }
        }
    }
}
function getMessage(root,id,path,flag,uid,uname,aPath){
    var data = "";
    if(flag==0){
        data = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME,TRANSFERTYPE,FRIENDID,MESSAGETYPE,CONTENT,SOURCELANGUAGE,TARGETCONTENT,FILENAME,ISREAD,OOB,TIME from HTMESSAGES where FRIENDID = '"+id+"'") +')');
    }
    if(flag==1){
        data = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME,TRANSFERTYPE,FRIENDID,MESSAGETYPE,CONTENT,SOURCELANGUAGE,TARGETCONTENT,FILENAME,ISREAD,OOB,TIME from HTMESSAGES where ROOMID = '"+id+"'") +')');    
    }
    if(data!=""&&data!=null){
        for(var i in data){
            var obj = new Message();
            //obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            if(flag==0){
                if(data[i].FRIENDID=="104"){
                    if(data[i].TRANSFERTYPE==1){
                        obj.SenderID = data[i].FRIENDID;
                        obj.SenderName = "Notepad";
                        obj.ReciveID = uid;
                        obj.ReciveName = uname;
                    }
                    else
                    {
                        obj.ReciveID = data[i].FRIENDID;
                        obj.ReciveName = "Notepad";
                        obj.SenderID = uid;
                        obj.SenderName = uname;
                    }
                }
                else
                {
                    if(data[i].TRANSFERTYPE==1){
                        obj.SenderID = data[i].FRIENDID;
                        var info = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].FRIENDID+"'") +')');
                        if(info!=""&&info!=null){
                            obj.SenderName = info[0].NICKNAME;
                        }
                        obj.ReciveID = uid;
                        obj.ReciveName = uname;
                    }
                    else
                    {
                        obj.ReciveID = data[i].FRIENDID;
                        var info = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].FRIENDID+"'") +')');
                        if(info!=""&&info!=null){
                            obj.ReciveName = info[0].NICKNAME;
                        }
                        obj.SenderID = uid;
                        obj.SenderName = uname;
                    }
                }
            }
            if(flag==1)
            {
                obj.SenderID = data[i].FRIENDID;
                var info = eval('('+ XLY.Sqlite.Find(path,"select NICKNAME from HTUSERBASE where USERID = '"+data[i].FRIENDID+"'") +')');
                if(info!=""&&info!=null){
                    obj.SenderName = info[0].NICKNAME;
                }
                obj.ReciveID = uid;
                obj.ReciveName = uname;
            }
            obj.StartTime = data[i].TIME;
            obj.Content = data[i].CONTENT;
            if(data[i].MESSAGETYPE==0){
                obj.ContentType = "文本";
            }
            else if(data[i].MESSAGETYPE==999){
                obj.ContentType = "系统提示";
            }
            else if(data[i].MESSAGETYPE==3){
                obj.ContentType = "音频";
            }
            else if(data[i].MESSAGETYPE==9){
                obj.ContentType = "涂鸦";
            }
            else if(data[i].MESSAGETYPE==4){
                obj.ContentType = "地理位置";
            }
            else if(data[i].MESSAGETYPE==13){
                obj.ContentType = "群组通话";
            }
            else if(data[i].MESSAGETYPE==11){
                obj.ContentType = "";
            }
            else if(data[i].MESSAGETYPE==1){
                obj.ContentType = "";
            }
            else if(data[i].MESSAGETYPE==2){
                obj.ContentType = "图片";
            }
            else if(data[i].MESSAGETYPE==5){
                obj.ContentType = "名片";
            }
            else if(data[i].MESSAGETYPE==6){
                //log(data[i]);
            }
            obj.TargetContent = data[i].TARGETCONTENT;
            obj.SourceLanguage = data[i].SOURCELANGUAGE;
            obj.AttachmentName = data[i].FILENAME;
            if(data[i].FILENAME!=""&&data[i].FILENAME!=null){
                obj.AttachmentPath = aPath+data[i].FILENAME;
            }
            obj.AttachmentMsg = "";
            if(data[i].ISREAD==1){
                obj.IsRead = "是";
            }
            else
            {
                obj.IsRead = "否";
            }
            root.Items.push(obj);
        }
    }
}