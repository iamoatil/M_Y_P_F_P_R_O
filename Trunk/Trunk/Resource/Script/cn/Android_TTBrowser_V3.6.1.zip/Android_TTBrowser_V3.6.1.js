﻿/*[config]
<plugin name="天天浏览器" group="Web痕迹,9" devicetype="android" icon="\icons\ttbrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.tiantianmini.android.browser" version="3.6.1" description="天天浏览器" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.tiantianmini.android.browser/databases/HWBrowser.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="存储路径" code="Path" type="string" width = "150"></item>
    <item name="文件大小" code="Size" type="string" width = "150"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="关键字" code="Keyword" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Download() {
    this.DataState = "Normal";
    this.Content = "";
    this.Url = "";
    this.Path = "";
    this.Size = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function Search() {
    this.DataState = "Normal";
    this.KeyWord = "";
}

//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}

function bindTree() {
    newTreeNode("下载信息", "Download", getDownload(db));
    newTreeNode("浏览记录", "History", getHistory(db));
    newTreeNode("书签", "Bookmark", getBookmark(db));
    newTreeNode("搜索", "Search", getSearch(db));
}
function getNews() {
    var list = new Array();
    data = ["下载信息", "浏览记录", "书签", "搜索"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from TB_DownloadItem") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Content = data[i].name;
        obj.Url = data[i].downUrl;
        obj.Path = data[i].src;
        obj.Size = data[i].length / 1024 / 1024 + "MB";
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from TB_History") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = data[i].time;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from TB_Bookmark") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].name;
        obj.Url = data[i].url;
        obj.Time = data[i].time;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from TB_Search") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.KeyWord = data[i].keyword;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
//var db = "D:\\temp\\data\\data\\com.tiantianmini.android.browser\\databases\\HWBrowser.db";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
