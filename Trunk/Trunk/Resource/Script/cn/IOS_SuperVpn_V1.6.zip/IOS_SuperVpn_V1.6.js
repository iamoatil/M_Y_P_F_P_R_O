﻿/*[config]
<plugin name="SuperVPN,7" group="生活旅游,6" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/supervpn.png" app="com.simple.VPN" version="1.6" description="SuperVPN" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.simple.VPN</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
</data>
<data type="OneKeyLink" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="VpnId" code="VpnId" type="string" width="80"></item>
    <item name="标记" code="Flag" type="string" width = "150"></item>
    <item name="是否VIP" code="IsVip" type="string" width="80"></item>
    <item name="名称" code="VPNName" type="string" width="120"></item>
    <item name="当前是否连接" code="CurrentStatus" type="string" width="120"></item>
</data>
<data type="VipSet" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="VipId" type="string" width="120"></item>
    <item name="名称" code="VipName" type="string" width="120"></item>
    <item name="价格" code="Price" type="string" width="150"></item>
</data>
<data type = "UserInfo" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="ID" code="Id" type="string" width="120"></item>
    <item name="VIP过期时间" code="VipExpireTime" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="账户类型" code="UserType" type="string" width = "120" ></item>
    <item name="当前是否连接" code="IsSucc" type="string" width = "120" ></item>
</data>
</plugin>
[config]*/
function VipSet(){
    this.DataState = "Normal";
    this.VipId = "";
    this.VipName = "";
    this.Price = "";
}
function OneKeyLink() {
    this.DataState = "Normal";
    this.VpnId = "";
    this.Flag = "";
    this.IsVip = "否";
    this.VPNName = "";
    this.CurrentStatus = "否";
}
//定义数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.Id = "";
    this.VipExpireTime = null;
    this.UserType = "免费";
    this.IsSucc = "否";
}

function News(){
    this.DataState = "Normal";
    this.List = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var upath = source[0]+"\\com.simple.VPN\\Documents\\Uer.bin";
//测试数据
//var upath = "C:\\XLYSFTasks\\任务-2017-06-06-15-12-10\\source\\IosData\\2017-06-06-15-12-29\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.simple.VPN\\Documents\\Uer.bin";
//
//定义特征库文件

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "SuperVPN";
    root.Type = "";
    getNews(root);
    
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(upath)){
        var dataXml = eval('('+ XLY.PList.ReadToJsonString(upath) +')');
        var aa = -1;
        var bb = 0;
        var cc = "";
        if(dataXml!=""&&dataXml!=null){
            for(var x in dataXml){
                if(dataXml[x].RECENT_VPN_SERVER_INDEX!=""&&dataXml[x].RECENT_VPN_SERVER_INDEX!=null){
                    aa = dataXml[x].RECENT_VPN_SERVER_INDEX;
                }
                if(dataXml[x].uuid!=""&&dataXml[x].uuid!=null){
                    bb = dataXml[x].uuid;
                }
                if(dataXml[x].vpnlist!=""&&dataXml[x].vpnlist!=null){
                    cc = dataXml[x].vpnlist;
                }
            }
            if(cc!=""&&cc!=null){
                getCC(root,aa,bb,cc);
            }
        }
    }
}
function getCC(root,aa,bb,cc){
    var data = eval('('+ cc +')');
    
    var userNode = new TreeNode();
    userNode.Text = "用户信息";
    userNode.Type = "UserInfo";
    var userObj = new UserInfo();
    userObj.Id = bb;
    if(data.deadtime!=""&&data.deadtime!=null){
        userObj.VipExpireTime = XLY.Convert.LinuxToDateTime(data.deadtime);
    }
    if(data.is_vip!=""&&data.is_vip!=null){
        userObj.UserType = "VIP";
    }
    if(data.succ!=""&&data.succ!=null){
        userObj.IsSucc = "是";
    }
    userNode.Items.push(userObj);
    if(userNode.Items!=""&&userNode.Items!=null){
        root.TreeNodes.push(userNode);
    }
    
    var vipNode = new TreeNode();
    vipNode.Text = "购买VIP";
    vipNode.Type = "VipSet";
    if(data.product_list!=""&&data.product_list!=null){
        var vipSetMeal = data.product_list;
        for(var v in vipSetMeal){
            var vipObj = new VipSet();
            vipObj.VipId = vipSetMeal[v].product_id;
            vipObj.VipName = vipSetMeal[v].name_desc;
            vipObj.Price = vipSetMeal[v].price_desc;
            vipNode.Items.push(vipObj);
        }
    }
    if(vipNode.Items!=""&&vipNode.Items!=null){
        root.TreeNodes.push(vipNode);
    }
    
    var linkNode = new TreeNode();
    linkNode.Text = "一键链接";
    linkNode.Type = "OneKeyLink";
    if(data.panel_group!=""&&data.panel_group!=null){
        var oneKeyLink = data.panel_group;
        for(var k in oneKeyLink){
            var linkObj = new OneKeyLink();
            linkObj.VpnId = oneKeyLink[k].id;
            linkObj.Flag = oneKeyLink[k].flag;
            if(oneKeyLink[k].is_vip_node==true){
                linkObj.IsVip = "是";
            }
            linkObj.VPNName = oneKeyLink[k].name;
            if(oneKeyLink[k].id==aa){
                linkObj.CurrentStatus = "是";
            }
            linkNode.Items.push(linkObj);
        }
    }
    if(linkNode.Items!=""&&linkNode.Items!=null){
        root.TreeNodes.push(linkNode);
    }
}