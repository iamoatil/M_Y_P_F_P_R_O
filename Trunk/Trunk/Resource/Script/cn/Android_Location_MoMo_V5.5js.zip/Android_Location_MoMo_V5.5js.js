﻿/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\map.png" app="com.immomo.momo" version="5.5" description="陌陌" data="$data,LocationInfoDataSource" >
<source>
    <value>/data/data/com.immomo.momo/databases#F</value>
</source>
<data type = "Position" contract="Map"> 
<item name="描述" code="Remark" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="double" width="" format="F6"></item>
<item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
<item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "";
    this.Source = "陌陌";
    this.StartDate = null;
}

//获取历史搜索树的信息
function getPosition(path) {
    var db = eval('(' + XLY.File.FindFileNames(path) + ')');
    var info = new Array();
    var str = ""
    for(var index in db){
        var reg = /^\d+$/;
        if(reg.test(db[index])){
            str = path+"\\"+db[index];
        }
    }
    var data = eval('(' + XLY.Sqlite.Find(str, "select cast(field2 as text)as Remark ,field15,field16 from groups") + ')');
    var info = new Array();
    if(data!=null){
        for (var i in data) {
            //log(data[i]);
            if(data[i].field16!=0||data[i].field15!=0){
                var obj = new Position();
                obj.Longitude = XLY.Convert.ToDouble(data[i].field16);
                obj.Latitude = XLY.Convert.ToDouble(data[i].field15);
                obj.Remark = data[i].Remark;
                info.push(obj);
            }
        }
    }
    var data1 = eval('(' + XLY.Sqlite.Find(path+"\\feeds", "select cast(field4 as text)as Remark ,field5,field6 ,field16 from sites") + ')');
    if(data1!=null){
        for (var j in data1) {
            //log(data1[j]);
            if(data1[j].field6!=null||data1[j].field5!=null){
                var obj = new Position();
                obj.Longitude = XLY.Convert.ToDouble(data1[j].field6);
                obj.Latitude = XLY.Convert.ToDouble(data1[j].field5);
                obj.StartDate = XLY.Convert.LinuxToDateTime(data1[j].field16);
                obj.Remark = data1[j].Remark;
                info.push(obj);
            } 
        }
    }
    return info;
}

var result = new Array();
//源文件路径
var source = $source;
var db = source[0];
//var db = "C:\\Users\\Administrator\\Desktop\\com.immomo.momo\\databases";
result=getPosition(db);
var res = JSON.stringify(result);
res;
