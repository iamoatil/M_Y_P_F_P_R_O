﻿/*[config]
<plugin name="YY语音,8" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/YY.png" app="com.duowan.mobile" version="4.1.3" description="YY语音" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.duowan.mobile/databases#F</value>
</source>

<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID号" code="ID" type="int" width="0" format=""></item>
<item name="YY号" code="YYID" type="int" width="150" format=""></item>
<item name="用户名" code="Name" type="string" width="150" format=""></item>
<item name="帐号" code="Passport" type="string" width="150" format=""></item>
<item name="昵称" code="NickName" type="string" width="150" format=""></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="签名" code="Sign" type="string" width="150" format=""></item>
<item name="登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="生日" code="Birthday" type="string" width="150" format=""></item>
</data>

<data type="BuddyGroup" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="组名" code="Name" type="string" width="" format=""></item>
</data>

<data type="User" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID号" code="ID" type="int" width="0" ></item>
<item name="YY号" code="YYID" type="int" width="140" ></item>
<item name="昵称" code="Name" type="string" width="150" format=""></item>
<item name="签名" code="Sign" type="string" width="150" format=""></item>
<item name="最后登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="头像地址" code="HeadImage" type="string" width="100" format=""></item>
<item name="生日" code="Birthday" type="string" width="100" format=""></item>
</data>

<data type="Message" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送用户" code="SenderName" type="string" width="120" ></item>
<item name="接收用户" code="ReceiveName" type="string" width="120" ></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="时间" code="Date" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

<data type="Forum" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="群组ID" code="GroupID" type="int" width="140" ></item>
<item name="群组名称" code="GroupName" type="string" width="150" format=""></item>
<item name="群组号" code="AliasId" type="string" width="150" format=""></item>
<item name="群组图标地址" code="Logo" type="string" width="100" format=""></item>
</data>
</plugin>
[config]*/

//****************************************以下是定义数据结构****************************************
//定义Account数据结构
function Account() {
    this.DataState = "Normal";
    this.Name = "";
    this.NickName = "";
    this.Sign = "";
    this.Time = null;
    this.Passport = "";
    this.ID = 0;
    this.Gender = "";
    this.Birthday = "";
}

//定义BuddyGroup数据结构
function BuddyGroup() {
    this.DataState = "Normal";
    this.Name = "";
}

//定义User数据结构
function User() {
    this.DataState = "Normal";
    this.Name = "";
    this.Time = null;
    this.Sign = "";
    this.ID = 0;
    this.Gender = "";
    this.HeadImage = "";
    this.Birthday = "";
}

//定义Message数据结构
function Message() {
    this.SenderName = "";
    this.ReceiveName = "";
    this.SenderImage = "";
    this.Content = "";
    this.Type = "";
    this.Date = null;
    this.SendState = "";
    this.DataState = "Normal";
}

//定义Forum数据结构
function Forum() {
    this.Name = "";
    this.ForumID = "";
    this.ParentID = "";
    this.Logo = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//****************************************以下是处理APP数据****************************************
var result = new Array();
//源文件
var source = $source;
var path = source[0];
//var path = "C:\\XLYSFTasks\\未命名-16\\source\\data\\data\\com.duowan.mobile\\databases";

//特征库文件
var charactor1 = "chalib\\Android_DuoWanYY_V2.11.0\\accounts.charactor";
var charactor2 = "chalib\\Android_DuoWanYY_V2.11.0\\forumDbdymatic.charactor";
var charactor3 = "chalib\\Android_DuoWanYY_V2.11.0\\friendInfoDb_dymatic.charactor";
var charactor4 = "chalib\\Android_DuoWanYY_V2.11.0\\user_msg_db_dymatic.charactor";
var charactor5 = "chalib\\Android_DuoWanYY_V2.11.0\\userInfoDb.charactor";
//创建账号树结构
var corePath = path + "\\core.db";
var recoveryCorePth = XLY.Sqlite.DataRecovery(corePath, "", "Auth_AccountInfo,User_UserInfo");
var accountData = eval('(' + XLY.Sqlite.FindByName(recoveryCorePth, "Auth_AccountInfo") + ')');
for (var index in accountData) {
    var account = new TreeNode();
    account.Text = accountData[index].name;
    account.Type = "Account";
    account.DataState = accountData[index].XLY_DataType
    var accInfo = getAccountInfo(accountData[index], path)
    account.Items.push(accInfo);
    buildChildNodesForAccount(account, path, accInfo)
    result.push(account);
}

var res = JSON.stringify(result);
res;

//****************************************以下是处理APP数据的方法****************************************
//获取账号信息
function getAccountInfo(data,path) {
    var userInfo = eval('(' + XLY.Sqlite.Find(recoveryCorePth, "select * from User_UserInfo where userId='" + data.userId + "'") + ')');
    var obj = new Account();
    obj.ID = data.userId;
    obj.Name = data.name;
    obj.Time = XLY.Convert.LinuxToDateTime(data.loginTime);
    obj.Passport = data.passport;  
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    if (userInfo.length != 0) {
        obj.YYID = userInfo[0].yyId;
        obj.Gender = (userInfo[0].gender == "Male") ? "男" : "女";
        obj.NickName = userInfo[0].nickName;
        obj.Sign = userInfo[0].signature;
        if(userInfo[0].birthday != "0"){
            obj.Birthday = XLY.Convert.ToDateTime(userInfo[0].birthday,"yyyyMMdd");
        }
    }
    return obj;
}

//获取账号子节点信息
function buildChildNodesForAccount(tree, path, acc) {
    //创建账号好友子节点
    var buddyGroup = new TreeNode();
    buddyGroup.Text = "好友分组"
    buddyGroup.Type = "BuddyGroup";
    buddyGroup.DataState = "Normal";
    friendListPath = path + "\\" + acc.ID + ".db";
    var recoveryTableObj =eval('(' + XLY.Sqlite.Find(friendListPath,"select tbl_name from sqlite_master where type = 'table' and tbl_name like '%im_%'") + ')');
    recoveryTables = "";
    for(var i in recoveryTableObj){
        recoveryTables += recoveryTableObj[i].tbl_name + ",";
    }
    recoveryTables = recoveryTables.substr(0,recoveryTables.length - 1);
    var recoveryFriendListPath = XLY.Sqlite.DataRecovery(friendListPath, "", recoveryTables);
    var friendGroupData = eval('(' + XLY.Sqlite.Find(recoveryFriendListPath, "select  folderId,folderName,XLY_DataType from im_friend_list where folderId > 0 group by folderId") + ')');
    for (var index in friendGroupData) {
        var obj = new BuddyGroup();
        obj.Name = friendGroupData[index].folderName;
        obj.DataState = XLY.Convert.ToDataState(friendGroupData[index].XLY_DataType);
        buddyGroup.Items.push(obj);

        //创建好友分组的各节点
        var friendGroup = new TreeNode();
        friendGroup.Text = friendGroupData[index].folderName;
        friendGroup.Type = "User";
        friendGroup.DataState = friendGroupData[index].XLY_DataType;
        var friendGroupInfo = getUserInfo(path, recoveryFriendListPath, friendGroupData[index].folderId);
        friendGroup.Items = friendGroupInfo;
        buddyGroup.TreeNodes.push(friendGroup);

        //创建好友聊天信息节点
        for (var num in friendGroupInfo) {
            var friendMessage = new TreeNode();
            friendMessage.Text = friendGroupInfo[num].Name;
            friendMessage.Type = "Message";
            friendMessage.DataState = friendGroupInfo[num].DataState;
            friendMessage.Items = getFriendMessageInfo(path, acc, friendGroupInfo[num]);
            friendGroup.TreeNodes.push(friendMessage);
        }
    }

    //创建账号群组子节点
    var forum = new TreeNode();
    forum.Text = "群组";
    forum.Type = "Forum";
    var forumInfo = getForumInfo(acc);
    forum.Items = forumInfo;
    for (var number in forumInfo) {
        var forumMessage = new TreeNode();
        forumMessage.Text = forumInfo[number].Name;
        forumMessage.Type = "Message";
        forumMessage.DataState = forumInfo[number].DataState;
        forumMessage.Items = getForumMessageInfo(acc, forumInfo[number]);
        forum.TreeNodes.push(forumMessage);
    }
    tree.TreeNodes.push(buddyGroup);
    tree.TreeNodes.push(forum);
}

//获取帐号子节点之好友分组中好友信息
function getUserInfo(upath, fpath, id) {
    var data = eval('(' + XLY.Sqlite.Find(fpath, "select * from im_friend_list where folderId = '" + id + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var userData = eval('(' + XLY.Sqlite.Find(recoveryCorePth, "select * from User_UserInfo where userId = '" + data[index].id + "'") + ')');
        var obj = new User();
        obj.Name = data[index].nickName;
        obj.ID = data[index].id;
        obj.YYID = data[index].imId;
        obj.HeadImage = data[index].headPhotoUrl;
        if (data[index].birthday != "" && data[index].birthday != "0") {
                obj.Birthday = XLY.Convert.ToDateTime(data[index].birthday, "yyyyMMdd");
        }
            
        if (userData.length > 0) {
            obj.Time = XLY.Convert.LinuxToDateTime(userData[0].updateTime);
            obj.Gender = (userData[0].gender == "Male") ? "男" : "女";           
            obj.Sign = userData[0].signature;
            obj.DataState = XLY.Convert.ToDataState(userData[0].XLY_DataType);
        }
        
        info.push(obj);
    }
    return info;
}

//获取好友聊天信息
function getFriendMessageInfo(path, acc, id) {
    var tableName = "im_1v1_msg_" + XLY.Convert.CalculateMd5(id.ID);
    if(recoveryTables.indexOf(tableName) < 0){
        return new Array();
    }

    var data = eval('(' + XLY.Sqlite.Find(friendListPath, "select * from "+tableName) + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        if (data[index].send_uid == acc.ID) {
            obj.SenderName = acc.NickName+ "(" + acc.YYID + ")";
            obj.ReceiveName = id.Name + "(" + id.YYID + ")";
        } else {
            obj.SenderName = id.Name + "(" + id.YYID + ")";
            obj.ReceiveName = acc.NickName + "(" + acc.YYID + ")";
        }
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].msg_send_timestamp);
        obj.Content = data[index].msgText;
        obj.SendState = (data[index].isSend == 1) ? "Send" : "Receive";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取群组信息
function getForumInfo(acc) {
    var data = eval('(' + XLY.Sqlite.Find(friendListPath, "select * from im_group_list") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Forum();
        obj.GroupName = data[index].groupName;
        obj.GroupID = data[index].groupId;
        obj.AliasId = data[index].aliasId;
        obj.Logo = data[index].logoUrl;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取群组聊天消息
function getForumMessageInfo(acc, forum) {
    var tableName = "im_group_msg_" + XLY.Convert.CalculateMd5(forum.GroupID);
    if(recoveryTables.indexOf(tableName) < 0){
        return new Array();
    }
    
    var data = eval('(' + XLY.Sqlite.Find(friendListPath, "select * from " + tableName) + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        obj.SenderName = data[index].nickName + "(" + data[index].send_uid + ")";
        obj.ReceiveName = forum.GroupName + "(" + forum.AliasId + ")";
        obj.Content = data[index].msgText;
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].msg_send_timestamp);
        obj.SendState = (data[index].send_uid == acc.ID) ? "Send" : "Receive";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}
