﻿/*[config]
<plugin name="Twitter,6" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/twitter.png" app="com.atebits.Tweetie2" version="6.76" description="Twitter" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.atebits.Tweetie2</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="Account" type="string" width="220" format = "" ></item>
    <item name="用户ID" code="UserID" type="string" width="120" format=""></item>
    <item name="用户名" code="UserName" type="string" width="120" format = "" ></item>
    <item name="登录时间" code="LastLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="PrivateLetter" contract="DataState" datefilter="AttachmentPath">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者用户名" code="SenderName" type="string" width="120" format = ""></item>
    <item name="发送者昵称" code="SenderNickName" type="string" width="120" format = ""></item>
    <item name="发送者简介" code="SenderBio" type="string" width="120" format = ""></item>
    <item name="发送者头像链接" code="SenderHeadUrl" type="url" width="120" format = ""></item>
    <item name="内容" code="Content" type="string" width="100" format=""></item>
    <item name="类型" code="ContentType" type="string" width="100" format=""></item>
    <item name="附件链接" code="AttachmentPath" type="url" width="200" format = ""></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Cache数据结构
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.Account = "";
    this.UserID = "";
    this.UserName = "";
    this.LastLanchTime = null;
}
//定义PrivateLetter数据结构
function PrivateLetter(){
    this.DataState = "Normal";
    this.SenderName = "";
    this.SenderNickName = "";
    this.SenderBio = "";
    this.SenderHeadUrl = "";
    this.Content = "";
    this.ContentType = "";
    this.AttachmentPath = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.atebits.Tweetie2\\Documents\\com.atebits.tweetie.application-state";
var cookPath = source[0]+"\\com.atebits.Tweetie2\\Library\\Cookies\\Cookies.binarycookies";
var userPath = source[0]+"\\com.atebits.Tweetie2\\Library\\Preferences\\com.atebits.Tweetie2.plist";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.atebits.Tweetie2\\Documents\\com.atebits.tweetie.application-state";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.atebits.Tweetie2\\Library\\Cookies\\Cookies.binarycookies";
//var userPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.atebits.Tweetie2\\Library\\Preferences\\com.atebits.Tweetie2.plist";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_Weibo_V6.5.1\\db_65100_6050936393.dat.charactor";
var charactor2 = "\\chalib\\iOS_Weibo_V6.5.1\\message_6050936393.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "Twitter";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].twitter!=""&&data[i].twitter!=null){
                    var bb = data[i].twitter[0].accounts[0];
                    for(var b in bb){
                        var cc = bb[b];
                        var obj = new UserInfo();
                        for(var c in cc){
                            //obj.DataState = "Normal";
                            if(cc[c].username!=""&&cc[c].username!=null){
                                obj.UserName = cc[c].username;
                            }
                            if(cc[c].accountID!=""&&cc[c].accountID!=null){
                                obj.Account = cc[c].accountID;
                            }
                            if(cc[c].userID!=""&&cc[c].userID!=null){
                                obj.UserID = cc[c].userID;
                            }
                            if(cc[c].lastActiveDate!=""&&cc[c].lastActiveDate!=null){
                                obj.LastLanchTime = XLY.Convert.LinuxToDateTime(cc[c].lastActiveDate);
                            }
                        }
                        var node = new TreeNode();
                        if(obj.UserName!=""&&obj.UserName!=null){
                            node.Text = obj.UserName;
                        }
                        else
                        {
                            node.Text = "sssssssssfff";
                        }
                        node.Type = "UserInfo";
                        node.Items.push(obj);
                        if(node.Items!=""&&node.Items!=null){
                            root.TreeNodes.push(node);
                            if(obj.Account!=""&&obj.Account!=null){
                                getUserChildNodeInfo(node,obj.Account);
                            }
                        }
                    }
                }
            }
        }
    }
    if(XLY.File.IsValid(cookPath)){
        var cachenode = new TreeNode();
        cachenode.Text = "Cache缓存";
        cachenode.Type = "Cache";
        getCache(cachenode);
        root.TreeNodes.push(cachenode);
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
function getUserChildNodeInfo(root,info){
    var privaterLettlerPath = allPath + "\\app.acct."+info+".detail.11";
    if(XLY.File.IsValid(privaterLettlerPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(privaterLettlerPath) +')');
        if(data!=""&&data!= null){
            var cnode = new TreeNode();
            cnode.Text = "私信";
            cnode.Type = "News";
            root.TreeNodes.push(cnode);
            for(var i in data){
                if(data[i].$objects!=""&&data[i].$objects!=null){
                    var aa = data[i].$objects[0].NSMutableDictionary[0].directMessagesState.TFNDirectMessageContextState[0].directMessageModel.TFNDirectMessageModel;
                    //log(aa.length);
                    for(var a in aa){
                        if(aa[a].cachedUserByUserID!=""&&aa[a].cachedUserByUserID!=null){
                            //log(aa[a]);
                        }
                        if(aa[a].inbox!=""&&aa[a].inbox!=null){
                            var bb = aa[a].inbox.TFNDirectMessageInbox;
                            for(var b in bb){
                                if(bb[b].conversations!=""&&bb[b].conversations!= null){
                                    var cc = bb[b].conversations;
                                    if(cc.NSMutableArray!=""&&cc.NSMutableArray!= null){
                                        var dd = cc.NSMutableArray;
                                        for(var d in dd){
                                            if(dd[d].TFNDirectMessageConversation!=""&&dd[d].TFNDirectMessageConversation!=null){
                                                var elk = "";
                                                var node = new TreeNode();
                                                var ee = dd[d].TFNDirectMessageConversation;
                                                for(var e in ee){
                                                    if(ee[e].entries!=""&&ee[e].entries!= null){
                                                        var ff = ee[e].entries.NSMutableArray;
                                                        for(var f in ff){
                                                            var gg = ff[f].TFNDirectMessageEntry;
                                                            var obj = new PrivateLetter();
                                                            var ghjkk = 0;
                                                            
                                                            for(var g in gg){
                                                                if(gg[g].displayText!= null&&gg[g].displayText!= "$null"){
                                                                    obj.Content = gg[g].displayText;
                                                                    ghjkk = gg[g].displayText.length;
                                                                }
                                                                if(gg[g].attachment!=null&&gg[g].attachment!= "$null"){
                                                                    if(gg[g].attachment.TFNDirectMessageMediaAttachment!= null){
                                                                        var hh = gg[g].attachment.TFNDirectMessageMediaAttachment[0].entityMedia.TFNTwitterEntityMedia;
                                                                        for(var h in hh){
                                                                            if(hh[h].videoInfo!="$null"&&hh[h].videoInfo!=null){
                                                                                obj.ContentType = "video/mp4";
                                                                            }
                                                                            if(hh[h].mediaURL!="$null"&&hh[h].mediaURL!=null)
                                                                            {
                                                                                obj.ContentType = "图片";
                                                                            }
                                                                        }
                                                                    }
                                                                    if(gg[g].attachment.TFNDirectMessageStickerAttachment!= null){
                                                                        obj.ContentType = "贴纸";
                                                                    }
                                                                }
                                                                if(gg[g].sourceText!=""&&gg[g].sourceText!=null){
                                                                    obj.AttachmentPath = gg[g].sourceText.substr(ghjkk,gg[g].sourceText.length);
                                                                    if(ghjkk==gg[g].sourceText.length){
                                                                        obj.ContentType = "文本";
                                                                    }
                                                                }
                                                                if(gg[g].sender!= null&&gg[g].sender!= "$null"){
                                                                    var jj = gg[g].sender.TFNDirectMessageCachedUser[0].user.TFNDirectMessageUser;
                                                                    for(var j in jj){
                                                                        if(jj[j].bio!=""&&jj[j].bio!=null){
                                                                            obj.SenderBio = jj[j].bio;
                                                                        }
                                                                        if(jj[j].username!=""&&jj[j].username!=null){
                                                                            obj.SenderName = jj[j].username;
                                                                        }
                                                                        if(jj[j].fullName!=""&&jj[j].fullName!=null){
                                                                            obj.SenderNickName = jj[j].fullName;
                                                                        }
                                                                        if(jj[j].profileImageURL!=""&&jj[j].profileImageURL!=null){
                                                                            obj.SenderHeadUrl = jj[j].profileImageURL;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            if(obj.SenderName!=""&&obj.SenderName!=null){
                                                                node.Items.push(obj);
                                                            }
                                                            
                                                        }
                                                    }
                                                    if(ee[e].participants!=""&&ee[e].participants!=null){
                                                        elk = ee[e].participants.NSMutableOrderedSet;
                                                    }
                                                }
                                                if(dd[d].TFNDirectMessageConversation[2].conversationID.length<20){
                                                    node.Text = dd[d].TFNDirectMessageConversation[2].conversationID;
                                                }
                                                else
                                                {
                                                    node.Text = dd[d].TFNDirectMessageConversation[7].participants.NSMutableOrderedSet[0]["NS.object.0"].TFNDirectMessageConversationParticipant[1].participatingUser.TFNDirectMessageCachedUser[0].user.TFNDirectMessageUser[2].fullName;
                                                }
                                                node.Type = "PrivateLetter";
                                                cnode.TreeNodes.push(node);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}