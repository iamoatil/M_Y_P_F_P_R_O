﻿/*[config]
<plugin name="滴滴打车,6" group="地图公交,7" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/dididache.png" app="com.xiaojukeji.didi" version="5.0.14" description="滴滴打车" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.xiaojukeji.didi</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="SearchWord"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关键字" code="Key" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="120" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="性别" code="Gender" type="string" width="120" format=""></item>
    <item name="年龄" code="Age" type="string" width="120" format = "" ></item>
    <item name="头像链接地址" code="ProfileHeadUrl" type="url" width="200" format=""></item>
    <item name="会员等级" code="LevelName" type="string" width="120" format=""></item>
    <item name="联系电话" code="Phone" type="string" width="120" format=""></item>
    <item name="实名认证" code="IsAuthDesc" type="string" width="120" format=""></item>
    <item name="车主认证" code="IsDriverAuth" type="string" width="120" format=""></item>
    <item name="行业" code="Trade" type="string" width="120" format=""></item>
</data>
<data type="CommonAddress" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="ToName" type="string" width="120" format = "" ></item>
    <item name="地点名" code="AddressName" type="string" width="120" format=""></item>
    <item name="标签" code="Tag" type="string" width="120" format=""></item>
    <item name="经度" code="Lng" type="string" width="120" format=""></item>
    <item name="纬度" code="Lat" type="string" width="120" format=""></item>
</data>
<data type="Message" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format = "" ></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format = "" ></item>
    <item name="接收者ID" code="ReceiveID" type="string" width="120" format = "" ></item>
    <item name="接收者姓名" code="ReceiveName" type="string" width="120" format = "" ></item>
    <item name="内容" code="MessageText" type="string" width="120" format = "" ></item>
    <item name="最后阅读ID" code="LastReadMessageID" type="string" width="200" format=""></item>
    <item name="对方头像链接" code="AvatarUrl" type="url" width="200" format=""></item>
    <item name="消息发送时间" code="MessageSendTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.NickName = "";
    this.Gender = "";
    this.Age = "";
    this.ProfileHeadUrl = "";
    this.LevelName = "";
    this.Phone = "";
    this.IsAuthDesc = "";
    this.IsDriverAuth = "";
    this.Trade = "";
}
//定义CommonAddress数据结构
function CommonAddress(){
    this.DataState = "Normal";
    this.ToName = "";
    this.AddressName = "";
    this.Tag = "";
    this.Lng = "";
    this.Lat = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReceiveID = "";
    this.ReceiveName = "";
    this.MessageText = "";
    this.LastReadMessageID = "";
    this.AvatarUrl = "";
    this.MessageSendTime = "";
}
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.xiaojukeji.didi\\Documents";
var userIDPath = source[0]+"\\com.xiaojukeji.didi\\Documents\\ONEContacts\\contacts.json";
var cookPath = source[0]+"\\com.xiaojukeji.didi\\Library\\Cookies\\Cookies.binarycookies";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-04-14-10-18-44\\source\\IosData\\2017-04-14-10-19-50\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.xiaojukeji.didi\\Documents";
//var userIDPath = "C:\\XLYSFTasks\\任务-2017-04-14-10-18-44\\source\\IosData\\2017-04-14-10-19-50\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.xiaojukeji.didi\\Documents\\ONEContacts\\contacts.json";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-04-14-10-18-44\\source\\IosData\\2017-04-14-10-19-50\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.xiaojukeji.didi\\Library\\Cookies\\Cookies.binarycookies";
//定义特征库文件
var charactor = "chalib\\iOS_Didi_V5.0.14\\DDIMDataBase.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "滴滴打车";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var data = eval('('+ XLY.File.FindFileNamesWithExtension(allPath+"\\UserData") +')');
    if(data!=""&&data!=null){
        var reg = new RegExp("userProfile","i");
        for(var i in data){
            if(reg.test(data[i])){
                var userPath = allPath +"\\UserData\\"+data[i];
                var commonAddressPath = allPath + "\\UserData\\commonAddress_" +data[i].substr(11,data[i].length-1);
                if(XLY.File.IsValid(userPath)){
                    var info = eval('('+ XLY.File.ReadFile(userPath) +')');
                    if(info!=""&&info!=null){
                        var node = new TreeNode();
                        node.Text = info.nick;
                        node.Type = "UserInfo";
                        if(XLY.File.IsValid(commonAddressPath)){
                            var node1 = new TreeNode();
                            node1.Text = "常用地址";
                            node1.Type = "News";
                            getCommonAddress(node1,commonAddressPath);
                            node.TreeNodes.push(node1);
                        }
                        else
                        {
                            var reg1 = new RegExp("commonAddress_","i");
                            for(var a in data){
                                if(reg1.test(data[a])){
                                    var otherCommonAddress = allPath +"\\UserData\\"+data[a];
                                    if(XLY.File.IsValid(otherCommonAddress)){
                                        var nodeoth = new TreeNode();
                                        nodeoth.Text = "其他用户常用地址";
                                        nodeoth.Type = "CommonAddress";
                                        getCommonAddress(nodeoth,otherCommonAddress);
                                        if(nodeoth.Items!=""&&nodeoth.Items!=null){
                                            root.TreeNodes.push(nodeoth);
                                        }
                                    }
                                }
                            }
                        }
                        var obj = new UserInfo();
                        //obj.DataState = "Normal";
                        obj.UserName = info.nick;
                        obj.NickName = info.nickname;
                        if(info.gender==1){
                            obj.Gender = "男";
                        }
                        else if(info.gender==2)
                        {
                            obj.Gender = "女";
                        }
                        else
                        {
                            obj.Gender = "未设置";
                        }
                        obj.Age = info.age;
                        obj.ProfileHeadUrl = info.head_url;
                        obj.LevelName = info.levelName;
                        obj.Phone = info.phone;
                        obj.IsAuthDesc = info.auth_desc;
                        obj.IsDriverAuth = info.driver_auth_state;
                        obj.Trade = info.trade;
                        node.Items.push(obj);
                        root.TreeNodes.push(node);
                        
                        if(XLY.File.IsValid(userIDPath)){
                            var ddddddddddd = eval('('+ XLY.File.ReadXML(userIDPath) +')');
                            if(ddddddddddd!=""&&ddddddddddd!= null){
                                if(ddddddddddd.plist.dict.string!=""&&ddddddddddd.plist.dict.string!=null){
                                    var aa = ddddddddddd.plist.dict.string;
                                    var messaegPath = allPath + "\\DDIM\\" +aa+"\\DDIMDataBase.db";
                                    
                                    var node2 = new TreeNode();
                                    node2.Text = "消息";
                                    node2.Type = "Message";
                                    getMessage(node2,messaegPath,obj.UserName);
                                    node.TreeNodes.push(node2);
                                }
                            }
                            
                        }
                        if(XLY.File.IsValid(userIDPath)){
                            var aaaaaaa = eval('('+ XLY.File.ReadXML(userIDPath) +')');
                            if(aaaaaaa!=""&&aaaaaaa!= null){
                                if(aaaaaaa.plist.dict.string!=""&&aaaaaaa.plist.dict.string!=null){
                                    var aa = aaaaaaa.plist.dict.string;
                                    var tempID = eval('('+ XLY.File.FindDirectories(allPath+"\\DDIM") +')');
                                    for(var t in tempID){
                                        if(tempID[t]!=allPath+"\\DDIM\\"+aa){
                                            var node222 = new TreeNode();
                                            node222.Text = tempID[t].substr(tempID[t].length-15,tempID[t].length);
                                            node222.Type = "Message";
                                            getMessage(node222,tempID[t]+"\\DDIMDataBase.db",obj.UserName);
                                            if(node222.Items!=""&&node222.Items!=null){
                                                root.TreeNodes.push(node222);
                                            }
                                        }
                                    }
                                }
                            }
                            
                        }
                        if(XLY.File.IsValid(cookPath)){
                            var nodeCook = new  TreeNode();
                            nodeCook.Text = "Cache缓存";
                            nodeCook.Type = "Cache";
                            getCache(nodeCook);
                            root.TreeNodes.push(nodeCook);
                        }
                    }
                }
            }
        }
    }
}
function getCommonAddress(root,path){
    var data = eval('('+ XLY.File.ReadFile(path) +')');
    if(data!=""&&data!=null){
        var nodehome = new TreeNode();
        nodehome.Text = "家";
        nodehome.Type = "CommonAddress";
        var obj = new CommonAddress();
        //obj.DataState = "Normal";
        if(data.homePOIEntityModel.to_name!=""&&data.homePOIEntityModel.to_name!=null){
            obj.ToName = data.homePOIEntityModel.to_name;
        }
        if(data.homePOIEntityModel.addressname!=""&&data.homePOIEntityModel.addressname!=null){
            obj.AddressName = data.homePOIEntityModel.addressname;
        }
        if(data.homePOIEntityModel.lng!=""&&data.homePOIEntityModel.lng!=null){
            obj.Lng = data.homePOIEntityModel.lng;
        }
        if(data.homePOIEntityModel.lat!=""&&data.homePOIEntityModel.lat!=null){
            obj.Lat = data.homePOIEntityModel.lat;
        }
        if(data.homePOIEntityModel.tag!=""&&data.homePOIEntityModel.tag!=null){
            obj.Tag = data.homePOIEntityModel.tag;
        }
        nodehome.Items.push(obj);
        root.TreeNodes.push(nodehome);
        
        var obj33 = new News();
        obj33.List = nodehome.Text;
        root.Items.push(obj33);
        
        var nodecompany = new TreeNode();
        nodecompany.Text = "公司";
        nodecompany.Type = "CommonAddress";
        var obj1 = new CommonAddress();
        //obj.DataState = "Normal";
        if(data.companyPOIEntityModel.to_name!=""&&data.companyPOIEntityModel.to_name!=null){
            obj1.ToName = data.companyPOIEntityModel.to_name;
        }
        if(data.companyPOIEntityModel.addressname!=""&&data.companyPOIEntityModel.addressname!=null){
            obj1.AddressName = data.companyPOIEntityModel.addressname;
        }
        if(data.companyPOIEntityModel.lng!=""&&data.companyPOIEntityModel.lng!=null){
            obj1.Lng = data.companyPOIEntityModel.lng;
        }
        if(data.companyPOIEntityModel.lat!=""&&data.companyPOIEntityModel.lat!=null){
            obj1.Lat = data.companyPOIEntityModel.lat;
        }
        if(data.companyPOIEntityModel.tag!=""&&data.companyPOIEntityModel.tag!=null){
            obj1.Tag = data.companyPOIEntityModel.tag;
        }
        nodecompany.Items.push(obj1);
        root.TreeNodes.push(nodecompany);
        
        var obj333 = new News();
        obj333.List = nodecompany.Text;
        root.Items.push(obj333);
    }
}
function getMessage(root,messaegPath1,user){
    if(XLY.File.IsValid(messaegPath1)){
        var info = eval('('+ XLY.Sqlite.Find(messaegPath1,"select cast(sessionId as TEXT) as id,sessionName,userIdsArray,lastReadMessageID,messageTimeStamp,avatarUrl from SessionTable") +')');
        var aaaaaaaaa = "SessionTable";
        for(var b in info){
            if(info[b].id!=""&&info[b].id!=null){
                aaaaaaaaa+= ",Session_"+info[b].id;
            }
        }
        messaegPath = XLY.Sqlite.DataRecovery(messaegPath1,charactor,aaaaaaaaa);
        if(info!=""&&info!=null){
            for(var a in info){
                var obj = new Message();
                //obj.DataState = XLY.Convert.ToDataState(info[a].XLY_DataType);
                if(info[a].id!=""&&info[a].id!= null){
                    var aaaa = "Session_"+info[a].id;
                    var ssss = eval('('+ XLY.Sqlite.Find(messaegPath,"select userId,content from '"+aaaa+"' where sessionId = '"+info[a].id+"'") +')');
                    if(ssss!=""&&ssss!=null){
                        obj.SenderID = ssss[0].userId;
                        var bbb = eval('('+ ssss[0].content +')');
                        obj.MessageText = "标题："+bbb.title+"\t"+"内容："+bbb.title+"\t"+"背景图片："+bbb.coverImage+"\t"+"图片："+bbb.image;
                    }
                }
                obj.SenderName = info[a].sessionName;
                //log(info[a].userIdsArray);
                obj.ReceiveID = "123";
                obj.ReceiveName = user;
                if(info[a].lastReadMessageID==0){
                    obj.LastReadMessageID = "";
                }
                else
                {
                    obj.LastReadMessageID = info[a].lastReadMessageID;
                }
                
                obj.AvatarUrl = info[a].avatarUrl;
                obj.MessageSendTime = XLY.Convert.LinuxToDateTime(info[a].messageTimeStamp);
                root.Items.push(obj);
            }
        }
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
