﻿
//descritpion:配置模板

/*[config]
<plugin name="同步账号,22" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\device.png" app="com.apple.Accounts" data="$data" description="同步账号" >
<source>
    <value>com.apple.Accounts</value>
</source>
<data>
    <item name="账户名称" code="Name" type="string" width="220" ></item>
    <item name="账户类型" code="Type" type="string" width = "240" ></item>
    <item name="账户标识" code="Identifier" type="string" width="280" ></item>
</data>
</plugin>
[config]*/

// js content


function Info() {
    this.Name = "";   //账户名称
    this.Type = ""; //账户类型
    this.Identifier = ""; //账户标识
}

var result = new Array();
//源文件
var source = $source;
var db = source[0] + "\\HomeDomain\\Library\\Accounts\\Accounts3.sqlite";
//var db = "D:\\temp\\data\\Accounts3.sqlite";
var accs = eval('('+ XLY.Sqlite.Find(db,"select a.ZACCOUNTTYPE,a.ZUSERNAME,a.ZOWNINGBUNDLEID,t.ZACCOUNTTYPEDESCRIPTION,t.ZIDENTIFIER from zaccount as a left join zaccounttype as t on a.ZACCOUNTTYPE=t.Z_PK") +')'); 


for(var i in accs){
    var obj = new Info();
    var row = accs[i];
    obj.Name = row.ZUSERNAME;
    obj.Type = row.ZACCOUNTTYPEDESCRIPTION;
    obj.Identifier = row.ZIDENTIFIER;
    if(obj.Name !=null){
        result.push(obj);
    }
}


// return
var res = JSON.stringify(result);
res;










