﻿/*[config]
<plugin name="人人网,8" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/renren.png" app="com.renren.mobile.android" version="7.5.1" description="人人网" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.renren.mobile.android/databases/#F</value>
</source>
<data type="Account" datefilter="lastLoginTime" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="人人号" code="renrenID" type="string" width="150"></item>
<item name="用户名" code="ID" type="string" width="150"></item>
<item name="真实姓名" code="name" type="string" width="150"></item>
<item name="头像URL" code="headUrl" type="URL" width="300"></item>
<item name="最后登录时间" code="lastLoginTime" type="string" width="150"></item>
</data>
<data type="ExistFriends" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="人人号" code="renrenID" type="string" width="150"></item>
<item name="姓名" code="name" type="string" width="150"></item>
<item name="分组" code="group" type="string" width="150"></item>
<item name="头像URL" code="headUrl" type="URL" width="300"></item>
</data>
<data type="NewFirends" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="人人号" code="renrenID" type="string" width="150"></item>
<item name="姓名" code="name" type="string" width="150"></item>
<item name="来源" code="source" type="string" width="150"></item>
<item name="头像URL" code="headUrl" type="URL" width="300"></item>
</data>
<data type="Feeds" datefilter="time" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="姓名" code="name" type="string" width="150"></item>
<item name="来源" code="source" type="string" width="150"></item>
<item name="动态" code="activity" type="string" width="75"></item>
<item name="内容" code="content" type="string" width="300"></item>
<item name="分享" code="share" type="string" width="75"></item>
<item name="赞" code="like" type="string" width="75"></item>
<item name="赞过的人" code="likePerson" type="string" width="150"></item>
<item name="评论" code="comment" type="string" width="300"></item>
<item name="附件" code="attachement" type="string" width="150"></item>
<item name="时间" code="time" type="string" width="150"></item>
</data>
<data type="History" datefilter="Date" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="SenderName" type="string" width="150"></item>
<item name="接收人" code="to" type="string" width="150"></item>
<item name="内容" code="Content" type="string" width="300"></item>
<item name="类型" code="type" type="string" width="150"></item>
<item name="创建日期" code="Date" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss" order="desc" ></item>
<item name="头像" code="SenderImage" type="image"  show="false" width="100" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>
<data type="Room" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群号" code="roomId" type="string" width="150"></item>
<item name="群名称" code="roomName" type="string" width="150"></item>
<item name="群主" code="roomOwner" type="string" width="150"></item>
<item name="群头像" code="roomHeadUrl" type="string" width="300"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account(){
	this.renrenID="";
	this.ID="";
	this.name="";
	this.lastLoginTime="";
	this.headUrl="";
	this.DataState = "Normal";
}

function ExistFriends(){
	this.renrenID="";
	this.name="";
	this.group="";
	this.headUrl="";
	this.DataState = "Normal";
}

function NewFirends(){
	this.renrenID="";
	this.name="";
	this.source="";
	this.headUrl="";
	this.DataState = "Normal";
}


function Feeds(){ 
	this.name="";
	this.time="";
	this.source="";
	this.activity="";
	this.content="";
	this.share="";
	this.like="";
	this.likePerson="";
	this.attachement="";
	this.comment="";
	this.DataState = "Normal";
}

function History(){
	this.Date="";
	this.SenderName="";
	this.to="";
	this.type="";
	this.Content="";
	this.SendState="";
	this.Type = "";
	this.SenderImage="";
	this.DataState = "Normal";
}

function Room(){
	this.roomId="";
	this.roomName="";
	this.roomOwner="";
	this.roomHeadUrl="";
	this.DataState = "Normal";
}

//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}
//群组信息
function roomNodeCreate(path) {
	var res =new Array();
	try{
		var data=eval('('+XLY.Sqlite.Find(path ,"select room_id,room_name,groupownername,groupheadurl,XLY_DataType from room" )+')');
		for(var index in data)
		{
			var obj=new Room();
			obj.roomId=data[index].room_id;
			obj.roomName=data[index].room_name;
			obj.roomOwner=data[index].groupownername;
			obj.roomHeadUrl=data[index].groupheadurl;
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
			res.push(obj);
		}
		return res;
	}
	catch(e){
		return res;
	}
}

//账户信息
function accountNodeCreate(path,uid) {
	var res =new Array();
	try{
		var data=eval('('+XLY.Sqlite.Find(path ,"select uid,account,name,last_login_time,head_url,XLY_DataType from account where uid ="+uid+"" )+')');
		var obj=new Account();
		obj.renrenID=data[0].uid;
		obj.ID=data[0].account;
		obj.name=data[0].name;
		obj.lastLoginTime=data[0].last_login_time;
		obj.headUrl=data[0].head_url;
		obj.DataState = XLY.Convert.ToDataState(data[0].XLY_DataType); 
		res.push(obj);
		return res;
	}
	catch(e){
		return res;
	}
}

//现有好友
function existNodeCreate(path) {
	var res =new Array();
	try{
		var data=eval('('+XLY.Sqlite.Find(path ,"select uid,username,network,headurl,XLY_DataType from friends" )+')');
		for(var index in data)
		{
			var obj=new ExistFriends();
			obj.renrenID=data[index].uid;
			obj.name=data[index].username;
			obj.group=data[index].network;
			obj.headUrl=data[index].headurl;
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
			res.push(obj);
		}
		return res;
	}
	catch(e){
		return res;
	}
}

//推荐好友
function newNodeCreate(path) {
	var res =new Array();
	try{
		var data=eval('('+XLY.Sqlite.Find(path ,"select user_id,user_name,content,head_url,XLY_DataType from news_friend" )+')');
		for(var index in data)
		{
			var obj=new NewFirends();
			obj.renrenID=data[index].user_id;
			obj.name=data[index].user_name;
			obj.source=data[index].content;
			obj.headUrl=data[index].head_url;
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
			res.push(obj);
		}
		return res;
	}
	catch(e){
		return res;
	}
}

//好友动态
function feedNodeCreate(path) {
	var res =new Array();
	try{
		//var path="F:\\renren\\data\\data\\com.renren.mobile.android\\databases\\renren_"+UID+".db";
		var info=eval('('+XLY.Sqlite.Find(path ,"select * from newsfeed_new" )+')');
		for(var index in info)
		{
			var data=eval('('+info[index].content+')');
			var obj=new Feeds();
			obj.DataState = XLY.Convert.ToDataState(info[index].XLY_DataType); 
			obj.name=data.user_name;
			obj.time=XLY.Convert.LinuxToDateTime(data.time);
			obj.source=data.origin_title;
			obj.activity=data.prefix;
			obj.content=data.title;
			obj.share=data.share_count;
			obj.like=data.like.like_count;
			if(data.like.like_count!=0){
				for(var index in data.like.like_user)
				{
					obj.likePerson+=data.like.like_user[index].name+"/";
				}
			}
			for(var index in data.attachement_list)
			{
				if(data.attachement_list[index].main_url!=null){
					obj.attachement+=data.attachement_list[index].main_url+" ";
				}
				if(data.attachement_list[index].digest!=null){
					obj.attachement+=data.attachement_list[index].digest+"/";
				}
			}
			for(var index in data.comment_list)
			{
				if(data.comment_list[index].user_name!=null){
					obj.comment+=data.comment_list[index].user_name+" ";
				}
				if(data.comment_list[index].content!=null){
					obj.comment+=data.comment_list[index].content+" ";
				}
				if(data.comment_list[index].time!=null){
					obj.comment+=XLY.Convert.LinuxToDateTime(data.comment_list[index].time+"");
				}
			}
			res.push(obj);
		}
		return res;
	}
	catch(e){
		return res;
	}
}

//历史记录
function historyNodeCreate(path,fid,uname,friname) {
	var res =new Array();
	try{
		var pattern = /^([0-9.]+)$/;
		if (pattern.test(fid)) {
			var info=eval('('+XLY.Sqlite.Find(path ,"select * from history where to_id="+fid+"" )+')');
			for(var index in info)
			{
				var obj=new History();
				obj.DataState = XLY.Convert.ToDataState(info[index].XLY_DataType); 
				obj.Date= XLY.Convert.LinuxToDateTime( info[index].time_stamp );
				obj.SenderName=info[ index].fname;
				if(info[ index].msg_source=="SINGLE"){
					if(info[ index].type=="TEXT"){
						obj.type="【文字】";
						obj.Type="String";
						obj.Content=info[index].data0;
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.SendState="Send";
							obj.to=friname;
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.SendState="Receive";
							obj.to=uname;
						}
					}
					if(info[ index].type=="POI"){
						obj.type="【位置】";
						obj.Type="String";
						obj.Content=info[index].data0+" . "+info[index].data1+ "    地址:"+info[index].data2;
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="VOIP_MESSAGE"){
						obj.type="【电话】";
						obj.Type="String";
						obj.Content="通话时长："+info[index].data4;
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="BUSINESS_CARD"){
						obj.type="【明信片】";
						obj.Type="String";
						obj.Content=subStringBus(info[index].xml);
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="IMAGE"){
						obj.type="【图片】";
						obj.Type="Image";
						obj.Content=info[index].data0;
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="SECRET_IMAGE"){
						obj.type="【私密图片】";
						obj.Type="String";
						obj.Content="【私密图片】";
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="READ_SECRET"){
						obj.type="【私密图片】";
						obj.Type="String";
						obj.Content="【私密图片】";
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="AUDIO"){
						obj.type="【录音】";
						obj.Type="Audio";
						obj.Content=info[index].data0;
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
					if(info[ index].type=="APPMSG"){
						obj.type="【应用消息】";
						obj.Type="String";
						obj.Content=info[index].xml;
						if(info[ index].direction=="SEND_TO_SERVER"){
							obj.to=friname;
							obj.SendState="Send";
						}
						if(info[ index].direction=="RECV_FROM_SERVER"){
							obj.to=uname;
							obj.SendState="Receive";
						}
					}
				}
				if(info[ index].msg_source=="GROUP"){
					obj.to=friname;
					if(info[ index].direction=="SEND_TO_SERVER"){
						obj.SendState="Send";
					}
					if(info[ index].direction=="RECV_FROM_SERVER"){
						obj.SendState="Receive";
					}
					if(info[ index].type=="TEXT"){
						obj.type="【文字】";
						obj.Type="String";
						obj.Content=info[index].data0;
					}
					if(info[ index].type=="POI"){
						obj.type="【位置】";
						obj.Type="String";
						obj.Content=info[index].data0+" . "+info[index].data1+ "    地址:"+info[index].data2;
					}
					if(info[ index].type=="VOIP_MESSAGE"){
						obj.type="【电话】";
						obj.Type="String";
						obj.Content="通话时长："+info[index].data4;
					}
					if(info[ index].type=="BUSINESS_CARD"){
						obj.type="【明信片】";
						obj.Type="String";
						obj.Content=subStringBus(info[index].xml);
					}
					if(info[ index].type=="IMAGE"){
						obj.type="【图片】";
						obj.Type="Image";
						obj.Content=info[index].data0;
					}
					if(info[ index].type=="SECRET_IMAGE"){
						obj.type="【私密图片】";
						obj.Type="String";
						obj.Content="【私密图片】";
					}
					if(info[ index].type=="READ_SECRET"){
						obj.type="【私密图片】";
						obj.Type="String";
						obj.Content="【私密图片】";
					}
					if(info[ index].type=="AUDIO"){
						obj.type="【录音】";
						obj.Type="Audio";
						obj.Content=info[index].data0;
					}
					if(info[ index].type=="APPMSG"){
						obj.type="【应用消息】";
						obj.Type="String";
						obj.Content=info[index].xml;
					}
					if(info[ index].type=="GROUP_FEED"){
						obj.type="【群动态】";
						obj.Type="String";
						obj.Content= subStringFee(info[index].xml);
					}
				}
				res.push(obj);
			}
		}
		return res;
	}
	catch(e){
		return res;
	}
}
//明信片格式处理
function subStringBus(s){
	var ss;                         // 声明变量。
	ss = "明信片：【"+s.substring(s.indexOf("name=")+6, s.lastIndexOf("/>")-2)+"】";   // 取子字符串。   // 取子字符串。
	return(ss);                   // 返回子字符串。
}

//动态格式处理
function subStringFee(s){
	var ss;                         // 声明变量。
	ss = s.substring(s.indexOf("news_feed_user_name=")+21, s.lastIndexOf("news_feed_user_id")-2)+":"+s.substring(s.indexOf("group_feed description=")+24, s.lastIndexOf("is_share=")-2);   // 取子字符串。
	return(ss);                   // 返回子字符串。
}

var result = new Array();
//源文件
var source = $source;
var path1 =source[0]+"/account.db";
var path2 =source[0]+"/renren_";
var path3 =source[0]+"/talk_";

//数据恢复库的生成
var charactor1="chalib\\Android_Renren_V7.5.1\\account.db.charactor";
var charactor2="chalib\\Android_Renren_V7.5.1\\renren.db.charactor";
var charactor3="chalib\\Android_Renren_V7.5.1\\talk.db.charactor";
path1=XLY.Sqlite.DataRecovery( path1,charactor1 ,"account");
var allData=eval('('+XLY.Sqlite.Find(path1 ,"select uid,name,XLY_DataType from account")+')');

//通过账号建立节点
for(var index in allData){
	path2 =source[0]+"/renren_";
	path3 =source[0]+"/talk_";
	if(XLY.File.ReadFile( path2+allData[index].uid+".db")){

		//节点实例化
		var accountNode = new TreeNode();
		accountNode.Text = "帐号信息"
			accountNode.Type = "Account";

		var existNode = new TreeNode();
		existNode.Text = "好友列表"
			existNode.Type = "ExistFriends";

		var newNode = new TreeNode();
		newNode.Text = "推荐好友"
			newNode.Type = "NewFirends";

		var feedNode = new TreeNode();
		feedNode.Text = "好友动态";
		feedNode.Type = "Feeds";

		var historyNode = new TreeNode();
		historyNode.Text = "聊天记录";
		historyNode.Type = "History";

		var roomNode = new TreeNode();
		roomNode.Text = "群组信息";
		roomNode.Type = "Room";
		path2=XLY.Sqlite.DataRecovery( path2+allData[index].uid+".db",charactor2 ,"friends,newsfeed_new,news_friend");

		//节点数据填充
		newNode.Items=newNodeCreate(path2);
		feedNode.Items=feedNodeCreate(path2);
		accountNode.Items=accountNodeCreate(path1,allData[index].uid);
		existNode.Items=existNodeCreate(path2);
		var someone=new TreeNode();
		someone.Text =allData[index].name;
		someone.DataState=XLY.Convert.ToDataState(allData[index].XLY_DataType); 
		path3=XLY.Sqlite.DataRecovery( path3+allData[index].uid+".db",charactor3 ,"history,room");
		if(path3.indexOf("recovery.db")>0){
			roomNode.Items=roomNodeCreate(path3);

			//个人聊天信息
			var friendData=eval('('+XLY.Sqlite.Find(path2,"select uid,username,XLY_DataType from friends" )+')');
			for(var _index in friendData)
			{
				var somefriend =new TreeNode();
				somefriend.Text =friendData[_index].username;
				somefriend.Type = "History";
				somefriend.DataState=XLY.Convert.ToDataState(friendData[_index].XLY_DataType); 
				somefriend.Items =historyNodeCreate(path3,friendData[_index].uid,allData[index].name,friendData[_index].username);
				existNode.TreeNodes.push(somefriend);
			}
			//群组聊天信息
			var roomData=eval('('+XLY.Sqlite.Find(path3,"select room_id,room_name,XLY_DataType from room" )+')');
			for(var _index in roomData)
			{
				var someroom =new TreeNode();
				someroom.Text =roomData[_index].room_name;
				someroom.Type = "History";
				someroom.DataState=XLY.Convert.ToDataState(roomData[_index].XLY_DataType); 
				someroom.Items =historyNodeCreate(path3,roomData[_index].room_id,allData[index].name,roomData[_index].room_name);
				roomNode.TreeNodes.push(someroom);
			}

		}
		//数据打印
		someone.TreeNodes.push(accountNode);
		someone.TreeNodes.push(existNode);
		someone.TreeNodes.push(roomNode);
		someone.TreeNodes.push(feedNode);
		someone.TreeNodes.push(newNode);

		result.push(someone);
	}
}

var res = JSON.stringify(result);
res;
