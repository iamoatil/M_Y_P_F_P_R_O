﻿/*[config]
<plugin name="飞信，9" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\fetion.png"  app="cn.10086.feixin.fetion" description="飞信"  data="$data,ComplexTreeDataSource" version="3.6.1">
<source>
<value>cn.10086.feixin.fetion</value>
</source>

<data type="User" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="昵称" code="Name" type="string" width="" format = "" ></item>
<item name="签名" code="Impresa" type="string" width="" format = ""></item>
<item name="手机号" code="Mobile" type="string" width="" format = "" ></item>
<item name="飞信号" code="Sid" type="string" width="" format = "" ></item>
<item name="注册邮箱" code="Registeremail" type="string" width="" format = "" ></item>
<item name="生日" code="Birthdate" type="string" width="" format = "" ></item>
<item name="ID" code="ID" type="string" width="" format="" show = "false"></item>
<item name="Uri" code="Uri" type="string" width="" format="" show = "false"></item>
</data>

<data type="Group" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分组名称" code="Name" type="string" width="" format="" ></item>
<item name="OwerID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type="ContactGroup" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="联系人分组" code="Name" type="string" width="" format="" ></item>
<item name="分组ID" code="ID" type="string" width="" format="" show = "false"></item>
<item name="OwerID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type="DgGroup" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="讨论组名称" code="Name" type="string" width="" format = "" ></item>
<item name="讨论组uri" code="Uri" type="string" width="" format="" show = "false"></item>
<item name="用户ID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type="PgGroup" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="群名称" code="Name" type="string" width="" format = "" ></item>
<item name="群介绍" code="Introduction" type="string" width="" format = "" ></item>
<item name="群uri" code="Uri" type="string" width="" format="" show = "false"></item>
<item name="用户ID" code="OwerID" type="string" width="" format="" show = "false"></item>
</data>

<data type ="Contact" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="昵称" code="Name" type="string" width="100" format=""></item>
<item name="好友账号" code="ID" type="string" width="140" format=""></item>
<item name="飞信号" code="Sid" type="string" width="100" format=""></item>
<item name="备注" code="Local_name" type="string" width="200" format=""></item>
<item name="电话号码" code="Mobile" type="string" width="300" format=""></item>
<item name="签名" code="Impresa" type="string" width="300" format = ""></item>
<item name="组id" code="GroupID" type="string" width="" format="" show = "false"></item>
<item name="OwerID" code="OwerID" type="string" width="" format="" show = "false"></item>
<item name="Uri" code="Uri" type="string" width="" format="" show = "false"></item>
</data>

<data type = "Discussion" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="昵称" code="Name" type="string" width="100" format=""></item>
<item name="好友账号" code="ID" type="string" width="140" format=""></item>
<item name="飞信号" code="FetionID" type="string" width="100" format=""></item>
<item name="备注" code="Local_name" type="string" width="200" format=""></item>
</data>

<data type="Message" datefilter="Date" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="发送人" code="Sender" type="string" width="100" format=""></item>
<item name="接收人" code="Target" type="string" width="100" format=""></item>
<item name="会话内容" code="Content" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order = "asc"></item>
<item name="消息类型" code="MsgType" type="Enum" format="EnumColumnType" width="60"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="Enum" format="EnumSendState"  show="false"></item>
</data>
</plugin>
[config]*/

//定义User数据结构
function User(){  
    this.Name = "";
    this.Impresa = "";
    this.Mobile = "";
    this.Sid = "";
    this.Registeremail = "";
    this.Birthdate = "";
    this.ID = "";
    this.Uri = "";
    this.DataState = "Normal";    
}

//定义分组
function Group(){
    this.Name = "";
    this.DataState = "Normal";
}

//定义联系人分组
function ContactGroup(){  
    this.Name = "";
    this.ID = "";
    this.OwerID = "";
    this.DataState = "Normal";    
}

//定义群分组
function DgGroup(){  
    this.Name = "";
    this.Uri = "";
    this.OwerID = "";
    this.DataState = "Normal";    
}

//定义讨论组分组
function PgGroup(){  
    this.Name = "";
    this.Uri = "";
    this.Introduction = "";
    this.OwerID = "";
    this.DataState = "Normal";    
}

//定义联系人数据结构
function Contact(){
    this.Name = "";
    this.ID = "";
    this.Sid = "";
    this.Local_name = "";
    this.Mobile = "";
    this.Impresa = "";
    this.Uri = "";
    this.OwerID = "";
    this.groupID = "";
    this.DataState = "Normal"; 
}

//定义会话数据结构
function Message(){
    this.Sender = "";
    this.Target = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
    this.Type = "";
    this.MsgType = "";
    this.SendState = "";
}
//定义树数据结构
function TreeNode() {
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

function bindTree(){
    var recoverydb1 = XLY.Sqlite.DataRecovery( db+"\\Library\\FetionData\\useraccount.db",charactor1,"useraccount");
    useraccount = eval('(' + XLY.Sqlite.FindByName(recoverydb1, 'useraccount') + ')');
    var fetion = new TreeNode();
    fetion.Text = "账户信息";
    fetion.Type = "User";
    var userinfo = getUser(db,useraccount);
    fetion.Items = userinfo;
    for(var i in userinfo){
        var user = new TreeNode();
        user.Text = userinfo[i].Mobile;
        user.Type = "Group";
        fetion.TreeNodes.push(user);
        Groupinfo(db,"联系人分组","ContactGroup",getContactGroup(db,userinfo[i]),user,userinfo[i]);
        Groupinfo(db,"讨论组","DgGroup",getDgGroup(db,userinfo[i]),user,userinfo[i]);
        Groupinfo(db,"群组","PgGroup",getPgGroup(db,userinfo[i]),user,userinfo[i]);
        
    }
    return fetion;
}

//获取分组及会话信息
function Groupinfo(path,name,type,groupinfo,root,rootinfo){
    root.Items.push(getGroup(name));
    var group = new TreeNode();
    group.Text = name;
    group.Type = type;
    group.Items = groupinfo;
    dbmessage = path+"\\Library\\FetionData\\"+rootinfo.ID+"\\chatdata.db";
    if(XLY.File.IsValid(dbmessage)){
        var recoverydb = XLY.Sqlite.DataRecovery(dbmessage,charactor5,"chatmessage");
        if(name=="联系人分组"){
            for(var i in groupinfo){
                var ctgroup = new TreeNode();
                ctgroup.Text = groupinfo[i].Name;
                ctgroup.Type = "Contact";
                ctgroup.DataState = groupinfo[i].DataState;
                dbcontact = path+"\\Library\\FetionData\\"+groupinfo[i].OwerID+"\\contactq3.db";
                if(!XLY.File.IsValid(dbcontact)){
                    dbcontact = path+"\\Library\\FetionData\\"+groupinfo[i].OwerID+"\\contact.db";
                }
                var recoverydb2 = XLY.Sqlite.DataRecovery( dbcontact,charactor2,"Contact,ContactGroup");
                var contact = new Array();
                if(groupinfo[i].DataState=="Normal" ){
                    contact = getContact(path,recoverydb2,groupinfo[i]);
                }else{
                    if(groupinfo[i].ID !=""){
                        contact = getContact(path,recoverydb2,groupinfo[i]);
                    }
                }
                ctgroup.Items = contact;
                group.TreeNodes.push(ctgroup);
                for(var j in contact){
                    var friend = new TreeNode(); 
                    friend.Text = contact[j].Name;
                    friend.Type = "Message";
                    friend.Items = getMessage(recoverydb,contact[j],rootinfo,"联系人会话");
                    friend.DataState = contact[j].DataState;
                    ctgroup.TreeNodes.push(friend);
                }
            }
        }else{
            if(XLY.File.IsValid(dbmessage)){
                for(var i in groupinfo){
                    var DPgroup = new TreeNode();
                    DPgroup.Text = groupinfo[i].Name;
                    DPgroup.Type = "Message";
                    DPgroup.Items = getMessage(recoverydb,groupinfo[i],rootinfo);    
                    DPgroup.DataState = groupinfo[i].DataState;
                    group.TreeNodes.push(DPgroup);
                }
            } 
        }
    }
    root.TreeNodes.push(group);
}

//获取用户信息
function getUser(path,data){
    var list = new Array;
    for(var i in data){
        var plist = path+"\\Library\\FetionData\\"+data[i].uid+"\\profile.plist";
        if(XLY.File.IsValid(plist)){
            var obj = new User();
            var user = eval('('+ XLY.PList.ReadToJsonString(plist) +')');           
            var userPro;
            var userProStr;
            for(var j in user){
                userPro = user[j];
                userProStr = JSON.stringify(userPro);
                if(userProStr.indexOf("nick") > 0){
                    obj.Name = userPro.nick;
                }
                else if(userProStr.indexOf("mobile") > 0){
                    obj.Mobile = userPro.mobile;
                }
                else if(userProStr.indexOf("impresa") > 0){
                    obj.Impresa = userPro.impresa;
                }
                else if(userProStr.indexOf("sid") > 0){
                    obj.Sid = userPro.sid;
                }
                else if(userProStr.indexOf("registeremail") > 0){
                    obj.Registeremail = userPro.registeremail;
                }
                else if(userProStr.indexOf("birth") > 0 && userProStr.indexOf("birth_perm") == -1){
                    obj.Birthdate = userPro.birth;
                }
                else if(userProStr.indexOf("uid") > 0){
                    obj.ID = userPro.uid;
                }
                else if(userProStr.indexOf("uri") > 0){
                    obj.Uri = userPro.uri;
                }
            }            

            if(obj.Name==""){
                obj.Name = obj.Mobile;
            }
            
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取分组
function getGroup(name){
    var obj = new Group();
    obj.Name = name;
    obj.DataState = "Normal";
    return obj;
}

//获取联系人分组名称
function getContactGroup(path,data){
    var list = new Array()
    var dbgroup = path+"\\Library\\FetionData\\"+data.ID+"\\contactq3.db";
    if(!XLY.File.IsValid(dbgroup)){
        dbgroup = path+"\\Library\\FetionData\\"+data.ID+"\\contact.db";
    }
    
    if(XLY.File.IsValid(dbgroup)){
        var recoverydb2 = XLY.Sqlite.DataRecovery( dbgroup,charactor2,"Contact,ContactGroup");
        group = eval('('+ XLY.Sqlite.FindByName(recoverydb2,'ContactGroup') +')');
        if(group.length>0){
            for(var i in group){
                var obj = new ContactGroup();
                obj.Name = group[i].name;
                obj.ID = group[i].groupID;
                obj.OwerID = data.ID;
                obj.DataState = XLY.Convert.ToDataState(group[i].XLY_DataType);
                list.push(obj);
            }
        }
    }
    return list;
}
 
//获取讨论组名称
function getDgGroup(path,data){
    var list = new Array();
    var dbgroup = path+"\\Library\\FetionData\\"+data.ID+"\\dggroup.db";
    if(XLY.File.IsValid(dbgroup)){
        var recoverydb3 = XLY.Sqlite.DataRecovery(dbgroup,charactor3,"dggroup");
        group = eval('('+ XLY.Sqlite.FindByName(recoverydb3,'dggroup') +')');
        if(group.length>0){
            for(var i in group){
                if((/sip+/gi).test(group[i].uri)){
                    var obj = new DgGroup();
                    obj.Name = group[i].name;
                    obj.Uri = group[i].uri;
                    obj.OwerID = data.ID;
                    obj.DataState = XLY.Convert.ToDataState(group[i].XLY_DataType);
                    list.push(obj);
                }
            }
        }
    }
    return list;
}

//获取群组名称
function getPgGroup(path,data){
    var list = new Array();
    var dbgroup = path+"\\Library\\FetionData\\"+data.ID+"\\pggroup.db";
    if(XLY.File.IsValid(dbgroup)){
        var recoverydb4 = XLY.Sqlite.DataRecovery(dbgroup,charactor4,"pggroup");
        group = eval('('+ XLY.Sqlite.FindByName(recoverydb4,'pggroup') +')');
        if(group.length>0){
            for(var i in group){
                if((/sip+/gi).test(group[i].uri)){
                    var obj = new PgGroup();
                    obj.Name = group[i].name;
                    obj.Uri = group[i].uri;
                    obj.Introduction = group[i].introduction;
                    obj.OwerID = data.ID;
                    obj.DataState = XLY.Convert.ToDataState(group[i].XLY_DataType);
                    list.push(obj); 
                }             
            }            
        }
    }
    return list;
}

//获取联系人
function getContact(path,path1,data){
    var list = new Array();
    dbcontact = path+"\\Library\\FetionData\\"+data.OwerID+"\\contactq3.db";
    if(!XLY.File.IsValid(dbcontact)){
        dbcontact = path+"\\Library\\FetionData\\"+data.ID+"\\contact.db";
    }

    if(XLY.File.IsValid(dbcontact)){
        if(data.ID != 0 && data.ID.length>0){
            contact = eval('('+ XLY.Sqlite.Find(path1,"select * from Contact where groupID = '"+data.ID+"'") +')');
        }else if(data.ID==0){
            contact = eval('('+ XLY.Sqlite.Find(path1,"select * from Contact where groupID ='' or groupID = 0") +')');
        }
        if(contact.length>0){
            for(var i in contact){
                if(contact[i].sid !=""){        
                    var obj = new Contact();
                    if(contact[i].nickName==""){
                        if(contact[i].mobileNumber==""){
                            obj.Name = contact[i].sid;
                        }else{
                            obj.Name = contact[i].mobileNumber;
                        }
                    }else{
                        obj.Name = contact[i].nickName;
                    }
                    obj.ID = contact[i].userID;
                    obj.Sid = contact[i].sid;
                    obj.Local_name = contact[i].localName;
                    obj.Mobile = contact[i].mobileNumber;
                    obj.Impresa = contact[i].impresa;
                    obj.Uri = contact[i].uri;
                    obj.OwerID = data.OwerID;
                    obj.DataState = XLY.Convert.ToDataState(contact[i].XLY_DataType);
                    list.push(obj);
                }
            }
        }
    }
    return list;
}

//获取会话信息
function getMessage(path,data,rootinfo,flag){
    if((/sip+/gi).test(data.Uri)){
        var message = eval("("+ XLY.Sqlite.Find(path,"select * from chatmessage where sessionUri = '"+data.Uri+"'") +")");
        var info = new Array();
        for(var i in message){
            if(message[i] != []){
                var obj = new Message();
                if(flag=="联系人会话"){
                    if(message[i].status==5){
                        obj.SendState = "Receive";
                        obj.Sender = data.Name;
                        obj.Target = rootinfo.Name;
                    }else{
                        obj.SendState = "Send";
                        obj.Sender = rootinfo.Name;
                        obj.Target = data.Name;
                    }
                }else{
                    if(message[i].status==5){
                        obj.SendState = "Receive";            
                    }else{
                        obj.SendState = "Send";
                    }    
                    obj.Sender = message[i].speakerName;
                    obj.Target = data.Name;
                }
                obj.Time = XLY.Convert.LinuxToDateTime(message[i].msgTime);
                
                if(message[i].msgContent != []){        
                    obj.Content = message[i].msgContent;
                }else{
                    obj.Content = message[i].orignalContent;
                }
                if((/^<object+\s+type="AUDIO\"/ig).test(message[i].orignalContent)){
                    obj.Type = "Audio";obj.MsgType = "音频";
                }else if((/^<object+\s+type=\"IMG\"/).test(message[i].orignalContent)){
                    obj.Type = "Image";obj.MsgType = "图片";
                }else{
                    obj.Type = "HTML";obj.MsgType = "文本";
                }
                obj.DataState = XLY.Convert.ToDataState(message[i].XLY_DataType);
                info.push(obj);
            }
        }
        return info;
    }
}

//********************************************************
var source = $source;
var db = source[0]+"\\cn.10086.feixin.fetion";
//var db = "C:\\XLYSFTasks\\未命名-2\\source\\IosData\\2015-10-13-16-34-06\\cn.10086.feixin.fetion";
//var db = "C:\\Users\\Administrator\\Desktop\\cn.10086.feixin.fetion";
var charactor1 = "\\chalib\\IOS_Fetion_V3.5.0\\useraccount.db.charactor";
var charactor2 = "\\chalib\\IOS_Fetion_V3.5.0\\contact.db.charactor";
var charactor3 = "\\chalib\\IOS_Fetion_V3.5.0\\dggroup.db.charactor";
var charactor4 = "\\chalib\\IOS_Fetion_V3.5.0\\pggoup.db.charactor";
var charactor5 = "\\chalib\\IOS_Fetion_V3.5.0\\chatdata.db.charactor";
var result = new Array();
result.push(bindTree());
var res = JSON.stringify(result);
res;
