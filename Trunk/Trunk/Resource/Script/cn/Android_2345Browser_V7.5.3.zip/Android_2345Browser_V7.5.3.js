﻿/*[config]
<plugin name="2345浏览器,4" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="\icons\2345Browser.png" app="com.browser2345" version="7.5.3" description="2345浏览器"  data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/com.browser2345/app_webview/Cookies</value>
<value>/data/data/com.browser2345/databases/2345db_2</value>
<value>/data/data/com.browser2345/databases/browser2.db</value>
<value>/data/data/com.browser2345/databases/downloads.db</value>
<value>/data/data/com.browser2345/databases/video.db</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Cookies" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="主键" code="Key" type="string" width = "150"></item>
<item name="名字" code="Name" type="string" width = "200"></item>
<item name="值" code="Value" type="string" width = "200"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="创建时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Bookmark" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="创建时间" code="Time" type="string" width = "200"></item>
</data>
<data type="History" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="访问次数" code="Visits" type="url" width = "150"></item>
<item name="创建时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Download" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="网址" code="Url" type="url" width = "200"></item>
<item name="名字" code="Name" type="string" width = "200"></item>
<item name="类型" code="Type" type="string" width = "150"></item>
<item name="路径" code="Path" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "150"></item>
<item name="总大小" code="TotalSize" type="string" width = "150"></item>
<item name="已下载大小" code="CurrentSize" type="string" width = "150"></item>
</data>
<data type="VideoHistory" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="更新时间" code="Time" type="string" width = "200"></item>
</data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function Search() {
    this.DataState = "Normal";
    this.Title = "";
    this.Time = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
}
function Download() {
    this.DataState = "Normal";
    this.Url = "";
    this.Name = "";
    this.Type = "";
    this.Time = "";
    this.TotalSize = "";
    this.CurrentSize = "";
    this.Path = "";
}
function VideoHistory() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}

//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}
function bindTree() {
    newTreeNode("Cookies", "Cookies", getCookies(db));
    newTreeNode("书签", "Bookmark", getBookmark(db2));
    newTreeNode("浏览记录", "History", getHistory(db2));
    newTreeNode("搜索", "Search", getSearch(db1));
    newTreeNode("下载文件", "Download", getDownload(db3));
    newTreeNode("视频播放记录", "VideoHistory", getVideoHistory(db4));
}
function getNews() {
    var list = new Array();
    data = ["Cookies", "书签", "浏览记录", "下载", "视频播放记录"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}


function getCookies(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies") + ')');
    for (var i in data) {
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from UrlEnter_InputRecord") + ')');
    for (var i in data) {
        var obj = new Search();
        obj.Title = data[i].Title;
        obj.Time = data[i].Date;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmarks ") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(lastmod as double)as time, * from downloads") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Url = data[i].uri;
        obj.Name = data[i].title;
        obj.Type = data[i].mimetype;
        obj.TotalSize = data[i].total_bytes / 1024 / 1024 + " MB";
        obj.CurrentSize = data[i].current_bytes / 1024 / 1024 + " MB";
        obj.Path = data[i].xly_data;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getVideoHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from video_history") + ')');
    for (var i in data) {
        var obj = new VideoHistory();
        obj.Title = data[i].name;
        obj.Url = data[i].page_url;
        obj.Time = data[i].update_time;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
////********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
var db2 = source[2];
var db3 = source[3];
var db4 = source[4];

var charactor = "\\chalib\\Android_2345Browser_V7.5.3\\Cookies.charactor";
var charactor1 = "\\chalib\\Android_2345Browser_V7.5.3\\2345db_2.charactor";
var charactor2 = "\\chalib\\Android_2345Browser_V7.5.3\\browser2.db.charactor";
var charactor3 = "\\chalib\\Android_2345Browser_V7.5.3\\downloads.db.charactor";
var charactor4 = "\\chalib\\Android_2345Browser_V7.5.3\\video.db.charactor";

var db = XLY.Sqlite.DataRecovery(db, charactor, "cookies");
var db1 = XLY.Sqlite.DataRecovery(db1, charactor1, "UrlEnter_InputRecord");
var db2 = XLY.Sqlite.DataRecovery(db2, charactor2, "bookmarks,history");
var db3 = XLY.Sqlite.DataRecovery(db3, charactor3, "downloads");
var db4 = XLY.Sqlite.DataRecovery(db4, charactor4, "video_history");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
