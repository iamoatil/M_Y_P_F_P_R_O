﻿/*[config]
<plugin name="TurboVPN,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/tubo.png" app="free.vpn.unblock.proxy.turbovpn" version="1.8.2" description="TurboVPN" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/free.vpn.unblock.proxy.turbovpn/shared_prefs#F</value>
    <value>/data/data/free.vpn.unblock.proxy.turbovpn/files#F</value>
</source>
<data type="UserInfo" contract = "DataState" detailfield = "PrefVpn">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="VPN启动时是否自动连接" code="ConnectAuto" type="string" width = "100"></item>
    <item name="连接次数" code="ConnectCount" type="string" width = "100"></item>
    <item name="是否首次连接" code="IsFirstConnect" type="string" width = "100"></item>
    <item name="设备名称" code="PrefVpn" type="string" width = "80"></item>
    <item name="设备MAC" code="DeviceMAC" type="string" width = "80"></item>
    <item name="设备IMEI" code="DeviceImei" type="string" width = "80"></item>
    <item name="设备序列号" code="DeviceXLH" type="string" width = "80"></item>
    <item name="AndroidID" code="AndroidID" type="string" width = "80"></item>
    <item name="当前是否正在使用" code="IsUseServe" type="string" width = "80"></item>
    <item name="最后请求服务器ip" code="LastReqIP" type="string" width = "80"></item>
    <item name="最后使用端口" code="LastPort" type="string" width = "80"></item>
    <item name="最后使用协议" code="LastProto" type="string" width = "100"></item>
    <item name="请求失败次数" code="FailedRequests" type="string" width = "80"></item>
    <item name="请求成功次数" code="SuccessfulRequests" type="string" width = "80"></item>
    <item name="首次连接服务器时间" code="FirstReqTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后请求服务器时间" code="LastReqTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="是否限制广告跟踪" code="IsLimitAdTracking" type="string" width = "80"></item>
    <item name="服务器列表" code="ServerList" type="string" width = "120"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.ConnectAuto = "否";
    this.ConnectCount = "";
    this.IsFirstConnect = "否";
    this.PrefVpn = "";
    this.DeviceMAC = "";
    this.DeviceImei = "";
    this.DeviceXLH = "";
    this.AndroidID = "";
    this.IsUseServe = "否";
    this.LastReqIP = "";
    this.LastPort = "";
    this.LastProto = "";
    this.FailedRequests = "";
    this.FirstReqTime = null;
    this.LastReqTime = null;
    this.IsLimitAdTracking = "否";
    this.ServerList = "";
    this.SuccessfulRequests = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];
var allPathAdd = source[0];

//测试数据
//var allPath = "D:\\temp\\data\\data\\free.vpn.unblock.proxy.turbovpn\\shared_prefs";
//var allPathAdd = "D:\\temp\\data\\data\\free.vpn.unblock.proxy.turbovpn\\files";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "TurboVPN";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Text = "VPN连接信息"
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    
    var countryPath = allPathAdd+"\\country.json";
    if(XLY.File.IsValid(countryPath)){
        var conData = XLY.File.ReadFile(countryPath);
        if(conData!=""&&conData!=null){
            //log(conData.substr(1,conData.length-2).split(",")[0].split(":")[0].substr(1,2));
            obj.ServerList = conData;
        }
    }
    var umePath = allPathAdd+"\\umeng_it.cache";
    if(XLY.File.IsValid(umePath)){
        var arr = getBianaryDeviceInfo(umePath);
        obj.DeviceMAC = arr.mac;
        obj.DeviceImei = arr.imei;
        obj.DeviceXLH = arr.serial;
        obj.AndroidID = arr.android_id;
    }
    var meaPath = allPath+"\\com.google.android.gms.measurement.prefs.xml";
    if(XLY.File.IsValid(meaPath)){
        var meaData = eval('('+ XLY.File.ReadXML(meaPath) +')');
        if(meaData!=""&&meaData!=null){
            if(meaData.map!=""&&meaData.map!=null){
                var mmeaData = meaData.map.boolean;
                if(mmeaData!=""&&mmeaData!=null){
                    for(var m in mmeaData){
                        if(mmeaData[m]["@name"]=="use_service"){
                            if(mmeaData[m]["@value"]=="true"){
                                obj.IsUseServe = "是";
                            }
                        }
                    }
                }
            }
        }
    }
    var sdkPath = allPath+"\\SDKIDFA.xml";
    if(XLY.File.IsValid(sdkPath)){
        var sdkData = eval('('+ XLY.File.ReadXML(sdkPath) +')');
        if(sdkData!=""&&sdkData!=null){
            if(sdkData.map!=""&&sdkData.map!=null){
                var sdkBoolData = sdkData.map.boolean;
                if(sdkBoolData!=""&&sdkBoolData!=null){
                    if(sdkBoolData["@value"]=="true"){
                        obj.IsLimitAdTracking = "是";
                    }
                }
            }
        }
    }
    var generPath = allPath+"\\umeng_general_config.xml";
    if(XLY.File.IsValid(generPath)){
        var generData = eval('('+ XLY.File.ReadXML(generPath) +')');
        if(generData!=""&&generData!=null){
            if(generData.map!=""&&generData.map!=null){
                var sdkIntData = generData.map.int;
                var sdkLongData = generData.map.long;
                if(sdkIntData!=""&&sdkIntData!=null){
                    for(var i in sdkIntData){
                        if(sdkIntData[i]["@name"]=="failed_requests"){
                            obj.FailedRequests = sdkIntData[i]["@value"];
                        }
                        if(sdkIntData[i]["@name"]=="successful_request"){
                            obj.SuccessfulRequests = sdkIntData[i]["@value"];
                        }
                    }
                }
                if(sdkLongData!=""&&sdkLongData!=null){
                    for(var j in sdkLongData){
                        if(sdkLongData[j]["@name"]=="last_request_time"){
                            obj.LastReqTime = XLY.Convert.LinuxToDateTime(sdkLongData[j]["@value"]);
                        }
                        if(sdkLongData[j]["@name"]=="first_activate_time"){
                            obj.FirstReqTime = XLY.Convert.LinuxToDateTime(sdkLongData[j]["@value"]);
                        }
                    }
                }
            }
        }
    }
    var vpnPrePath = allPath+"\\vpn.prefs.xml";
    if(XLY.File.IsValid(vpnPrePath)){
        var vpnPreData = eval('('+ XLY.File.ReadXML(vpnPrePath) +')');
        if(vpnPreData!=""&&vpnPreData!=null){
            if(vpnPreData.map!=""&&vpnPreData.map!=null){
                var vpnPreIntData = vpnPreData.map.int;
                var vpnPreStringData = vpnPreData.map.string;
                if(vpnPreIntData!=""&&vpnPreIntData!=null){
                    if(vpnPreIntData["@value"]!=""&&vpnPreIntData["@value"]!=null){
                        obj.LastPort = vpnPreIntData["@value"];
                    }
                }
                if(vpnPreStringData!=""&&vpnPreStringData!=null){
                    for(var e in vpnPreStringData){
                        if(vpnPreStringData[e]["@name"]=="last_proto"){
                            obj.LastProto = vpnPreStringData[e]["#text"];
                        }
                        if(vpnPreStringData[e]["@name"]=="last_ip"){
                            obj.LastReqIP = vpnPreStringData[e]["#text"];
                        }
                    }
                }
            }
        }
    }
    var sdmobPath = allPath+"\\admob_user_agent.xml";
    if(XLY.File.IsValid(sdmobPath)){
        var sdmobData = eval('('+ XLY.File.ReadXML(sdmobPath) +')');
        if(sdmobData!=""&&sdmobData!=null){
            if(sdmobData.map!=""&&sdmobData.map!=null){
                var ssdmodData = sdmobData.map.string;
                if(ssdmodData!=""&&ssdmodData!=null){
                    if(ssdmodData["#text"]!=""&&ssdmodData["#text"]!=null){
                        obj.PrefVpn = ssdmodData["#text"];
                    }
                }
            }
        }
    }
    var appPath = allPath+"\\app.prefs.xml";
    if(XLY.File.IsValid(appPath)){
        var appData = eval('('+ XLY.File.ReadXML(appPath) +')');
        if(appData!=""&&appData!=null){
            if(appData.map!=""&&appData.map!=null){
                var aappData = appData.map.boolean;
                var aappLongData = appData.map.long;
                if(aappLongData!=""&&aappLongData!= null){
                    for(var z in aappLongData){
                        if(aappLongData[z]["@name"]=="connected_count"){
                            obj.ConnectCount = aappLongData[z]["@value"];
                        }
                    }
                }
                if(aappData!=""&&aappData!=null){
                    for(var p in aappData){
                        if(aappData[p]["@name"]=="first_time_connect"){
                            if(aappData[p]["#text"]=="true"){
                                obj.IsFirstConnect = "是";
                            }
                        }
                        if(aappData[p]["@name"]=="connect_when_vpn_starts"){
                            if(aappData[p]["#text"]=="true"){
                                obj.ConnectAuto = "是";
                            }
                        }
                    }
                }
            }
        }
    }
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}
function getBianaryDeviceInfo(path){
    var handle = XLY.Blob.GetFileHandle(path);
    var aa = [0x73,0x65,0x72,0x69,0x61,0x6C];
    var bb = [0x61,0x6E,0x64,0x72,0x6F,0x69,0x64,0x5F,0x69,0x64];
    var cc = [0x6D,0x61,0x63];
    var dd = [0x69,0x6D,0x65,0x69];
    var a = XLY.Blob.FindBytesFromHandle(handle,0,aa);
    var b = XLY.Blob.FindBytesFromHandle(handle,0,bb);
    var c = XLY.Blob.FindBytesFromHandle(handle,0,cc);
    var d = XLY.Blob.FindBytesFromHandle(handle,0,dd);
    var arr = {};
    if(a!=-1){
        var aaa = XLY.Blob.GetBytesFromHandle(handle,a+8,XLY.Blob.GetBytesFromHandle(handle,a+7,1)[0]);
        arr.serial = XLY.Blob.ToString(aaa);
    }
    if(b!=-1){
        var bbb = XLY.Blob.GetBytesFromHandle(handle,b+0x0C,XLY.Blob.GetBytesFromHandle(handle,b+0x0B,1)[0]);
        arr.android_id = XLY.Blob.ToString(bbb);
    }
    if(c!=-1){
        var ccc = XLY.Blob.GetBytesFromHandle(handle,c+5,XLY.Blob.GetBytesFromHandle(handle,c+4,1)[0]);
        arr.mac = XLY.Blob.ToString(ccc);
    }
    if(d!=-1){
        var ddd = XLY.Blob.GetBytesFromHandle(handle,d+6,XLY.Blob.GetBytesFromHandle(handle,d+5,1)[0]);
        arr.imei = XLY.Blob.ToString(ddd);
    }
    XLY.Blob.CloseFileHandle(handle);
    return arr;
}