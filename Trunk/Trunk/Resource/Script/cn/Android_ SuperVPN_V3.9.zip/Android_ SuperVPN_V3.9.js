﻿/*[config]
<plugin name="SuperVPN1,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/supervpncheng.png" app="com.chengcheng.FreeVPN" version="3.9" description="SuperVPN1" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.chengcheng.FreeVPN/shared_prefs#F</value>
    <value>/data/data/com.chengcheng.FreeVPN/files/PanelInfo</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="设备信息" code="DeviceInfo" type="string" width = "100"></item>
    <item name="是否成功连接" code="IsConnect" type="string" width = "100"></item>
    <item name="是否自动收集位置" code="IsAutoCollectLocation" type="string" width = "80"></item>
    <item name="是否显示广告" code="IsShowAd" type="string" width = "80"></item>
    <item name="是否VIP" code="IsVIP" type="string" width = "80"></item>
    <item name="是否显示内容提示" code="IsShowCT" type="string" width = "80"></item>
    <item name="是否开启更新检查" code="IsUpdateChecker" type="string" width = "80"></item>
    <item name="过期时间" code="ExpTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
</data>
<data type="VpnList" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="VPN名称" code="VPNName" type="string" width = "100"></item>
    <item name="ID" code="Id" type="string" width = "100"></item>
    <item name="图标名称" code="IconName" type="string" width = "80"></item>
    <item name="VPN ID" code="VpnId" type="string" width = "80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.DeviceInfo = "";
    this.IsConnect = "否";
    this.IsAutoCollectLocation = "否";
    this.IsShowAd = "否";
    this.IsVIP = "否";
    this.IsShowCT = "否";
    this.IsUpdateChecker = "否";
    this.ExpTime = null;
}
function VpnList(){
    this.DataState = "Normal";
    this.VPNName = "";
    this.Id = "";
    this.IconName = "";
    this.VpnId = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];
var filePath = source[1];

//测试数据
//var allPath = "F:\\temp\\data\\data\\com.chengcheng.FreeVPN\\shared_prefs";
//var filePath = "F:\\temp\\data\\data\\com.chengcheng.FreeVPN\\files\\PanelInfo";
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "SuperVPN(chengcheng)";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Text = "VPN信息";
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    
    
    var admPath = allPath+"\\admob.xml";
    if(XLY.File.IsValid(admPath)){
        var admData = eval('('+ XLY.File.ReadXML(admPath) +')');
        if(admData!=""&&admData!= null){
            var admBoolData = admData.map.boolean;
            if(admBoolData!=""&&admBoolData!=null){
                for(var a in admBoolData){
                    if(admBoolData[a]["@name"]=="auto_collect_location"){
                        if(admBoolData[a]["@value"]=="true"){
                            obj.IsAutoCollectLocation = "是";
                        }
                    }
                }
            }
        }
    }
    var admuPath = allPath+"\\admob_user_agent.xml";
    if(XLY.File.IsValid(admuPath)){
        var admuData = eval('('+ XLY.File.ReadXML(admuPath) +')');
        if(admuData!=""&&admuData!= null){
            var admStrData = admuData.map.string;
            if(admStrData!=""&&admStrData!=null){
                if(admStrData["#text"]!=""&&admStrData["#text"]!=null){
                    obj.DeviceInfo = admStrData["#text"];
                }
            }
        }
    }
    if(XLY.File.IsValid(filePath)){
        var data = eval('('+ XLY.File.ReadFile(filePath) +')');
        if(data!=""&&data!= null){
            getVPNList(usernode,data.vpn_list);
            if(data.is_show_ad=="true"){
                obj.IsShowAd = "是";
            }
            if(data.succ=="true"){
                obj.IsConnect = "是";
            }
            if(data.is_vip=="true"){
                obj.IsVIP = "是";
            }
            if(data.show_comment_tip=="true"){
                obj.IsShowCT = "是";
            }
            if(data.update_checker=="true"){
                obj.IsUpdateChecker = "是";
            }
            obj.ExpTime = XLY.Convert.LinuxToDateTime(data.deadtime);
        }
    }
    usernode.Items.push(obj);
    root.TreeNodes.push(usernode);
}
function getVPNList(root,data){
    var node = new TreeNode();
    node.Text = "VPN列表";
    node.Type = "VpnList";
    for(var i in data){
        var obj = new VpnList();
        obj.VPNName = data[i].name;
        obj.Id = data[i].id;
        obj.IconName = data[i].icon_name;
        obj.VpnId = data[i].vpn_id;
        node.Items.push(obj);
    }
    root.TreeNodes.push(node);
}