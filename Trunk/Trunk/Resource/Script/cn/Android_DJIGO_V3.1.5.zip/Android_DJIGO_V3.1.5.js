﻿/*[config]
<plugin name="DJI GO,8" group="生活旅游,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/dji.png" app="dji.pilot" version="3.1.5" description="DJI GO" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/dji.pilot/shared_prefs/dji.pilot.xml</value>
    <value>/data/data/dji.pilot/databases/dji.db</value>
    <value>/data/data/dji.pilot/files/user_avatar.png</value>
    <value>SDCard:/DJI/dji.pilot#F</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="AccountID" type="string" width="150"></item>
    <item name="用户ID" code="ID" type="string" width="150"></item>
    <item name="用户昵称" code="NickName" type="string" width="150"></item>
    <item name="头像" code="HeadUrl" type="url" width="300"></item>
    <item name="飞行记录次数" code="FlyRecordNum" type="string" width = "80"></item>
    <item name="最后一次DPS定位" code="DjiLastAirPoint" type="string" width = "200"></item>
    <item name="国家代码" code="CodeTag" type="string" width = "200"></item>
    <item name="邮箱" code="AccountEmail" type="string" width = "200"></item>
    <item name="版本" code="FlyVersior" type="string" width = "200"></item>
</data>
<data type="Dynamic" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者昵称" code="SenderName" type="string" width="150"></item>
    <item name="发送者头像" code="SenderUrl" type="url" width="150"></item>
    <item name="标题" code="Title" type="string" width="150"></item>
    <item name="内容链接" code="ContentUrl" type="url" width="150"></item>
    <item name="模型名称" code="ModelName" type="string" width="150"></item>
    <item name="经度" code="Lng" type="string" width="80"></item>
    <item name="纬度" code="Lat" type="string" width = "80"></item>
    <item name="是否公开" code="IsPublic" type="string" width = "80"></item>
    <item name="类型" code="ContentType" type="string" width = "80"></item>
    <item name="定位" code="AccountLocation" type="string" width = "80"></item>
    <item name="标签" code="Tag" type="string" width = "80"></item>
    <item name="发布时间" code="SendTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="更新时间" code="UpdateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="是否VIP" code="IsVip" type="string" width = "80"></item>
    <item name="查看" code="ViewCount" type="string" width = "80"></item>
    <item name="点赞" code="LikeCount" type="string" width = "80"></item>
    <item name="评论" code="CommentCount" type="string" width = "80"></item>
    <item name="收藏" code="FavoriteCount" type="string" width = "80"></item>
    <item name="是否点赞" code="IsLike" type="string" width = "80"></item>
    <item name="是否关注" code="IsFollow" type="string" width = "80"></item>
    <item name="是否收藏" code="IsFavorite" type="string" width = "80"></item>
</data>
<data type="PhotoGraph" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="开始时间" code="PhotoGraphTime" type="string" width="150"></item>
    <item name="源文件路径" code="SourcePath" type="url" width="150"></item>
    <item name="时长" code="EndTimeMsec" type="string" width="150"></item>
    <item name="文件名" code="FileName" type="url" width="150"></item>
    <item name="是否高清" code="IsHD" type="string" width="150"></item>
    <item name="经度" code="Lng" type="string" width="300"></item>
    <item name="纬度" code="Lat" type="string" width = "80"></item>
</data>
<data type="Log" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="时间" code="Time" type="string" width="150"></item>
    <item name="内容" code="Content" type="string" width="150"></item>
</data>
<data type="Creation" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="文件路径" code="FilePath" type="string" width="150"></item>
    <item name="分享链接" code="ShareUrl" type="url" width="150"></item>
    <item name="标题" code="Title" type="string" width = "120"></item>
    <item name="类型" code="Type" type="string" width="80"></item>
    <item name="描述" code="Description" type="string" width="150"></item>
    <item name="创建时间" code="CreateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="文件时长" code="Duration" type="string" width="80"></item>
    <item name="用户邮箱" code="UserEmail" type="string" width="150"></item>
</data>
</plugin>
[config]*/
function Creation(){
    this.DataState = "Normal";
    this.FilePath = "";
    this.ShareUrl = "";
    this.Title = "";
    this.Description = "";
    this.CreateTime = null;
    this.Duration = "";
    this.UserEmail = "";
    this.Type = "";
}
function Log(){
    this.DataState = "Normal";
    this.Time = "";
    this.Content = "";
}
function PhotoGraph(){
    this.DataState = "Normal";
    this.PhotoGraphTime = "";
    this.SourcePath = "";
    this.EndTimeMsec = "";
    this.FileName = "";
    this.IsHD = "";
    this.Lng = "";
    this.Lat = "";
}
function Dynamic(){
    this.DataState = "Normal";
    this.SenderName = "";
    this.SenderUrl = "";
    this.Title = "";
    this.ContentUrl = "";
    this.ModelName = "";
    this.Lng = "";
    this.Lat = "";
    this.IsPublic = "";
    this.ContentType = "";
    this.AccountLocation = "";
    this.Tag = "";
    this.IsVip = "";
    this.ViewCount = "";
    this.LikeCount = "";
    this.CommentCount = "";
    this.FavoriteCount = "";
    this.IsLike = "";
    this.IsFollow = "";
    this.IsFavorite = "";
    this.SendTime = null;
    this.UpdateTime = null;
}
//定义数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.AccountID = "";
    this.ID = "";
    this.NickName = "";
    this.HeadUrl = "";
    this.FlyRecordNum = "";
    this.DjiLastAirPoint = "";
    this.CodeTag = "";
    this.AccountEmail = "";
    this.FlyVersior = "";
}

function News(){
    this.DataState = "Normal";
    this.List = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var fpath = source[0];
var dpath = source[1];
var avatarPath = source[2];
var spath = source[3];
//测试数据
//var fpath = "D:\\temp1\\data\\data\\dji.pilot\\shared_prefs\\dji.pilot.xml";
//var dpath = "D:\\temp2\\data\\data\\dji.pilot\\databases\\dji.db";
//var avatarPath = "D:\\temp1\\data\\data\\dji.pilot\\files\\user_avatar.png";
//var spath = "D:\\temp1\\data\\data\\DJI\\dji.pilot";
//
//定义特征库文件
var charactor = "chalib\\Android_Chelaile_V3.24.2\\com.ygkj.chelaile.db.charactor";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "DJI GO";
    root.Type = "";
    getNews(root);
    
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(fpath)){
        var info = eval('('+ XLY.File.ReadXML(fpath) +')');
        var data = info.map.string;
        var num = info.map.int;
        
        if(data!=""&&data!= null){
            var obj = new UserInfo();
            if(XLY.File.IsValid(avatarPath)){
                obj.HeadUrl = avatarPath;
            }
            if(num!=""&&num!=null){
                for(var j in num){
                    if(num[j]["@name"]=="fly_recordnum"){
                        obj.FlyRecordNum = num[j]["#value"];
                    }
                }
            }
            for(var i in data){
                if(data[i]["@name"]=="key_account_id"){
                    var aa = XLY.Blob.ToBytes(data[i]["#text"],"base64");
                    obj.ID = XLY.Blob.ToString(aa);
                }
                if(data[i]["@name"]=="key_account_nickname"){
                    var aa = XLY.Blob.ToBytes(data[i]["#text"],"base64");
                    obj.NickName = XLY.Blob.ToString(aa);
                }
                if(data[i]["@name"]=="key_account_email"){
                    var aa = XLY.Blob.ToBytes(data[i]["#text"],"base64");
                    obj.AccountEmail = XLY.Blob.ToString(aa);
                }
                if(data[i]["@name"]=="key_xg_lang_code_tag"){
                    obj.CodeTag = data[i]["#text"];
                }
                if(data[i]["@name"]=="key_account_uid"){
                    var aa = XLY.Blob.ToBytes(data[i]["#text"],"base64");
                    obj.AccountID = XLY.Blob.ToString(aa);
                }
                if(data[i]["@name"]=="key_cur_airmap_flyforbid_version"){
                    obj.FlyVersior = data[i]["#text"];
                }
                if(data[i]["@name"]=="DJILastAirPoint"){
                    obj.DjiLastAirPoint = data[i]["#text"];
                }
                
            }
            var node = new TreeNode();
            node.Text = obj.AccountID+"_"+obj.NickName;
            node.Type = "UserInfo";
            node.Items.push(obj);
            getUserChildNode(node,data);
            root.TreeNodes.push(node);
        }
    }
}
function getUserChildNode(root,info){
    var reg = new RegExp("controller_cache_first_page_content");
    var node = new TreeNode();
    node.Text = "天空之城";
    node.Type = "Dynamic";
    for(var i in info){
        if(reg.test(info[i]["@name"])){
           var aa = eval('('+ info[i]["#text"] +')');
           if(aa.items!=""&&aa.items!= null){
               for(var j in aa.items){
                   var obj = new Dynamic();
                   obj.SenderName = aa.items[j].account_name;
                   obj.SenderUrl = aa.items[j].account_avatar;
                   obj.Title = aa.items[j].title;
                   obj.ContentUrl = aa.items[j].thumb_l_url;
                   obj.ModelName = aa.items[j].model;
                   obj.Lng = aa.items[j].lng;
                   obj.Lat = aa.items[j].lat;
                   obj.IsPublic = aa.items[j].is_public;
                   obj.ContentType = aa.items[j].type;
                   obj.AccountLocation = aa.items[j].account_location;
                   var bb = "";
                   if(aa.items[j].tags_count!=0){
                       for(var m in aa.items[j].tags){
                           if(m==aa.items[j].tags_count-1){
                               bb += aa.items[j].tags[m].name;
                           }
                           else
                           {
                               bb += aa.items[j].tags[m].name+",";
                           }
                       }
                   }
                   obj.Tag = bb;
                   if(aa.items[j].is_vip=="False"){
                       obj.IsVip = "否";
                   }
                   else
                   {
                       obj.IsVip = "是";
                   }
                   obj.SendTime = XLY.Convert.LinuxToDateTime(aa.items[j].created_at);
                   obj.UpdateTime = XLY.Convert.LinuxToDateTime(aa.items[j].updated_at);
                   obj.ViewCount = aa.items[j].views_count;
                   obj.LikeCount = aa.items[j].likes_count
                   obj.CommentCount = aa.items[j].comments_count;
                   obj.FavoriteCount = aa.items[j].favorites_count;
                   if(aa.items[j].is_liked=="False"){
                       obj.IsLike = "否";
                   }
                   else
                   {
                       obj.IsLike = "是";
                   }
                   if(aa.items[j].is_favorited=="False"){
                       obj.IsFavorite = "否";
                   }
                   else
                   {
                       obj.IsFavorite = "是";
                   }
                   if(aa.items[j].is_follow=="False"){
                       obj.IsFavorite = "否";
                   }
                   else
                   {
                       obj.IsFavorite = "是";
                   }
                   node.Items.push(obj);
               }
           }
        }
    }
    if(node.Items!=""&&node.Items!=null){
        root.TreeNodes.push(node);
    }
    var folderPath = spath+"\\DJI_RECORD";
    var fileReg = new RegExp(".info");
    var fileName = eval('('+ XLY.File.FindFileNamesWithExtension(folderPath) +')');
    
    var editorNode = new TreeNode();
    editorNode.Text = "编辑器";
    editorNode.Type = "";
    
    var pictureNode = new TreeNode();
    pictureNode.Text = "图库";
    pictureNode.Type = "";
    
    var creationNode = new TreeNode();
    creationNode.Text = "创作";
    creationNode.Type = "Creation";
    if(XLY.File.IsValid(dpath)){
        var draftBean = eval('('+ XLY.Sqlite.Find(dpath,"select * from dji_pilot2_mine_db_DraftBean") +')');
        if(draftBean!=""&&draftBean!=null){
            for(var d in draftBean){
                var objDr = new Creation();
                //objDr.DataState = XLY.Convert.ToDataState(draftBean[d].XLY_DataType);
                objDr.FilePath = draftBean[d].filePath;
                objDr.ShareUrl = draftBean[d].shareUrl;
                objDr.Title = draftBean[d].title;
                objDr.Description = draftBean[d].description;
                objDr.CreateTime = XLY.Convert.LinuxToDateTime(draftBean[d].createTime);
                objDr.Duration = draftBean[d].duration;
                objDr.UserEmail = draftBean[d].userEmail;
                objDr.Type = draftBean[d].type;
                creationNode.Items.push(objDr);
            }
        }
    }
    
    var videoNode = new TreeNode();
    videoNode.Text = "视频";
    videoNode.Type = "PhotoGraph";
    
    var photoNode = new TreeNode();
    photoNode.Text = "照片";
    photoNode.Type = "";
    
    var favoriteNode = new TreeNode();
    favoriteNode.Text = "收藏";
    favoriteNode.Type = "";
    
    var PhotoGraphTimeReg = new RegExp("CaptureDate=");
    var Is_HDReg = new RegExp("Is_HD=");
    var EndTimeMsecReg = new RegExp("EndTimeMsec=");
    var LocalFileNameReg = new RegExp("LocalFileName=");
    var PositionGPSLatReg = new RegExp("PositionGPSLat=");
    var PositionGPSLngReg = new RegExp("PositionGPSLng=");
    if(fileName!=""&&fileName!=null){
        for(var f in fileName){
            if(fileReg.test(fileName[f])){
                var infoFilePath = folderPath + "\\"+fileName[f];
                if(XLY.File.IsValid(infoFilePath)){
                    var infoFileContent = XLY.File.ReadFile(infoFilePath).split("\r\n");
                    if(infoFileContent!=""&&infoFileContent!=null){
                        var aa = infoFileContent[0].split("\n");
                        if(aa!=""&&aa!=null){
                            var fur = infoFilePath.substr(0,infoFilePath.length-4)+"mp4";
                            var fileObj = new PhotoGraph();
                            if(XLY.File.IsValid(fur)){
                                fileObj.SourcePath = fur;
                            }
                            for(var p in aa){
                                if(PhotoGraphTimeReg.test(aa[p])){
                                    fileObj.PhotoGraphTime = aa[p].substr(12,aa[p].length);
                                }
                                if(Is_HDReg.test(aa[p])){
                                    if(aa[p].substr(6,aa[p].length)=='false'){
                                        fileObj.IsHD = "否";
                                    }
                                    else
                                    {
                                        fileObj.IsHD = "是";
                                    }
                                }
                                if(EndTimeMsecReg.test(aa[p])){
                                    fileObj.EndTimeMsec = aa[p].substr(12,aa[p].length)/1000+" 秒";
                                }
                                if(LocalFileNameReg.test(aa[p])){
                                    fileObj.FileName = aa[p].substr(14,aa[p].length);
                                }
                                if(PositionGPSLatReg.test(aa[p])){
                                    fileObj.Lat = aa[p].substr(15,aa[p].length);
                                }
                                if(PositionGPSLngReg.test(aa[p])){
                                    fileObj.Lng = aa[p].substr(15,aa[p].length);
                                }
                            }
                            videoNode.Items.push(fileObj);
                        }
                    }
                    
                }
            }
        }
    }
    pictureNode.TreeNodes.push(videoNode);
    pictureNode.TreeNodes.push(photoNode);
    pictureNode.TreeNodes.push(favoriteNode);
    editorNode.TreeNodes.push(pictureNode);
    editorNode.TreeNodes.push(creationNode);
    root.TreeNodes.push(editorNode);
    
    
    var logNode = new TreeNode();
    logNode.Text = "日志";
    logNode.Type = "";
    
    var cacheLogNode = new TreeNode();
    cacheLogNode.Text = "缓存日志";
    cacheLogNode.Type = "Log";
    
    var errLogNode = new TreeNode();
    errLogNode.Text = "错误日志";
    errLogNode.Type = "Log";
    
    var errorLogPath = spath+"\\LOG\\ERROR_POP_LOG";
    var cacheLogPath = spath+"\\LOG\\CACHE";
    var errorLogFile = eval('('+ XLY.File.FindFileNamesWithExtension(errorLogPath) +')');
    if(errorLogFile!=""&&errorLogFile!=null){
        for(var e in errorLogFile){
            var errDataFilePath = errorLogPath+"\\"+errorLogFile[e];
            var errorDataLog = XLY.File.ReadFile(errDataFilePath);
            var err = errorDataLog.split("\r\n");
            for(var r in err){
                 var logObj = new Log();
                 logObj.Time = err[r].split("\n")[0];
                 logObj.Content = err[r].split("\n")[1];
                 if(logObj.Time!=""&&logObj.Time!=null){
                     errLogNode.Items.push(logObj);
                 }
            }
        }
    }
    logNode.TreeNodes.push(cacheLogNode);
    var cacheLogFile = eval('('+ XLY.File.FindDirectories(cacheLogPath) +')');
    if(cacheLogFile!=""&&cacheLogFile!= null){
        for(var c in cacheLogFile){
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="active"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                             var logObj = new Log();
                             logObj.Time = cat[t].split("@")[0];
                             logObj.Content = cat[t].split("@")[1];
                             if(logObj.Time!=""&&logObj.Time!=null){
                                 childNode.Items.push(logObj);
                             }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="BLELog"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                             var logObj = new Log();
                             logObj.Content = cat[t];
                             if(logObj.Content!=""&&logObj.Content!=null){
                                 childNode.Items.push(logObj);
                             }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="popup"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                             var logObj = new Log();
                             logObj.Time = cat[t].split("@")[0];
                             logObj.Content = cat[t].split("@")[1];
                             if(logObj.Time!=""&&logObj.Time!=null){
                                 childNode.Items.push(logObj);
                             }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="ServerLog"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                            var logObj = new Log();
                            logObj.Content = cat[t];
                            if(logObj.Content!=""&&logObj.Content!=null){
                                childNode.Items.push(logObj);
                            }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="UP_Default"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                            var logObj = new Log();
                            logObj.Content = cat[t].split("@")[1];
                            if(logObj.Content!=""&&logObj.Content!=null){
                                childNode.Items.push(logObj);
                            }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="UpgradeLog"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                            var logObj = new Log();
                            logObj.Content = cat[t];
                            if(logObj.Content!=""&&logObj.Content!=null){
                                childNode.Items.push(logObj);
                            }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
            if(cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1)=="VerPhone"){
                var cacheLogFileFolder = cacheLogFile[c];
                var childNode = new TreeNode();
                childNode.Text = cacheLogFile[c].substr(cacheLogPath.length+1,cacheLogFile[c].length-1);
                childNode.Type = "Log";
                
                var cacheLogFileChild = eval('('+ XLY.File.FindFileNamesWithExtension(cacheLogFileFolder) +')');
                if(cacheLogFileChild!=""&&cacheLogFileChild!=null){
                    for(var q in cacheLogFileChild){
                        var caDataFilePath = cacheLogFileFolder+"\\"+cacheLogFileChild[q];
                        var caDataLog = XLY.File.ReadFile(caDataFilePath);
                        var cat = caDataLog.split("\r\n");
                        for(var t in cat){
                             var logObj = new Log();
                             logObj.Time = cat[t].split("@")[0];
                             logObj.Content = cat[t].split("@")[1];
                             if(logObj.Time!=""&&logObj.Time!=null){
                                 childNode.Items.push(logObj);
                             }
                        }
                    }
                }
                if(childNode.Items!=""&&childNode.Items!=null){
                    cacheLogNode.TreeNodes.push(childNode);
                }
            }
        }
    }
    logNode.TreeNodes.push(errLogNode);
    root.TreeNodes.push(logNode);
}