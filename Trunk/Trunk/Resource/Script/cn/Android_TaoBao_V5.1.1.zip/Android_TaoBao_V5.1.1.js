﻿/*[config]
<plugin name="淘宝,7" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="/icons/TaoBao.png" app="com.taobao.taobao" version="5.1.1" description="淘宝" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.taobao.taobao/databases/tbsearchdata</value>
<value>/data/data/com.taobao.taobao/shared_prefs/userinfo.xml</value>
<value>/data/data/com.taobao.taobao/databases/MessageCenterData</value>
<value>/data/data/com.taobao.taobao/databases/data_history</value>
</source>
<data type = "Search" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="关键字" code="Word" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss" ></item>
<item name="地址" code="Address" type="string" width="100" format=""></item>
<item name="价格" code="Price" type="string" width="100" format=""></item>
<item name="商品图片" code="Pic" type="string" width="400" format=""></item>
</data>
<data type="Account">
<item name="登录过的帐号名" code="Name" type="string" width = "" ></item>
<item name="时间" code="Time" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type = "Browse" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
<item name="宝贝名称" code="Name" type="string" width="" ></item>
<item name="时间" code="Time" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
<item name="地点" code="Address" type="string" width = "" ></item>
<item name="费用" code="Fee" type="string" width = "" ></item>
<item name="图标" code="Pic" type="url" width = "" ></item>
</data>
<data type = "Friend" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
<item name="名称" code="Name" type="string" width = "" ></item>
</data>
<data type = "Message" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
<item name="发送者" code="Sender" type="string" width = "" ></item>
<item name="接受者" code="Receiver" type="string" width = "" ></item>
<item name="内容" code="Content" type="string" width="" ></item>
<item name="时间" code="Time" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Search(){
    this.Pic = "";
    this.Word = "";
    this.Time = null;
    this.Address = "";
    this.Price = "";
    this.DataState="Normal";
}

function Account() {
    this.Name = "";
    this.Time = null;
}

function Browse() {
    this.Time = null;
    this.Name = "";
    this.Address = "";
    this.Fee = "";
    this.Pic = "";
    this.DataState="Normal";
}

function Friend() {
    this.Name = "";
    this.DataState="Normal";
}

function Message() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Content = "";
    this.DataState="Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//获取历史搜索树的信息
function getSearchInfo(path) {
    var data = eval('(' + XLY.Sqlite.FindByName(path, "history") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Search();
        if (data[index].word != null) {
            obj.Word = data[index].word;
        }else{
            obj.Word = data[index].title;
            obj.Address = data[index].address;
            obj.Price = data[index].fee;
            obj.Pic = data[index].picUrl;
        }
        obj.Time = data[index].gmt_create;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取历史登录帐号信息
function getAccountInfo(path){
    var data = eval('(' + XLY.File.ReadXML(path) + ')');
    var obj = new Account();
    var info = new Array();
    var accdata = data.map.string;
    for (var i in accdata) {
        switch(accdata[i]["@name"]){
            case "username":obj.Name = accdata[i]["#text"]; break;
            case "loginTime":obj.Time = XLY.Convert.LinuxToDateTime(accdata[i]["#text"]);break;
            default:break;
        }     
    }
    info.push(obj);
    return info;
}

//获取地理位置信息
function getBrowseInfo(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.FindByName(path, 'history') + ')');
    if(data!=null){    
        for(var i in data){
            var obj = new Browse();
            obj.Name = data[i].title;
            obj.Address = data[i].address;
            obj.Fee = data[i].fee;
            obj.Pic = data[i].picUrl;
            obj.Time = data[i].gmt_create;
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

function getFriend(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'contact' ) +')');
    for(var i in data){
        var obj = new Friend();
        obj.Name = data[i].account;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }  
    return list;
}

function getMessage(path,friend){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from message where account='"+friend+"'" ) +')');
    for(var i in data){
        var obj = new Message();
        if(data[i].direction==1){
            obj.Sender = data[i].owner;
            obj.Receiver = data[i].account;
        }else{
            obj. Sender = data[i].account;
            obj.Receiver = data[i].owner;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Content = data[i].content;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }  
    return list;
}
var result = new Array();
//源文件路径
var source = $source;
var dbsearch = source[0];
var accPath = source[1];
var dbmessagecenter = source[2];
var dbbrowse = source[3];
//var dbbrowse = "D:\\temp\\data\\data\\com.taobao.taobao\\databases\\data_history";
//var dbsearch = "D:\\temp\\data\\data\\com.taobao.taobao\\databases\\tbsearchdata";
//var dbmessage = "D:\\temp\\data\\data\\com.taobao.taobao\\databases\\message_db";
//var dbmessagecenter = "D:\\temp\\data\\data\\com.taobao.taobao\\databases\\MessageCenterData";
//var accPath = "D:\\temp\\data\\data\\com.taobao.taobao\\shared_prefs\\userinfo.xml";
var charactor1 = "\\chalib\\Android_Taobao_V5.1.1\\data_history.charactor";
var charactor2 = "\\chalib\\Android_Taobao_V5.1.1\\tbsearchdata.charactor";
var charactor3 = "\\chalib\\Android_Taobao_V5.1.1\\MessageCenterData.charactor";
var browsePath = XLY.Sqlite.DataRecovery(dbbrowse,charactor1,"history" );
var searchPath = XLY.Sqlite.DataRecovery(dbsearch,charactor2,"history" );
var messagecenterPath = XLY.Sqlite.DataRecovery(dbmessagecenter,charactor3,"contact,message" );
//创建历史搜索树
var search = new TreeNode();
search.Text = "历史搜索";
search.Type = "Search";
search.Items = getSearchInfo(searchPath);
//创建所有登录帐号树
var account = new TreeNode();
account.Text = "历史登录帐号";
account.Type = "Account";
account.Items = getAccountInfo(accPath);
//创建位置信息树
var browse = new TreeNode();
browse.Text = "浏览信息";
browse.Type = "Browse";

var browseInfo = getBrowseInfo(browsePath);
if(browseInfo != null)
{
    browse.Items=browseInfo;
}
var friend = new TreeNode();
friend.Text = "联系人";
friend.Type = "Friend";
var friendinfo = getFriend(messagecenterPath);
friend.Items = friendinfo;
for(var i in friendinfo){
    var contact = new TreeNode();
    contact.Text = friendinfo[i].Name;
    contact.Type = "Message";
    contact.Items = getMessage(messagecenterPath,friendinfo[i].Name);
    friend.TreeNodes.push(contact);
}

result.push(search);
result.push(account);
result.push(browse);
result.push(friend);
var res = JSON.stringify(result);
res;
