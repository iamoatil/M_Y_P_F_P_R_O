﻿/*[config]
<plugin name="遨游浏览器" group="Web痕迹,8" devicetype="android" icon="\icons\mxbrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.mx.browser" version="4.5.4.10000" description="遨游云浏览器" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.mx.browser/app_webview/Cookies</value>
    <value>/data/data/com.mx.browser/databases/#F</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="主键" code="Key" type="string" width = "150"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="值" code="Value" type="string" width = "200"></item>
    </data>
    <data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="类型" code="Type" type="string" width = "200"></item>
    <item name="Cookies" code="Cookies" type="string" width = "200"></item>
    <item name="代理" code="Agent" type="string" width = "200"></item>
    <item name="存储路径" code="Path" type="string" width = "150"></item>
    <item name="用户ID" code="Id" type="string" width = "150"></item>
    <item name="描述" code="Description" type="string" width = "150"></item>
    <item name="文件大小" code="Size" type="string" width = "150"></item>
    <item name="下载时间" code="Time" type="string" width = "150"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="最后访问时间" code="Time" type="string" width = "200"></item>
    <item name="访问次数" code="Num" type="string" width = "200"></item>
    </data>
    <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="用户ID" code="Id" type="string" width = "150"></item>
    <item name="访问次数" code="Num" type="string" width = "200"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="HomePage" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="图标" code="Icon" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function Download() {
    this.DataState = "Normal";
    this.Content = "";
    this.Url = "";
    this.Type = "";
    this.Cookies = "";
    this.Agent = "";
    this.Path = "";
    this.Id = "";
    this.Description = "";
    this.Size = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
    this.Num = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Id = "";
    this.Num = "";
    this.Time = "";
}
function HomePage() {
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Icon = "";
}

//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}

function bindTree() {
    newTreeNode("Cookies", "Cookies", getCookies(db3));
    newTreeNode("下载信息", "Download", getDownload(db4));
    newTreeNode("浏览记录", "History", getHistory(db5));
    newTreeNode("书签", "Bookmark", getBookmark(db5));
    newTreeNode("主页", "HomePage", getHomePage(db5));
}
function getNews() {
    var list = new Array();
    data = ["Cookies", "下载信息", "浏览记录", "书签", "主页"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getCookies(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies") + ')');
    for (var i in data) {
        var obj = new Cookies();
        obj.Key = data[i].host_key;
        obj.Name = data[i].name;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from downloads") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Content = data[i].hint;
        obj.Url = data[i].uri;
        obj.Type = data[i].type;
        obj.Cookies = data[i].cookiedata;
        obj.Agent = data[i].useragent;
        obj.Path = data[i]._data;
        obj.Id = data[i].uid;
        obj.Description = data[i].description;
        obj.Size = data[i].total_bytes / 1024 / 1024 + "MB";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].lastmod);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Num = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].last_visit);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmark") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Id = data[i].guid;
        obj.Num = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHomePage(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from mxquickdial") + ')');
    for (var i in data) {
        var obj = new HomePage();
        obj.Name = data[i].title;
        obj.Url = data[i].url;
        obj.Icon = data[i].icon_url;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db0 = source[0];
var db1 = source[1] + "\\downloads.db";
var db2 = source[1];

var b = eval('(' + XLY.File.FindFileNames(db2) + ')');
for (var i in b) {
    var reg = /^mxbrowser_USER/;
    var c = b[i].match(reg);
    //log(b[i]);
    if (c != null) {
        path = db2 + "\\mxbrowser_USER40087338" + ".db";
    }
}

var charactor1 = "\\chalib\\Android_MXBrowser_V4.5.4.10000\\Cookies.charactor";
var charactor2 = "\\chalib\\Android_MXBrowser_V4.5.4.10000\\downloads.db.charactor";
var charactor3 = "\\chalib\\Android_MXBrowser_V4.5.4.10000\\mxbrowser.db.charactor";

var db3 = XLY.Sqlite.DataRecovery(db0, charactor1, "cookies");
var db4 = XLY.Sqlite.DataRecovery(db1, charactor2, "downloads");
var db5 = XLY.Sqlite.DataRecovery(path, charactor3, "bookmark,history,mxquickdial");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
