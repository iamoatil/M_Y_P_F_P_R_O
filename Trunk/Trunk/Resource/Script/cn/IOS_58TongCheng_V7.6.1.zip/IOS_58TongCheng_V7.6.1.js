﻿/*[config]
<plugin name="58同城,9" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/58.png" app="com.taofang.iphone" version="5.3.5" description="58同城" data="$data,ComplexTreeDataSource"  >
<source>
<value>com.taofang.iphone</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="Map">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
</data>
<data type="SearchHistory" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关键字" code="keyword" type="string" width="100"></item>
</data>
<data type="FootHistory" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关键字" code="title" type="string" width="200"></item>
<item name="分类" code="Category" type="string" width="400"></item>
</data>
<data type="DialHistory" datefilter="time" contract="DataState">   
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="标题" code="title" type="string" width="300"></item>
<item name="用户" code="Name" type="string" width="150"></item>
<item name="手机" code="phone" type="string" width="150" ></item>
<item name="链接" code="Url" type="Url" width="400" ></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>
<data type="BrowseHistory" datefilter="time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="标题" code="title" type="string" width="300"></item>
<item name="分类" code="cateName" type="string" width="150"></item>
<item name="地址" code="location" type="string" width="150"></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>

<data type="SiftHistory" datefilter="time" contract="DataState">  
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="类别" code="cateName" type="string" width="150"></item>
<item name="位置" code="location" type="string" width="150"></item>
<item name="标题" code="title" type="string" width="300"></item>
<item name="快速链接" code="webUrl" type="Url" width="400"></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>
<data type="LastGpsCity">
<item name="地址" code="location" type="string" width="150"></item>

</data>

</plugin>
[config]*/
function News(){
    this.List = "";
}
function UserInfo() {
    this.Name = "";  
    this.ID = "";   
    this.Avatar = "";  
    this.DataState = "Normal";
}
function SearchHistory() {
    this.keyword = "";  
    this.DataState = "Normal";  
}

function FootHistory() {
    this.title = "";  
    this.Category = "";  
    this.DataState = "Normal";  
}

function DialHistory() {
    this.Url = "";  
    this.title = "";  
    this.Name = "";   
    this.phone = "";  
    this.time = "";  
    this.DataState = "Normal";  
}

function BrowseHistory() {
    this.Url = "";  
    this.title = "";  
    this.cateName = "";  
    this.location = "";  
    this.time = "";  
    this.DataState = "Normal";  
}

function SiftHistory() {
    this.cateName = "";  
    this.location = "";  
    this.title = "";  
    this.webUrl = "";  
    this.time = "";  
    this.DataState = "Normal";  
}

function LastGpsCity() {
    this.location = "";  
}

//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "58同城";
    news.Type = "News"; 
    accountinfo = getNews();
    //news.Items = accountinfo;
    news.DataState = "Normal";
    
    var search = new TreeNode();
     search.Type = "SearchHistory";
     search.Text = "首页搜索记录";
     search.Items = getSearchHistory(db);
     news.TreeNodes.push(search);
     
     var browser = new TreeNode();
     browser.Type = "BrowseHistory";
     browser.Text = "浏览记录";
     browser.Items = getBrowseHistory(db);
     news.TreeNodes.push(browser);
     
     var dial = new TreeNode();
     dial.Type = "DialHistory";
     dial.Text = "拨号记录";
     dial.Items = getDialHistory(db);
     news.TreeNodes.push(dial);
     
     var foot = new TreeNode();
     foot.Type = "FootHistory";
     foot.Text = "分类搜索";
     foot.Items = getFootHistory(db);
     news.TreeNodes.push(foot)

    for(var i in accountinfo ){
         var UserNode =new TreeNode();
         UserNode.Type="UserInfo";
         UserNode.Text = accountinfo[i].Name;
         UserNode.Items = getUserInfo(accPath); 
         news.TreeNodes.push(UserNode);
                
    }   
    result.push(news)
}
function getNews(){
    var list = new Array();
    data = [];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function getUserInfo(path){
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path,"select * from sync_user")+ ')'); 
  log(data);  
    for(var i in data){
        var obj = new UserInfo();
        obj.ID = data[i].user_id;
        obj.Name = data[i].user_name;
        obj.Avatar = data[i].avatar;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);        
    }
    return list
}
//搜索历史记录
function getSearchHistory(path)
{
    try{
        var arr = new Array();
        var data = eval('(' + XLY.Sqlite.Find(path, "select * from Search ") + ')');
        for(var index in data)
        {
            if(data[index].wordKey)
            {
                var obj=new SearchHistory();
                obj.keyword = data[index].wordKey;  
                obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
                arr.push(obj);
            }
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//足迹
function getFootHistory(path)
{
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, "select * from ListCateSearch ") + ')');
        for(var index in data)
        {
            var obj=new FootHistory();
            obj.title = data[index].wordKey;  
            obj.Category = data[index].category;  
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            arr.push(obj);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//拨打记录
function getDialHistory(path)
{
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, "select * from DialHistory order by updatetime desc") + ')');
        for(var index in data)
        {
            var obj=new SiftHistory();
            obj.Url = data[index].url;  
            obj.title = data[index].title;  
            obj.Name = data[index].username;    
            obj.phone = data[index].phoneNumber;  
            obj.time = data[index].updatetime;  
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            arr.push(obj);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//浏览记录
function getBrowseHistory(path)
{
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, "select * from DetailHistory order by updatetime desc") + ')');
        for(var index in data)
        {
            var obj=new SiftHistory();
            obj.Url = data[index].url;  
            obj.title = data[index].title;  
            obj.cateName = data[index].catename;  
            obj.location = data[index].localname;  
            obj.time = data[index].updatetime;  
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            arr.push(obj);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//筛选记录
function getShiftHistory(path)
{
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, "select * from FilterHistory order by updatetime desc") + ')');
        for(var index in data)
        {
            var obj=new SiftHistory();
            obj.cateName = data[index].categoryName;  
            obj.location = data[index].localname;  
            obj.title = data[index].title;  
            obj.webUrl = data[index].url;      
            obj.time = data[index].updatetime;  
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            arr.push(obj);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//*************************************************************************
var source = $source;
var db1 = source[0]+"com.taofang.iphone/Documents/mainDB.db";
var accPath1 = source[0]+"com.taofang.iphone/Documents/users";

//var accPath1 = "D:\\temp\\data\\data\\com.taofang.iphone\\Documents\\users";
//var db1 = "D:\\temp\\data\\data\\com.taofang.iphone\\Documents\\mainDB.db"
var accPath2 = eval('('+ XLY.File.FindDirectories(accPath1) +')');

for(var i in accPath2 ){
    RegExp = /[1-9]\d*_2$/;
    a = accPath2[i].match(RegExp);
    if(a != null){
        var accPath = accPath2[i] + "\\dataNew\\data.db"; 
    }   
}
//var charactor = "D:\\temp\\data\\data\\com.taofang.iphone\\Documents\\mainDB.db.charactor"
var charactor = "chalib\\IOS_58TongCheng_V7.6.1\\mainDB.db.charactor";
var db = XLY.Sqlite.DataRecovery( db1,charactor ,"Search,ListCateSearch,DialHistory,DetailHistory");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
