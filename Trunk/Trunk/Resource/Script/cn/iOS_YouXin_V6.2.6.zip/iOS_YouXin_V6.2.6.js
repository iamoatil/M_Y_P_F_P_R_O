﻿/*[config]
<plugin name="有信,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/iOSYX.png" app="com.telecom-guoling.feiin" version="6.2.6" description="有信" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.telecom-guoling.feiin</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="有信ID" code="UID" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="出生年月" code="Birthday" type="string" width="120" format = "" ></item>
    <item name="文字签名" code="WordSign" type="string" width="120" format = "" ></item>
    <item name="声音签名" code="SoundSign" type="string" width="120" format = "" ></item>
    <item name="电话号码" code="MobileNumber" type="string" width="120" format = "" ></item>
    <item name="最近登录日期" code="LastUpdate" type="string" width="120" format = "" ></item>
</data>
<data type="FollowInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="有信ID" code="UID" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="出生年月" code="Birthday" type="string" width="120" format = "" ></item>
    <item name="是否VIP" code="IsVip" type="string" width="80" format = "" ></item>
    <item name="最后登录时间" code="LastUpdate" type="string" width="120" format = "" ></item>
    <item name="对话次数" code="TalkTime" type="string" width="80" format = "" ></item>
    <item name="对话开始时间" code="StartTime" type="string" width="120" format = "" ></item>
    <item name="对话结束时间" code="EndTime" type="string" width="120" format = "" ></item>
</data>
<data type="Message" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="消息ID" code="RecordID" type="string" width = "120"></item>
    <item name="发送者ID" code="SenderID" type="string" width = "120"></item>
    <item name="发送者" code="Sender" type="string" width = "120"></item>
    <item name="接收者ID" code="ReceiverID" type="string" width = "120"></item>
    <item name="接收者" code="Receiver" type="string" width = "120"></item>
    <item name="内容" code="Content" type="string" width = "120"></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="类型" code="Type" type="string"  width = "120"></item>
    <item name="附件路径" code="ContentPath" type="url"  width = "120"></item>
</data>
<data type="Dynamic" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="评论人ID" code="UserID" type="string" width="200" format = "" ></item>
    <item name="评论人昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="类型" code="DynamicType" type="string" width="200" format=""></item>
    <item name="评论ID" code="DynamicID" type="string" width="200" format=""></item>
    <item name="评论内容" code="DynamicContent" type="string" width="200" format=""></item>
    <item name="时间" code="DynamicTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.NickName = "";
    this.UID = "";
    this.Sex = "";
    this.HeadUrl = "";
    this.Birthday = "";
    this.WordSign = "";
    this.SoundSign = "";
    this.MobileNumber = "";
    this.LastUpdate = "";
}
//定义FollowInfo数据结构
function FollowInfo(){
    this.DataState = "Normal";
    this.NickName = "";
    this.UID = "";
    this.Sex = "";
    this.HeadUrl = "";
    this.Birthday = "";
    this.IsVip = "否";
    this.LastUpdate = "";
    this.TalkTime = "";
    this.StartTime = "";
    this.EndTime = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.RecordID = "";
    this.SenderID = "";
    this.Sender = "";
    this.ReceiverID = "";
    this.Receiver = "";
    this.Content = "";
    this.CreateTime = null;
    this.Type = "";
    this.ContentPath = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.telecom-guoling.feiin\\Documents";
var userPath = source[0]+"\\com.telecom-guoling.feiin\\Library\\Preferences\\com.telecom-guoling.feiin.plist";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-08-31-13-37-19\\source\\IosData\\2017-08-31-13-37-51\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.telecom-guoling.feiin\\Documents"
//var userPath = "C:\\XLYSFTasks\\任务-2017-08-31-13-37-19\\source\\IosData\\2017-08-31-13-37-51\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.telecom-guoling.feiin\\Library\\Preferences\\com.telecom-guoling.feiin.plist";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_YouXin_V6.2.6\\IMDataNew.Sqlite3.charactor";
var charactor2 = "\\chalib\\iOS_YouXin_V6.2.6\\StrangePersonInfo.Sqlite3.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "有信";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userinfo = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        var reg = new RegExp("userinfo_[0-9]{9}");
        for(var i in userinfo){
            for(var key in userinfo[i]){
                if(reg.test(key)){
                    var aa = userinfo[i][key];
                    var objUser = new UserInfo();
                    for(var a in aa){
                        if(aa[a].birthday!=""&&aa[a].birthday!=null){
                            objUser.Birthday = aa[a].birthday;
                        }
                        if(aa[a].lastupdate!=""&&aa[a].lastupdate!=null){
                            objUser.LastUpdate = aa[a].lastupdate;
                        }
                        if(aa[a].mobileNumber!=""&&aa[a].mobileNumber!=null){
                            objUser.MobileNumber = aa[a].mobileNumber;
                        }
                        if(aa[a].name!=""&&aa[a].name!=null){
                            objUser.NickName = aa[a].name;
                        }
                        if(aa[a].picture!=""&&aa[a].picture!=null){
                            objUser.HeadUrl = aa[a].picture;
                        }
                        if(aa[a].sex!=""&&aa[a].sex!=null){
                            objUser.Sex = aa[a].sex;
                        }
                        if(aa[a].signature!=""&&aa[a].signature!=null){
                            objUser.WordSign = aa[a].signature;
                        }
                        if(aa[a].uid!=""&&aa[a].uid!=null){
                            objUser.UID = aa[a].uid;
                        }
                        if(aa[a].voice!=""&&aa[a].voice!=null){
                            objUser.SoundSign = aa[a].voice;
                        }
                    }
                    
                    var usernode = new TreeNode();
                    usernode.Text = objUser.UID+"_"+objUser.NickName;
                    usernode.Type = "UserInfo";
                    usernode.Items.push(objUser);
                    getUserInfo(usernode,objUser.UID,objUser.NickName);
                    root.TreeNodes.push(usernode);
                }
            }
        }
    }
}
function getUserInfo(root,userid,username){
    getFollowInfo(root,userid);
    var node = new TreeNode();
    node.Text = "消息";
    node.Type = "";
    getMessageInfo(node,userid,username);
    root.TreeNodes.push(node);
}
function getFollowInfo(root,userid){
    var followPath1 = allPath + "\\"+userid+"\\StrangePersonInfo.Sqlite3";
    var followPath = XLY.Sqlite.DataRecovery(followPath1,charactor2,"tatnlinelistusers");
    if(XLY.File.IsValid(followPath)){
        var followData = eval('('+ XLY.Sqlite.Find(followPath,"select XLY_DataType,info from tatnlinelistusers where type = '2' and uid<>'"+userid+"'") +')');
        if(followData!=""&&followData!=null){
            var followNode = new TreeNode();
            followNode.Text = "好友列表";
            followNode.Type = "FollowInfo";
            for(var i in followData){
                if(followData[i].XLY_DataType==2){
                    var objFollow = new FollowInfo();
                    objFollow.DataState = XLY.Convert.ToDataState(followData[i].XLY_DataType);
                    if(followData[i].info!=""&&followData[i].info!=null){
                        var aa = eval('('+ followData[i].info +')');
                        objFollow.NickName = aa.name;
                        objFollow.UID = aa.uid;
                        objFollow.Sex = aa.sex;
                        objFollow.HeadUrl = aa.picture_big;
                        objFollow.Birthday = aa.birthday;
                        if(aa.isvip=='true'){
                            objFollow.IsVip = "是";
                        }
                        
                        objFollow.LastUpdate = aa.lastupdate;
                        objFollow.TalkTime = aa.talktime;
                        objFollow.StartTime = aa.startTime;
                        objFollow.EndTime = aa.endTime;
                        followNode.Items.push(objFollow);
                    }
                }
                
            }
            root.TreeNodes.push(followNode);
        }
    }
}
function getMessageInfo(root,userid,username){
    var messagePath1 = allPath +"\\" +userid+"\\IMDataNew.Sqlite3";
    var messagePath = XLY.Sqlite.DataRecovery(messagePath1,charactor1,"NewIMMessageInfo",true);
    var followPath = allPath + "\\"+userid+"\\StrangePersonInfo.Sqlite3";
    if(XLY.File.IsValid(messagePath)){
        var messageUidInfo = eval('('+ XLY.Sqlite.Find(messagePath,"select distinct(uid) from NewIMMessageInfo") +')');
        if(messageUidInfo!=""&&messageUidInfo!=null){
            for(var i in messageUidInfo){
                var messageNode = new TreeNode();
                if(messageUidInfo[i].uid=="8000"){
                    messageNode.Text = messageUidInfo[i].uid+"_"+"有信团队";
                }
                else
                {
                    var nameInfo = eval('('+ XLY.Sqlite.Find(followPath,"select info from tatnlinelistusers where uid = '"+messageUidInfo[i].uid+"'") +')');
                    if(nameInfo!=""&&nameInfo!=null){
                        var aa = eval('('+ nameInfo[0].info +')');
                        if(aa!=""&&aa!=null){
                            messageNode.Text = messageUidInfo[i].uid+"_"+aa.name;
                        }
                    }
                }
                
                messageNode.Type = "Message";
                var messageInfo = eval('('+ XLY.Sqlite.Find(messagePath,"select msgtype,msgcontype,msgtime,recordid,msgcontent,jsonDataString,uid,XLY_DataType from NewIMMessageInfo where uid='"+messageUidInfo[i].uid+"'") +')');
                if(messageInfo!=""&&messageInfo!=null){
                    for(var j in messageInfo){
                        var messageObj = new Message();
                        messageObj.DataState = XLY.Convert.ToDataState(messageInfo[j].XLY_DataType);
                        messageObj.RecordID = messageInfo[j].recordid;
                        if(messageInfo[j].msgtype==0){
                            messageObj.SenderID = messageNode.Text.split("_")[0];
                            messageObj.Sender = messageNode.Text.split("_")[1];
                            messageObj.ReceiverID = userid;
                            messageObj.Receiver = username;
                        }
                        if(messageInfo[j].msgtype==1){
                            messageObj.SenderID = userid;
                            messageObj.Sender = username;
                            messageObj.ReceiverID = messageNode.Text.split("_")[0];
                            messageObj.Receiver = messageNode.Text.split("_")[1];
                        }
                        //log(messageInfo[j].msgcontent.replace(/\%/g,","));
                        
                        messageObj.CreateTime = messageInfo[j].msgtime;
                        
                        if(messageInfo[j].msgcontype==1){
                            messageObj.Type = "文本";
                            var aaaaa = Str2Bytes(messageInfo[j].msgcontent.replace(/\%/g,""));
                            if(aaaaa!=""&&aaaaa!=null){
                                messageObj.Content = XLY.Blob.ToString(aaaaa);
                            }
                            else
                            {
                                messageObj.Content = messageInfo[j].msgcontent;
                            }
                        }
                        if(messageInfo[j].msgcontype==2){
                            messageObj.Type = "图片";
                            
                            if(messageInfo[j].msgcontent.replace(/\%/g,"")[0]==7){
                                var pos = messageInfo[j].msgcontent.lastIndexOf(".")+4;
                                var content = messageInfo[j].msgcontent.substr(0,pos);
                                var pos1 = content.lastIndexOf("%")+2;
                                messageObj.Content = content.substr(pos1,content.length);
                                messageObj.ContentPath = allPath +"\\" +userid+"\\IMMedia\\"+messageNode.Text.split("_")[0]+"\\"+messageInfo[j].msgcontent;
                            }
                            else
                            {
                                var bbbbbb = eval('('+ messageInfo[j].msgcontent +')');
                                messageObj.Content = bbbbbb["[UXinIMPicName]"];
                                messageObj.ContentPath = allPath +"\\" +userid+"\\IMMedia\\"+messageNode.Text.split("_")[0]+"\\"+messageInfo[j].msgcontent;
                            }
                        }
                        if(messageInfo[j].msgcontype==3){
                            messageObj.Type = "音频";
                            messageObj.Content = messageInfo[j].msgcontent;
                            messageObj.ContentPath = allPath +"\\" +userid+"\\IMMedia\\"+messageNode.Text.split("_")[0]+"\\"+messageInfo[j].msgcontent;
                        }
                        if(messageInfo[j].msgcontype==5){
                            messageObj.Type = "地理位置";
                            var pos = messageInfo[j].msgcontent.indexOf("(");
                            var cc = messageInfo[j].msgcontent.substr(pos,messageInfo[j].msgcontent.length);
                            var pos1 = cc.indexOf(")");
                            var ccc = cc.substr(1,pos1-1).replace(/\%/g,"");
                            var s2b = Str2Bytes(ccc);
                            //log(XLY.Blob.ToString(s2b));
                            var ddd = messageInfo[j].msgcontent.split(",");
                            var reg1 = new RegExp("longitude");
                            var reg2 = new RegExp("latitude");
                            var reg3 = new RegExp("description");
                            var lonlon = "";
                            var latlat = "";
                            var address = "";
                            for(var d in ddd){
                                if(reg1.test(ddd[d])){
                                    var lonPos = ddd[d].lastIndexOf("%");
                                    var lon = ddd[d].substr(0,lonPos);
                                    var longPos = lon.lastIndexOf("%");
                                    lonlon = lon.substr(longPos+3,lon.length);
                                }
                                if(reg2.test(ddd[d])){
                                    var latPos = ddd[d].lastIndexOf("%");
                                    var lat = ddd[d].substr(0,latPos);
                                    var lattPos = lat.lastIndexOf("%");
                                    latlat = lat.substr(lattPos+3,lat.length);
                                }
                                if(reg3.test(ddd[d])){
                                    var desPos = ddd[d].indexOf(":");
                                    var des = ddd[d].substr(desPos+4,ddd[d].length);
                                    var dddddd1Pos = des.indexOf("(");
                                    var dddddd1 = des.substr(0,dddddd1Pos).replace(/\%/g,"");
                                    var dd1 = XLY.Blob.ToString(Str2Bytes(dddddd1));
                                    var ddddddd2Pos = des.substr(dddddd1Pos,des.length).indexOf(")");
                                    var ddddddd2 = des.substr(dddddd1Pos+1,ddddddd2Pos-1).replace(/\%/g,"");
                                    var dd2 = XLY.Blob.ToString(Str2Bytes(ddddddd2));
                                    var ddddddd3 = des.substr(ddddddd2Pos+dddddd1Pos+1,des.length).replace(/\%/g,"");
                                    var dd3 = XLY.Blob.ToString(Str2Bytes(ddddddd3));
                                    address = dd1+"("+dd2+")"+dd3;
                                }
                            }
                            messageObj.Content = "经度："+lonlon+"\n纬度："+latlat+"\n地址："+address;
                        }
                        messageNode.Items.push(messageObj);
                    }
                }
                root.TreeNodes.push(messageNode);
            }
        }
    }
}
function Str2Bytes(str){
    var pos = 0;
    var len = str.length;
    if(len %2 != 0){
       return null; 
    }

    len /= 2;
    var hexA = new Array();
    for(var i=0; i<len; i++){
       var s = str.substr(pos, 2);
       var v = parseInt(s, 16);
       hexA.push(v);
       pos += 2;
    }
   return hexA;
}
