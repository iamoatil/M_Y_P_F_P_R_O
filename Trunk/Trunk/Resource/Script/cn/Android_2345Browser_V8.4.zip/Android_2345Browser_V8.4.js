﻿/*[config]
<plugin name="2345浏览器,6" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/2345Browser.png" app="com.browser2345" version="8.4" description="2345浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.browser2345/databases/browser2.db</value>
    <value>/data/data/com.browser2345/databases/2345db_2</value>
    <value>/data/data/com.browser2345/databases/downloads.db</value>
    <value>/data/data/com.browser2345/databases/webviewCookiesChromium.db</value>
    <value>/data/data/com.browser2345/databases/video.db</value>
    <value>/data/data/com.browser2345/shared_prefs/com.browser2345_preferences.xml</value>
    <value>/data/data/com.browser2345/app_webview/Cookies</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
    <item name="登录时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名称" code="UserName" type="string" width="200" format = "" ></item>
    <item name="登录时间" code="Time"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="UID" code="ID" type="string" width="100" format = "" ></item>
    <item name="城市" code="Location" type="string" width="100" format="" ></item>
</data>
<data type="History" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="200" format="" ></item>
    <item name="URL地址" code="Url" type="url" width="200" format=""></item>
    <item name="访问时间" code="Time"  type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="访问次数(次)" code="Visits" order="desc" type="string" width="100" format=""></item>
</data>
<data type="VideoHistory" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="200" format="" ></item>
    <item name="URL地址" code="Url" type="url" width="200" format = ""></item>
    <item name="播放时长" code="PlayTime" type="string" width="100" format=""></item>
    <item name="播放时间" code="Time"  type="datetime" width="150" format=""></item>
</data>
<data type="Bookmark" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="100" format="" ></item>
    <item name="主题" code="Title" type="string" width="300" format = ""></item>
    <item name="URL地址" code="Url" type="url" width="500" format=""></item>
    <item name="创建时间" code="Created" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="DownloadFile" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="200" format=""></item>
    <item name="文件URL地址" code="Url" type="url" width="400" format=""></item>
    <item name="存储路径" code="SavePath" type="string" width="200" format = ""></item>
    <item name="文件类型" code="FileType" type="string" width="240" format=""></item>
    <item name="文件状态" code="Status" type="string" width="100" format = ""></item>
    <item name="最后修改时间" code="LastModTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="总大小" code="TotalBytes" type="string" width="100" format=""></item>
    <item name="当前大小" code="CurrentBytes" type="string" width="100" format=""></item>
</data>
<data type="Cookies" contract="DataState" datefilter="LastTime">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="Name" code="Name" type="string" width="200" format=""></item>
    <item name="Key" code="Host_Key" type="string" width="160" format=""></item>
    <item name="Value" code="CookieValue" type="string" width="400" format=""></item>
    <item name="创建时间" code="CreateTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="过期时间" code="ExpireTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后认证时间" code="LastTime" type="datetime" order="desc" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="存放路径" code="Path" type="string" width="200" format = ""></item>
</data>
<data type="BookmarkNode" contract="DataState" datefilter="LastTime">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="书签分类" code="List" type="string" width="200" format=""></item>
</data>
<data type="SearchWords" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="主题" code="Title" type="string" width="200" format = ""></item>
    <item name="Url" code="Url" type="string" width="400" format = ""></item>
    <item name="搜索类型" code="TypeId" type="string" width="200" format = ""></item>
    <item name="搜索时间" code="Time" type="datetime" order="desc" width="150" format=""></item>
</data>
</plugin>
[config]*/
//定义数据结构

//***remark***
//*** Author:lt
//*** DateTime:2016-11-12
//***remark***

function News(){
    this.DataState = "Normal";
    this.List = "";
    this.Time = null;
}
//用户信息
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.Time = null;
    this.ID = "";
    this.Location = "";
}
//历史记录
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = null;
    this.Visits = "";
}
//书签分类
function BookmarkNode(){
    this.DataState = "Normal";
    this.List = "";
}
//视频播放记录
function VideoHistory(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.PlayTime = "";
    this.Time = null;
}
//收藏/书签
function Bookmark(){
    this.DataState = "Normal";
    this.ID = "";
    this.Title = "";
    this.Url = "";
    this.Created = null;
}
//下载文件
function DownloadFile(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.SavePath = "";
    this.FileType = "";
    this.Status = "";
    this.LastModTime = null;
    this.TotalBytes = "";
    this.CurrentBytes = "";
}
//Cookies
function Cookies(){
    this.DataState = "Normal";
    this.Name = "";
    this.Host_Key = "";
    this.CookieValue = "";
    this.CreateTime = null;
    this.ExpireTime = null;
    this.LastTime = null;
    this.Path = "";
}
//搜索记录
function SearchWords(){
    this.DateState = "Normal";
    this.Title = "";
    this.Url = "";
    this.TypeId = "";
    this.Time = null;
}
//树形结构
function TreeNode(){
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.Type = "";//节点[Items]的数据类型
    this.DataState = "Normal";
}

var source = $source;
var db = source[0];//书签和历史记录
var db1 = source[1];//搜索记录
var db2 = source[2];//下载
var db3 = source[3];//cookies
var db4 = source[4];//视频记录
var db5 = source[5];//用户信息
var db6 = source[6];

//var db = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\databases\\browser2.db";
//var db1 = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\databases\\2345db_2.db";
//var db2 = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\databases\\downloads.db";
//var db3 = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\databases\\webviewCookiesChromium.db";
//var db4 = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\databases\\video.db";
//var db5 = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\shared_prefs\\com.browser2345_preferences.xml";
//var db6 = "C:\\XLYSFTasks\\任务-2016-11-28-19-01-35\\source\\data\\data\\com.browser2345\\app_webview\\Cookies";

var charactor1 = "\\chalib\\Android_2345Browse_V8.4\\2345db_2.charactor";
var charactor2 = "\\chalib\\Android_2345Browse_V8.4\\browser2.db.charactor";
var charactor3 = "\\chalib\\Android_2345Browse_V8.4\\downloads.db.charactor";
var charactor4 = "\\chalib\\Android_2345Browse_V8.4\\video.db.charactor";
var charactor5 = "\\chalib\\Android_2345Browse_V8.4\\webviewCookiesChromium.db.charactor";
var charactor6 = "\\chalib\\Android_2345Browse_V8.4\\Cookies.charactor";


if(XLY.File.IsValid(db3)){
    var db_ck = XLY.Sqlite.DataRecovery(db3,charactor5,"cookies");
}
else
{
    var db_ck = XLY.Sqlite.DataRecovery(db6,charactor6,"cookies");
}

var db_bm = XLY.Sqlite.DataRecovery(db,charactor2,"bookmarks,history");
var db_sw = XLY.Sqlite.DataRecovery(db1,charactor1,"UrlEnter_InputRecord");
var db_dl = XLY.Sqlite.DataRecovery(db2,charactor3,"downloads");
var db_vh = XLY.Sqlite.DataRecovery(db4,charactor4,"video_history");
var ui_xml = db5;

function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}

function getNews(){
    var list = new Array();
    var userXml = eval('(' + XLY.File.ReadXML(ui_xml) + ')');
    var usernamedata = userXml.map.string;
    var timedata = userXml.map.long;
    var obj = new News();
    for(var i in usernamedata){
        switch(usernamedata[i]["@name"]){
            case "user":
            obj.List = usernamedata[i]["#text"]; 
            break;
            default:
            break;
        }  
    }
    for (var i in timedata) {
        if(timedata[i]["@name"]=="time"){
            obj.Time = XLY.Convert.LinuxToDateTime(timedata[i]["@value"]);
        }
    }
    list.push(obj);
    return list;
}

function newTreeNode(text,type,items,root){
    var temp = new TreeNode();
    temp.Text = text;
    temp.Type = type;
    temp.Items = items;
    root.TreeNodes.push(temp);
}

function getBookmarkNode(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var accountname = "select distinct account_name from bookmarks where XLY_DataType='"+2+"'";
        var data = ExecSql(path,accountname);
        for(var i in data){
            var obj = new BookmarkNode();
            obj.List = data[i].account_name;
            list.push(obj);
        }
        return list; 
    }
}
function getBookmark(path,data1){
    if(XLY.File.IsValid(path)){
        if(data1=="" || data1==null){
            var list = new Array();
            var tmpsql = "select * from bookmarks";
            var bookmarkdata = ExecSql(path,tmpsql);
            for(var i in bookmarkdata){
                if(data1==bookmarkdata[i].account_name){
                    var obj = new Bookmark();
                    obj.DataState = XLY.Convert.ToDataState(bookmarkdata[i].XLY_DataType);
                    obj.ID = bookmarkdata[i].xly_id;
                    obj.Title = bookmarkdata[i].title;
                    obj.Url = bookmarkdata[i].url;
                    obj.Created = XLY.Convert.LinuxToDateTime(bookmarkdata[i].created);
                    list.push(obj);
                }
                if(bookmarkdata[i].XLY_DataType==1 &&bookmarkdata[i].parent==0){
                    var obj = new Bookmark();
                    obj.DataState = XLY.Convert.ToDataState(bookmarkdata[i].XLY_DataType);
                    obj.ID = bookmarkdata[i].xly_id;
                    obj.Title = bookmarkdata[i].title;
                    obj.Url = bookmarkdata[i].url;
                    obj.Created = XLY.Convert.LinuxToDateTime(bookmarkdata[i].created);
                    list.push(obj);
                }
            }
            return list;
        }
        else
        {
            var list = new Array();
            var tmpsql = "select * from bookmarks";
            var bookmarkdata = ExecSql(path,tmpsql);
            for(var i in bookmarkdata){
                if(data1==bookmarkdata[i].account_name){
                    var obj = new Bookmark();
                    obj.DataState = XLY.Convert.ToDataState(bookmarkdata[i].XLY_DataType);
                    obj.ID = bookmarkdata[i].xly_id;
                    obj.Title = bookmarkdata[i].title;
                    obj.Url = bookmarkdata[i].url;
                    obj.Created = XLY.Convert.LinuxToDateTime(bookmarkdata[i].created);
                    list.push(obj);
                }
            }
            return list;
        }
    }
}

function getDownload(path) {
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var tmpsql = "select XLY_DataType,title,uri,_data,mimetype,status,lastmod,total_bytes,current_bytes,deleted from downloads";
        var downloaddata = ExecSql(path,tmpsql);
        log(downloaddata);
        for(var i in downloaddata){
            var obj = new DownloadFile();
            obj.DataState = XLY.Convert.ToDataState(downloaddata[i].XLY_DataType);
            obj.Title = downloaddata[i].title;
            obj.Url = XLY.Convert.UrlDecode(downloaddata[i].uri);
            obj.SavePath = downloaddata[i].xly_data;
            obj.FileType = downloaddata[i].mimetype; 
            if(200==downloaddata[i].status)
            {
                obj.Status = "下载完成";
            }
            else if(193==downloaddata[i].status){
                obj.Status = "下载暂停";
            }
            else
            {
                obj.Status = "下载异常";
            }
            obj.LastModTime = XLY.Convert.LinuxToDateTime(downloaddata[i].lastmod);
            obj.TotalBytes = downloaddata[i].total_bytes;
            obj.CurrentBytes = downloaddata[i].current_bytes;
            list.push(obj);
        }
        return list;
    }
}

function getHistory(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var tmpsql = "select * from history";
        var historydata = ExecSql(path,tmpsql);
        for(var i in historydata){
            var obj = new History();
            obj.DataState = XLY.Convert.ToDataState( historydata[i].XLY_DataType);
            obj.Title = historydata[i].title;
            obj.Url = historydata[i].url;
            obj.Visits = historydata[i].visits;
            obj.Time = XLY.Convert.LinuxToDateTime(historydata[i].date);
            list.push(obj);
        }
        return list;
    }
}

function getVideoHistory(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var tmpsql = "select * from video_history";
        var videohistorydata = ExecSql(path,tmpsql);
        if(videohistorydata){
            for(var i in videohistorydata){
                var obj = new VideoHistory();
                obj.DataState = XLY.Convert.ToDataState( videohistorydata[i].XLY_DataType);
                obj.Title = videohistorydata[i].name;
                obj.Url = videohistorydata[i].page_url;
                obj.PlayTime = videohistorydata[i].playtime+"秒";
                obj.Time = videohistorydata[i].update_time;
                list.push(obj);
            }
        }
        return list;
    }
}

function getCookies(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var tmpsql = "select * from cookies";
        var cookiesdata = ExecSql(path,tmpsql);
        for(var i in cookiesdata){
            var obj = new Cookies();
            obj.DataState = XLY.Convert.ToDataState( cookiesdata[i].XLY_DataType);
            obj.Name = cookiesdata[i].name;
            obj.Host_Key = cookiesdata[i].host_key;
            obj.CookieValue = cookiesdata[i].value;
            obj.CreateTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].creation_utc);
            obj.ExpireTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].expires_utc);
            obj.LastTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].last_access_utc);
            obj.Path = cookiesdata[i].path;
            list.push(obj);
        }
        return list;
    }
}

function getSearchWord(path){
    if(XLY.File.IsValid(path)){
        var list = new Array();
        var tmpsql = "select * from UrlEnter_InputRecord";
        var searchworddata = ExecSql(path,tmpsql);
        for(var i in searchworddata){
            var obj = new SearchWords();
            obj.DataState = XLY.Convert.ToDataState( searchworddata[i].XLY_DataType);
            obj.Title = searchworddata[i].Title;
            obj.Url = searchworddata[i].Url;
            if(1==searchworddata[i].typeId)
            {
                obj.TypeId = "网页";
            }
            else{
                obj.TypeId = "关键字";
            }
            obj.Time = searchworddata[i].Date;
            list.push(obj);
        }
    }
    return list;
}

function getUserInfo(path){
    var list = new Array();
    var userXml = eval('(' + XLY.File.ReadXML(path) + ')');
    var sdata = userXml.map.string;
    var ldata = userXml.map.long;
    var obj = new UserInfo();
    if(sdata.length>0&&sdata!= null){
            for(var index in sdata){
                if(sdata[index]['@name']=="user"){
                    obj.UserName = sdata[index]['#text'];
                }
                if(sdata[index]['@name']=="city_for_news"){
                    obj.Location = sdata[index]['#text'];
                }
                if(sdata[index]['@name']=="uid"){
                    obj.ID = sdata[index]['#text'];
                }
            }
    }
    if(ldata.length>0&&ldata!=null){
            for(var i in ldata){
                if(ldata[i]['@name']=="time"){
                    obj.Time = XLY.Convert.LinuxToDateTime(ldata[i]['@value']);
                }
            }
    }
    list.push(obj);
    //for(var i in data){
    //    var obj = new UserInfo();
    //    obj.UserName = data[i];
    //    list.push(obj);
    //}
    return list;
}

function bindTree(){
    var accountname = "select distinct account_name from bookmarks where XLY_DataType='"+2+"'";
    var data = ExecSql(db_bm,accountname);
    var news = new TreeNode();
    news.Text = "2345浏览器";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
    var userXml = eval('(' + XLY.File.ReadXML(ui_xml) + ')');
    var usernamedata = userXml.map.string;
    for(var i in usernamedata){
        if(usernamedata[i]["@name"]=="user"){
            var news1 = new TreeNode();
            news1.Text = usernamedata[i]["#text"];
            news1.Type = "UserInfo";
            news1.Items = getUserInfo(ui_xml);
            news1.DataState = "Normal";
            news.TreeNodes.push(news1);
        }
    }
    var news2 = new TreeNode();
    news2.Text = "书签";
    news2.Type = "BookmarkNode";
    news2.Items = getBookmarkNode(db_bm);
    news2.DataState = "Normal";
    news.TreeNodes.push(news2);
    
    for(var i in data){
        if(data[i].account_name=="2345"){
            newTreeNode("默认用户","Bookmark",getBookmark(db_bm,data[i].account_name),news2);
        }
        else if(data[i].account_name==null || data[i].account_name==""){
            newTreeNode("未知用户","Bookmark",getBookmark(db_bm,data[i].account_name),news2);
        }
        else
        {
            newTreeNode(data[i].account_name,"Bookmark",getBookmark(db_bm,data[i].account_name),news2);
        }
    }
    newTreeNode("搜索","SearchWords",getSearchWord(db_sw),news);
    newTreeNode("浏览记录","History",getHistory(db_bm),news);
    newTreeNode("视频播放记录","VideoHistory",getVideoHistory(db_vh),news);
    newTreeNode("下载","DownloadFile",getDownload(db_dl),news);
    newTreeNode("Cookies","Cookies",getCookies(db_ck),news);
    result.push(news);
}

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
