﻿/*[config]
<plugin name="百度地图,1" group="地图公交,5" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\baiduMap.png" app="com.baidu.map" version="6.2.0" description="百度地图" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.baidu.map</value>
</source>

<data  type="Search">
<item name="历史搜索地址" code="Addr" type="string" width="200" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
<item name="搜索方式" code="Way" type="string" width="100" format=""></item>
</data>

<data  type="Searchpoi">
<item name="历史搜索地址" code="Addr" type="string" width="300" format=""></item>

</data>

<data  type="Searchroute">
<item name="搜索起点" code="Start" type="string" width="300" format=""></item>
<item name="搜索终点" code="Dest" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>
    
<data  type="Favorite">
<item name="详细地址" code="Addr" type="string" width="200" format=""></item>
<item name="经度" code="Longitude" type="string" width="120" format=""></item>
<item name="纬度" code="Latitude" type="string" width="120" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>    
</data>

<data type="Route">
<item name="行进路线" code="Instructions" type="string" width="400" format=""></item>   
</data>

<data  type="Navigate">
<item name="导航起点" code="Start" type="string" width="200" ></item>
<item name="导航终点" code="Dest" type="string" width="200" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
<item name="导航方式" code="Type" type="string" width="100" format=""></item>
</data>
    
<data  type="Solution">
<item name="方案" code="Plan" type="string" width="200" format=""></item>
<item name="与目标地的距离(米)" code="Dis" type="string" width="200" format=""></item>
</data>

</plugin>
[config]*/

// js content

//定义数据结构
function Navigate() {
    this.Start = "";
    this.Dest = "";
    this.Time = null;
    this.Type = "";
}

function Search() {
    this.Addr = "";
    this.Time = null;
    this.Way = "";
}

function Searchpoi() {
    this.Addr = "";
    //this.Time = null;
}

function Searchroute() {
    this.Start = "";
    this.Dest = "";
    this.Time = null;
}

function Solution() {
    this.Dis = "";
    this.Plan = ""
}

function Route() {
    this.Instructions = "";
}

function Favorite() {
    this.Addr = "";
    this.Longitude = "";
    this.Latitude = "";
    this.Time = null;
}

//获取到达目的地方案信息
function GetSolution(infos, num) {
    var leg = infos.legs;
    var list = new Solution();
    list.Dis = leg.distance;
    list.Plan = "方案" + (++num);
    return list;
}

//获取导航地址信息
function GetNavigate(value, time) {
    var list = new Navigate();
    var dest = value.Fav_Sync.endnode;
    var start = value.Fav_Sync.startnode;
    list.Start = start.usname + "(" + "经度" + start.x / 100000 + ";" + "纬度" + start.y / 100000 + ")";
    list.Dest = dest.usname + "(" + "经度" + dest.x / 100000 + ";" + "纬度" + dest.y / 100000 + ")";
    list.Time = XLY.Convert.LinuxToDateTime(time);
    list.Type = GetString(value.Fav_Sync.uspathname);
    return list;
}

//获取公交导航路线信息
function GetRoute(infos) {
    var line = infos.busline;
    var list = new Route();
    var info = line[0];
    if (info.instructions != null) {
        list.Instructions = info.instructions;
    }
    return list;
}

//获取步行或驾车路线信息
function GetLine(infos) {
    var list = new Route();
    list.Instructions = infos.description;
    return list;
}

//获取搜索地点的信息
function GetSearchp(poi) {
    var arr = new Array();
    for (var p in poi) {
        var data = ExecEval(poi[p].value);
        var list = new Search();
        list.Addr = data.poiHisValue;
        list.Time = XLY.Convert.LinuxToDateTime(data.addtimesec);
        list.Way = "地点搜索";
        arr[p] = list;
    }
    return arr;
}

function GetSearchpoi(infos) {
    var list = new Searchpoi();
    list.Addr = infos.key;
    //var time = ExecEval(infos.value);
    //list.Time = XLY.Convert.LinuxToDateTime(time.addtimesec);
    return list;
}

//获取搜索路线信息
function GetSearchr(route) {
    var arr = new Array();
    for (var r in route) {
        var list = new Search();
        var datar = ExecEval(route[r].value);
        list.Addr = datar.efavnode.name+"("+"经度:"+datar.efavnode.geoptx/100000+"纬度:"+datar.efavnode.geopty/100000+")";
        list.Time = XLY.Convert.LinuxToDateTime(datar.addtimesec);
        list.Way = "路线搜索";
        arr[r] = list;
    }
    return arr;
}

function GetSearchroute(infos) {
    var list = new Searchroute();
    var data = ExecEval(infos.value);
    list.Start = data.sfavnode.name + "(" + "经度" + data.sfavnode.geoptx / 100000 + ";" + "纬度" + data.sfavnode.geopty / 100000 + ")";
    list.Dest = data.efavnode.name + "(" + "经度" + data.efavnode.geoptx / 100000 + ";" + "纬度" + data.efavnode.geopty / 100000 + ")";
    list.Time = XLY.Convert.LinuxToDateTime(data.addtimesec);
    return list;
}

//获取收藏夹信息
function GetFavorite(infos) {
    var list = new Favorite();
    var data = infos.value;
    var info = ExecEval(data);
    var con = info.Fav_Sync;
    list.Addr = con.uspoiname
    list.Longitude = con.pt.x / 100000;
    list.Latitude = con.pt.y / 100000;
    list.Time = XLY.Convert.LinuxToDateTime(infos.key);
    return list
}

//创建简单的一级树模型
function BuildSimpleTree(treeinfos, treename, method) {
    for (var index in treeinfos) {
        var list = treeinfos[index];
        var treeinfo = method(list);
        treename.Items.push(treeinfo);
    }
}

//创建并获得导航路线信息树
function BuildSolutionTree(treeinfos, treename) {
    for (var index in treeinfos) {
        var list = treeinfos[index];
        var treeinfo = GetSolution(list, index);
        treename.Items.push(treeinfo);
    }
}

//json化字符串
function ExecEval(object) {
    var infos = eval('(' + object + ')');
    return infos;
}

//处理通过SQL语句查询
function ExecSql(path, sql) {
    var infos = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    return infos;
}

//获取字符串的特定子串
function GetString(str) {
    var newstr = str.slice(0, 2);
    return newstr;

}

//合并两条json数组
function objConcat(a1, a2) {
    var newarr = new Array();
    var p = 0;
    for (var k1 in a1) {
        newarr[k1] = a1[k1];
        p = k1;
    }
    p = parseInt(p) + 1;
    for (var k2 in a2) {
        newarr[p + parseInt(k2)] = a2[k2];
    }
    return newarr;
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

var result = new Array();
var source = $source;
var dataRoot=source[0]+"\\com.baidu.map\\Documents";

//var dataRoot = "C:\\Users\\Administrator\\Desktop\\11\\Documents";
//定义和查询历史搜索的信息
var poihispath = dataRoot + "/his_record.sdb";
var psql = "select id,key,cast(value as text)as value from his_record order by id";
var poihisdata = ExecSql(poihispath, psql);
var routehispath = dataRoot + "/routeHis_record.sdb";
var routehissql = "select id,key,cast(value as text)as value from routeHis_record order by id";
var routehisdata = ExecSql(routehispath, routehissql);

//创建历史搜索树
var searchTree = new TreeNode();
searchTree.Text = "历史搜索";
searchTree.Type = "Search";
var searchinfosp = GetSearchp(poihisdata);
var searchinfosr = GetSearchr(routehisdata);
var searchdata = objConcat(searchinfosp, searchinfosr);
searchTree.Items = searchdata;

//创建地点搜索树
var poihisTree = new TreeNode();
poihisTree.Text = "地点搜索";
poihisTree.Type = "Searchpoi";
BuildSimpleTree(poihisdata, poihisTree, GetSearchpoi);

//创建路线搜索树
var routehisTree = new TreeNode();
routehisTree.Text = "路线搜索";
routehisTree.Type = "Searchroute";
BuildSimpleTree(routehisdata, routehisTree, GetSearchroute);
searchTree.TreeNodes.push(poihisTree);
searchTree.TreeNodes.push(routehisTree);

//创建收藏点树结构并获取值
var favpath = dataRoot + "/fav_poi.sdb";
var fsql = "select key,cast(value as text)as value from fav_poi";
var favdata = ExecSql(favpath, fsql);
var favoriteTree = new TreeNode();
favoriteTree.Text = "收藏地点";
favoriteTree.Type = "Favorite";
BuildSimpleTree(favdata, favoriteTree, GetFavorite);

//定义导航树结构
var navipath = dataRoot + "/fav_route.sdb"
var navisql = "select key,cast(value as text)as value from fav_route";
var nividata = ExecSql(navipath, navisql);
var navigateTree = new TreeNode();
navigateTree.Text = "导航信息";
navigateTree.Type = "Navigate";

//处理导航路线的数据结构
for (var index in nividata) {
    var infos = nividata[index].value;
    var time = nividata[index].key
    var value = ExecEval(infos);
    var naviinfo = GetNavigate(value, time);
    navigateTree.Items.push(naviinfo);

    //提取公交方式导航的信息
    if (value.Fav_Sync.eplankind == 3) {
        var content = value.Fav_Content;
        var con = eval('(' + content + ')');
        var solutionTree = new TreeNode();
        solutionTree.Text = value.Fav_Sync.endnode.usname + "(" + GetString(value.Fav_Sync.uspathname) + ")";
        solutionTree.Type = "Solution";
        BuildSolutionTree(con.routes, solutionTree, GetSolution);
        for (var i in con.routes) {
            var step = con.routes[i].legs.steps;
            var routeTree = new TreeNode();
            routeTree.Text = "方案" + (++i);
            routeTree.Type = "Route";
            BuildSimpleTree(step, routeTree, GetRoute);
            solutionTree.TreeNodes.push(routeTree);
        }
    }

    //提取步行或驾车导航的信息
    if (value.Fav_Sync.eplankind == 0) {
        var content = value.Fav_Content;
        var con = eval('(' + content + ')');
        var solutionTree = new TreeNode();
        solutionTree.Text = value.Fav_Sync.endnode.usname + "(" + GetString(value.Fav_Sync.uspathname) + ")";
        solutionTree.Type = "Route";
        var step = con.routes.legs.steps;
        BuildSimpleTree(step, solutionTree, GetLine);
    }
    navigateTree.TreeNodes.push(solutionTree);
}

//返回各级树的信息
result.push(searchTree);
result.push(favoriteTree);
result.push(navigateTree);
//返回该APP的所有信息
var res = JSON.stringify(result);
res;
