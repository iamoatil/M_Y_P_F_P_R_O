﻿/*[config]
<plugin name="备忘录,8" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\note.png" app="com.apple.Memo" version="7.1" description="提取IOS设备备忘录信息" data="$data" >
<source>
<value>com.apple.Memo</value>
</source>
<data type="NoteMsg" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="信息" code="NoteBody" type="string" width="200" ></item>
<item name="创建日期" code="CreateDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="150" ></item>
<item name="最后修改日期" code="LastEditDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="150" ></item>
</data>
</plugin>
[config]*/

/*定义数据结构*/
function NoteMsg() {
    this.DataState = "Normal";
    this.NoteBody = "";
    this.LastEditDate = null;
    this.CreateDate = null;
}



function GetLocalDate(timeStamp) {
    if (timeStamp == null) {
        return null;
    }
    else {
        return XLY.Convert.ToDateTime(2001, 1, 1, timeStamp);
    }
}

function GetNoteInfo(path){
    var data = eval('(' + XLY.Sqlite.Find(path, " SELECT NTB.[XLY_DataType], NTB.[ZCONTENT] AS NoteBody ,CAST(NT.[ZCREATIONDATE] AS TEXT) AS InDate ,CAST(NT.[ZMODIFICATIONDATE] AS TEXT) AS LastEditDate FROM ZNOTEBODY NTB LEFT JOIN ZNOTE NT  ON NT.[Z_PK] = NTB.[Z_PK] ORDER BY NT.[ZMODIFICATIONDATE] DESC ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new NoteMsg();        
        obj.NoteBody = data[index].NoteBody;
        obj.CreateDate = GetLocalDate(data[index].InDate); // XLY.Convert.ToDateTime(2001, 1, 1, data[index].InDate);
        obj.LastEditDate = GetLocalDate(data[index].LastEditDate); // XLY.Convert.ToDateTime(2001, 1, 1, data[index].LastEditDate);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);


        info.push(obj)
    }
    return info;
}

var tableList = "ZNOTE,ZNOTEBODY";
var source = $source;
var searchPath = source[0];
var searchPath = searchPath + "\\HomeDomain\\Library\\Notes\\notes.sqlite";
var chailb = "chalib\\IOS_Note\\notes_V7.sqlite.charactor";
var dbpath = XLY.Sqlite.DataRecovery(searchPath, chailb, tableList);
searchPath = dbpath;

var result = new Array();

result=GetNoteInfo(searchPath);

var res = JSON.stringify(result);
res;
