﻿/*[config]
<plugin name="快牙,10" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/kuaiya.png" app="com.dewmobile.kuaiya" version="4.9.1" description="快牙" data="$data,ComplexTreeDataSource"  >
<source>
    <value>/data/data/com.dewmobile.kuaiya#F</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="UserAccount" type="string" width="120" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="快牙号" code="KuaiYaId" type="string" width="150" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="头像本地链接" code="LocalHeadUrl" type="url" width="120" format = "" ></item>
    <item name="个性签名" code="PersonalSign" type="string" width="120" format = "" ></item>
</data>
<data type = "Message" detailfield = "body" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="senderID" type="string" width="80" format = ""></item>
    <item name="发送者姓名" code="senderName" type="string" width="100" format = ""></item>
    <item name="接收者ID" code="receiverID" type="string" width="80" format = ""></item>
    <item name="接收者姓名" code="receiverName" type="string" width="100" format = ""></item>
    <item name="内容" code="body" type="string" width="120" format = ""></item>
    <item name="补充" code="addPath" type="string" width="80" format = ""></item>
    <item name="发送时间" code="time" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>
<data type = "FileTransfer" detailfield = "FilePath" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="senderID" type="string" width="80" format = ""></item>
    <item name="发送者姓名" code="senderName" type="string" width="100" format = ""></item>
    <item name="接收者ID" code="receiverID" type="string" width="80" format = ""></item>
    <item name="接收者姓名" code="receiverName" type="string" width="100" format = ""></item>
    <item name="文件类型" code="FileType" type="string" width="120" format = ""></item>
    <item name="文件名" code="FileName" type="string" width="120" format = ""></item>
    <item name="文件路径" code="FilePath" type="string" width="120" format = ""></item>
    <item name="文件大小" code="FileSize" type="string" width="80" format = ""></item>
    <item name="已接收大小" code="FileReceiveSize" type="string" width="80" format = ""></item>
    <item name="已接收时间" code="FileReceiveTim" type="string" width="80" format = ""></item>
    <item name="发送时间" code="time" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>
<data type = "LocalFile" detailfield = "" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="文件名" code="FileName" type="string" width="150" format = ""></item>
    <item name="文件大小" code="FileSize" type="string" width="150" format = ""></item>
    <item name="本地路径" code="LocalPath" type="string" width="300" format = ""></item>
</data>
<data type = "Dynamic" detailfield = "" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="150" format = ""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="150" format = ""></item>
    <item name="标题" code="Title" type="string" width="100" format = ""></item>
    <item name="首页图片链接" code="PageUrl" type="url" width="300" format = ""></item>
    <item name="大小" code="Size" type="string" width="100" format = ""></item>
    <item name="时间" code="Time" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="内容链接" code="ContentUrl" type="url" width="300" format = ""></item>
</data>
<data type = "GroupInfo" detailfield = "" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群组名" code="GroupName" type="string" width="150" format = ""></item>
    <item name="群组介绍" code="GroupDescription" type="string" width="150" format = ""></item>
    <item name="群主" code="GroupOwner" type="string" width="150" format = ""></item>
    <item name="群组最大人数" code="MaxUsersCount" type="string" width="80" format = ""></item>
    <item name="群组人数" code="UsersCount" type="string" width="80" format = ""></item>
    <item name="群组成员" code="GroupMember" type="string" width="100" format = ""></item>
</data>
</plugin>
[config]*/
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Dynamic数据结构
function Dynamic(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.Title = "";
    this.PageUrl = "";
    this.Size = "";
    this.Time = null;
    this.ContentUrl = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserAccount = "";
    this.NickName = "";
    this.KuaiYaId = "";
    this.Sex = "";
    this.HeadUrl = "";
    this.LocalHeadUrl = "";
    this.PersonalSign = "";
}
function Message() {
    this.DataState = "Normal"; 
    this.senderID = ""; 
    this.senderName = ""; 
    this.receiverID = "";
    this.receiverName = "";
    this.body = ""; 
    this.addPath = ""; 
    this.time = null;   
}
function FileTransfer() {
    this.DataState = "Normal";
    this.senderID = "";
    this.senderName = "";
    this.receiverID = "";
    this.receiverName = "";
    this.FileType = "";
    this.FileName = "";
    this.FilePath = "";
    this.FileSize = "";
    this.FileReceiveSize = "";
    this.FileReceiveTim = "";
    this.time = null; 
}
function LocalFile() {
    this.DataState = "Normal";  
    this.FileName = "";  
    this.FileSize = ""; 
    this.LocalPath = ""; 
}
function GroupInfo() {
    this.DataState = "Normal";  
    this.GroupName = "";  
    this.GroupDescription = ""; 
    this.MaxUsersCount = ""; 
    this.UsersCount = ""; 
    this.GroupMember = ""; 
    this.GroupOwner = "";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];
//测试数据
//var allPath = "D:\\temp1\\data\\data\\com.dewmobile.kuaiya";
//定义特征库文件
var charactor1 = "\\chalib\\Android_Kuaiya_V4.9.1\\27764308.db.charactor";
var charactor2 = "\\chalib\\Android_Kuaiya_V4.9.1\\dynamic_db.db.charactor";
var charactor3 = "\\chalib\\Android_Kuaiya_V4.9.1\\im_user.db.charactor";
var charactor4 = "\\chalib\\Android_Kuaiya_V4.9.1\\search.db.charactor";
var charactor5 = "\\chalib\\Android_Kuaiya_V4.9.1\\transfer20.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "快牙";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var dbPath = allPath +"\\files";
    var dbData = eval('('+ XLY.File.FindDirectories(dbPath) +')');
    var aa = 0;
    for(var d in dbData){
        if(XLY.File.GetFileName(dbData[d])=="easemobDB"){
            aa = 1;
        }
    }
    if(aa==1){
        var userPath = allPath +"\\files\\easemobDB\\";
        var filePath = eval('('+ XLY.File.FindFiles(userPath) +')');
        if(filePath!=""&&filePath!=null){
            for(var i in filePath){
                var fileUserId = XLY.File.GetFileName(filePath[i]);
                var id = fileUserId.substr(0,fileUserId.length-3)
                var userPath1 = allPath+"\\databases\\im_user.db";
                var userPath = XLY.Sqlite.DataRecovery(userPath1,charactor3,"contact,profiles");
                if(XLY.File.IsValid(userPath)){
                    var userinfo = eval('('+ XLY.Sqlite.Find(userPath,"select p_pf from profiles where p_uid = '"+id+"'") +')');
                    if(userinfo!=""&&userinfo!= null){
                        var node = new TreeNode();
                        node.Type = "UserInfo";
                        getAccountInfo(node,userinfo[0].p_pf,id);
                        if(node.Text!=""&&node.Text!=null){
                            root.TreeNodes.push(node);
                            var fur = "conversation,group,message";
                            var filePathA = XLY.Sqlite.DataRecovery(filePath[i],charactor1,fur);
                            getUserInfo(node,userPath,filePathA);
                        }
                    }
                }
            }    
        }   
    }
    else
    {
        var userPath = allPath +"\\shared_prefs\\localUser.xml";
        if(XLY.File.IsValid(userPath)){
            var userInfo1 = eval('('+ XLY.File.ReadXML(userPath) +')');
            if(userInfo1!=""&&userInfo1!= null){
                var userInfo = userInfo1.map.string;
                for(var i in userInfo){
                    if(userInfo[i]["@name"]=="profile"){
                        var node = new TreeNode();
                        node.Type = "UserInfo";
                        var obj = new UserInfo();
                        node.Text = eval('('+ userInfo[i]["#text"] +')').deviceName;
                        obj.NickName = eval('('+ userInfo[i]["#text"] +')').deviceName;
                        node.Items.push(obj);
                        
                        var fileSendPath1 = allPath + "\\databases\\transfer20.db";
                        var fileSendPath = XLY.Sqlite.DataRecovery(fileSendPath1,charactor5,"transfer");
                        if(XLY.File.IsValid(fileSendPath)){
                            var fileSendData = eval('('+ XLY.Sqlite.Find(fileSendPath,"select XLY_DataType,category,name,direction,createtime,path,url,totalbytes,currentbytes,elapse,title,owner_zid from transfer where net = '0'") +')');
                            if(fileSendData!=""&&fileSendData!=null){
                                var fileSendNode = new TreeNode();
                                fileSendNode.Text = "文件传输";
                                fileSendNode.Type = "FileTransfer";
                                for(var f in fileSendData){
                                    var fileSendObj = new FileTransfer();
                                    fileSendObj.DataState = XLY.Convert.ToDataState(fileSendData[f].XLY_DataType);
                                    if(fileSendData[f].direction==0){
                                        fileSendObj.senderID = root.Text.split("_")[0];
                                        fileSendObj.senderName = root.Text.split("_")[1];
                                        fileSendObj.receiverID = fileSendData[f].owner_zid;
                                        fileSendObj.receiverName = fileSendData[f].name;
                                    }
                                    else
                                    {
                                        fileSendObj.senderName = fileSendData[f].name;
                                        fileSendObj.receiverID = root.Text.split("_")[0];
                                        fileSendObj.receiverName = root.Text.split("_")[1];
                                    }
                                    if(fileSendData[f].category=="app"){
                                        fileSendObj.FileType = "应用程序";
                                    }
                                    else if(fileSendData[f].category=="folder"){
                                        fileSendObj.FileType = "文件";
                                    }
                                    else
                                    {
                                        fileSendObj.FileType = "其他";
                                    }
                                    
                                    fileSendObj.FileName = fileSendData[f].title;
                                    fileSendObj.FilePath = fileSendData[f].path;
                                    fileSendObj.FileSize = fileSendData[f].totalbytes/1024 + " KB";
                                    fileSendObj.FileReceiveSize = fileSendData[f].currentbytes/1024 +" KB";
                                    fileSendObj.FileReceiveTim = fileSendData[f].elapse/60+" 秒";
                                    fileSendObj.time = XLY.Convert.LinuxToDateTime(fileSendData[f].createtime); 
                                    fileSendNode.Items.push(fileSendObj);
                                }
                                if(fileSendNode.Items!=""&&fileSendNode.Items!=null){
                                    node.TreeNodes.push(fileSendNode);
                                }
                            }
                        }
                        var filePath1 = allPath + "\\databases\\search.db";
                        var filePath = XLY.Sqlite.DataRecovery(filePath1,charactor4,"searchCache");
                        if(XLY.File.IsValid(filePath)){
                            var contactId = eval('('+ XLY.Sqlite.Find(filePath,"select distinct(category) from searchCache") +')');
                            if(contactId!=""&&contactId!= null){
                                var LocalFileNode = new TreeNode();
                                LocalFileNode.Text = "本地文件";
                                LocalFileNode.Type = "News";
                                for(var i in contactId){
                                    if(contactId[i].category==1){
                                        var node1 = new TreeNode();
                                        node1.Text = "应用";
                                        node1.Type = "LocalFile";
                                        getLocalFileInfo(node1,contactId[i].category,filePath);
                                        if(node1.Items!=""&&node1.Items!=null){
                                            LocalFileNode.TreeNodes.push(node1);
                                        }
                                    }
                                    if(contactId[i].category==2){
                                        var node1 = new TreeNode();
                                        node1.Text = "视频";
                                        node1.Type = "LocalFile";
                                        getLocalFileInfo(node1,contactId[i].category,filePath);
                                        if(node1.Items!=""&&node1.Items!=null){
                                            LocalFileNode.TreeNodes.push(node1);
                                        }
                                    }
                                    if(contactId[i].category==3){
                                        var node1 = new TreeNode();
                                        node1.Text = "音乐";
                                        node1.Type = "LocalFile";
                                        getLocalFileInfo(node1,contactId[i].category,filePath);
                                        if(node1.Items!=""&&node1.Items!=null){
                                            LocalFileNode.TreeNodes.push(node1);
                                        }
                                    }
                                    if(contactId[i].category==5){
                                        var node1 = new TreeNode();
                                        node1.Text = "文件";
                                        node1.Type = "LocalFile";
                                        getLocalFileInfo(node1,contactId[i].category,filePath);
                                        if(node1.Items!=""&&node1.Items!=null){
                                            LocalFileNode.TreeNodes.push(node1);
                                        }
                                    }
                                }
                                node.TreeNodes.push(LocalFileNode);
                            }
                        }
                        root.TreeNodes.push(node);
                    }
                }
            }
        }
    }
}
function getAccountInfo(root,data1,id){
    var data = eval('('+ data1 +')');
    var obj = new UserInfo();
    //obj.DataState = XLY.Convert.ToDataState()
    obj.UserAccount = data.trans;
    obj.NickName = data.nick;
    obj.KuaiYaId = id;
    if(data.gd==0){
        obj.Sex = "女";
    }
    else if(data.gd==1)
    {
        obj.Sex = "男";
    }
    else
    {
        obj.Sex = "未指定";
    }
    obj.HeadUrl = data.avurl;
    obj.LocalHeadUrl = allPath+"\\files\\avatar";
    obj.PersonalSign = data.sg;
    
    root.Text = obj.KuaiYaId+"_"+obj.NickName;
    root.Items.push(obj);
}
function getUserInfo(root,temp,messagePath){
    var contactId = eval('('+ XLY.Sqlite.Find(temp,"select c_uid from contact") +')');
    if(contactId!=""&&contactId!=null){
        var node = new TreeNode();
        node.Text = "联系人";
        node.Type = "UserInfo";
        for(var i in contactId){
            var contactInfo = eval('('+ XLY.Sqlite.Find(temp,"select XLY_DataType,p_pf from profiles where p_uid = '"+contactId[i].c_uid+"'") +')');
            if(contactInfo!=""&&contactInfo!=null){
                var contactData = eval('('+ contactInfo[0].p_pf +')');
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(contactInfo[0].XLY_DataType);
                obj.UserAccount = contactData.trans;
                obj.NickName = contactData.nick;
                obj.KuaiYaId = contactId[i].c_uid;
                if(contactData.gd==0){
                    obj.Sex = "女";
                }
                else if(contactData.gd==1)
                {
                    obj.Sex = "男"; 
                }
                else
                {
                    obj.Sex = "未指定";
                }
                obj.HeadUrl = contactData.avurl;
                obj.LocalHeadUrl = allPath+"\\files\\avatar";
                obj.PersonalSign = contactData.sg;
                node.Items.push(obj);
            }
        }
        if(node.Items!=""&&node.Items!=null){
            root.TreeNodes.push(node); 
        }
    }
    var dynamicPath1 = allPath + "\\databases\\dynamic_db.db";
    var dynamicPath = XLY.Sqlite.DataRecovery(dynamicPath1,charactor2,"follow_dynamic");
    if(XLY.File.IsValid(dynamicPath)){
        var dynamicData = eval('('+ XLY.Sqlite.Find(dynamicPath,"select XLY_DataType,ruid,content from follow_dynamic") +')');
        if(dynamicData!=""&&dynamicData!= null){
            var dynamicNode = new TreeNode();
            dynamicNode.Text = "动态" ;
            dynamicNode.Type = "Dynamic";
            for(var i in dynamicData){
                if(dynamicData[i].XLY_DataType==2){
                    var dynamicObj = new Dynamic();
                    dynamicObj.DataState = XLY.Convert.ToDataState(dynamicData[i].XLY_DataType);
                    dynamicObj.SenderID = dynamicData[i].ruid;
                    var dynamicIdToName = eval('('+ XLY.Sqlite.Find(temp,"select p_pf from profiles where p_uid = '"+dynamicObj.SenderID+"'") +')');
                    if(dynamicIdToName!=""&&dynamicIdToName!= null){
                        var eachDynamicName = eval('('+ dynamicIdToName[0].p_pf +')');
                        if(eachDynamicName.nick!=""&&eachDynamicName.nick!= null){
                            dynamicObj.SenderName = eachDynamicName.nick;
                        }
                    }
                    var yur = eval('('+ dynamicData[i].content +')');
                    dynamicObj.Title = yur.n;
                    dynamicObj.PageUrl = yur.t;
                    dynamicObj.Size = yur.s/1024 + " KB";
                    dynamicObj.Time = XLY.Convert.LinuxToDateTime(yur.dt);
                    dynamicObj.ContentUrl = yur.u;
                    dynamicNode.Items.push(dynamicObj);
                }
            }
            if(dynamicNode.Items!=""&&dynamicNode.Items!=null){
                root.TreeNodes.push(dynamicNode);
            }
        }
    }
    var fileSendPath1 = allPath + "\\databases\\transfer20.db";
    var fileSendPath = XLY.Sqlite.DataRecovery(fileSendPath1,charactor5,"transfer");
    if(XLY.File.IsValid(fileSendPath)){
        var fileSendData = eval('('+ XLY.Sqlite.Find(fileSendPath,"select XLY_DataType,category,name,direction,createtime,path,url,totalbytes,currentbytes,elapse,title,owner_zid from transfer where net = '0'") +')');
        if(fileSendData!=""&&fileSendData!=null){
            var fileSendNode = new TreeNode();
            fileSendNode.Text = "文件传输";
            fileSendNode.Type = "FileTransfer";
            for(var f in fileSendData){
                var fileSendObj = new FileTransfer();
                fileSendObj.DataState = XLY.Convert.ToDataState(fileSendData[f].XLY_DataType);
                if(fileSendData[f].direction==0){
                    fileSendObj.senderID = root.Text.split("_")[0];
                    fileSendObj.senderName = root.Text.split("_")[1];
                    fileSendObj.receiverID = fileSendData[f].owner_zid;
                    fileSendObj.receiverName = fileSendData[f].name;
                }
                else
                {
                    var sendFileId = eval('('+ XLY.Sqlite.Find(temp,"select c_uid from contact where c_nk = '"+fileSendData[f].name+"'") +')');
                    if(sendFileId!=""&&sendFileId!=null){
                        fileSendObj.senderID = sendFileId[0].c_uid;
                    }
                    fileSendObj.senderName = fileSendData[f].name;
                    fileSendObj.receiverID = root.Text.split("_")[0];
                    fileSendObj.receiverName = root.Text.split("_")[1];
                }
                if(fileSendData[f].category=="app"){
                    fileSendObj.FileType = "应用程序";
                }
                else if(fileSendData[f].category=="folder"){
                    fileSendObj.FileType = "文件";
                }
                else
                {
                    fileSendObj.FileType = "其他";
                }
                
                fileSendObj.FileName = fileSendData[f].title;
                fileSendObj.FilePath = fileSendData[f].path;
                fileSendObj.FileSize = fileSendData[f].totalbytes/1024 + " KB";
                fileSendObj.FileReceiveSize = fileSendData[f].currentbytes/1024 +" KB";
                fileSendObj.FileReceiveTim = fileSendData[f].elapse/60+" 秒";
                fileSendObj.time = XLY.Convert.LinuxToDateTime(fileSendData[f].createtime); 
                fileSendNode.Items.push(fileSendObj);
            }
            if(fileSendNode.Items!=""&&fileSendNode.Items!=null){
                root.TreeNodes.push(fileSendNode);
            }
        }
    }
    var filePath1 = allPath + "\\databases\\search.db";
    var filePath = XLY.Sqlite.DataRecovery(filePath1,charactor4,"searchCache");
    if(XLY.File.IsValid(filePath)){
        var contactId = eval('('+ XLY.Sqlite.Find(filePath,"select distinct(category) from searchCache") +')');
        if(contactId!=""&&contactId!= null){
            var LocalFileNode = new TreeNode();
            LocalFileNode.Text = "本地文件";
            LocalFileNode.Type = "News";
            for(var i in contactId){
                if(contactId[i].category==1){
                    var node = new TreeNode();
                    node.Text = "应用";
                    node.Type = "LocalFile";
                    getLocalFileInfo(node,contactId[i].category,filePath);
                    if(node.Items!=""&&node.Items!=null){
                        LocalFileNode.TreeNodes.push(node);
                    }
                }
                if(contactId[i].category==2){
                    var node = new TreeNode();
                    node.Text = "视频";
                    node.Type = "LocalFile";
                    getLocalFileInfo(node,contactId[i].category,filePath);
                    if(node.Items!=""&&node.Items!=null){
                        LocalFileNode.TreeNodes.push(node);
                    }
                }
                if(contactId[i].category==3){
                    var node = new TreeNode();
                    node.Text = "音乐";
                    node.Type = "LocalFile";
                    getLocalFileInfo(node,contactId[i].category,filePath);
                    if(node.Items!=""&&node.Items!=null){
                        LocalFileNode.TreeNodes.push(node);
                    }
                }
                if(contactId[i].category==5){
                    var node = new TreeNode();
                    node.Text = "文件";
                    node.Type = "LocalFile";
                    getLocalFileInfo(node,contactId[i].category,filePath);
                    if(node.Items!=""&&node.Items!=null){
                        LocalFileNode.TreeNodes.push(node);
                    }
                }
            }
            root.TreeNodes.push(LocalFileNode);
        }
    }
    if(XLY.File.IsValid(messagePath)){
        var groupData = eval('('+ XLY.Sqlite.Find(messagePath,"select groupid,groupsubject,groupdescription,groupowner,members,memberscount,maxuserscount from 'group'") +')');
        if(groupData!=""&&groupData!=null){
            var groupNode = new TreeNode();
            groupNode.Text = "群组";
            groupNode.Type = "News";    
            for(var i in groupData){
                var groupChildNode = new TreeNode();
                groupChildNode.Text = groupData[i].groupid+"_"+groupData[i].groupsubject;
                groupChildNode.Type = "GroupInfo";
                var groupObj = new GroupInfo();
                //groupObj.DataState = XLY.Convert.ToDataState(groupData[i].XLY_DataType); 
                groupObj.GroupName = groupData[i].groupsubject;  
                groupObj.GroupDescription = groupData[i].groupdescription; 
                groupObj.MaxUsersCount = groupData[i].maxuserscount; 
                groupObj.UsersCount = groupData[i].memberscount; 
                var bb = eval('('+ XLY.Sqlite.Find(temp,"select p_pf from profiles where p_uid = '"+groupData[i].groupowner+"'") +')');
                if(bb!=""&&bb!= null){
                    var cc = eval('('+ bb[0].p_pf +')');
                    if(cc.nick!=""&&cc.nick!=null){
                        groupObj.GroupOwner = cc.nick;
                    }
                }
                var dd = groupData[i].members.split(",");
                var fur = "";
                for(var j in dd){
                    var everyGroupMemberName = eval('('+ XLY.Sqlite.Find(temp,"select p_pf from profiles where p_uid = '"+dd[j]+"'") +')');
                    if(everyGroupMemberName!=""&&everyGroupMemberName!=null){
                        var everyGroupMember = eval('('+ everyGroupMemberName[0].p_pf +')');
                        if(everyGroupMember.nick!=""&&everyGroupMember.nick!= null){
                            if(j==dd.length-1){
                                fur += dd[j]+"_"+everyGroupMember.nick;
                            }
                            else
                            {
                                fur += dd[j]+"_"+everyGroupMember.nick+"\r";
                            }
                        }
                    }
                }
                groupObj.GroupMember = fur; 
                groupChildNode.Items.push(groupObj);
                groupNode.TreeNodes.push(groupChildNode);
            }
            root.TreeNodes.push(groupNode);
        }
        var conversationId = eval('('+ XLY.Sqlite.Find(messagePath,"select id,type from conversation") +')');
        if(conversationId!=""&&conversationId!=null){
            var messageNode = new TreeNode();
            messageNode.Text = "聊天记录";
            messageNode.Type = "News";
            var groupA = 0;
            var groupIdArr = new Array();
            var friendB = 0;
            var friendIdArr = new Array();
            for(var i in conversationId){
                if(conversationId[i].type==0){
                    friendB+= 1;
                    friendIdArr.push(conversationId[i].id);
                }
                if(conversationId[i].type==1){
                    groupA+= 1;
                    groupIdArr.push(conversationId[i].id);
                }
            }
            var groupNodeA = new TreeNode();
            groupNodeA.Text = "群组聊天记录";
            groupNodeA.Type = "News";
            
            var friendNodeB = new TreeNode();
            friendNodeB.Text = "好友聊天记录";
            friendNodeB.Type = "News";
            
            if(groupA!= 0){
                for(var j in groupIdArr){
                    var groupNodeAChild = new TreeNode();
                    var groupIdToName = eval('('+ XLY.Sqlite.Find(messagePath,"select groupsubject from 'group' where groupid = '"+groupIdArr[j]+"'") +')');
                    if(groupIdToName!=""&&groupIdToName!=null){
                        groupNodeAChild.Text = groupIdArr[j]+"_"+groupIdToName[0].groupsubject;
                        groupNodeAChild.Type = "Message";
                        getGroupMessage(groupNodeAChild,groupIdArr[j],groupIdToName[0].groupsubject,messagePath,temp,0);
                    }
                    if(groupNodeAChild.Items!=""&&groupNodeAChild.Items!=null){
                        groupNodeA.TreeNodes.push(groupNodeAChild);
                    }
                }
                if(groupNodeA.TreeNodes!=""&&groupNodeA.TreeNodes!=null){
                    messageNode.TreeNodes.push(groupNodeA);
                }
            }
            if(friendB!= 0){
                for(var j in friendIdArr){
                    var friendNodeAChild = new TreeNode();
                    var friendIdToName = eval('('+ XLY.Sqlite.Find(temp,"select p_pf from profiles where p_uid = '"+friendIdArr[j]+"'") +')');
                    if(friendIdToName!=""&&friendIdToName!=null){
                        var eachFriendName = eval('('+ friendIdToName[0].p_pf +')');
                        if(eachFriendName.nick!=""&&eachFriendName.nick!= null){
                            friendNodeAChild.Text = friendIdArr[j]+"_"+eachFriendName.nick;
                        }
                    }
                    friendNodeAChild.Type = "Message";
                    getGroupMessage(friendNodeAChild,friendIdArr[j],friendNodeAChild.Text.split("_")[1],messagePath,temp,1);
                    if(friendNodeAChild.Items!=""&&friendNodeAChild.Items!=null){
                        friendNodeB.TreeNodes.push(friendNodeAChild);
                    }
                }
                if(friendNodeB.TreeNodes!=""&&friendNodeB.TreeNodes!=null){
                    messageNode.TreeNodes.push(friendNodeB);
                }
            }
            if(messageNode.TreeNodes!=""&&messageNode.TreeNodes!=null){
                root.TreeNodes.push(messageNode);
            }
        }
    }
}
function getLocalFileInfo(root,type,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,path,fileName,length from searchCache where category = '"+type+"'") +')');
    if(data!=""&&data!= null){
        for(var i in data){
            var obj = new LocalFile();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);  
            obj.FileName = data[i].fileName;  
            obj.FileSize = data[i].length/1024+" KB"; 
            obj.LocalPath = data[i].path; 
            root.Items.push(obj);
        }
    }
}
function getGroupMessage(root,id,name,path,userpath,flag){
    var data = eval('('+ XLY.Sqlite.Find(path,"select cast (msgtime as int) as time,isread,msgdirection,msgbody,XLY_DataType from message where conversation = '"+id+"'") +')');
    if(data!=""&&data!=null){
        for(var i in data){
            if(data[i].XLY_DataType==2){
                var obj = new Message();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                var aa = eval('('+ data[i].msgbody +')');
                obj.senderID = aa.from; 
                var senName = eval('('+ XLY.Sqlite.Find(userpath,"select p_pf from profiles where p_uid = '"+obj.senderID+"'") +')');
                if(senName!=""&&senName!=null){
                    var fur = eval('('+ senName[0].p_pf +')');
                    obj.senderName = fur.nick;
                }
                
                obj.receiverID = aa.to;
                if(flag==0){
                    obj.receiverName = name;
                }
                else
                {
                    var reiName = eval('('+ XLY.Sqlite.Find(userpath,"select p_pf from profiles where p_uid = '"+obj.receiverID+"'") +')');
                    if(reiName!=""&&reiName!=null){
                        var fur = eval('('+ reiName[0].p_pf +')');
                        obj.receiverName = fur.nick;
                    }
                }
                obj.body = ""; 
                for(var j in aa.bodies){
                    if(j==aa.bodies.length-1){
                        obj.body+= aa.bodies[j].msg;
                    }
                    else
                    {
                        obj.body+= aa.bodies[j].msg+",";
                    }
                }
                
                var fur = {};
                if(aa.ext!=""&&aa.ext!=null){
                    for(var m in aa.ext){
                        for(var key in aa.ext[m]){
                            if(key=="from"){
                                fur.from = aa.ext[m][key];
                            }
                            if(key=="type"){
                                fur.type = aa.ext[m][key];
                            }
                            if(key=="uids"){
                                fur.uids = aa.ext[m][key];
                            }
                            if(key=="z_msg_length"){
                                fur.z_msg_length = aa.ext[m][key];
                            }
                            if(key=="z_msg_name"){
                                fur.z_msg_name = aa.ext[m][key];
                            }
                            if(key=="z_msg_s_path"){
                                fur.z_msg_s_path = aa.ext[m][key];
                            }
                            if(key=="z_msg_size"){
                                fur.z_msg_size = aa.ext[m][key];
                            }
                            if(key=="z_msg_url"){
                                fur.z_msg_url = aa.ext[m][key];
                            }
                            if(key=="name"){
                                fur.name = aa.ext[m][key];
                            }
                        }
                    }
                }
                if(fur!=""&&fur!=null){
                    if(fur.from!=""&&fur.from!= null){
                        if(fur.name!=""&&fur.name!= null){
                            obj.addPath = fur.from+" 修改了群名称为 " +fur.name;
                        }
                        else
                        {
                            obj.addPath = fur.from+" 邀请了 " +fur.uids;
                        }
                    }
                    else
                    {
                        if(fur.z_msg_name!=""&&fur.z_msg_name!= null){
                            obj.addPath+= "附件名："+fur.z_msg_name+"\r";
                        }
                        if(fur.z_msg_s_path!=""&&fur.z_msg_s_path!= null){
                            obj.addPath+= "附件路径："+fur.z_msg_s_path+"\r";
                        }
                        if(fur.z_msg_size!=""&&fur.z_msg_size!= null){
                            obj.addPath+= "附件大小："+fur.z_msg_size+"\r";
                        }
                        if(fur.z_msg_url!=""&&fur.z_msg_url!= null){
                            obj.addPath+= "附件链接："+fur.z_msg_url;
                        }
                    }
                }
                obj.time = XLY.Convert.LinuxToDateTime(data[i].time)
                root.Items.push(obj);
            }
        }
    }
    
}