﻿/*[config]
<plugin name="车来了,6" group="地图公交,7" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/chelaile.png" app="com.chelaile.lite" version="5.28.0" description="车来了" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.chelaile.lite</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="GroupID"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="组ID" code="List" type="string" width = "150"></item>
</data>
<data type="SearchWord"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关键字" code="Key" type="string" width = "150"></item>
    <item name="地点城市ID" code="City" type="string" width = "150"></item>
    <item name="类型" code="SearchType" type="string" width = "120"></item>
    <item name="创建时间" code="CreateTime"  type="string" width="150" format = ""></item>
    <item name="更新时间" code="UpdateTime"  type="string" width="150" format = ""></item>
</data>
<data type="SearchRoute"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="开始地点" code="StartName" type="string" width = "120"></item>
    <item name="目的地点" code="EndName" type="string" width = "120"></item>
    <item name="地点城市" code="City" type="string" width = "120"></item>
    <item name="创建时间" code="CreateTime"  type="string" width="150" format = ""></item>
    <item name="更新时间" code="UpdateTime"  type="string" width="150" format = ""></item>
    <item name="开始地点经度" code="StartLng"  type="string" width="120" format = ""></item>
    <item name="开始地点纬度" code="StartLat"  type="string" width="120" format = ""></item>
    <item name="目的地点经度" code="EndLng"  type="string" width="120" format = ""></item>
    <item name="目的地点纬度" code="EndLat"  type="string" width="120" format = ""></item>
</data>
<data type="BookMark" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="地点名" code="AddressName" type="string" width="120" format = "" ></item>
    <item name="地点" code="Address" type="string" width="120" format = "" ></item>
    <item name="地点城市ID" code="City" type="string" width="120" format = "" ></item>
    <item name="经度" code="Lng"  type="string" width="120" format = ""></item>
    <item name="纬度" code="Lat"  type="string" width="120" format = ""></item>
    <item name="创建时间" code="CreateTime"  type="string" width="150" format = ""></item>
    <item name="更新时间" code="UpdateTime"  type="string" width="150" format = ""></item>
</data>
<data type="Message" contract="DataState" datefilter="SenderHeadUrl">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者id" code="SenderId" type="string" width="120" format = "" ></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="发送者头像" code="SenderHeadUrl" type="url" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="发送状态" code="ContentType" type="string" width="120" format=""></item>
    <item name="发送时间" code="MessageSendTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="接收时间" code="MessageReceiveTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="已读" code="IsRead" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="120" format = "" ></item>
    <item name="姓名" code="Name" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="string" width="120" format = "" ></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义GroupID数据结构
function GroupID(){
    this.DataState = "Normal";
    this.List = "";
}
//定义SearchWord数据结构
function SearchWord(){
    this.DataState = "Normal";
    this.Key = "";
    this.City = "";
    this.SearchType = "";
    this.CreateTime = "";
    this.UpdateTime = "";
}
//定义BookMark数据结构
function BookMark(){
    this.DataState = "Normal";
    this.AddressName = "";
    this.Address = "";
    this.City = "";
    this.Lng = "";
    this.Lat = "";
    this.CreateTime = "";
    this.UpdateTime = "";
}
//定义SearchRoute数据结构
function SearchRoute(){
    this.DataState = "Normal";
    this.StartName = "";
    this.EndName = "";
    this.City = "";
    this.CreateTime = "";
    this.UpdateTime = "";
    this.StartLng = "";
    this.StartLat = "";
    this.EndLng = "";
    this.EndLat = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
    this.HeadUrl = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderId = "";
    this.SenderName = "";
    this.SenderHeadUrl = "";
    this.Content = "";
    this.ContentType = "";
    this.MessageSendTime = null;
    this.MessageReceiveTime = null;
    this.IsRead = "";
}
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.chelaile.lite\\Documents";
var userIDPath = source[0]+"\\com.chelaile.lite\\Library\\Preferences\\com.chelaile.lite.plist";
var cookPath = source[0]+"\\com.chelaile.lite\\Library\\Cookies\\Cookies.binarycookies";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.chelaile.lite\\Documents";
//var userIDPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.chelaile.lite\\Library\\Preferences\\com.chelaile.lite.plist";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.chelaile.lite\\Library\\Cookies\\Cookies.binarycookies";
//定义特征库文件
var mycharactor = "\\chalib\\iOS_Chelaile_V5.28.0\\mydatabase.sqlite.charactor";
var scharactor = "\\chalib\\iOS_Chelaile_V5.28.0\\storage.charactor";
//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "车来了";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userIDPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(userIDPath) +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].userInfo!=""&&data[i].userInfo!=null){
                    //var aa =  XLY.Blob.ToString(data[i].userInfo,"base64");
                    var nodeUser = new TreeNode();
                    nodeUser.Text = "健身房好好";
                    nodeUser.Type = "UserInfo";
                    root.TreeNodes.push(nodeUser);
                    getUserChildNode(nodeUser);
                }
            }
        }
    }
}
function getUserChildNode(root){
    var myDataBasePath = allPath + "\\mydatabase.sqlite";
    var cllLocalCityListPath = allPath + "\\CLLLocalCityList.plist";
    var bmdehs6pddopsPath = allPath + "\\bmdehs6pddops";
    if(XLY.File.IsValid(myDataBasePath)){
        var dataQueryHistory = eval('('+ XLY.Sqlite.Find(myDataBasePath,"select * from cll_query_history") +')');
        var dataTransferSchemeHistory = eval('('+ XLY.Sqlite.Find(myDataBasePath,"select * from cll_transfer_scheme_history") +')');
        var dataTransitQueryHistoryNew = eval('('+ XLY.Sqlite.Find(myDataBasePath,"select * from cll_transit_query_history_new") +')');
        if(dataQueryHistory!=""&&dataQueryHistory!=null){
            var qhNode = new TreeNode();
            qhNode.Text = "搜索关键字";
            qhNode.Type = "SearchWord";
            root.TreeNodes.push(qhNode);
            for(var a in dataQueryHistory){
                var qhObj = new SearchWord();
                //qhObj.DataState = XLY.Convert.ToDataState(dataQueryHistory[a].XLY_DataType);
                qhObj.Key = dataQueryHistory[a].item_name;
                qhObj.City = dataQueryHistory[a].city_id;
                if(dataQueryHistory[a].type==1){
                    qhObj.SearchType = "车站";
                }
                else if(dataQueryHistory[a].type==2){
                    qhObj.SearchType = "地点";
                }
                else if(dataQueryHistory[a].type==0){
                    qhObj.SearchType = "巴士路线";
                }
                else
                {
                }
                qhObj.CreateTime = dataQueryHistory[a].create_time;
                qhObj.UpdateTime = dataQueryHistory[a].update_time;
                qhNode.Items.push(qhObj);
            }
        }
        if(dataTransferSchemeHistory!=""&&dataTransferSchemeHistory!=null){
            var tshNode = new TreeNode();
            tshNode.Text = "搜索路线";
            tshNode.Type = "SearchRoute";
            root.TreeNodes.push(tshNode);
            for(var b in dataTransferSchemeHistory){
                var tshObj = new SearchRoute();
                //tshObj.DataState = XLY.Convert.ToDataState(dataTransferSchemeHistory[b].XLY_DataType);
                tshObj.StartName = dataTransferSchemeHistory[b].start_name;
                tshObj.EndName = dataTransferSchemeHistory[b].end_name;
                tshObj.City = dataTransferSchemeHistory[b].city_id;
                tshObj.CreateTime = dataTransferSchemeHistory[b].create_time;
                tshObj.UpdateTime = dataTransferSchemeHistory[b].update_time;
                tshObj.StartLng = dataTransferSchemeHistory[b].start_lng;
                tshObj.StartLat = dataTransferSchemeHistory[b].start_lat;
                tshObj.EndLng = dataTransferSchemeHistory[b].end_lng;
                tshObj.EndLat = dataTransferSchemeHistory[b].end_lat;
                tshNode.Items.push(tshObj);
            }
        }
        if(dataTransitQueryHistoryNew!=""&&dataTransitQueryHistoryNew!=null){
            var tqhNode = new TreeNode();
            tqhNode.Text = "地点书签";
            tqhNode.Type = "BookMark";
            root.TreeNodes.push(tqhNode);
            for(var c in dataTransitQueryHistoryNew){
                var tqhObj = new BookMark();
                //tqhObj.DataState = XLY.Convert.ToDataState(dataTransitQueryHistoryNew[c].XLY_DataType);
                tqhObj.AddressName = dataTransitQueryHistoryNew[c].name;
                tqhObj.Address = dataTransitQueryHistoryNew[c].address;
                tqhObj.City = dataTransitQueryHistoryNew[c].city_id;
                tqhObj.Lng = dataTransitQueryHistoryNew[c].lng;
                tqhObj.Lat = dataTransitQueryHistoryNew[c].lat;
                tqhObj.CreateTime = dataTransitQueryHistoryNew[c].create_time;
                tqhObj.UpdateTime = dataTransitQueryHistoryNew[c].update_time;
                tqhNode.Items.push(tqhObj);
            }
        }
    }
    var bmdata = eval('('+ XLY.File.FindDirectories(bmdehs6pddopsPath) +')');
    if(bmdata!=""&&bmdata!=null){
        for(var m in bmdata){
            var aa = bmdata[m].substr(bmdehs6pddopsPath.length+1,bmdata[m].length);
            var messagePath = bmdata[m]+"\\storage";
            if(XLY.File.IsValid(messagePath)){
                var messageDataGroup = eval('('+ XLY.Sqlite.Find(messagePath,"select group_id from RCT_GROUP") +')');
                if(messageDataGroup!=""&&messageDataGroup!= null){
                    var mesNode = new TreeNode();
                    mesNode.Text = "上车聊聊";
                    mesNode.Type = "GroupID";
                    root.TreeNodes.push(mesNode);
                    for(var s in messageDataGroup){
                        var mesChildNode = new TreeNode();
                        mesChildNode.Text = messageDataGroup[s].group_id;
                        mesChildNode.Type = "Message";
                        mesNode.TreeNodes.push(mesChildNode);
                        var mesObj = new GroupID();
                        mesObj.List = mesChildNode.Text;
                        mesNode.Items.push(mesObj);
                        
                        var messageData = eval('('+ XLY.Sqlite.Find(messagePath,"select * from RCT_MESSAGE where target_id = '"+messageDataGroup[s].group_id+"'") +')');
                        if(messageData!=""&&messageData!= null){
                            for(var g in messageData){
                                var mesChildObj = new Message();
                                //mesChildObj.DataState = XLY.Convert.ToDataState(messageData[g].XLY_DataType);
                                mesChildObj.SenderId = messageData[g].sender_id;
                                var bb = eval('('+ messageData[g].content +')');
                                if(bb.user!=""&&bb.user!=null){
                                    mesChildObj.SenderName = bb.user.name;
                                }
                                if(bb.user!=""&&bb.user!=null){
                                    mesChildObj.SenderHeadUrl = bb.user.icon;
                                }
                                if(bb.content!=""&&bb.content!=null){
                                    mesChildObj.Content = bb.content;
                                }
                                if(messageData[g].send_status==30){
                                    mesChildObj.ContentType = "正常发送";
                                }
                                else
                                {
                                    mesChildObj.ContentType = "发送失败";
                                }
                                
                                mesChildObj.MessageSendTime = XLY.Convert.LinuxToDateTime(messageData[g].send_time);
                                mesChildObj.MessageReceiveTime = XLY.Convert.LinuxToDateTime(messageData[g].receive_time);
                                if(messageData[g].read_status==1){
                                    mesChildObj.IsRead = "是";
                                }
                                else
                                {
                                    mesChildObj.IsRead = "否";
                                }
                                mesChildNode.Items.push(mesChildObj);
                            }
                        }
                    }
                }
            }
        }
    }
    if(XLY.File.IsValid(cookPath)){
        var nodeCook = new  TreeNode();
        nodeCook.Text = "Cache缓存";
        nodeCook.Type = "Cache";
        getCache(nodeCook);
        root.TreeNodes.push(nodeCook);
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
