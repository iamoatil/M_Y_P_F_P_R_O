﻿/*[config]
<plugin name="Facebook,10" group="社交聊天,2" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Facebook.png" app="com.facebook.katana" version="38.0.0.47.240" description="Facebook" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.facebook.katana/databases#F</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Account" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="生日" code="Birthday" type="string" width="120" ></item>
<item name="邮箱" code="Email" type="string" width = "120" ></item>
<item name="电话" code="Phone" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
</data>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="Contact"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="生日" code="Birthday" type="string" width="120" ></item>
<item name="头像" code="Avatar" type="string" width = "120" ></item>
<item name="添加时间" code="Time" type="string" width="120" ></item>
</data>
<data type="Group"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "120" ></item>
<item name="ID1" code="ID1" type="string" show = "false" width = "120" ></item>
<item name="成员" code="Member" type="string" width = "120" ></item>
<item name="成员ID" code="MID" type="string" width = "120" ></item>
</data>
<data type="Msg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="消息ID" code="ID" type="string" width="100" ></item>
<item name="发送者" code="Sender" type="string" width="120" ></item>
<item name="接收者" code="Receiver" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="附件" code="Attatchment" type="string" width = "120" ></item>
<item name="经纬度" code="Coordinate" type="string" width = "120" ></item>
<item name="来源" code="Source" type="string" width = "120" ></item>
</data>
<data type="Fmsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
<item name="ID1" code="ID1" type="string" show = "false" width = "120" ></item>
</data>
<data type="FrMsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="消息ID" code="ID" type="string" width="100" ></item>
<item name="发送者" code="Sender" type="string" width="120" ></item>
<item name="接收者" code="Receiver" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="附件" code="Attatchment" type="string" width = "120" ></item>
<item name="来源" code="Source" type="string" width = "120" ></item>
</data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account() {
    this.Name = "";
    this.ID = "";
    this.Email = "";
    this.Phone = "";
    this.Avatar = "";
    this.Birthday = "";
    this.DataState = "Normal";
}

function Contact() {
    this.Name = "";
    this.ID = "";
    this.Email = "";
    this.Phone = "";
    this.Avatar = "";
    this.Birthday = "";
    this.Time = "";
    this.DataState = "Normal";
}
function Info(){
    this.Acc = "";
}
function Group() {
    this.DataState = "Normal";
    this.ID = "";
    this.ID1 = "";
    this.Name = "";
    this.Member = "";
    this.MID = "";
}
function Msg() {
    this.DataState = "Normal";
    this.Sender = "";
    this.ID = "";
    this.Receiver = "";
    this.Time = "";
    this.Attatchment = "";
    this.Coordinate = "";
    this.Source = "";
}
function Fmsg() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID1 = "";
}
function FrMsg() {
    this.DataState = "Normal";
    this.Sender = "";
    this.ID = "";
    this.Receiver = "";
    this.Time = "";
    this.Attatchment = "";
    this.Coordinate = "";
    this.Source = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "Facebook";
    news.Type = "Info"; 
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
       for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account"; 
        account.Items = accountinfo;
        news.TreeNodes.push(account);
        
        var gr = new TreeNode();
        gr.Text = "群组";
        gr.Type = "Group";       
        gr.Items = getGroup(db2);  
        account.TreeNodes.push(gr);
       
                var msg = new  TreeNode();
        msg.Text = "好友消息";
        msg.Type = "Fmsg";
        msginfo = getFmsg(db2,accountinfo);
        msg.Items = msginfo;
        msg.DataState = "Normal";
        account.TreeNodes.push(msg);
        
           for(var k in msginfo){  
            var fmsg = new TreeNode();
            fmsg.Text = msginfo[k].Name;     
            fmsg.Type = "FrMsg";
            fmsg.Items = getFrMsg(db2,msginfo[k],accountinfo);              
            fmsg.DataState = "Normal";    
            msg.TreeNodes.push(fmsg);
           }
        
        var contact = new TreeNode();
        contact.Text = "联系人";
        contact.Type = "Contact";
        var contactinfo = getContact(db1);   
        contact.Items = contactinfo;
        account.TreeNodes.push(contact);
        
        var group = new TreeNode();
        group.Text = "群组消息";
        group.Type = "Group";
        var groupinfo = getGroup(db2);       
        //group.Items = groupinfo;
        account.TreeNodes.push(group);
       for(var j in groupinfo){  
                var message = new TreeNode();
                message.Text = groupinfo[j].ID;     
                message.Type = "Msg";
                message.Items = getMsg(db2,groupinfo[j],accountinfo);              
                message.DataState = "Normal";    
                group.TreeNodes.push(message);
       }

     }
result.push(news);    
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from preferences where key ='/auth/user_data/fb_me_user'" ) +')');   
    for(var i in data){
        var obj = new Account();
        var info = eval('('+ data[i].value +')');
        obj.Name = info.name;
        obj.ID = info.uid;
        obj.Birthday = info.birth_date_year+info.birth_date_month+info.birth_date_day;
        obj.Email = info.emails[0] +"," + info.emails[1];
        obj.Phone = info.phones[0];
        obj.Avatar = info.pic_square;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getContact(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from contacts" ) +')');   
    for(var i in data){
        var obj = new Contact();
        obj.Name = data[i].display_name;
        obj.ID = data[i].fbid;
        obj.Birthday = data[i].bday_month+"月"+data[i].bday_day+"日";
        obj.Avatar = data[i].big_picture_url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].added_time_ms);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from threads where thread_key like '%GROUP%'" ) +')');   
    for(var i in data){
        var obj = new Group();
        obj.Name = data[i].name;
        obj.ID1 = data[i].thread_key;
        obj.ID = data[i].thread_key.slice(6,data[i].thread_key.length);
        var mem = eval('('+ data[i].participants +')'); 
        for(var j in mem){
            obj.Member += mem[j].name+"、";
            obj.MID += mem[j].user_key.slice(9,mem[j].user_key.length)+"、";
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp_ms)
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getMsg(path,groupinfo,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from messages where thread_key = '"+groupinfo.ID1+"'" ) +')');
    for(var i in data){
        var obj = new Msg();
        var send = eval('('+ data[i].sender +')');
        if(send != null){
           obj.Sender = send.name; 
        }
        obj.Content = data[i].text;
        obj.ID = data[i].msg_id;
        obj.Receiver = groupinfo.ID; 
        obj.Attatchment = data[i].attachments;
        var coo = eval('('+ data[i].coordinates +')');
        obj.Source = data[i].source;  
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp_ms);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFmsg(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from threads where thread_key like '%ONE%' group by thread_key" ) +')');
    for(var i in data){
        var obj = new Fmsg();
        var name = eval('('+ data[i].participants +')');
        if(name[1].name == accountinfo[0].Name){
          obj.Name = name[0].name;
        }
        else
        {
          obj.Name = name[1].name;
        }
        obj.ID1 = data[i].thread_key;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFrMsg(path,msginfo,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from messages where thread_key = '"+msginfo.ID1+"'" ) +')');
    for(var i in data){
        var obj = new FrMsg();
        var send = eval('('+ data[i].sender +')');
        if(send != null){
           obj.Sender = send.name;       
       if(send.name == accountinfo[0].Name){
           obj.Receiver = msginfo.Name; 
       }
       else
       {
         obj.Receiver = accountinfo[0].Name; 
       } 
        }   
        obj.Content = data[i].text;
        obj.ID = data[i].msg_id;       
        obj.Attatchment = data[i].attachments;
        var coo = eval('('+ data[i].coordinates +')');
        //log(data[i].coordinates);
         //obj.Coordinate = 
        obj.Source = data[i].source;  
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp_ms);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0]+"\\prefs_db";
var db1 = source[0]+"\\contacts_db2";
var db2 = source[0]+"\\threads_db2";

//var charactor1 = "\\chalib\\Android_FaceBook_V38.0.0.47.240\\prefs_db.charactor";
//var charactor2 = "\\chalib\\Android_FaceBook_V38.0.0.47.240\\contacts_db2.charactor";
//var charactor3 = "\\chalib\\Android_FaceBook_V38.0.0.47.240\\threads_db2.charactor";

//var db="D:\\temp\\data\\data\\com.facebook.katana\\databases\\prefs_db";
//var db1 = "D:\\temp\\data\\data\\com.facebook.katana\\databases\\contacts_db2";
//var db2="D:\\temp\\data\\data\\com.facebook.katana\\databases\\threads_db2";
//var charactor1 = "D:\\temp\\data\\data\\com.facebook.katana\\databases\\prefs_db.charactor";
//var charactor2 = "D:\\temp\\data\\data\\com.facebook.katana\\databases\\contacts_db2.charactor";
//var charactor3 = "D:\\temp\\data\\data\\com.facebook.katana\\databases\\threads_db2.charactor";
//var db = XLY.Sqlite.DataRecovery(db4,charactor1,"preferences");
//var db1 = XLY.Sqlite.DataRecovery(db5,charactor2,"contacts");
//var db2 = XLY.Sqlite.DataRecovery(db6,charactor3,"threads,messages");


var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;

