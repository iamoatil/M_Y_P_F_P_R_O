﻿/*[config]
<plugin name="陌陌,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/icon_momo.png" app="com.wemomo.momoappdemo1" version="7.6.0" description="陌陌" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.wemomo.momoappdemo1</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="出生年月" code="Birthday" type="string" width="120" format = "" ></item>
    <item name="星座" code="Constellation" type="string" width="120" format = "" ></item>
    <item name="个人签名" code="Sign" type="string" width="120" format = "" ></item>
    <item name="家乡" code="SpHomeTown" type="string" width="120" format = "" ></item>
    <item name="注册日期" code="JoinDate" type="string" width="120" format = "" ></item>
    <item name="登录时间" code="LocTimesec" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="职业" code="NameTag" type="string" width="120" format = "" ></item>
    <item name="标签" code="UserLabels" type="string" width="120" format = "" ></item>
    <item name="个人说明" code="Website" type="string" width="120" format = "" ></item>
    <item name="电影" code="Movie" type="string" width="120" format = "" ></item>
    <item name="音乐" code="Music" type="string" width="120" format = "" ></item>
    <item name="书籍" code="Book" type="string" width="120" format = "" ></item>
</data>
<data type="Contact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="姓名" code="UserName" type="string" width="120" format = "" ></item>
    <item name="电话号码" code="PhoneNumber" type="string" width="120" format=""></item>
    <item name="陌陌号" code="MomoNumber" type="string" width="120" format=""></item>
</data>
<data type="Dynamic" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="评论人昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="评论人陌陌号" code="UserName" type="string" width="200" format = "" ></item>
    <item name="类型" code="DynamicType" type="string" width="200" format=""></item>
    <item name="备注" code="DynamicStatus" type="string" width="200" format=""></item>
    <item name="内容" code="DynamicContent" type="string" width="200" format=""></item>
    <item name="时间" code="DynamicTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format=""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="接收者ID" code="ReciveID" type="string" width="120" format=""></item>
    <item name="接收者姓名" code="ReciveName" type="string" width="120" format=""></item>
    <item name="发送时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="内容" code="Content" type="string" width="100" format = ""></item>
    <item name="类型" code="ContentType" type="string" width="100" format=""></item>
</data>
<data type="MessageGroup" contract="DataState" datefilter="Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format=""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="接收者ID" code="ReciveID" type="string" width="120" format=""></item>
    <item name="接收者姓名" code="ReciveName" type="string" width="120" format=""></item>
    <item name="发送时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="内容" code="Content" type="string" width="100" format = ""></item>
    <item name="类型" code="ContentType" type="string" width="100" format=""></item>
    <item name="等级" code="Rank" type="string" width="100" format=""></item>
</data>
<data type="GroupInfo" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群名称" code="GroupName" type="string" width="120" format=""></item>
    <item name="群等级" code="GroupLevel" type="string" width="120" format=""></item>
    <item name="群主" code="GroupOwner" type="string" width="120" format=""></item>
    <item name="招人简介" code="GroupIntroduce" type="string" width="120" format=""></item>
    <item name="成员个数" code="GroupMemberCount" type="string" width="120" format = ""></item>
    <item name="最大成员个数" code="GroupLimitCount" type="string" width="120" format=""></item>
    <item name="站点" code="GroupSiteName" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreateTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="DiscussInfo" contract="DataState" datefilter="GroupMember">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="GroupName" type="string" width="120" format=""></item>
    <item name="等级" code="GroupLevel" type="string" width="120" format=""></item>
    <item name="群主" code="GroupOwner" type="string" width="120" format=""></item>
    <item name="成员个数" code="GroupMemberCount" type="string" width="120" format = ""></item>
    <item name="最大成员个数" code="GroupLimitCount" type="string" width="120" format=""></item>
    <item name="成员" code="GroupMember" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreateTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function DiscussInfo(){
    this.DataState = "Normal";
    this.GroupLevel = "";
    this.GroupName = "";
    this.GroupOwner = "";
    this.GroupMemberCount = "";
    this.GroupMember = "";
    this.GroupLimitCount = "";
    this.CreateTime = null;
}
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupLevel = "";
    this.GroupName = "";
    this.GroupOwner = "";
    this.GroupIntroduce = "";
    this.GroupMemberCount = "";
    this.GroupSiteName = "";
    this.GroupLimitCount = "";
    this.CreateTime = null;
}
function Dynamic(){
    this.DataState = "Normal";
    this.UserNickName = "";
    this.UserName = "";
    this.DynamicType = "";
    this.DynamicStatus = "";
    this.DynamicContent = "";
    this.DynamicTime = null;
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.NickName = "";
    this.Email = "";
    this.Sex = "";
    this.Birthday = "";
    this.Constellation = "";
    this.Sign = "";
    this.SpHomeTown = "";
    this.NameTag = "";
    this.LocTimesec = null;
    this.UserLabels = "";
    this.Website = "";
    this.Movie = "";
    this.Music = "";
    this.Book = "";
    this.JoinDate = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PhoneNumber = "";
    this.MomoNumber = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReciveID = "";
    this.ReciveName = "";
    this.StartTime = null;
    this.Content = "";
    this.ContentType = "";
}
//定义MessageGroup数据结构
function MessageGroup(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReciveID = "";
    this.ReciveName = "";
    this.StartTime = null;
    this.Content = "";
    this.ContentType = "";
    this.Rank = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.wemomo.momoappdemo1\\Documents";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-04-24-17-19-17\\source\\IosData\\2017-04-24-17-21-39\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.wemomo.momoappdemo1\\Documents";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_Momo_V7.6.0\\u.474432438.sqlite.charactor";
var charactor2 = "\\chalib\\iOS_Momo_V7.6.0\\u.474432438.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "陌陌";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var data = eval('('+ XLY.File.FindFileNamesWithExtension(allPath) +')');
    var reg = new RegExp("u.","i");
    var reg1 = new RegExp("main","i");
    var reg2 = new RegExp("user","i");
    if(data!=""&&data!=null){
        for(var i in data){
            if(reg.test(data[i])){
                if(!reg1.test(data[i])){
                    if(!reg2.test(data[i])){
                        var aa = data[i].split(".")[1];
                        var infoPath1 = allPath+"\\db\\"+data[i];
                        var eeeee = "";
                        var dataDiscuss = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_mdcontactdiscuss_v12'") +')');
                        if(dataDiscuss!=""&&dataDiscuss!=null){
                            eeeee+= dataDiscuss[0].tbl_name+",";
                        }
                        var dataFans = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_mdcontactfans_v12'") +')');
                        if(dataFans!=""&&dataFans!=null){
                            eeeee+= dataFans[0].tbl_name+",";
                        }
                        var dataFollow = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_mdcontactfollow_v12'") +')');
                        if(dataFollow!=""&&dataFollow!=null){
                            eeeee+= dataFollow[0].tbl_name+",";
                        }
                        var dataGroup = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_mdcontactgroup_v12'") +')');
                        if(dataGroup!=""&&dataGroup!=null){
                            eeeee+= dataGroup[0].tbl_name+",";
                        }
                        var dataDiscussProfile = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_mddiscussprofile_v12'") +')');
                        if(dataDiscussProfile!=""&&dataDiscussProfile!=null){
                            eeeee+= dataDiscussProfile[0].tbl_name+",";
                        }
                        var dataUserProfile = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_mduserprofile_v12'") +')');
                        if(dataUserProfile!=""&&dataUserProfile!=null){
                            eeeee+= dataUserProfile[0].tbl_name+",";
                        }
                        
                        var dataGroupProfileInfo = eval('('+ XLY.Sqlite.Find(infoPath1,"select distinct tbl_name from sqlite_master where tbl_name = 'eta_momogroupprofileinfo_v12'") +')');
                        if(dataGroupProfileInfo!=""&&dataGroupProfileInfo!=null){
                            eeeee+= dataGroupProfileInfo[0].tbl_name+",";
                        }
                        eeeee = eeeee.substr(0,eeeee.length-1);
                        var infoPath = XLY.Sqlite.DataRecovery(infoPath1,charactor2,eeeee);
                        var node = new TreeNode();
                        if(aa!= "1000478346179"){
                            var usernameinfo = eval('('+ XLY.Sqlite.Find(infoPath,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+aa+"'") +')');
                            if(usernameinfo!=""&&usernameinfo!=null){
                                node.Text = aa+"_"+usernameinfo[0].u_name;
                            }
                            else
                            {
                                node.Text = aa;
                                
                            }
                            
                        }
                        else
                        {
                            node.Text = aa+"_默认账户";
                        }
                        node.Type = "UserInfo";
                        root.TreeNodes.push(node);
                        getUserChaildNode(node,data[i],aa,infoPath);
                    }
                }
            }
        }
    }
}
function getUserChaildNode(root,info,user,infoPath){
    if(info!=""&&info!=null){
        var userPath1 = allPath+"\\"+info;
        var nodeAllFri = new TreeNode();
        nodeAllFri.Text = "好友信息";
        nodeAllFri.Type = "News";
        
        var groupAndDiscussNode = new TreeNode();
        groupAndDiscussNode.Text = "群组信息";
        groupAndDiscussNode.Type = "News";
        
        var messageroot = new TreeNode();
        messageroot.Text = "聊天消息";
        messageroot.Type = "News";
                
        if(XLY.File.IsValid(infoPath)){
            var dataUser = eval('('+ XLY.Sqlite.Find(infoPath,"select * from eta_mduserprofile_v12 where u_momoid = '"+info.split(".")[1]+"'") +')');
            if(dataUser!=""&&dataUser!= null){
                getUserInfomation(root,dataUser)
            }
            var dataFans = eval('('+ XLY.Sqlite.Find(infoPath,"select u_id from eta_mdcontactfans_v12") +')');
            if(dataFans!=""&&dataFans!= null){
                var nodeFans = new TreeNode();
                nodeFans.Text = "粉丝";
                nodeFans.Type = "UserInfo";
                for(var f in dataFans){
                    var dataFansFans = eval('('+ XLY.Sqlite.Find(infoPath,"select * from eta_mduserprofile_v12 where u_momoid = '"+dataFans[f].u_id+"'") +')');
                    if(dataFansFans!=""&&dataFansFans!=null){
                        getUserInfomation(nodeFans,dataFansFans);
                    }
                }
                if(nodeFans.Items!=""&&nodeFans.Items!=null){
                    nodeAllFri.TreeNodes.push(nodeFans);
                }
            }
            var dataFollow = eval('('+ XLY.Sqlite.Find(infoPath,"select u_id from eta_mdcontactfollow_v12") +')');
            if(dataFollow!=""&&dataFollow!= null){
                var nodeFollow = new TreeNode();
                nodeFollow.Text = "关注";
                nodeFollow.Type = "UserInfo";
                for(var w in dataFollow){
                    var dataFollowFollow = eval('('+ XLY.Sqlite.Find(infoPath,"select * from eta_mduserprofile_v12 where u_momoid = '"+dataFollow[w].u_id+"'") +')');
                    if(dataFollowFollow!=""&&dataFollowFollow!=null){
                        getUserInfomation(nodeFollow,dataFollowFollow);
                    }
                }
                if(nodeFollow.Items!=""&&nodeFollow.Items!=null){
                    nodeAllFri.TreeNodes.push(nodeFollow);
                }
            }
            var dataGroup = eval('('+ XLY.Sqlite.Find(infoPath,"select g_id from eta_mdcontactgroup_v12") +')');
            if(dataGroup!=""&&dataGroup!= null){
                var nodeGroup = new TreeNode();
                nodeGroup.Text = "群信息";
                nodeGroup.Type = "GroupInfo";
                for(var g in dataGroup){
                    var dataGroupGroup = eval('('+ XLY.Sqlite.Find(infoPath,"select * from eta_momogroupprofileinfo_v12 where gi_groupid = '"+dataGroup[g].g_id+"'") +')');
                    if(dataGroupGroup!=""&&dataGroupGroup!=null){
                        getGroupInfomation(nodeGroup,dataGroupGroup,infoPath);
                    }
                }
                if(nodeGroup.Items!=""&&nodeGroup.Items!=null){
                    groupAndDiscussNode.TreeNodes.push(nodeGroup);
                }
            }
            var dataDiscuss = eval('('+ XLY.Sqlite.Find(infoPath,"select  from eta_mddiscussprofile_v12") +')');
            if(dataDiscuss!=""&&dataDiscuss!= null){
                var nodeDiscuss = new TreeNode();
                nodeDiscuss.Text = "讨论组信息";
                nodeDiscuss.Type = "DiscussInfo";
                getDiscussInfomation(nodeDiscuss,dataDiscuss,infoPath);
                if(nodeDiscuss.Items!=""&&nodeDiscuss.Items!=null){
                    groupAndDiscussNode.TreeNodes.push(nodeDiscuss);
                }
            }
        }
        if(XLY.File.IsValid(userPath1)){
            //好友表名
            var data7 = eval('('+ XLY.Sqlite.Find(userPath1,"select distinct tbl_name from sqlite_master where tbl_name like 'momo_%'") +')');
            var dddddd = "";
            if(data7!=""&&data7!= null){
                
                for(var d in data7){
                    dddddd+= data7[d].tbl_name+",";
                }
                if(info.split(".")[1]=="1000478346179"){
                    dddddd+= "md_multi_messages_1,md_sessions_1";
                }
                else
                {
                    dddddd+= "md_feed_moment_notice_002,md_multi_messages_1,md_phonebook_temp4,md_recommenduser_4,md_sessions_1";
                }
            }
            var userPath = XLY.Sqlite.DataRecovery(userPath1,charactor1,dddddd);
            if(XLY.File.IsValid(userPath)){
                //动态
                var data1 = eval('('+ XLY.Sqlite.Find(userPath,"select * from md_feed_moment_notice_002") +')');
                //群消息
                var data2 = eval('('+ XLY.Sqlite.Find(userPath,"select XLY_DataType,mm_groupid,mm_remoteid,mm_text,cast(mm_time as int) as time,mm_contentType from md_multi_messages_1") +')');
                //群组
                var data5 = eval('('+ XLY.Sqlite.Find(userPath,"select distinct(mm_groupid) from md_multi_messages_1") +')');
                //联系人
                var data3 = eval('('+ XLY.Sqlite.Find(userPath,"select * from md_phonebook_temp4") +')');
                //好友推荐
                var data4 = eval('('+ XLY.Sqlite.Find(userPath,"select * from md_recommenduser_4") +')');
                var dataSession = eval('('+ XLY.Sqlite.Find(userPath,"select s_s1,s_key from md_sessions_1") +')');
                var data6 = eval('('+ XLY.Sqlite.Find(userPath,"select distinct tbl_name from sqlite_master where tbl_name like 'momo_%'") +')');
                if(data1!=""&&data1!=null){
                    var node1 = new TreeNode();
                    node1.Text = "动态";
                    node1.Type = "Dynamic";
                    getDynamic(node1,data1);
                    var obj1 = new News();
                    obj1.List = node1.Text;
                    root.TreeNodes.push(node1);
                }
                if(data2!=""&&data2!= null){
                    var node2 = new TreeNode();
                    node2.Text = "讨论组";
                    //node2.Type = "Message";
                    if(XLY.File.IsValid(infoPath)){
                        getGroupMessage(node2,data2,data5,infoPath);
                        messageroot.TreeNodes.push(node2);
                    }
                }
                if(data3!=""&&data3!=null){
                    var node3 = new TreeNode();
                    node3.Text = "联系人";
                    node3.Type = "Contact";
                    getContact(node3,data3);
                    if(node3.Items!=""&&node3.Items!=null){
                        nodeAllFri.TreeNodes.push(node3);
                    }
                    
                }
                var node13 = new TreeNode();
                node13.Text = "好友消息";
                node13.Type = "News";
                messageroot.TreeNodes.push(node13);
                
                var node23 = new TreeNode();
                node23.Text = "群消息";
                node23.Type = "News";
                messageroot.TreeNodes.push(node23);
                
                if(data6!=""&&data6!= null){
                    if(dataSession!=""&&dataSession!= null){
                        for(var s in dataSession){
                            if(dataSession[s].s_s1!=""&&dataSession[s].s_s1!= null){
                                for(var z in data6){
                                    var dataSessionInfo = eval('('+ XLY.Sqlite.Find(userPath,"select s_msgid from '"+data6[z].tbl_name+"'") +')');
                                    if(dataSessionInfo!=""&&dataSessionInfo!= null){
                                        for(var n in dataSessionInfo){
                                            if(dataSessionInfo[n].s_msgid!=""&&dataSessionInfo[n].s_msgid!= null){
                                                if(dataSession[s].s_s1==dataSessionInfo[n].s_msgid){
                                                    if(dataSession[s].s_key!=""&&dataSession[s].s_key!= null){
                                                        getPersonMessageNode(node13,dataSession[s].s_key,data6[z].tbl_name,infoPath,userPath,user);
                                                    }
                                                }
                                            }
                                        }  
                                    }
                                    else
                                    {
                                        var dataSessionInfo1 = eval('('+ XLY.Sqlite.Find(userPath,"select gm_msgid from '"+data6[z].tbl_name+"'") +')');
                                        if(dataSessionInfo1!=""&&dataSessionInfo1!= null){
                                            for(var k in dataSessionInfo1){
                                                if(dataSessionInfo1[k].gm_msgid!=""&&dataSessionInfo1[k].gm_msgid!= null){
                                                    if(dataSession[s].s_s1==dataSessionInfo1[k].gm_msgid){
                                                        if(dataSession[s].s_key!=""&&dataSession[s].s_key!= null){
                                                            getGroupMessageNode(node23,dataSession[s].s_key,data6[z].tbl_name,infoPath,userPath);
                                                        }
                                                    }
                                                }
                                            }  
                                        }
                                    }
                                }
                            }
                        }  
                    }
                    else
                    {
                        for(var y in data6){
                            var dataNoSessionInfo = eval('('+ XLY.Sqlite.Find(userPath,"select s_type,s_remoteid,cast(s_time as int) as time,s_text,s_contenttype from '"+data6[y].tbl_name+"'") +')');
                            if(dataNoSessionInfo!=""&&dataNoSessionInfo!=null){
                                var nameNode = eval('('+ XLY.Sqlite.Find(infoPath,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+dataNoSessionInfo[0].s_remoteid+"'") +')');
                                var nodeMoSession = new TreeNode();
                                if(nameNode!=""&&nameNode!=null){
                                    nodeMoSession.Text = dataNoSessionInfo[0].s_remoteid+"_"+nameNode[0].u_name;
                                }
                                else
                                {
                                    nodeMoSession.Text = dataNoSessionInfo[0].s_remoteid;
                                }
                                nodeMoSession.Type = "Message";
                                if(nameNode!=""&&nameNode!=null){
                                    getNoMoSession(nodeMoSession,dataNoSessionInfo,nameNode[0].u_name,user,infoPath);
                                }
                                if(nodeMoSession.Items!=""&&nodeMoSession.Items!=null){
                                    node13.TreeNodes.push(nodeMoSession);
                                }
                            }
                        }
                    }
                }
            }
        }
        root.TreeNodes.push(nodeAllFri);
        root.TreeNodes.push(groupAndDiscussNode);
        root.TreeNodes.push(messageroot);
    }
}
function getDynamic(root,data){
    for(var i in data){
        var obj = new Dynamic();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        if(data[i].s_type==1){
            var aa = eval('('+ data[i].s_json +')');
            obj.UserNickName = aa.user.name;
            obj.UserName = data[i].s_momoId;
            obj.DynamicType = "点赞";
            if(aa.pretext){
                obj.DynamicStatus = aa.pretext;
            }
            else
            {
                obj.DynamicStatus = "普通";
            }
            
            obj.DynamicContent = aa.session_text;
            obj.DynamicTime = XLY.Convert.LinuxToDateTime(aa.create_time);
        }
        else
        {
            var aa = eval('('+ data[i].s_json +')');
            obj.UserNickName = aa.user.name;
            obj.UserName = data[i].s_momoId;
            obj.DynamicType = "评论";
            if(aa.pretext){
                obj.DynamicStatus = aa.pretext;
            }
            else
            {
                obj.DynamicStatus = "普通";
            }
            obj.DynamicContent = aa.content;
            obj.DynamicTime = XLY.Convert.LinuxToDateTime(aa.create_time);
        }
        root.Items.push(obj);
    }
}
function getGroupMessage(root,data,temp,path){
    if(temp!=""&&temp!=null){
        for(var i in temp){
            var node = new TreeNode();
            var name = eval('('+ XLY.Sqlite.Find(path,"select d_name from eta_mddiscussprofile_v12 where d_discussid = '"+temp[i].mm_groupid+"'") +')');
            if(name!=""&&name!=null){
                node.Text = temp[i].mm_groupid+"_"+name[0].d_name;
            }
            else
            {
                node.Text = temp[i].mm_groupid;
            }
            node.Type = "Message";
            for(var j in data){
                if(temp[i].mm_groupid==data[j].mm_groupid)
                {
                    var obj = new Message();
                    obj.DataState = XLY.Convert.ToDataState(data[j].XLY_DataType);
                    obj.SenderID = data[j].mm_remoteid;
                    var sendName = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+data[j].mm_remoteid+"'") +')');
                    if(sendName!=""&&sendName!=null){
                        obj.SenderName =  sendName[0].u_name;
                    }
                    obj.ReciveID = data[j].mm_groupid;
                    obj.ReciveName = name[0].d_name;
                    obj.StartTime = XLY.Convert.LinuxToDateTime(data[j].time);
                    obj.Content = data[j].mm_text;
                    if(data[j].mm_contentType==1){
                        obj.ContentType = "文本";
                    }
                    else if(data[j].mm_contentType==2){
                        obj.ContentType = "图片";
                    }
                    else if(data[j].mm_contentType==3){
                        obj.ContentType = "地理位置";
                    }
                    else if(data[j].mm_contentType==4){
                        obj.ContentType = "语音";
                    }
                    else if(data[j].mm_contentType==8){
                        obj.ContentType = "系统提示";
                    }
                    else if(data[j].mm_contentType==10){
                        obj.ContentType = "名片";
                    }
                    else if(data[j].mm_contentType==11){
                        obj.ContentType = "视频";
                    }
                    else if(data[j].mm_contentType==14){
                        obj.ContentType = "音乐";
                    }
                    else
                    {
                        obj.ContentType = "不确定";
                    }
                    node.Items.push(obj);
                }
            }
            root.TreeNodes.push(node);
        }
    }
}
function getContact(root,data){
    for(var i in data){
        var obj = new Contact();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.UserName = data[i].p_name;
        obj.PhoneNumber = data[i].p_phonenumber;
        obj.MomoNumber = data[i].p_momoid;
        root.Items.push(obj);
    }
}
function getUserInfomation(root,dataUser){
    for(var i in dataUser){
        var objUser = new UserInfo();
        objUser.DataState = XLY.Convert.ToDataState(dataUser[i].XLY_DataType);
        objUser.NickName = dataUser[i].u_name;
        if(dataUser[i].u_sex==0){
            objUser.Sex = "男";
        }
        else if(dataUser[i].u_sex==1)
        {
            objUser.Sex = "女";
        }
        else
        {
            objUser.Sex = "未指定";
        }
        objUser.Birthday = dataUser[i].u_age;
        objUser.JoinDate = dataUser[i].u_regtime;
        objUser.Constellation = dataUser[i].u_constellation;
        objUser.Sign = dataUser[i].u_sign;
        if(dataUser[i].u_hometown!=""&&dataUser[i].u_hometown!=null){
            objUser.SpHomeTown = dataUser[i].u_hometown.name;
        }
        if(dataUser[i].u_nametag!=""&&dataUser[i].u_nametag!=null){
            var taginfo = eval('('+ dataUser[i].u_nametag +')');
            objUser.NameTag = taginfo.desc;
        }
        objUser.LocTimesec = XLY.Convert.LinuxToDateTime(dataUser[i].u_loctime);
        if(dataUser[i].u_vip!=""&&dataUser[i].u_vip!=null){
            objUser.UserLabels = dataUser[i].u_vip.level;
        }
        objUser.Website = dataUser[i].u_website;
        if(dataUser[i].u_movies!=""&&dataUser[i].u_movies!= null){
            var vvvvvvvvvv = eval('('+ dataUser[i].u_movies +')');
            for(var v in vvvvvvvvvv){
                objUser.Movie += "电影名：\r"+vvvvvvvvvv[v].title+"\r"+"导演：\r"+vvvvvvvvvv[v].author+"\r";
            }
        }
        if(dataUser[i].u_musics!=""&&dataUser[i].u_musics!= null){
            var mmm = eval('('+ dataUser[i].u_musics +')');
            for(var m in mmm){
                objUser.Music += "歌名：\r"+mmm[m].title+"\r"+"演唱：\r"+mmm[m].desc+"\r";
            }
        }
        if(dataUser[i].u_books!=""&&dataUser[i].u_books!= null){
            var bbbbbbb = eval('('+ dataUser[i].u_books +')');
            for(var b in bbbbbbb){
                objUser.Book += "书名：\r"+bbbbbbb[b].title+"\r"+"作者：\r"+bbbbbbb[b].author+"\r";
            }
        }
        root.Items.push(objUser);
    }
}
function getGroupInfomation(root,data,path){
    for(var i in data){
        var obj = new GroupInfo();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.GroupLevel = data[i].gi_level;
        obj.GroupLimitCount = data[i].gi_limitcount;
        obj.GroupName = data[i].gi_name;
        var owner = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+data[i].gi_owner+"'") +')');
        if(owner!=""&&owner!=null){
            obj.GroupOwner = owner[0].u_name;
        }
        obj.GroupIntroduce = data[i].gi_introduce;
        obj.GroupMemberCount = data[i].gi_membercount;
        obj.GroupSiteName = data[i].gi_sitename;
        obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].gi_createdate);
        root.Items.push(obj);
    }
}
function getDiscussInfomation(root,data,path){
    for(var i in data){
        var obj = new GroupInfo();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.GroupLevel = data[i].d_level;
        obj.GroupLimitCount = data[i].d_limitcount;
        obj.GroupName = data[i].d_name;
        var owner = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+data[i].d_owner+"'") +')');
        if(owner!=""&&owner!=null){
            obj.GroupOwner = owner[0].u_name;
        }
        obj.GroupMemberCount = data[i].d_membercount;
        var member = eval('('+ data[i].d_members +')');
        for(var m in member){
            obj.GroupMember += "姓名：\r"+member[m].name+"\r"+"陌陌id：\r"+member[m].id+"\r";
        }
        
        obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].time);
        root.Items.push(obj);
    }
}
function getPersonMessageNode(root,temp,data,path,userPath,user){
    var name = "";
    if(XLY.File.IsValid(path)){
        var dataname = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+temp+"'") +')');
        if(dataname!=""&&dataname!=null){
            name = dataname[0].u_name;
        }
    }
    var node = new TreeNode();
    if(name!=""){
        node.Text = temp+"_"+name;
    }
    else
    {
        node.Text = temp;
    }
    node.Type = "Message";
    if(XLY.File.IsValid(userPath)){
        var datainfo = eval('('+ XLY.Sqlite.Find(userPath,"select s_type,s_remoteid,cast(s_time as int) as time,s_text,s_contenttype from '"+data+"'") +')');
        if(datainfo!=""&&datainfo!=null){
            for(var i in datainfo){
                var obj = new Message();
                obj.DataState = XLY.Convert.ToDataState(datainfo[i].XLY_DataType);
                if(datainfo[i].s_type==1){
                    obj.SenderID = user;
                    obj.ReciveID = datainfo[i].s_remoteid;
                }
                else if(datainfo[i].s_type==2){
                    obj.SenderID = datainfo[i].s_remoteid;
                    obj.ReciveID = user;
                }
                else
                {
                }
                if(XLY.File.IsValid(path)){
                    var seName = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+obj.SenderID+"'") +')');
                    if(seName!=""&&seName!=null){
                        obj.SenderName = seName[0].u_name;
                    }
                    var reName = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+obj.ReciveID+"'") +')');
                    if(reName!=""&&reName!=null){
                        obj.ReciveName = reName[0].u_name;
                    }
                }
                obj.StartTime = XLY.Convert.LinuxToDateTime(datainfo[i].time);
                obj.Content = datainfo[i].s_text;
                if(datainfo[i].s_contenttype==6){
                    obj.ContentType = "系统提示";
                }
                else if(datainfo[i].s_contenttype==1){
                    obj.ContentType = "文本";
                }
                else if(datainfo[i].s_contenttype==4){
                    obj.ContentType = "语音";
                }
                else if(datainfo[i].s_contenttype==2){
                    obj.ContentType = "图片";
                }
                else if(datainfo[i].s_contenttype==3){
                    obj.ContentType = "地理位置";
                }
                else if(datainfo[i].s_contenttype==14){
                    obj.ContentType = "音乐";
                }
                else if(datainfo[i].s_contenttype==8){
                    obj.ContentType = "视频聊天";
                }
                else if(datainfo[i].s_contenttype==13){
                    obj.ContentType = "邀请提示";
                }
                else if(datainfo[i].s_contenttype==10)
                {
                    obj.ContentType = "momo通知";
                }
                else
                {
                    obj.ContentType = "未确定";
                }
                node.Items.push(obj);
            }
        }
    }
    if(node.Items!=""&&node.Items!=null){
        root.TreeNodes.push(node);
    }
}
function getGroupMessageNode(root,temp,data,path,userPath){
    var name = "";
    if(XLY.File.IsValid(path)){
        var dataname = eval('('+ XLY.Sqlite.Find(path,"select gi_name from eta_momogroupprofileinfo_v12 where gi_groupid = '"+temp.substr(2,temp.length)+"'") +')');
        if(dataname!=""&&dataname!=null){
            name = dataname[0].gi_name;
        }
    }
    var node = new TreeNode();
    if(name!=""){
        node.Text = temp.substr(2,temp.length)+"_"+name;
    }
    else
    {
        node.Text = temp.substr(2,temp.length);
    }
    node.Type = "MessageGroup";
    if(XLY.File.IsValid(userPath)){
        var datainfo = eval('('+ XLY.Sqlite.Find(userPath,"select gm_remoteid,gm_userTitle,cast(gm_time as int) as time,gm_text,gm_contentType from '"+data+"'") +')');
        if(datainfo!=""&&datainfo!=null){
            for(var i in datainfo){
                var obj = new Message();
                obj.DataState = XLY.Convert.ToDataState(datainfo[i].XLY_DataType);
                obj.SenderID = datainfo[i].gm_remoteid;
                obj.ReciveID = temp.substr(2,temp.length);
                if(XLY.File.IsValid(path)){
                    var seName = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+obj.SenderID+"'") +')');
                    if(seName!=""&&seName!=null){
                        obj.SenderName = seName[0].u_name;
                    }
                    obj.ReciveName = name;
                }
                obj.Rank = datainfo[i].gm_userTitle;
                obj.StartTime = XLY.Convert.LinuxToDateTime(datainfo[i].time);
                obj.Content = datainfo[i].gm_text;
                if(datainfo[i].gm_contentType==1){
                    obj.ContentType = "文本";
                }
                else if(datainfo[i].gm_contentType==2){
                    obj.ContentType = "图片";
                }
                else if(datainfo[i].gm_contentType==3){
                    obj.ContentType = "地理位置";
                }
                else if(datainfo[i].gm_contentType==4){
                    obj.ContentType = "语音";
                }
                else if(datainfo[i].gm_contentType==8){
                    obj.ContentType = "系统提示";
                }
                else if(datainfo[i].gm_contentType==10){
                    obj.ContentType = "名片";
                }
                else if(datainfo[i].gm_contentType==11){
                    obj.ContentType = "视频";
                }
                else if(datainfo[i].gm_contentType==14){
                    obj.ContentType = "音乐";
                }
                else
                {
                    obj.ContentType = "不确定";
                }
                node.Items.push(obj);
            }
        }
    }
    if(node.Items!=""&&node.Items!=null){
        root.TreeNodes.push(node);
    }
}
function getNoMoSession(root,datainfo,name,user,path){
    if(XLY.File.IsValid(path)){
        for(var i in datainfo){
            var obj = new Message();
            obj.DataState = XLY.Convert.ToDataState(datainfo[i].XLY_DataType);
            if(datainfo[i].s_type==1){
                obj.SenderID = user;
                obj.ReciveID = datainfo[i].s_remoteid;
            }
            else if(datainfo[i].s_type==2){
                obj.SenderID = datainfo[i].s_remoteid;
                obj.ReciveID = user;
            }
            else
            {
            }
            if(XLY.File.IsValid(path)){
                var seName = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+obj.SenderID+"'") +')');
                if(seName!=""&&seName!=null){
                    obj.SenderName = seName[0].u_name;
                }
                var reName = eval('('+ XLY.Sqlite.Find(path,"select u_name from eta_mduserprofile_v12 where u_momoid = '"+obj.ReciveID+"'") +')');
                if(reName!=""&&reName!=null){
                    obj.ReciveName = reName[0].u_name;
                }
            }
            obj.StartTime = XLY.Convert.LinuxToDateTime(datainfo[i].time);
            obj.Content = datainfo[i].s_text;
            if(datainfo[i].s_contenttype==6){
                obj.ContentType = "系统提示";
            }
            else if(datainfo[i].s_contenttype==1){
                obj.ContentType = "文本";
            }
            else if(datainfo[i].s_contenttype==4){
                obj.ContentType = "语音";
            }
            else if(datainfo[i].s_contenttype==2){
                obj.ContentType = "图片";
            }
            else if(datainfo[i].s_contenttype==3){
                obj.ContentType = "地理位置";
            }
            else if(datainfo[i].s_contenttype==14){
                obj.ContentType = "音乐";
            }
            else if(datainfo[i].s_contenttype==8){
                obj.ContentType = "视频聊天";
            }
            else if(datainfo[i].s_contenttype==13){
                obj.ContentType = "邀请提示";
            }
            else if(datainfo[i].s_contenttype==10)
            {
                obj.ContentType = "momo通知";
            }
            else
            {
                obj.ContentType = "未确定";
            }
            root.Items.push(obj);
        }
    }
}