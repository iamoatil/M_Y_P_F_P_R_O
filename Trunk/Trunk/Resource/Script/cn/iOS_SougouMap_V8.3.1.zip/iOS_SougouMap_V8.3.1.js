﻿/*[config]
<plugin name="搜狗地图,6" group="地图公交,7" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/SogouMap.png" app="com.sogou.map.app.Map" version="8.3.1" description="搜狗地图" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.sogou.map.app.Map</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="GroupID"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="组ID" code="List" type="string" width = "150"></item>
</data>
<data type="SearchWord"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关键字" code="Key" type="string" width = "150"></item>
    <item name="地点城市ID" code="City" type="string" width = "150"></item>
    <item name="类型" code="SearchType" type="string" width = "120"></item>
    <item name="创建时间" code="CreateTime"  type="string" width="150" format = ""></item>
    <item name="更新时间" code="UpdateTime"  type="string" width="150" format = ""></item>
</data>
<data type="SearchRoute"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="开始地点" code="StartName" type="string" width = "120"></item>
    <item name="目的地点" code="EndName" type="string" width = "120"></item>
    <item name="地点城市" code="City" type="string" width = "120"></item>
    <item name="创建时间" code="CreateTime"  type="string" width="150" format = ""></item>
    <item name="更新时间" code="UpdateTime"  type="string" width="150" format = ""></item>
    <item name="开始地点经度" code="StartLng"  type="string" width="120" format = ""></item>
    <item name="开始地点纬度" code="StartLat"  type="string" width="120" format = ""></item>
    <item name="目的地点经度" code="EndLng"  type="string" width="120" format = ""></item>
    <item name="目的地点纬度" code="EndLat"  type="string" width="120" format = ""></item>
</data>
<data type="Favorite" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Caption" type="string" width="120" format = "" ></item>
    <item name="创建者ID" code="UserID" type="string" width="120" format = "" ></item>
    <item name="类型" code="FavorityType" type="string" width="120" format = "" ></item>
    <item name="描述" code="FavorityDescription" type="string" width="120" format = "" ></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>s
<data type="Message" contract="DataState" datefilter="SenderHeadUrl">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者id" code="SenderId" type="string" width="120" format = "" ></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format=""></item>
    <item name="发送者头像" code="SenderHeadUrl" type="url" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="发送状态" code="ContentType" type="string" width="120" format=""></item>
    <item name="发送时间" code="MessageSendTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="接收时间" code="MessageReceiveTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="已读" code="IsRead" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="180" format = "" ></item>
    <item name="姓名" code="Name" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="电话" code="Phone" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义Favorite数据结构
function Favorite(){
    this.DataState = "Normal";
    this.Caption = "";
    this.UserID = "";
    this.FavorityType = "";
    this.FavorityDescription = "";
    this.CreateTime = null;
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义GroupID数据结构
function GroupID(){
    this.DataState = "Normal";
    this.List = "";
}
//定义SearchWord数据结构
function SearchWord(){
    this.DataState = "Normal";
    this.Key = "";
    this.City = "";
    this.SearchType = "";
    this.CreateTime = "";
    this.UpdateTime = "";
}
//定义BookMark数据结构
function BookMark(){
    this.DataState = "Normal";
    this.AddressName = "";
    this.Address = "";
    this.City = "";
    this.Lng = "";
    this.Lat = "";
    this.CreateTime = "";
    this.UpdateTime = "";
}
//定义SearchRoute数据结构
function SearchRoute(){
    this.DataState = "Normal";
    this.StartName = "";
    this.EndName = "";
    this.City = "";
    this.CreateTime = "";
    this.UpdateTime = "";
    this.StartLng = "";
    this.StartLat = "";
    this.EndLng = "";
    this.EndLat = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
    this.Sex = "";
    this.Phone = "";
    this.HeadUrl = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderId = "";
    this.SenderName = "";
    this.SenderHeadUrl = "";
    this.Content = "";
    this.ContentType = "";
    this.MessageSendTime = null;
    this.MessageReceiveTime = null;
    this.IsRead = "";
}
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.sogou.map.app.Map\\Documents\\MapData.data";
//var userIDPath = source[0]+"\\com.chelaile.lite\\Library\\Preferences\\com.chelaile.lite.plist";
var cookPath = source[0]+"\\com.sogou.map.app.Map\\Library\\Cookies\\Cookies.binarycookies";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sogou.map.app.Map\\Documents\\MapData.data";
//var userIDPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.chelaile.lite\\Library\\Preferences\\com.chelaile.lite.plist";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sogou.map.app.Map\\Library\\Cookies\\Cookies.binarycookies";
//定义特征库文件
//var charactor = "chalib\\iOS_Didi_V5.0.14\\DDIMDataBase.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "搜狗地图";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(allPath)){
        var data = eval('('+ XLY.Sqlite.Find(allPath,"select * from ZSGMUSERDATAENTITY") +')');
        if(data!=""&&data!=null){
            var nodeUser = new TreeNode();
            nodeUser.Text = data[0].ZNAME;
            nodeUser.Type = "UserInfo";
            root.TreeNodes.push(nodeUser);
            var obj = new UserInfo();
            obj.ID = data[0].ZUSERID;
            obj.Name = data[0].ZNAME;
            if(data[0].ZSEX==1){
                obj.Sex = "男";
            }
            else if(data[0].ZSEX==2){
                obj.Sex = "女";
            }
            else
            {
                obj.Sex = "未指定";
            }
            
            obj.Phone = data[0].ZPHONENUM;
            obj.HeadUrl = data[0].ZLARGEAVATAR;
            nodeUser.Items.push(obj);
            getUserChildNode(nodeUser);
        }
    }
}
function getUserChildNode(root){
    if(XLY.File.IsValid(allPath)){
        var dataFavorite = eval('('+ XLY.Sqlite.Find(allPath,"select * from ZSGMFAVORITEENTITY") +')');
        if(dataFavorite!=""&&dataFavorite!=null){
            var nodeFavorite = new TreeNode();
            nodeFavorite.Text = "收藏夹";
            nodeFavorite.Type = "Favorite";
            for(var i in dataFavorite){
                var obj = new Favorite();
                //obj.DataState = XLY.Convert.ToDataState(dataFavorite[i].XLY_DataType);
                obj.Caption = dataFavorite[i].ZCAPTION;
                obj.UserID = dataFavorite[i].ZUSERID;
                if(dataFavorite[i].ZTYPE==101){
                    obj.FavorityType = "常用地点";
                }
                else if(dataFavorite[i].ZTYPE==102)
                {
                    obj.FavorityType = "详细地址收藏点";
                }
                else if(dataFavorite[i].ZTYPE==103){
                    obj.FavorityType = "收藏路线";
                }
                else if(dataFavorite[i].ZTYPE==105){
                    obj.FavorityType = "附近收藏点";
                }
                else
                {
                    obj.FavorityType = "未明确";
                }
                //var a = new Base64();
                //var info = utf16to8(a.decode(dataFavorite[i].ZDATA)).toString();
                var cc = XLY.Blob.ToBytes(dataFavorite[i].ZDATA,"base64");
                var arr = getZdataInfo(cc,dataFavorite[i].ZTYPE,dataFavorite[i].ZFID);
                if(arr.flag==101){
                    obj.FavorityDescription = "标签："+arr.sbookname+"\r"+"标签补充："+arr.sbookenname+"\r"+"地址："+arr.saddress;
                }
                else if(arr.flag==102){
                    obj.FavorityDescription = "标题："+arr.sname+"\r"+"城市："+arr.scity+"\r"+"地址："+arr.saddress+"\r"+"类型："+arr.stype;
                }
                else if(arr.flag==103){
                    obj.FavorityDescription = "未明确";
                }
                else if(arr.flag==105)
                {
                    if(arr.sphone){
                        obj.FavorityDescription = "标题："+arr.sname+"\r"+"联系电话："+arr.sphone+"\r"+"城市："+arr.scity+"\r"+"地址："+arr.saddress+"\r"+"类型："+arr.stype;
                    }
                    else
                    {
                        obj.FavorityDescription = "标题："+arr.sname+"\r"+"城市："+arr.scity+"\r"+"地址："+arr.saddress+"\r"+"类型："+arr.stype;
                    }
                    
                }
                else
                {
                    
                }
                
                obj.CreateTime = XLY.Convert.LinuxToDateTime(dataFavorite[i].ZCREATETIME);
                nodeFavorite.Items.push(obj);
            }
            if(nodeFavorite.Items!=""&&nodeFavorite.Items!=null){
                root.TreeNodes.push(nodeFavorite);
            }
        }
    }
    if(XLY.File.IsValid(cookPath)){
        var nodeCook = new  TreeNode();
        nodeCook.Text = "Cache缓存";
        nodeCook.Type = "Cache";
        getCache(nodeCook);
        root.TreeNodes.push(nodeCook);
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
function Base64() {
 
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
 
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }
 
    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }
 
    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
 
        }
        return utftext;
    }
 
    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}

function utf16to8(str) {
    var out, i, len, c;

    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
    c = str.charCodeAt(i);
    if ((c >= 0x0001) && (c <= 0x007F)) {
        out += str.charAt(i);
    } else if (c > 0x07FF) {
        out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
        out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    } else {
        out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    }
    }
    return out;
}
function getZdataInfo(data,flag,fid){
        var size = data.length;
        var a = 0;
        var b = 0;
        var arr = {};
        if(flag==105){
            arr.flag = 105;
            if(fid!=""&&fid!= null){
                while(a<size){
                    //var sign = XLY.Blob.GetBytes(data,a,1);
                    if(data[a]==0x0A){
                        a = a+1;
                        b = a+1;
                        var ffid = XLY.Blob.GetBytes(data,b,data[a]);
                        arr.fid = XLY.Blob.ToString(ffid);
                        a = data[a]+b+0x18;
                        b = a+1;
                        if(data[a]==0x0A){
                            var ssid = XLY.Blob.GetBytes(data,b+1,data[b]);
                            arr.sid = XLY.Blob.ToString(ssid);
                            a = data[b]+b+1;
                            b = a+1;
                            if(data[a]==0x12){
                                var ssname = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.sname = XLY.Blob.ToString(ssname);
                                a = data[b]+b+0x12;
                                b = a+1;
                                var sign = XLY.Blob.GetBytes(data,a,0x02);
                                if(sign==[0x41,0x32].toString()){
                                    a = a+2;
                                    b = a+1;
                                    var ssaddress = XLY.Blob.GetBytes(data,b,data[a]);
                                    arr.saddress = XLY.Blob.ToString(ssaddress);
                                    a = b+data[a];
                                    b = a+1;
                                    if(data[a]==0x3A){
                                        var sscity = XLY.Blob.GetBytes(data,b+1,data[b]);
                                        arr.scity = XLY.Blob.ToString(sscity);
                                        a = a+1+data[b];
                                        b = a+1;
                                        var signtype = XLY.Blob.GetBytes(data,b,5);
                                        a = a+5;
                                        b = a+1;
                                        if(signtype==[0x48,0x00,0x68,0x00,0x72].toString()){
                                            var sstype = XLY.Blob.GetBytes(data,b+1,data[b]);
                                            arr.stype = XLY.Blob.ToString(sstype);
                                            a = a+0x10;
                                            b = a+1;
                                            continue;
                                        }
                                    }
                                }
                                if(sign==[0x41,0x2A].toString()){
                                    a = a+2;
                                    b = a+1;
                                    var ssphone = XLY.Blob.GetBytes(data,b,data[a]);
                                    arr.ssphone = XLY.Blob.ToString(ssphone);
                                    a = b+1+data[a];
                                    b = a+1;
                                    
                                    var ssaddress = XLY.Blob.GetBytes(data,b,data[a]);
                                    arr.saddress = XLY.Blob.ToString(ssaddress);
                                    
                                    a = b+data[a];
                                    b = a+1;
                                    if(data[a]==0x3A){
                                        var sscity = XLY.Blob.GetBytes(data,b+1,data[b]);
                                        arr.scity = XLY.Blob.ToString(sscity);
                                        a = a+1+data[b];
                                        b = a+1;
                                        var signtype = XLY.Blob.GetBytes(data,b,5);
                                        a = a+5;
                                        b = a+1;
                                        if(signtype==[0x48,0x00,0x68,0x00,0x72].toString()){
                                            var sstype = XLY.Blob.GetBytes(data,b+1,data[b]);
                                            arr.stype = XLY.Blob.ToString(sstype);
                                            a = a+0x10;
                                            b = a+1;
                                            continue;
                                        }
                                    }
                                    
                                }
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            else
            {
                while(a<size){
                    //var sign = XLY.Blob.GetBytes(data,a,1);
                    if(XLY.Blob.FindBytes(data,0,[0x0A])){
                        a = XLY.Blob.FindBytes(data,0,[0x0A]);
                        break;
                    }
                }  
                while(a<size){ 
                    if(data[a]==0x0A){
                        b = a+1;
                        var ffid = XLY.Blob.GetBytes(data,b,data[b]);
                        arr.fid = XLY.Blob.ToString(ffid);
                        a = data[b]+b+1;
                        b = a+1;
                        
                        if(data[a]==0x12){
                            var ssname = XLY.Blob.GetBytes(data,b+1,data[b]);
                            arr.sname = XLY.Blob.ToString(ssname);
                            a = data[b]+b+0x12;
                            b = a+1;
                            var sign = XLY.Blob.GetBytes(data,a,0x02);
                            if(sign==[0x41,0x32].toString()){
                                a = a+2;
                                b = b+1;
                                var ssaddress = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.saddress = XLY.Blob.ToString(ssaddress);
                                a = data[b]+b+1;
                                b = a+1;
                                if(data[a]==0x3A){
                                    var sscity = XLY.Blob.GetBytes(data,b+1,data[b]);
                                    arr.scity = XLY.Blob.ToString(sscity);
                                    a = a+1+data[b];
                                    b = a+1;
                                    var signtype = XLY.Blob.GetBytes(data,b,5);
                                    a = a+5;
                                    b = a+1;
                                    if(signtype==[0x48,0x00,0x68,0x00,0x72].toString()){
                                        var sstype = XLY.Blob.GetBytes(data,b+1,data[b]);
                                        arr.stype = XLY.Blob.ToString(sstype);
                                        a = a+0x10;
                                        b = a+1;
                                        continue;
                                    }
                                }
                            }
                            if(sign==[0x41,0x2A].toString()){
                                a = a+2;
                                b = b+1;
                                var ssphone = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.sphone = XLY.Blob.ToString(ssphone);
                                a = data[b]+b+1;
                                b = a+1;
                                if(data[a]==0x32){
                                    var ssaddress = XLY.Blob.GetBytes(data,b+1,data[b]);
                                    arr.saddress = XLY.Blob.ToString(ssaddress);
                                    a = data[b]+b+1;
                                    b = a+1;
                                    if(data[a]==0x3A){
                                        var sscity = XLY.Blob.GetBytes(data,b+1,data[b]);
                                        arr.scity = XLY.Blob.ToString(sscity);
                                        a = a+1+data[b];
                                        b = a+1;
                                        var signtype = XLY.Blob.GetBytes(data,b,5);
                                        a = a+5;
                                        b = a+1;
                                        if(signtype==[0x48,0x00,0x68,0x00,0x72].toString()){
                                            var sstype = XLY.Blob.GetBytes(data,b+1,data[b]);
                                            arr.stype = XLY.Blob.ToString(sstype);
                                            a = a+0x10;
                                            b = a+1;
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }    
            }
        }
        if(flag==102){
            arr.flag = 102;
            if(fid!=""&&fid!= null){
                while(a<size){
                    //var sign = XLY.Blob.GetBytes(data,a,1);
                    if(data[a]==0x0A){
                        a = a+1;
                        b = a+1;
                        var ffid = XLY.Blob.GetBytes(data,b,data[a]);
                        arr.fid = XLY.Blob.ToString(ffid);
                        a = data[a]+b+0x18;
                        b = a+1;
                        if(data[a]==0x0A){
                            var ssid = XLY.Blob.GetBytes(data,b+1,data[b]);
                            arr.sid = XLY.Blob.ToString(ssid);
                            a = data[b]+b+0x12;
                            b = a+1;
                            if((XLY.Blob.GetBytes(data,a,2))==[0x41,0x22].toString()){
                                b = b+1;
                                var ssname = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.sname = XLY.Blob.ToString(ssname);
                                a = data[b]+b+1;
                                b = a+1;
                                if(data[a]==0x2A){
                                    var sscity = XLY.Blob.GetBytes(data,b+1,data[b]);
                                    arr.scity = XLY.Blob.ToString(sscity);
                                    a = b+data[b]+1;
                                    b = a+1;
                                    if(data[a]==0x32){
                                        var ssaddress = XLY.Blob.GetBytes(data,b+1,data[b]);
                                        arr.saddress = XLY.Blob.ToString(ssaddress);
                                        a = b+1+data[b];
                                        b = a+1;
                                        if(data[a]==0x3A){
                                            var sstype = XLY.Blob.GetBytes(data,b+1,data[b]);
                                            arr.stype = XLY.Blob.ToString(sstype);
                                            a = a+0x10;
                                            b = a+1;
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        if(flag==101){
            arr.flag = 101;
            if(fid!=""&&fid!= null){
                while(a<size){
                    //var sign = XLY.Blob.GetBytes(data,a,1);
                    if(data[a]==0x0A){
                        a = a+1;
                        b = a+1;
                        var ffid = XLY.Blob.GetBytes(data,b,data[a]);
                        arr.fid = XLY.Blob.ToString(ffid);
                        a = data[a]+b+0x17;
                        b = a+1;
                        if(data[a]==0x0A){
                            var ssbookname = XLY.Blob.GetBytes(data,b+1,data[b]);
                            arr.sbookname = XLY.Blob.ToString(ssbookname);
                            a = data[b]+b+0x13;
                            b = a+1;
                            if(data[a]==0x22){
                                var ssbookenname = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.sbookenname = XLY.Blob.ToString(ssbookenname);
                                a = data[b]+b+1;
                                b = a+1;
                                if(data[a]==0x2A){
                                    var ssaddress = XLY.Blob.GetBytes(data,b+1,data[b]);
                                    arr.saddress = XLY.Blob.ToString(ssaddress);
                                    a = a+4;
                                    b = a+1;
                                    continue;
                                }
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            else {
                
            }
        }
        if(flag==103){
            arr.flag = 103;
            if(fid!=""&&fid!= null){
                while(a<size){
                    //var sign = XLY.Blob.GetBytes(data,a,1);
                    if(data[a]==0x0A){
                        a = a+1;
                        b = a+1;
                        var ffid = XLY.Blob.GetBytes(data,b,data[a]);
                        arr.fid = XLY.Blob.ToString(ffid);
                        a = data[a]+b+0x18;
                        b = a+1;
                        if(data[a]==0x12){
                            b = b+2;
                            var ssbookname = XLY.Blob.GetBytes(data,b,data[b+1]+data[b]);
                            arr.sbookname = XLY.Blob.ToString(ssbookname);
                            a = data[b]+b+0x13;
                            b = a+1;
                            if(data[a]==0x22){
                                var ssbookenname = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.sbookenname = XLY.Blob.ToString(ssbookenname);
                                a = data[b]+b+1;
                                b = a+1;
                                if(data[a]==0x2A){
                                    var ssaddress = XLY.Blob.GetBytes(data,b+1,data[b]);
                                    arr.saddress = XLY.Blob.ToString(ssaddress);
                                    a = a+4;
                                    b = a+1;
                                    continue;
                                }
                            }
                        }
                        if(data[b]==0x12){
                            var ssbookname = XLY.Blob.GetBytes(data,b+1,data[b]);
                            arr.sbookname = XLY.Blob.ToString(ssbookname);
                            a = data[b]+b+0x13;
                            b = a+1;
                            if(data[a]==0x22){
                                var ssbookenname = XLY.Blob.GetBytes(data,b+1,data[b]);
                                arr.sbookenname = XLY.Blob.ToString(ssbookenname);
                                a = data[b]+b+1;
                                b = a+1;
                                if(data[a]==0x2A){
                                    var ssaddress = XLY.Blob.GetBytes(data,b+1,data[b]);
                                    arr.saddress = XLY.Blob.ToString(ssaddress);
                                    a = a+4;
                                    b = a+1;
                                    continue;
                                }
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            else {
                
            }
        }
        return arr;
}