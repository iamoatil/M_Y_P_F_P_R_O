﻿/*[config]
<plugin name="HelloTalk,5" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="icons\hellotalk.png" app="com.hellotalk" version="2.2.8" description="Test-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.hellotalk/databases/#F</value>
</source>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="User" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="120" ></item>
<item name="帐号ID" code="Id" type="string" width = "100" ></item>
</data>
<data type="Contact" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="120" ></item>
<item name="帐号ID" code="Id" type="string" width = "100" ></item>
</data>
<data type="Follow" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="帐号ID" code="Id" type="string" width = "100" ></item>
<item name="关注时间" code="Time" type="string" width = "100" ></item>
</data>
<data type="Fans" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="帐号ID" code="Id" type="string" width = "100" ></item>
<item name="关注时间" code="Time" type="string" width = "100" ></item>
</data>
<data type="SUser" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="120" ></item>
<item name="帐号ID" code="Id" type="string" width = "100" ></item>
<item name="头像" code="Avatar" type="string" width = "100" ></item>
</data>
<data type="Comment" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="用户ID" code="UID" type="string" width="120" ></item>
<item name="评论ID" code="CID" type="string" width = "100" ></item>
<item name="内容" code="Content" type="string" width="120" ></item>
<item name="时间" code="Time" type="string" width = "100" ></item>
<item name="评论人" code="Name" type="string" width="120" ></item>
</data>
<data type="Moment" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="用户ID" code="UID" type="string" width = "120" ></item>
<item name="昵称" code="Nick" type="string" width = "120" ></item>
<item name="头像" code="Avatar" type="string" width="120" ></item>
<item name="动态ID" code="MID" type="string" width = "100" ></item>
<item name="内容" code="Content" type="string" width="120" ></item>
<item name="位置" code="Position" type="string" width = "100" ></item>
<item name="经纬度" code="LONLAT" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width="120" ></item>
</data>
<data type="Fav" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="收藏ID" code="FID" type="string" width = "120" ></item>
<item name="用户ID" code="UID" type="string" width = "120" ></item>
<item name="消息类型" code="MType" type="string" width = "120" ></item>
<item name="传输类型" code="TType" type="string" width="120" ></item>
<item name="文件" code="File" type="string" width = "100" ></item>
<item name="内容" code="Content" type="string" width="120" ></item>
<item name="收藏时间" code="Time" type="string" width = "100" ></item>
</data>
<data type="Message" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="发送者" code="SID" type="string" width = "120" ></item>
<item name="接收者" code="RID" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="附件" code="File" type="string" width = "120" ></item>
<item name="消息类型" code="MType" type="string" width = "120" ></item>
<item name="阅读状态" code="Read" type="string" width="120" ></item>
<item name="接收时间" code="Time" type="string" width = "100" ></item>
</data>
<data type="Friend" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "120" ></item>
<item name="姓名" code="Name" type="string" width = "120" ></item>
</data>
<data type="Group" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID" code="ID" type="string" width = "120" ></item>
<item name="创建时间" code="Time" type="string" width = "100" ></item>
</data>
<data type="Mem" contract="DataState"  datefilter="RegisterDate">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="成员ID" code="ID" type="string" width = "120" ></item>
<item name="成员名" code="Name" type="string" width = "120" ></item>
</data>
</plugin>
[config]*/
function Info(){
    this.Acc = "";
    this.DataState = "Normal";
}
function User() {
    this.Name = "";
    this.Id = "";
    this.DataState = "Normal";
}
function Follow() {
    this.Name = "";
    this.Id = "";
    this.Time = "";
    this.DataState = "Normal";
}
function Fans() {
    this.Name = "";
    this.Id = "";
    this.Time = "";
    this.DataState = "Normal";
}
function SUser() {
    this.Name = "";
    this.Id = "";
    this.Avatar = "";
    this.DataState = "Normal";
}
function Contact() {
    this.Name = "";
    this.Id = "";
    this.DataState = "Normal";
}
function Comment() {
    this.UID = "";
    this.CID = "";
    this.Content = "";
    this.Time = "";
    this.Name = "";
    this.DataState = "Normal";
}
function Moment() {
    this.UID = "";
    this.MID = "";
    this.Content = "";
    this.Time = "";
    this.Nick = "";
    this.Avatar = "";
    this.Position = "";
    this.LONLAT = "";
    this.DataState = "Normal";
}
function Fav() {
    this.FID = "";
    this.UID = "";
    this.MType = "";
    this.TType = "";
    this.File = "";
    this.Time = "";
    this.Content = "";
    this.DataState = "Normal";
}
function Message() {
    this.SID = "";
    this.RID = "";
    this.Content = "";
    this.MType = "";
    this.Read = "";
    this.Time = "";
    this.File = "";
    this.DataState = "Normal";
}
function Friend() {
    this.ID = "";
    this.Name = "";
    this.DataState = "Normal";
}
function Group() {
    this.ID = "";
    this.Mem = "";
    this.Time = "";
    this.DataState = "Normal";
}
function Mem() {
    this.ID = "";
    this.Name = "";
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "HelloTalk";
    news.Type = "Info"; 
    news.DataState = "Normal";
    
    var info = new TreeNode();
    info.Text = "账号";
    info.Type = "Info";
    accountinfo = getInfo(db);
    info.Items = accountinfo;
    info.DataState = "Normal";
    news.TreeNodes.push(info);
    
    for(var i in accountinfo){
       var account = new TreeNode() ;
       account.Text = accountinfo[i].Acc;
       account.Type = "Info";
       info.TreeNodes.push(account);
       
       //var abc = db+"\\u_"+accountinfo[i].Acc;
       //var bcd = db+"\\"+accountinfo[i].Acc+"_ht.db";
       
       //var charactor = db+"\\u.charactor";
       //var charactor1 = db+"\\ht.db.charactor";
       
       var charactor = "\\chalib\\Android_HelloTalk_V6.1.2\\u.charactor";
       var charactor1 = "\\chalib\\Android_HelloTalk_V6.1.2\\ht.db.charactor";
       
       var abc = XLY.Sqlite.DataRecovery(db+"\\u_"+accountinfo[i].Acc,charactor,"USER,SIMPLE_USER,COMMENT,MOMENT");
       var bcd = XLY.Sqlite.DataRecovery(db+"\\"+accountinfo[i].Acc+"_ht.db",charactor1,"message,chatroom,roommember,favorite,htfollowids,ht_follower_list"); 
       
         var user = new TreeNode();
         user.Text = "帐号信息";
         user.Type = "User";                
         var userinfo = getUser(abc,accountinfo[i]);
         user.Items = userinfo;
         account.TreeNodes.push(user);
         
         var contact = new TreeNode();
         contact.Text = "联系人";
         contact.Type = "Contact";    
         var contactinfo = getContact(abc);
         contact.Items = contactinfo;
         account.TreeNodes.push(contact);
         
           var msg = new TreeNode();
         msg.Text = "消息";
         account.TreeNodes.push(msg);
          
         var message = new TreeNode();
         message.Text = "群消息";
         message.Type = "Message"; 
         var ginfo =  getGMessage(bcd,accountinfo[i]);        
         message.Items = ginfo;
         msg.TreeNodes.push(message);
         
         var group = new TreeNode();
         group.Text = "加入的群";
         group.Type = "Group";    
         var groupinfo = getGroup(bcd);
         group.Items = groupinfo;
         account.TreeNodes.push(group);
         
         for(var m in groupinfo ){
             var mem = new TreeNode();
             mem.Text =  groupinfo[m].ID;
             mem.Type = "Mem";    
             mem.Items = getMem(bcd,groupinfo[m]);
             group.TreeNodes.push(mem);
             
             var gmsg = new TreeNode();
             gmsg.Text =  groupinfo[m].ID;
             gmsg.Type = "Message";    
             gmsg.Items = getGMessage(bcd,groupinfo[m],accountinfo);
             message.TreeNodes.push(gmsg);
         
         }
         var friend = new TreeNode();
         friend.Text = "好友消息";
         friend.Type = "Friend";   
         var finfo = getFriend(bcd,accountinfo[i],contactinfo);        
         friend.Items = finfo;
         msg.TreeNodes.push(friend);
         
         for(var j in finfo){
             var fmsg = new TreeNode();
             fmsg.Text = finfo[j].ID;
             fmsg.Type = "Message";          
             fmsg.Items =getFMessage(bcd,finfo[j],accountinfo);
             friend.TreeNodes.push(fmsg);
         }
         
         var comment = new TreeNode();
         comment.Text = "评论";
         comment.Type = "Comment";                
         comment.Items = getComment(abc,accountinfo[i]);
         account.TreeNodes.push(comment);
         
         var follow = new TreeNode();
         follow.Text = "关注";
         follow.Type = "Follow";                
         follow.Items = getFollow(bcd,accountinfo[i],contactinfo);
         account.TreeNodes.push(follow);
         
         var fans = new TreeNode();
         fans.Text = "粉丝";
         fans.Type = "Fans";                
         fans.Items = getFans(bcd,accountinfo[i],contactinfo);
         account.TreeNodes.push(fans);
         
         var fav = new TreeNode();
         fav.Text = "收藏";
         fav.Type = "Fav";                
         fav.Items = getFav(bcd,accountinfo[i],contactinfo);
         account.TreeNodes.push(fav);
         
         var moment = new TreeNode();
         moment.Text = "动态";
         moment.Type = "Moment";                
         moment.Items = getMoment(abc,accountinfo[i]);
         account.TreeNodes.push(moment);
         
         var suser = new TreeNode();
         suser.Text = "查看详情的人";
         suser.Type = "SUser";                
         suser.Items = getSUser(abc,accountinfo[i]);
         account.TreeNodes.push(suser);  
    }
    
        result.push(news);
}
 function getUser(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from USER where SERVER_USER_ID = '"+accountinfo.Acc+"'" ) +')');
    for(var i in data){        
        var obj = new User();
        obj.Name = data[i].NICKNAME;
        obj.Id = data[i].SERVER_USER_ID;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getGMessage(path,groupinfo,accountinfo){
     if(groupinfo.ID != null){   
      var list = new Array(); 
      var data = eval('('+ XLY.Sqlite.Find(path,"select * from message  where  rid = '"+groupinfo.ID+"' " ) +')');
      for(var i in data){        
        var obj = new Message();
        obj.RID = data[i].rid; 
        obj.SID = data[i].uid;
        var content = eval('('+ data[i].data +')');   
        obj.Content = content.k;
        switch(data[i].type){
            case 0: 
            obj.MType = "文本";
            break;
            case 1: 
            obj.MType = "翻译";
            break;
            case 7: 
            obj.MType = "语音转文字的翻译";
            break;
            case 2: 
            obj.MType = "图片";
            break;
            case 8: 
            obj.MType = "修改的句子";
            break;
            case 12: 
            obj.MType = "视频";
            break;
            case 5: 
            obj.MType = "名片";
            break;
            case 4: 
            obj.MType = "位置";
            break;
            case 9: 
            obj.MType = "大表情";
            break;
            case 13: 
            obj.MType = "涂鸦";
            break;
            case 3: 
            obj.MType = "语音";
            break;
            case 11: 
            obj.MType = "通话";
            break;
            case 16: 
            obj.MType = "贺卡";
            break;
            default : 
            obj.MType = "其他";
            break;
        }
        obj.File = data[i].filename;
        obj.Read = (data[i].isRead == 0) ? "已读" : "未读";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
      }
 }
 function getFMessage(path,finfo,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from message  where  uid = '"+finfo.ID+"' " ) +')');
    for(var i in data){        
        var obj = new Message();
        if(data[i].sendtype == 0){
            obj.SID = data[i].uid; 
            for(var j in accountinfo){
              obj.RID = accountinfo[j].Acc;
            } 
        }
        else
        {
            obj.RID = data[i].uid; 
            for(var j in accountinfo){
             obj.SID = accountinfo[j].Acc;
            } 
        }
        obj.SID = data[i].rid; 
        var content = eval('('+ data[i].data +')');   
        obj.Content = content.k;
        switch(data[i].type){
            case 0: 
            obj.MType = "文本";
            break;
            case 1: 
            obj.MType = "翻译";
            break;
            case 7: 
            obj.MType = "语音转文字的翻译";
            break;
            case 2: 
            obj.MType = "图片";
            break;
            case 8: 
            obj.MType = "修改的句子";
            break;
            case 12: 
            obj.MType = "视频";
            break;
            case 5: 
            obj.MType = "名片";
            break;
            case 4: 
            obj.MType = "位置";
            break;
            case 9: 
            obj.MType = "大表情";
            break;
            case 13: 
            obj.MType = "涂鸦";
            break;
            case 3: 
            obj.MType = "语音";
            break;
            case 11: 
            obj.MType = "通话";
            break;
            case 16: 
            obj.MType = "贺卡";
            break;
            default : 
            obj.MType = "其他";
            break;
        }
        obj.File = data[i].filename;
        obj.Read = (data[i].isRead == 0) ? "已读" : "未读";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getFriend(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct uid from message  where rid = 0  " ) +')');
    for(var i in data){        
        var obj = new Friend();
        obj.ID = data[i].uid;    
        //obj.Id = data[i].SERVER_USER_ID;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getGroup(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from chatroom " ) +')');
    for(var i in data){        
        var obj = new Group();
        obj.ID = data[i].rid;    
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getMem(path,groupinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from roommember where rid = '"+groupinfo.ID+"' " ) +')');
    for(var i in data){        
        var obj = new Mem();
        obj.ID = data[i].uid;    
        obj.Name = data[i].membername;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
    
}
 function getComment(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from COMMENT  " ) +')');
    for(var i in data){        
        var obj = new Comment();
        obj.UID = data[i].USER_ID;
        obj.CID = data[i].COMMENT_ID;
        obj.Content = data[i].CONTENT;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].POSTED_AT);
        obj.Name = data[i].NICKNAME;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getFav(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from favorite  " ) +')');
    for(var i in data){        
        var obj = new Fav();
        obj.FID = data[i].fid;
        obj.UID = data[i].uid;
        var a = data[i].messagetype;
        switch(a){
            case 0:
            obj.MType = "文本";
            break;
           case 3:
            obj.MType = "语音";
            break;
            case 7:
            obj.MType = "语音和文本";
            break; 
            case 8:
            obj.MType = "修改的文本";
            break;  
            default :
            obj.MType = "其他";
            
        }
        switch(data[i].transfertype){
            case 0: 
            obj.TType = "发送";
            break;
            case 1: 
            obj.TType = "接收";
            break;
        }
        obj.File = data[i].filename;
        var b = eval('('+ data[i].data +')');
        obj.Content = b.c;
        obj.Time = XLY.Convert.LinuxToDateTime(b.h);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getMoment(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from MOMENT left join USER on MOMENT.SERVER_USER_ID = USER.SERVER_USER_ID " ) +')');
    for(var i in data){        
        var obj = new Moment();
        obj.UID = data[i].SERVER_USER_ID;
        obj.MID = data[i].xly_id;
        obj.Content = data[i].CONTENT;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].POSTED_AT);
        obj.Position = data[i].POSITION_INFO;
        obj.Nick = data[i].NICKNAME;
        obj.Avatar = data[i].AVATAR_URL;
        obj.LONLAT = data[i].LONGITUDE+","+data[i].LATITUDE;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getSUser(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from SIMPLE_USER  " ) +')');
    for(var i in data){        
        var obj = new SUser();
        obj.Name = data[i].NICKNAME;
        obj.Id = data[i].USERID;
        obj.Avatar = data[i].HEADURL;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getFollow(path,accountinfo,contactinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from htfollowids" ) +')');
    for(var i in data){        
        var obj = new Follow();
        obj.Name = data[i].NICKNAME;
        obj.Id = data[i].USERID;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].CREATETIME);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getFans(path,accountinfo,contactinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ht_follower_list" ) +')');
    for(var i in data){        
        var obj = new Fans();
        obj.Name = data[i].NICKNAME;
        obj.Id = data[i].USERID;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].CREATETIME);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
 function getContact(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from USER " ) +')');
    for(var i in data){        
        var obj = new Contact();
        obj.Name = data[i].NICKNAME;
        obj.Id = data[i].SERVER_USER_ID;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getInfo(db){
    var list = new Array();
    var filenames = eval('('+ XLY.File.FindFiles(db) +')')    
    var info = new Array();
    for(var index in filenames){        
        var data = XLY.File.GetFileName(filenames[index]); 
        if((/^u_[0-9]\d*$/g).test(data)) info.push(data);
    }
    for(var i in info){
        var obj = new Info();
        obj.Acc = info[i].slice(2,info[i].length);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);  
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
//var db = "D:\\temp\\data\\data\\com.hellotalk\\databases";

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
