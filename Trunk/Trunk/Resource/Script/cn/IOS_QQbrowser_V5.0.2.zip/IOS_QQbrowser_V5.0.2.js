﻿// JScript source code

//descritpion:Test-导航树

/*[config]
<plugin name="QQ浏览器,1" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\IOS_QQBrowser.png" app="com.tencent.mttlite" version="5.0.2" description="QQ浏览器" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tencent.mttlite</value>
</source>
<data detailfield="Addr" type="Urlinfo">
<item name="名称" code="Name" type="string" width="120" ></item>
<item name="URL地址" code="Addr" type="string" width="160" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" ></item>
</data>
    
<data detailfield="Addr" type="Quicklink">
<item name="名称" code="Name" type="string" width="100" ></item>
<item name="URL地址" code="Addr" type="string" width="120" format=""></item>
</data>

<data  type="Download">
<item name="下载地址" code="Durl" type="string" width="120" ></item>
<item name="文件当前下载量" code="Downsize" type="string" width="60" format=""></item>
<item name="文件总大小" code="Totalsize" type="string" width="60" format=""></item>
<item name="下载时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" ></item>
<item name="下载状态" code="Status" type="string" width="60" format=""></item>    
</data>

<data  type="Account">
<item name="登录名" code="Acc" type="string" width="" ></item>   
</data>

</plugin>
[config]*/

// js content

//定义数据结构
function Download() {
    this.Durl = "";
    this.Downsize = "";
    this.Totalsize = "";
    this.Time = null;
    this.Status = "";
}

function Account() {
    this.Acc = "";
}

function Urlinfo() {
    this.Name = "";
    this.Time = null;
    this.Addr = "";
}

function Quicklink() {
    this.Name = "";
    this.Addr = "";
}

function ExecSql(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    return data;
}

function GetAcc(account) {
    var acc = new Account();
    acc.Acc = account;
    return acc
}

function search(str) {
    var reg = /mttData+[0-9]+.db+$/gi;
    var target = reg.test(str);
    if (target) {
        return str;
    }
}

function cut(str) {
    var end = str.lastIndexOf(".");
    var resource = str.slice(7, end);
    if (resource != null) {
        return resource;
    }
}

function GetInfo(sources) {
    var info = new Urlinfo();
    info.Name = sources.name;
    info.Addr = sources.url;
    info.Time = XLY.Convert.LinuxToDateTime(parseInt(sources.time));
    return info;
}

function GetQuicklink(sources) {
    var info = new Quicklink();
    info.Name = sources.name;
    info.Addr = sources.url;
    return info;
}

function Getdownload(sources) {
    var downinfo = new Download();
    downinfo.Durl = sources.url;
    downinfo.Downsize = sources.downsize;
    downinfo.Totalsize = sources.totalsize;
    downinfo.Status = sources.status;
    downinfo.Time = XLY.Convert.LinuxToDateTime(parseInt(sources.time));
    return downinfo
}

function BuildSimpleTree(path, treesql, treename, method) {
    var treeinfos = ExecSql(path, treesql)
    for (var index in treeinfos) {
        var list = treeinfos[index];
        var treeinfo = method(list);
        treename.Items.push(treeinfo);
    }
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}


var result = new Array();
//源文件
var source = $source;
var dataRoot = source[0] + "\\com.tencent.mttlite\\Documents\\.mttlite";

//var dataRoot="E:\\app data\\Iphone\\QQ浏览器\\2222\\Documents\\.mttlite";

var files = eval('(' + XLY.File.FindFiles(dataRoot) + ')');
for (var findex in files) {
    var filename = XLY.File.GetFileName(files[findex]);
    var t_file = search(filename);
    if (t_file != null) {
        var account = cut(t_file);
        var accountTree = new TreeNode();
        accountTree.Text = account;
        accountTree.Type = "Account";
        var accinfo = GetAcc(account);
        accountTree.Items.push(accinfo);

        var accdata = dataRoot + "\\" + t_file;
        var bmsql = "select b.[title]as name,b.[url]as url,b.[type]as type,b.[insert_date]as time from bookmarks b";
        var bookmarkTree = new TreeNode();
        bookmarkTree.Text = "书签";
        bookmarkTree.Type = "Urlinfo";
        BuildSimpleTree(accdata, bmsql, bookmarkTree, GetInfo);

        var hsql = "select h.[title]as name,h.[url]as url,h.[visited_date]as time,h.[visited_count]as count from history h";
        var historyTree = new TreeNode();
        historyTree.Text = "历史记录";
        historyTree.Type = "Urlinfo";
        BuildSimpleTree(accdata, hsql, historyTree, GetInfo);

        var qsql = "select q.[name],q.[url] from quicklinks q";
        var quicklinkTree = new TreeNode();
        quicklinkTree.Text = "快速链接";
        quicklinkTree.Type = "Quicklink";
        BuildSimpleTree(accdata, qsql, quicklinkTree, GetQuicklink);

        var ddata = dataRoot + "\\download.db";
        var dsql = "select do.[d_url]as url,do.[d_path]as path,do.[d_total_size]as totalsize,do.[d_down_size]as downsize,do.[d_status]as status,do.[d_time]as time from downloads do";
        var downloadTree = new TreeNode();
        downloadTree.Text = "下载";
        downloadTree.Type = "Download";
        BuildSimpleTree(ddata, dsql, downloadTree, Getdownload);

        accountTree.TreeNodes.push(bookmarkTree);
        accountTree.TreeNodes.push(historyTree);
        accountTree.TreeNodes.push(quicklinkTree);
        accountTree.TreeNodes.push(downloadTree);
        result.push(accountTree)
    }
}

// return
var res = JSON.stringify(result);
res;




