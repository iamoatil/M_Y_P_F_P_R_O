﻿/*[config]
<plugin name="淘宝,7" group="生活旅游,6" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="/icons/TaoBao.png" app="com.taobao.taobao" version="6.2.0" description="淘宝" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.taobao.taobao/databases/#F</value>
    <value>/data/data/com.taobao.taobao/shared_prefs/userinfo.xml</value>
</source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type = "Browse" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="宝贝名称" code="Name" type="string" width="" ></item>
    <item name="时间" code="Time" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    <item name="宝贝价格" code="Fee" type="string" width="" ></item>
    <item name="地点" code="Address" type="string" width = "" ></item>
    </data>
    <data type="Account">
    <item name="登录过的帐号名" code="Name" type="string" width = "" ></item>
    </data>
    <data type = "Contact" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="联系人" code="Account" type="string" width="300" format = ""></item>
     <item name="ID" code="ID" type="string" width="100" format=""></item>
    <item name="头像" code="Avatar" type="string" width="100" format=""></item>
    <item name="店名" code="Name" type="string" width="100" format=""></item>
    <item name="联系时间" code="Time" type="string" width="100" format = ""></item>
    </data>
    <data type = "Message" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="发送者" code="Sender" type="string" width = "" ></item>
    <item name="接受者" code="Receiver" type="string" width = "" ></item>
    <item name="内容" code="Content" type="string" width="" ></item>
    <item name="时间" code="Time" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}

function Account() {
    this.Name = "";
}
function Contact() {
    this.Account = "";
    this.Avatar = "";
    this.Name = "";
    this.ID = "";
    this.Time = "";
    this.DataState="Normal";
}
function Message() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Content = "";
    this.DataState="Normal";
}
function Browse() {
    this.Time = null;
    this.Name = "";
    this.Fee = "";
    this.Address = "";
    this.DataState="Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "淘宝";
    news.Type = "Account"; 
    accountinfo = getAccount(dbmessagecenter);
   // log(accountinfo);
    news.Items = accountinfo;
    news.DataState = "Normal";
    for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account"; 
        news.TreeNodes.push(account);

        var friend = new TreeNode();
        friend.Text = "联系人";
        friend.Type = "Contact";
        var friendinfo = getContact(dbmessagecenter,accountinfo[i]);
        friend.Items = friendinfo;
        for(var j in friendinfo){           
            var contact = new TreeNode();
            contact.Text = friendinfo[j].Account;
            contact.Type = "Message";
            contact.Items = getMessage(dbmessagecenter,friendinfo[j].Account,accountinfo[i]);
            friend.TreeNodes.push(contact);
        }
        account.TreeNodes.push(friend);   
    }  
      var browse = new TreeNode();
      browse.Text = "浏览信息";
      browse.Type = "Browse";
      browse.items = getBrowse(dbbrowse);
      news.TreeNodes.push(browse);
      
 result.push(news);
}      
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
    

function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct owner from contact" ) +')');    
    for(var i in data){
        var obj = new Account();
        obj.Name = data[i].owner;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getContact(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from contact where owner = '"+accountinfo.Name+"' and account <> '"+accountinfo.Name+"'" ) +')');   
    for(var i in data){
        var obj = new Contact();
        obj.Account = data[i].account;
        obj.Avatar = data[i].head_img;
        obj.Name = data[i].display_name;
        obj.ID = data[i].user_id;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Avatar = data[i].head_img;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }  
    return list;
}
function getMessage(path,contact,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from message where account = '"+contact+"' and owner='"+ accountinfo.Name +"'") +')');
    for(var i in data){
        var obj = new Message();
        if(data[i].direction==1){
            obj.Sender = data[i].owner;
            obj.Receiver = data[i].account;
        }else{
            obj.Sender = data[i].account;
            obj.Receiver = data[i].owner;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        var JSONObject1 = data[i].col2.split(",");
        var js = JSONObject1[3];       
        obj.Content = js.substr(11,js.length-6);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }  
    return list;
}
function getBrowse(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.FindByName(path, 'history') + ')');
    if(data!=null){    
        for(var i in data){
            var obj = new Browse();
            obj.Name = data[i].title;
            obj.Address = data[i].address;
            obj.Fee = data[i].fee + "元";
            obj.Time = data[i].gmt_create;
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0]+"\\AmpData";  
var db1 = source[0]+"\\data_history";
var accPath = source[1];

var charactor = "\\chalib\\Android_TaoBao_V6.2.0\\AmpData.charactor";
var charactor1 = "\\chalib\\Android_TaoBao_V6.2.0\\data_history.charactor";

//var db1 = "C:\\com.taobao.taobao3\\databases\\data_history";
//var db = "C:\\com.taobao.taobao3\\databases\\AmpData";
//var accPath = "C:\\com.taobao.taobao3\\shared_prefs\\userinfo.xml";
//
//var charactor1 = "C:\\com.taobao.taobao3\\databases\\data_history.charactor";
//var charactor = "C:\\com.taobao.taobao3\\databases\\AmpData.charactor";

var dbmessagecenter = XLY.Sqlite.DataRecovery(db,charactor,"contact,message");
var dbbrowse = XLY.Sqlite.DataRecovery(db1,charactor1,"history");

var result = new Array();
bindTree();
var res = JSON.stringify(result);


res;

