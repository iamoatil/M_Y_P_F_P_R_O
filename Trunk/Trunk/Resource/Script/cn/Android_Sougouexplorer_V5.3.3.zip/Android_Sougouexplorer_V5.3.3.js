﻿
/*[config]
<plugin name="搜狗浏览器,6" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/SouGou.png" app="sogou.mobile.explorer" version="5.3.3" description="搜狗浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/sogou.mobile.explorer/databases#F</value>
    <value>/data/data/sogou.mobile.explorer/shared_prefs/sogou.mobile.explorer_preferences.xml</value>

</source>

<data type="HisstoryAccount" contract = "DataState">
    
    <item name="用户ID" code="userid" type="string" width="100" format=""></item>
    <item name="用户名" code="nick" type="string" width="80" format = ""></item>
    <item name="用户头像" code="avatar" type="string" width="200" format=""></item>
</data>

<data type = "History" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="150" format = ""></item>
    <item name="历史浏览地址" code="Url" type="string" width="300" format=""></item>
    <item name="时间" code="time" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="访问次数" code="count" type="int" width="80" format = ""></item>
</data>

<data type = "BookMark" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="150" format = ""></item>
    <item name="历史浏览地址" code="Url" type="string" width="300" format=""></item>
    <item name="时间" code="time" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>

<data type = "DownLoad" detailfield = "url" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="下载URL" code="url" type="string" width="300" format = ""></item>
    <item name="下载文件名" code="name" type="string" width="150" format = ""></item>
    <item name="保存路径" code="path" type="string" width="200" format = ""></item>
    <item name="下载时间" code="time" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="文件总大小" code="total" type="string" width="100" format = ""></item>
    <item name="当前下载大小" code="cursize" type="string" width="100" format = ""></item>
    <item name="下载状态" code="status" type="string" width="100" format=""></item>
</data>

<data type = "Search" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="150" format = ""></item>
    <item name="历史浏览地址" code="Url" type="string" width="300" format=""></item>
    <item name="时间" code="time" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="搜索次数" code="count" type="int" width="80" format = ""></item>
</data>

<data type = "Quick" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="150" format = ""></item>
    <item name="历史浏览地址" code="Url" type="string" width="300" format=""></item>
    <item name="时间" code="time" type="datetime" width="120" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="类型" code="type" type="string" width="80" format = ""></item>
</data>

<data type = "Novel" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="150" format = ""></item>
    <item name="作者" code="author" type="string" width="100" format=""></item>
    <item name="封面图片" code="image" type="string" width="300" format = ""></item>
</data>

</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function HisstoryAccount() {
    this.userid = "";   //用户ID
    this.nick = ""; //用户名
    this.avatar = "";   //用户头像
}

function History() {
    this.Title = "";    //标题
    this.Url = "";  //历史浏览地址
    this.time = null;   //时间
    this.count = 0; //访问次数
    this.DataState = "Normal";
}

function BookMark() {
    this.Title = "";    //标题
    this.Url = "";  //历史浏览地址
    this.time = null;   //时间
    this.DataState = "Normal";
}


function DownLoad() {
    this.url = "";  //下载URL
    this.name = ""; //下载文件名
    this.path = ""; //保存路径
    this.time = null;   //下载时间
    this.total = "";    //文件总大小
    this.cursize = "";  //当前下载大小
    this.status = "";   //下载状态
    this.DataState = "Normal";
}

function Search() {
    this.Title = "";    //标题
    this.Url = "";  //历史浏览地址
    this.time = null;   //时间
    this.count = 0; //访问次数
    this.DataState = "Normal";
}

function Quick() {
    this.Title = "";    //标题
    this.Url = "";  //历史浏览地址
    this.time = null;   //时间
    this.type = 0;  //类型
    this.DataState = "Normal";
}

function Novel() {
    this.Title = "";    //标题
    this.author = "";   //作者
    this.image = "";    //封面图片
    this.DataState = "Normal";
}

//定义树形结构

function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//md5计算

var MD5 = function (string) {
  
    function RotateLeft(lValue, iShiftBits) {
        return (lValue<<iShiftBits) | (lValue>>>(32-iShiftBits));
    }
  
    function AddUnsigned(lX,lY) {
        var lX4,lY4,lX8,lY8,lResult;
        lX8 = (lX & 0x80000000);
        lY8 = (lY & 0x80000000);
        lX4 = (lX & 0x40000000);
        lY4 = (lY & 0x40000000);
        lResult = (lX & 0x3FFFFFFF)+(lY & 0x3FFFFFFF);
        if (lX4 & lY4) {
            return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
        }
        if (lX4 | lY4) {
            if (lResult & 0x40000000) {
                return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
            } else {
                return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
            }
        } else {
            return (lResult ^ lX8 ^ lY8);
        }
    }
  
    function F(x,y,z) { return (x & y) | ((~x) & z); }
    function G(x,y,z) { return (x & z) | (y & (~z)); }
    function H(x,y,z) { return (x ^ y ^ z); }
    function I(x,y,z) { return (y ^ (x | (~z))); }
  
    function FF(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function GG(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function HH(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function II(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function ConvertToWordArray(string) {
        var lWordCount;
        var lMessageLength = string.length;
        var lNumberOfWords_temp1=lMessageLength + 8;
        var lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1 % 64))/64;
        var lNumberOfWords = (lNumberOfWords_temp2+1)*16;
        var lWordArray=Array(lNumberOfWords-1);
        var lBytePosition = 0;
        var lByteCount = 0;
        while ( lByteCount < lMessageLength ) {
            lWordCount = (lByteCount-(lByteCount % 4))/4;
            lBytePosition = (lByteCount % 4)*8;
            lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount)<<lBytePosition));
            lByteCount++;
        }
        lWordCount = (lByteCount-(lByteCount % 4))/4;
        lBytePosition = (lByteCount % 4)*8;
        lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80<<lBytePosition);
        lWordArray[lNumberOfWords-2] = lMessageLength<<3;
        lWordArray[lNumberOfWords-1] = lMessageLength>>>29;
        return lWordArray;
    };
  
    function WordToHex(lValue) {
        var WordToHexValue="",WordToHexValue_temp="",lByte,lCount;
        for (lCount = 0;lCount<=3;lCount++) {
            lByte = (lValue>>>(lCount*8)) & 255;
            WordToHexValue_temp = "0" + lByte.toString(16);
            WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length-2,2);
        }
        return WordToHexValue;
    };
  
    function Utf8Encode(string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
  
        for (var n = 0; n < string.length; n++) {
  
            var c = string.charCodeAt(n);
  
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
  
        }
  
        return utftext;
    };
  
    var x=Array();
    var k,AA,BB,CC,DD,a,b,c,d;
    var S11=7, S12=12, S13=17, S14=22;
    var S21=5, S22=9 , S23=14, S24=20;
    var S31=4, S32=11, S33=16, S34=23;
    var S41=6, S42=10, S43=15, S44=21;
  
    string = Utf8Encode(string);
  
    x = ConvertToWordArray(string);
  
    a = 0x67452301; b = 0xEFCDAB89; c = 0x98BADCFE; d = 0x10325476;
  
    for (k=0;k<x.length;k+=16) {
        AA=a; BB=b; CC=c; DD=d;
        a=FF(a,b,c,d,x[k+0], S11,0xD76AA478);
        d=FF(d,a,b,c,x[k+1], S12,0xE8C7B756);
        c=FF(c,d,a,b,x[k+2], S13,0x242070DB);
        b=FF(b,c,d,a,x[k+3], S14,0xC1BDCEEE);
        a=FF(a,b,c,d,x[k+4], S11,0xF57C0FAF);
        d=FF(d,a,b,c,x[k+5], S12,0x4787C62A);
        c=FF(c,d,a,b,x[k+6], S13,0xA8304613);
        b=FF(b,c,d,a,x[k+7], S14,0xFD469501);
        a=FF(a,b,c,d,x[k+8], S11,0x698098D8);
        d=FF(d,a,b,c,x[k+9], S12,0x8B44F7AF);
        c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1);
        b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE);
        a=FF(a,b,c,d,x[k+12],S11,0x6B901122);
        d=FF(d,a,b,c,x[k+13],S12,0xFD987193);
        c=FF(c,d,a,b,x[k+14],S13,0xA679438E);
        b=FF(b,c,d,a,x[k+15],S14,0x49B40821);
        a=GG(a,b,c,d,x[k+1], S21,0xF61E2562);
        d=GG(d,a,b,c,x[k+6], S22,0xC040B340);
        c=GG(c,d,a,b,x[k+11],S23,0x265E5A51);
        b=GG(b,c,d,a,x[k+0], S24,0xE9B6C7AA);
        a=GG(a,b,c,d,x[k+5], S21,0xD62F105D);
        d=GG(d,a,b,c,x[k+10],S22,0x2441453);
        c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681);
        b=GG(b,c,d,a,x[k+4], S24,0xE7D3FBC8);
        a=GG(a,b,c,d,x[k+9], S21,0x21E1CDE6);
        d=GG(d,a,b,c,x[k+14],S22,0xC33707D6);
        c=GG(c,d,a,b,x[k+3], S23,0xF4D50D87);
        b=GG(b,c,d,a,x[k+8], S24,0x455A14ED);
        a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905);
        d=GG(d,a,b,c,x[k+2], S22,0xFCEFA3F8);
        c=GG(c,d,a,b,x[k+7], S23,0x676F02D9);
        b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A);
        a=HH(a,b,c,d,x[k+5], S31,0xFFFA3942);
        d=HH(d,a,b,c,x[k+8], S32,0x8771F681);
        c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122);
        b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C);
        a=HH(a,b,c,d,x[k+1], S31,0xA4BEEA44);
        d=HH(d,a,b,c,x[k+4], S32,0x4BDECFA9);
        c=HH(c,d,a,b,x[k+7], S33,0xF6BB4B60);
        b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70);
        a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6);
        d=HH(d,a,b,c,x[k+0], S32,0xEAA127FA);
        c=HH(c,d,a,b,x[k+3], S33,0xD4EF3085);
        b=HH(b,c,d,a,x[k+6], S34,0x4881D05);
        a=HH(a,b,c,d,x[k+9], S31,0xD9D4D039);
        d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5);
        c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8);
        b=HH(b,c,d,a,x[k+2], S34,0xC4AC5665);
        a=II(a,b,c,d,x[k+0], S41,0xF4292244);
        d=II(d,a,b,c,x[k+7], S42,0x432AFF97);
        c=II(c,d,a,b,x[k+14],S43,0xAB9423A7);
        b=II(b,c,d,a,x[k+5], S44,0xFC93A039);
        a=II(a,b,c,d,x[k+12],S41,0x655B59C3);
        d=II(d,a,b,c,x[k+3], S42,0x8F0CCC92);
        c=II(c,d,a,b,x[k+10],S43,0xFFEFF47D);
        b=II(b,c,d,a,x[k+1], S44,0x85845DD1);
        a=II(a,b,c,d,x[k+8], S41,0x6FA87E4F);
        d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0);
        c=II(c,d,a,b,x[k+6], S43,0xA3014314);
        b=II(b,c,d,a,x[k+13],S44,0x4E0811A1);
        a=II(a,b,c,d,x[k+4], S41,0xF7537E82);
        d=II(d,a,b,c,x[k+11],S42,0xBD3AF235);
        c=II(c,d,a,b,x[k+2], S43,0x2AD7D2BB);
        b=II(b,c,d,a,x[k+9], S44,0xEB86D391);
        a=AddUnsigned(a,AA);
        b=AddUnsigned(b,BB);
        c=AddUnsigned(c,CC);
        d=AddUnsigned(d,DD);
    }
  
    var temp = WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);
  
    return temp.toLowerCase();
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path = source[0];
var xmlpath = source[1];
//var path = "J:\\APP_script\\Android_js\\SouGouexplorer\\test2\\databases";
//var xmlpath = "J:\\APP_script\\Android_js\\SouGouexplorer\\test2\\shared_prefs\\sogou.mobile.explorer_preferences.xml";

//测试数据
//var path1 = "E:\\app_data\\Android\\com.opera.browser\\app_opera\\favorites.db";
//var path2 = "E:\\app_data\\Android\\com.opera.browser\\shared_prefs\\recently_closed_tabs.xml";


//定义特征库文件
var dlch = "chalib\\Android_Sougouexplorer_V5.3.3\\downloads.db.charactor";
var hisch = "chalib\\Android_Sougouexplorer_V5.3.3\\sogou_cloud_default.db.charactor";
var browserch="chalib\\Android_Sougouexplorer_V5.3.3\\sogou_mobile_browser.db.charactor";


//恢复数据库中删除的数据
//var recoverypath = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");


buildTree();

var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************

//创建主节点
function buildTree(){
    var sougouroot = new TreeNode();
    sougouroot.Text = "搜狗浏览器";
    
    var mainpath = path+"\\sogou_mobile_browser.db";
    var recHisaccPath = XLY.Sqlite.DataRecovery(mainpath,browserch ,"sogou_native_user_info,sogou_his_url,quicklaunch,novel");
    //主节点之下创建历史浏览及收藏，下载记录，历史搜索，浏览器主页等四个节点
    var history = new TreeNode();
    history.Text = "历史浏览及收藏";
    buildHistoryNode(history,recHisaccPath);
    
    var download = new TreeNode();
    download.Text = "下载记录";
    getDownloadInfo(download);
    
    var serchHis = new TreeNode();
    serchHis.Text = "历史搜索";
    getserchHisInfo(serchHis,recHisaccPath);
    
    var home = new TreeNode();
    home.Text = "浏览器主页";
    buildHomeNode(home,recHisaccPath)
    
    sougouroot.TreeNodes.push(history);
    sougouroot.TreeNodes.push(download);
    sougouroot.TreeNodes.push(serchHis);
    sougouroot.TreeNodes.push(home);
    result.push(sougouroot);
}


//根据数据库中账号信息创建历史浏览及收藏的子节点
function buildHistoryNode(hisroot,hisaccPath){
    //记录登陆过的账号信息
    //var hisaccPath = path+"\\sogou_mobile_browser.db";
    
    var hisaccInfo = eval('('+ XLY.Sqlite.Find(hisaccPath,"select * from sogou_native_user_info") +')');
    if(hisaccInfo.length>0){
        hisroot.Type = "HisstoryAccount";
        for(var i in hisaccInfo){
            //获取账号信息
            var hisrootObj = new HisstoryAccount();
            hisrootObj.userid = hisaccInfo[i].u_user_id;
            hisrootObj.nick = hisaccInfo[i].u_nick_name;
            hisrootObj.avatar = hisaccInfo[i].u_midavatar;
            hisroot.Items.push(hisrootObj);
            
            //根据帐号创建子节点
            if(hisaccInfo[i].XLY_DataType==2){
                var accnode = new TreeNode();
                accnode.text = hisaccInfo[i].u_nick_name;
                if(hisaccInfo[i].u_nick_name=="Understander"){
                    accnode.text = "默认帐号";
                }
                hisroot.TreeNodes.push(accnode);
                buildAccInfoNode(accnode,hisaccInfo[i])
            }
            
        }
    }
    
}



//创建每个帐号下的历史浏览及收藏记录
function buildAccInfoNode(accroot,accinfo){
    //计算各历史帐号的数据文件名称
    var accPath = "";
    var md5info = MD5(accinfo.u_user_id);
    accPath = path+"\\sogou_cloud_"+md5info+".db";
    
    if(accinfo.u_nick_name=="Understander"){
        accPath = path + "\\sogou_cloud_default.db";
    }
    //var xmlinfo = eval('('+ XLY.File.ReadXML(xmlpath) +')');
    var xmlinfo = XLY.File.ReadFile(xmlpath)
    var reg = new RegExp(accinfo.u_nick_name,"i");
    if(reg.test(xmlinfo)){
        var dbfilename = eval('('+ XLY.File.FindFileNamesWithExtension(path) +')');
        for(var index in dbfilename){
            //log(/^sogou_cloud_+.+\.db$/.test(dbfilename[index]));
            //log();
            if(/^sogou_cloud_+.+\.db$/.test(dbfilename[index])&&dbfilename[index]!="sogou_cloud_default.db"&&!/recovery/.test(dbfilename[index])){
                accPath = path+"\\"+dbfilename[index];
            }
        }
    }
    //log(accPath);
    if(XLY.File.IsValid(accPath)){
        
        //获取文件中历史浏览内容并创建节点
        var recaccPath = XLY.Sqlite.DataRecovery(accPath,hisch,"cloud_history,cloud_favorite");
        var hisdata = eval('('+ XLY.Sqlite.Find(recaccPath,"select * from cloud_history") +')');
        //log(hisdata.length);
        if(hisdata.length>0&&hisdata!=null){
            //创建历史浏览记录节点
            var acchis = new TreeNode();
            acchis.Text = "历史浏览";
            acchis.type = "History";
            //log(accroot);
            for(var i in hisdata){
                var acchisObj = new History();
                acchisObj.Title = hisdata[i].h_title;    //标题
                acchisObj.Url = hisdata[i].h_url;  //历史浏览地址
                acchisObj.time = XLY.Convert.LinuxToDateTime(hisdata[i].h_last_modify);   //时间
                acchisObj.count = XLY.Convert.ToInt(hisdata[i].h_visit_count); //访问次数
                acchisObj.DataState = XLY.Convert.ToDataState(hisdata[i].XLY_DataType);
                acchis.Items.push(acchisObj);
            }
            accroot.TreeNodes.push(acchis);
        }
        
        //获取文件中收藏内容并创建节点
        var bmdata =  eval('('+ XLY.Sqlite.Find(recaccPath,"select * from cloud_favorite") +')');
        if(bmdata.length>0&&bmdata!=null){
            var accbm = new TreeNode();
            accbm.Text = "收藏信息";
            accbm.Type = "BookMark";
            for(var i in bmdata){
                if(bmdata[i].f_is_folder==0){
                    if(bmdata[i].f_server_pid==""||bmdata[i].f_server_pid==null){
                        accbm.Items.push(getbmInfo(bmdata[i]));
                    }
                }
                if(bmdata[i].f_is_folder==1){
                    if(bmdata[i].f_server_pid == ""){
                        var subnode = new TreeNode();
                        subnode.Text = bmdata[i].f_title;
                        subnode.Type = "BookMark";
                        var sbbmdata = eval('('+ XLY.Sqlite.Find(recaccPath,"select * from cloud_favorite  where f_is_folder=0 AND f_server_pid = '"+bmdata[i].f_server_id+"'") +')');
                        if(sbbmdata.length>0){
                            for(var index in sbbmdata){
                                subnode.Items.push(getbmInfo(sbbmdata[index]));
                            }
                        }
                        //创建收藏文件夹的子节点，如果完整展示恢复数据的此处的入参为恢复之后数据库路径，由于特征库配置不严谨或者进行sqlite数据恢复之后的结果容易出现乱码，可将入参改为未恢复的路径accPath
                        buildeChildNode(recaccPath,bmdata[i].f_server_id,subnode);
                        accbm.TreeNodes.push(subnode);
                    }
                }
            }
            accroot.TreeNodes.push(accbm);
        }
    }
}


//创建书签的子节点
function buildeChildNode(path,pid,treeroot){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cloud_favorite where f_is_folder=1 AND f_server_pid = '"+pid+"' ") +')');
    if(data.length>0){
        for(var i in data){
            var childNode = new TreeNode();
            childNode.Text = data[i].f_title;
            childNode.Type = "BookMark";
            var bmdata = eval('('+ XLY.Sqlite.Find(path,"select * from cloud_favorite where f_is_folder=0 AND f_server_pid = '"+data[i].f_server_id+"'") +')');
            if(bmdata.length>0){
                for(var num in bmdata){
                    childNode.Items.push(getbmInfo(bmdata[num]));
                }
            }
            buildeChildNode(path,data[i].f_server_id,childNode);
            treeroot.TreeNodes.push(childNode);
        }
    }
}



//获取书签记录中的内容
function getbmInfo(info){
    var bmobj = new BookMark();
    bmobj.Title = info.f_title;    //标题
    bmobj.Url = info.f_url;  //历史浏览地址
    bmobj.time = XLY.Convert.LinuxToDateTime(info.f_last_modify);   //时间
    bmobj.DataState = XLY.Convert.ToDataState(info.XLY_DataType);
    return bmobj;
}



//获取下载信息
function getDownloadInfo(dlroot){
    
    var dlpath = path+"\\downloads.db";
    //恢复删除数据
    var recdlpath = XLY.Sqlite.DataRecovery(dlpath,dlch ,"downloads");
    var dldata = eval('('+ XLY.Sqlite.Find(dlpath,"select uri,hint,_data,status,lastmod,total_bytes,current_bytes from downloads") +')');
    if(dldata.length>0&&dldata!=null){
        dlroot.Type = "DownLoad";
        for(var i in dldata){
            var dlobj = new DownLoad();
            dlobj.url = dldata[i].uri;  //下载URL
            dlobj.name = dldata[i].hint; //下载文件名
            dlobj.path = dldata[i].xly_data; //保存路径
            dlobj.time = XLY.Convert.LinuxToDateTime(dldata[i].lastmod);   //下载时间
            dlobj.total = dldata[i].total_bytes;    //文件总大小
            dlobj.cursize = dldata[i].current_bytes;  //当前下载大小
            dldata[i].status==200?dlobj.status = "下载已完成":dlobj.status = "下载暂停或异常终止";   //下载状态
            dlobj.DataState = XLY.Convert.ToDataState(dldata[i].XLY_DataType);
            dlroot.Items.push(dlobj);
        }
    }
}

//历史搜索信息
function getserchHisInfo(serchroot,shpath){
    var shdata = eval('('+ XLY.Sqlite.Find(shpath,"select * from sogou_his_url where h_type<>2") +')');
    if(shdata.length>0&&shdata!=null){
        serchroot.Type = "Search";
        for(var i in shdata){
            var shobj = new Search();
            shobj.Title = shdata[i].h_title;    //标题
            shobj.Url = shdata[i].h_url;  //历史浏览地址
            shobj.time = shdata[i].h_last_use_time;   //时间
            shobj.count = shdata[i].h_visit_count; //访问次数
            shobj.DataState = XLY.Convert.ToDataState(shdata[i].XLY_DataType);
            serchroot.Items.push(shobj);
        }
    }
}


//创建主页子节点
function buildHomeNode(homeroot,hpath){
    //创建快速访问链接
    var quick = new TreeNode();
    quick.Text = "快速访问";
    quick.type = "Quick";
    var qdata = eval('('+ XLY.Sqlite.Find(hpath,"select * from quicklaunch") +')');
    if(qdata.length>0&&qdata!=null){
        for(var i in qdata){
            var qobj = new Quick();
            qobj.Title = qdata[i].title;    //标题
            qobj.Url = qdata[i].url;  //历史浏览地址
            qobj.time = null;   //时间
            if(qdata[i].type==0){
                qobj.time = XLY.Convert.LinuxToDateTime(qdata[i].md5_lastupdate);
            }
            qdata[i].type==1?qobj.type="浏览器默认":qobj.type = "用户添加";  //类型
            qobj.DataState = XLY.Convert.ToDataState(qdata[i].XLY_DataType);
            quick.Items.push(qobj);
            
        }
    }
    homeroot.TreeNodes.push(quick);
    
    
    //创建添加的小说信息
    var novel = new TreeNode();
    novel.Text = "小说信息";
    novel.Type = "Novel";
    var ndata = eval('('+ XLY.Sqlite.Find(hpath,"select * from novel ") +')');
    if(ndata.length>0&&ndata!=null){
        for(var index in ndata){
            var nobj = new Novel();
            nobj.Title = ndata[index].title;    //标题
            nobj.author = ndata[index].author;   //作者
            nobj.image = ndata[index].image_url;    //封面图片
            nobj.DataState = XLY.Convert.ToDataState(ndata[index].XLY_DataType);
            novel.Items.push(nobj);
        }
    }
    homeroot.TreeNodes.push(novel);
    
}


