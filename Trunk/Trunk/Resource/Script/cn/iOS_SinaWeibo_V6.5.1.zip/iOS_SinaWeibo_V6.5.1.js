﻿/*[config]
<plugin name="新浪微博,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/sinaweibo.png" app="com.sina.weibo" version="6.5.1" description="新浪微博" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.sina.weibo</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="SearchWord"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关键字" code="Key" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="200" format = "" ></item>
    <item name="性别" code="Gender" type="string" width="200" format=""></item>
    <item name="页标识" code="PageID" type="string" width="200" format = "" ></item>
    <item name="头像链接地址" code="ProfileHeadUrl" type="url" width="200" format=""></item>
    <item name="背景链接地址" code="BGUrl" type="url" width="200" format=""></item>
    <item name="关注" code="Following" type="string" width="200" format=""></item>
    <item name="粉丝" code="Follower" type="string" width="200" format=""></item>
    <item name="简介" code="Descrp" type="string" width="200" format=""></item>
    <item name="微博数" code="WeiboCount" type="string" width="200" format=""></item>
    <item name="最后修改用户信息时间" code="LastLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Contact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="200" format = "" ></item>
    <item name="头像链接地址" code="ProfileHeadUrl" type="url" width="200" format=""></item>
    <item name="最近微博" code="LastContent" type="string" width="200" format=""></item>
    <item name="会员等级" code="MembershipRank" type="string" width="200" format=""></item>
    <item name="最后使用时间" code="LastUsedTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后消息时间" code="LastMessageTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="LastContact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="200" format = "" ></item>
    <item name="评论" code="Remark" type="string" width="200" format = "" ></item>
    <item name="头像链接地址" code="ProfileHeadUrl" type="url" width="200" format=""></item>
    <item name="性别" code="Gender" type="string" width="200" format=""></item>
    <item name="简介" code="Introduction" type="string" width="200" format=""></item>
    <item name="最后联系时间" code="LastContactTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="GroupInfo" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="GroupName" type="string" width="100" format="" ></item>
    <item name="群头像" code="Avater" type="string" width="200" format = ""></item>
    <item name="创建者ID" code="OwnerID" type="string" width="120" format = ""></item>
    <item name="创建者名称" code="OwnerName" type="string" width="120" format = ""></item>
    <item name="成员个数" code="MemberCount" type="string" width="120" format = ""></item>
    <item name="管理员ID" code="ManagerID" type="string" width="200" format = ""></item>
    <item name="时间" code="JoinTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="PrivateLetter" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="120" format=""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="120" format = ""></item>
    <item name="接收者ID" code="ReciveID" type="string" width="120" format=""></item>
    <item name="接收者姓名" code="ReciveName" type="string" width="140" format = ""></item>
    <item name="发送时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="内容" code="Content" type="string" width="100" format=""></item>
    <item name="已读" code="IsRead" type="string" width="200" format = ""></item>
</data>
<data type="GroupChat" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="200" format = ""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="200" format = ""></item>
    <item name="接收者ID" code="ReceiveID" type="string" width="200" format = ""></item>
    <item name="接收者姓名" code="ReceiveName" type="string" width="200" format = ""></item>
    <item name="类型" code="SendType" type="string" width="200" format = ""></item>
    <item name="内容" code="Content"  type="string" width="150" format = ""></item>
    <item name="已读" code="IsRead"  type="string" width="150" format = ""></item>
    <item name="时间" code="SendTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="HomePage" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="源微博ID" code="ID" type="string" width="200" format = ""></item>
    <item name="源昵称" code="Nick" type="string" width="200" format = ""></item>
    <item name="源id" code="Uid" type="string" width="200" format = ""></item>
    <item name="源头像" code="Protrait" type="url" width="200" format = ""></item>
    <item name="源内容" code="Content" type="string" width="200" format = ""></item>
    <item name="转发次数" code="Rtnum" type="string" width="200" format = ""></item>
    <item name="评论次数" code="Commentnum" type="string" width="200" format = ""></item>
    <item name="源图像链接" code="Pic" type="string" width="200" format = ""></item>
    <item name="博文ID" code="RtrootuSourceid" type="string" width="200" format = ""></item>
    <item name="博主ID" code="Rtrootuid" type="string" width="200" format = ""></item>
    <item name="博主昵称" code="RtrootNick" type="string" width="200" format = ""></item>
    <item name="博文" code="Rtreason" type="string" width="200" format = ""></item>
    <item name="来源" code="ContentSource" type="string" width="200" format = ""></item>
    <item name="经度" code="Lon" type="string" width="200" format = ""></item>
    <item name="纬度" code="Lat" type="string" width="200" format = ""></item>
    <item name="时间" code="DTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
<data type="PageInfo" contract="DataState" datefilter="PageContent">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="PageTitle" type="string" width="200" format = ""></item>
    <item name="链接" code="PageURL"  type="url" width="150" format = ""></item>
    <item name="图片链接" code="PageImageURL"  type="url" width="150" format = ""></item>
    <item name="内容" code="PageContent" type="string" width="200" format = ""></item>
    <item name="最后修改时间" code="DTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function SearchWord(){
    this.DataState = "Normal";
    this.Key = "";
}
function PageInfo(){
    this.DataState = "Normal";
    this.PageTitle = "";
    this.PageURL = "";
    this.PageImageURL = "";
    this.PageContent = "";
    this.DTime = null;
}
function HomePage(){
    this.DataState = "Normal";
    this.ID = "";
    this.Nick = "";
    this.Uid = "";
    this.Protrait = "";
    this.Content = "";
    this.Rtnum = "";
    this.Commentnum = "";
    this.Pic = "";
    this.RtrootuSourceid = "";
    this.Rtrootuid = "";
    this.RtrootNick = "";
    this.Rtreason = "";
    this.ContentSource = "";
    this.Lon = "";
    this.Lat = "";
    this.DTime = null;
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Cache数据结构
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.Gender = "";
    this.LastLanchTime = null;
    this.PageID = "";
    this.ProfileHeadUrl = "";
    this.BGUrl = "";
    this.Following = "";
    this.Follower = "";
    this.Descrp = "";
    this.WeiboCount = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.UserName = "";
    this.LastContent = "";
    this.LastMessageTime = null;
    this.LastUsedTime = null;
    this.MembershipRank = "";
    this.ProfileHeadUrl = "";
}
//定义LastContact数据结构
function LastContact(){
    this.DataState = "Normal";
    this.UserName = "";
    this.Remark = "";
    this.Gender = "";
    this.Introduction = "";
    this.ProfileHeadUrl = "";
    this.LastContactTime = null;
}
//定义GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupName = "";
    this.Avater = "";
    this.OwnerID = "";
    this.ManagerID = "";
    this.MemberCount = "";
    this.JoinTime = null;
    this.OwnerName = "";
}
//定义PrivateLetter数据结构
function PrivateLetter(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReciveID = "";
    this.ReciveName = "";
    this.StartTime = null;
    this.Content = "";
    //this.ContentType = "";
    this.IsRead = "";
}
//定义GroupChat数据结构
function GroupChat(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReceiveID = "";
    this.ReceiveName = "";
    this.SendType = "";
    this.Content = "";
    this.IsRead = "";
    this.SendTime = null;
}
//定义SearchSt数据结构
function SearchSt(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Host = "";
    this.STime = null;
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.sina.weibo\\Documents";
var cookPath = source[0]+"\\com.sina.weibo\\Library\\Cookies\\Cookies.binarycookies";
var searchPath = source[0]+"\\com.sina.weiboLibrary\\Preferences\\com.sina.weibo.plist";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-03-29-17-46-02\\source\\IosData\\2017-03-29-17-47-00\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sina.weibo\\Documents";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-03-29-17-46-02\\source\\IosData\\2017-03-29-17-47-00\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sina.weibo\\Library\\Cookies\\Cookies.binarycookies";
//var searchPath = "C:\\XLYSFTasks\\任务-2017-03-29-17-46-02\\source\\IosData\\2017-03-29-17-47-00\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sina.weibo\\Library\\Preferences\\com.sina.weibo.plist";
//定义特征库文件
var charactor1 = "chalib\\iOS_Weibo_V6.5.1\\db_65100_6050936393.dat.charactor";
var charactor2 = "chalib\\iOS_Weibo_V6.5.1\\message_6050936393.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "新浪微博";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var data = eval('('+ XLY.File.FindFileNames(allPath) +')');
    var reg = new RegExp("message_","i");
    var reg1 = new RegExp("recovery","i");
    var reg2 = new RegExp("db_","i");
                        
    if(data!=""&&data!= null){
        
        for(var i in data){
            if(reg.test(data[i])){
                if(!reg1.test(data[i])){
                    if(data[i].split("_")[1]==0||data[i].split("_")[1]==null){
                        var aa = "默认账户";
                    }
                    else
                    {
                        var aa = data[i].split("_")[1];              
                        for(var f in data){
                            if(reg2.test(data[f])){
                                if(!reg1.test(data[f])){
                                    if(data[f].split("_")[2]==aa){
                                        var ff = allPath+"\\"+data[f]+".dat";
                                    }
                                }
                            }
                        }
                        var bdf = eval('('+ XLY.Sqlite.Find(ff,"select screenName from profileusers where userID = '"+aa+"'") +')');
                    }
                    var obj = new News();
                    if(bdf!=""&&bdf!=null){
                        obj.List = aa+"_"+bdf[0].screenName;
                    }
                    else
                    {
                        obj.List = aa;
                    }
                    root.Items.push(obj);
                    var node = new TreeNode();
                    node.Text = obj.List;
                    node.Type = "UserInfo";
                    root.TreeNodes.push(node);
                    getUserInfo(node,aa,obj.List);
                }
            }
        }
    }
    if(XLY.File.IsValid(cookPath)){
        var cachenode = new TreeNode();
        cachenode.Text = "Cache缓存";
        cachenode.Type = "Cache";
        getCache(cachenode);
        root.TreeNodes.push(cachenode);
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
function getUserInfo(root,info,temp){
    if(info=="默认账户"){
        var aa = "1005270587517.dat";
        info = 0;
    }
    else
    {
        var aa = info+".dat";
    }
    var data = eval('('+ XLY.File.FindFileNamesWithExtension(allPath) +')');
    var reg = new RegExp(aa,"i");
    for(var i in data){
        if(reg.test(data[i])){
            var userPath1 = allPath+"\\"+data[i];
            var messagePath1 = allPath+"\\message_"+info+".db";
            var abc = eval('('+ XLY.Sqlite.Find(messagePath1,"select id from t_group") +')');
            var dddddd = "";
            if(abc!=""&&abc!=null){
                
                for(var d in abc){
                    dddddd+= "t_message_g_"+abc[d].id+",";
                }
                dddddd+= "t_buddy,t_group,t_message,t_chat";
            }
            else
            {
                dddddd= "t_buddy,t_group,t_message,t_chat";
            }    
            var messagePath = XLY.Sqlite.DataRecovery(messagePath1,charactor2,dddddd);
            var userPath = XLY.Sqlite.DataRecovery(userPath1,charactor1,"contacts,profileusers,timeline_pageinfos,weibos");
            
            if(XLY.File.IsValid(userPath)){
                var user = eval('('+ XLY.Sqlite.Find(userPath,"select * from profileusers") +')');
                if(user!=""&&user!=null){
                    var obj = new UserInfo();
                    obj.DataState = XLY.Convert.ToDataState(user[0].XLY_DataType);
                    obj.UserName = user[0].screenName;
                    if(user[0].gender==1){
                        obj.Gender = "男";
                    }
                    else if(user[0].gender==0)
                    {
                        obj.Gender = "女";
                    }
                    else
                    {
                        obj.Gender = "不确定";
                    }
                    obj.LastLanchTime = XLY.Convert.LinuxToDateTime(user[0].lastUpdateUserInfoTime);
                    obj.PageID = user[0].pageID;
                    obj.ProfileHeadUrl = user[0].profileImageURL;
                    obj.BGUrl = user[0].coverUrl;
                    obj.Following = user[0].followingCount;
                    obj.Follower = user[0].followersCount;
                    obj.Descrp = user[0].description;
                    obj.WeiboCount = "";
                    root.Items.push(obj);
                    var contactnode = new TreeNode();
                    contactnode.Text = "好友列表";
                    contactnode.Type = "News";
                    getContactInfo(contactnode,userPath,messagePath);
                    root.TreeNodes.push(contactnode);
                }
            }
            if(XLY.File.IsValid(messagePath)){
                var groupNode = new TreeNode();
                groupNode.Text = "群组信息";
                groupNode.Type = "GroupInfo";
                var group = eval('('+ XLY.Sqlite.Find(messagePath,"select * from t_group") +')');
                if(group!=""&&group!= null){
                    for(var i in group){
                        var obj = new GroupInfo();
                        obj.DataState = XLY.Convert.ToDataState(group[i].XLY_DataType);
                        obj.GroupName = group[i].name;
                        obj.Avater = group[i].avatar;
                        obj.OwnerID = group[i].owner;
                        var aa = eval('('+ XLY.Sqlite.Find(messagePath,"select name from t_buddy where id = '"+obj.OwnerID+"'") +')');
                        if(aa!=""&&aa!=null){
                            obj.OwnerName = aa[0].name;
                        }
                        obj.ManagerID = group[i].managers;
                        obj.MemberCount = group[i].member_count;
                        obj.JoinTime = XLY.Convert.LinuxToDateTime(group[i].join_time);
                        
                        var node = new TreeNode();
                        node.Text = group[i].id+"_"+group[i].name;
                        node.Type = "GroupChat";
                        node.DataState = XLY.Convert.ToDataState(group[i].XLY_DataType);
                        getGroupNodeInfo(node,messagePath,"t_message_g_"+group[i].id);
                        groupNode.TreeNodes.push(node);
                        groupNode.Items.push(obj);
                    }
                    root.TreeNodes.push(groupNode);
                }
                
                var privateNode = new TreeNode();
                privateNode.Text = "私信";
                privateNode.Type = "News";
                var chatName = eval('('+ XLY.Sqlite.Find(messagePath,"select distinct(chat_id) from t_message") +')');
                if(chatName!=""&&chatName!= null){
                    for(var i in chatName){
                        var node1 = new TreeNode();
                        var aaa = eval('('+ XLY.Sqlite.Find(messagePath,"select name from t_buddy where id = '"+chatName[i].chat_id+"'") +')');
                        //var aaa = eval('('+ XLY.Sqlite.Find(userPath,"select screenName from contacts where uerID = '"+chatName[i].uid+"'") +')');
                        if(aaa!=""&&aaa!=null){
                            node1.Text = chatName[i].chat_id+"_"+aaa[0].name;
                        }
                        else
                        {
                            node1.Text = chatName[i].chat_id;
                        }
                        node1.Type = "PrivateLetter";
                        node1.DataState = XLY.Convert.ToDataState(chatName[i].XLY_DataType);
                        getPrivaterLetter(node1,messagePath,chatName[i].chat_id,temp);
                        privateNode.TreeNodes.push(node1);
                    }
                    root.TreeNodes.push(privateNode);
                }
                
                var childNode = new TreeNode();
                childNode.Text = "微博";
                childNode.Type = "News";
                getChildNode(childNode,userPath,info);
                root.TreeNodes.push(childNode);
            }
        }
    }
}
function getContactInfo(root,userPath,messagePath){
    var followingNode = new TreeNode();
    followingNode.Text = "关注";
    followingNode.Type = "Contact";
    var followerNode = new TreeNode();
    followerNode.Text = "粉丝";
    followerNode.Type = "Contact";
    var data = eval('('+ XLY.Sqlite.Find(userPath,"select * from contacts") +')');
    if(data!=""&&data!=null){
        for(var i in data){
            var obj = new Contact();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.UserName = data[i].screenName;
            obj.LastContent = data[i].lastStatusContent;
            obj.LastMessageTime = XLY.Convert.LinuxToDateTime(data[i].lastMessageTime);
            obj.LastUsedTime = XLY.Convert.LinuxToDateTime(data[i].lastUsedTime);
            obj.MembershipRank = data[i].membershipRank;
            obj.ProfileHeadUrl = data[i].profileImageURL;
            if(data[i].relationship==1){
                followingNode.Items.push(obj);
            }
            else
            {
                followerNode.Items.push(obj);
            }
        }
        root.TreeNodes.push(followingNode);
        root.TreeNodes.push(followerNode);
    }
    var lastContactNode = new TreeNode();
    lastContactNode.Text = "最近联系人";
    lastContactNode.Type = "LastContact";
    var buddy = eval('('+ XLY.Sqlite.Find(messagePath,"select * from t_buddy") +')');
    if(buddy!=""&&buddy!=null){
        for(var i in buddy){
            var obj = new LastContact();
            obj.DataState = XLY.Convert.ToDataState(buddy[i].XLY_DataType);
            obj.UserName = buddy[i].name;
            obj.Remark = buddy[i].remark;
            if(buddy[i].gender==1){
                obj.Gender = "男";
            }
            else if(buddy[i].gender==0)
            {
                obj.Gender = "女";
            }
            else
            {
                obj.Gender = "不确定";
            }
            var aa = eval('('+ XLY.Sqlite.Find(messagePath,"select * from t_chat where id = '"+buddy[i].id+"'") +')');
            if(aa!=""&&aa!=null){
                obj.LastContactTime = XLY.Convert.LinuxToDateTime(aa[0].time);
            }
            obj.Introduction = buddy[i].introduction;
            obj.ProfileHeadUrl = buddy[i].avatar;
            lastContactNode.Items.push(obj);
        }
        root.TreeNodes.push(lastContactNode);
    }
}
function getPrivaterLetter(root,path,id,temp){
    if(id!=0){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from t_message where chat_id = '"+id+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new PrivateLetter();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                if(data[i].status==1){
                    obj.SenderID = temp.split("_")[0];
                    obj.SenderName = temp.split("_")[1];
                    obj.ReciveID = id;
                    var aaa1 = eval('('+ XLY.Sqlite.Find(path,"select name from t_buddy where id = '"+id+"'") +')');
                    if(aaa1!=""&&aaa1!=null){
                        obj.ReciveName = aaa1[0].name;
                    }
                }
                else
                {
                    obj.SenderID = id;
                    var aaa = eval('('+ XLY.Sqlite.Find(path,"select name from t_buddy where id = '"+id+"'") +')');
                    if(aaa!=""&&aaa!=null){
                        obj.SenderName = aaa[0].name;
                    }
                    obj.ReciveID = temp.split("_")[0];
                    obj.ReciveName = temp.split("_")[1];
                }
                if(data[i].time!=0){
                    obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].time);
                }
                obj.Content = data[i].content;
                if(data[i].read_status==1){
                    obj.IsRead = "是";
                }
                else
                {
                    obj.IsRead = "否";
                }
                root.Items.push(obj);
            }
        }
    }
}
function getGroupNodeInfo(root,path,id){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from '"+id+"'") +')');
    if(data!=""&&data!=null){
        for(var i in data){
            var obj = new GroupChat();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.SenderID = data[i].sender_uid;
            var aaa = eval('('+ XLY.Sqlite.Find(path,"select name from t_buddy where id = '"+data[i].sender_uid+"'") +')');
            //var aaa = eval('('+ XLY.Sqlite.Find(userPath,"select screenName from contacts where uerID = '"+data[i].uid+"'") +')');
            if(aaa!=""&&aaa!=null){
                obj.SenderName = aaa[0].name;
            }
            obj.ReceiveID = id.split("_")[3];
            var aaa1 = eval('('+ XLY.Sqlite.Find(path,"select name from t_group where id = '"+obj.ReceiveID+"'") +')');
            //var aaa = eval('('+ XLY.Sqlite.Find(userPath,"select screenName from contacts where uerID = '"+data[i].uid+"'") +')');
            if(aaa1!=""&&aaa1!=null){
                obj.ReceiveName = aaa1[0].name;
            }
            if(obj.SenderID==0){
                obj.SenderName = "系统提示";
            }
            obj.SendType = data[i].type;
            obj.Content = data[i].content;
            obj.IsRead = data[i].read_status;
            if(data[i].time!=0){
                obj.SendTime = XLY.Convert.LinuxToDateTime(data[i].time);
            }
            root.Items.push(obj);
        }
    }
}
function getChildNode(root,path,id){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from weibos") +')');
    if(data!=""&&data!=null){
        var homePageNode = new TreeNode();
        homePageNode.Text = "首页";
        homePageNode.Type = "HomePage";

        var atmeNode = new TreeNode();
        atmeNode.Text = "@我的微博";
        atmeNode.Type = "HomePage";
        
        var meweiboNode = new TreeNode();
        meweiboNode.Text = "我的微博";
        meweiboNode.Type = "HomePage";
        
        var obj1 = new News();
        obj1.List = homePageNode.Text;
        root.Items.push(obj1);
        for(var i in data){
            if(data[i].type=="at_status_kjweo_0"){
                var obj = new HomePage();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.ID = data[i].mblogid;
                obj.Nick = data[i].nick;
                obj.Uid = data[i].uid;
                obj.Protrait = data[i].portrait;
                obj.Content = data[i].content;
                obj.Rtnum = data[i].rtnum;
                obj.Commentnum = data[i].commentnum;
                obj.Pic = data[i].pic;
                obj.RtrootuSourceid = data[i].rtrootid;
                obj.Rtrootuid = data[i].rtrootuid;
                obj.RtrootNick = data[i].rtrootnick;
                obj.Rtreason = data[i].rtreason;
                obj.ContentSource = data[i].source;
                obj.Lon = data[i].longitude;
                obj.Lat = data[i].latitude;
                if(data[i].dateline!=0){
                    obj.DTime = XLY.Convert.LinuxToDateTime(data[i].dateline);
                }
                atmeNode.Items.push(obj);
            }
            else
            {
                var obj = new HomePage();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.ID = data[i].mblogid;
                obj.Nick = data[i].nick;
                obj.Uid = data[i].uid;
                obj.Protrait = data[i].portrait;
                obj.Content = data[i].content;
                obj.Rtnum = data[i].rtnum;
                obj.Commentnum = data[i].commentnum;
                obj.Pic = data[i].pic;
                obj.RtrootuSourceid = data[i].rtrootid;
                obj.Rtrootuid = data[i].rtrootuid;
                obj.RtrootNick = data[i].rtrootnick;
                obj.Rtreason = data[i].rtreason;
                obj.ContentSource = data[i].source;
                obj.Lon = data[i].longitude;
                obj.Lat = data[i].latitude;
                if(data[i].dateline!=0){
                    obj.DTime = XLY.Convert.LinuxToDateTime(data[i].dateline);
                }
                if(obj.Uid==id){
                    meweiboNode.Items.push(obj);
                }
                else
                {
                    homePageNode.Items.push(obj);
                }
                
            }
        }
        if(meweiboNode.Items!=""&&meweiboNode.Items!=null){
            root.TreeNodes.push(meweiboNode);
            var obj2 = new News();
            obj2.List = meweiboNode.Text;
            root.Items.push(obj2);
        }
        if(atmeNode.Items!=""&&atmeNode.Items!=null){
            root.TreeNodes.push(atmeNode);
            var obj3 = new News();
            obj3.List = atmeNode.Text;
            root.Items.push(obj3);
        }
        root.TreeNodes.push(homePageNode);
    }
    if(XLY.File.IsValid(searchPath)){
        var searchNode = new TreeNode();
        searchNode.Text = "搜索关键字";
        searchNode.Type = "SearchWord";
        var data1 = eval('('+ XLY.PList.ReadToJsonString(searchPath) +')');
        if(id==0){
            var aaaa = "WBAccountSearchHistory-1005270587517";
        }
        else
        {
            var aaaa = "WBAccountSearchHistory-"+id;
        }
        if(data1!=""&&data1!= null){
            for(var i in data1){
                if(data1[i][aaaa]!=""&&data1[i][aaaa]!= null){
                    var bbbbbbb = data1[i][aaaa];
                    var bbbbbbbb = bbbbbbb[0].WBAccountSearchHistoryTypeSquare[0];
                    for(var bbbbb in bbbbbbbb){
                        var obj111 = new SearchWord();
                        //obj111.DataState = XLY.Convert.ToDataState(bbbbbbbb[bbbbb].XLY_DataType);;
                        obj111.Key = bbbbbbbb[bbbbb];
                        searchNode.Items.push(obj111);
                    }
                    root.TreeNodes.push(searchNode);
                }
            }
        }
    }
    if(XLY.File.IsValid(path)){
        var searchPageNode = new TreeNode();
        searchPageNode.Text = "推荐";
        searchPageNode.Type = "PageInfo";
        var pageinfo = eval('('+ XLY.Sqlite.Find(path,"select * from timeline_pageinfos") +')');
        if(pageinfo!=""&&pageinfo!= null){
            for(var a in pageinfo){
                var obj9 = new PageInfo();
                obj9.DataState = XLY.Convert.ToDataState(pageinfo[a].XLY_DataType);;
                obj9.PageID = pageinfo[a].pageID;
                obj9.PageTitle = pageinfo[a].pageTitle;
                obj9.PageURL = pageinfo[a].pageURL;
                obj9.PageImageURL = pageinfo[a].pageImageURL;
                //log(pageinfo[a].cards);
                if(pageinfo[a].contents!=""&&pageinfo[a].contents!=null&&pageinfo[a].contents!="[]"){
                    obj9.PageContent = pageinfo[a].contents;
                }
                else if(pageinfo[a].cards!=""&&pageinfo[a].cards!=null)
                {
                    var ee = eval('('+ pageinfo[a].cards +')');
                    for(var e in ee){
                        if(ee[e]!=""&&ee[e]!= null){
                            obj9.PageContent = "标题："+ee[e].page_title+"\r"+"链接："+ee[e].page_url+"\r"+"内容："+ee[e].content2+"\r"+ee[e].content1;
                        }
                    }
                }
                else
                {
                    //var ee = eval('('+ pageinfo[a].extra_properties +')');
                    obj9.PageContent = pageinfo[a].extra_properties;
                    //obj9.PageContent = "标题："+ee.buttons[0].name+"\r"+"链接："+ee.buttons[0].pic;
                }
                if(pageinfo[a].lastUpdateTime!= 0){
                    obj9.DTime = XLY.Convert.LinuxToDateTime(pageinfo[a].lastUpdateTime);
                }
                else
                {
                    obj9.DTime = null;
                }
                searchPageNode.Items.push(obj9);
            }
            root.TreeNodes.push(searchPageNode);
        }
    }
}