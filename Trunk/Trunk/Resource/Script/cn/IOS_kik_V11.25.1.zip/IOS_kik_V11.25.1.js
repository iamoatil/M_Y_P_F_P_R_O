﻿//本程序是针对三星的特别版
/*[config]
<plugin name="kik" group="社交聊天,17" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/KIK.png" app="AppDomainGroup-group.com.kik.chat" version="11.25.1" description="kik" data="$data,ComplexTreeDataSource" >
<source>
    <value>AppDomainGroup-group.com.kik.chat</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="电子邮件" code="mail" type="string" width="200" format=""></item>
    <item name="用户昵称" code="UserNickname" type="string" width="200" format=""></item>
    <item name="姓名" code="Name" type="string" width="200" format = ""></item>
</data>
<data type="Msg" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="消息内容" code="MsgInfo" type="string" width="200" format = ""></item>
    <item name="发送时间" code="SendTime" type="string" width="200" format = ""></item>
    <item name="发送者ID" code="SenderId" type="string" width="200" format = ""></item>
    <item name="发送者昵称" code="SenderNickname" type="string" width="200" format = ""></item>
    <item name="发送者姓名" code="SenderName" type="string" width="200" format = ""></item>
</data>
</plugin>
[config]*/

function News() {
    this.DataState = "Normal";  //数据状态
    this.List = ""; //列表
    this.MDFString = "";    //MD5
}
function UserInfo() {
    this.DataState = "Normal";  //数据状态
    this.mail = "";   //电子邮件
    this.UserNickname = ""; //用户昵称
    this.Name = ""; //姓名
    this.MDFString = "";    //MD5
}
function Msg() {
    this.DataState = "Normal";  //数据状态
    this.MsgInfo = "";  //消息内容
    this.SendTime = ""; //发送时间
    this.SenderId = ""; //发送者ID
    this.SenderNickname = "";   //发送者昵称
    this.SenderName = "";   //发送者姓名
    this.MDFString = "";    //MD5
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
}
var result = new Array();
//配置文件路径全局共用

//*************************************程序入口****************************************
//源数据
var source = $source;
var Path1= source[0] + "\\AppDomainGroup-group.com.kik.chat\\Library\\Preferences\\group.com.kik.chat.plist";
var charactor = "\\chalib\\IOS_KIK_11.25.1\\kik.sqlite1.charactor";
var pathnumber = Getpathnumber();
var Pathold = source[0] +"\\AppDomainGroup-group.com.kik.chat\\cores\\private\\"  + pathnumber + "\\kik.sqlite";
var Path2 = XLY.Sqlite.DataRecovery(Pathold,charactor,"Z_4MESSAGES,ZKIKCHAT,ZKIKMESSAGE,ZKIKUSER");
//测试数据
//var Path1 = "E:\\xlyspf\\任务-2017-08-17-14-22-02\\AppDomainGroup-group.com.kik.chat\\Library\\Preferences\\group.com.kik.chat.plist";
//var Pathold = "E:\\xlyspf\\任务-2017-08-17-14-22-02\\AppDomainGroup-group.com.kik.chat\\cores\\private\\416d212490fb4182b2e65a5bef68a593\\kik.sqlite";
//var charactor = "F:\\李锦祥个人文件\\脚本学习\\SPF20170328\\21-Build\chalib\\IOS_KIK_11.25.1\\kik.sqlite1.charactor";
//var Path2 = XLY.Sqlite.DataRecovery(Pathold,charactor,"Z_4MESSAGES,ZKIKCHAT,ZKIKMESSAGE,ZKIKUSER");
BuildNode();
var res = JSON.stringify(result);
res;
//*************************************程序结束****************************************
//++++++++++++++++++++++++++++++++++自定义函数部分++++++++++++++++++++++++++++++++++++++
//自定义数据库读取函数  
//自定义数据库读取函数  
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}
//主函数
function BuildNode(){
 //**********************************根节点建立**************************************  
    var RootNode = new TreeNode();
    RootNode.Text = "KIK";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(RootNode);
    result.push(RootNode);
}
function GetRootInfo(Node){
    var temp = ["用户信息","消息"];
    var temp1 = new Array();
    for(var i in temp){
        var InfoList = new News();
        InfoList.List = temp[i];
        temp1.push(InfoList);
    }
    //获得用户信息
    var UserInfoNode = new TreeNode();
    UserInfoNode.Text = temp[0];
    UserInfoNode.Type = "UserInfo";
    UserInfoNode.Items = GetUserInfo();
    Node.TreeNodes.push(UserInfoNode);
    //获取消息
    var MsgNode = new TreeNode();
    MsgNode.Text = temp[1];
    MsgNode.Type = "News";
    MsgNode.Items = GetMsg(MsgNode);
    Node.TreeNodes.push(MsgNode);
    //返回列表
    return temp1;
}
//数据库路路径获取函数
function Getpathnumber(){
    var temp1 = "";
    if(XLY.File.IsValid(Path1)){
        var temp3 = eval('('+ XLY.PList.ReadToJsonString(Path1) +')');
        for(var i in temp3){
            for(var key in temp3[i]){
                if(key == "kik.cores"){
                    temp1 = temp3[i][key][0][0];
                }
            }
        }
    }
    return temp1;
}
//用户信息获取函数
function GetUserInfo(){
    var temp1 = new Array();
    var temp2 = new UserInfo();
    var temp4 = "";
    var temp5 = "";
    if(XLY.File.IsValid(Path1)){
        var temp3 = eval('('+ XLY.PList.ReadToJsonString(Path1) +')');
        for(var i in temp3){
            for(var key in temp3[i]){
                if(key.split(":").length > 1){
                    switch(key.split(":")[1]){
                        case "email": temp2.mail = temp3[i][key];
                        break;
                        case "username":temp2.UserNickname = temp3[i][key];
                        break;
                    }
                    if(key.split(":")[1] == "firstName"){
                        temp4 = temp3[i][key];
                    }
                    if(key.split(":")[1] == "lastName"){
                        temp5 = temp3[i][key];
                    }
                    temp2.Name = temp4+temp5;
                } 
            }
        }
        
    }
    temp1.push(temp2)
    return temp1;
}
//消息获取函数
function GetMsg(MsgNode){
    var temp1 = new Array();
    var ChatNumber = ExecSql(Path2,"select DISTINCT Z_4CHAT,XLY_DataType from Z_4MESSAGES");
    for(var i in ChatNumber){
        var  temp2 = new News();
        
        var NewNode = new TreeNode();
        NewNode.Text = GetTalkTopic(ChatNumber[i].Z_4CHAT);
        NewNode.Type = "Msg";
        NewNode.Items = GetMsgInfo(ChatNumber[i].Z_4CHAT);
        MsgNode.TreeNodes.push(NewNode);
        temp2.DataState = XLY.Convert.ToDataState(ChatNumber[i].XLY_DataType);
        temp2.List = NewNode.Text;
        temp1.push(temp2);
    }
    return temp1;
}
function GetTalkTopic(ChatId){
    var temp1 = ExecSql(Path2,"select  ZUSER from ZKIKCHAT where Z_PK = "+ChatId);
    
    if(temp1 != null && temp1.length != 0){
        var temp2 = ExecSql(Path2,"select  ZDISPLAYNAME from ZKIKUSER where Z_PK = "+temp1[0].ZUSER);
        return temp2[0].ZDISPLAYNAME;
    }
    else{
        var temp2 = "未找到对话标题";
        return temp2;
    }
}
function GetMsgInfo(ChatId){
    var temp1 = new Array();
    var Info = ExecSql(Path2,"select  Z_6MESSAGES from Z_4MESSAGES where Z_4CHAT = "+ChatId);
    if(Info != null && Info.length != 0){
        for(var i in Info){
            var Info2 = ExecSql(Path2,"select  ZBODY,cast(ZRECEIVEDTIMESTAMP as text) as MSTIME,ZUSER,ZINTERNALID,XLY_DataType from ZKIKMESSAGE where Z_PK = "+Info[i].Z_6MESSAGES);
            var Info3 = "";
            if(Info2 != null && Info2.length != 0){
                if(Info2[0].ZINTERNALID == 0){ 
                    Info3 = ExecSql(Path2,"select  ZDISPLAYNAME,ZJID,ZUSERNAME from ZKIKUSER where Z_PK = "+Info2[0].ZUSER);
                }
                else{
                    Info3 = ExecSql(Path2,"select  ZDISPLAYNAME,ZJID,ZUSERNAME from ZKIKUSER where Z_PK = 1");
                }
                var temp2 = new Msg();
                temp2.MsgInfo = Info2[0].ZBODY;
                var MyTime = XLY.Convert.LinuxToDateTime(Info2[0].MSTIME).split("-");
                temp2.SendTime = parseInt(MyTime[0])+31+"-"+MyTime[1]+"-"+MyTime[2];
                temp2.SenderId = Info3[0].ZJID;
                temp2.SenderNickname = Info3[0].ZUSERNAME;
                temp2.SenderName = Info3[0].ZDISPLAYNAME;
                temp2.DataState = XLY.Convert.ToDataState(Info2[0].XLY_DataType);
            }
            
            temp1.push(temp2);
        }
    }
    
    return temp1;
}