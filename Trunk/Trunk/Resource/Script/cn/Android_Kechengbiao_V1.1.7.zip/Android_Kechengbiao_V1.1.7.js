﻿/*[config]
<plugin name="超级课程表" group="社交聊天,8" devicetype="android" icon="\icons\Syllabus.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.xtuone.android.syllabus" version="7.1.1" description="Syllabus" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.xtuone.android.syllabus/shared_prefs/userInfo.xml</value>
    <value>/data/data/com.xtuone.android.syllabus/databases/chat_module.db</value>  
    <value>/data/data/com.xtuone.android.syllabus/databases/countdown.db</value>
    <value>/data/data/com.xtuone.android.syllabus/databases/friday.db</value>
    <value>/data/data/com.xtuone.android.syllabus/databases/notes.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Account" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="学校" code="School" type="string" width = "150"></item>
    <item name="寝室" code="Dorm" type="string" width = "200"></item>
    <item name="账号密码" code="Code" type="string" width = "150"></item>
    <item name="近期动向" code="Status" type="string" width = "150"></item>
    <item name="微信账号" code="Wechat" type="string" width = "150"></item>
    <item name="人人网账号" code="Renren" type="string" width = "150"></item>
    <item name="微博账号" code="Webo" type="string" width = "150"></item>
    <item name="学校ID" code="Id" type="string" width = "200"></item>
    <item name="专业" code="Organization" type="string" width = "150"></item>
    <item name="昵称" code="NickName" type="string" width = "150"></item>
    <item name="头像" code="Icon" type="string" format="EnumDataState" width="60"></item>
    <item name="所在学院" code="Academy" type="string" width = "150"></item>
    <item name="性别" code="Gender" type="string" width = "200"></item>
    <item name="年级" code="Grade" type="string" width = "150"></item>
    <item name="用户ID" code="UserId" type="string" width = "150"></item>
    <item name="会员等级" code="Rate" type="string" width = "150"></item>
    <item name="账号等级" code="ARate" type="string" width = "150"></item>
    <item name="高中ID" code="HighschoolId" type="string" width = "150"></item>
    <item name="学院ID" code="AcademyId" type="string" width = "150"></item>
    <item name="最后登录时间" code="Time" type="string" width = "200"></item>
    <item name="出生城市" code="BornCity" type="string" width = "150"></item>
    <item name="签名" code="Signature" type="string" width = "150"></item>
    <item name="树洞主题数" code="Count" type="string" width = "150"></item>
    <item name="恋爱状态" code="LoveState" type="string" width = "150"></item>
    <item name="登录状态" code="Login" type="string" width = "150"></item>
    <item name="家乡" code="Hometown" type="string" width = "150"></item>
    <item name="所在省份" code="BornProvince" type="string" width = "150"></item>
    <item name="所在省份ID" code="ProvinceId" type="string" width = "200"></item>
    <item name="出生日期" code="BornDate" type="string" width = "150"></item>
    <item name="爱好" code="Hobby" type="string" width = "150"></item>
    <item name="手机号码" code="Mobile" type="string" width = "150"></item>
    <item name="所在城市ID" code="BornCityID" type="string" width = "150"></item>
    <item name="高中" code="HighSchool" type="string" width = "200"></item>
    <item name="真实姓名" code="RealName" type="string" width = "150"></item>
    <item name="添加时间" code="AddTime" type="string" width = "150"></item>
    </data>
    <data type="Blacklist" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="学生ID" code="Id" type="string" width = "150"></item>
    <item name="头像" code="Icon" type="string" width = "200"></item>
    <item name="昵称" code="NickName" type="string"  width = "200"></item>
    <item name="姓名拼音" code="Pinyin" type="string"  width = "200"></item>
    <item name="聊天ID" code="CId" type="string" width = "200"></item>
    <item name="会员等级" code="VIPLevel" type="string"  width = "200"></item>
    <item name="性别" code="Gender" type="string"  width = "200"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Contact" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="学生ID" code="Id" type="string" width = "150"></item> 
    <item name="是否会员" code="VIP" type="string" width = "150"></item>
    <item name="头像" code="Icon" type="string" width = "200"></item>
    <item name="昵称" code="NickName" type="string"  width = "200"></item>
    <item name="聊天ID" code="CId" type="string" width = "200"></item>
    <item name="最后聊天内容" code="Chat" type="string" width = "200"></item>
    <item name="最后聊天时间" code="Ctime" type="string" width = "200"></item>
    <item name="是否朋友" code="Friend" type="string" width = "200"></item>
    </data>
    <data type="Message" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="学生ID" code="Id" type="string" width = "150"></item> 
    <item name="发送人" code="Sender" type="string" width = "150"></item>
    <item name="接收人" code="Receiver" type="string" width = "150"></item>
    <item name="内容" code="Content" type="string"  width = "150"></item>
    <item name="聊天时间" code="Time" type="string" width = "200"></item>
    <item name="接收时间" code="RTime" type="string" width = "200"></item>
    <item name="是否成功" code="Success" type="string" width = "200"></item>
    <item name="消息类型" code="Type" type="string"  width = "150"></item>
    </data>
    <data type="Countdown" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="类型" code="Type" type="string" width = "150"></item>
    <item name="标签" code="Lable" type="string" width = "200"></item>
    <item name="考试地点" code="Location" type="string"  width = "200"></item>
    <item name="考试内容" code="Content" type="string"  width = "200"></item>
    <item name="考试时间" code="Time" type="string"  width = "200"></item>
    <item name="是否提醒" code="Remind" type="string"  width = "200"></item>
    <item name="学生ID" code="SId" type="string"  width = "200"></item>
    <item name="提醒时间" code="RTime" type="string"  width = "200"></item>
    </data>
    <data type="Course" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
    <item name="开始学年" code="Start" type="string" width = "150"></item>
    <item name="结束学年" code="End" type="string" width = "150"></item>
    <item name="学期" code="Semester" type="string" width = "150"></item>
    <item name="课程数" code="Num" type="string" width = "150"></item>
    <item name="课程ID" code="CourseId" type="string" width = "150"></item>
    <item name="周几有课" code="Day" type="string" width = "150"></item>
    <item name="开始节数" code="SSection" type="string" width = "150"></item>
    <item name="结束节数" code="ESection" type="string" width = "150"></item>
    <item name="课程名" code="Name" type="string" width = "150"></item>
    <item name="老师" code="Teacher" type="string" width = "150"></item>
    <item name="教室" code="Classroom" type="string" width = "150"></item>
    <item name="开始时间" code="STime" type="string" width = "150"></item>
    <item name="结束时间" code="ETime" type="string" width = "150"></item>
    <item name="是否提醒" code="Remind" type="string" width = "150"></item>
    <item name="周数" code="Week" type="string" width = "150"></item>
    </data>
    <data type="TestNote" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="标签" code="Lable" type="string" width = "150"></item>
    <item name="内容" code="Content" type="string"  width = "150"></item>
    <item name="创建时间" code="CTime" type="string" width = "200"></item>
    <item name="学生ID" code="ID" type="string"  width = "150"></item>
    <item name="服务器ID" code="SId" type="string"  width = "150"></item>
    <item name="修改时间" code="MTime" type="string" width = "200"></item>
    <item name="图片网上路径" code="Image" type="string"  width = "150"></item>
    <item name="图片本地路径" code="Pic" type="string"  width = "150"></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account(){
    this.DataState = "Normal";
    this.School = "";
    this.Dorm = "";
    this.Code = "";
    this.Status = "";
    this.Wechat = "";
    this.Renren = "";
    this.Webo = "";
    this.Id = "";
    this.Organization = "";  
    this.NickName = "";
    this.Icon = "";
    this.Academy = "";
    this.Gender = "";
    this.Grade = "";
    this.UserId = "";  
    this.Rate = "";
    this.HighschoolId = "";
    this.Time = "";
    this.BornCity = "";
    this.Signature = "";
    this.LoveState = "";
    this.ARate = "";
    this.Term = "";
    this.Count = "";   
    this.Login = "";
    this.Hometown = "";
    this.BornProvince = "";
    this.ProvinceId = "";
    this.BornDate = "";
    this.Hobby = "";
    this.AcademyId = "";  
    this.Mobile = "";
    this.BornCityID = "";
    this.HighSchool = "";
    this.RealName = "";
    this.AddTime = "";  
}
function Blacklist(){
    this.DataState = "Normal";
    this.Id = "";
    this.Icon = "";
    this.NickName = "";
    this.Pinyin = "";
    this.CId = "";
    this.VIPLevel = "";
    this.Gender = "";
    this.Time = "";
}
function Contact(){
    this.DataState = "Normal";
    this.Id = "";
    this.VIP = "";
    this.Icon = "";
    this.NickName = "";
    this.CId = "";
    this.Chat = "";
    this.Ctime = "";
    this.Friend = "";
}
function Message(){
    this.DataState = "Normal";
    this.Id = "";
    this.Sender = "";
    this.Receiver = "";
    this.Content = "";
    this.Time = "";
    this.RTime = "";    
    this.Success = "";
    this.Type = "";
}
function Countdown(){
    this.DataState = "Normal";
    this.Type = "";
    this.Lable = "";
    this.Location = "";
    this.Content = "";
    this.Time = "";
    this.Remind = "";    
    this.SId = "";
    this.RTime = "";
}
function Course(){
    this.DataState = "Normal";
    this.Start = "";
    this.End = "";
    this.Semester = "";
    this.Num = "";
    this.CourseId = "";
    this.Day = "";
    this.SSection = "";    
    this.ESection = "";   
    this.Name = "";
    this.Teacher = "";
    this.Classroom = "";
    this.STime = "";
    this.ETime = "";
    this.Remind = "";
    this.Week = "";  
}
function TestNote(){
    this.DataState = "Normal";
    this.Lable = "";
    this.Content = "";
    this.CTime = "";
    this.MTime = "";
    this.ID = "";
    this.SId = "";    
    this.Image = "";
     this.Pic = "";
}

//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "超级课程表";
    news.Type = "Account"; 
    accountinfo = getAccount(db1);
    news.Items = accountinfo;
    news.DataState = "Normal";
     
    for(var i in accountinfo){
    var account = new TreeNode() ;
    account.Text = accountinfo[i].RealName;
    account.Type = "Account"; 
    account.Items = getAccount(db1,accountinfo[i],accountinfo) ;
    news.TreeNodes.push(account)
    }

    var course = new TreeNode() ;
    course.Text = "课程表";
    course.Type = "Course"; 
    course.Items = getCourse(db8) ;
    account.TreeNodes.push(course);
      
    var cuont = new TreeNode() ;
    cuont.Text = "考试提醒";
    cuont.Type = "Countdown"; 
    cuont.Items = getCountdown(db7) ;
    account.TreeNodes.push(cuont);
    
    var note = new TreeNode() ;
    note.Text = "便签";
    note.Type = "TestNote"; 
    note.Items = getNote(db9) ;
    account.TreeNodes.push(note);

    var contact = new TreeNode() ;
    contact.Text = "联系人";
    contact.Type = "Contact"; 
    contactinfo = getContact(db6);
    contact.Items = contactinfo;
    account.TreeNodes.push(contact);
           
    for(var i in contactinfo){  
    var message = new TreeNode();
    message.Text = contactinfo[i].NickName;
    message.Type = "Message";
    message.Items = getMessage(db6,contactinfo[i],accountinfo);
    message.DataState = "Normal";    
    contact.TreeNodes.push(message);
    } 
    
    var blacklist = new TreeNode() ;
    blacklist.Text = "黑名单";
    blacklist.Type = "Blacklist"; 
    blacklist.Items = getBlacklist(db6) ;
    account.TreeNodes.push(blacklist);
    
   result.push(news);
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var obj = new Account();
    var info = data.map.string;
    var info2 = data.map.int;
    for(var i in info ){
        if(info[i]["@name"] == "school_name"){
            obj.School = info[i]["#text"];            
        }
        if(info[i]["@name"] == "DORM_ROOM"){
            obj.Dorm = info[i]["#text"];           
        }
        if(info[i]["@name"] == "password"){
            obj.Code = info[i]["#text"];   
        }
        if(info[i]["@name"] == "NOW_STATUS"){
            obj.Status = info[i]["#text"];    
        }
        if(info[i]["@name"] == "we_chat"){
            obj.Wechat = info[i]["#text"];    
        }
        if(info[i]["@name"] == "identity"){
            obj.Renren = info[i]["#text"];          
        }
        if(info[i]["@name"] == "weiboToken"){
            obj.Webo = info[i]["#text"];     
        }
        if(info[i]["@name"] == "ORGANIZATION"){
            obj.Organization = info[i]["#text"];          
        }
        if(info[i]["@name"] == "nickName"){
            obj.NickName = info[i]["#text"];            
        }
        if(info[i]["@name"] == "avatarUrl"){
            obj.Icon = info[i]["#text"];            
        }
        if(info[i]["@name"] == "academyName"){
            obj.Academy = info[i]["#text"];           
        }
        if(info[i]["@name"] == "studentId"){
            obj.UserId = info[i]["#text"];           
        }
        if(info[i]["@name"] == "BORN_CITY"){
            obj.BornCity = info[i]["#text"];            
        }
        if(info[i]["@name"] == "signature"){
            obj.Signature = info[i]["#text"];            
        }
        if(info[i]["@name"] == "hometown"){
            obj.Hometown = info[i]["#text"];            
        }
        if(info[i]["@name"] == "BORN_PROVINCE"){
            obj.BornProvince = info[i]["#text"];          
        }      
        if(info[i]["@name"] == "hobby"){
            obj.Hobby = info[i]["#text"];  
        }
        if(info[i]["@name"] == "mobile_number"){
            obj.Mobile = info[i]["#text"];            
        }
        if(info[i]["@name"] == "HIGH_SCHOOL"){
            obj.HighSchool = info[i]["#text"];            
        }
        if(info[i]["@name"] == "realName"){
            obj.RealName = info[i]["#text"];   
        } 
 }
    var info1 = data.map.long;
     for(var i in info1){
        if(info1[i]["@name"] == "addTime"){
            obj.AddTime =XLY.Convert.LinuxToDateTime(info1[i]["@value"]);               
        }
        if(info1[i]["@name"] == "date_of_birth"){
            obj.BornDate =XLY.Convert.LinuxToDateTime(info1[i]["@value"]);
        }
        if(info1[i]["@name"] == "lastLoginTime"){
             obj.Time =XLY.Convert.LinuxToDateTime(info1[i]["@value"]);          
        }
}
    var info3 = data.map.boolean;
     for(var i in info3){
        if(info3[i]["@name"] == "isLogin"){ obj.Login
          obj.Login = info3[i]["@value"];  
         }
}
    var info2 = data.map.int;
     for(var i in info2){
       if(info2[i]["@name"] == "vip_level"){
         obj.Rate =info2[i]["@value"];  
     }
      if(info2[i]["@name"] == "gender"){
       var a = info2[i]["@value"];
            switch(a){
              case '0':
                obj.Gender = "未知";
                break;
              case '1':
                obj.Gender = "男性";
                break;
              case '2':
                obj.Gender = "女性";
                break;
            }
      }         
      if(info2[i]["@name"] == "loveState"){
        var b = info2[i]["@value"];
            switch(b){               
              case '0':
                obj.LoveState = "保密";
                break;
              case '1':
                obj.LoveState = "初恋还在";
                break;
              case '2':
                obj.LoveState = "单身";
                break;
              case '3':
                obj.LoveState = "关系很难解释";
                break;
              case '4':
                obj.LoveState = "刚交往";
                break;
              case '5':
                obj.LoveState = "热恋中";
                break;
              case '6':
                obj.LoveState = "刚分手";
                break;
            }
      }
      if(info2[i]["@name"] == "school_id"){
        obj.Id =info2[i]["@value"];  
      }
      if(info2[i]["@name"] == "HIGH_SCHOOL_ID"){
        obj.HighschoolId =info2[i]["@value"];  
      }
      if(info2[i]["@name"] == "user_id"){
        obj.UserId =info2[i]["@value"];  
     }
     if(info2[i]["@name"] == "hometown_city_id"){
        obj.BornCityID = info2[i]["@value"]; 
     }
     if(info2[i]["@name"] == "academy_id"){
        obj.AcademyId =info2[i]["@value"];  
     }
     if(info2[i]["@name"] == "treehole_topic_count"){
        obj.Count =info2[i]["@value"];  
     }
     if(info2[i]["@name"] == "rate_level"){
        obj.ARate = info2[i]["@value"];  
     }       
     if(info2[i]["@name"] == "term"){
        obj.Term =info2[i]["@value"];  
    }
     if(info2[i]["@name"] == "grade"){
        obj.Grade =info2[i]["@value"];  
    }
     if(info2[i]["@name"] == "BORN_PROVINCE_ID"){
        obj.ProvinceId =info2[i]["@value"];  
    }              
}
         list.push(obj);
    return list;
}
function getCourse(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from course" ) +')');    
    for(var i in data){
        var obj = new Course();
        obj.Start = data[i].schoolYearStart;
        obj.End = data[i].schoolYearEnd;
        obj.Semester = data[i].semester;
        obj.Num = data[i].maxCourse;
        obj.CourseId = data[i].course_id;
        obj.Day = data[i].day_of_week;
        obj.SSection = data[i].courseStartSection;
        obj.ESection = data[i].courseEndSection;
        obj.Name = data[i].courseName;
        obj.Teacher = data[i].teacher;
        obj.Classroom = data[i].classroom;
        obj.Week = data[i].week;
        obj.STime = data[i].startTime;
        obj.ETime = data[i].endTime;
        obj.Remind = (data[i].isRemind == 1) ? "已提醒" : "未提醒";
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCountdown(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select cast(countdown_time as double)as time, cast(remind_time as double)as time1,* from t_countdown" ) +')');
    for(var i in data){
        var obj = new Countdown();
        obj.Type = data[i].type;
        obj.Lable = data[i].label;
        obj.Location = data[i].location;
        obj.Content = data[i].content;
        obj.Remind =  (data[i].isRemind == 1) ? "已提醒" : "未提醒";
        obj.SId = data[i].student_id;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.RTime = XLY.Convert.LinuxToDateTime(data[i].time1);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getNote(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from t_note" ) +')');
    for(var i in data){
        var obj = new TestNote();
        obj.Lable = data[i].label;
        obj.Content = data[i].content;
        obj.ID = data[i].student_id;
        obj.SId = data[i].server_id;
        var a = eval('('+ data[i].images_json +')');
        if(a.length != 0){
           obj.Image = a[0].serverUrl;
           obj.Pic = a[0]. localUrl;        
        }    
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.MTime = XLY.Convert.LinuxToDateTime(data[i].modify_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBlacklist(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select cast(date_time as double)as time, * from blacklist" ) +')');
    for(var i in data){
        var obj = new Blacklist();
        obj.Id = data[i].student_id;
        obj.Icon = data[i].avatar_url;
        obj.NickName = data[i].nickname;
        obj.Pinyin = data[i].pinyin;
        obj.CId = data[i].chat_id;
        obj.VIPLevel = data[i].vip_level;
         var a = data[i].gender;
            switch(a){
              case 0:
                obj.Gender = "未知";
                break;
              case 1:
                obj.Gender = "男性";
                break;
              case 2:
                obj.Gender = "女性";
            }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getContact(path,contactinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select cast(lastest_content_time as double)as time,* from contacts" ) +')');
    for(var i in data){
        var obj = new Contact();
        obj.Id = data[i].contacts_student_id;
        obj.VIP =  (data[i].IS_VIP == 1) ? "是" : "否";
        obj.Icon = data[i].avatar_url;
        obj.NickName = data[i].nickname;
        obj.CId = data[i].chat_id;
        obj.Chat = data[i].lastest_content;
        obj.Friend =  (data[i].is_friend == 1) ? "是" : "否";
        obj.Ctime = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getMessage(path,contactinfo,accountinfo){
    var list = new Array(); 
    var data = eval('('+ XLY.Sqlite.Find(path,"select cast(chat_time as double)as time,cast(chat_recv_time as double)as time1,* from message where send_student_id = '"+contactinfo.Id+"' or recv_student_id ='"+contactinfo.Id+"'") +')');    
    for(var i in data){
        var obj = new Message();
        obj.Id = data[i].student_id;
        if(data[i].student_id ==data[i].recv_student_id){
           obj.Sender = contactinfo.NickName;
           obj.Receiver = accountinfo[0].NickName;
        }
       else
           {  
            obj.Sender = accountinfo[0].NickName;
           obj.Receiver = contactinfo.NickName;
           }
        obj.Content = data[i].chat_content;
         var a = data[i].message_type;
            switch(a){
              case 0:
                obj.Type = "文本";
                break;
              case 2:
                obj.Type = "图片";
                break;
            }
        obj.Success =  (data[i].is_success == 1) ? "是" : "否";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.RTime = XLY.Convert.LinuxToDateTime(data[i].time1);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }   
    return list;
}
//********************************************************
var source = $source;
var db1 = source[0];
var db2 = source[1];
var db3 = source[2];
var db4 = source[3];
var db5 = source[4];

var charactor = "\\chalib\\Android_Kechengbiao_V1.1.7\\chat_module.db.charactor";
var charactor1 = "\\chalib\\Android_Kechengbiao_V1.1.7\\countdown.db.charactor";
var charactor2 = "\\chalib\\Android_Kechengbiao_V1.1.7\\friday.db.charactor";
var charactor3 = "\\chalib\\Android_Kechengbiao_V1.1.7\\notes.db.charactor";

var db6 = XLY.Sqlite.DataRecovery(db2,charactor,"blacklist,contacts,message");
var db7 = XLY.Sqlite.DataRecovery(db3,charactor1,"t_countdown");
var db8 = XLY.Sqlite.DataRecovery(db4,charactor2,"course");
var db9 = XLY.Sqlite.DataRecovery(db5,charactor3,"t_note");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
