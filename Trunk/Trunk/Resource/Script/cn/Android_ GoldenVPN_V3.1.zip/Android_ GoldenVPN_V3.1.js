﻿/*[config]
<plugin name="自由门,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/goldenvpn.png" app="com.golden.freegate" version="3.1" description="自由门" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.golden.freegate/shared_prefs/admob.xml</value>
    <value>/data/data/com.golden.freegate/shared_prefs/com.google.android.gms.measurement.prefs.xml</value>
    <value>/data/data/com.golden.freegate/files/charon.log</value>
    <value>/data/data/com.golden.freegate/databases/google_app_measurement.db</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="是否使用http" code="UseHttps" type="string" width = "100"></item>
    <item name="请求会话计数" code="RequestInSessionCount" type="string" width = "100"></item>
    <item name="是否自动定位" code="AutoCollectLocation" type="string" width = "80"></item>
    <item name="是否使用服务" code="UseService" type="string" width = "80"></item>
    <item name="最后暂停时间" code="LastPauseTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后上传时间" code="LastUploadTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="设备型号" code="DeviceInfo" type="string" width = "120"></item>
</data>
<data type="LogInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="时间" code="LogTime" type="string" width = "100"></item>
    <item name="操作" code="LogAction" type="string" width = "450"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UseHttps = "否";
    this.RequestInSessionCount = "";
    this.AutoCollectLocation = "否";
    this.UseService = "否";
    this.LastPauseTime = null;
    this.LastUploadTime = null;
    this.DeviceInfo = "";
}
function LogInfo(){
    this.DataState = "Normal";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var admobPath = source[0];
var meaPath = source[1];
var logPath = source[2];
var dbPath = source[3];

//测试数据
//var admobPath = "D:\\temp\\data\\data\\com.golden.freegate\\shared_prefs\\admob.xml";
//var meaPath = "D:\\temp\\data\\data\\com.golden.freegate\\shared_prefs\\com.google.android.gms.measurement.prefs.xml";
//var logPath = "D:\\temp\\data\\data\\com.golden.freegate\\files\\charon.log";
//var dbPath = "D:\\temp\\data\\data\\com.golden.freegate\\databases\\google_app_measurement.db";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "自由门";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Text = "自由门VPN信息";
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    if(XLY.File.IsValid(admobPath)){
        var admData = eval('('+ XLY.File.ReadXML(admobPath) +')');
        if(admData!=""&&admData!=null){
            if(admData.map!=""&&admData.map!=""){
                var admIntData = admData.map.int;
                var admBoolData = admData.map.boolean;
                if(admIntData!=""&&admIntData!=null){
                    if(admIntData["@value"]!=""&&admIntData["@value"]!=null){
                        obj.RequestInSessionCount = admIntData["@value"];
                    }
                }
                if(admBoolData!=""&&admBoolData!=null){
                    for(var a in admBoolData){
                        if(admBoolData[a]["@name"]=="use_https"){
                            if(admBoolData[a]["@value"]=="true"){
                                obj.UseHttps = "是";
                            }
                        }
                        if(admBoolData[a]["@name"]=="auto_collect_location"){
                            if(admBoolData[a]["@value"]=="true"){
                                obj.AutoCollectLocation = "是";
                            }
                        }
                    }
                }
            }
        }
    }
    if(XLY.File.IsValid(meaPath)){
        var meaData = eval('('+ XLY.File.ReadXML(meaPath) +')');
        if(meaData!=""&&meaData!=null){
            if(meaData.map!=""&&meaData.map!=""){
                var meaLongData = meaData.map.long;
                var meaBoolData = meaData.map.boolean;
                if(meaLongData!=""&&meaLongData!=null){
                    for(var b in meaLongData){
                        if(meaLongData[b]["@name"]=="last_upload"){
                            obj.LastUploadTime = XLY.Convert.LinuxToDateTime(meaLongData[b]["@value"]);
                        }
                        if(admBoolData[a]["@name"]=="last_pause_time"){
                            obj.LastPauseTime = XLY.Convert.LinuxToDateTime(meaLongData[b]["@value"]);
                        }
                    }
                }
                if(meaBoolData!=""&&meaBoolData!=null){
                    for(var c in meaBoolData){
                        if(meaBoolData[c]["@name"]=="last_upload"){
                            if(meaBoolData[c]["@value"]=="true"){
                                obj.UseService = "是";
                            }
                        }
                    }
                }
            }
        }
    }
    if(XLY.File.IsValid(logPath)){
        getUserChildInfo(usernode,logPath);
    }
    if(XLY.File.IsValid(dbPath)){
        var deviceInfoData = eval('('+ XLY.Sqlite.Find(dbPath,"select metadata from raw_events_metadata") +')');
        if(deviceInfoData!=""&&deviceInfoData!=null){
            var dd = deviceInfoData[0].metadata;
            var ddd = XLY.Blob.ToBytes(dd,"base64");
            var pos = XLY.Blob.FindBytes(ddd,0,[0x52]);
            if(pos!=-1){
                var e = pos+1;
                var f = pos+2;
                var fur = XLY.Blob.GetBytes(ddd,f,ddd[e]);
                obj.DeviceInfo = XLY.Blob.ToString(fur);
            }
        }
    }
    
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}
function getUserChildInfo(root,path){
    var node = new TreeNode();
    node.Text = "日志";
    node.Type = "LogInfo";
    var data = XLY.File.ReadFile(path);
    if(data!=""&&data!= null){
        var aaa = data.split("\n");
        for(var i in aaa){
           if(aaa[i]!=""&&aaa!=null){
               var obj = new LogInfo();
               obj.LogTime = aaa[i].split("]")[0]+"]";
               obj.LogAction = aaa[i].split("]")[1];
               node.Items.push(obj);
           }
        }
        
    }
    if(node.Items!=""&&node.Items!=null){
        root.TreeNodes.push(node);
    }
}