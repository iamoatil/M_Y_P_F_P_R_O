﻿/*[config]
<plugin name="SuperVPN2,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/supervpnMusjoy.png" app="com.musjoy.pocketvpn" version="2.3" description="SuperVPN2" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.musjoy.pocketvpn/databases/strongswan.db</value>
    <value>/data/data/com.musjoy.pocketvpn/shared_prefs/file_service.xml</value>
    <value>/data/data/com.musjoy.pocketvpn/shared_prefs/promotion_cache.xml</value>
    <value>/data/data/com.musjoy.pocketvpn/shared_prefs/umeng_general_config.xml</value>
    <value>/data/data/com.musjoy.pocketvpn/files/umeng_it.cache</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="最后链接服务器名称" code="LastServerMarkName" type="string" width = "100"></item>
    <item name="最后链接服务器时间" code="LastServerMarkTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="设备MAC地址" code="DeviceMAC" type="string" width = "100"></item>
    <item name="设备序列号" code="DeviceXuLieHao" type="string" width = "120"></item>
    <item name="AndroidID" code="AndroidID" type="string" width = "80"></item>
    <item name="首次登陆时间" code="FirstActivityTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="成功请求次数" code="SuccessfulRequest" type="string" width = "80"></item>
    <item name="最后一个服务器请求耗时" code="LastRequestSpent" type="string" width = "120"></item>
    <item name="最后一个服务器请求时间" code="LastRequestTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.LastServerMarkName = "";
    this.LastServerMarkTime = null;
    this.DeviceMAC = "";
    this.DeviceXuLieHao = "";
    this.AndroidID = "";
    this.FirstActivityTime = null;
    this.SuccessfulRequest = "";
    this.LastRequestSpent = "";
    this.LastRequestTime = null;
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dbPath = source[0];
var xmlPathB = source[1];
var xmlPathC = source[2];
var xmlPathD = source[3];
var filePath = source[4];

//测试数据
//var dbPath = "D:\\temp\\data\\data\\com.musjoy.pocketvpn\\databases\\strongswan.db";
//var xmlPathB = "D:\\temp\\data\\data\\com.musjoy.pocketvpn\\shared_prefs\\file_service.xml";
//var xmlPathC = "D:\\temp\\data\\data\\com.musjoy.pocketvpn\\shared_prefs\\promotion_cache.xml";
//var xmlPathD = "D:\\temp\\data\\data\\com.musjoy.pocketvpn\\shared_prefs\\umeng_general_config.xml";
//var filePath = "D:\\temp\\data\\data\\com.musjoy.pocketvpn\\files\\umeng_it.cache";
//定义特征库文件
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "SuperVPN(musjoy)";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(dbPath)){
        var profileData = eval('('+ XLY.Sqlite.Find(dbPath,"select * from vpnprofile") +')');
        var usernode = new TreeNode();
        if(profileData!=""&&profileData!=null){
            usernode.Text = "请联系客服";
            usernode.Type = "";
        }
        else
        {
            usernode.Text = "免费用户";
            usernode.Type = "UserInfo";
            var obj = new UserInfo();
            
            if(XLY.File.IsValid(xmlPathD)){
                var xmlDataD = eval('('+ XLY.File.ReadXML(xmlPathD) +')');
                if(xmlDataD!=""&&xmlDataD!=null){
                    var aa = xmlDataD.map.long;
                    var bb = xmlDataD.map.int;
                    if(bb!=""&&bb!=null){
                        for(var b in bb){
                            if(bb[b]["@name"]=="successful_request"){
                                obj.SuccessfulRequest = bb[b]["@value"];
                            }
                            if(bb[b]["@name"]=="last_request_spent_ms"){
                                obj.LastRequestSpent = bb[b]["@value"]/1000+"秒";
                            }
                        }
                    }
                    if(aa!=""&&aa!=null){
                        for(var a in aa){
                            if(aa[a]["@name"]=="last_request_time"){
                                obj.LastRequestTime = XLY.Convert.LinuxToDateTime(aa[a]["@value"]);
                            }
                            if(aa[a]["@name"]=="first_activate_time"){
                                obj.FirstActivityTime = XLY.Convert.LinuxToDateTime(aa[a]["@value"]);
                            }
                        }
                    }
                }
            }
            if(XLY.File.IsValid(xmlPathB)){
                var xmlDataB = eval('('+ XLY.File.ReadXML(xmlPathB) +')');
                if(xmlDataB!=""&&xmlDataB!=null){
                    var bbb = xmlDataB.map.string;
                    if(bbb!=""&&bbb!=null){
                        if(bbb["#text"]!=""&&bbb["#text"]!=null){
                            obj.LastServerMarkName = bbb["#text"];
                        }
                    }
                }
            }
            if(XLY.File.IsValid(xmlPathC)){
                var xmlDataC = eval('('+ XLY.File.ReadXML(xmlPathC) +')');
                if(xmlDataC!=""&&xmlDataC!=null){
                    var ccc = xmlDataC.map.long;
                    if(ccc!=""&&ccc!=null){
                        if(ccc["@value"]!=""&&ccc["@value"]!=null){
                            obj.LastServerMarkTime = XLY.Convert.LinuxToDateTime(ccc["@value"]);
                        }
                    }
                }
            }
            if(XLY.File.IsValid(filePath)){
                var ff = getBinaryDeviceInfo(filePath);
                obj.DeviceMAC = ff.mac;
                obj.DeviceXuLieHao = ff.serial;
                obj.AndroidID = ff.android_id;
            }
            usernode.Items.push(obj);
            if(usernode.Items!=""&&usernode.Items!=null){
                root.TreeNodes.push(usernode);
            }
        }
    }
    
}
function getBinaryDeviceInfo(path){
    var handle = XLY.Blob.GetFileHandle(path);
    var aa = [0x73,0x65,0x72,0x69,0x61,0x6C];
    var bb = [0x61,0x6E,0x64,0x72,0x6F,0x69,0x64,0x5F,0x69,0x64];
    var cc = [0x6D,0x61,0x63];
    var a = XLY.Blob.FindBytesFromHandle(handle,0,aa);
    var b = XLY.Blob.FindBytesFromHandle(handle,0,bb);
    var c = XLY.Blob.FindBytesFromHandle(handle,0,cc);
    var arr = {};
    if(a!=-1){
        var aaa = XLY.Blob.GetBytesFromHandle(handle,a+8,XLY.Blob.GetBytesFromHandle(handle,a+7,1)[0]);
        arr.serial = XLY.Blob.ToString(aaa);
    }
    if(b!=-1){
        var bbb = XLY.Blob.GetBytesFromHandle(handle,b+0x0C,XLY.Blob.GetBytesFromHandle(handle,b+0x0B,1)[0]);
        arr.android_id = XLY.Blob.ToString(bbb);
    }
    if(c!=-1){
        var ccc = XLY.Blob.GetBytesFromHandle(handle,c+5,XLY.Blob.GetBytesFromHandle(handle,c+4,1)[0]);
        arr.mac = XLY.Blob.ToString(ccc);
    }
    XLY.Blob.CloseFileHandle(handle);
    return arr;
}