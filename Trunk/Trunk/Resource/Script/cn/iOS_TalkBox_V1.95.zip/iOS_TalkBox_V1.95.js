﻿/*[config]
<plugin name="TalkBox,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/talkbox.png" app="com.weihua.whuadev" version="1.95" description="TalkBox" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.gtomato.talkbox</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="100" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="100" format = "" ></item>
    <item name="用户ID" code="UID" type="string" width="100" format = "" ></item>
    <item name="FaceBookID" code="FaceBookID" type="string" width="100" format = "" ></item>
    <item name="是否当前登录" code="IsLoading" type="string" width="100" format = "" ></item>
    <item name="电话号码" code="MobileNumber" type="string" width="100" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="100" format = "" ></item>
    <item name="邮箱" code="Email" type="string" width="100" format = "" ></item>
    <item name="隐私设置" code="PrivacySetting" type="string" width="100" format = "" ></item>
    <item name="学校" code="School" type="string" width="100" format = "" ></item>
    <item name="个人签名" code="AboutMe" type="string" width="100" format = "" ></item>
    <item name="公司" code="Company" type="string" width="100" format = "" ></item>
    <item name="职业" code="JobTitle" type="string" width="100" format = "" ></item>
    <item name="地址" code="Location" type="string" width="100" format = "" ></item>
</data>
<data type="Contact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="NickName" type="string" width="100" format = "" ></item>
    <item name="用户名" code="UserName" type="string" width="100" format = "" ></item>
    <item name="真实名称" code="ActualName" type="string" width="100" format = "" ></item>
    <item name="TalkBoxID" code="UID" type="string" width="100" format = "" ></item>
    <item name="好友来源" code="FromWhere" type="string" width="100" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="100" format = "" ></item>
    <item name="最后信息发送时间" code="LastMessageDate" type="string" width="100" format = "" ></item>
</data>
<data type="GroupList" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="群组ID" code="GroupID" type="string" width = "100"></item>
    <item name="群组名称" code="GroupName" type="string" width = "100"></item>
</data>
<data type="GroupMember" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="TalkBoxID" code="TalkBoxID" type="string" width="100" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="100" format = "" ></item>
    <item name="用户名" code="UserName" type="string" width="100" format=""></item>
    <item name="头像" code="AvataUrl" type="url" width="100" format=""></item>
</data>
<data type="Message" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者ID" code="SenderID" type="string" width="100" format = "" ></item>
    <item name="发送者昵称" code="SenderName" type="string" width="100" format = "" ></item>
    <item name="接收者ID" code="ReceiveID" type="string" width="100" format=""></item>
    <item name="接收者昵称" code="ReceiveName" type="string" width="100" format=""></item>
    <item name="消息内容" code="Content" type="string" width="100" format=""></item>
    <item name="发送时间" code="SendTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    <item name="消息类型" code="ContentType" type="string" width="100" format = ""></item>
    <item name="经度" code="Long" type="string" width="100" format = ""></item>
    <item name="纬度" code="Lat" type="string" width="100" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function GroupMember(){
    this.DataState = "Normal";
    this.TalkBoxID = "";
    this.NickName = "";
    this.UserName = "";
    this.AvataUrl = "";
}
//定义GroupList数据结构
function GroupList(){
    this.DataState = "Normal";
    this.GroupID = "";
    this.GroupName = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.NickName = "";
    this.UID = "";
    this.FaceBookID = "";
    this.MobileNumber = "";
    this.HeadUrl = "";
    this.Email = "";
    this.PrivacySetting = "";
    this.School = "";
    this.AboutMe = "";
    this.Company = "";
    this.JobTitle = "";
    this.Location = "";
    this.IsLoading = "否";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.NickName = "";
    this.UserName = "";
    this.ActualName = "";
    this.UID = "";
    this.HeadUrl = "";
    this.LastMessageDate = "";
    this.FromWhere = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReceiveID = "";
    this.ReceiveName = "";
    this.Content = "";
    this.SendTime = null;
    this.ContentType = "";
    this.Long = "";
    this.Lat = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.gtomato.talkbox\\Documents";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-08-22-11-38-37\\source\\IosData\\2017-08-22-11-39-07\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.gtomato.talkbox\\Documents"
//定义特征库文件
var charactor = "\\chalib\\iOS_TalkBox_V1.95\\contact.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "TalkBox";
    news.Type = "";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var userPath = allPath+"\\UserInfo.user";
    var userid = "";
    if(XLY.File.IsValid(userPath)){
        var usertemp = eval('('+ XLY.PList.MacReadToJsonString(userPath) +')');
        if(usertemp!=""&&usertemp!= null){
            var userinfo = usertemp["$objects"];
            userid = userinfo[1].tbId;
        }
    }
    var reg = new RegExp("userHistory");
    var direcData = eval('('+ XLY.File.FindDirectories(allPath) +')');
    if(direcData!=""&&direcData!=null){
        for(var i in direcData){
            if(reg.test(direcData[i])){
                var userChildPath1 = direcData[i]+"\\contact.db";
                var userChildPath = XLY.Sqlite.DataRecovery(userChildPath1,charactor,"user,groupName,groupList,contactList");
                if(XLY.File.IsValid(userChildPath)){
                    var userChildData = eval('('+ XLY.Sqlite.Find(userChildPath,"select XLY_DataType,tbId,fbId,username,firstname,lastname,avatarUrl,city,phone,company,job_title,school,about_me,privacy_setting,email from user") +')');
                    if(userChildData!=""&&userChildData!=null){
                        var usernode = new TreeNode();
                        usernode.Text = userChildData[0].tbId+"_"+userChildData[0].username+"("+userChildData[0].firstname +" "+userChildData[0].lastname+")";
                        usernode.Type = "UserInfo";
                        for(var j in userChildData){
                            var obj = new UserInfo();
                            obj.DataState = XLY.Convert.ToDataState(userChildData[j].XLY_DataType);
                            obj.UserName = userChildData[j].username;
                            obj.NickName = userChildData[j].firstname +" "+userChildData[j].lastname;
                            obj.UID = userChildData[j].tbId;
                            obj.FaceBookID = userChildData[j].fbId;
                            obj.MobileNumber = userChildData[j].phone;
                            obj.HeadUrl = userChildData[j].avatarUrl;
                            obj.Email = userChildData[j].email;
                            if(userChildData[j].privacy_setting=="open"){
                                obj.PrivacySetting = "全部可见";
                            }
                            else
                            {
                                obj.PrivacySetting = "仅好友可见";
                            }
                            
                            obj.School = userChildData[j].school;
                            obj.AboutMe = userChildData[j].about_me;
                            obj.Company = userChildData[j].company;
                            obj.JobTitle = userChildData[j].job_title;
                            obj.Location = userChildData[j].city;
                            if(userid==userChildData[j].tbId){
                                obj.IsLoading = "是";
                            }
                            usernode.Items.push(obj);
                        }
                        getUserChildTreeNode(usernode,userChildPath,obj.NickName,obj.UID);
                        root.TreeNodes.push(usernode);
                    }
                }
            }
        }
    }
}
function getUserChildTreeNode(root,path,nickname,uid){
    var contactList = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,tbId,displayName,avatarUrl,lastMessageDate,username,actualName,fromFacebook,fromPhone,fromNetwork from contactList" ) +')');
    if(contactList!=""&&contactList!=null){
        var contactNode = new TreeNode();
        contactNode.Text = "好友列表";
        contactNode.Type = "Contact";
        for(var i in contactList){
            var obj = new Contact();
            obj.DataState = XLY.Convert.ToDataState(contactList[i].XLY_DataType);
            obj.NickName = contactList[i].displayName;
            obj.UserName = contactList[i].username;
            obj.ActualName = contactList[i].actualName;
            obj.UID = contactList[i].tbId;
            obj.HeadUrl = contactList[i].avatarUrl;
            obj.LastMessageDate = contactList[i].lastMessageDate;
            if(contactList[i].fromFacebook!=0){
                obj.FromWhere = "来自Facebook";
            }
            if(contactList[i].fromPhone!=0){
                obj.FromWhere = "来自手机联系人";
            }
            if(contactList[i].fromNetwork!=0){
                obj.FromWhere = "来自网络";
            }
            contactNode.Items.push(obj);
        }
        root.TreeNodes.push(contactNode);
    }
    var GroupppppList = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,gpId,groupName from groupName" ) +')');
    if(GroupppppList!=""&&GroupppppList!=null){
        var groupNode = new TreeNode();
        groupNode.Text = "群组列表";
        groupNode.Type = "GroupList";
        for(var i in GroupppppList){
            var groupChildNode = new TreeNode();
            groupChildNode.Text = GroupppppList[i].gpId+"_"+GroupppppList[i].groupName;
            groupChildNode.Type = "GroupMember";
            groupChildNode.DataState = XLY.Convert.ToDataState(GroupppppList[i].XLY_DataType);
            var obj = new GroupList();
            obj.DataState = XLY.Convert.ToDataState(GroupppppList[i].XLY_DataType);
            obj.GroupID = GroupppppList[i].gpId;
            obj.GroupName = GroupppppList[i].groupName;
            groupNode.Items.push(obj);
            var group111Member = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,tbId,displayName,avatarUrl,username from groupList where gpId = '"+GroupppppList[i].gpId+"'") +')');
            if(group111Member!=""&&group111Member!=null){
                for(var j in group111Member){
                    var gmObj = new GroupMember();
                    gmObj.DataState = XLY.Convert.ToDataState(group111Member[j].XLY_DataType);
                    gmObj.TalkBoxID = group111Member[j].tbId;
                    gmObj.NickName = group111Member[j].displayName;
                    gmObj.UserName = group111Member[j].username;
                    gmObj.AvataUrl = group111Member[j].avatarUrl;
                    groupChildNode.Items.push(gmObj);
                }
            }
            groupNode.TreeNodes.push(groupChildNode);
        }
        root.TreeNodes.push(groupNode);
    }
    var aa = XLY.File.GetFileName(path);
    var bb = path.substr(0,path.length-aa.length-1);
    var messageDir = eval('('+ XLY.File.FindDirectories(bb) +')');
    var reg1 = new RegExp("P");
    var reg2 = new RegExp("G");
    if(messageDir!=""&&messageDir!= null){
        var msgNode = new TreeNode();
        msgNode.Text = "聊天记录";
        msgNode.Type = "";
        
        var msgFrNode = new TreeNode();
        msgFrNode.Text = "好友聊天记录";
        msgFrNode.Type = "";
        
        var msgGPNode = new TreeNode();
        msgGPNode.Text = "群组聊天记录";
        msgGPNode.Type = "";
        
        
        for(var i in messageDir){
            var filename = XLY.File.GetFileName(messageDir[i]);
            if(reg1.test(filename)){
                var friendChatChildNode = new TreeNode();
                var friendName = eval('('+ XLY.Sqlite.Find(path,"select displayName from contactList where tbId = '"+filename.substr(1,filename.length)+"'") +')');
                if(friendName!=""&&friendName!=null){
                    friendChatChildNode.Text = filename.substr(1,filename.length)+"_"+friendName[0].displayName;
                }
                else
                {
                    friendChatChildNode.Text = filename.substr(1,filename.length)+"_默认";
                }
                friendChatChildNode.Type = "Message";
                var messagePath = messageDir[i]+"\\latest";
                if(XLY.File.IsValid(messagePath)){
                    var messageInfo = eval('('+ XLY.PList.MacReadToJsonString(messagePath) +')');
                    
                    if(messageInfo!=""&&messageInfo!=null){
                        var aaaaaaa = messageInfo["$objects"];
                        var arr = new Array();
                        for(var b in aaaaaaa){
                            if(aaaaaaa[b].senderID!=""&&aaaaaaa[b].senderID!=null){
                                arr.push(b);
                            }
                        }
                        for(var c in arr){
                            if(arr[parseInt(c)+1]!=""&&arr[parseInt(c)+1]!=null){
                                var temp = new Array();
                                for(var d = 0;d<aaaaaaa.length;d++){
                                    if(d>=arr[c]&&d<arr[parseInt(c)+1]){
                                        temp.push(aaaaaaa[d]);
                                    }
                                }
                            }
                            else
                            {
                                var temp = new Array();
                                for(var d = 0;d<aaaaaaa.length;d++){
                                    if(d>= arr[c]&&d<aaaaaaa.length){
                                        temp.push(aaaaaaa[d]);
                                    }
                                }
                            }
                            if(temp!=""&&temp!=null&&temp!= "[]"){
                                var msgObj = new Message();
                                for(var f in temp){
                                    if(temp[f].senderID!=""&&temp[f].senderID!=null){
                                        msgObj.SenderID = temp[f].senderID;
                                        
                                        var sName = eval('('+ XLY.Sqlite.Find(path,"select displayName from contactList where tbId = '"+temp[f].senderID+"'") +')');
                                        if(sName!=""&&sName!=null){
                                            msgObj.SenderName = sName[0].displayName;
                                        }
                                        else
                                        {
                                            msgObj.SenderName = nickname;
                                        }
                                        msgObj.ReceiveID = temp[f].receiverID;
                                        var rName = eval('('+ XLY.Sqlite.Find(path,"select displayName from contactList where tbId = '"+temp[f].receiverID+"'") +')');
                                        if(rName!=""&&rName!=null){
                                            msgObj.ReceiveName = rName[0].displayName;
                                        }
                                        else
                                        {
                                            msgObj.ReceiveName = nickname;
                                        }
                                        if(temp[f].messageType==0){
                                            msgObj.ContentType = "音频文件";
                                            msgObj.Content = allPath+"\\soundHistory"+uid+"\\"+XLY.File.GetFileName(messageDir[i])+"\\"+String(temp[f].msgID)+".caf";
                                        }
                                        else if(temp[f].messageType==2)
                                        { 
                                            msgObj.ContentType = "文本文件";
                                        }
                                        else if(temp[f].messageType==3)
                                        {
                                            msgObj.ContentType = "图片文件";
                                        }
                                        else
                                        {
                                            msgObj.ContentType = "新类型文件";
                                        }
                                        msgObj.Long = "";
                                        msgObj.Lat = "";
                                    }
                                    else if(temp[f]["NS.time"]!=""&&temp[f]["NS.time"]!=null){
                                        var timer = XLY.Convert.LinuxToDateTime(temp[f]["NS.time"]);
                                        msgObj.SendTime = parseInt(timer.substr(0,4))+31+timer.substr(4,timer.length);
                                    }
                                    else if(temp[f]["NS.data"]!=""&&temp[f]["NS.data"]!=null){
                                        var efn = XLY.Blob.ToBytes(temp[f]["NS.data"],"base64");
                                        msgObj.Content = XLY.Blob.ToString(efn);
                                    }
                                    else if(temp[f]["$classes"]!=""&&temp[f]["$classes"]!=null)
                                    {
                                        //log(temp[f]);
                                    }
                                    else if(temp[f].metaDataType!=""&&temp[f].metaDataType!=null)
                                    {
                                        //log(temp[f]);
                                    }
                                    else
                                    {
                                        if(temp[f]=="YES"){
                                            msgObj.Content = temp[f];
                                        }
                                        else
                                        {
                                            var efn = XLY.Blob.ToBytes(temp[f],"base64");
                                            msgObj.Content = XLY.Blob.ToString(efn);
                                        }
                                        
                                    }
                                }
                                friendChatChildNode.Items.push(msgObj);
                            }
                            
                        }
                    }
                }
                msgFrNode.TreeNodes.push(friendChatChildNode);
            }
            if(reg2.test(filename)){
                var gpChatChildNode = new TreeNode();
                var gpName = eval('('+ XLY.Sqlite.Find(path,"select groupName from groupName where gpId = '"+filename.substr(1,filename.length)+"'") +')');
                if(gpName!=""&&gpName!=null){
                    gpChatChildNode.Text = filename.substr(1,filename.length)+"_"+gpName[0].groupName;
                }
                gpChatChildNode.Type = "Message";
                var messagePath = messageDir[i]+"\\latest";
                if(XLY.File.IsValid(messagePath)){
                    var messageInfo = eval('('+ XLY.PList.MacReadToJsonString(messagePath) +')');
                    if(messageInfo!=""&&messageInfo!= null){
                        var aaaaaaa = messageInfo["$objects"];
                        var arr = new Array();
                        for(var b in aaaaaaa){
                            if(aaaaaaa[b].senderID!=""&&aaaaaaa[b].senderID!=null){
                                arr.push(b);
                            }
                        }
                        for(var c in arr){
                            if(arr[parseInt(c)+1]!=""&&arr[parseInt(c)+1]!=null){
                                var temp = new Array();
                                for(var d = 0;d<aaaaaaa.length;d++){
                                    if(d>=arr[c]&&d<arr[parseInt(c)+1]){
                                        temp.push(aaaaaaa[d]);
                                    }
                                }
                            }
                            else
                            {
                                var temp = new Array();
                                for(var d = 0;d<aaaaaaa.length;d++){
                                    if(d>= arr[c]&&d<aaaaaaa.length){
                                        temp.push(aaaaaaa[d]);
                                    }
                                }
                            }
                            if(temp!=""&&temp!=null&&temp!= "[]"){
                                var msgObj = new Message();
                                for(var f in temp){
                                    if(temp[f].senderID!=""&&temp[f].senderID!=null){
                                        msgObj.SenderID = temp[f].senderID;
                                        var sName = eval('('+ XLY.Sqlite.Find(path,"select displayName from contactList where tbId = '"+temp[f].senderID+"'") +')');
                                        if(sName!=""&&sName!=null){
                                            msgObj.SenderName = sName[0].displayName;
                                        }
                                        else
                                        {
                                            msgObj.SenderName = nickname;
                                        }
                                        msgObj.ReceiveID = gpChatChildNode.Text.split("_")[0];
                                        msgObj.ReceiveName = gpChatChildNode.Text.split("_")[1];
                                        if(temp[f].messageType==0){
                                            msgObj.ContentType = "音频文件";
                                            msgObj.Content = allPath+"\\soundHistory"+uid+"\\"+XLY.File.GetFileName(messageDir[i])+"\\"+String(temp[f].msgID)+".caf";
                                            
                                        }
                                        else if(temp[f].messageType==2)
                                        { 
                                            msgObj.ContentType = "文本文件";
                                        }
                                        else if(temp[f].messageType==3)
                                        {
                                            msgObj.ContentType = "图片文件";
                                        }
                                        else
                                        {
                                            msgObj.ContentType = "新类型文件";
                                        }
                                        msgObj.Long = "";
                                        msgObj.Lat = "";
                                    }
                                    else if(temp[f]["NS.time"]!=""&&temp[f]["NS.time"]!=null){
                                        var timer = XLY.Convert.LinuxToDateTime(temp[f]["NS.time"]);
                                        msgObj.SendTime = parseInt(timer.substr(0,4))+31+timer.substr(4,timer.length);
                                    }
                                    else if(temp[f]["NS.data"]!=""&&temp[f]["NS.data"]!=null){
                                        var efn = XLY.Blob.ToBytes(temp[f]["NS.data"],"base64");
                                        msgObj.Content = XLY.Blob.ToString(efn);
                                    }
                                    else if(temp[f]["$classes"]!=""&&temp[f]["$classes"]!=null)
                                    {
                                        //log(temp[f]);
                                    }
                                    else if(temp[f].metaDataType!=""&&temp[f].metaDataType!=null)
                                    {
                                        //log(temp[f]);
                                    }
                                    else
                                    {
                                        if(temp[f]=="YES"){
                                            msgObj.Content = temp[f];
                                        }
                                        else
                                        {
                                            var efn = XLY.Blob.ToBytes(temp[f],"base64");
                                            msgObj.Content = XLY.Blob.ToString(efn);
                                        }
                                        
                                    }
                                }
                                gpChatChildNode.Items.push(msgObj);
                            }
                        }
                    }
                }
                msgGPNode.TreeNodes.push(gpChatChildNode);
            }
        }
        msgNode.TreeNodes.push(msgFrNode);
        msgNode.TreeNodes.push(msgGPNode);
        root.TreeNodes.push(msgNode);
    }
}
function Base64() {
 
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
 
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }
 
    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }
 
    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
 
        }
        return utftext;
    }
 
    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}

function utf16to8(str) {
    var out, i, len, c;

    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
    c = str.charCodeAt(i);
    if ((c >= 0x0001) && (c <= 0x007F)) {
        out += str.charAt(i);
    } else if (c > 0x07FF) {
        out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
        out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    } else {
        out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    }
    }
    return out;
}