﻿/*[config]
<plugin name="58同城,9" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/58.png" app="com.wuba" version="5.4.0.0" description="58同城" data="$data,ComplexTreeDataSource"  >
<source>
<value>data/data/com.wuba/databases/cc.58</value>
<value>data/data/com.wuba/shared_prefs/com.wuba_new_v5.xml</value>
</source>
<data  type="BrowseHistory" datefilter="time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="58同城编号" code="infoID" type="String" width="150" ></item>
<item name="标题" code="title" type="String" width="300" ></item>
<item name="类别" code="cateName" type="String" width="150" ></item>
<item name="位置" code="location" type="String" width="50" ></item>
<item name="快速链接" code="webUrl" type="URL" width="500" ></item>
<item name="时间" code="time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="SiftHistory" datefilter="time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="类别" code="cateName" type="String" width="150" ></item>
<item name="位置" code="location" type="String" width="50" ></item>
<item name="快速链接" code="webUrl" type="Url" width="500" ></item>
<item name="时间" code="time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="DialHistory" datefilter="time" contract="DataState">   
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="标题" code="title" type="string" width="300"></item>
<item name="分类" code="cateName" type="string" width="150"></item>
<item name="地址" code="location" type="string" width="150"></item>
<item name="手机" code="phone" type="string" width="150" ></item>
<item name="链接" code="Url" type="Url" width="400" ></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>
<data type="UserInfo" contract="Map">
<item name="账号" code="userName" type="String" width="" ></item>
<item name="登录地址" code="Desc" type="String" width="400" ></item>
<item name="定位坐标" code="location" type="String" width="300" ></item>
<item name="最新查询内容" code="latstSearch" type="String" width="200" ></item>
<item name="最新筛选类别" code="latstSift" type="String" width="" ></item>
<item name="时间" code="Date" type="datetime" width="" show="false"></item>
<item name="经度" code="Longitude" type="double" format="F6" width="" show="false"></item>
<item name="维度" code="Latitude" type="double" format="F4"  width="" show="false"></item>

</data>

</plugin>
[config]*/

// js content

//定义数据结构
function BrowseHistory() {
	this.infoID = "";  
	this.title = "";  
	this.cateName = "";  
	this.location = "";  
	this.webUrl = "";  
	this.time = "";  
	this.DataState = "Normal";  
}

function SiftHistory() {
	this.cateName = "";  
	this.location = "";  
	this.webUrl = "";  
	this.time = "";  
	this.DataState = "Normal";  
}

function DialHistory() {
	this.Url = "";  
	this.title = "";  
	this.cateName = "";  
	this.location = "";  
	this.phone = "";  
	this.time = "";  
	this.DataState = "Normal";  
}

function UserInfo() {
	this.userName = "";  
	this.Desc = "";  
	this.location = "";  
	this.latstSearch = "";  
	this.latstSift = "";  
	this.Date = "";  
	this.Longitude = "";  
	this.Latitude = "";  
}
//树形结构
function TreeNode() {
	this.Text = "";//节点名称
	this.TreeNodes = new Array();//子节点数字
	this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
	this.DataState = "Normal";  
}

//获取浏览历史记录
function getBrowseHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from browse order by updatetime desc") + ')');
		for(var index in data)
		{
			var obj=new BrowseHistory();
			obj.infoID = data[index].infoid;  
			obj.title = data[index].title;  
			obj.cateName = data[index].catename;  
			obj.location = data[index].localname;  
			obj.webUrl = data[index].weburl;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			obj.time = XLY.Convert.ToDateTime(data[index].updatetime,"yy/MM/dd HH:mm"); 
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//获取筛选历史记录
function getSiftHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from sift order by updatetime desc") + ')');
		for(var index in data)
		{
			var obj=new SiftHistory();
			obj.cateName = data[index].catename;  
			obj.location = data[index].localname;  
			obj.webUrl = data[index].weburl;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			obj.time = XLY.Convert.ToDateTime(data[index].updatetime,"yy/MM/dd HH:mm"); 
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//获取用户信息
function getUserInfo(path)
{
	var arr = new Array();
	try{
	    var info = XLY.File.ReadFile(path);
	    if (info == "") {
	        return;
	    }
		var data=info.split("\n");
		var obj=new UserInfo();
		for(var index in data)
		{
			if(data[index].indexOf("USERNAME")>0)
			{
				var c=eval('('+XLY.Convert.XMLToJSON( data[index])+')')
					obj.userName=c.string["#text"];
			}
			if(data[index].indexOf("location_text")>0)
			{
				var c=eval('('+XLY.Convert.XMLToJSON( data[index])+')')
					obj.Desc=c.string["#text"];
			}
			if((/string name=\"lon\"/gi).test(data[index]))
			{
				var c=eval('('+XLY.Convert.XMLToJSON( data[index])+')')
					obj.location=c.string["#text"];
				obj.Longitude=c.string["#text"];
			}
			if((/string name=\"lat\"/gi).test(data[index]))
			{
				var c=eval('('+XLY.Convert.XMLToJSON( data[index])+')')
					obj.location+="     "+c.string["#text"];
				obj.Latitude=c.string["#text"];
			}
			if(data[index].indexOf("searcher_history")>0)
			{
				var c=eval('('+XLY.Convert.XMLToJSON( data[index])+')')
					obj.latstSearch=c.string["#text"];
			}
			if(data[index].indexOf("SIFT_CATE")>0)
			{
				var c=eval('('+XLY.Convert.XMLToJSON( data[index])+')')
					obj.latstSift=c.string["#text"];
			} 
		}
		arr.push(obj);
		return arr;
	}
	catch(e){
		return arr;
	}
}
//获取拨打历史记录
function getDialHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from dial order by updatetime desc") + ')');
		for(var index in data)
		{
			var obj=new SiftHistory();
			obj.Url = data[index].url;  
			obj.title = data[index].title;  
			obj.cateName = data[index].catename;  
			obj.location = data[index].localname;  
			obj.phone = data[index].phoneNumber;  
			obj.time = data[index].updatetime;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}
var result = new Array();

//源文件
var source = $source;
var path1 = source[0] ;
var path2 = source[1] ;

//数据恢复库的生成
var charactor="chalib\\Android_58TongCheng_V5.4.0.0\\cc.58.charactor";
path1=XLY.Sqlite.DataRecovery( path1,charactor ,"browse,dial,sift");

//以下为节点的实例化
var BrowseNode =new TreeNode();
BrowseNode.Type="BrowseHistory";
BrowseNode.Text="浏览记录";

var DialNode =new TreeNode();
DialNode.Type="DialHistory";
DialNode.Text="拨打历史";

var SiftNode =new TreeNode();
SiftNode.Type="SiftHistory";
SiftNode.Text="筛选记录";

var UserNode =new TreeNode();
UserNode.Type="UserInfo";
UserNode.Text="用户信息";

//以下为节点的数据填充
BrowseNode.Items=getBrowseHistory(path1);
SiftNode.Items=getSiftHistory(path1);
UserNode.Items=getUserInfo(path2);
DialNode.Items=getDialHistory(path1);

//结果打印
result.push(BrowseNode);
result.push(DialNode);
result.push(SiftNode);
result.push(UserNode);
var res = JSON.stringify(result);
res;
