﻿/*[config]
<plugin name="图吧导航,10" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Tuba.png" app="com.mapbar.android.mapbarmap" version="9.1.2" description="图吧导航" data="$data,ComplexTreeDataSource" >
<source>
 <value>/data/data/com.mapbar.android.mapbarmap/#F</value>
</source>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="最后导航目的地" code="Navi" type="string" width = "150"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="地点" code="POI" type="string" width = "150"></item>
<item name="所属位置" code="Address" type="string" width = "200"></item>
<item name="POI电话" code="Phone" type="string" width = "200"></item>
<item name="所在城市" code="District" type="string" width = "200"></item>
<item name="类型" code="Type" type="string" width = "200"></item>
<item name="位置标志" code="Flag" type="string" width = "200"></item>
<item name="常用地" code="Offen" type="string" width = "200"></item>
<item name="更新时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Site" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="关键字" code="Key" type="string" width = "150"></item>
<item name="位置" code="Location" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Navi" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点 途径点 终点位置" code="Start" type="string" width = "150"></item>
<item name="起点 途径点 终点所属市" code="Pass" type="string" width = "150"></item>
<item name="起点 途径点 终点地名" code="End" type="string" width = "150"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account() {
    this.ID = "";
    this.Navi = "";
}
function Search() {
    this.POI = "";
    this.Address = "";
    this.Phone = "";
    this.District = "";
    this.Type = "";
    this.Flag = "";
    this.Offen = "";
    this.Time = "";
    this.DataState="Normal";
}
function Site() {
    this.Key = "";
    this.Location = "";
    this.Time = "";
    this.DataState="Normal";
}
function Navi() {
    this.Start = "";
    this.Pass = "";
    this.End = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "图吧导航";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].ID;
        account.Type = "Account";
        account.Items = accountinfo; 
        news.TreeNodes.push(account);
        
        var search = new TreeNode() ;
        search.Text = "历史线路目的地";
        search.Type = "Search"; 
        search.Items = getSearch(db1);
        account.TreeNodes.push(search);
        
        var site = new TreeNode() ;
        site.Text = "历史搜索地点";
        site.Type = "Site"; 
        site.Items = getSite(db2);
        account.TreeNodes.push(site);
        
        var navi = new TreeNode() ;
        navi.Text = "最后导航";
        navi.Type = "Navi"; 
        navi.Items = getNavi(db3);
        account.TreeNodes.push(navi);
    }
     result.push(news);
} 

 function getAccount (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');
     var obj = new Account();
     var info = data.map.string;
     for(var i in info){
          if(info[i]["@name"] == "userSharedPreferencesAccount"){
              obj.ID = info[i]["#text"];          
          }
          if(info[i]["@name"] == "last_navi_road_name"){
              obj.Navi = info[i]["#text"];          
          }
     }
    list.push(obj);
    return list;
 }
function getSearch(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from table_favorite" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.POI = data[i].poiname;
        obj.Address = data[i].poiaddress;
        obj.Phone = data[i].poiphone;
        obj.District = data[i].poicity;
        obj.Type = data[i].poitype;
        var a = data[i].poiflag;
        switch(a){
            case 1:
            obj.Flag = "收藏地址";
            break;
            case 3:
            obj.Flag = "常用地点";
            break;
            case 4:
            obj.Flag = "路线目的地历史";
            break;
            case 5:
            obj.Flag = "桌面快捷方式";
            break;
            default:
            obj.Flag = "其他";
            break;
        }
        obj.Offen = data[i].oftenaddressname;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].updatetime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getSite(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from table_suggestion_map" ) +')');
    for(var i in data){
        var obj = new Site();
        obj.Key = data[i].keyword;
        obj.Location = data[i].location;
        obj.Time = data[i].updatetime;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getNavi(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadFile(path) +')');
    var data1 = data.dests;
    for(var i in data1){
        var obj = new Navi();
        obj.Start = data1[i].addr;
        obj.Pass = data1[i].region;
        obj.End = data1[i].name;
        //obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
 //********************************************************
var source = $source;
var db= source[0]+"\\shared_prefs\\userSharedPreferences.xml";
var db3= source[0]+"\\files\\mapbarmap_saved_route.bin";
var db4 = source[0]+"\\databases\\favorite.db";
var db5 = source[0]+"\\databases\\suggestion_map.db";

var charactor = "\\chalib\\Android_Tubadaohang_9.1.2\\favorite.db.charactor";
var charactor1 = "\\chalib\\Android_Tubadaohang_9.1.2\\suggestion_map.db.charactor";

//var db = "D:\\temp\\data\\data\\com.mapbar.android.mapbarmap\\shared_prefs\\userSharedPreferences.xml";
//var db4 = "D:\\temp\\data\\data\\com.mapbar.android.mapbarmap\\databases\\favorite.db";
//var db5 = "D:\\temp\\data\\data\\com.mapbar.android.mapbarmap\\databases\\suggestion_map.db";
//var db3 = "D:\\temp\\data\\data\\com.mapbar.android.mapbarmap\\files\\mapbarmap_saved_route.bin";
//
//var charactor = "D:\\temp\\data\\data\\com.mapbar.android.mapbarmap\\databases\\favorite.db.charactor";
//var charactor1 = "D:\\temp\\data\\data\\com.mapbar.android.mapbarmap\\databases\suggestion_map.db.charactor";

var db1 = XLY.Sqlite.DataRecovery(db4,charactor,"table_favorite");
var db2 = XLY.Sqlite.DataRecovery(db5,charactor1,"table_suggestion_map");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
