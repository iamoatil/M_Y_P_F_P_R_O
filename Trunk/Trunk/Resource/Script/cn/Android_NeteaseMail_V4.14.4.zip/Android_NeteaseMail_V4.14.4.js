﻿/*[config]
<plugin name="网易邮箱,6" group="主流邮箱,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Mail163.png" app="com.netease.mobimail" version="4.14.4" description="网易邮箱" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.netease.mail/databases/mmail</value>
</source>
<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="邮箱地址" code="Address" type="string" width="" format=""></item>
<item name="昵称" code="Nick" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string"   width="" format=""></item>
</data>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="Contact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="邮箱地址" code="Address" type="string" width="" format = ""></item>
<item name="昵称" code="Name" type="string" width="" format = ""></item>
</data>
<data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID" code="ID" type="string" width="150" format=""></item>
<item name="发件人" code="Send" type="string" width="150" format=""></item>
<item name="收件人" code="Receive" type="string" width="300" format=""></item>
<item name="发送时间" code="SendTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="接收时间" code="ReceiveTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="主题" code="Subject" type="string" width="200" format=""></item>
<item name="邮件内容" code="Content" type="string" width="200" format=""></item>
<item name="附件" code="Fujian" type="string" width="200" format=""></item>
<item name="阅读状态" code="IsRead" type="string" width="150" format=""></item>
<item name="回复状态" code="IsReply" type="string" width="150" format=""></item>
<item name="星标状态" code="IsMark" type="string" width="150" format=""></item>
<item name="附件状态" code="IsAttach" type="string" width="150" format=""></item>
</data>
<data type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum"  show = "false" format="EnumDataState" ></item>
<item name="ID" code="GroupId" type="string" width="" show = "false" format = ""></item>
<item name="名字" code="Name" type="string" width="" show = "false" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义Account数据结构
function Account() {
    this.Address = "";
    this.Nick = "";
    this.ID = "";
    this.DataState = "Normal";
}
function Info(){
    this.Acc = "";
}
function Contact() {
    this.Address = "";
    this.DataState = "Normal";
    this.Name = "";
}
//定义Message数据结构
function Message() {
    this.ID = "";
    this.Send = "";
    this.Receive = "";
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.IsReply = "";
    this.Content = "";
    this.IsRead = "";
    this.IsMark = "";
    this.IsAttach = "";
    this.DataState = "Normal";
    this.Fujian = "";
}
function Group(){
    this.GroupId = "";
    this.Name = "";
    this.DataState = "Normal";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var info = new TreeNode();
    info.Text = "网易邮箱";
    info.Type = "Account"; 
    accountinfo = getAccount(db1);
    info.Items = accountinfo;
    info.DataState = "Normal";
    
       for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Address;
        account.Type = "Info"; 
        info.TreeNodes.push(account);
        
        var contact = new TreeNode() ;
        contact.Text = "联系人";
        contact.Type = "Contact"; 
        contact.Items = getContact(db1,accountinfo[i]);
        account.TreeNodes.push(contact); 
        
        var group = new TreeNode() ;
        group.Text = "邮件";
        group.Type = "Group"; 
        var groupinfo = getGroup(db1,accountinfo[i]);
       
        for(var j in groupinfo){
            var msg = new TreeNode() ;
            msg.Text = groupinfo[j].Name;
            msg.Type = "Message"; 
            msg.Items = getMessage(db1,accountinfo,groupinfo[j]);
            group.TreeNodes.push(msg); 
        }
        account.TreeNodes.push(group);
       }
    result.push(info);    
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from AccountCore" ) +')'); 
    for(var i in data){
        var obj = new Account();
        obj.Address = data[i].mailAddress;
        obj.ID = data[i].id;   
        
        if(data[i].Nick!=""&&data[i].Nick!=null){
            obj.Nick = data[i].Nick;
        }
        else
        {
            var name = eval('('+ XLY.Sqlite.Find(path,"select key,value from AccountExtData where accId = '"+data[i].id+"'") +')');
            if(name!=""&&name!=null){
                for(var j in name){
                    if(name[j].key=="senders"){
                        var aa = eval('('+ name[j].value +')');
                        obj.Nick = aa[0].name;
                    }
                }
            }
        }
        list.push(obj);
    }
    return list;
}
//function getContact(path,accountinfo){
//    var list = new Array();
//    var tablename = "Contact_" + accountinfo.ID;
//    var data = eval('(' + XLY.Sqlite.Find(path, "select * from '" + tablename + "'") + ')');  
//    for(var i in data){
//        var obj = new Contact();
//        var email = eval('('+ data[i].email +')');
//        for(var k in email){
//            obj.Address = email[k].value;
//        }
//        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
//        list.push(obj);
//    }
//    return list;
//}
function getContact(path,accountinfo){
    var list = new Array();
    var tablename = "Contact_" + accountinfo.ID;
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from '" + tablename + "'") + ')');  
    for(var i in data){
        var obj = new Contact();
        var email = eval('('+ data[i].email +')');
        for(var k in email){
            obj.Address = email[k].value;
        }
        var name = eval('('+ data[i].name +')');
        obj.Name = name.value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getGroup(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from Mailbox where accountId = "+accountinfo.ID+"") +')');

    for(var i in data){
        var obj = new Group();
        obj.GroupId = data[i].serverId;
        obj.Name = data[i].displayName;
        list.push(obj);
    }
    return list;
}
function getMessage(path,accountinfo,groupinfo){
    var list = new Array();
    var tablename = "Mail_" + accountinfo[0].ID;
    var amtname = "Part_" + accountinfo[0].ID;
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from '"+tablename+"' where mailboxKey = "+groupinfo.GroupId+"" ) +')'); 
    if(data!=""&&data!=null){
        for(var i in data){
            var obj = new Message();
            obj.ID = data[i].messageId;
            obj.SendTime = XLY.Convert.LinuxToDateTime(data[i].sendDate);
            obj.ReceiveTime = XLY.Convert.LinuxToDateTime(data[i].recvDate);
            var sender = eval('('+ data[i].mailFrom +')'); 
            obj.Send = sender.name+"("+sender.mailAddress+")";
            var receiver = eval('('+ data[i].mailTo +')'); 
            obj.Receive = receiver[0].name+"("+receiver[0].mailAddress+")";
            obj.Subject = data[i].subject;
            obj.Content = data[i].textContent;
            obj.IsRead = (data[i].isRead == 1) ? "已阅" : "未读";
            obj.IsReply = (data[i].isReplied == 1) ? "已回复" : "未回复";
            obj.IsMark = (data[i].isMarked == 1) ? "星标邮件" : "";
            obj.IsAttach = (data[i].hasAttach) ? "有附件" : "无附件";
            var fujiandata = eval('('+ XLY.Sqlite.Find(path,"select localPath,contentType,size,downloadTime from '"+amtname+"' where messageId = '"+data[i].localId+"'") +')');
            if(fujiandata!=""&&fujiandata!=null){
                obj.Fujian = "附件信息：\n 路径："+fujiandata[0].localPath+";\n类型:"+fujiandata[0].contentType.split("\/")[1]+";\n大小："+fujiandata[0].size +"Byte"+";\n时间："+XLY.Convert.LinuxToDateTime(fujiandata[0].downloadTime);
                
            }
            list.push(obj);
        }
    }
    return list;
}
//********************************************************
var source = $source;
var db1 = source[0];

//var db1 = "D:\\temp\\data\\data\\2017-0055能力验证网易163邮箱\\Root\\data\\com.netease.mail\\databases\\mmail";
var charactor = "chalib\\Android_NeteaseMail_V4.14.4\\mmail.charactor";
//var db1 = XLY.Sqlite.DataRecovery(db,charactor,"AccountCore,Contact_0,Mail_0,Mailbox,AccountExtData");
var result = new Array();
bindTree();
var res = JSON.stringify( result );
res;