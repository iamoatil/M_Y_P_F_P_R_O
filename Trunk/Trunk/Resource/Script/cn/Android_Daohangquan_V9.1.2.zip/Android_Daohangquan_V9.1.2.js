﻿/*[config]
<plugin name="导航犬,10" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\NaviDog.png" app="cn.com.tiros.android.navidog" version="9.1.2" description="导航犬" data="$data,ComplexTreeDataSource" >
<source>
 <value>/data/data/cn.com.tiros.android.navidog/shared_prefs/userSharedPreferences.xml</value>
 <value>/data/data/cn.com.tiros.android.navidog/databases/favorite.db</value>
 <value>/data/data/cn.com.tiros.android.navidog/databases/suggestion_map.db</value>
</source>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="当前账号" code="Name" type="string" width = "150"></item>
<item name="历史账号" code="OldName" type="string" width = "150"></item>
</data>
<data type="Fav" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="地点" code="POI" type="string" width = "150"></item>
<item name="位置" code="Addr" type="string" width = "200"></item>
<item name="电话" code="Phone" type="string" width = "200"></item>
<item name="所在城市" code="City" type="string" width = "200"></item>
<item name="类型" code="Type" type="string" width = "200"></item>
<item name="位置标记" code="Flag" type="string" width = "200"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="关键字" code="Key" type="string" width = "150"></item>
<item name="位置" code="Location" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account() {
    this.OldName = "";
    this.Name = "";
}
function Fav() {
    this.POI = "";
    this.Addr = "";
    this.Phone = "";
    this.City = "";
    this.Type = "";
    this.Time = "";
    this.Flag = "";
    this.DataState="Normal";
}
function Search(){
    this.Key = "";
    this.Time = "";
    this.Location = "";
    this.DataState="Normal";
}

function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "导航犬";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    var acc = new TreeNode() ;
    acc.Text = "账号";
    acc.Type = "Account"; 
    acc.Items = getAccount(db);
    news.TreeNodes.push(acc)
    
    var fav = new TreeNode() ;
    fav.Text = "收藏";
    fav.Type = "Fav"; 
    fav.Items = getFav(db1);
    news.TreeNodes.push(fav);
     
    var search = new TreeNode() ;
    search.Text = "搜索";
    search.Type = "Search"; 
    search.Items = getSearch(db2);
    news.TreeNodes.push(search);

     result.push(news);
} 

 function getAccount (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');
     var obj = new Account();
     var info = data.map.string;
     for(var i in info){
          if(info[i]["@name"] == "userSharedPreferencesAccount"){
              obj.Name = info[i]["#text"];          
          }
          if(info[i]["@name"] == "userSharedPreferencesOldAccount"){
              obj.OldName = info[i]["#text"];          
          }
     }
    list.push(obj);
    return list;
 }
function getFav(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from table_favorite" ) +')');
    for(var i in data){
        var obj = new Fav();
        obj.POI = data[i].poiname;
        obj.Addr = data[i].poiaddress;
        obj.Phone = data[i].poiphone;
        obj.City = data[i].poicity;
        obj.Type = data[i].poitype;
        var a = data[i].poiflag;
        switch(a){
            case 1: 
            obj.Flag = "收藏地址";
            break;
            case 3: 
            obj.Flag = "常用地点";
            break;
            case 4: 
            obj.Flag = "路线目的地历史";
            break;
           case 5: 
            obj.Flag = "桌面快捷方式";
            break;
           default: 
            obj.Flag = "其他";
            break;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].updatetime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getSearch(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from table_suggestion_map" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Key = data[i].keyword;
        obj.Location = data[i].location;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].updatetime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}

 //********************************************************
var source = $source;
var db = source[0];
var db3 = source[1];
var db4 = source[2];
var charactor = "\\chalib\\Android_Daohangquan_V9.1.2\\\favorite.db.charactor";
var charactor1 = "\\chalib\\Android_Daohangquan_V9.1.2\\\suggestion_map.db.charactor";

//var db = "D:\\temp\\data\\data\\cn.com.tiros.android.navidog\\shared_prefs\\userSharedPreferences.xml";
//var db3 = "D:\\temp\\data\\data\\cn.com.tiros.android.navidog\\databases\\favorite.db";
//var db4 = "D:\\temp\\data\\data\\cn.com.tiros.android.navidog\\databases\\suggestion_map.db";
//
//var charactor = "D:\\temp\\data\\data\\cld.navi.mainframe\\databases\\favorite.db.charactor";
//var charactor1 = "D:\\temp\\data\\data\\cld.navi.mainframe\\databases\\suggestion_map.db.charactor";

var db1 = XLY.Sqlite.DataRecovery(db3,charactor,"table_favorite");
var db2 = XLY.Sqlite.DataRecovery(db4,charactor1,"table_suggestion_map");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
