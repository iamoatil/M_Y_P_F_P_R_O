﻿/*[config]
<plugin name="QQ邮箱,4" group="主流邮箱,4" devicetype="ios" pump="usb,wifi,mirror,bluetooth,LocalData" icon="\icons\QQMail.png" app="com.tencent.qqmail" version="3.2.1" description="QQ邮箱" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tencent.qqmail</value>
</source>

<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" width="100" format="EnumDataState"></item>
<item name="名称" code="Name" type="string" width = "100"></item>
<item name="头像" code="Image" type="string" width = "200"></item>
<item name="账户配置内容(plist)" code="ProFile" type="string" width="200"></item>
<item name="邮箱地址" code="Email" type="string" width="300"></item>
</data>

<data detailfield="TextContent" type="Mail" contract="DataState,Mail">
<item name="数据状态" code="DataState" type="Enum" width="100" format="EnumDataState"></item>
<item name="发件人" code="Sender" type="string" width="270" ></item>
<item name="收件人" code="Receiver" type="string" width="270" ></item>
<item name="发送时间" code="StartDate" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="接收时间" code="RecvDataTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="主题" code="Subject" type="mail" width="300" ></item>
<item name="内容摘要" code="Abstract" type="string" width="300" ></item>
<item name="内容详细信息" code="TextContent" type="string" width="300" show='false'></item>
<item name="附件信息" code="Attachments" type="list" width="300" show='false'></item>
<item name="附件路径" code="AttachmentPaths" type="list" width="300" show='false'></item>
<item name="阅读状态" code="Status" type="string" width = "100" ></item>
<item name="是否重要邮件" code="IsVip" type="string" width="100" ></item>
<item name="是否为星标邮件" code="Star" type="string" width="100" ></item>
</data>

<data type="Contact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" width="100" format="EnumDataState"></item>
<item name="好友名称" code="Name" type="string" width="200"></item>
<item name="邮箱地址" code="Email" type="string" width="300"></item>
<item name="备注" code="Mark" type="string" width="200"></item>
<item name="VIP会员" code="VIP" type="string" width="400"></item>
</data>
</plugin>
[config]*/

//定义Account数据结构
function Account() {
    this.AccountId = "";
    this.Name = "";
    this.Image = "";
    this.Email = "";
    this.ProFile = "";
    this.DataState = "Normal";
}
    
//定义Mail数据结构
function Mail() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Subject = "";
    this.Abstract = "";
    this.TextContent = "";
    this.Attachments = new Array();
    this.AttachmentPaths = new Array();
    this.RecvDataTime = "";
    this.StartDate = "";
    this.Status = "";
    this.Star = "";
    this.IsVip = "";
    this.DataState = "Normal";
}

//定义分组信息
function Group(){
    this.GroupId = "";
    this.AccountId = "";
    this.RemoteId = "";
    this.Name = "";
    this.TotalCount = "";
    this.UnReadCount = "";
    this.ReadCount = "";
    this.DataState = "Normal";
}

//定义Contact数据结构
function Contact() {
    this.Name = "";
    this.Email = "";
    this.Mark = "";
    this.VIP = "";
    this.DataState = "Normal";
}

//树结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//构建账户信息
function CreateAccountInfo(data){
    var account = new Account();
    account.AccountId = data.id;
    account.Image = data.accountImage;
    account.Name = data.nickname;
    account.Email = data.name;
    account.ProFile = data.profile;
    account.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return account;
}

var result = new Array();
var source = $source;
var mailPath =source[0]+ "\\com.tencent.qqmail\\Documents\\FMailDB.db";
//定义特征库文件
var charactor = "chalib\\IOS_QQMail_V3.0.1\\FMailDB.db.charactor";
//处理删除的数据
var recoveryPath = XLY.Sqlite.DataRecovery(mailPath, charactor, "Account");


// 加载主体树
function BindTree(){
    
    // 根节点
    var rootNode = new TreeNode();
    rootNode.Text = "本机账户信息";
    
    // 获取账户信息;
    var accountData = eval('('+ XLY.Sqlite.Find(recoveryPath,"select s.*,a.profile from FM_Account_Setting s left join FM_Account a on s.[name]= a.[name]") +')');
    for(var data in accountData){
        var account = new TreeNode();
        account.Text = accountData[data].nickname+"("+accountData[data].name+")";
        account.Type = "Account";
        account.DataState = XLY.Convert.ToDataState(accountData[data].XLY_DataType);
        var accountInfo = CreateAccountInfo(accountData[data]);
        account.Items.push(accountInfo);
        // 获取账户分组节点
        LoadAccountGroupNode(accountInfo,account)
        rootNode.TreeNodes.push(account);
    }
    return rootNode;
}

// 获取账户分组节点
function LoadAccountGroupNode(account,parentTree){
    var groupNodes = eval('('+ XLY.Sqlite.Find(recoveryPath,"select * from FM_Folder where accountId = "+account.AccountId+"") +')');
    var emailData= eval('('+ XLY.Sqlite.Find(recoveryPath,"select c.[content],m.* from FM_Mail_Content c left join FM_MailInfo m on c.[mailId]=m.[mailId] where m.fromEmail = '"+account.Email+"' or tos like '%"+account.Email+"%'") +')');
    for(var i in groupNodes){
        var groupTree = new TreeNode();
        var group = CreateGroup(groupNodes[i])
        groupTree.Text = group.Name;
        groupTree.Type = "Mail";
        groupTree.DataState = group.DataState;
        // 获取当前分组下的邮件信息;
        LoadGroupMessageNode(group,emailData,groupTree);
        parentTree.TreeNodes.push(groupTree);
    }
}

// 加载分组信息;
function CreateGroup(group){
    var groupInfo = new Group();
    if(group==null) return groupInfo;
    groupInfo.GroupId = group.id;
    groupInfo.AccountId = group.accountId;
    groupInfo.RemoteId = group.remoteId;
    groupInfo.Name = group.showName;
    groupInfo.TotalCount = group.totalCnt;
    groupInfo.UnReadCount = group.unReadCnt;
    groupInfo.ReadCount = XLY.Convert.ToInt(groupInfo.TotalCount)-XLY.Convert.ToInt(groupInfo.UnReadCount);
    groupInfo.DataState = XLY.Convert.ToDataState(group.XLY_DataType);
    return groupInfo;
}

// 获取分组信息节点
function LoadGroupMessageNode(group,emailData,parent){
    // 获取重要联系人
    if(group.RemoteId == "addrvip_addrvip_"){
        
    }else{
        for(var i in emailData){
            if(emailData[i].folderId==group.GroupId){
                var mail = CreateMail(emailData[i]);
                parent.Items.push(mail);
            }
        }
    }
    
}

// 获取邮件信息
function CreateMail(mail){
    var mailInfo = new Mail();
    mailInfo.Sender = mail.fromEmail;
    mailInfo.Receiver = mail.tos;
    mailInfo.Time = XLY.Convert.LinuxToDateTime(mail.receivedUtc);
    mailInfo.Subject = mail.subject;
    mailInfo.Abstract = mail.abstract;
    mailInfo.RecvDataTime=XLY.Convert.LinuxToDateTime(mail.receivedUtc);
    mailInfo.TextContent = mail.content;
    if(mail.hasAttach == 1){
        var emailAttach = eval('('+ XLY.Sqlite.Find(recoveryPath,"select * from FM_Mail_Attach where mailId = '"+mail.mailId+"'") +')');
        for(var attach in emailAttach){
            var str = "附件名称:"+emailAttach[attach].name+";附件大小:"+emailAttach[attach].size;
            mailInfo.Attachments.push(str);
            mailInfo.AttachmentPaths.push(emailAttach[attach].name);
        }
    }
    mailInfo.StartDate = "";
    mailInfo.Status = (mail.isRead == 1) ? "已读" : "未读";
    mailInfo.Star = (mail.isStar == 1) ? "星标邮件" : "";
    mailInfo.IsVip= (mail.isVip == 1)?"是" : "";
    mailInfo.DataState = "Normal";
    return mailInfo;
}


result.push(BindTree());
var res = JSON.stringify(result);
res;





















































