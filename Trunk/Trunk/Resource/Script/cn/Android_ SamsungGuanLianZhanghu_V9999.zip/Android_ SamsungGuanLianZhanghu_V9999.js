﻿/*[config]
<plugin name="三星邮箱,3" group="主流邮箱,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/samsungguanlianyouxiang.png" app="com.osp.app.signin" version="5.0.92" description="三星手机关联邮箱" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.osp.app.signin/databases/openData.db</value>
    <value>/data/data/com.osp.app.signin/shared_prefs/com.osp.app.signin_preferences.xml</value>
    <value>/data/data/com.osp.app.signin/shared_prefs/WebViewChromiumPrefs.xml</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关联邮箱账号" code="UserName" type="string" width = "120"></item>
    <item name="最后更改时间" code="LastChangeTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="版本代码" code="VersionCode" type="string" width = "80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.LastChangeTime = null;
    this.VersionCode = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var emailPath1 = source[0];
var lastTimePath = source[1];
var versionCodePath = source[2];

//测试数据
//var emailPath1 = "C:\\Users\\liu\\Desktop\\com.osp.app.signin\\databases\\openData.db";
//var lastTimePath = "C:\\Users\\liu\\Desktop\\com.osp.app.signin\\shared_prefs\\com.osp.app.signin_preferences.xml";
//var versionCodePath = "C:\\Users\\liu\\Desktop\\com.osp.app.signin\\shared_prefs\\WebViewChromiumPrefs.xml";
//定义特征库文件
var charactor = "\\chalib\\Android_SamsungShouJiGuanLianYouXiang_V9999\\openData.db.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
var emailPath = XLY.Sqlite.DataRecovery(emailPath1,charactor,"tncrequest");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "三星手机关联邮箱";
    root.Type = "";
    getNews(root);
    result.push(root);
}
function getNews(root){
    var userNode = new TreeNode();
    userNode.Text = "关联邮箱账号";
    userNode.Type = "UserInfo";
    
    if(XLY.File.IsValid(emailPath)){
        var dataEmail = eval('('+ XLY.Sqlite.Find(emailPath,"select XLY_DataType,Key from tncrequest") +')');
        if(dataEmail!=""&&dataEmail!= null){
            for(var p in dataEmail){
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(dataEmail[p].XLY_DataType);
                obj.UserName = dataEmail[p].Key;
                if(XLY.File.IsValid(lastTimePath)){
                    var lastTime = eval('('+ XLY.File.ReadXML(lastTimePath) +')');
                    if(lastTime!=""&&lastTime!= null){
                        var aa = lastTime.map.long;
                        if(aa!=""&&aa!=null){
                            for(var i in aa){
                                if(aa[i]["@name"]=="LAST_EMAIL_RECEIVE_CHANGE_TIME_KEY"){
                                    obj.LastChangeTime = XLY.Convert.LinuxToDateTime(aa[i]["@value"]);
                                }
                            }
                        }
                    }
                }
                if(XLY.File.IsValid(versionCodePath)){
                    var versionCode = eval('('+ XLY.File.ReadXML(versionCodePath) +')');
                    if(versionCode!=""&&versionCode!= null){
                        var bb = versionCode.map.int;
                        obj.VersionCode = bb["@value"];
                    }
                }
                userNode.Items.push(obj);
            }
        }
    }
    root.TreeNodes.push(userNode);
}