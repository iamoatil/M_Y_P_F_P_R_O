﻿/*[config]
<plugin name="百度地图,10" group="地图公交,7,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\baiduMap.png" app="com.baidu.BaiduMap" version="9.5.0" description="百度地图" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.baidu.BaiduMap/files#F</value>
<value>/data/data/com.baidu.BaiduMap/databases/#F</value>
</source>
<data type="Info" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Walk" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="起点经纬度" code="STart" type="string" width = "150"></item>
<item name="起点位置" code="SAddr" type="string" width = "150"></item>
<item name="终点经纬度" code="End" type="string" width = "150"></item>
<item name="终点位置" code="EAddr" type="string" width = "150"></item>
<item name="距离（米）" code="Distance" type="string" width = "150"></item>
<item name="持续时间（秒）" code="Duration" type="string" width = "150"></item>
<item name="平均速度" code="Avg" type="string" width = "150"></item>
<item name="最大速度" code="Max" type="string" width = "150"></item>
<item name="消耗卡路里" code="Cal" type="string" width = "150"></item>
<item name="名称" code="Title" type="string" width = "200"></item>
<item name="描述" code="Desc" type="string" width = "200"></item>
</data>
<data type="Car" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="起点经纬度" code="STart" type="string" width = "150"></item>
<item name="起点位置" code="SAddr" type="string" width = "150"></item>
<item name="终点经纬度" code="End" type="string" width = "150"></item>
<item name="终点位置" code="EAddr" type="string" width = "150"></item>
<item name="距离（米）" code="Distance" type="string" width = "150"></item>
<item name="持续时间（秒）" code="Duration" type="string" width = "150"></item>
<item name="平均速度(千米/小时)" code="Avg" type="string" width = "150"></item>
<item name="最大速度（千米/小时)" code="Max" type="string" width = "150"></item>
<item name="名称" code="Title" type="string" width = "200"></item>
<item name="描述" code="Desc" type="string" width = "200"></item>
</data>
<data type="Location" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="经纬度" code="STart" type="string" width = "150"></item>
<item name="位置" code="Addr" type="string" width = "150"></item>
<item name="商铺" code="POI" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "150"></item>
<item name="商铺类型" code="POIType" type="string" width = "150"></item>
</data>
<data type="POI" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="关键字" code="Key" type="string" width = "200"></item>
<item name="位置" code="Location" type="string" width = "150"></item>
<item name="添加时间" code="Time" type="string" width = "150"></item>
</data>
<data type="Route" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点经纬度" code="STart" type="string" width = "150"></item>
<item name="起点位置" code="SAddr" type="string" width = "150"></item>
<item name="终点经纬度" code="End" type="string" width = "150"></item>
<item name="终点位置" code="EAddr" type="string" width = "150"></item>
<item name="搜索时间" code="Time" type="string" width = "150"></item>
</data>
<data type="FavPOI" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="地点名称" code="Name" type="string" width = "200"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="地点经纬度" code="LatLng" type="string" width = "150"></item>
<item name="收藏时间" code="Time" type="string" width = "150"></item>
</data>
<data type="FavRoute" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="起点经纬度" code="Start" type="string" width = "150"></item>
<item name="起点" code="SAddr" type="string" width = "150"></item>
<item name="终点" code="EAddr" type="string" width = "150"></item>
<item name="线路名" code="Name" type="string" width = "150"></item>
<item name="终点经纬度" code="End" type="string" width = "150"></item>
<item name="收藏时间" code="Time" type="string" width = "150"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Info(){
    this.ID = "";
    this.DataState = "Normal";
}
function Walk() {
    this.ID = "";
    this.Start = "";
    this.SAddr = "";
    this.End = "";
    this.EAddr = "";
    this.Distance = "";
    this.Duration = "";
    this.Avg = "";
    this.Max = "";
    this.Cal = "";
    this.Title = "";
    this.Desc = "";
    this.DataState="Normal";
}
function Car() {
    this.ID = "";
    this.Start = "";
    this.SAddr = "";
    this.End = "";
    this.EAddr = "";
    this.Distance = "";
    this.Duration = "";
    this.Avg = "";
    this.Max = "";
    this.Title = "";
    this.Desc = "";
    this.DataState="Normal";
}
function Location() {
    this.Start = "";
    this.POI = "";
    this.Addr = "";
    this.Time = "";
    this.ID = "";
    this.POIType = "";
    this.DataState="Normal";
}
function POI() {
    this.Key = "";
    this.Location = "";
    this.Time = "";
    this.DataState="Normal";
}
function Route() {
    this.STart = "";
    this.SAddr = "";
    this.End = "";
    this.EAddr = "";
    this.Time = "";
    this.DataState="Normal";
}
function FavPOI() {
    this.Name = "";
    this.ID = "";
    this.Location = "";
    this.LatLng = "";
    this.Time = "";
    this.DataState="Normal";
}
function FavRoute() {
    this.Start = "";
    this.SAddr = "";
    this.EAddr = "";
    this.Name = "";
    this.End = "";
    this.Time = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
     var news = new TreeNode();
     news.Text = "百度地图";
    news.Type = "Info"; 
    //accountinfo = getAccount(db1);
    //news.Items = accountinfo;
    news.DataState = "Normal";
    
    var news1 = new TreeNode();
    news1.Text = "账号";
    news1.Type = "Info";
    accountinfo = getInfo(db);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    
    var walk = new TreeNode() ;
    walk.Text = "步行导航";
    walk.Type = "Walk"; 
    walk.Items = getWalk(db1);
    news.TreeNodes.push(walk);    
    
    var car = new TreeNode() ;
    car.Text = "驾车导航";
    car.Type = "Car"; 
    car.Items = getCar(db1);
    news.TreeNodes.push(car);
    
    var location = new TreeNode() ;
    location.Text = "定位信息";
    location.Type = "Location"; 
    location.Items = getLocation(db1);
    news.TreeNodes.push(location);
    
    var poi = new TreeNode() ;
    poi.Text = "地点搜索";
    poi.Type = "POI"; 
    poi.Items = getPOI(db2);
    news.TreeNodes.push(poi);
    
    var route = new TreeNode() ;
    route.Text = "路线搜索";
    route.Type = "Route"; 
    route.Items = getRoute(db3);
    news.TreeNodes.push(route);
    
    var favpoi = new TreeNode() ;
    favpoi.Text = "地点收藏";
    favpoi.Type = "FavPOI"; 
    favpoi.Items = getFavPOI(db4);
    news.TreeNodes.push(favpoi);
    
    var favroute = new TreeNode() ;
    favroute.Text = "路线收藏";
    favroute.Type = "FavRoute"; 
    favroute.Items = getFavRoute(db4);
    news.TreeNodes.push(favroute);
    
     result.push(news);
} 

//坐标转换
function LocationInfo(x,y){
    var a = x / 20037508.34 * 180;
    var b = y / 20037508.34 * 180; 
    var c = 180 / Math.PI * (2 * Math.atan(Math.pow(Math.E, b * Math.PI / 180)) - Math.PI / 2);
    var info = [a,c+0.1675];
    return info;
}

function getCar(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from Track_Car" ) +')');
    for(var i in data){
        var obj = new Car();
        obj.ID = data[i].guid;
        obj.SAddr = data[i].start_addr;
        var a = LocationInfo(data[i].start_lng,data[i].start_lat); 
        obj.STart = a[0] + " ; " + a[1];
        var b = LocationInfo(data[i].end_lng,data[i].end_lat);
        obj.End = b[0] + " ; " + b[1];
        obj.EAddr = data[i].end_addr;
        obj.Distance = data[i].distance;
        obj.Duration = data[i].duration;
        obj.Avg = data[i].avg_speed;
        obj.Max = data[i].max_speed;
        obj.Title = data[i].title;
        obj.Desc = data[i].desc;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getWalk(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from Track_Walk" ) +')');
    for(var i in data){
        var obj = new Walk();
        obj.ID = data[i].guid;
        obj.SAddr = data[i].start_addr;
        var a = LocationInfo(data[i].start_lng,data[i].start_lat); 
        obj.STart = a[0] + " ; " + a[1];
        var b = LocationInfo(data[i].end_lng,data[i].end_lat);
        obj.End = b[0] + " ; " + b[1];
        obj.EAddr = data[i].end_addr;
        obj.Distance = data[i].distance;
        obj.Duration = data[i].duration;
        obj.Avg = data[i].avg_speed;
        obj.Max = data[i].max_speed;
        obj.Title = data[i].title;
        obj.Cal = data[i].calorie;
        obj.Desc = data[i].desc;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getLocation(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from Track_Location T left join Track_Relation TR where T.guid = TR.guid" ) +')');
    for(var i in data){
        var obj = new Location();
        obj.ID = data[i].guid;
        var a = LocationInfo(data[i].lng,data[i].lat); 
        obj.STart = a[0] + " ; " + a[1];
        obj.POI = data[i].poi_name;
        obj.Addr = data[i].city_name+data[i].district+data[i].business+data[i].street+data[i].street_num;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ctime);
        obj.POIType = data[i].poi_type;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getPOI(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * ,cast(value as text)as a from poi_his" ) +')');
    for(var i in data){
        var obj = new POI();
        var b = eval('('+ data[i].a +')');
        //log(b);
        obj.Key = b.Fav_Content;
        obj.Location = b.Fav_L1c2;
        obj.Time = XLY.Convert.LinuxToDateTime(b.Fav_Sync.addtimesec);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getRoute(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * ,cast(value as text)as a from route_his" ) +')');
    for(var i in data){
        var obj = new Route();
       if(data[i].a.length>100){ 
        var b = eval('('+ data[i].a +')');
        var c = eval('('+ b.Fav_Content +')');
        var d = LocationInfo(c.sfavnode.geoptx,c.sfavnode.geopty);
        obj.STart = obj.LatLng = d[0] + " ; " + d[1];
        obj.SAddr = c.sfavnode.name;
        obj.EAddr = c.efavnode.name;
        var e = LocationInfo(c.efavnode.geoptx,c.efavnode.geopty);
        obj.End = e[0] + " ; " + e[1];
        obj.Time = XLY.Convert.LinuxToDateTime(b.Fav_Sync.addtimesec);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
       }
    } 
    return list;
}
function getFavPOI(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from fav_poi_main" ) +')');
    for(var i in data){
        var obj = new FavPOI()
        obj.Name = data[i].ext_name;
        obj.ID = data[i].cid;
        obj.Location = data[i].ext_content;
        var c = LocationInfo(data[i].ext_geoptx,data[i].ext_geopty);
        obj.LatLng =  c[0] + " ; " + c[1];
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ctime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);  
    }
   
    return list;
}
function getFavRoute(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from fav_route_main" ) +')');
    for(var i in data){
        var obj = new FavRoute();  
        var b = eval('('+ data[i].sfavnode +')');
        var c = LocationInfo(b.geoptx,b.geopty);
        obj.Start = c[0] + " ; " + c[1];
        obj.SAddr = b.name;
        var e = eval('('+ data[i].efavnode +')');
        var d = LocationInfo(e.geoptx,e.geopty);
        obj.End = d[0] + " ; " + d[1];
        obj.EAddr = e.name;
        obj.Name = data[i].name;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ctime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }    
   
    return list;
}
 //********************************************************
var source = $source;
var db = source[0]
var db2 = source[0]+"\\poi_his.sdb";
var db3 = source[0]+"\\route_his.sdb";
var db4 = source[1]+"\\baidumapfav.db";
var db1 = source[1]+"\\tracks.db";

//
//var db6 = "E:\\temp\\data\\data\\com.baidu.BaiduMap\\databases\\tracks.db";
//var db2 = "E:\\temp\\data\\data\\com.baidu.BaiduMap\\files\\poi_his.sdb";
//var db3 = "E:\\temp\\data\\data\\com.baidu.BaiduMap\\files\\route_his.sdb";
//var db7 = "E:\\temp\\data\\data\\com.baidu.BaiduMap\\databases\\baidumapfav.db";
//



//var db = "E:\\temp\\data\\data\\com.baidu.BaiduMap\\files";
function getInfo(db){
    var list = new Array();
    var filenames = eval('('+ XLY.File.FindFiles(db) +')');
    var info = new Array();
    for(var index in filenames){         
        var data = XLY.File.GetFileName(filenames[index]);      
        if((/^[0-9]+\_carplatform$/).test(data)) info.push(data.substring(0,data.indexOf("_")));
    }
   
 
    for(var i in info){
        var obj = new Info();
        obj.ID = info[i];
          list.push(obj);  
    }
    
     
      return list;
    
}
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;