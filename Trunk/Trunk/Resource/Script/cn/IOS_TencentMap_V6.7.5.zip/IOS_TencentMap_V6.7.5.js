﻿/*[config]
<plugin name="腾讯地图,3" group="地图公交,5" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\tencentMap.png" app="com.tencent.sosomap" version="6.7.5" description="腾讯地图" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.tencent.sosomap</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "80"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="头像链接" code="HeadUrl" type="url" width="200" format = "" ></item>
    <item name="头像本地路径" code="HeadLocalPath" type="url" width="200" format = "" ></item>
    <item name="设备信息" code="DeviceInfo" type="string" width="200" format = "" ></item>
    <item name="登录时间" code="Time" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>
<data type="Search" contract="DataState" datefilter="Time">
    <item name="开始位置名称" code="StartName" type="string" width="100" format=""></item>
    <item name="开始位置经度" code="StartLongitude" type="string" width="150" format="F6"></item>
    <item name="开始位置纬度" code="StartLatitude" type="string" width="100" format="F6" ></item> 
    <item name="开始位置地址" code="StartAddr" type="string" width="100" format=""></item>
    <item name="目的位置名称" code="EndName" type="string" width="100" format=""></item>
    <item name="目的位置经度" code="EndLongitude" type="string" width="150" format="F6"></item>
    <item name="目的位置纬度" code="EndLatitude" type="string" width="100" format="F6" ></item> 
    <item name="目的位置地址" code="EndAddr" type="string" width="100" format=""></item>
</data>
<data  type="Favorite" contract="DataState" datefilter="Time">
    <item name="地名" code="Name" type="string" width="100" ></item>
    <item name="详细地址" code="Addr" type="string" width="100" format=""></item>
    <item name="经度" code="Longitude" type="string" width="100" format="F6"></item>
    <item name="纬度" code="Latitude" type="string" width="100" format="F6"></item>
    <item name="电话" code="Phone" type="string" width="100" format=""></item>    
    <item name="分类" code="Category" type="string" width="100" format=""></item> 
</data>
<data type="Route" contract="DataState" datefilter="Time">
    <item name="街名" code="Roadname" type="string" width="100" ></item>
    <item name="转向" code="Action" type="string" width="50" format=""></item>
    <item name="路径" code="Textinfo" type="string" width="300" format=""></item>
    <item name="经度" code="Longitude" type="string" width="80" format="F6" ></item>
    <item name="纬度" code="Latitude" type="string" width="80" format="F6"></item>    
</data>
<data  type="Navigate" contract="DataState" datefilter="Time">
    <item name="导航起点" code="Start" type="string" width="150" ></item>
    <item name="导航终点" code="Dest" type="string" width="150" format=""></item>
    <item name="时间" code="Time" type="datetime" width="80" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>
<data  type="Busline" contract="DataState" datefilter="Time">
    <item name="导航起点" code="Start" type="string" width="150" ></item>
    <item name="导航终点" code="Dest" type="string" width="150" format=""></item>
    <item name="公交路线" code="Line" type="string" width="200" format=""></item>
    <item name="时间" code="Time" type="datetime" width="80" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
function UserInfo(){
    this.DataState = "Normal";
    this.UserNickName = "";
    this.HeadUrl = "";
    this.HeadLocalPath = "";
    this.DeviceInfo = "";
    this.Time = null;
}
function Navigate() {
    this.Start = "";
    this.Dest = "";
    this.Time = null;
}
function Busline() {
    this.Start = "";
    this.Dest = "";
    this.Line = "";
    this.Time = null;
}
function Search() {
    this.StartName = "";
    this.StartLongitude = "";
    this.StartLatitude = "";
    this.StartAddr = "";
    this.EndName = "";
    this.EndLongitude = "";
    this.EndLatitude = "";
    this.EndAddr = "";
}
function Route() {
    this.Roadname = "";
    this.Action = "";
    this.Textinfo = "";
    this.Longitude = "";
    this.Latitude = "";
}
function Favorite() {
    this.Name = "";
    this.Addr = "";
    this.Longitude = "";
    this.Latitude = "";
    this.Phone = "";
    this.Category = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.tencent.sosomap\\Documents";
var userPath = source[0]+"\\com.tencent.sosomap\\Library\\Preferences\\com.tencent.sosomap.plist";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.sosomap\\Documents";
//var userPath = "C:\\XLYSFTasks\\任务-2017-04-14-17-06-49\\source\\IosData\\2017-04-14-17-08-16\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.sosomap\\Library\\Preferences\\com.tencent.sosomap.plist";
//定义特征库文件
var charactor1 = "chalib\\iOS_Weibo_V6.5.1\\db_65100_6050936393.dat.charactor";
var charactor2 = "chalib\\iOS_Weibo_V6.5.1\\message_6050936393.db.charactor";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "腾讯地图";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        var reg = new RegExp(".png","i");
        if(data!=""&&data!= null){
            var obj = new UserInfo();
            for(var i in data){
                if(data[i].weichatinfo!=""&&data[i].weichatinfo!=null){
                    obj.UserNickName = data[i].weichatinfo[3].nn;
                    obj.HeadUrl = data[i].weichatinfo[2].hiurl;
                    obj.Time = XLY.Convert.LinuxToDateTime(data[i].weichatinfo[6].time);
                    //var aa = obj.Time.split("-")[0];
                    //var bb = 31+aa;
                    var headUrl = eval('('+ XLY.File.FindFileNamesWithExtension(allPath) +')');
                    if(headUrl!=""&&headUrl!=null){
                        for(var a in headUrl){
                            if(reg.test(headUrl[a])){
                                obj.HeadLocalPath = allPath + "\\" + headUrl[a];
                            }
                        }
                    }
                }
                if(data[i].machinePlatForm!=""&&data[i].machinePlatForm!=null){
                    obj.DeviceInfo = data[i].machinePlatForm;
                }
            }
            var node = new TreeNode();
            if(obj.UserNickName!=""&&obj.UserNickName!=null){
                node.Text = obj.UserNickName;
            }
            else
            {
                node.Text = "默认账户";
            }
            
            node.Type = "UserInfo";
            node.Items.push(obj);
            root.TreeNodes.push(node);
            var obj1 = new News();
            obj1.List = obj.UserNickName;
            root.Items.push(obj1);
            getUserChildNodeInfo(node);
        }
    }
}
function getUserChildNodeInfo(root){
    var allChildPath = allPath +"\\user";
    var combineoffineMapDataPath = allChildPath+"\\combineofflineMapData.dat";
    var favoritePath = allChildPath+"\\favorite.dat";
    var routeSearchHistoryPath = allChildPath+"\\routesearchistorypath.dat";
    var startUp2Path = allChildPath+"\\startup2.dat";
    if(XLY.File.IsValid(combineoffineMapDataPath)){
        var dataCombin = eval('('+ XLY.File.ReadFile(combineoffineMapDataPath) +')');
        
    }
    if(XLY.File.IsValid(favoritePath)){
        var dataFavorite = eval('('+ XLY.File.ReadFile(favoritePath) +')');
        if(dataFavorite!=""&&dataFavorite!= null){
            if(dataFavorite.fav_list!=""&&dataFavorite.fav_list!= null){
                var nodeF = new TreeNode();
                nodeF.Text = "收藏夹";
                nodeF.Type = "Favorite"; 
                for(var i in dataFavorite.fav_list){
                    var obj = new Favorite();
                    obj.Name = dataFavorite.fav_list[i].name;
                    obj.Addr = dataFavorite.fav_list[i].content.addr;
                    obj.Longitude = dataFavorite.fav_list[i].content.xpinfo.x;
                    obj.Latitude = dataFavorite.fav_list[i].content.xpinfo.y;
                    obj.Phone = dataFavorite.fav_list[i].content.phone;
                    obj.Category = dataFavorite.fav_list[i].content.classes;
                    nodeF.Items.push(obj);
                }
                if(nodeF.Items!=""&&nodeF.Items!=null){
                    root.TreeNodes.push(nodeF);
                }
            }
        }
    }
    if(XLY.File.IsValid(routeSearchHistoryPath)){
        var dataRouteSearc = eval('('+ XLY.File.ReadFile(routeSearchHistoryPath) +')');
        if(dataRouteSearc!=""&&dataRouteSearc!= null){
            if(dataRouteSearc.routesearchistory!=""&&dataRouteSearc.routesearchistory!= null){
                var nodeS = new TreeNode();
                nodeS.Text = "搜索路线";
                nodeS.Type = "Search"; 
                for(var i in dataRouteSearc.routesearchistory){
                    var obj = new Search();
                    obj.StartName = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathStart.name;
                    obj.StartLongitude = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathStart.pointx;
                    obj.StartLatitude = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathStart.pointy;
                    obj.StartAddr = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathStart.addr;
                    obj.EndName = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathEnd.name;
                    obj.EndLongitude = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathEnd.pointx;
                    obj.EndLatitude = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathEnd.pointy;
                    obj.EndAddr = dataRouteSearc.routesearchistory[i].RouteSearchHistoryPathEnd.addr;
                    nodeS.Items.push(obj);
                }
                if(nodeS.Items!=""&&nodeS.Items!=null){
                    root.TreeNodes.push(nodeS);
                }
            }
        }
    }
    if(XLY.File.IsValid(startUp2Path)){
        var dataStartUp = eval('('+ XLY.File.ReadFile(startUp2Path) +')');
    }
}