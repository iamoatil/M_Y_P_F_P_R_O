﻿/*[config]
<plugin name="悠悠驾车,10" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\uu.png" app="com.uu.uueeye" version="3.3.17" description="悠悠驾车" data="$data,ComplexTreeDataSource" >
<source>
    <value>/mnt/sdcard/uueeye/edbf#F</value>
</source>
<data type="Info" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Eeye" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="经度" code="Lat" type="string" width = "150"></item>
<item name="纬度" code="Lon" type="string" width = "150"></item>
<item name="名称" code="Name" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="限速" code="Speed" type="string" width = "200"></item>
<item name="类型" code="Type" type="string" width = "200"></item>
</data>
<data type="Point" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="经度" code="Lat" type="string" width = "150"></item>
<item name="纬度" code="Lon" type="string" width = "150"></item>
<item name="名称" code="Name" type="string" width = "150"></item>
<item name="位置" code="Address" type="string" width = "200"></item>
<item name="电话" code="Phone" type="string" width = "200"></item>
<item name="收藏时间" code="Time" type="string" width = "200"></item>
<item name="ID" code="ID" type="string" width = "200"></item>
<item name="描述" code="Description" type="string" width = "200"></item>
</data>
<data type="Place" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="经度" code="Lat" type="string" width = "150"></item>
<item name="纬度" code="Lon" type="string" width = "150"></item>
<item name="地点名称" code="PName" type="string" width = "150"></item>
<item name="位置" code="Address" type="string" width = "200"></item>
<item name="添加时间" code="Time" type="string" width = "200"></item>
<item name="名称" code="Name" type="string" width = "150"></item>
</data>
<data type="Vehide" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
<item name="省" code="Province" type="string" width = "200"></item>
<item name="车牌号" code="Num" type="string" width = "200"></item>
<item name="燃油类型" code="Type" type="string" width = "200"></item>
<item name="车品牌" code="Model" type="string" width = "200"></item>
<item name="图片路径" code="Offen" type="string" width = "200"></item>
<item name="发动机号" code="Enginer" type="string" width = "200"></item>
<item name="车辆识别码" code="Framemo" type="string" width = "200"></item>
<item name="添加时间" code="Time" type="string" width = "200"></item>
<item name="查询违章的城市" code="City" type="string" width = "200"></item>
<item name="车辆购买日期" code="Date" type="string" width = "200"></item>
</data>
<data type="Foot" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Key" type="string" width = "150"></item>
<item name="距离" code="Distance" type="string" width = "150"></item>
<item name="收藏时间" code="Time" type="string" width = "200"></item>
<item name="定位" code="Location" type="string" width = "150"></item>
<item name="链接" code="Url" type="string" width = "200"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="经度" code="Lat" type="string" width = "150"></item>
<item name="纬度" code="Lon" type="string" width = "150"></item>
<item name="名称" code="Name" type="string" width = "150"></item>
<item name="位置" code="Address" type="string" width = "200"></item>
<item name="电话" code="Phone" type="string" width = "200"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Info(){
    this.ID = "";
    this.DataState = "Normal";
}
function Eeye() {
    this.Lat = "";
    this.Lon = "";
    this.Name = "";
    this.ID = "";
    this.Speed = "";
    this.Type = "";
    this.DataState="Normal";
}
function Point() {
    this.Lat = "";
    this.Lon = "";
    this.Name = "";
    this.Address = "";
    this.Phone = "";
    this.Time = "";
    this.ID = "";
    this.Description = "";
    this.DataState="Normal";
}
function Place() {
    this.Lat = "";
    this.Lon = "";
    this.Name = "";
    this.Address = "";
    this.Phone = "";
    this.Time = "";
    this.PName = "";
    this.DataState="Normal";
}
function Vehide() {
    this.ID = "";
    this.Province = "";
    this.Num = "";
    this.Type = "";
    this.Model = "";
    this.Offen = "";
    this.Enginer = "";
    this.Framemo = "";
    this.Time = "";
    this.City = "";
    this.Date = "";
    this.DataState="Normal";
}
function Foot() {
    this.Key = "";
    this.Distance = "";
    this.Time = "";
    this.Location = "";
    this.Url = "";
    this.DataState="Normal";
}
function Search() {
    this.Lat = "";
    this.Lon = "";
    this.Name = "";
    this.Address = "";
    this.Phone = "";
    this.Time = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
     var news = new TreeNode();
     news.Text = "悠悠驾车";
    news.Type = "Info"; 
    //accountinfo = getAccount(db1);
    //news.Items = accountinfo;
    news.DataState = "Normal";
    
    var news1 = new TreeNode();
    news1.Text = "账号";
    news1.Type = "Info";
    accountinfo = getInfo(db);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    
           for(var i in accountinfo){
            var account = new TreeNode() ;
            account.Text = accountinfo[i].ID;
            account.Type = "Info"; 
            news1.TreeNodes.push(account);
            
            var dbpath = db+"\\"+accountinfo[i].ID+"\\";
            var db1 = XLY.Sqlite.DataRecovery(dbpath+"user_eeye", charactor,"user_eeye");
            var db2 = XLY.Sqlite.DataRecovery(dbpath+"mark_point", charactor1,"mark_point");
            var db3 = XLY.Sqlite.DataRecovery(dbpath+"ncplaces", charactor2,"ncplaces");
            var db4 = XLY.Sqlite.DataRecovery(dbpath+"vehicleInfo", charactor3,"vehicle_info");
            var db5 = XLY.Sqlite.DataRecovery(dbpath+"track_point", charactor4,"trackdat");
           
            

            var eeye = new TreeNode() ;
            eeye.Text = "电子眼";
            eeye.Type = "Eeye"; 
            eeye.Items = getEeye(db1);
            account.TreeNodes.push(eeye);
        
            var point = new TreeNode() ;
            point.Text = "标记点";
            point.Type = "Point"; 
            point.Items = getPoint(db2);
            account.TreeNodes.push(point);
        
            var place = new TreeNode() ;
            place.Text = "常用地点";
            place.Type = "Place"; 
            place.Items = getPlace(db3);
            account.TreeNodes.push(place);
            
            var vehide = new TreeNode() ;
            vehide.Text = "车辆信息";
            vehide.Type = "Vehide"; 
            vehide.Items = getVehide(db4);
            account.TreeNodes.push(vehide);
            
            var foot = new TreeNode() ;
            foot.Text = "足迹";
            foot.Type = "Foot"; 
            foot.Items = getFoot(db5);
            account.TreeNodes.push(foot);
           }
        var db6 = XLY.Sqlite.DataRecovery(db+"\\history_destinationination", charactor5,"history_destination");
            var search = new TreeNode() ;
            search.Text = "导航搜索历史";
            search.Type = "Search"; 
            search.Items = getSearch(db6);
            news1.TreeNodes.push(search);
     result.push(news);
} 


function getEeye(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from user_eeye" ) +')');
    for(var i in data){
        var obj = new Eeye();
        obj.Lat = data[i].lat;
        obj.Lon = data[i].lon;
        obj.Name = data[i].name;
        obj.ID = data[i].eeye_uuid;
        var a = data[i].type;
        switch(a){
          case 1: 
            obj.Type = "闯红灯";
            break;
          case 4: 
            obj.Type = "限速";
            break;
          case 8: 
            obj.Type = "流动测速";
            break;
          case 11: 
            obj.Type = "违规拍照";
            break;
          default:
            obj.Type = "其他";
            break;
        }
        obj.Speed = data[i].speed;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getPoint(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from mark_point" ) +')');
    for(var i in data){
        var obj = new Point();
        obj.Lat = data[i].lat;
        obj.Lon = data[i].lon;
        obj.Name = data[i].name;
        obj.ID = data[i].user_id;
        obj.Address = data[i].address;
        obj.Phone = data[i].tele;
        obj.Description = data[i].appraise;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getPlace(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ncplaces" ) +')');
    for(var i in data){
        var obj = new Place();
        obj.Lat = data[i].lat;
        obj.Lon = data[i].lon;
        obj.PName = data[i].name;
        obj.Address = data[i].addr;
        obj.Name = data[i].expand;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getVehide(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from vehicle_info" ) +')');
    for(var i in data){
        var obj = new Vehide();
        obj.ID = data[i].vehicleUuid;
        obj.Province = data[i].lsprefix;
        obj.Num = data[i].lsnum;
        var a = data[i].oilType;
        switch(a){
          case 1: 
            obj.Type = "97汽油";
            break;
          case 2: 
            obj.Type = "93汽油";
            break;
          case 3: 
            obj.Type = "90汽油";
            break;
          case 4: 
            obj.Type = "柴油";
            break;
        }
        obj.Model = data[i].brand;
        obj.Offen = data[i].picturePath;
        obj.Enginer = data[i].engineno;
        obj.Framemo = data[i].frameno;
        obj.Date = data[i].birthday;
        obj.City = data[i].cities;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getFoot(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from trackdat" ) +')');
    for(var i in data){
        var obj = new Foot();
        obj.Key = data[i].name;
        obj.Distance = data[i].distance+" 米";
        obj.Location = data[i].loc;
        obj.Url = data[i].point_url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].stime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history_destination" ) +')');
 for(var i in data){
        var obj = new Point();
        obj.Lat = data[i].lat;
        obj.Lon = data[i].lon;
        obj.Name = data[i].name;
        obj.Address = data[i].address;
        obj.Phone = data[i].tele;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
 //********************************************************
var source = $source;
var db= source[0];
var charactor = "\\chalib\\Android_YouYouJiaChe_3.3.17\\user_eeye.charactor";
var charactor1 = "\\chalib\\Android_YouYouJiaChe_3.3.17\\mark_point.charactor";
var charactor2 = "\\chalib\\Android_YouYouJiaChe_3.3.17\\ncplaces.charactor";
var charactor3 = "\\chalib\\Android_YouYouJiaChe_3.3.17\\vehicleInfo.charactor";
var charactor4 = "\\chalib\\Android_YouYouJiaChe_3.3.17\\track_point.charactor";
var charactor5= "\\chalib\\Android_YouYouJiaChe_3.3.17\\history_destinationination.charactor";
function getInfo(db){
    var list = new Array();
    var filenames = eval('('+ XLY.File.FindDirectories(db) +')');
    //log(filenames);
    
    var info = new Array();
    for(var index in filenames){        
        var data = XLY.File.GetFileName(filenames[index]); 
        //log(data);
       info.push(data);
    }
    for(var i in info){
        var obj = new Info();
        obj.ID = info[i];
        list.push(obj);  
    }
    return list;
}
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
