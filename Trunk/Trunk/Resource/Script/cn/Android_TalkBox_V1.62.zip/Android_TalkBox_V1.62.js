﻿/*[config]
<plugin name="TalkBox,7" group="社交聊天,6" devicetype="android" pump="usb,wifi,mirror,bluetooth"  icon="/icons/talkbox.png"  app="com.gtomato.talkbox" description="TalkBox"  data="$data,ComplexTreeDataSource" version="1.62">
<source>
<value>/data/data/com.gtomato.talkbox/files#F</value>
<value>/data/data/com.gtomato.talkbox/databases#F</value>
<value>/data/data/com.gtomato.talkbox/shared_prefs/TalkBoxData.xml</value>
</source>
<data type="Talkbox" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分组" code="Name" type="string" width="600" format="" ></item>
</data>
<data type="User" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="ID" code="ID" type="string" width="80" format = ""></item>
<item name="昵称" code="Name" type="string" width="100" format = "" ></item>
<item name="邮箱" code="Email" type="string" width="100" format = "" ></item>
<item name="电话" code="Call" type="string" width="100" format = "" ></item>
<item name="学校" code="School" type="string" width="100" format = "" ></item>
<item name="公司" code="Company" type="string" width="100" format = "" ></item>
<item name="城市" code="City" type="string" width="100" format = "" ></item>
<item name="国籍" code="Country" type="string" width="100" format = "" ></item>
<item name="最后登陆时间" code="Time" type="datetime" width="140" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Contact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="昵称" code="Name" type="string" width="" format = ""></item>
<item name="全称" code="Displayname" type="string" width="" format = ""></item>
<item name="头像" code="Image" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string" width="" format="" show="false"></item>
</data>
<data type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="昵称" code="Name" type="string" width="80" format = ""></item>
<item name="成员" code="Member" type="string" width="500" format = ""></item>
<item name="ID" code="ID" type="string" width="" format="" show = "false"></item>

</data>
<data type="Message" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="发送人" code="Sender" type="string" width="100" format=""></item>
<item name="接收人" code="Target" type="string" width="100" format=""></item>
<item name="会话内容" code="Content" type="string" width="300" format = ""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order = "asc"></item>
<item name="消息类型" code="MsgType" type="string" format="" width="60"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="Enum" format="EnumSendState"  show="false"></item>
</data>
</plugin>
[config]*/

//******************************************定义数据结构******************************************

function Talkbox()
{
    this.Name = "";
    this.DataState="Normal";
}

function User()
{
    this.ID = "";
    this.Name = "";
    this.Email = "";
    this.Call = "";
    this.School = "";
    this.Company = "";
    this.City = "";
    this.Country = "";
    this.Time = "";
    this.DataState="Normal";
}

function Contact()
{
    this.ID = "";
    this.Name = "";
    this.Displayname = "";
    this.Image = "";
    this.DataState="Normal";
}

function Group()
{
    this.ID = "";
    this.Name = "";
    this.Member = "";
    this.DataState="Normal";
}

function Message()
{
    this.Sender = "";
    this.Target = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
    this.Type = "";
    this.MsgType = "";
    this.SendState = "";
}


//定义树结构
function TreeNode() 
{
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

function bindTree(result){
    var filename = getFilename(db);
    for(var i in filename){
        var userinfo = getUser(filename[i]);
        var user = new TreeNode();
        user.Text = userinfo[0].Name;
        user.Type = "User";
        user.Items = userinfo;
        buildChildNodeForAccount(user,filename[i],userinfo[0]);
        result.push(user);
    }
}

function getFilename(path){
    var list = new Array();
    var file = eval('('+ XLY.File.FindDirectories(path) +')');
    for(var i in file){
        var reg = /AccountData/i;
        var filename = XLY.File.GetFileName(file[i]);
        if(reg.test(filename)){
            dbpath = file[i]+"\\contacts.db";
            list.push(dbpath);
        }
    }
    return list;
}

function getUser(path){
    var list = new Array();
    var countrypath = db1+"\\countryCode.sqlite";
    var data = eval('('+ XLY.Sqlite.FindByName(path,'user' ) +')');
    for(var i in data){
        var obj = new User();
        obj.ID = data[i].tbId;
        obj.Name = data[i].firstname+data[i].lastname;
        obj.Email = data[i].email;
        obj.Call = data[i].phone;
        obj.School = data[i].school;
        obj.Company = data[i].company;
        obj.City = data[i].city;
        //var info = eval('('+ XLY.Sqlite.Find(countrypath,"select * from countryCode where countryCode = '"+data[i].countryCode+"'") +')');
        //if(info != null){
        //    log(info);
        //    obj.Country = info[0].countryName;
        //}
        var userinfo = eval('('+ XLY.File.ReadXML(timepath) +')');
        var loginDate = userinfo.map.long;
        var username = userinfo.map.string;
        //log(username);
        for(var index in username){
            if(username[index]['@name']=="Username"){
            }
        }
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//创建树结构
function createTreeNode(text, type) {
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

//创建帐号子节点
function buildChildNodeForAccount(root,path,data){
    var contact = createTreeNode("好友列表","Contact");
    contact.Items = getContactInfo(path);
    var contactinfo = getContactInfo(path);
        for(var j in contactinfo){
            var friend = new TreeNode();
            friend.Text = contactinfo[j].Name;
            friend.Type = "Message";
            friend.Items = getMessage(data,contactinfo[j],"好友消息");
            contact.TreeNodes.push(friend);
        }
    
    var group = createTreeNode("群组列表","Group");
    buildChildNodeForGroup(group,path,data);
    
    root.TreeNodes.push(contact);
    root.TreeNodes.push(group);
}


//创建群组子节点
function buildChildNodeForGroup(node,path,root){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from groupName") +')');
    for(var num in data){
        var grouplist = createTreeNode(data[num].groupName,"Message");
        grouplist.Items = getMessage(root,data[num],"",path);
        node.Items.push(getGrouplistInfo(data[num],path));
        node.TreeNodes.push(grouplist);
    }
}

//获取好友列表信息
function getContactInfo(path){
   var data = eval('('+ XLY.Sqlite.Find(path,"select * from contactList ") +')');
   var list = new Array();
    for(var i in data){
        var obj = new Contact();
        obj.ID = data[i].tbId;
        obj.Name = data[i].username;
        obj.Displayname = data[i].displayName;
        obj.Image = data[i].avatarUrl;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取群组成员信息
function getGrouplistInfo(key,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from groupList where gpId = '"+key.gpId+"'") +')');
    var obj = new Group();
    obj.Name = key.groupName;
    for(var index in data){
        obj.Member += data[index].displayName+"("+data[index].tbId+")"+";  ";
    }      
    obj.DataState = XLY.Convert.ToDataState(key.XLY_DataType);
    return obj;
}

//获取消息
function getMessage(data1,data2,flag,path){
    var list = new Array();
    var dbmsg = db1+"\\"+data1.ID+"_conversations.db";
    if(flag=="好友消息"){
        var tblname = "msgs_history_P"+data2.ID;
        var tblinfo = eval('('+ XLY.Sqlite.Find(dbmsg,"select * from conversations where tb_id = '"+data2.ID+"'") +')');
    }else{
        var tblname = "msgs_history_GP"+data2.gpId;
        var tblinfo = eval('('+ XLY.Sqlite.Find(dbmsg,"select * from conversations where tb_id = '"+data2.gpId+"'") +')');
    }
    if(tblinfo.length>0){
        var msg = eval('('+ XLY.Sqlite.Find(dbmsg,"select cast(msg_time as text) as time,* from '"+tblname+"'") +')');            
        for(var i in msg){
            var obj = new Message();
            if(flag=="好友消息"){
                if(msg[0].sender_id==data2.ID||msg[0].receiver_id==data2.ID){                
                    if(msg[0].sender_id==data1.ID){
                        obj.Sender = data1.Name;
                        obj.Target = data2.Name;
                        obj.SendState = "Send";
                    }else{
                        obj.Sender = data2.Name;
                        obj.Target = data1.Name;
                        obj.SendState = "Receive";
                    }
                    getMsgType(msg[i],obj);
                    obj.Time = XLY.Convert.LinuxToDateTime(msg[i].time);
                    obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                    list.push(obj);
                }
            }else{
                if(msg[i].sender_id==data1.ID){
                    obj.Sender = data1.Name;
                    obj.SendState = "Send";
                }else{
                    var send = eval('('+ XLY.Sqlite.Find(path,"select * from groupList where tbId='"+msg[i].sender_id+"'") +')');
                    obj.Sender = send[0].displayName;
                    obj.SendState = "Receive";
                }
                obj.Target = data2.groupName;
                getMsgType(msg[i],obj);
                obj.Time = XLY.Convert.LinuxToDateTime(msg[i].time);
                obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                list.push(obj);
            }
        }
    }
    return list;    
}

//消息类型
function getMsgType(data,root){
    var cont = data.content;
    var info = eval('('+ cont +')');
    switch(data.data_type){
        case 2:  root.Type = "HTML";root.MsgType = "文本";root.Content = data.temp_file;
        break;
        case 1: root.Type = "Image";root.MsgType = "图片";root.Content = data.meta_data+"\n手机路径："+data.temp_file;
        break;
        case 0: root.Type = "Audio";root.MsgType = "音频";root.Content = "语音时长："+data.msg_length+"s";
        break;
        default: root.Type = "HTML";root.MsgType = "其他"; root.Content = data.temp_file;
    }
}
//*****************************************************************
var result = new Array();
var source = $source;
var db = source[0];
var db1 = source[1];
var timepath = source[2];
//var db = "D:\\temp\\data\\data\\com.gtomato.talkbox\\files";
//var db1 = "D:\\temp\\data\\data\\com.gtomato.talkbox\\databases";
//var timepath = "D:\\temp\\data\\data\\com.gtomato.talkbox\\shared_prefs\\TalkBoxData.xml";

bindTree(result);
var res = JSON.stringify(result);
res;
