﻿/*[config]
<plugin name="LinkedIn,10" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\LinkedIn.png" app="com.linkedin.Zephyr" version="6.0.19" description="LinkedIn" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.linkedin.Zephyr</value>
</source>
<data type="Account" contract = "DataState">
<item name="账号" code="ID" type="string" width = "120" ></item>
</data>
<data type="Fmsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="名称" code="Name" type="string" width = "120" ></item>
<item name="ID" code="ID" type="string"  width = "120" ></item>
</data>
<data type="FrMsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者" code="Sender" type="string" width="120" ></item>
<item name="接收者" code="Receiver" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="附件" code="Attatchment" type="string" width = "120" ></item>
<item name="附件类型" code="Type" type="string" width = "120" ></item>
<item name="链接" code="Url" type="string" width = "120" ></item>
<item name="表情" code="Emoji" type="string" width = "120" ></item>
</data>
</plugin>
[config]*/
function Account() {
    this.ID = "";
}
function Fmsg() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
}
function FrMsg() {
    this.DataState = "Normal";
    this.Sender = "";
    this.Emoji = "";
    this.Receiver = "";
    this.Time = "";
    this.Attatchment = "";
    this.Content = "";
    this.Type = "";
    this.Url = "";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "LinkedIn";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
 for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].ID;
        account.Type = "Account"; 
        news.TreeNodes.push(account);
        
        var msg = new  TreeNode();
        msg.Text = "消息";
        msg.Type = "Fmsg";
        msginfo = getFmsg(db2);
        msg.Items = msginfo;
        msg.DataState = "Normal";
        account.TreeNodes.push(msg);
        
           for(var k in msginfo){  
            var fmsg = new TreeNode();
            fmsg.Text = msginfo[k].Name;     
            fmsg.Type = "FrMsg";
            fmsg.Items = getFrMsg(db2,msginfo[k],accountinfo);              
            fmsg.DataState = "Normal";    
            msg.TreeNodes.push(fmsg);
           }       
 }   
      result.push(news);
} 
 function getAccount(path){
    var list = new Array();
    var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
    for(var i in data ){
         if(data[i]["com.linkedin.hi5.username"] != null && data[i]["com.linkedin.hi5.username"] != "" ){
             var obj = new Account();
            obj.ID = data[i]["com.linkedin.hi5.username"];        
        }     
    }
       list.push(obj); 
    return list;
}
function getFmsg(path){
     var list = new Array();
     var data = eval('('+ XLY.Sqlite.Find(path,"select * from conversations_ui") +')'); 
        for(var i in data){
            var obj = new Fmsg();
            obj.Name = data[i].participants_list;
            obj.ID = data[i].conversation_id;
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
        return list;
}
function getFrMsg(path,msginfo,accountinfo){
      var list = new Array();
      var data = eval('('+ XLY.Sqlite.Find(path,"select * from events e left join message_events m on e.[_id] = m.event_id left join attachments a on a.[message_event_id] = m._id left join\
       sticker_events s on s.[event_id] = e.[_id] left join actors ac on e.actor_id = ac.[_id]  where conversation_id = '"+msginfo.ID+"'" ) +')');
        for(var i in data){
            var obj = new FrMsg();
            var sendpeople = data[i].last_name+data[i].first_name;
            if(sendpeople == msginfo.Name){
                obj.Sender = accountinfo[0].ID;
            }
            else
            {
                obj.Sender = sendpeople;
            }           
            obj.ID = data[i].remote_id;
            obj.Receiver = msginfo.Name;
            obj.Content = data[i].body;
            obj.Attatchment = data[i].file_name;
            obj.Type = data[i].media_type;
            obj.Url = data[i].url;
            obj.Emoji = data[i].media_id;
            obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp)
            obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
            list.push(obj);
        }
        return list;
}
//********************************************************
var source = $source;
var db = source[0]+"\\com.linkedin.Zephyr\\Library\\Preferences\\com.linkedin.Zephyr.plist";
var db2 = source[0]+"\\com.linkedin.Zephyr\\Documents\\Messenger.sqlite";
//var db = "D:\\temp\\data\\data\\com.linkedin.Zephyr\\Library\\Preferences\\com.linkedin.Zephyr.plist";
//var db2 ="D:\\temp\\data\\data\\com.linkedin.Zephyr\\Documents\\Messenger.sqlite";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
