﻿/*[config]
<plugin name="支付宝,7" group="生活旅游,6" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/ZhiFuBaoWallet.png" app="com.alipay.iphoneclient" version="10.0.15" description="支付宝" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.alipay.iphoneclient</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width = "120"></item>
    <item name="账号" code="Account" type="string" width="120"></item>
    <item name="全称" code="FullName" type="string" width="120"></item>
    <item name="头像" code="HeadUrl" type="url" width = "120"></item>
    <item name="昵称" code="NickName" type="string" width = "100"></item>
    <item name="备注名称" code="MemoName" type="string" width = "100"></item>
    <item name="备注" code="Remark" type="string" width = "100"></item>
    <item name="性别" code="Gender" type="string" width = "100"></item>
    <item name="是否是好友" code="IsFriend" type="string" width = "100"></item>
    <item name="签名" code="SignaTrue" type="string" width = "100"></item>
    <item name="用户等级" code="UserGrade" type="string" width = "100"></item>
    <item name="添加来源" code="AddSource" type="string" width = "100"></item>
    <item name="所在地" code="Area" type="string" width = "100"></item>
    <item name="是否实名" code="IsRealNameStatus" type="string" width = "100"></item>
    <item name="真实姓名是否可见" code="IsRealNameVisible" type="string" width = "100"></item>
    <item name="电话号码" code="RemarkPhone" type="string" width = "100"></item>
    <item name="可见的支付宝账号" code="ExposedAlipayAccount" type="string" width = "100"></item>
</data>
<data type="GroupList" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群组ID" code="GroupId" type="string" width="150"></item>
    <item name="群组名" code="GroupName" type="string" width="120"></item>
    <item name="群组头像" code="GroupImageUrl" type="url" width="120"></item>
    <item name="创建时间" code="CreateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="群主ID" code="GroupMasterID" type="string" width="120"></item>
    <item name="群主名" code="GroupMasterName" type="string" width="120"></item>
    <item name="群组人数上限" code="Threshold" type="string" width="120"></item>
    <item name="权限" code="PermissionsDesc" type="string" width="120"></item>
</data>
<data type = "GroupMember" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="ID" code="Id" type="string" width = "80" ></item>
    <item name="名称" code="Name" type="string" width = "80" ></item>
</data>
<data type = "ContactAdd" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="用户ID" code="UserId" type="string" width = "120" ></item>
    <item name="全称" code="FullName" type="string" width = "120" ></item>
    <item name="账号" code="Account" type="string" width = "120" ></item>
    <item name="头像" code="HeadUrl" type="url" width = "120" ></item>
    <item name="昵称" code="NickName" type="string" width = "120" ></item>
    <item name="性别" code="Gender" type="string" width = "80" ></item>
    <item name="备注" code="Message" type="string" width = "120" ></item>
    <item name="创建时间" code="CreateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="已读" code="IsRead" type="string" width = "80" ></item>
    <item name="类型" code="MessageType" type="string" width = "120" ></item>
    <item name="行为" code="Action" type="string" width = "120" ></item>
    <item name="来源" code="SourceDec" type="string" width = "120" ></item>
    <item name="已实名" code="IsRealNameStatus" type="string" width = "120" ></item>
    <item name="真实姓名是否可见" code="IsRealNameVisible" type="string" width = "120" ></item>
</data>
<data type = "Chat" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="消息ID" code="MsgId" type="string" width = "120" ></item>
    <item name="发送者ID" code="SenderId" type="string" width = "120" ></item>
    <item name="发送者名称" code="SenderName" type="string" width = "120" ></item>
    <item name="接收者ID" code="ReceiveId" type="string" width = "120" ></item>
    <item name="接收者名称" code="ReceiveName" type="string" width = "120" ></item>
    <item name="模板代码" code="TemplateCode" type="string" width = "120" ></item>
    <item name="模板数据" code="TemplateData" type="string" width = "120" ></item>
    <item name="内容" code="BizMemo" type="string" width = "120" ></item>
    <item name="类型" code="ToType" type="string" width = "120" ></item>
    <item name="链接" code="Linke" type="url" width = "120" ></item>
    <item name="发送时间" code="SendTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
</data>
</plugin>
[config]*/
function ContactAdd(){
    this.DataState = "Normal";
    this.UserId = "";
    this.FullName = "";
    this.Account = "";
    this.HeadUrl = "";
    this.NickName = "";
    this.Gender = "";
    this.Message = "";
    this.CreateTimeId = null;
    this.IsRead = "";
    this.MessageType = "";
    this.Action = "";
    this.SourceDec = "";
    this.IsRealNameStatus = "";
    this.IsRealNameVisible = "";
}
function Chat(){
    this.DataState = "Normal";
    this.MsgId = "";
    this.SenderId = "";
    this.SenderName = "";
    this.ReceiveId = "";
    this.ReceiveName = "";
    this.TemplateCode = "";
    this.TemplateData = "";
    this.BizMemo = "";
    this.ToType = "";
    this.Linke = "";
    this.SendTime = null;
}
function GroupMember(){
    this.DataState = "Normal";
    this.Id = "";
    this.Name = "";
}
function GroupList() {
    this.DataState = "Normal";
    this.GroupId = "";
    this.GroupName = "";
    this.GroupImageUrl = "";
    this.CreateTime = "";
    this.GroupMasterID = "";
    this.GroupMasterName = "";
    this.Threshold = "";
    this.PermissionsDesc = "";
}
//定义数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.Account = "";
    this.FullName = "";
    this.HeadUrl = "";
    this.NickName = "";
    this.MemoName = "";
    this.Remark = "";
    this.Gender = "";
    this.IsFriend = "";
    this.SignaTrue = "";
    this.UserGrade = "";
    this.AddSource = "";
    this.Area = "";
    this.IsRealNameStatus = "";
    this.IsRealNameVisible = "";
    this.RemarkPhone = "";
    this.ExposedAlipayAccount = "";
}

function News(){
    this.DataState = "Normal";
    this.List = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var upath = source[0]+"\\com.alipay.iphoneclient\\Documents\\Contact";
var chatPath = source[0]+"\\com.alipay.iphoneclient\\Documents\\Chat";
//测试数据
//var upath = "C:\\XLYSFTasks\\任务-2017-06-08-09-54-08\\source\\IosData\\2017-06-08-09-54-40\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.alipay.iphoneclient\\Documents\\Contact";
//var chatPath = "C:\\XLYSFTasks\\任务-2017-06-08-09-54-08\\source\\IosData\\2017-06-08-09-54-40\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.alipay.iphoneclient\\Documents\\Chat";
//
//定义特征库文件
var charactor1 = "chalib\\iOS_ZhiFuBao_V10.0.15\\2a401d838bceb5af.db.charactor";
var charactor2 = "chalib\\iOS_ZhiFuBao_V10.0.15\\2a401d838bceb5af1.db.charactor";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "支付宝";
    root.Type = "";
    getNews(root);
    result.push(root);
}
function getNews(root){
    var dataFileName = eval('('+ XLY.File.FindFileNamesWithExtension(upath) +')');
    if(dataFileName!=""&&dataFileName!=null){
        for(var i in dataFileName){
            var contactPath1 = upath+"\\"+dataFileName[i];
            if(XLY.File.IsValid(contactPath1)){
                var contactPath = XLY.Sqlite.DataRecovery(contactPath1,charactor2,"ap_group_list,ap_socialtag_list,contact_account_list,contact_hello_friend");
                if(XLY.File.IsValid(contactPath)){
                    var data = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,userID,account,fullName,headUrl,nickName,sourceCode,memoName,gender,isMyFriend,signature,userGrade,source,area,province,realNameStatus,showRealName,realNameVisible,remarkPhonesJson,exposedAlipayAccount from contact_account_list") +')');
                    if(data!=""&&data!=null){
                        var nodeUser = new TreeNode();
                        var nodeContact = new TreeNode();
                        nodeContact.Text = "联系人";
                        nodeContact.Type = "UserInfo";
                        for(var j in data){
                            var objUser = new UserInfo();
                            objUser.DataState = XLY.Convert.ToDataState(data[j].XLY_DataType);
                            objUser.UserId = data[j].userID;
                            objUser.Account = data[j].account;
                            objUser.FullName = data[j].fullName;
                            objUser.HeadUrl = data[j].headUrl;
                            objUser.NickName = data[j].nickName;
                            objUser.MemoName = data[j].memoName;
                            var remark = eval('('+ XLY.Sqlite.Find(contactPath,"select socialTag from ap_socialtag_list where userId = '"+data[j].userID+"'") +')');
                            if(remark!=""&&remark!=null){
                                objUser.Remark = remark[0].socialTag;
                            }
                            if(data[j].gender=="m"){
                                objUser.Gender = "男";
                            }
                            else if(data[j].gender=="F"){
                                objUser.Gender = "女";
                            }
                            else
                            {
                                objUser.Gender = "未指定";
                            }
                            if(data[j].isMyFriend==1){
                                objUser.IsFriend = "是";
                            }
                            else
                            {
                                objUser.IsFriend = "否";
                            }
                            
                            objUser.SignaTrue = data[j].signature;
                            objUser.UserGrade = data[j].userGrade;
                            objUser.AddSource = data[j].source;
                            objUser.Area = data[j].area+" "+data[j].province;
                            if(data[j].realNameStatus=="Y"){
                                objUser.IsRealNameStatus = "是";
                            }
                            else
                            {
                                objUser.IsRealNameStatus = "否";
                            }
                            if(data[j].realNameVisible=="1"){
                                objUser.IsRealNameVisible = "真实姓名可见";
                            }
                            else
                            {
                                objUser.IsRealNameVisible = "对方隐藏真实姓名";
                            }
                            objUser.RemarkPhone = data[j].remarkPhonesJson;
                            objUser.ExposedAlipayAccount = data[j].exposedAlipayAccount;
                            if(data[j].sourceCode=="unknow"||data[j].sourceCode==""){
                                nodeUser.Text = data[j].userID+"_"+data[j].nickName;//data[j].account+"_"+data[j].fullName;
                                nodeUser.Type = "UserInfo";
                                nodeUser.Items.push(objUser);
                            }
                            else
                            {
                                nodeContact.Items.push(objUser);
                            }
                        }
                        var nodeGroup = new TreeNode();
                        nodeGroup.Text = "群组信息";
                        nodeGroup.Type = "GroupList";
                        getNodeGroupInfo(nodeGroup,contactPath);
                        
                        var nodeChat = new TreeNode();
                        nodeChat.Text = "聊天记录";
                        nodeChat.Type = "Chat";
                        getNodeChatInfo(nodeChat,contactPath,dataFileName[i],nodeUser.Text);
                        
                        var nodeContactAdd = new TreeNode();
                        nodeContactAdd.Text = "好友请求";
                        nodeContactAdd.Type = "ContactAdd";
                        
                        var dataContactAdd = eval('('+ XLY.Sqlite.Find(contactPath,"select XLY_DataType,userID,fullName,account,headUrl,nickName,gender,message,createTime,isRead,messageType,action,sourceDec,realNameStatus,realNameVisible from contact_hello_friend") +')');
                        if(dataContactAdd!=""&&dataContactAdd!=null){
                            for(var y in dataContactAdd){
                                var objContactAdd = new ContactAdd();
                                objContactAdd.DataState = XLY.Convert.ToDataState(dataContactAdd[y].XLY_DataType);
                                objContactAdd.UserId = dataContactAdd[y].userID;
                                objContactAdd.FullName = dataContactAdd[y].fullName;
                                objContactAdd.Account = dataContactAdd[y].account;
                                objContactAdd.HeadUrl = dataContactAdd[y].headUrl;
                                objContactAdd.NickName = dataContactAdd[y].nickName;
                                if(dataContactAdd[y].gender=="m"){
                                    objContactAdd.Gender = "男";
                                }
                                else if(dataContactAdd[y].gender=="f")
                                {
                                    objContactAdd.Gender = "女";
                                }
                                else
                                {
                                    objContactAdd.Gender = "未指定";
                                }
                                objContactAdd.Message = dataContactAdd[y].message;
                                objContactAdd.CreateTimeId = XLY.Convert.LinuxToDateTime(dataContactAdd[y].createTime);
                                if(dataContactAdd[y].isRead==true){
                                    objContactAdd.IsRead = "是";
                                }
                                else
                                {
                                    objContactAdd.IsRead = "否";
                                }
                                
                                objContactAdd.MessageType = dataContactAdd[y].messageType;
                                objContactAdd.Action = dataContactAdd[y].action;
                                objContactAdd.SourceDec = dataContactAdd[y].sourceDec;
                                if(dataContactAdd[y].realNameStatus=="Y"){
                                    objContactAdd.IsRealNameStatus = "是";
                                }
                                else
                                {
                                    objContactAdd.IsRealNameStatus = "否";
                                }
                                if(dataContactAdd[y].realNameVisible==1){
                                    objContactAdd.IsRealNameVisible = "是";
                                }
                                else
                                {
                                    objContactAdd.IsRealNameVisible = "否";
                                }
                                nodeContactAdd.Items.push(objContactAdd);
                            }
                        }
                        if(nodeContact.Items!=""&&nodeContact.Items!=null){
                            nodeUser.TreeNodes.push(nodeContact);
                        }
                        if(nodeContactAdd.Items!=""&&nodeContactAdd.Items!=null){
                            nodeUser.TreeNodes.push(nodeContactAdd);
                        }
                        if(nodeGroup.Items!=""&&nodeGroup.Items!=null){
                            nodeUser.TreeNodes.push(nodeGroup);
                        }
                        if(nodeChat.TreeNodes!=""&&nodeChat.TreeNodes!=null){
                            nodeUser.TreeNodes.push(nodeChat);
                        }
                        if(nodeUser.Items!=""&&nodeUser.Items!=null){
                            root.TreeNodes.push(nodeUser);
                        }
                    }
                }
            }
        }
    }
}
function getNodeGroupInfo(root,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,groupId,groupName,groupImageUrl,memberUserIdsDesc,masterUserId,gmtCreate,threshold,permissionsDesc from ap_group_list") +')');
    if(data!=""&&data!=null){
        for(var i in data){
            var node = new TreeNode();
            node.Text = data[i].groupId+"_"+data[i].groupName;
            node.Type = "GroupMember";
            var obj = new GroupList();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.GroupId = data[i].groupId;
            obj.GroupName = data[i].groupName;
            obj.GroupImageUrl = data[i].groupImageUrl;
            obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].gmtCreate);
            obj.GroupMasterID = data[i].masterUserId;
            var masterName = eval('('+ XLY.Sqlite.Find(path,"select nickName from contact_account_list where userId = '"+data[i].masterUserId+"'") +')');
            if(masterName!=""&&masterName!=null){
                obj.GroupMasterName = masterName[0].nickName;
            }
            obj.Threshold = data[i].threshold;
            obj.PermissionsDesc = data[i].permissionsDesc;
            root.Items.push(obj);
            
            var aa = eval('('+ data[i].memberUserIdsDesc +')');
            for(var j in aa){
                var objMember = new GroupMember();
                objMember.Id = aa[j];
                var memberName = eval('('+ XLY.Sqlite.Find(path,"select nickName from contact_account_list where userId = '"+aa[j]+"'") +')');
                if(memberName!=""&&memberName!=null){
                    objMember.Name = memberName[0].nickName;
                }
                node.Items.push(objMember);
            }
            root.TreeNodes.push(node);
        }
    }
}
function getNodeChatInfo(root,path,fileName,temp){
    var nodeFriendChat = new TreeNode();
    nodeFriendChat.Text = "好友聊天记录";
    nodeFriendChat.Type = "";
    
    var nodeGroupChat = new TreeNode();
    nodeGroupChat.Text = "群组聊天记录";
    nodeGroupChat.Type = "";
    var chatInfoPath1 = chatPath+"\\"+fileName;
    if(XLY.File.IsValid(chatInfoPath1)){
        var tableName = eval('('+ XLY.Sqlite.Find(chatInfoPath1,"select name from sqlite_master where type = 'table'") +')');
        var reg = new RegExp("chat_");
        var reg1 = new RegExp("_list");
        var fur = "";
        if(tableName!=""&&tableName!=null){
            for(var t in tableName){
                if(reg.test(tableName[t].name)){
                    if(!reg1.test(tableName[t].name)){
                        if(t==tableName.length-1){
                            fur+= tableName[t].name;
                        }
                        else
                        {
                            fur+= tableName[t].name+",";
                        }
                    }
                }
            }
        }
        var chatInfoPath = XLY.Sqlite.DataRecovery(chatInfoPath1,charactor1,fur);
        if(XLY.File.IsValid(chatInfoPath)){
            if(tableName!=""&&tableName!=null){
                for(var i in tableName){
                    if(reg.test(tableName[i].name)){
                        if(!reg1.test(tableName[i].name)){
                            var chatId = eval('('+ XLY.Sqlite.Find(chatInfoPath,"select distinct(toUId) from '"+tableName[i].name+"'") +')');
                            if(chatId!=""&&chatId!=null){
                                if(chatId.length==1){
                                    if(chatId[0].toUId!= temp.split("_")[0]){
                                        var groupName = eval('('+ XLY.Sqlite.Find(path,"select groupName from ap_group_list where groupId = '"+chatId[0].toUId+"'") +')');
                                        if(groupName!=""&&groupName!=null){
                                            var nodeGroup = new TreeNode();
                                            nodeGroup.Text = chatId[0].toUId+"_"+groupName[0].groupName;
                                            nodeGroup.Type = "Chat";
                                            var data = eval('('+ XLY.Sqlite.Find(chatInfoPath,"select XLY_DataType,msgID,fromUId,toUId,templateCode,templateData,bizMemo,bizType,createTime,link from '"+tableName[i].name+"'") +')');
                                            if(data!=""&&data!=null){
                                                for(var j in data){
                                                    var obj = new Chat();
                                                    obj.DataState = XLY.Convert.ToDataState(data[j].XLY_DataType);
                                                    obj.MsgId = data[j].msgID;
                                                    obj.SenderId = data[j].fromUId;
                                                    var senderName = eval('('+ XLY.Sqlite.Find(path,"select nickName from contact_account_list where userId = '"+data[j].fromUId+"'") +')');
                                                    if(senderName!=""&&senderName!=null){
                                                        obj.SenderName = senderName[0].nickName;
                                                    }
                                                    obj.ReceiveId = data[j].toUId;
                                                    var receiveName = eval('('+ XLY.Sqlite.Find(path,"select groupName from ap_group_list where groupId = '"+data[j].toUId+"'") +')');
                                                    if(receiveName!=""&&receiveName!=null){
                                                        obj.ReceiveName = receiveName[0].groupName;
                                                    }
                                                    obj.TemplateCode = data[j].templateCode;
                                                    obj.TemplateData = data[j].templateData;
                                                    obj.BizMemo = data[j].bizMemo;
                                                    obj.ToType = data[j].bizType;
                                                    obj.Linke = data[j].link;
                                                    obj.SendTime = XLY.Convert.LinuxToDateTime(data[j].createTime);
                                                    nodeGroup.Items.push(obj);
                                                }
                                            }
                                            if(nodeGroup.Items!=""&&nodeGroup.Items!=null){
                                                nodeGroupChat.TreeNodes.push(nodeGroup);
                                            }
                                        }
                                    }
                                }
                                if(chatId.length==2){
                                    for(var p in chatId){
                                        if(chatId[p].toUId!= temp.split("_")[0]){
                                            var chatName = eval('('+ XLY.Sqlite.Find(path,"select nickName from contact_account_list where userId = '"+chatId[p].toUId+"'") +')');
                                            if(chatName!=""&&chatName!=null){
                                                var nodeFriend = new TreeNode();
                                                nodeFriend.Text = chatId[p].toUId+"_"+chatName[0].nickName;
                                                nodeFriend.Type = "Chat";
                                                var data = eval('('+ XLY.Sqlite.Find(chatInfoPath,"select XLY_DataType,msgID,fromUId,toUId,templateCode,templateData,bizMemo,bizType,createTime,link from '"+tableName[i].name+"'") +')');
                                                if(data!=""&&data!=null){
                                                    for(var j in data){
                                                        var obj = new Chat();
                                                        obj.DataState = XLY.Convert.ToDataState(data[j].XLY_DataType);
                                                        obj.MsgId = data[j].msgID;
                                                        obj.SenderId = data[j].fromUId;
                                                        var senderName = eval('('+ XLY.Sqlite.Find(path,"select nickName from contact_account_list where userId = '"+data[j].fromUId+"'") +')');
                                                        if(senderName!=""&&senderName!=null){
                                                            obj.SenderName = senderName[0].nickName;
                                                        }
                                                        obj.ReceiveId = data[j].toUId;
                                                        var receiveName = eval('('+ XLY.Sqlite.Find(path,"select nickName from contact_account_list where userId = '"+data[j].toUId+"'") +')');
                                                        if(receiveName!=""&&receiveName!=null){
                                                            obj.ReceiveName = receiveName[0].nickName;
                                                        }
                                                        obj.TemplateCode = data[j].templateCode;
                                                        obj.TemplateData = data[j].templateData;
                                                        obj.BizMemo = data[j].bizMemo;
                                                        obj.ToType = data[j].bizType;
                                                        obj.Linke = data[j].link;
                                                        obj.SendTime = XLY.Convert.LinuxToDateTime(data[j].createTime);
                                                        nodeFriend.Items.push(obj);
                                                    }
                                                }
                                                if(nodeFriend.Items!=""&&nodeFriend.Items!=null){
                                                    nodeFriendChat.TreeNodes.push(nodeFriend);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    root.TreeNodes.push(nodeFriendChat);
    root.TreeNodes.push(nodeGroupChat);
}