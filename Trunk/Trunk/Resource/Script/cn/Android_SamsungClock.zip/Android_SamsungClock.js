﻿/*[config]
<plugin name="闹钟,13" group="基本信息,1" devicetype="android" pump="usb,Mirror,chip,Raid" icon="\icons\clock.png" app="" manufacture="Samsung" description="" data="$data" version="">
    <source>
		<value>/data/data/com.sec.android.app.clockpackage/databases/#F</value>
    </source>
    <data contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="提示消息" code="name" type="string" width="" ></item>
        <item name="时" code="hour" type="int" width=""></item>
        <item name="分" code="minutes" type="int" width="" format=""></item>
        <item name="重复提醒" code="repeattype" type="string" width="300" format=""></item>
        <item name="是否每周重复" code="isRepeat" type="string"  format=""></item>
        <item name="是否启用" code="active" type="string" width="" ></item>
        <item name="提示铃声" code="alarmuri" type="string" width="300" ></item>
    </data>
</plugin>
[config]*/

// js content

function Item() {
    this.hour = 0; //小时
    this.minutes = 0; //分钟
    this.repeattype = ""; //重复提醒种类
    this.isRepeat = "否";
    this.active = "";//是否启用   
    this.vibrate = ""; //是否震动
    this.alarmuri = ""; //提示铃声
}


var result = new Array();
//源文件
var source = $source;

var db = source[0] + "\\alarm.db";
//var db = "D:\\temp\\data\\data\\com.sec.android.app.clockpackage\\databases\\alarm.db";

// *******************************************************************************

 // 转化为可显示的字符串
    function ToDisplayString(cDisplay, key) {
        var result = '';
        for (var i = 0; i < key.length; ++i) {
            result += cDisplay[key[i] - 1] + ';';
        }
        return result;
    }

    // 获取非重复的提醒日期字符串
    function TryGetDisPlayString(value, dic, cDisplay) {
        for (var key in dic) {
            if (dic[key] == value) {
                return ToDisplayString(cDisplay, key);
            }
        }
        return null;
    }

    // 获取重复的提醒日期字符串
    function TryGetRepeatDisplayString(value, dic, cDisplay) {
        for (var key in dic) {
            if (dic[key] == value - 4) {
                return ToDisplayString(cDisplay, key);
            }
        }
        return null;
    }

    // 生成全组合
    function Combination(dic, lsArray, selectCount) {
        var totolcount = lsArray.length;
        var currectselect = new Array();
        var last = selectCount - 1;
        for (var i = 0; i < selectCount; ++i) {
            currectselect[i] = i;
        }
        while (true) {
            var key = '';
            for (var i = 0; i < selectCount; ++i) {
                key += lsArray[currectselect[i]].toString();
            }
            dic[key] = 0;
            if (currectselect[last] < totolcount - 1) {
                currectselect[last]++;
            }
            else {
                var pos = last;
                while (pos > 0 && currectselect[pos - 1] == currectselect[pos] - 1) {
                    pos--;
                }
                if (pos == 0) {
                    return;
                }
                currectselect[pos - 1]++;
                for (var i = pos; i < selectCount; ++i) {
                    currectselect[i] = currectselect[i - 1] + 1;
                }
            }
        }
    }

    var dic = new Array();
    var cDisplay = new Array('星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期天');
    var iDisplay = new Array('1', '2', '3', '4', '5', '6', '7');
    var singleKey = new Array();
    //------------------------------------------------------------------------------------------
    singleKey['1'] = 16777217; // 2^24 + 1
    singleKey['2'] = 1048577; // 2^20 + 1
    singleKey['3'] = 65537; // 2^16 + 1
    singleKey['4'] = 4097; // 2^12 + 1
    singleKey['5'] = 257; // 2^8 + 1
    singleKey['6'] = 17; //2^4 + 1
    singleKey['7'] = 268435457; // 2^28 + 1
    //------------------------------------------------------------------------------------------
    for (var i = 1; i <= 7; ++i) {
        Combination(dic, iDisplay, i);
    }
    // 填充值
    for (var k in dic) {
        var sum = 0;
        for (var i = 0; i < k.length; ++i) {
            sum += singleKey[k[i]];
        }
        dic[k] = sum - (k.length - 1);
    }

   // document.write(TryGetDisPlayString(17891329, dic, cDisplay));


// *******************************************************************************

var db_recovery = XLY.Sqlite.DataRecovery(db, '', "alarm");

var dblist = eval('(' + XLY.Sqlite.FindByName(db_recovery, 'alarm') + ')');

for (var i in dblist) {
    var row = dblist[i];
    var obj = new Item();
    //do sth
    obj.DataState = XLY.Convert.ToDataState(row.XLY_DataType);

    obj.minutes = row.alarmtime % 100; 
    obj.hour = (row.alarmtime - obj.minutes)/100;
    
    obj.repeattype = TryGetDisPlayString(row.repeattype,dic,cDisplay);
    if(obj.repeattype==null){
         obj.repeattype = TryGetRepeatDisplayString(row.repeattype,dic,cDisplay);
         obj.isRepeat ='是';
    }

    //obj.alarmtime = XLY.Convert.LinuxToDateTime(row.alarmtime);
    obj.active = row.active == 1 ? '是' : '否';
    obj.name = row.name;
    obj.alarmuri = row.alarmuri;
    //add item
    result.push(obj);
}


// return
var res = JSON.stringify(result);
res;
