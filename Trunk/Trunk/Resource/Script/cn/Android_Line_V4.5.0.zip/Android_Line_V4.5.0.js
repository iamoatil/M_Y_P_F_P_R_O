﻿/*[config]
<plugin name="Line" group="社交聊天,6" devicetype="android" icon="\icons\line.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="jp.naver.line.android" version="4.5.0" description=" Line" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/jp.naver.line.android/databases/naver_line</value>
    <value>/data/data/jp.naver.line.android/shared_prefs/LINE_sdk_pref.xml</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Friend" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="昵称" code="Name" type="string" width = "150"></item>
    <item name="签名" code="Msg" type="string" width = "200"></item>
    <item name="添加时间" code="CTime" type="string" width = "150"></item>
    <item name="最近更新时间" code="UTime" type="string" width = "150"></item>
    <item name="ID" code="ID" type="string" show="false" width = "150"></item>
    </data>
    <data type="Group" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="群名称" code="Name" type="string" width = "150"></item>
    <item name="创建人" code="Creater" type="string" width = "200"></item>
    <item name="创建时间" code="CTime" type="string" width = "150"></item>
    <item name="ID" code="ID" type="string" show="false" width = "150"></item>
    </data>
    <data type="Message" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="发送者" code="Sender" type="string" width = "150"></item>
    <item name="接收者" code="Receiver" type="string" width = "200"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "150"></item>
    <item name="消息类型" code="Type" type="string" show="false" width = "150"></item>
    </data>
   
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Friend(){
    this.DataState = "Normal";
    this.Name = "";
    this.Msg = "";
    this.CTime = "";
    this.UTime = "";
    this.ID = "";
}
function Group(){
    this.DataState = "Normal";
    this.Name = "";
    this.Creater = "";
    this.CTime = "";
    this.ID = "";
}
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Content = "";
    this.Time = "";
    this.Type = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "Line";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    var friendinfo = getFriend(db);
    var friendNode = newTreeNode("好友","Friend",friendinfo,news);
    var ownerinfo = eval('('+ XLY.File.ReadXML(db1) +')');
    var c = JSON.stringify(ownerinfo.map.int[0]);
    var oID = c.substr(10,33);
    for(var i in friendinfo){
        newTreeNode(friendinfo[i].Name,"Message",getMessage(db,friendinfo[i],"好友",oID),friendNode);
    }
    var gourpinfo = getGroup(db);
    var gourpNode = newTreeNode("群组","Group",gourpinfo,news);
    for(var i in gourpinfo){
        newTreeNode(gourpinfo[i].Name,"Message",getMessage(db,gourpinfo[i],"群组",oID),gourpNode);
    }
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["好友","群组"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
function getFriend(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from contacts" ) +')');
    for(var i in data){
        var obj = new Friend();
        obj.Name = data[i].name;
        obj.Msg = data[i].status_msg;
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].added_time_to_friend);
        obj.UTime = XLY.Convert.LinuxToDateTime(data[i].updated_time);
        obj.ID = data[i].m_id;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from groups" ) +')');
    for(var i in data){
        var cn = eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id='"+data[i].creator+"'") +')');
        var obj = new Group();
        obj.Name = data[i].name;
        obj.Creater = cn[0].name;
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].created_time);
        obj.ID = data[i].id;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getMessage(path,forg,flag,oID){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from chat_history where chat_id = '"+forg.ID+"'" ) +')');
    var chat = eval('('+ XLY.Sqlite.Find(path,"select * from chat where chat_id = '"+forg.ID+"'" ) +')');
    var ower = eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id = '"+oID+"'" ) +')');
    for(var i in data){
        var sender = eval('('+ XLY.Sqlite.Find(path,"select * from contacts where m_id = '"+data[i].from_mid+"'" ) +')');
        var obj = new Message();
        if(flag=="好友"){
            if(data[i].chatid==data[i].from_mid){
                obj.Sender = forg.Name;
                obj.Receiver = ower[0].name;
              
            }else if(data[i].from_mid==null){
                obj.Receiver = forg.Name;
                obj.Sender=ower[0].name;
            } 
        }else{
            if(data[i].from_mid==null){
                obj.Sender=ower[0].name;
            }else{
                obj.Sender=sender[0].name;
            }
            obj.Receiver = forg.Name;
        }
        obj.Content = data[i].content;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
//var db = "D:\\temp\\data\\data\\jp.naver.line.android\\databases\\naver_line";
//var db1 = "D:\\temp\\data\\data\\jp.naver.line.android\\shared_prefs\\LINE_sdk_pref.xml";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
