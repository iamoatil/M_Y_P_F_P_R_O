﻿/*[config]
<plugin name="百度贴吧,5" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid"  icon="/icons/baidutieba.png"  app="com.baidu.tieba" description="百度贴吧"  data="$data,ComplexTreeDataSource" version="6.3.3">
<source>
<value>/data/data/com.baidu.tieba/databases/#F</value>
</source>
<data type="Tieba" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分组" code="Name" type="string" width="600" format="" ></item>
</data>
<data type="User" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="ID" code="ID" type="string" width="" format = ""></item>
<item name="昵称" code="Name" type="string" width="" format = "" ></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Contact" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="昵称" code="Name" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string" width="" format = ""></item>
</data>
<data type="Group" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="名称" code="Name" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string" width="" format = ""></item>
</data>
<data type="Message" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="发送人" code="Sender" type="string" width="100" format=""></item>
<item name="接收人" code="Target" type="string" width="100" format=""></item>
<item name="会话内容" code="Content" type="string" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order = "asc"></item>
<item name="消息类型" code="MsgType" type="Enum" format="EnumColumnType" width="60"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="Enum" format="EnumSendState"  show="false"></item>
</data>
<data type="Search" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="内容" code="Content" type="string" width="" format = ""></item>
<item name="时间" code="Time" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Post" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>
<item name="贴吧名称" code="Name" type="string" width="" format = ""></item>
<item name="主题" code="Theme" type="string" width="300" format = ""></item>
<item name="最后访问时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//******************************************定义数据结构******************************************
//定义数据结构
function Tieba()
{
    this.Name = "";
    this.DataState="Normal";
}

//定义用户信息数据结构
function User()
{
    this.ID = "";
    this.Name = "";
    this.Time="";
    this.DataState="Normal";
}

//定义好友数据结构
function Contact()
{
    this.ID = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义好友数据结构
function Group()
{
    this.ID = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义会话数据结构
function Message(){
    this.Sender = "";
    this.Target = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
    this.Type = "";
    this.MsgType = "";
    this.SendState = "";
}

//定义搜索数据结构
function Search()
{
    this.Time = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义发帖数据结构
function Post()
{
    this.Theme = "";
    this.Time = "";
    this.Name = "";
    this.DataState="Normal";
}

//定义树结构
function TreeNode() 
{
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

//******************************************定义处理数据的方法******************************************
function bindTree()
{
    var tieba = new TreeNode();
    tieba.Text = "百度贴吧";
    tieba.Type = "User";
    userinfo = getUser(dbuser);
    tieba.Items = userinfo;
    for(var i in userinfo){
        var user = new TreeNode();
        user.Text = userinfo[i].Name;
        user.Type = "Tieba";
        user.Items = getTieba();
        user.DataState = XLY.Convert.ToDataState( userinfo[i].XLY_DataType);
        tieba.TreeNodes.push(user);
        var dbmsg = getRecoveryPath(db,userinfo[i]);
        
        //创建好友树节点
        var friend = new TreeNode();
        friend.Text = "好友";
        friend.Type = "Contact";
        var dbcontact = XLY.Sqlite.DataRecovery(db+"\\relationship.db",charactor3,"table_"+userinfo[i].ID);
        var friendinfo = getContact(dbcontact,userinfo[i]);
        friend.Items = friendinfo;
        user.TreeNodes.push(friend);
        for(var j in friendinfo){
            if(friendinfo[i].ID!=null){         
                var contact = new TreeNode();
                contact.Text = friendinfo[j].Name;
                contact.Type = "Message";
                contact.Items = getMessage(dbmsg,userinfo[i],friendinfo[j],"好友消息");
                contact.DataState = XLY.Convert.ToDataState( friendinfo[j].XLY_DataType);
                friend.TreeNodes.push(contact);
            }
        } 
        //创建群组树节点
        var groupname = new TreeNode();
        groupname.Text = "群组";
        groupname.Type = "Group";
        var groupinfo = getGroup(dbmsg,userinfo[i]);
        groupname.Items = groupinfo;
        user.TreeNodes.push(groupname);
        for(var k in groupinfo){
            var group = new TreeNode();
            group.Text = groupinfo[k].Name;
            group.Type = "Message";
            group.Items = getMessage(dbmsg,userinfo[i],groupinfo[k]);
            group.DataState = XLY.Convert.ToDataState( groupinfo[k].XLY_DataType);
            groupname.TreeNodes.push(group);
        }
        //创建搜索树几点
        var search = new TreeNode();
        search.Text = "搜索";
        search.Type = "Search";
        var searchdata = getSearch(dbuser,userinfo[i]);
        search.Items = searchdata;
        user.TreeNodes.push(search);
        //创建回帖树节点
        var post = new TreeNode();
        post.Text = "浏览记录";
        post.Type = "Post";
        var dbpost = db+"\\baidu_adp.db";
        var postinfo = getPost(dbpost,userinfo[i]);
        post.Items = postinfo;
        user.TreeNodes.push(post);          
    }
    return tieba;
}

//获取用户信息
function getUser(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.FindByName(path,'account_data' ) +')');
    for(var i in data){
        var obj = new User();
        obj.ID = data[i].id;
        obj.Name = data[i].account;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//获取分组
function getTieba(){
    var list = new Array();
    var info = ["好友","群组","搜索","发帖信息"]; 
    for(var i in info){
        var obj = new Tieba();
        obj.Name = info[i];
        obj.DataState = "Normal";
        list.push(obj);
    }
    return list;
}

//获取好友信息
function getContact(path,data){
    var list = new Array();
    var tablename = "table_"+data.ID;
    var info = eval('('+ XLY.Sqlite.FindByName(path,tablename ) +')');
    if(info!=null){
        for(var i in info){
            if(info[i].id!=0){
                var obj = new Contact();
                obj.ID = info[i].id;
                obj.Name = info[i].name;
                obj.DataState = XLY.Convert.ToDataState( info[i].XLY_DataType);
                list.push(obj);
            }
        }
    }
    return list;
}

//获取群组信息
function getGroup(path,data){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select * from tb_message_center where custom_group_type = 1" ) +')');
    if(info.length>0){
        for(var i in info){
            var obj = new Group();
            obj.ID = info[i].gid;
            obj.Name = info[i].group_name;
            obj.DataState = XLY.Convert.ToDataState( info[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

function getRecoveryPath(path,data){
    var msg = path+"\\"+data.ID+".db";
    var tblinfo = eval('('+ XLY.Sqlite.Find(msg,"select distinct tbl_name from sqlite_master where tbl_name like 'tb_private_msg_%' or tbl_name like 'tb_group_msg_%'") +')');    
    var tblname = "";
    for(var index in tblinfo){
        tblname += tblinfo[index].tbl_name+","; 
    }
    var name = tblname.substr(0,tblname.length-1);
    var dbmsg = XLY.Sqlite.DataRecovery(msg,charactor4,"tb_message_center,"+name);
    return dbmsg;
}

//获取会话信息
function getMessage(path,data1,data2,flag){
    var list = new Array();
    if(flag=="好友消息"){
        var info = eval('('+ XLY.Sqlite.Find(path,"select distinct tbl_name from sqlite_master where tbl_name like 'tb_private_msg_%'") +')');
        if(info!=null){
            for(var i in info){
                if(info[i].tbl_name=="tb_private_msg_"+data2.ID){
                    var msg = eval('('+ XLY.Sqlite.Find(path,"select *,cast(content as text)as a,cast(user_info as text)as b from "+info[i].tbl_name ) +')');
                    for(var i in msg){
                        var obj = new Message();                       
                        if(msg[i].uid==data1.ID){
                            obj.Sender = data1.Name;
                            obj.Target = data2.Name;
                            obj.SendState = "Send";
                        }else{
                            obj.Sender = data2.Name;
                            obj.Target = data1.Name;
                            obj.SendState = "Receive";
                        }                        
                        if(msg[i].uid==data1.ID){
                            obj.Sender = data1.Name;
                            obj.Target = msg[i].to_uid;
                            obj.SendState = "Send";
                        }else{
                            obj.Sender = msg[i].uid;
                            obj.Target = data1.Name;
                            obj.SendState = "Receive";
                        }
                        getMsgType(msg[i],obj);
                        obj.Time = XLY.Convert.LinuxToDateTime(msg[i].create_time);
                        obj.Content = msg[i].a;
                        obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                        list.push(obj);
                    }
                }
            }
        }
    }else{
        var info1 = eval('('+ XLY.Sqlite.Find(path,"select distinct tbl_name from sqlite_master where tbl_name like 'tb_group_msg_%'") +')');
        if(info1!=null){
             for(var i in info1){
                 if(info1[i].tbl_name=="tb_group_msg_"+data2.ID){
                    var msg = eval('('+ XLY.Sqlite.Find(path,"select *,cast(content as text)as a,cast(user_info as text)as b from "+info1[i].tbl_name ) +')');
                    for(var i in msg){
                        var obj = new Message();
                        var senderinfo = eval('('+ msg[i].b +')');
                        obj.Sender = senderinfo.userName;
                        obj.Target = data2.Name;
                        if(senderinfo.userName==data1.Name){
                            obj.SendState = "Send";
                        }else{
                            obj.SendState = "Receive";
                        }
                        getMsgType(msg[i],obj);
                        obj.Time = XLY.Convert.LinuxToDateTime(msg[i].create_time);
                        obj.Content = msg[i].a;
                        obj.DataState = XLY.Convert.ToDataState(msg[i].XLY_DataType);
                        list.push(obj);
                    }
                }
             }       
        }
    }
    return list;
}

//消息类型
function getMsgType(data,root){
    switch(data.msg_type){
        case "1":  root.Type = "HTML";root.MsgType = "文本";
        break;
        case "2": root.Type = "Image";root.MsgType = "图片";
        break;
        case "3": root.Type = "Audio";root.MsgType = "音频";
        break;
        default: root.Type = "HTML";root.MsgType = "文本";  
    }
}

//获取搜索信息
function getSearch(path,data){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select * from (select key,account,time from search_data union select key,account,time from search_post_data) where account = '"+data.ID+"'" ) +')');
    if(info.length>0){
        for(var i in info){
            var obj = new Group();
            obj.Content = info[i].key;
            obj.Time = XLY.Convert.LinuxToDateTime(info[i].time);
            obj.DataState = XLY.Convert.ToDataState( info[i].XLY_DataType);
            list.push(obj);
        }
    }
    return list;
}

//获取回帖信息
function getPost(path,data){
    var list = new Array();
    var tblname = "tb.pb_history"+data.ID;
    tbl = eval('('+ XLY.Sqlite.Find(path,"select * from cache_meta_info where nameSpace = '"+tblname+"'") +')');
    var recoverydb = XLY.Sqlite.DataRecovery(path,charactor1,"cache_meta_info,"+tbl[0].tableName);
    var info = eval('('+ XLY.Sqlite.Find(recoverydb,"select cast(lastHitTime as text)as time,* from "+tbl[0].tableName) +')'); 
    for(var i in info){
        var obj = new Post();
        if(info[i].m_value.length>0){
            var value = eval('('+ info[i].m_value +')');
            obj.Theme = value.thread_name;
            obj.Name = value.forum_name+"吧";
        }
        obj.Time = XLY.Convert.LinuxToDateTime(info[i].time);
        obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//*****************************************************************
var result = new Array();
var source = $source;
var db = source[0];

//var db = "D:\\temp\\data\\data\\com.baidu.tieba\\databases";
var charactor1="\\chalib\\Android_Baidutieba_V6.3.3\\baidu_adp.db.charactor";
var charactor2="\\chalib\\Android_Baidutieba_V6.3.3\\baidu_tieba.db.charactor";
var charactor3="\\chalib\\Android_Baidutieba_V6.3.3\\relationship.db.charactor";
var charactor4="\\chalib\\Android_Baidutieba_V6.3.3\\user.db.charactor";
var dbuser = db+"\\baidu_tieba.db";
var dbsearch = XLY.Sqlite.DataRecovery(db+"\\baidu_tieba.db",charactor2,"account_data,search_data,search_post_data");


result.push(bindTree());
var res = JSON.stringify(result);
res;
