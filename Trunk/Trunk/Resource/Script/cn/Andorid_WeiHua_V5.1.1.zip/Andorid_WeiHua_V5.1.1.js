﻿/*[config]
<plugin name="微话,3" group="社交聊天,6" devicetype="android" icon="\icons\weihua.png" pump="LocalData,USB,Mirror,Wifi,Bluetooth,chip" app="com.weihua.superphone" version="5.1.1" description="微话" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.weihua.superphone/databases#F</value>
    <value>/data/data/com.weihua.superphone/shared_prefs/com.weihua.superphone_preferences.xml</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="列表" code="Account" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="用户ID" code="UserID" type="string"  width = "100"></item>
    <item name="用户名" code="UserName" type="string" width = "100"></item>
    <item name="密码" code="PassWord" type="string" width = "100"></item>
    <item name="昵称" code="NickName" type="string" width = "100"></item>
    <item name="性别" code="Sex" type="string" width = "80"></item>
    <item name="头像" code="HeadUrl" type="url" width = "120"></item>
    <item name="个性签名" code="Signature" type="string" width = "150"></item>
    <item name="最近登录时间" code="ModifyTime" type="string" width = "120"></item>
    <item name="手机号码" code="MobileNumber" type="string" width = "120"></item>
    <item name="地址" code="Address" type="string" width = "120"></item>
    <item name="是否当前登录" code="IsLoading" type="string" width = "120"></item>
</data>
<data type="FollowInfo" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="用户ID" code="UID" type="string"  width = "100"></item>
    <item name="用户名" code="UserName" type="string" width = "100"></item>
    <item name="昵称" code="NickName" type="string" width = "100"></item>
    <item name="备注" code="Remark" type="string" width = "100"></item>
    <item name="性别" code="Sex" type="string" width = "80"></item>
    <item name="出生日期" code="Birthday" type="string" width = "120"></item>
    <item name="个性签名" code="Signature" type="string" width = "150"></item>
    <item name="手机号码" code="MobileNumber" type="string" width = "120"></item>
    <item name="头像" code="HeadUrl" type="url" width = "120"></item>
    <item name="地址" code="Address" type="string" width = "120"></item>
    <item name="是否VIP" code="IsVip" type="string" width = "80"></item>
    <item name="添加时间" code="AddTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="CallLog" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="通话ID" code="CallId" type="string"  width = "100"></item>
    <item name="用户ID" code="UserID" type="string"  width = "100"></item>
    <item name="通话号码" code="PhoneNumber" type="string"  width = "120"></item>
    <item name="通话人名称" code="Name" type="string" width = "120"></item>
    <item name="通话类型" code="CallType" type="string" width = "100"></item>
    <item name="通话状态" code="CallStatus" type="string" width = "100"></item>
    <item name="通话开始时间" code="CallStartTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="通话接听时间" code="CallAcceptTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="通话结束时间" code="CallEndTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Contact" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="电话号码" code="PhoneNumber" type="string" width = "150"></item>
    <item name="名称" code="CallName" type="string" width = "120"></item>
    <item name="添加时间" code="AddTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract = "DataState" detailfield = "Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="发送者ID" code="SenderID" type="string" width = "150"></item>
    <item name="发送者" code="Sender" type="string" width = "150"></item>
    <item name="接收者ID" code="ReceiverID" type="string" width = "200"></item>
    <item name="接收者" code="Receiver" type="string" width = "200"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="CallTime" contract = "DataState" detailfield = "Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="电话号码" code="PhoneNumber" type="string" width = "120"></item>
    <item name="通话次数" code="Times" type="string" width = "80"></item>
</data>
</plugin>
[config]*/
//定义News数据结构
function News(){
    this.Account = "";
}
function CallTime(){
    this.DataState = "Normal";
    this.PhoneNumber = "";
    this.Times = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserID = "";
    this.UserName = "";
    this.NickName = "";
    this.Sex = "";
    this.Signature = "";
    this.HeadUrl = "";
    this.MobileNumber = "";
    this.Address = "";
    this.ModifyTime = "";
    this.PassWord = "";
    this.IsLoading = "";
}
//定义FollowInfo数据结构
function FollowInfo(){
    this.DataState = "Normal";
    this.UID = "";
    this.UserName = "";
    this.NickName = "";
    this.Remark = "";
    this.Sex = "";
    this.Birthday = "";
    this.Signature = "";
    this.MobileNumber = "";
    this.HeadUrl = "";
    this.Address = "";
    this.IsVip = "否";
    this.AddTime = null;
}
//定义CallLog数据结构
function CallLog(){
    this.DataState = "Normal";
    this.CallId = "";
    this.UserID = "";
    this.PhoneNumber = "";
    this.Name = "";
    this.CallType = "";
    this.CallStatus = "";
    this.CallStartTime = null;
    this.CallAcceptTime = null;
    this.CallEndTime = null;
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.PhoneNumber = "";
    this.CallName = "";
    this.AddTime = null;
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.Sender = "";
    this.ReceiverID = "";
    this.Receiver = "";
    this.Content = "";
    this.CreateTime = null;
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allDatabasePath = source[0];
var xmlPath = source[1];
//测试数据
//var allDatabasePath = "D:\\temp\\data\\data\\com.weihua.superphone\\databases";
//var xmlPath = "D:\\temp\\data\\data\\com.weihua.superphone\\shared_prefs\\com.weihua.superphone_preferences.xml";

//定义特征库文件
//var charactor1 = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Line_V7.1.1\\naver_line.charactor";
//var charactor2 = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Line_V7.1.1\\e2ee.charactor";

var charactor1 = "\\chalib\\Android_WeiHua_5.1.1\\13981910547user.db.charactor";
var charactor2 = "\\chalib\\Android_WeiHua_5.1.1\\public.db.charactor";
var charactor3 = "\\chalib\\Android_WeiHua_5.1.1\\weihua_setting.db.charactor";

//恢复数据库中删除的数据
//var naverLinePath = XLY.Sqlite.DataRecovery(naverLinePath1,naverLinePathcharactor,"chat_history,contacts,groups,membership");
//var e2eePath = XLY.Sqlite.DataRecovery(e2eePath1,e2eePathcharactor,"keystore");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "微话";
    root.Type = "News";
    getList(root);
    result.push(root);
}
//获取当前用户
function getList(root){
    var publicPath1 = allDatabasePath+"\\public.db";
    var publicPath = XLY.Sqlite.DataRecovery(publicPath1,charactor2,"contact,contactPhoneNum,myuserdb");
    if(XLY.File.IsValid(publicPath)){
        var contactData = eval('('+ XLY.Sqlite.Find(publicPath,"select XLY_DataType,contactShowName,contactAddTimestamp,contactId from contact") +')');
        if(contactData!=""&&contactData!=null){
            var contactNode = new TreeNode();
            contactNode.Text = "联系人";
            contactNode.Type = "Contact";
            for(var i in contactData){
                var obj = new Contact();
                obj.DataState = XLY.Convert.ToDataState(contactData[i].XLY_DataType);
                var aaa = 10+parseInt(contactData[i].contactId);
                var phoneNumber = eval('('+ XLY.Sqlite.Find(publicPath,"select contactPhoneNumer from contactPhoneNum where contactKey = '"+aaa+"'") +')');
                var phNum = "";
                if(phoneNumber!=""&&phoneNumber!=null){
                    for(var j in phoneNumber){
                        if(j<phoneNumber.length-1){
                            phNum+= phoneNumber[j].contactPhoneNumer+"\n";
                        }
                        else
                        {
                            phNum+= phoneNumber[j].contactPhoneNumer;
                        }
                        
                    }
                }
                obj.PhoneNumber = phNum;
                obj.CallName = contactData[i].contactShowName;
                obj.AddTime = XLY.Convert.LinuxToDateTime(contactData[i].contactAddTimestamp);
                contactNode.Items.push(obj);
            }
            root.TreeNodes.push(contactNode);
        }
        if(XLY.File.IsValid(xmlPath)){
            var user = eval('('+ XLY.File.ReadXML(xmlPath) +')');
            if(user!=""&&user!= null){
                var userxml = user.map.string;
                for(var i in userxml){
                    if(userxml[i]["@name"]=="username"){
                        var settingPath1 = allDatabasePath + "\\weihua_setting.db";
                        var settingPath = XLY.Sqlite.DataRecovery(settingPath1,charactor3,"tab_user_info");
                        if(XLY.File.IsValid(settingPath)){
                            var userinfo = eval('('+ XLY.Sqlite.Find(settingPath,"select XLY_DataType,userid,username,nicename,sex,imageurl,sign,province,city,modify_time from tab_user_info") +')');
                            if(userinfo!=""&&userinfo!=null){
                                for(var j in userinfo){
                                    var userNode = new TreeNode();
                                    userNode.Text = userinfo[j].username+"_"+userinfo[j].nicename;
                                    userNode.Type = "UserInfo";
                                    userNode.DataState = XLY.Convert.ToDataState(userinfo[j].XLY_DataType);
                                    getUserInfo(userNode,userinfo[j],userxml[i]["#text"],publicPath);
                                    root.TreeNodes.push(userNode);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
function getUserInfo(root,userinfo,ad,path){
    var userPath1 = allDatabasePath +"\\"+userinfo.username+"user.db";
    var userPath = XLY.Sqlite.DataRecovery(userPath1,charactor1,"friend,calltimes,ppCallRecords,messageinfo");
    if(XLY.File.IsValid(userPath)){
        var friendData = eval('('+ XLY.Sqlite.Find(userPath,"select XLY_DataType,userId,username,phoneNum1,phoneNum2,phoneNum3,addFriendTimestamp,vip,birthday,nickname,headPicUrl,signature,sex,area,remark from friend where userId<>0") +')');
        if(friendData!=""&&friendData!=null){
            var friendNode = new TreeNode();
            friendNode.Text = "微话好友";
            friendNode.Type = "FollowInfo";
            for(var i in friendData){
                var fObj = new FollowInfo();
                fObj.DataState = XLY.Convert.ToDataState(friendData[i].XLY_DataType);
                fObj.UID = friendData[i].userId;
                fObj.UserName = friendData[i].username;
                fObj.NickName = friendData[i].nickname;
                fObj.Remark = friendData[i].remark;
                if(friendData[i].sex==1){
                    fObj.Sex = "男";
                }
                else if(friendData[i].sex==2){
                    fObj.Sex = "女";
                }
                else
                {
                    fObj.Sex = "未指定";
                }
                
                fObj.Birthday = friendData[i].birthday;
                fObj.Signature = friendData[i].signature;
                fObj.MobileNumber = friendData[i].phoneNum1+"\n"+friendData[i].phoneNum2+"\n"+friendData[i].phoneNum3;
                fObj.HeadUrl = friendData[i].headPicUrl;
                if(friendData[i].vip==0){
                    fObj.IsVip = "否";
                }
                else
                {
                    fObj.IsVip = "是";
                }
                fObj.Address = friendData[i].area;
                fObj.AddTime = XLY.Convert.LinuxToDateTime(friendData[i].addFriendTimestamp);
                friendNode.Items.push(fObj);
            }
            root.TreeNodes.push(friendNode);
        }
        var callData = eval('('+ XLY.Sqlite.Find(userPath,"select phone,times from calltimes") +')'); 
        if(callData!=""&&callData!=null){
            var callNode = new TreeNode();
            callNode.Text = "通话记录";
            callNode.Type = "CallTime";
            
            for(var i in callData){
                var callObj = new CallTime();
                callObj.DataState = XLY.Convert.ToDataState(callData[i].XLY_DataType);
                callObj.PhoneNumber = callData[i].phone;
                callObj.Times = callData[i].times;
                callNode.Items.push(callObj);
                
                
                var callCData = eval('('+ XLY.Sqlite.Find(userPath,"select XLY_DataType,callid,userid,phone,nickname,calltype,status,starttime,accepttime,endtime from ptopCallRecords where phone like '"+"%"+callData[i].phone+"'") +')');
                if(callCData!=""&&callCData!=null){
                    var callChildNode = new TreeNode();
                    callChildNode.Text = callData[i].phone;
                    callChildNode.Type = "CallLog";
                    for(var a in callCData){
                        var callCObj = new CallLog();
                        callCObj.DataState = XLY.Convert.ToDataState(callCData[a].XLY_DataType);
                        callCObj.CallId = callCData[a].callid;
                        callCObj.UserID = callCData[a].userid;
                        callCObj.PhoneNumber = callCData[a].phone;
                        callCObj.Name = callCData[a].nickname;
                        callCObj.CallType = callCData[a].calltype;
                        callCObj.CallStatus = callCData[a].status;
                        callCObj.CallStartTime = XLY.Convert.LinuxToDateTime(callCData[a].starttime);
                        callCObj.CallAcceptTime = XLY.Convert.LinuxToDateTime(callCData[a].accepttime);
                        callCObj.CallEndTime = XLY.Convert.LinuxToDateTime(callCData[a].endtime);
                        callChildNode.Items.push(callCObj);
                    }
                    callNode.TreeNodes.push(callChildNode);
                }
            }
            root.TreeNodes.push(callNode);
        }
        
        var msgIdData = eval('('+ XLY.Sqlite.Find(userPath,"select distinct(userid) from messageinfo") +')');
        if(msgIdData!=""&&msgIdData!=null){
            var msgNode = new TreeNode();
            msgNode.Text = "聊天消息";
            msgNode.Type = "Message";
            for(var i in msgIdData){
                var msgData = eval('('+ XLY.Sqlite.Find(userPath,"select XLY_DataType,body,createTime,msgSendType from messageinfo where userid = '"+msgIdData[i].userid+"'") +')');
                if(msgData!=""&&msgData!=null){
                    var msgChildNode = new TreeNode();
                    if(msgIdData[i].userid==8000){
                        msgChildNode.Text = msgIdData[i].userid+"_"+"小秘书消息";
                        
                    }
                    else
                    {
                        var friendName = eval('('+ XLY.Sqlite.Find(userPath,"select nickname from friend where username = '"+msgIdData[i].userid+"'") +')');
                        if(friendName!=""&&friendName!=null){
                            msgChildNode.Text = msgIdData[i].userid+"_"+friendName[0].nickname;
                        }
                    }
                    msgChildNode.Type = "Message";
                    for(var b in msgData){
                        var msgDataObj = new Message();
                        msgDataObj.DataState = XLY.Convert.ToDataState(msgData[b].XLY_DataType);
                        if(msgData[b].msgSendType=="send"){
                            msgDataObj.SenderID = userinfo.username;
                            msgDataObj.Sender = userinfo.nicename;
                            msgDataObj.ReceiverID = msgChildNode.Text.split("_")[0];
                            msgDataObj.Receiver = msgChildNode.Text.split("_")[1];
                        }
                        else
                        {
                            msgDataObj.SenderID = msgChildNode.Text.split("_")[0];
                            msgDataObj.Sender = msgChildNode.Text.split("_")[1];
                            msgDataObj.ReceiverID = userinfo.username;
                            msgDataObj.Receiver = userinfo.nicename;
                        }
                        
                        msgDataObj.Content = msgData[b].body;
                        msgDataObj.CreateTime = XLY.Convert.LinuxToDateTime(msgData[b].createTime);
                        msgChildNode.Items.push(msgDataObj);
                    }
                    msgNode.TreeNodes.push(msgChildNode);
                }
            }
            root.TreeNodes.push(msgNode);
        }
    }
    var obj = new UserInfo();
    obj.DataState = XLY.Convert.ToDataState(userinfo.XLY_DataType);
    obj.UserID = userinfo.userid;
    obj.UserName = userinfo.username;
    obj.NickName = userinfo.nicename;
    if(userinfo.sex==1){
        obj.Sex = "男";
    }
    else if(userinfo.sex==2){
        obj.Sex = "女";
    }
    else
    {
        obj.Sex = "未设置";
    }
    
    obj.Signature = userinfo.sign;
    obj.HeadUrl = userinfo.imageurl;
    obj.MobileNumber = userinfo.username;
    obj.Address = userinfo.province +" "+userinfo.city;
    if(ad==userinfo.username){
        obj.IsLoading = "是";
    }
    else
    {
        obj.IsLoading = "否";
    }
    obj.ModifyTime = userinfo.modify_time;
    var pass = eval('('+ XLY.Sqlite.Find(path,"select userPassword from myuserdb where loginUsername = '"+userinfo.username+"'") +')');
    if(pass!=""&&pass!=null){
        obj.PassWord = pass[0].userPassword;
    }
    
    root.Items.push(obj);
}