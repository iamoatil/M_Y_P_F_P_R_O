﻿/*[config]
<plugin name="人人网,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\renren.png" app="com.xiaonei.xiaonei" version="9.0.2" description="人人网" data = "$data,ComplexTreeDataSource" >
<source>
    <value>com.xiaonei.xiaonei</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="AccountId" type="string" width="120" format = "" ></item>
    <item name="绑定手机号码" code="BindPhone" type="string" width="80" format = "" ></item>
    <item name="登录密码" code="PassWord" type="string" width="80" format = "" ></item>
    <item name="粉丝" code="FollowingCount" type="string" width="80" format = "" ></item>
    <item name="关注" code="FollowCount" type="string" width="80" format = "" ></item>
    <item name="来访" code="EarlyVisitCount" type="string" width="80" format = "" ></item>
    <item name="注册时间" code="firstLoadingTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="设备信息" code="MachinPlatForm" type="string" width="120" format = "" ></item>
    <item name="是否是最后登录用户" code="LastLoading" type="string" width="80" format = "" ></item>
</data>
<data type="Contact" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="UserName" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="生日" code="Birthday" type="string" width="120" format=""></item>
    <item name="个性签名" code="PersonSign" type="string" width="120" format=""></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="背景" code="BackGroudUrl" type="url" width="120" format = "" ></item>
    <item name="距离" code="Distence" type="string" width="120" format=""></item>
    <item name="最后登录时间" code="LastLoadingTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="GroupInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="群昵称" code="GroupNickName" type="string" width="200" format = "" ></item>
    <item name="群成员" code="GroupMember" type="string" width="200" format = "" ></item>
</data>
<data type="Message" contract="DataState" datefilter="Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者" code="SenderID" type="string" width="120" format=""></item>
    <item name="接收者" code="ReciveID" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="100" format = ""></item>
    <item name="类型" code="ContentType" type="string" width="100" format = ""></item>
    <item name="发送时间" code="StartTime" type="string" width="100" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.AccountId = "";
    this.FollowingCount = "";
    this.FollowCount = "";
    this.EarlyVisitCount = "";
    this.firstLoadingTime = null;
    this.MachinPlatForm = "";
    this.LastLoading = "否";
    this.BindPhone = "";
    this.PassWord  = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.HeadUrl = "";
    this.BackGroudUrl = "";
    this.UserName = "";
    this.Birthday = "";
    this.PersonSign = "";
    this.Distence  = "";
    this.Sex = "";
    this.LastLoadingTime = null;
}
//定义GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupNickName = "";
    this.GroupMember = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.ReciveID = "";
    this.ContentType = "";
    this.StartTime = "";
    this.Content = "";
}
//Cache数据结构
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.xiaonei.xiaonei";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-05-25-16-26-10\\source\\IosData\\2017-05-25-16-26-23\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.xiaonei.xiaonei";
//var cachePath = "D:\\Program Files\\MobileMaster\\DC-4501 手机取证系统\\案例\\案例（20170518100802）\\iPhone 5C(4)\\Backup\\Applications\\com.sgiggle.Tango\\Library\\Cookies\\Cookies.binarycookies";
//var userPath = "D:\\Program Files\\MobileMaster\\DC-4501 手机取证系统\\案例\\案例（20170518100802）\\iPhone 5C(4)\\Backup\\Applications\\com.sgiggle.Tango\\Library\\Preferences\\com.sgiggle.Tango.plist";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_Tango_4.0.218442\\discoveryFavoritesDB_rel_3.db.charactor";
var charactor2 = "\\chalib\\iOS_Tango_4.0.218442\\profilecache.db.charactor";
var charactor3 = "\\chalib\\iOS_Tango_4.0.218442\\tc.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "人人网";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var userPath = allPath + "\\Library\\Preferences\\com.xiaonei.xiaonei.plist";
    if(XLY.File.IsValid(userPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        var fur = "";
        var reg = new RegExp("isPushOn_");
        var arrr = new Array();
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].loginedUserAccountList!=""&&data[i].loginedUserAccountList!=null){
                    fur = data[i].loginedUserAccountList[0];
                }
                
                
                for(var key in data[i]){
                    if(reg.test(key)){
                        if(data[i][key]==true){
                            arrr.push(key.split("_")[1]);
                        }
                    }
                }
            }
            if(fur!=""&&fur!=null){
                for(var f in fur){
                    var userNode = new TreeNode();
                    userNode.Text = fur[f];
                    userNode.Type = "UserInfo";
                    var obj = new UserInfo();
                    obj.AccountId = fur[f];
                    var groupList = "";
                    getUserChild(userNode,fur[f],arrr);
                    for(var j in data){
                        if(data[j]["kSubscribersCountLastTime_"+fur[f]]!=""&&data[j]["kSubscribersCountLastTime_"+fur[f]]!=null){
                            obj.FollowCount = data[j]["kSubscribersCountLastTime_"+fur[f]];
                        }
                        if(data[j]["kVisitorChangeCountKey_"+fur[f]]!=""&&data[j]["kVisitorChangeCountKey_"+fur[f]]!=null){
                            obj.FollowingCount = data[j]["kVisitorChangeCountKey_"+fur[f]];
                        }
                        if(data[j]["kVisitorsCountLastTime_"+fur[f]]!=""&&data[j]["kVisitorsCountLastTime_"+fur[f]]!=null){
                            obj.EarlyVisitCount = data[j]["kVisitorsCountLastTime_"+fur[f]];
                        }
                        if(data[j].machinePlatForm!=""&&data[j].machinePlatForm!=null){
                            obj.MachinPlatForm = data[j].machinePlatForm;
                        }
                        if(data[j]["kBindMobileNumber"+fur[f]]!=""&&data[j]["kBindMobileNumber"+fur[f]]!=null){
                            obj.BindPhone = data[j]["kBindMobileNumber"+fur[f]];
                        }
                        if(data[j]["nameDisplayList"+fur[f]]!=""&&data[j]["nameDisplayList"+fur[f]]!=null){
                            groupList = data[j]["nameDisplayList"+fur[f]];
                        }
                        if(data[j]["systemMsgKeyList"+fur[f]]!=""&&data[j]["systemMsgKeyList"+fur[f]]!=null){
                            //log(data[j]["systemMsgKeyList"+fur[f]]);
                        }
                        if(data[j]["kOldTimeShowDate_"+fur[f]]!=""&&data[j]["kOldTimeShowDate_"+fur[f]]!=null){
                            //log(data[j]["kOldTimeShowDate_"+fur[f]]);
                        }
                        if(data[j]["kOldTimeShowDate_"+fur[f]]!=""&&data[j]["kOldTimeShowDate_"+fur[f]]!=null){
                            //log(data[j]["kOldTimeShowDate_"+fur[f]]);
                        }
                        if(data[j]["kFriendsBirthdayListTime_"+fur[f]]!=""&&data[j]["kFriendsBirthdayListTime_"+fur[f]]!=null){
                            obj.firstLoadingTime = XLY.Convert.LinuxToDateTime(data[j]["kFriendsBirthdayListTime_"+fur[f]]);
                        }
                        if(data[j]["kInitLoginPassword_"+fur[f]]!=""&&data[j]["kInitLoginPassword_"+fur[f]]!=null){
                            obj.PassWord = data[j]["kInitLoginPassword_"+fur[f]];
                        }
                        if(data[j].lastUserAccount==fur[f]){
                            obj.LastLoading = "是";
                        }
                    }
                    userNode.Items.push(obj);
                    root.TreeNodes.push(userNode);
                }
            }
        }
    }
    
}
function getUserChild(root,id,arr){
    var node = new TreeNode();
    node.Text = "消息";
    node.Type = "";
    
    var node1 = new TreeNode();
    node1.Text = "群组聊天";
    node1.Type = "";
    var node2 = new TreeNode();
    node2.Text = "讨论组";
    node2.Type = "";
    var node3 = new TreeNode();
    node3.Text = "个人消息";
    node3.Type = "";
    var brr = new Array();
    var crr = new Array();
    var messagePath = allPath + "\\Documents\\ChatLogUpload.txt";
    if(XLY.File.IsValid(messagePath)){
        var messageData = XLY.File.ReadFile(messagePath);
        if(messageData!=""&&messageData!= null){
            var furMessageData = messageData.split("\r\n");
            var bur = furMessageData[0].split("\n");
            for(var j in bur){
                var cur = bur[j].split(",");
                if(cur[0].split("=")[1]==id){
                    //for(var a in arr){
                    //    if(arr[a]==cur[1].split("=")[1]){
                    //        
                    //    }
                    //}
                    crr.push(cur);
                    brr.push(cur[1].split("=")[1]);
                }
            }
            brr = brr.sort();
            var res = new Array();
            for(var i = 1; i < brr.length; i++){
                if(brr[i]!=res[res.length-1]){
                    res.push(brr[i]);
                }
            }
            for(var r in res){
                if(res[r].match(/^2/)){
                    var chatNode = new TreeNode();
                    chatNode.Text = res[r];
                    chatNode.Type = "Message";
                    for(var p in crr){
                        if(crr[p][1].split("=")[1]==res[r]){
                            var obj = new Message();
                            obj.SenderID = id;
                            obj.ReciveID = res[r];
                            
                            obj.ContentType = crr[p][4].split("=")[1];
                            obj.StartTime = crr[p][3].split("=")[1];
                            obj.Content = crr[p][2].split("=")[1];
                            chatNode.Items.push(obj);
                        }
                    }
                    
                    node1.TreeNodes.push(chatNode);
                }
                else if(res[r].match(/^3/)){
                    var chatNode = new TreeNode();
                    chatNode.Text = res[r];
                    chatNode.Type = "Message";
                    for(var p in crr){
                        if(crr[p][1].split("=")[1]==res[r]){
                            var obj = new Message();
                            obj.SenderID = id;
                            obj.ReciveID = res[r];
                            
                            obj.ContentType = crr[p][4].split("=")[1];
                            obj.StartTime = crr[p][3].split("=")[1];
                            obj.Content = crr[p][2].split("=")[1];
                            chatNode.Items.push(obj);
                        }
                    }
                    node2.TreeNodes.push(chatNode);
                }
                else
                {
                    var chatNode = new TreeNode();
                    chatNode.Text = res[r];
                    chatNode.Type = "Message";
                    for(var p in crr){
                        if(crr[p][1].split("=")[1]==res[r]){
                            var obj = new Message();
                            obj.SenderID = id;
                            obj.ReciveID = res[r];
                            
                            obj.ContentType = crr[p][4].split("=")[1];
                            obj.StartTime = crr[p][3].split("=")[1];
                            obj.Content = crr[p][2].split("=")[1];
                            chatNode.Items.push(obj);
                        }
                    }
                    node3.TreeNodes.push(chatNode);
                }
            }
        }
    }
    node.TreeNodes.push(node1);
    node.TreeNodes.push(node2);
    node.TreeNodes.push(node3);
    root.TreeNodes.push(node);
}