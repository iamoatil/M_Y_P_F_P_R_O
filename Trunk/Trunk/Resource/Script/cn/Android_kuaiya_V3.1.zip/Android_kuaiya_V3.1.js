﻿
//descritpion:配置模板

/*[config]
<plugin name="快牙,10" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/kuaiya.png" app="com.dewmobile.kuaiya" version="3.7.2" description="快牙" data="$data,ComplexTreeDataSource"  >
<source>
    <value>/data/data/com.dewmobile.kuaiya/databases#F</value>
    <value>/data/data/com.dewmobile.kuaiya/shared_prefs#F</value>
</source>
<data type = "User">
    <item name="用户名" code="username" type="string" width = "" ></item>
    <item name="用户设备名" code="devname" type="string" width="" format = ""></item> 
    <item name="用户设备ID" code="devID" type="string" width="" format=""></item> 
</data>

<data type = "Info">
    <item name="传输设备ID" code="deviceID" type="string" width = "" ></item>
    <item name="传输次数" code="stimes" type="string" width="" format=""></item> 
</data>


<data type = "Transfer" detailfield = "body" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="文件发送者" code="sender" type="string" width="200" format = ""></item>
    <item name="文件接收者" code="receiver" type="string" width="200" format = ""></item>
    <item name="传输文件信息" code="body" type="string" width="700" format = ""></item>
    <item name="传输文件类型" code="type" type="string" width="80" format = "" order="desc"></item>
    <item name="发送时间" code="stime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="完成时间" code="rtime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>

</plugin>
[config]*/

// js content

function User() {
    this.username = ""; //用户名
    this.devname = "";  //用户设备名
    this.devID = "";    //用户设备ID
}
function Info() {
    this.deviceID = ""; //传输设备ID
    this.stimes = "";   //传输次数
}
function Transfer() {
    this.DataState = "Normal";  //数据状态
    this.sender = "";   //文件发送者
    this.receiver = ""; //文件接收者
    this.body = ""; //传输文件信息
    this.type = ""; //传输文件类型
    this.stime = null;  //发送时间
    this.rtime = null;  //完成时间
}

function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

function creatTreeNode(text,type){
    var tree = new TreeNode();
    tree.Text = text;
    tree.Type = type;
    return tree;
}

function bindTree(path){
    
    
    
    var root = creatTreeNode("快牙传输","Info");
    var info = getKuaiyaInfo(path+"\\transfer20.db");
    root.Items = info;
    
    

    
    if(XLY.File.IsValid(uPath+"\\localUser.xml")){
         var userInfo = getUserInfo(uPath+"\\localUser.xml");
         //log(userInfo);
         var user = creatTreeNode(userInfo.username,"User");
         user.Items.push(userInfo);
         
         root.TreeNodes.push(user);
    
         buildAccountTreeNodes(user,path+"\\transfer20.db",userInfo);
    }
    
    
    return root;
}

function getUserInfo(path){
    var uinfo = eval('('+ XLY.File.ReadXML(uPath+"\\localUser.xml") +')');
    var obj = new User();
    var uname = eval('('+ uinfo.map.string[0]['#text'] +')');
    var did = eval('('+ uinfo.map.string[1]['#text'] +')');
    //log(uname.username);
    obj.username = uname.username;
    obj.devID= uname.imei;
    obj.devname = did.deviceName;
    return obj;
}

function getKuaiyaInfo(path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select device,stimes from detail") +')');
    var arr = new Array();
    if(data.length >0){  
        for(var i in data){
            var obj = new Info();
            obj.deviceID = data[i].device;
            obj.stimes = data[i].stimes;
            arr.push(obj);
        }
    }
    return arr;
}


function buildAccountTreeNodes(root,path,uinfo){

    //创建文件传输节点
    var fileTransfer = creatTreeNode("文件传输","Transfer");
    root.TreeNodes.push(fileTransfer);
     //装入文件传输节点信息
    var fileTransferInfo = getFileTransfer(path,uinfo);
    fileTransfer.Items = fileTransferInfo;
}

function getFileTransfer(path,uinfo){
    var data = eval('('+ XLY.Sqlite.Find(path,"select device,name,direction,createtime,category,path,totalbytes,currentbytes,lastmod,title from transfer ") +')');
    var arr = new Array();    
    if(data.length>0){
        for(var i in data){
            var obj = new Transfer();
            obj.DataState = "Normal";
            if(data[i].direction==1){
                obj.sender = uinfo.username;
                obj.receiver = "用户名："+data[i].name+"\n用户设备号："+data[i].device;
            }else{
                obj.sender = "用户名："+data[i].name+"\n用户设备号："+data[i].device;
                obj.receiver = uinfo.username;
            }
            obj.body = "文件名称："+data[i].title+"\n文件大小"+data[i].totalbytes+"\n文件已传输字节数:"+data[i].currentbytes+"\n文件路径:"+data[i].path;
            if(data[i].category=="image"){
                obj.type = "图片";
            }
            else if(data[i].category=="video")
            {
                obj.type = "视频";
            }
            else if(data[i].category=="folder")
            {
                obj.type = "文件";
            }else if(data[i].category=="app")
            {
                obj.type = "应用";
            }else if(data[i].category=="audio")
            {
                obj.type = "音频";
            }else
            {
                obj.type = data[i].category;
            }
            //obj.type = data[i].category;
            obj.stime = XLY.Convert.LinuxToDateTime(data[i].createtime);
            obj.rtime = XLY.Convert.LinuxToDateTime(data[i].lastmod);
            arr.push(obj);
        }
    }
    return arr;
}
    
//获取用户昵称
function getUserNick(uid,path){
    var data = eval('('+ XLY.Sqlite.Find(path,"select p_pf from profiles where p_uid = '"+uid+"'") +')');
    if(data.length>0){
          var nickInfo = eval('('+ data[0].p_pf +')');
          if(nickInfo.nick.length>0){
              return nickInfo.nick;
          }
    }
    return uid;
}

var source = $source;
var pPath = source[0];
var uPath = source[1];
//var pPath = "D:\\temp\\data\\data\\com.dewmobile.kuaiya\\databases";
//var uPath = "D:\\temp\\data\\data\\com.dewmobile.kuaiya\\shared_prefs";
//var charactor = "\\chalib\\Android_Skype_5.0.99\\main.db.charactor";
var result = new Array();

result.push(bindTree(pPath));
var res  = JSON.stringify(result);
res;


