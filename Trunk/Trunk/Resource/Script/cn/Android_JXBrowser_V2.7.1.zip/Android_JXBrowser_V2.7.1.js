﻿/*[config]
<plugin name="极速浏览器" group="Web痕迹,8" devicetype="android" icon="\icons\jxbrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.jx.minibrowser" version="2.7.1" description="极速浏览器" data="$data,ComplexTreeDataSource">
<source>
<value>/mnt/sdcard/haowangzhi/com.jx.minibrowser/.Db/browser.db</value>
<value>/mnt/sdcard/haowangzhi/com.jx.minibrowser/.Db/file.db</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="History" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="访问时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Bookmark" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Title" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="创建时间" code="Time" type="string" width = "200"></item>
</data>
<data type="Download" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="内容" code="Content" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "200"></item>
<item name="是否暂停" code="Pause" type="string" width = "150"></item>
<item name="下载状态" code="Status" type="string" width = "150"></item>
<item name="文件大小" code="Size" type="string" width = "150"></item>
<item name="已下载大小" code="DSize" type="string" width = "150"></item>
<item name="开始时间" code="Time" type="string" width = "150"></item>
<item name="结束时间" code="FTime" type="string" width = "150"></item>
</data>
<data type="HomePage" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="名称" code="Name" type="string" width = "150"></item>
<item name="网址" code="Url" type="url" width = "150"></item>
<item name="图标" code="Icon" type="string" width = "150"></item>
</data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Download(){
    this.DataState = "Normal";
    this.Content = "";
    this.Url = "";
    this.Pause = "";
    this.Status = "";
    this.Size = "";
    this.DSize = "";
    this.Time = "";
    this.FTime = "";
}
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function Bookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function HomePage(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Icon = "";
}

//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "极速浏览器";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
    newTreeNode("下载信息","Download",getDownload(db2),news);
    newTreeNode("浏览记录","History",getHistory(db1),news);
    newTreeNode("书签","Bookmark",getBookmark(db1),news);
    newTreeNode("主页","HomePage",getHomePage(db1),news);
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["下载信息","浏览记录","书签","主页"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}
function getDownload(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from filedownload" ) +')');
    for(var i in data){
        var obj = new Download();
        obj.Content = data[i].filename;
        obj.Url = data[i].url;    
        if(data[i].ifpause =="1"){
            obj.Pause = "暂停";
        }
        else
        {
            obj.Pause = "未暂停";
        }
        if(data[i].status == 237){
            obj.Status = "完成下载";
        }
        else
        {
            obj.Status = "未完成下载";
        }
        obj.Size = data[i].totalsize/1024/1024+" MB";
        obj.DSize = data[i].downloadsize/1024/1024+" MB";
        obj.FTime = XLY.Convert.LinuxToDateTime(data[i].lasttimestamp);
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].firsttimestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from record" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from record where type = 2" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHomePage(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from lable" ) +')');
    for(var i in data){
        var obj = new HomePage();
        obj.Name = data[i].title;
        obj.Url = data[i].href;
        obj.Icon = data[i].img;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db3 = source[0];
var db4 = source[1];

var charactor1 = "\\chalib\\Android_JXBrowser_V2.7.1\\browser.db.charactor";
var charactor2 = "\\chalib\\Android_JXBrowser_V2.7.1\\file.db.charactor";


//
//var db3 = "D:\\temp\\data\\data\\com.jx.minibrowser\\.Db\\browser.db";
//var db4 = "D:\\temp\\data\\data\\com.jx.minibrowser\\.Db\\file.db";
//
//var charactor1 = "D:\\temp\\data\\data\\com.jx.minibrowser\\.Db\\browser.db.charactor";
//var charactor2 = "D:\\temp\\data\\data\\com.jx.minibrowser\\.Db\\file.db.charactor";

var db1 = XLY.Sqlite.DataRecovery(db3, charactor1, "lable,record" );
var db2 = XLY.Sqlite.DataRecovery(db4, charactor2, "filedownload" );

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
