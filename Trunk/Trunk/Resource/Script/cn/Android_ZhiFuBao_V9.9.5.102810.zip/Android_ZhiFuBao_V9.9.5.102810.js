﻿/*[config]
<plugin name="支付宝,6" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\ZhiFuBaoWallet.png" app="com.eg.android.AlipayGphone" version="9.9.5.102810" description="支付宝钱包" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.eg.android.AlipayGphone/shared_prefs/com.alipay.android.phone.socialcontact.xml</value>
    <value>/data/data/com.eg.android.AlipayGphone/databases/coupon.db</value>
    <value>/data/data/com.eg.android.AlipayGphone/databases/messagebox.db</value>
</source>
<data type = "Account" contract = "DataState" >
    <item name="登录帐号" code="Name" type="string" width = "" ></item>
    <item name="帐号ID" code="ID" type="string" width = "" ></item>
    <item name="年龄" code="Age" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="地址" code="Area" type="string" width = "120" ></item>
    <item name="国家" code="Country" type="string"  show="true" width="120" ></item>
    <item name="性别" code="Gender" type="string" width="150" ></item>
    <item name="身高" code="Heigh" type="string" width="200" format = ""></item>
    <item name="收入" code="Income" type="string" width="200" format = ""></item>
    <item name="兴趣" code="Intrest" type="string" width="150" ></item>
    <item name="职业" code="Professional" type="string" width="200" format = ""></item>
    <item name="签名" code="Sign" type="string" width="200" format = ""></item>
    <item name="体重" code="Weight" type="string" width="200" format = ""></item>
</data>
<data type="Coupon" datefilter="Date" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="红包ID" code="ID" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="用户ID" code="userId" type="string" width = "120" ></item>
    <item name="图标链接" code="Icon" type="string"  show="true" width="120" ></item>
    <item name="金额" code="Amount" type="string" width="150" ></item>
    <item name="领取状态" code="State" type="string" width="200" format = ""></item>
    <item name="来源" code="Source" type="string" width="200" format = ""></item> 
    <item name="创建时间" code="CreateDate" type="datetime" format = "yyyy-MM-dd HH:mm:ss" width = "140"></item>
    <item name="修改时间" code="ModifyTime" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
</data>
<data type="PaymentRecords" datefilter="Date" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="消息类型" code="Type" type="string" width="100" alignment = "center" order = "desc"></item>
    <item name="状态" code="Status" type="string" width="120" ></item>
    <item name="日期" code="Date" type="string"  show="true" width="120" ></item>
    <item name="金额" code="Amount" type="string" width="150" ></item>
    <item name="付款方式" code="PayWay" type="string" width="200" format = ""></item>
    <item name="交易对象" code="Target" type="string" width="200" format = ""></item>
    <item name="日期或商品说明" code="Goods" type="string" width="200" format = ""></item>
    <item name="用户ID" code="UserId" type="string" width="200" format = ""></item>
    <item name="付款状态" code="Title" type="string" width = "120" ></item>
    <item name="图标" code="Icon" type="string" width = "120" ></item>
    <item name="创建时间" code="CreateDate" type="datetime" format = "yyyy-MM-dd HH:mm:ss" width = "140"></item>
    <item name="过期时间" code="ValidTime" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="140" ></item>
 </data>   
</plugin>
[config]*/
function Account() {
    this.Name = "";
    this.ID = "";
    this.Age = "";
    this.Area = "";
    this.Country = "";
    this.Gender = "";
    this.Heigh = "";
    this.Income = "";
    this.Intrest = "";
    this.Professional = "";
    this.Sign = "";
    this.Weight = "";
}

function Coupon() {
    this.ID = "";
    this.userId = "";
    this.ModifyTime = "";
    this.CreateDate = "";
    this.Icon = "";
    this.Amount = "";
    this.State = "";
    this.Source = "";
    this.DataState = "Normal";
}

function PaymentRecords() {
    this.Type = "";
    this.Status = "";
    this.Date = "";
    this.Amount = "";
    this.PayWay = "";
    this.Target = "";
    this.Goods = "";
    this.UserId = "";
    this.Title = "";
    this.Icon = "";
    this.CreateDate = "";
    this.ValidTime = "";
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "支付宝钱包";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account"; 
        //account.Items = getAccount(db,accountinfo[i],accountinfo) ;
        news.TreeNodes.push(account)

        var coupon = new TreeNode() ;
        coupon.Text = "红包记录";
        coupon.Type = "Coupon"; 
        coupon.Items = getCoupon(db2,accountinfo[i]);
        account.TreeNodes.push(coupon)
        
        var bill = new TreeNode() ;
        bill.Text = "支付助手消息";
        bill.Type = "PaymentRecords"; 
        bill.Items = getPaymentRecords(db3,accountinfo[i]);
        account.TreeNodes.push(bill)
    }
  result.push(news);
}       
function getAccount(path)
{
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var obj = new Account();
    var info = data.map.string;
    for(var i in info){
        var obj = new Account();
        if(/^myaccountinfo_/.test(info[i]['@name'])){
            var info1 = info[i]['@name'].substring(14,info[i]['@name'].length);
         
            obj.ID = info1;
            if(info[i]['@name'] = "myaccountinfo_"+info1){
               
              var accinfo = eval('('+ info[i]["#text"] +')');
              //log(accinfo);
              obj.Name = accinfo.loginId;
              obj.Area = accinfo.areaDisplay;
              obj.Age = accinfo.age;
              obj.Country = accinfo.country;
              var a = accinfo.gender;
              switch(a){
                  case 'm': 
                 obj.Gender = "男" ;
                   case 'f': 
                 obj.Gender ="女";
                 break;
              }
              obj.Heigh = accinfo.height;
              obj.Income = accinfo.income;
              obj.Intrest = accinfo.interest;
              obj.Professional = accinfo.profession;
              obj.Sign = accinfo.signature;
              obj.Weight = accinfo.weight;
              
              
            }
            list.push(obj);  
          
        }
       
    }

    return list;
}

function getCoupon(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from itemmodel  where userId ='"+accountinfo.ID+"'" ) +')');  
    for(var i in data){
        var obj = new Coupon();
        obj.ID = data[i].couponId;
        obj.userId = data[i].userId;
        obj.CreateDate = data[i].gmtClientShow;
        obj.ModifyTime = data[i].gmtModify;
        obj.Icon =  data[i].iconUrl;
        if(data[i].templateJson.length>20){
           var a = eval('('+ data[i].templateJson +')');
        }        
        obj.Amount = a.statusLine1Text;
        obj.State = a.statusLine2Text;
        var b = a.subtitle;
        var d = b.substr(0,2)
        var c = b.substring(24,b.length-7)
        obj.Source = d+c;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getPaymentRecords(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from messageinfo where userId ='"+accountinfo.ID+"'" ) +')');  
    for(var i in data){
        var obj = new PaymentRecords();
        var m = data[i].appType;
        if(m == 'msgbox'){
            obj.Type='系统消息';
        }
        else
        {
            obj.Type='账单信息';
        }
        

        
        if(data[i].content!=null && data[i].content!= ""){
            if(data[i].content.length>200 ){
                var a = eval('('+ data[i].content +')');
              obj.Status = a.status;
              obj.Date =  a.date;
              obj.Amount = a.money+a.unit;
         
              
              obj.PayWay = a.content[0].content;
              obj.Target = a.content[1].content;
              if(obj.Goods = a.content[2] !=null){
                  obj.Goods = a.content[2].content;
              }
              
            }
        }
        obj.UserId = data[i].userId;
        obj.Title = data[i].title;
        obj.Icon = data[i].iconLink;
        obj.CreateDate =  XLY.Convert.LinuxToDateTime(data[i].gmtCreate);
        obj.ValidTime = XLY.Convert.LinuxToDateTime(data[i].gmtValid);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db4 = source[1];
var db5 = source[2];

var charactor1 = "\\chalib\\Android_ZhiFuBao_V9.9.5.102810\\coupon.db.charactor";
var charactor2 = "\\chalib\\Android_ZhiFuBao_V9.9.5.102810\\messagebox.db.charactor";

var db2 = XLY.Sqlite.DataRecovery(db4,charactor1,"itemmodel");
var db3 = XLY.Sqlite.DataRecovery(db5,charactor2,"messageinfo");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;


