﻿/*[config]
<plugin name="网易邮箱,6" group="主流邮箱,4" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Mail163.png" app="com.netease.mobimail" version="3.5.6" description="网易邮箱" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.netease.mobimail/databases/mmail</value>
</source>

<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="邮箱地址" code="Address" type="string" width="" format=""></item>
<item name="邮箱所属人名称" code="Name" type="string" width="" format=""></item>
</data>

<data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发件人" code="Send" type="string" width="150" format=""></item>
<item name="收件人" code="Receive" type="string" width="300" format=""></item>
<item name="发送时间" code="SendTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="接收时间" code="ReceiveTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="主题" code="Subject" type="string" width="200" format=""></item>
<item name="邮件内容" code="Content" type="string" width="200" format=""></item>
<item name="阅读状态" code="IsRead" type="string" width="150" format=""></item>
<item name="回复状态" code="IsReply" type="string" width="150" format=""></item>
<item name="星标状态" code="IsMark" type="string" width="150" format=""></item>
<item name="附件状态" code="IsAttach" type="string" width="150" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义Account数据结构
function Account() {
    this.Address = "";
    this.Name = "";
    this.DataState = "Normal";
}

//定义Message数据结构
function Message() {
    this.Send = "";
    this.Receive = "";
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.IsReply = "";
    this.Content = "";
    this.IsRead = "";
    this.IsMark = "";
    this.IsAttach = "";
    this.DataState = "Normal";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var path = source[0];
//var path = "C:\\Users\\Administrator\\Desktop\\com.netease.mobimail\\databases\\mmail";

//定义特征库文件
var charactor = "chalib\\Android_NeteaseMail_V3.0\\mmail.charactor";

//处理删除的数据
var recoveryPath = XLY.Sqlite.DataRecovery(path, charactor, "AccountCore,Mailbox");

//创建帐号树结构
var accountInfo = eval('(' + XLY.Sqlite.FindByName(recoveryPath, "AccountCore") + ')');
var tablename = "";
for (var num in accountInfo) {
    tablename = tablename + "Mail_" + accountInfo[num].id + ",";
    var newTable = tablename.substring(0, tablename.lastIndexOf(","));
}
var mailPath = XLY.Sqlite.DataRecovery(path, charactor, newTable);
for (var index in accountInfo) {
    var account = new TreeNode();
    account.Text = accountInfo[index].mailAddress;
    account.Type = "Account";
    account.DataState = XLY.Convert.ToDataState(accountInfo[index].XLY_DataType);
    account.Items.push(getAccountInfo(accountInfo[index]));
    buildChildNodesForAccount(accountInfo[index].id,account,mailPath);
    result.push(account);
}
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
//获取帐号详细信息
function getAccountInfo(data) {
    var obj = new Account();
    obj.Address = data.mailAddress;
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return obj;
}

//创建帐号节点的子节点
function buildChildNodesForAccount(Id,root,path) {
    var fileInfos = eval('(' + XLY.Sqlite.Find(path, "select * from Mailbox where accountId = '" + Id + "' ") + ')');
    if(fileInfos!=null&&fileInfos.length>0){
        for (var index in fileInfos) {
            var childNode = new TreeNode();
            childNode.Text = fileInfos[index].displayName;
            childNode.Type = "Message";
            childNode.DataState = XLY.Convert.ToDataState(fileInfos[index].XLY_DataType);
            childNode.Items = getMessageInfoForChildNodes(fileInfos[index].serverId,Id,path);
            root.TreeNodes.push(childNode);
        }
    }
}


//获取邮件信息
function getMessageInfoForChildNodes(key,Id,path) {
    var tablename = "Mail_" + Id;
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from '" + tablename + "' where mailboxKey = '" + key + "' ") + ')');
    var info = new Array();
    if(data!=null&&data.length>0){
        for (var index in data) {
            var obj = new Message();
            //获取发件人信息
            var sendData=data[index].mailFrom;
            obj.Send = sendData;
            obj.Receive = getReceiveInfo(data[index].mailTo, data[index].mailCC, data[index].mailBCC, data[index].XLY_DataType);
            obj.SendTime = XLY.Convert.LinuxToDateTime(data[index].sendDate);
            obj.ReceiveTime = XLY.Convert.LinuxToDateTime(data[index].recvDate);
            obj.Subject = data[index].subject;
            obj.Content = "摘要:" + data[index].summary + "；邮件内容:" + data[index].textContent;
            obj.IsRead = (data[index].isRead == 1) ? "已阅" : "未读";
            obj.IsReply = (data[index].isReplied == 1) ? "已回复" : "未回复";
            obj.IsMark = (data[index].isMark == 1) ? "星标邮件" : "";
            obj.IsAttach = (data[index].hasAttach) ? "有附件" : "无附件";
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            info.push(obj);
        }
    }
    return info;
}

//获取收件人信息
function getReceiveInfo(data1,data2,data3,key) {
    //处理收件人，抄送，密送等格式的数据
    function print(data) {
        var info = "";
        info = data; 
        return info;
    }
    //获取收件人的全部信息
    if (print(data2) != "" && print(data3) == "") {
        return print(data1) + "；抄送：" + print(data2);
    } else if (print(data2) == "" && print(data3) != "") {
        return print(data1) + "；密送：" + print(data3);
    } else if (print(data2) != "" && print(data3) != "") {
        return print(data1) + "；抄送：" + print(data2) + "；密送：" + print(data3);
    } else if (print(data2) == "" && print(data3) == "") {
        return print(data1);
    }
}
