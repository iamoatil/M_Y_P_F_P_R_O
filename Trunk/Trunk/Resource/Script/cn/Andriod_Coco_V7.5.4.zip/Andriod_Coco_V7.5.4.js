﻿/*[config]
<plugin name="Coco,3" group="社交聊天,5" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/coco.png" app="com.instanza.cocovoice" version="7.5.4" description="Coco" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.instanza.cocovoice/databases#F</value>
    <value>/data/data/com.instanza.cocovoice/shared_prefs/com.instanza.cocovoice.xml</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="账号" code="UserCode" type="string" width="200" format=""></item>
    <item name="昵称" code="UserName" type="string" width="200" format=""></item>
    <item name="头像(大)" code="UserHeadB" type="string" width="200" format = ""></item>
    <item name="头像(小)" code="UserHeadL" type="string" width="200" format = ""></item>
    <item name="性别" code="UserGender" type="string" width="200" format=""></item>
    <item name="生日" code="UserBirthday" type="string" width="200" format = ""></item>
    <item name="个性签名" code="UserSign" type="string" width="200" format = ""></item>
    <item name="朋友圈背景图" code="Cover" type="string" width="200" format = ""></item>
    <item name="地区ID" code="ZoneId" type="string" width="200" format = ""></item>
</data>
<data type="GroupInfo"  contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="群号码" code="GroupNumber" type="string" width="200" format = "" ></item>
    <item name="群名称" code="GroupName" type="string" width="200" format = "" ></item>
    <item name="群个性签名" code="GroupSign" type="string" width="200" format = "" ></item>
    <item name="群头像" code="GroupHead" type="string" width="200" format = "" ></item>
    <item name="群人数" code="GroupCount" type="string" width="200" format = "" ></item>
    <item name="创建者账号" code="GroupCreatNumber" type="string" width="200" format = "" ></item>
    <item name="创建者昵称" code="GroupCreatName" type="string" width="200" format = "" ></item>
    
</data>
<data type="GroupMember" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="群员账号" code="GroupMemberId" type="string" width="200" format = "" ></item>
    <item name="群员昵称" code="GroupMemberNickName" type="string" width="200" format = "" ></item>
</data>    
<data type="GroupNearInfo"  contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="群号码" code="GroupNumber" type="string" width="200" format = "" ></item>
    <item name="群名称" code="GroupName" type="string" width="200" format = "" ></item>
    <item name="群个性签名" code="GroupSign" type="string" width="200" format = "" ></item>
    <item name="群头像(大)" code="GroupHeadB" type="string" width="200" format = "" ></item>
    <item name="群头像(小)" code="GroupHeadL" type="string" width="200" format = "" ></item>
    <item name="群人数" code="GroupCount" type="string" width="200" format = "" ></item>
    <item name="群人数最大值" code="GroupCountMax" type="string" width="200" format = "" ></item>
    <item name="创建者账号" code="GroupCreatNumber" type="string" width="200" format = "" ></item>
    <item name="创建者昵称" code="GroupCreatName" type="string" width="200" format = "" ></item>
    <item name="群创建时间" code="GroupCreaTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    <item name="群消息最后更新时间" code="GroupUpdate" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="AddressBook" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="联系人姓名" code="Name" type="string" width="200" format = "" ></item>
    <item name="联系人电话" code="PhoneNumber" type="string" width="200" format = "" ></item>
</data>
<data type="ChatMessage" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="消息类型" code="MType" type="string" width="200" format = "" ></item>
    <item name="发送者" code="Sender" type="string" width="200" format = "" ></item>
    <item name="接收者" code="Receiver" type="string" width="200" format = "" ></item>
    <item name="消息内容" code="Contents" type="string" width="200" format = "" ></item>
    <item name="消息发送时间" code="SendTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="Topic" contract = "DataState" detailfield = "Pic">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="朋友圈消息Id" code="SesId" type="string" width="200" format = "" ></item>
    <item name="文字描述" code="Desc" type="string" width="200" format = "" ></item>
    <item name="配图" code="Pic" type="string" width="200" format = "" ></item>
    <item name="时间" code="SendTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss" ></item>
    <item name="发送者Id" code="Sender" type="string" width="200" format = "" ></item>
    <item name="发送者昵称" code="NickName" type="string" width="200" format = "" ></item>
    <item name="经度" code="Lngt" type="string" width="200" format = "" ></item>
    <item name="纬度" code="Lat" type="string" width="200" format = "" ></item>
</data>
</plugin>
[config]*/
//定义并初始化News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义并初始化UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserCode = "";
    this.UserName = "";
    this.UserHeadB = "";
    this.UserHeadL = "";
    this.UserGender = "";
    this.UserBirthday = "";
    this.UserSign = "";
    this.Cover = "";
    this.ZoneId = "";
}
//定义并初始化GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupNumber = "";
    this.GroupName = "";
    this.GroupSign = "";
    this.GroupHead = "";
    this.GroupCount = "";
    this.GroupCreatNumber = "";
    this.GroupCreatName = "";
}
//定义并初始化GroupMember数据结构
function GroupMember(){
    this.DataState = "Normal";
    this.GroupMemberId = "";
    this.GroupMemberNickName = "";
}
//定义并初始化GroupNearInfo数据结构
function GroupNearInfo(){
    this.DataState = "Normal";
    this.GroupNumber = "";
    this.GroupName = "";
    this.GroupSign = "";
    this.GroupHeadB = "";
    this.GroupHeadL = "";
    this.GroupCount = "";
    this.GroupCountMax = "";
    this.GroupCreatNumber = "";
    this.GroupCreatName = "";
    this.GroupCreaTime = "";
    this.GroupUpdate = "";
}
//定义并初始化AddressBook数据结构
function AddressBook(){
    this.DataState = "Normal";
    this.Name = "";
    this.PhoneNumber = "";
}
//定义并初始化ChatMessage数据结构
function ChatMessage(){
    this.DataState = "Normal";
    this.MType = "";
    this.Sender = "";
    this.Receiver = "";
    this.Contents = "";
    this.SendTime = "";
}
//定义并初始化topic数据结构
function Topic(){
    this.DataState = "Normal";
    this.SesId = "";
    this.Desc = "";
    this.Pic = "";
    this.SendTime = "";
    this.Sender = "";
    this.NickName = "";
    this.Lngt = "";
    this.Lat = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
var result = new Array();
//配置文件路径全局共用

//*************************************程序入口****************************************
var source = $source;
var IdPath = source[1];
var charactor1 = "\\chalib\\Android_Voxer_V3.11.0.17532\\rv.db.charactor";
//var newpath=XLY.Sqlite.DataRecovery(newpath1,charactor1,"conversations,messages,misc,profiles");

//测试数据
//var charactor1 = "D:\\temp\\data\\data\\com.instanza.cocovoice\\databases\\46977810_coco.db.charactor";
var charactor1 = "\\chalib\\Andriod_Coco_V7.5.4\\46977810_coco.db.charactor";
//var IdPath = "D:\\temp\\data\\data\\com.instanza.cocovoice\\shared_prefs\\com.instanza.cocovoice.xml"

BuildNode();
var res = JSON.stringify(result);
res;
//*************************************程序结束****************************************



//++++++++++++++++++++++++++++++++++自定义函数部分++++++++++++++++++++++++++++++++++++++
//自定义数据库读取函数  
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}
//账号提取
function IdGet(UserIdGet){
    var temp1 = eval('('+ XLY.File.ReadXML(IdPath) +')'); 
    var temp2 = temp1.map.boolean;
    for(var i in temp2){
        temp3 = temp2[i]["@name"].split("_")[3];
    
        if(temp3.length != 0){
          UserIdGet.push(temp3);
        }
    }  
}
//用户数据库路径提取
function PathGet(UserIdGet,UserPath){
    for(var i in UserIdGet){
        var Path1 = source[0]+"\\"+UserIdGet[i]+"_coco.db";
        var Path = XLY.Sqlite.DataRecovery(Path1,charactor1,"ChatMessageModel,FriendModel,GroupMessageModel,GroupModel,GroupNearByModel,InviteFriendModel,SessionModel,SnsTopicModel,UserModel");
        UserPath.push(Path);
    }
}
//根节点函数
function BuildNode(){
    
    var UserIdGet = new Array();//用于存储用户Id
     var UserPath = new Array();//用户存储用户数据所在库路径
    
    IdGet(UserIdGet);//得到用户的id
    PathGet(UserIdGet,UserPath);//得到用户数据库所在路径
 //**********************************根节点建立**************************************  
    var RootNode = new TreeNode();
    RootNode.Text = "Coco";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(UserIdGet);
    var ContentString = ["用户信息","好友信息","手机通讯录","群组信息","聊天信息","朋友圈"];
    if(UserIdGet.length != 0){
        for(var i in UserIdGet){
            var UserInfoData = ExecSql(UserPath[i],"select * from UserModel where userId = "+UserIdGet[i]);
            var UserNode = new TreeNode(); 
            if(UserInfoData.length != 0){
                UserNode.Text = UserInfoData[0].userId + "_" + UserInfoData[0].nickName;
                UserNode.Items = GetUserNews(UserIdGet[i],UserPath[i],ContentString,UserNode);
            }
            else
            {
                UserNode.Text = "未找到用户信息";   
            }
            UserNode.Type = "News";
            RootNode.TreeNodes.push(UserNode);    
        }
    }
    result.push(RootNode);
}
//获得根节点信息
function GetRootInfo(UserId){
    var temp1 = new Array();
    if(UserId.length == 0){
       var temp2 = new News();
       temp2.List = "未找到用户";
       temp1.push(temp2);
      return temp1; 
    }
    for(var i in UserId){
    var temp2 = new News();
    temp2.List = UserId[i]+"_coco";
    temp1.push(temp2);
}
    return temp1;
}
function GetUserNews(UserId,UserPath,CotentStr,UserNode){
    var temp1 = new Array();
    for(var i in CotentStr){
      var temp2 = new News();
      temp2.List = CotentStr[i];
      temp1.push(temp2);
    }
//获取用户个人信息
    var UserIdStr = new Array();
    UserIdStr.push(UserId);
    var userinfonode = new TreeNode();
    userinfonode.Text = CotentStr[0];
    userinfonode.Type = "UserInfo";
    userinfonode.Items = GetUserInfo(UserIdStr,UserPath);
    UserNode.TreeNodes.push(userinfonode);

//获取好友信息
    var FriendStr = ExecSql(UserPath,"select * from FriendModel");
    var friendinfonode = new TreeNode();
    var FriendId = new Array();
    friendinfonode.Text = CotentStr[1];
    friendinfonode.Type = "UserInfo";
    for(var i in FriendStr){
        if(FriendStr[i].userId.length != 0){
            FriendId.push(FriendStr[i].userId);
        }
    }
    friendinfonode.Items = GetUserInfo(FriendId,UserPath);//共用函数GetUserInfo
    UserNode.TreeNodes.push(friendinfonode);
  
//获取通讯录联系人
    var addressbooknode = new TreeNode();
    addressbooknode.Text = CotentStr[2];
    addressbooknode.Type = "AddressBook";
    addressbooknode.Items = GetAddressBook(UserPath);

//群组信息
    var groupinfonode = new TreeNode();
    groupinfonode.Text = CotentStr[3];
    groupinfonode.Type = "News";
    groupinfonode.Items = GetGroupInfo(UserPath,groupinfonode); 
    UserNode.TreeNodes.push(groupinfonode);
//聊天信息
    var chatmessagenode = new TreeNode();
    chatmessagenode.Text = CotentStr[4];
    chatmessagenode.Type = "News";
    chatmessagenode.Items = GetChatMessage(UserPath,chatmessagenode); 
    UserNode.TreeNodes.push(chatmessagenode);
//朋友圈信息
    var topicnode = new TreeNode();
    topicnode.Text = CotentStr[5];
    topicnode.Type = "Topic";
    topicnode.Items = GetTopic(UserPath); 
    UserNode.TreeNodes.push(topicnode);
    return temp1;
}
//用户信息获取函数
function GetUserInfo(UserId,UserPath){
    var temp0 = new Array();
    for(var i in UserId ){
    var temp1 = ExecSql(UserPath,"select * from UserModel where userId = "+UserId[i]);
    var temp2 = new UserInfo();
    if(temp1.length != 0){
    temp2.UserCode = temp1[0].userId.toString();
    temp2.UserName = temp1[0].nickName;
    temp2.UserHeadB = temp1[0].avatarUrl;
    temp2.UserHeadL = temp1[0].avatarPrevUrl;
    switch(temp1[0].gender){
        case "0":temp2.UserGender = "未描述";
        break;
        case "1":temp2.UserGender = "男";
        break;
        case "2": temp2.UserGender = "女";
        break;
    }
    temp2.UserBirthday = temp1[0].birthdayYear.toString() + "_" + temp1[0].birthdayMonth.toString() + "_" + temp1[0].birthdayDay.toString();
    temp2.UserSign = temp1[0].note;
    temp2.Cover = temp1[0].snsCoverUrl;
    temp2.ZoneId = temp1[0].country;  
    temp0.push(temp2);  
    }
}
    return temp0;
}

//通讯录获取函数
function GetAddressBook(UserPath){
    var temp0 = new Array();
    var temp1 = ExecSql(UserPath,"select * from InviteFriendModel");
    if(temp1.length != 0){
        for(var i in temp1){
            var temp2 = new AddressBook();
            temp2.Name = temp1[i].name;
            temp2.PhoneNumber = temp1[i].phone_key;
            temp0.push(temp2);
        }
    }
    return temp0;
}

//群组信息或许函数2
function GetGroupAll(test,sqlstr,UserPath,groupinfonode){
    
    var temp0 = ExecSql(UserPath,sqlstr);
    var temp1 = new Array();  
    for(var i in temp0){
        var groupinfo = new News();
        groupinfo.List = temp0[i].group_id.toString();
        temp1.push(groupinfo);
        
        var newnode = new TreeNode();
        newnode.Text = temp0[i].group_id.toString();
        newnode.Type = "News";
        
        if(test == 0){
            
            newnode.Items = GetGroupInfoJoin(newnode.Text,UserPath,newnode);
        }
        if(test == 1){
            newnode.Items = GetGroupInfoNear(newnode.Text,UserPath,newnode);
         }
        groupinfonode.TreeNodes.push(newnode);
    }
    return temp1;
}

//群组信息获取函数1   
function GetGroupInfo(UserPath,groupinfonode){
    var groupstr = ["加入的群组信息","附近的群组信息"];
    var sqlstr = ["select group_id from GroupModel","select group_id from GroupNearByModel"];
    var temp1 = new Array();
    for(var i in groupstr){
        var groupinfo = new News();
        groupinfo.List = groupstr[i];
        temp1.push(groupinfo);
    }
    
    var groupjoininfonode = new TreeNode();
    groupjoininfonode.Text = groupstr[0];
    groupjoininfonode.Type = "News";
    groupjoininfonode.Items = GetGroupAll(0,sqlstr[0],UserPath,groupjoininfonode); 
    groupinfonode.TreeNodes.push(groupjoininfonode);
    
    var groupnearinfonode = new TreeNode();
    groupnearinfonode.Text = groupstr[1];
    groupnearinfonode.Type = "News";
    groupnearinfonode.Items = GetGroupAll(1,sqlstr[1],UserPath,groupnearinfonode);
    groupinfonode.TreeNodes.push(groupnearinfonode);
    
    return temp1;
}
 
//已加入群信息获取函数1
function GetGroupInfoJoin(SqlStr,UserPath,groupjoininfonode){
    var groupstr = ["群组信息","群组成员"];
    var temp1 = new Array();  
    for(var i in groupstr){
        var groupinfo = new News();
        groupinfo.List = groupstr[i];
        temp1.push(groupinfo);
    }
    var joininfonode = new TreeNode();
    joininfonode.Text = groupstr[0];
    joininfonode.Type = "GroupInfo";
    joininfonode.Items = GetInfoJoin(SqlStr,UserPath); 
    groupjoininfonode.TreeNodes.push(joininfonode);
    
    var joinmembernode = new TreeNode();
    joinmembernode.Text = groupstr[1];
    joinmembernode.Type = "GroupMember";
    joinmembernode.Items = GetMember(0,SqlStr,UserPath); 
    groupjoininfonode.TreeNodes.push(joinmembernode);
    return temp1;
}

//附近群组信息获取函数2
function GetGroupInfoNear(SqlStr,UserPath,groupnearinfonode){
    var groupstr = ["群组信息","群组成员"];
    var temp1 = new Array();
    for(var i in groupstr){
        var groupinfo = new News();
        groupinfo.List = groupstr[i];
        temp1.push(groupinfo);
    }
    var nearinfonode = new TreeNode();
    nearinfonode.Text = groupstr[0];
    nearinfonode.Type = "GroupNearInfo";
    nearinfonode.Items = GetInfoNear(SqlStr,UserPath); 
    groupnearinfonode.TreeNodes.push(nearinfonode);
    
    var nearmembernode = new TreeNode();
    nearmembernode.Text = groupstr[1];
    nearmembernode.Type = "GroupMember";
    nearmembernode.Items = GetMember(1,SqlStr,UserPath); 
    groupnearinfonode.TreeNodes.push(nearmembernode);
    return temp1;
}

//已加入群信息获取函数1
function GetInfoJoin(SqlStr,UserPath){
    var temp0 = ExecSql(UserPath,"select * from GroupModel where group_id = " + SqlStr);
    var temp1 = new Array();
        var temp2 = new GroupInfo();
        temp2.GroupNumber = temp0[0].group_id;
        temp2.GroupName = temp0[0].group_name;
        temp2.GroupSign = temp0[0].discription;
        temp2.GroupHead = temp0[0].group_avatar;
        temp2.GroupCount = temp0[0].count;
        temp2.GroupCreatNumber = temp0[0].creator;
        var temp3 = ExecSql(UserPath,"select * from UserModel where userId = " + temp0[0].creator);
        if(temp3.length != 0){
            temp2.GroupCreatName = temp3[0].nickName;
        }
       
        temp1.push(temp2);
    return temp1;
}

//群组成员获取函数
function GetMember(test,SqlStr,UserPath){
    if(test == 0){
        var temp0 = ExecSql(UserPath,"select * from GroupModel where group_id = " + SqlStr)[0].members;
    }
    if(test == 1){
        var temp0 =  ExecSql(UserPath,"select * from GroupNearByModel where group_id = " + SqlStr)[0].members;
    }
    if(temp0.length>0&&temp0!=null){
        temp0 = eval('('+ temp0 +')');
     }
    var temp1 = new Array();
    if(temp0[0] != null ){
        for(var i in temp0){
        var temp2 = new GroupMember();
        temp2.GroupMemberId = temp0[i].uid;
        var temp3 = ExecSql(UserPath,"select * from UserModel where userId = " + temp0[i].uid);
        if(temp3.length != 0){
            temp2.GroupMemberNickName = temp3[0].nickName;
        }
       
        temp1.push(temp2);
    }
    }
    return temp1;
} 

//附近群组信息获取函数2
function GetInfoNear(SqlStr,UserPath){
    var temp0 = ExecSql(UserPath,"select * from GroupNearByModel where group_id = " + SqlStr);
    var temp1 = new Array();
    var temp2 = new GroupNearInfo();
    if(temp0.length != 0){
        temp2.GroupNumber = temp0[0].group_id;
        temp2.GroupName = temp0[0].group_name;
        temp2.GroupSign = temp0[0].discription;
        temp2.GroupHeadB = temp0[0].originalUrl;
        temp2.GroupHeadL = temp0[0].group_avatar;
        temp2.GroupCount = temp0[0].count;
        temp2.GroupCountMax = temp0[0].maxCount;
        temp2.GroupCreatNumber = temp0[0].creator;
        var temp3 = ExecSql(UserPath,"select * from UserModel where userId = " + temp0[0].creator);
        if(temp3.length != 0){
            
            temp2.GroupCreatName = temp3[0].nickName;
        }
        temp2.GroupCreaTime = XLY.Convert.LinuxToDateTime(temp0[0].creaTime.toString());
        temp2.GroupUpdate = XLY.Convert.LinuxToDateTime(temp0[0].group_updatetime);
    }
        temp1.push(temp2);
    return temp1;
}

//聊天信息获取函数1
function GetChatMessage(UserPath,chatmessagenode){
    var chatstr = ["好友聊天记录","群组聊天记录"];
    var temp1 = new Array();
    for(var i in chatstr){
        var temp2 = new News();
        temp2.List = chatstr[i];
        temp1.push(temp2);

        var chatnode = new TreeNode();
        chatnode.Text = chatstr[i];
        chatnode.Type = "News";
        chatnode.Items = GetMessage(i,UserPath,chatnode); 
        chatmessagenode.TreeNodes.push(chatnode);
    }
   return temp1; 
}

//聊天信息获取函数2
function GetMessage(type,UserPath,chatnode){
    var temp1 = new Array();
    var temp3 = ExecSql(UserPath,"select * from SessionModel where sessionType = " + type.toString());
    for(var i in temp3){
        var temp2 = new News();
        temp2.List = temp3[i].sessionId + "_" + temp3[i].sessionName;
        temp1.push(temp2);
        var chatsonnode = new TreeNode();
        chatsonnode.Text = temp2.List;
        chatsonnode.Type = "ChatMessage";
        chatsonnode.Items = GetMessageson(type,UserPath,temp3[i].sessionId); 
        chatnode.TreeNodes.push(chatsonnode);
    }
    
    return temp1;   
}

//聊天信息获取函数3
function GetMessageson(type,UserPath,seId){
    if(type == 0){
        var sqlstr = "select * from ChatMessageModel where sessionid = " + seId;   
    }
    else
    {
        var sqlstr = "select * from GroupMessageModel where sessionid = " + seId;
    }
    var chatstr = ExecSql(UserPath,sqlstr );
    var temp1 = new Array();
    if(chatstr.length != 0){
    for(var i in chatstr){
        var temp2 =  new ChatMessage();
        var leixin = chatstr[i].msgtype;
        switch(leixin){
            case 0: temp2.MType = "文本";
            break;
            case 1: temp2.MType = "图片";
            break;
            case 2: temp2.MType = "语音";
            break;
            case 10: temp2.MType = "名片";
            break;
            case 14: temp2.MType = "电话";
            break;
            case 501: temp2.MType = "系统消息";
            break;
            case 503: temp2.MType = "系统消息";
            break;
            case 504: temp2.MType = "系统消息";
            break;
            default : temp2.MType = "未知类型";
            break;
        }
        var temp111 = ExecSql(UserPath,"select * from UserModel where userId = " + chatstr[i].fromuid);
        if(temp111.length != 0){
            temp2.Sender = temp111[0].nickName + "(" + chatstr[i].fromuid + ")" ;
        }
        
        if(type == 1){
            temp2.Receiver = "所有群成员";
        }
        else{
            temp2.Receiver = ExecSql(UserPath,"select * from UserModel where userId = " + chatstr[i].touid)[0].nickName + "(" + chatstr[i].touid + ")" ;
        }
        
        switch(leixin){
            case 0:temp2.Contents = chatstr[i].content; 
            break;
            
            case 14:
            {
                var temp11 = eval('('+ chatstr[i].blobdata +')');
                var ttt = eval('('+ XLY.Blob.ToString(temp11) +')').duration;
                if(ttt == 0){
                    temp2.Contents = "未接听";
                }
                else if(ttt == -1){
                    temp2.Contents = "拒绝接听";
                }
                else
                {
                    temp2.Contents = "通话时长" + ttt + "s";
                }
            }
            break;
            
            case 2: 
            {
                var temp11 = eval('('+ chatstr[i].blobdata +')');
                temp2.Contents = "语音地址:" + eval('('+ XLY.Blob.ToString(temp11) +')').fileUrl + "      " + "文件大小:" + eval('('+ XLY.Blob.ToString(temp11) +')').fileSize;
            }
            break;
            
            case 1: 
            {
                var temp11 = eval('('+ chatstr[i].blobdata +')');
                temp2.Contents = "图片地址:" + eval('('+ XLY.Blob.ToString(temp11) +')').imgUrl;}
            break;
            
          case 504: 
            {
                var temp11 = eval('('+ chatstr[i].blobdata +')');
                temp2.Contents = "你已添加了" + eval('('+ XLY.Blob.ToString(temp11) +')').nickname +"(" + eval('('+ XLY.Blob.ToString(temp11) +')').uid +")" + "为Coco好友，现在可以开始聊天了";}
            break;
            
            default:
            {
                var temp10 = eval('('+ chatstr[i].blobdata +')');
                temp2.Contents =  XLY.Blob.ToString(temp10);
            }
            break; 
        }
        temp2.SendTime = XLY.Convert.LinuxToDateTime(chatstr[i].msgtime);
        temp1.push(temp2);
    }
}
    return temp1;
}

//朋友圈获取函数
function GetTopic(UserPath){
    var temp1 = new Array();
    var sqlstr = "select * from SnsTopicModel"; 
    var temp2 = ExecSql(UserPath,sqlstr);
    for(var i in temp2){
        var topicmessage = new Topic;
       topicmessage.SesId = temp2[i].topicid;
       topicmessage.Desc = temp2[i].content;
       topicmessage.SendTime = XLY.Convert.LinuxToDateTime(temp2[i].msgtime);
       topicmessage.Sender = temp2[i].senderuid;
       var temptest = ExecSql(UserPath,"select * from UserModel where userId = " + temp2[i].senderuid);
       if(temptest.length != 0){
           topicmessage.NickName = temptest[0].nickName;
       }
       
        if(temp2[i].XLY_DataType != 1){
            var picstr = "";
            var temptest1 = eval('('+ temp2[i].blobdata +')');
            var temp3 = eval('('+ XLY.Blob.ToString(temptest1) +')');
            for(var j in temp3.blobs){
            picstr = picstr + "图片地址:" + temp3.blobs[j].imgUrl + "     ";
            topicmessage.Pic = picstr; 
            topicmessage.Lngt =  temp3.geo.lngt;
            topicmessage.Lat =  temp3.geo.lat;
            }
        }
        else
        {
            var temp14 = temp2[i].blobdata + "]";
            var temp15 = XLY.Blob.ToString(eval('('+ temp14 +')'));
            topicmessage.Pic =temp15.split(",")[1];
            
        }
       temp1.push(topicmessage);
       
}
   return temp1;
}