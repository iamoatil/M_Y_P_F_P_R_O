﻿/*[config]
<plugin name="谷歌浏览器,3" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/Chrome.png" app="com.android.chrome" version="54.0.2840.85" description="谷歌浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.android.chrome#F</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="来源网站" code="OriginUrl" type="string" width="200" format=""></item>
    <item name="登录名" code="UsernameValue" type="string" width="200" format=""></item>
    <item name="密码" code="Password" type="string" width="200" format = ""></item>
    <item name="首次登录时间" code="CreatedDate" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="AutoFill" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="200" format = ""></item>
    <item name="值" code="Value" type="string" width="200" format = ""></item>
    <item name="创建时间" code="CreatedDate" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后使用时间" code="LastUseDate" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="计数" code="Count" type="string" width="200" format = ""></item>
</data>
<data type="Download" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="Url" code="Url" type="url" width="200" format = ""></item>
    <item name="开始时间" code="StartTime" type="datetime" width="100" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="结束时间" code="EndTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后修改时间" code="LastModifyTime" type="string" width="200" format = ""></item>
    <item name="已下载" code="ReceivedByte" type="string" width="200" format = ""></item>
    <item name="总大小" code="TotalByte" type="string" width="100" format = ""></item>
    <item name="保存路径" code="CurrentPath" type="string" width="100" format = ""></item>
</data>
<data type="Bookmark" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="200" format = ""></item>
    <item name="书签网址" code="Url" type="url" width="100" format = ""></item>
    <item name="创建时间" code="CreateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后访问时间" code="LastVisitedTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="类型" code="Type" type="string" width="100" format = ""></item>
</data>
<data type="BookmarkNode" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format = ""></item>
</data>
<data type = "History" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Name" type="string" width="200" format=""></item>
    <item name="历史浏览地址" code="Url" type="url" width="200" format = ""></item>
    <item name="最后访问时间" code="LastVisitTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="访问次数" code="VisitCount" type="string" width="200" format=""></item>
</data>
<data type ="SearchWord" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关键字" code="Term" type="string" width="" format = ""></item>
    <item name="创建时间" code="CreationTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type ="Cookies" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="键名" code="Name" type="string" width="200" format = ""></item>
    <item name="键值" code="Value" type="string" width="200" format = ""></item>
    <item name="热键" code="HostKey" type="string" width="200" format = ""></item>
    <item name="创建时间" code="CreationTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="过期时间" code="ExpiresTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News() {
    this.List = "";
    this.DataState = "Normal";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.OriginUrl = "";
    this.UsernameValue = "";
    this.Password = "";
    this.CreatedDate = null;
}
//定义AutoFill数据结构
function AutoFill(){
    this.DataState = "Normal";
    this.Name = "";
    this.Value = "";
    this.CreatedDate = null;
    this.LastUseDate = null;
    this.Count = "";
}
//定义History数据结构
function History() {
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.LastVisitTime = null;
    this.VisitCount = "";
}
//定义Bookmark数据结构
function Bookmark(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.CreateTime = null;
    this.LastVisitedTime = null;
    this.Type = "";
}
//定义BookmarkNode数据结构
function BookmarkNode(){
    this.DataState = "Normal";
    this.List = "";
}
//定义SearchWord数据结构
function SearchWord(){
    this.DataState = "Normal";
    this.Term = "";
    this.CreationTime = null;
}
//定义Cookies数据结构
function Cookies(){
    this.DataState = "Normal";
    this.Name = "";
    this.Value = "";
    this.HostKey = "";
    this.CreationTime = null;
    this.ExpiresTime = "";
}
//定义Download数据结构
function Download(){
    this.DataState = "Normal";
    this.Url = "";
    this.StartTime = null;
    this.EndTime = null;
    this.LastModifyTime = "";
    this.ReceivedByte = "";
    this.TotalByte = "";
    this.CurrentPath = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
var bookmarkFolde = new Array();
var result = new Array();
//源文件
var source = $source;
var bookmarkPath = source[0]+"\\app_chrome\\Default\\Bookmarks";
var historyPath1 = source[0]+"\\app_chrome\\Default\\History";
var cookiesPath1 = source[0]+"\\app_chrome\\Default\\Cookies";
var userInfoPath1 = source[0]+"\\app_chrome\\Default\\Login Data";
var autofillPath1 = source[0]+"\\app_chrome\\Default\\Web Data";
//
var charactor1 = "\\chalib\\Android_Chrome_V54.0.2840.85\\History.charactor";
var charactor2 = "\\chalib\\Android_Chrome_V54.0.2840.85\\Cookies.charactor";
var charactor3 = "\\chalib\\Android_Chrome_V54.0.2840.85\\Login Data.charactor";
var charactor4 = "\\chalib\\Android_Chrome_V54.0.2840.85\\Web Data.charactor";
//
//var historyPath = XLY.Sqlite.DataRecovery(historyPath1,charactor1,"downloads,keyword_search_terms,urls");
//var cookiesPath = XLY.Sqlite.DataRecovery(cookiesPath1,charactor2,"cookies");
//var userInfoPath = XLY.Sqlite.DataRecovery(userInfoPath1,charactor3,"logins");
//var autofillPath = XLY.Sqlite.DataRecovery(autofillPath1,charactor4,"autofill");

//测试数据
//var charactor1 = "F:\\21-Build\\21-Build\\chalib\\Android_Chrome_V54.0.2840.85\\History.charactor";
//var charactor2 = "F:\\21-Build\\21-Build\\chalib\\Android_Chrome_V54.0.2840.85\\Cookies.charactor";
//var charactor3 = "F:\\21-Build\\21-Build\\chalib\\Android_Chrome_V54.0.2840.85\\Login Data.charactor";
//var charactor4 = "F:\\21-Build\\21-Build\\chalib\\Android_Chrome_V54.0.2840.85\\Web Data.charactor";
////
//var userInfoPath1 = "C:\\Users\\Administrator\\Desktop\\com.android.chrome\\app_chrome\\Default\\Login Data";
//var bookmarkPath = "C:\\Users\\Administrator\\Desktop\\com.android.chrome\\app_chrome\\Default\\Bookmarks";
//var historyPath1 = "C:\\Users\\Administrator\\Desktop\\com.android.chrome\\app_chrome\\Default\\History";
//var cookiesPath1 = "C:\\Users\\Administrator\\Desktop\\com.android.chrome\\app_chrome\\Default\\Cookies";
//var autofillPath1 = "C:\\Users\\Administrator\\Desktop\\com.android.chrome\\app_chrome\\Default\\Web Data";
//
if(XLY.File.IsValid(userInfoPath1)){
    var autofillPath = XLY.Sqlite.DataRecovery(autofillPath1,charactor4,"autofill");
}
else
{
    var autofillPath = "";
}
if(XLY.File.IsValid(historyPath1)){
    var historyPath = XLY.Sqlite.DataRecovery(historyPath1,charactor1,"downloads,keyword_search_terms,urls");
}
else
{
    var historyPath = "";
}
if(XLY.File.IsValid(cookiesPath1)){
    var cookiesPath = XLY.Sqlite.DataRecovery(cookiesPath1,charactor2,"cookies");
}
else
{
    var cookiesPath = "";
}
if(XLY.File.IsValid(autofillPath1)){
    var userInfoPath = XLY.Sqlite.DataRecovery(userInfoPath1,charactor3,"logins");
}
else
{
    var userInfoPath = "";
}




//定义特征库文件
//var charactor = "chalib\\Android_OperaBrowser_V20.0.1396\\favorites.db.charactor";

//恢复数据库中删除的数据
//var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "谷歌浏览器";
    news.Type = "News";
    news.Items = getNews();
    
    if(userInfoPath !=""&& userInfoPath !=null){
        var userinfoNode = new TreeNode();
        userinfoNode.Text = "登录账户信息";
        userinfoNode.Type = "UserInfo";
        userinfoNode.Items = getUserInfo(userInfoPath);
  	news.TreeNodes.push(userinfoNode);
    }
    
    if(autofillPath !=""&& autofillPath !=null){
        var autofillNode = new TreeNode();
        autofillNode.Text = "表单数据";
        autofillNode.Type = "AutoFill";
        autofillNode.Items = getAutoFill(autofillPath);
	news.TreeNodes.push(autofillNode);
    }
    if(XLY.File.IsValid(bookmarkPath)){
        var data = eval('('+XLY.File.ReadFile(bookmarkPath)+')').roots;
        var bookmarkNode = new TreeNode();
        bookmarkNode.Text = "书签";
        bookmarkNode.Type = "BookmarkNode";
        bookmarkNode.Items = getBookmarkNode(data,bookmarkNode);
        news.TreeNodes.push(bookmarkNode);
    }
    if(historyPath !=""&& historyPath !=null){
        var searchWordNode = new TreeNode();
        searchWordNode.Text = "搜索关键字";
        searchWordNode.Type = "SearchWord";
        searchWordNode.Items = getSearchWordInfo(historyPath);
	news.TreeNodes.push(searchWordNode);
    }
    if(cookiesPath !=""&& cookiesPath !=null){
        var cookiesNode = new TreeNode();
        cookiesNode.Text = "Cookies";
        cookiesNode.Type = "Cookies";
        cookiesNode.Items = getCookiesInfo(cookiesPath);
	news.TreeNodes.push(cookiesNode);
    }
    if(historyPath !=""&& historyPath !=null){
        var historyNode = new TreeNode();
        historyNode.Text = "历史记录";
        historyNode.Type = "History";
        historyNode.Items = getHistoryInfo(historyPath);
	news.TreeNodes.push(historyNode);
    }
    if(historyPath !=""&& historyPath !=null){
        var downloadNode = new TreeNode();
        downloadNode.Text = "下载记录";
        downloadNode.Type = "Download";
        downloadNode.Items = getDownloadInfo(historyPath);
 	news.TreeNodes.push(downloadNode);
    }
     
    result.push(news);
}
//获取数据库
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}
//获取功能列表信息
function getNews(){
    var list = new Array();
    var data = ["账号信息","书签","搜索关键字","Cookies","下载","历史记录"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
//获取书签节点信息
function getBookmarkNode(data,bookmarkNode){
    var arr = new Array();
    for(var i in data){
        var obj = new BookmarkNode();
        obj.List = data[i].name;
        if(obj.List){
            arr.push(obj);
        }
    }
    bookmarkNode.Items = getBookmark(data,bookmarkNode);
    return arr;
}
//获取账户信息
function getUserInfo(path){
    var list = new Array();
    var base64 = new Base64();
    var userinfostr = "select * from logins";
    var userinfo = ExecSql(path,userinfostr);
    for(var i in userinfo){
        var obj = new UserInfo();
        obj.DataState = XLY.Convert.ToDataState(userinfo[i].XLY_DataType);
        obj.OriginUrl = userinfo[i].origin_url;
        obj.UsernameValue = userinfo[i].username_value;
        obj.Password = base64.decode(userinfo[i].password_value);
        obj.CreatedDate = XLY.Convert.LinuxToDateTime(userinfo[i].date_created);
        list.push(obj);
    }
    return list;
} 
//获取表单信息
function getAutoFill(path){
    var list = new Array();
    var autofillstr = "select * from autofill";
    var autofill = ExecSql(path,autofillstr);
    for(var i in autofill){
        var obj = new AutoFill();
        obj.DataState = XLY.Convert.ToDataState(autofill[i].XLY_DataType);
        obj.Name = autofill[i].name;
        obj.Value = autofill[i].value;
        obj.CreatedDate = XLY.Convert.LinuxToDateTime(autofill[i].date_created);
        obj.LastUseDate = XLY.Convert.LinuxToDateTime(autofill[i].date_last_used);
        obj.Count = autofill[i].count;
        list.push(obj);
    }
    return list;
}
//添加书签信息
function getBookmark(info,node){
    var arr = new Array();
    var data = info;
    if(data!=null&&data!=""){
        for(var i in data){
            var genre = data[i].type;
            if(genre=="folder"){
                var subNode = new TreeNode();
                subNode.Text = data[i].name;
                subNode.Type = "Bookmark";
                subNode.Items = getBookmark(data[i].children,subNode);
                node.TreeNodes.push(subNode);
            }
            if(genre=="url"){
                var obj = new Bookmark();
                obj.Url = data[i].url;
                obj.Name = data[i].name;
                obj.CreateTime = XLY.Convert.LinuxToDateTime(data[i].date_added);
                if(data[i].meta_info){
                    obj.LastVisitedTime = XLY.Convert.LinuxToDateTime(data[i].meta_info.last_visited);
                }
                obj.Type = data[i].type;
                arr.push(obj);
            }
        }
    }
    return arr;
}
//获取搜索关键字信息
function getSearchWordInfo(path){
    var list = new Array();
    var searchwordstr = "select * from keyword_search_terms";
    var data = ExecSql(path,searchwordstr);
    for(var i in data){
        var obj = new SearchWord();
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.Term = data[i].term;
        var da1str="select last_visit_time from urls where id = '"+data[i].url_id+"'";
        var da1 = ExecSql(path,da1str);
        if(da1 !=""&& da1 !=null){
            obj.CreationTime = XLY.Convert.LinuxToDateTime(da1[0].last_visit_time);
        }
        else
        {
            obj.CreationTime = null;
        }
        list.push(obj);
    }
    return list;
}
//获取cookies信息
function getCookiesInfo(path){
    if(XLY.File.IsValid(path)){
        var list = new Array(); 
        var cookiesdatastring = "select * from cookies";
        var cookiesdata = ExecSql(path,cookiesdatastring);
        for(var i in cookiesdata){
            var obj = new Cookies();
            obj.DataState = XLY.Convert.ToDataState(cookiesdata[i].XLY_DataType);
            obj.Name = cookiesdata[i].name;
            obj.HostKey = cookiesdata[i].host_key;
            obj.Value = cookiesdata[i].value;
            obj.CreationTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].creation_utc);
            obj.ExpiresTime = XLY.Convert.LinuxToDateTime(cookiesdata[i].expires_utc)
            list.push(obj);
        }
        return list;
    }
}
//获取History信息
function getHistoryInfo(path){
    var list = new Array();
    var historystr = "select * from urls";
    var historydata = ExecSql(path,historystr);
    for(var i in historydata){
        var obj = new History();
        obj.DataState = XLY.Convert.ToDataState(historydata[i].XLY_DataType);
        obj.Name = historydata[i].title;
        obj.Url = historydata[i].url;
        obj.LastVisitTime = XLY.Convert.LinuxToDateTime(historydata[i].last_visit_time);
        obj.VisitCount = historydata[i].visit_count;
        list.push(obj);
    }
    return list;
}
//获取下载信息
function getDownloadInfo(path){
    var list = new Array();
    var downloadstring = "select current_path,start_time,received_bytes,total_bytes,end_time,referrer,last_modified from downloads";
    var downloaddata = ExecSql(path,downloadstring);
    for(var i in downloaddata){
        var obj = new Download();
        obj.DataState = XLY.Convert.ToDataState(downloaddata[i].XLY_DataType);
        obj.Url = downloaddata[i].referrer;
        obj.StartTime = XLY.Convert.LinuxToDateTime(downloaddata[i].start_time);
        obj.EndTime = XLY.Convert.LinuxToDateTime(downloaddata[i].end_time);
        obj.LastModifyTime = downloaddata[i].last_modified;
        obj.ReceivedByte = downloaddata[i].received_bytes;
        obj.TotalByte = downloaddata[i].total_bytes;
        obj.CurrentPath = downloaddata[i].current_path;
        list.push(obj);
    }
    return list;
}
//解码编码
function Base64() {
 
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
 
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }
 
    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }
 
    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
 
        }
        return utftext;
    }
 
    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}
