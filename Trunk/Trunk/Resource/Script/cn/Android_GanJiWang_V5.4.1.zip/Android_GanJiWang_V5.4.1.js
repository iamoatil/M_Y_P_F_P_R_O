﻿/*[config]
<plugin name="赶集网,11" group="生活旅游,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/ganji.png" app="com.ganji.android" version="5.4.1" description="赶集网" data="$data,ComplexTreeDataSource"  >
<source>
    <value>data/data/com.ganji.android/databases/History.db</value>
    <value>data/data/com.ganji.android/shared_prefs/userinfo.xml</value>
    <value>data/data/com.ganji.android/databases/webim.db</value>
    <value>data/data/com.ganji.android/app_browsehistory/#F</value>
</source>
<data  type="BrowseHistory" datefilter="time" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="类别" code="cateName" type="String" width="150" ></item>
    <item name="时间" code="time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="SiftHistory" datefilter="time" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="类别" code="cateName" type="String" width="150" ></item>
    <item name="城市" code="city" type="String" width="150" ></item>
    <item name="时间" code="time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="SearchHistory" datefilter="time" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="关键字" code="keyWord" type="string" width="300"></item>
    <item name="时间" code="time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
</data>
<data type="UserInfo" datefilter="time" contract = "DataState">   
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="赶集ID号" code="loginId" type="String" width="" ></item>
    <item name="用户名" code="userName" type="String" width = "300" ></item>
    <item name="电话号码" code="hasPhone" type="String" width = "400" ></item>
</data>
<data type="TalkList" datefilter="time" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="当前用户ID" code="userId" type="String" width="100" ></item>
    <item name="消息发送ID" code="send" type="String" width = "100" ></item>
    <item name="类型" code="type" type="String" width = "100" ></item>
    <item name="时间" code="time" type="DateTime" width="200" format="yyyy年MM月dd日 HH:mm"></item>
    <item name="发送内容" code="content" type="String" width="500" ></item>
</data>

<data type="Content"  contract = "DataState" detailfield="content">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="用户" code="person" type="String" width="100" ></item>
    <item name="联系电话" code="phone" type="String" width="100" ></item>
    <item name="区域" code="area" type="String" width = "100" ></item>
    <item name="发布内容" code="content" type="String" width="500" ></item>
</data>

</plugin>
[config]*/

// js content

//定义数据结构
function Content() {
    this.person = "";  
    this.phone = "";
    this.content = "";
    this.area = "";
    this.DataState = "Normal";  
}
function TalkList() {
    this.send = ""; 
    this.content = "";  
    this.type = "";  
    this.userId = "";  
    this.time = "";  
    this.DataState = "Normal";  
}
function BrowseHistory() {
    this.cateName = "";  
    this.time = "";  
    this.DataState = "Normal";  
}

function SiftHistory() {
    this.cateName = "";  
    this.city = "";  
    this.time = "";  
    this.DataState = "Normal";  
}
function SearchHistory() {
    this.keyword = "";  
    this.time = "";  
    this.DataState = "Normal";  
}
function UserInfo() {
    this.loginId = "";  
    this.userName = "";  
    this.hasPhone = ""; 
    this.DataState = "Normal";    
}
//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}

//获取浏览历史记录
function GetBrowseHistory(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from BrowsedHistory order by time desc") + ')');
for(var index in data)
{
    var obj=new BrowseHistory();
    obj.cateName = data[index].subCategoryName;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    obj.time = XLY.Convert.LinuxToDateTime(data[index].time) 
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取筛选历史记录
function GetSiftHistory(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from FilterHistory order by time desc") + ')');
for(var index in data)
{
    var obj=new SiftHistory();
    obj.cateName = data[index].subCategoryName;  
    obj.city = data[index].cityName;  
    obj.time = XLY.Convert.LinuxToDateTime(data[index].time) 
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}
//获取搜索历史记录
function GetSearchHistory(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from SearchHistory order by time desc") + ')');
for(var index in data)
{
    var obj=new SearchHistory();
    obj.keyWord = data[index].keyword;  
    obj.time = XLY.Convert.LinuxToDateTime(data[index].time) 
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}
//获取用户信息
function GetUserInfo(path)
{
var arr = new Array();
try{
var info = eval('('+ XLY.File.ReadXML(path) +')');
var obj = new UserInfo();
for(var index in info.map.string)
{
    if(info.map.string[index]['@name']=="loginId")
    {
        obj.loginId = info.map.string[index]["#text"];
    }
    if(info.map.string[index]['@name']=="hasPhone")
    {
        obj.hasPhone = info.map.string[index]["#text"];
    }
    if(info.map.string[index]['@name']=="loginName")
    {
        obj.userName = info.map.string[index]["#text"];
    }
   
}
arr.push(obj);
return arr;
}
catch(e){
return arr;
}
}

function GetTalkList(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from msgsTable order by updateTime desc") + ')');
for(var index in data)
{
    var obj=new TalkList();
    obj.userId = IDtoName(data[index].userId,path3);
    obj.send = IDtoName(data[index].fromUserId,path3);  
    obj.content = data[index].content;  
    if(data[index].sysMsgType==2){
    obj.type = "系统";}
    else{
    obj.type = "用户";}
    obj.time = XLY.Convert.LinuxToDateTime(data[index].updateTime);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

function IDtoName(ID,path)
{
    var data = XLY.Sqlite.Find(path, "select contractName from talkDetailTable where fromUserId = "+ID+""); 
    info = data.substr(data.indexOf(':\"')+2,data.indexOf('\"}]')-data.indexOf(':\"')-2);
    return info;
}
function StrToUnix(str)
{
 return XLY.Convert.LinuxToDateTime(str.substr(0,str.indexOf('_')));
}
function CreateNode(type,text,dbInfo,root)
{
    var childNode =new TreeNode();
    childNode.Type=type;
    childNode.Text = text;
    if(dbInfo)
    childNode.Items = dbInfo;
    root.push(childNode);
}

function GetBrowseContent(filename,pathA)
{
    var path = pathA+"\\"+filename;
    var arr = new Array();
try{
    info = XLY.File.ReadFile(path);
    var obj = new Content();
    var person = info.substr(info.indexOf('persont')+9,3);
    person=person.replace("t", "");
    obj.person = person;
    var phone = info.substr(info.indexOf('phonet')+8,11);
    obj.phone = phone;
    var description = info.substr(info.indexOf('descriptiont')+14,info.indexOf('editor_audit_statust')-info.indexOf('descriptiont')-27);
    description = description.replace("t insuran", "");
    obj.content = description;
    var district = info.substr(info.indexOf('district_namet')+16,2);
    district=district.replace("t", "");
    obj.area = district ;
    arr.push(obj);
    return arr;
    }
    catch(e)
    {
    return arr;
    }
    
    
}

function CreateNodeWithChild(root,type,text,dbInfo,childType,childText,childDB)
{
    var Node =new TreeNode();
    Node.Type=type;
    Node.Text=text;
    if(dbInfo)
    Node.Items = dbInfo;
    for(var i in childType)
    {
    var childNode =new TreeNode();
    childNode.Type=childType[i];
    childNode.Text =childText[i];
    if(childDB[i])
    childNode.Items = childDB[i];
    Node.TreeNodes.push(childNode);
    }
    root.push(Node);
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0] ;
var path2 = source[1] ;
var path3 = source[2] ;
var path4 = source[3] ;

var charactor1 = "chalib\\Android_GanJiWang_V5.4.1\\History.db.charactor";
var charactor2 = "chalib\\Android_GanJiWang_V5.4.1\\webim.db.charactor";

path1  =XLY.Sqlite.DataRecovery( path1,charactor1 ,"BrowsedHistory,FilterHistory,SearchHistory");
path3 = XLY.Sqlite.DataRecovery( path3,charactor2 ,"msgsTable,talkDetailTable");

var childText = new Array(); 
var childType = new Array(); 
var childDB = new Array();
//--------------------------------------------------------------------以下为多节点构造（浏览目录，浏览内容）
var data = eval('(' +XLY.File.FindFileNames(path4) + ')');
for(var index in data)
{
    childText.push(StrToUnix(data[index]));
    childType.push("Content");
    childDB.push(GetBrowseContent(data[index],path4));
}
CreateNodeWithChild(result,"BrowseHistory","浏览记录",GetBrowseHistory(path1),childType,childText,childDB);

//--------------------------------------------------------------------以下为单节点构造（筛选，搜索，用户，会话）
CreateNode("SiftHistory","筛选记录",GetSiftHistory(path1),result);
CreateNode("SearchHistory","搜索记录",GetSearchHistory(path1),result);
CreateNode("UserInfo","用户信息",GetUserInfo(path2),result);
CreateNode("TalkList","会话清单",GetTalkList(path3),result);

var res = JSON.stringify(result);
res;
