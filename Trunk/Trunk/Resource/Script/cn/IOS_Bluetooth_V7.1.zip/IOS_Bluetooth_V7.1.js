﻿/*[config]
<plugin name="蓝牙,11" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\bluetooth.png" app="com.apple.bluetooth" description="提取IOS设备蓝牙信息" data="$data" >
<source>
<value>com.apple.bluetooth</value>
</source>
<data type="BluetoothMsg">
<item name="编号" code="key" type="string" width="100" ></item>
<item name="默认名称" code="DefaultName" type="string" width="100" ></item>
<item name="名称" code="Name" type="string" width="100" ></item>
<item name="最后连接时间" code="LastSeenTime" type="datetime" width="150" ></item>
</data>
</plugin>
[config]*/

function BluetoothMsg
() {
    this.DefaultName = "";
    this.Name = "";
    this.LastSeenTime = null;
    this.key = "";
}


function GetBluetoothNodeInfo(path) {
    var strData = XLY.PList.ReadToJsonString(path);
    if (strData == null || strData == '') {
        return '';
    }

    var data = eval('(' + strData + ')');
    var arr = new Array();

    for (var index in data) {
        var obj = new BluetoothMsg();
        for (var key in data[index]) {
            for (var valueIndex in data[index][key]) {
                if (data[index][key][valueIndex].DefaultName != null) {
                    obj.DefaultName = data[index][key][valueIndex].DefaultName;
                }
                if (data[index][key][valueIndex].Name != null) {
                    obj.Name = data[index][key][valueIndex].Name;
                }
                if (data[index][key][valueIndex].LastSeenTime != null) {
                    obj.LastSeenTime = XLY.Convert.ToDateTime(1970, 1, 1, data[index][key][valueIndex].LastSeenTime);
                }
            }
            obj.key = key;
        }
        arr.push(obj);
    }
    return arr;
}

var source = $source;
var searchPath = source[0];

var searchPath = searchPath + "\\HomeDomain\\Library\\Preferences\\com.apple.MobileBluetooth.devices.plist";

var result = new Array();
result = GetBluetoothNodeInfo(searchPath);
var res = JSON.stringify(result);
res;
