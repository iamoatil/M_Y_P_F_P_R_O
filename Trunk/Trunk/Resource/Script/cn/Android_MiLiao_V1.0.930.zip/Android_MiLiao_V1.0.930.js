﻿//descritpion:米聊(1.0.930)_Android(4.1.1)

/*[config]
<plugin name="米聊,10" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="icons/AndroidMiLiao.png" app="com.xiaomi.channel" version="1.0.930" description="Test-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>data/data/com.xiaomi.channel/databases/sms.db</value>
</source>

// 群
<data type="Group" contract="DataState">
<item name="群名称" code="Name" type="string" width="170" alignment="left"></item>
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群号" code="Account" type="string" width="110" format=""></item>
<item name="群创建时间" code="CreateTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="165" format=""></item>
<item name="经度" code="Longitude" type="string" width="110" format=""></item>
<item name="纬度" code="Latitude" type="string" width="110" format=""></item>
<item name="角色" code="Role" type="string" width="65" format=""></item>
<item name="群成员数" code="MemberCount" type="string" width="90" format=""></item>
</data>

// 讨论组
<data type="DiscussionGroup" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="讨论名称" code="Name" type="string" width="" alignment="center"></item>
<item name="讨论组号" code="Account" type="string" width="" format=""></item>
<item name="创建时间" code="CreateTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="创建人" code="Creator" type="string" width="" format=""></item>
<item name="讨论组人数" code="MemberCount" type="string" width="" format=""></item>
<item name="经度" code="Longitude" type="string" width="" format=""></item>
<item name="纬度" code="Latitude" type="string" width="" format=""></item>
</data>

// 广播
<data type="Wall" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="广播标题" code="Title" type="string" width="250" alignment="left"></item>
<item name="创建时间" code="CreateTime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="广播者" code="Creator" type="string" width="240" alignment="center"></item>
<item name="更新回复" code="Newer" type="string" width="" alignment="center"></item>
<item name="最新回复" code="Latest" type="string" width="" alignment="center"></item>
<item name="评论数" code="ReviewCount" type="string" width="" alignment="center"></item>
<item name="赞数" code="LikeCount" type="string" width="" alignment="center"></item>
<item name="附件" code="Accessory" type="string" width="" alignment="center"></item>
</data>

// 用户信息
<data type="User" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width="130" ></item>
<item name="帐号" code="Account" type="string" width="200" ></item>
<item name="手机号码" code="Phone" type="string" width="250" ></item>
<item name="性别" code="Gender" type="string" width="50" alignment="center"></item>
<item name="生日" code="BrithDay" type="string" width="100" ></item>
<item name="头像" code="Photo" type="string" width="" ></item>
<item name="所在地" code="Location" type="string" width="" ></item>
<item name="学校" code="School" type="string" width="" ></item>
<item name="公司" code="Company" type="string" width=""></item>
<item name="个人简介" code="Bio" type="string" width=""></item>
<item name="个性签名" code="Signature" type="string" width=""></item>
<item name="语音签名" code="VoiceSignature" type="string" width=""></item>
<item name="社交绑定" code="BindValues" type="string" width="450"></item>
<item name="故乡" code="Hometown" type="string" width=""></item>
</data>

// 收藏
<data type="Collection" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Name" type="string" width=""></item>
<item name="帐号" code="Account" type="string" width=""></item>
<item name="年龄" code="Age" type="string" width=""></item>
<item name="性别" code="Sex" type="string" width=""></item>
<item name="头像" code="Icon" type="string" width=""></item>
<item name="收藏时间" code="CreatTime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="描述" code="Description" type="string" width=""></item>
</data>
 
// 消息
<data detailfield="Content" type="Message" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者头像" code="SenderImage" type="image" format=""  show="false"></item>
<item name="发送人" code="SenderName" type="string" width="300"></item>
<item name="接收人" code="Receiver" type="string" width="300"></item>
<item name="内容" code="Content" type="string" width="350" format=""></item>
<item name="时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
<item name="消息类别" code="MessageType" type="string" width=""></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="设备" code="Device" type="string" width="" format=""></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>
</plugin>
[config]*/

// js content

//************************** 定义数据结构 Star **************************


// 群
function Group() {
    this.Name = "";
    this.Account = "";
    this.CreateTime = null;
    this.Creator = "";
    this.Role = "";
    this.MemberCount = "";
    this.Longitude = "";
    this.Latitude = "";
    this.readSeq = "";
    this.lastMsgSeq = "";
    this.DataState = "Normal";
}

// 讨论组
function DiscussionGroup() {
    this.Name = "";
    this.Account = "";
    this.CreateTime = null;
    this.Creator = "";
    this.MemberCount = "";
    this.Longitude = "";
    this.DataState = "Normal";
}

// 广播
function Wall() {
    this.Title = "";
    this.CreateTime = null;
    this.Creator = "";
    this.ReviewCount = "";
    this.LikeCount = "";
    this.Accessory = ""; // 附件
    this.Newer = "";
    this.Latest = "";
    this.DataState = "Normal";
}

// 用户信息
function User() {
    this.Id = "";
    this.Name = "";
    this.Account = "";
    this.Phone = "";
    this.Gender = "";
    this.BrithDay = "";
    this.Photo = "";
    this.Location = "";
    this.School = "";
    this.Company = "";
    this.Bio = "";
    this.Signature = "";
    this.VoiceSignature = "";
    this.BindValues = "";
    this.Hometown = "";
    this.DataState = "Normal";
}

//收藏
function Collection() {
    this.Name = "";
    this.Account = "";
    this.Age = "";
    this.Sex = "";
    this.Icon = "";
    this.CreatTime = null;
    this.Description = "";
    this.DataState = "Normal";
}

// 消息
function Message() {
    this.SenderName = "";
    this.SenderImage = "";
    this.Receiver = "";
    this.Device = "";
    this.Content = "";
    this.MessageType = "";
    this.DataState = "Normal";
    this.Date = "";
    this.Type = "";
    this.SendState = "";
}

//************************** 定义数据结构 End **************************


//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点树
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

// SQLITE对象获取
function ExecSql(dbPath, sqlString) {
    return eval('(' + XLY.Sqlite.Find(dbPath, sqlString) + ')');
}
// string.format
String.prototype.format = function (args) {
    var result = this;
    if (arguments.length > 0) {
        var reg;
        if (arguments.length == 1 && typeof (args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    reg = new RegExp("({" + key + "})", "g");
                    result = result.replace(reg, args[key]);
                }
            }
        }
        else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    reg = new RegExp("({)" + i + "(})", "g");
                    result = result.replace(reg, arguments[i]);
                }
            }
        }
    }
    return result;
};

//String.prototype.Trim = function () {
//    return str.replace(/^(\s|\u00A0)+/, '').replace(/(\s|\u00A0)+$/, '');
//}

String.prototype.KbToMb = function () {
    var result = (this / 1024).toFixed(2);
    return result;
};

String.prototype.ByteToKb = function () {
    var result = (this / 1024).toFixed(2);
    return result;
};

String.prototype.ByteToMb = function () {
    var kb = this / 1024;
    var mb = kb / 1024;
    return mb.toFixed(2);
};

String.prototype.Sub = function () {
    return this.substr(0, 2);
};

var sqlStr = "select {0} from {1} ";

function GetSql(parm, tablename, where) {
    if (!isNewDb) {
        // 旧数据库SQL
        var sql = sqlStr.format(parm, tablename);
        if (where != "") {
            sql += where;
        }
        return sql;
    } else {
        var sql = sqlStr.format(parm + ",XLY_DataType", tablename);
        if (where != "") {
            sql += where;
        }
        return sql;
    }
}

function ParesCore() {
    var tree = new TreeNode();
    tree.type = "User";
    if (baseUse == null)
        return;
    tree.Text = accountFormat.format(baseUse.Name, baseUse.Account);
    tree.Items.push(baseUse);
    tree.TreeNodes.push(GetUserTree());
    tree.TreeNodes.push(GetCollectionBuddyTree());
    tree.TreeNodes.push(GetWallTree());
    tree.TreeNodes.push(GetGroupTree());
    result.push(tree);
}

// 构建广播树结构 [ 数据状态已接 ]
function GetWallTree() {
    // 广播树结构  结构:广播>用户>广播消息
    var tree = new TreeNode();
    tree.Text = "广播";
    // 绑定用户信息
    tree.Type = "User";
    // 获取广播者信息;
    var wallSender = GetWallSender();
    // 构建广播节点
    for (var use in wallSender) {
        // 用户信息
        var user = new User();
        // 获取用户信息;
        user = GetUserInfo(wallSender[use].PosterUuid);
        // 用户树
        var userTree = new TreeNode();
        userTree.Type = "Wall";
        userTree.DataState = user.DataState; // 数据状态(树结构)
        userTree.Text = accountFormat.format(user.Name, user.Account);
        userTree.TreeNodes = null;
        // 获取当前用户发送的广播信息;
        var wallList = GetWallInfoAll(wallSender[use].PosterUuid);
        for (var w in wallList) {
            var wall = GetWallInfo(wallList[w]);
            userTree.Items.push(wall);
        }
        tree.Items.push(user);
        tree.TreeNodes.push(userTree);
    }
    return tree;
}

// 构建收藏好友树结构 [ 数据状态已接 ]
function GetCollectionBuddyTree() {
    var tree = new TreeNode();
    tree.Text = "收藏";
    tree.Type = "Collection";

    // 获取收藏的好友信息
    var data = GetCollectionAll();
    for (var i in data) {
        tree.Items.push(GetCollectionInfo(data[i]));
    }
    tree.TreeNodes = null;
    return tree;
}

// 构建米聊好友树结构  [ 数据状态已接 ]
function GetUserTree() {
    // 构建好友树结构
    var tree = new TreeNode();
    tree.Text = "好友";
    tree.Type = "User";

    // 获取所有好友信息
    var data = GetUserAll(1);
    for (var o in data) {
        var user = ConvertUser(data[o]);
        // 获取该用户聊天记录
        var userTree = new TreeNode();
        userTree.Type = "Message";
        userTree.DataState = user.DataState;
        userTree.Text = accountFormat.format(user.Name, user.Account);
        var sms = GetUserMessage(user);
        for (var s in sms) {
            var msg = ConvertMessage(sms[s]);
            userTree.Items.push(msg);
        }
        tree.Items.push(user);
        tree.TreeNodes.push(userTree);
    }
    return tree;
}

// 构建群信息树结构 
function GetGroupTree() {
    var tree = new TreeNode();

    tree.Text = "我的群";
    tree.type = "Group";
    // 获取所有群信息;
    var group = GetGroupAll(18);

    for (var g in group) {
        try {
            var ginfo = ConvertGroup(group[g]);
            var gTree = new TreeNode();
            gTree.Text = accountFormat.format(ginfo.Name, ginfo.Account);
            gTree.Type = "Message";
            gTree.DataState = ginfo.DataState;
            //获取群聊天记录
            var msg = GetGroupMsg(ginfo);

            if (msg != null) {
                for (var m in msg) {
                    gTree.Items.push(ConvertGroupMessage(msg[m], ginfo));
                }
                tree.Items.push(ginfo);
                tree.TreeNodes.push(gTree);
            }
        } catch (e) {
        }
    }
    return tree;
}

// 获取指定群消息
function GetGroupMsg(g) {
    if (g == null) return null;
    if (g.readSeq == "" || g.lastMsgSeq == "") return null;
    var sqlStr = GetSql("server_seq, body as Content,sent_time as SendTime,sender_id as Sender,type as MessType,ext as ExtData", "sms", "where cast(server_seq as int) > {0} and cast(server_seq as int) < {1}".format(g.readSeq, g.lastMsgSeq));
    var data = ExecuteSql(sqlStr);
    return data;
}

// 转换消息
function ConvertGroupMessage(m, r) {
    var mess = new Message();
    if (m == null || r == null) return mess;
    mess.Content = m.Content;
    mess.SenderName = accountStr.format(GetGroupSender(m.ExtData), m.Sender);
    mess.Receiver = accountFormat.format(r.Name, r.Account);
    mess.MessageType = GetMsgType(m.MessType, mess);
    mess.Date = XLY.Convert.LinuxToDateTime(m.SendTime);
    mess.DataState = XLY.Convert.ToDataState(m.XLY_DataType);
    return mess;
}

// 获取所有群
function GetGroupAll(type) {
    if (type == null || type == "") return null;
    //var sqlStr = "select display_name as Name,account_name as Account,bind_values as BindValues,XLY_DataType from buddy where type = {0}".format(type);
    var sqlStr = GetSql("display_name as Name,account_name as Account,bind_values as BindValues", "buddy", "where type = {0}".format(type));
    var data = ExecuteSql(sqlStr);
    return data;
}

// 转换群信息
function ConvertGroup(g) {
    var group = new Group();
    if (g == null) return group;
    if (g.BindValues.trim() == "") return group;
    var bindValues = eval('(' + g.BindValues + ')');
    group.Name = g.Name;
    group.Account = g.Account;
    group.CreateTime = XLY.Convert.LinuxToDateTime(bindValues.createTime);
    group.Creator = accountStr.format(bindValues.ownerName, bindValues.ownerId);
    if (bindValues.myRole == "2")
        group.Role = "成员";
    if (bindValues.myRole == "3")
        group.Role = "管理员";
    if (bindValues.myRole == "4")
        group.Role = "创建者";
    group.MemberCount = bindValues.groupMemberCount;
    group.Longitude = bindValues.longitude;
    group.Latitude = bindValues.latitude;
    group.readSeq = bindValues.readSeq;
    group.lastMsgSeq = bindValues.lastMsgSeq;
    return group;
}

// 获取某一种类型的所有用户
function GetUserAll(type) {
    if (type == null || type == "") return null;
    //var sqlStr = "select _id as Id, display_name as Name,Account_name as Account,sex as Gender,phone_num_md5 as Phone,birthday as BrithDay,photo_url as Photo,location as Location,school as School,company as Company,bio as Bio,signature as Signature,Voice_Signature as VoiceSignature,bind_values as BindValues,hometown as Hometown,XLY_DataType from buddy where type={0}".format(type);
    var sqlStr = GetSql("_id as Id, display_name as Name,Account_name as Account,sex as Gender,phone_num_md5 as Phone,birthday as BrithDay,photo_url as Photo,location as Location,school as School,company as Company,bio as Bio,signature as Signature,Voice_Signature as VoiceSignature,bind_values as BindValues,hometown as Hometown", "buddy", "where type={0}".format(type));
    var data = ExecuteSql(sqlStr);
    return data;
}

// 获取用户的聊天记录
function GetUserMessage(user) {
    if (user == null || user.Id == null) return null;
    //var sqlStr = "select body as Content,sender_device_id as Device, outbound_status as OutBound,type as MessType,sender_id as Sender, sent_time as SendTime,XLY_DataType from sms where sender_id={0}".format(user.Id);
    var sqlStr = GetSql("body as Content,sender_device_id as Device, outbound_status as OutBound,type as MessType,sender_id as Sender, sent_time as SendTime", "sms", "where sender_id={0}".format(user.Id));
    var data = ExecuteSql(sqlStr);
    return data;
}

// 聊天信息转换
function ConvertMessage(sms) {
    var msg = new Message();
    if (sms == null || sms == "") return msg;
    msg.Content = sms.Content;
    var use = GetUserInfoById(sms.Sender);
    if (sms.OutBound == "4") {
        msg.SenderName = accountFormat.format(baseUse.Name, baseUse.Account);
        msg.Receiver = accountFormat.format(use.Name, use.Account);
        msg.SendState = "Send";
        msg.SenderImage = baseUse.Photo;
    } else {
        msg.SenderName = accountFormat.format(use.Name, use.Account);
        msg.Receiver = accountFormat.format(baseUse.Name, baseUse.Account);
        msg.SendState = "Receive";
        msg.SenderImage = use.Photo;
    }
    msg.Date = XLY.Convert.LinuxToDateTime(sms.SendTime);
    msg.MessageType = GetMsgType(sms.MessType, msg);

    msg.Device = GetDeviceType(sms.Device);
    msg.DataState = XLY.Convert.ToDataState(sms.XLY_DataType);
    return msg;
}

// 获取所有收藏好友信息
function GetCollectionAll() {
    //var sqlStr = "select miId as Account,name as Name,age as Age,sex as Sex,icon as Icon,createTime as CreateTime,description as Description,XLY_DataType from collectionBuddyTable";
    var sqlStr = GetSql("miId as Account,name as Name,age as Age,sex as Sex,icon as Icon,createTime as CreateTime,description as Description", "collectionBuddyTable", "");
    var data = ExecuteSql(sqlStr);
    return data;
}

// 组装收藏用户信息
function GetCollectionInfo(col) {
    var data = new Collection();
    if (col == null) return data;
    data.Name = col.Name;
    data.Account = accountStr1.format(col.Account);
    data.Age = col.Age;
    data.Sex = col.Sex;
    data.Icon = col.Icon;
    data.CreatTime = XLY.Convert.LinuxToDateTime(col.CreateTime);
    data.Description = col.Description;
    data.DataState = XLY.Convert.ToDataState(col.XLY_DataType);
    return data;
}

// 根据帐户获取信息
function ConvertUser(u) {
    var user = new User();
    if (u == null) return user;
    user.Id = u.Id;
    user.Name = u.Name;
    user.Account = u.Account;
    user.Phone = u.Phone;
    user.Gender = u.Gender;
    user.BrithDay = u.BrithDay;
    user.Photo = u.Photo;
    user.Location = u.Location;
    user.School = GetSchool(u.School);
    user.Company = GetCompany(u.Company);
    user.Bio = u.Bio;
    user.Signature = u.Signature;
    user.VoiceSignature = u.VoiceSignature;
    user.BindValues = GetUserBindValues(u.BindValues);
    user.Hometown = u.Hometown;
    user.DataState = XLY.Convert.ToDataState(u.XLY_DataType);
    return user;
}

// 根据用户ID获取用户信息
function GetUserInfoById(id) {
    var user = new User();
    if (id == null || id == "") return user;
    //var sqlStr = "select display_name as Name,Account_name as Account,sex as Gender,birthday as BrithDay,phone_num_md5 as Phone, photo_url as Photo,location as Location, school as School, company as Company, bio as Bio, signature as Signature,voice_Signature as VoiceSignature,bind_values as BindValues,hometown as Hometown,XLY_DataType from buddy where _id = '{0}'".format(id);
    var sqlStr = GetSql("display_name as Name,Account_name as Account,sex as Gender,birthday as BrithDay,phone_num_md5 as Phone, photo_url as Photo,location as Location, school as School, company as Company, bio as Bio, signature as Signature,voice_Signature as VoiceSignature,bind_values as BindValues,hometown as Hometown", "buddy", "where _id = '{0}'".format(id));
    var data = ExecuteSql(sqlStr);
    if (data == null || data.length == 0)
        return null;
    var u = data[0];
    user.Name = u.Name;
    user.Phone = u.Phone;
    user.Account = u.Account;
    user.Gender = u.Gender;
    user.BrithDay = u.BrithDay;
    user.Photo = u.Photo;
    user.Location = u.Location;
    user.School = GetSchool(u.School);
    user.Company = GetCompany(u.Company);
    user.Bio = u.Bio;
    user.Signature = u.Signature;
    user.VoiceSignature = u.VoiceSignature;
    user.BindValues = GetUserBindValues(u.BindValues);
    user.Hometown = u.Hometown;
    return user;
}

// 获取用户信息 uuid 用户帐号
function GetUserInfo(uuid) {
    var user = new User();
    if (uuid == null || uuid == "") return user;
    //var sqlStr = "select display_name as Name,Account_name as Account,phone_num_md5 as Phone,sex as Gender,birthday as BrithDay, photo_url as Photo,location as Location, school as School, company as Company, bio as Bio, signature as Signature,voice_Signature as VoiceSignature,bind_values as BindValues,hometown as Hometown,XLY_DataType from buddy where Account_name = '{0}@xiaomi.com'".format(uuid);
    var sqlStr = GetSql("display_name as Name,Account_name as Account,phone_num_md5 as Phone,sex as Gender,birthday as BrithDay, photo_url as Photo,location as Location, school as School, company as Company, bio as Bio, signature as Signature,voice_Signature as VoiceSignature,bind_values as BindValues,hometown as Hometown", "buddy", "where Account_name = '{0}@xiaomi.com'".format(uuid));
    var u = ExecuteSql(sqlStr)[0];
    if (u == null) return user;
    user.Name = u.Name;
    user.Phone = u.Phone;
    user.Account = u.Account;
    user.Gender = u.Gender;
    user.BrithDay = u.BrithDay;
    user.Photo = u.Photo;
    user.Location = u.Location;
    user.School = GetSchool(u.School);
    user.Company = GetCompany(u.Company);
    user.Bio = u.Bio;
    user.Signature = u.Signature;
    user.VoiceSignature = u.VoiceSignature;
    user.BindValues = GetUserBindValues(u.BindValues);
    user.Hometown = u.Hometown;
    user.DataState = XLY.Convert.ToDataState(u.XLY_DataType);
    return user;
}

// 获取广播发送人
function GetWallSender() {
    // 查询所有广播信息发送者，屏蔽相同人的发送
    //var sqlStr = "select distinct poster_uuid as PosterUuid,XLY_DataType from wall";
    var sqlStr = GetSql("distinct poster_uuid as PosterUuid", "wall", "");
    var allSender = ExecuteSql(sqlStr);
    if (allSender.length == 0 || allSender == null)
        return null;
    return allSender;
}

// 获取指定人发送的广播信息
function GetWallInfoAll(uuid) {
    if (uuid == null || uuid == "") return null;
    // 通过广播者信息获取当前广播者所有广播信息
    //var sqlStr = "select poster_uuid as Creator,content as Title, post_time as CreateTime,rpl_count as ReviewCount,like_count as LikeCount,att_info as Accessory, newer_reply as Newer,latest_reply as Latest,XLY_DataType from wall where poster_uuid='{0}'".format(uuid);
    var sqlStr = GetSql("poster_uuid as Creator,content as Title, post_time as CreateTime,rpl_count as ReviewCount,like_count as LikeCount,att_info as Accessory, newer_reply as Newer,latest_reply as Latest", "wall", "where poster_uuid='{0}'".format(uuid));
    // 获取数据集合
    var dataWall = ExecuteSql(sqlStr);
    if (dataWall == null || dataWall.length == 0)
        return null;
    return dataWall;
}

// 获取广播信息
function GetWallInfo(w) {
    // 广播信息
    var wall = new Wall();
    if (w != null) {
        //var sqlStr="select display_name as Nick from buddy where account_name = '{0}@xiaomi.com'".format(w.Creator)";
        var sqlStr = GetSql("display_name as Nick", "buddy", "where account_name = '{0}@xiaomi.com'".format(w.Creator));
        // 获取创建者的昵称;
        var nick = ExecuteSql(sqlStr);
        if (nick[0] == null)
            return wall;
        // 标题
        wall.Title = w.Title;
        // 创建者
        wall.Creator = accountStr.format(nick[0].Nick, w.Creator);
        wall.CreateTime = XLY.Convert.LinuxToDateTime(w.CreateTime);
        wall.ReviewCount = w.ReviewCount;
        wall.LikeCount = w.LikeCount;
        wall.Accessory = GetAccessory(w.Accessory);
        wall.Newer = w.Newer;
        wall.Latest = w.Latest;
        wall.DataState = XLY.Convert.ToDataState(w.XLY_DataType);
    }
    return wall;
}

// Sqlite执行
function ExecuteSql(sqlStr) {
    return ExecSql(nSource, sqlStr);
}

// 学校信息处理
function GetSchool(school) {
    var schoolStr = "";
    if (school != null && school.trim() != "") {
        var acc = eval(school);
        for (var c in acc) {
            var b = acc[c].list;
            for (var i in b) {
                schoolStr += " 学校:{0}\n".format(b[i].name);
            }
        }
    }
    return schoolStr;
}

// 获取公司信息
function GetCompany(company) {
    var companyStr = "";
    if (company != null && company.trim() != "") {
        var cpy = eval(company);
        for (var c in cpy) {
            companyStr += "公司:{0}\n".format(cpy[c].name);
        }
    }
    return companyStr;
}

// 获取附件
function GetAccessory(accessory) {
    var sory = "";
    // 附件处理
    if (accessory != null && accessory.trim() != "") {
        // 取出附件对象(可能多个)
        var acc = eval('(' + accessory + ')');
        if (acc == null || acc.length == 0)
            return sory;
        if (acc.length == 1) {
            sory = "文件：{0}".format(acc[0].reallink);
        } else {
            for (var o in acc) {
                sory += "文件:{0} \n".format(acc[o].reallink);
            }
        }
    }
    return sory;
}


// 获取群消息发送者
function GetGroupSender(str) {
    if (str != null && str.trim() != "") {
        var data = eval('[' + str + ']');
        return data[0].senderNick;
    }
    return "";
}

// 获取用户绑定信息
function GetUserBindValues(bindValues) {
    var bValues = "";

    if (bindValues != null) {
        var data = eval(bindValues);
        if (data == null) return bValues;
        if (data.length == 0 || data == null)
            return bValues;
        if (data.length == 1) {
            bValues = GetBindType(data[0]);
        } else {
            for (var i in data) {
                bValues += GetBindType(data[i]);
            }
        }
    }
    return bValues;

}

// 获取消息类型。
function GetMsgType(mstype, msg) {
    switch (mstype) {
        case 1:
            msg.Type = "String";
            return "文本";
        case 2:
            msg.Type = "Image";
            return "图片";
        case 33:
            return "表情";
        case 37:
            msg.Type = "String";
            return "定向内容";
        default:
            msg.Type = "String";
            return "文本";
    }
}

// 获取设备类型
function GetDeviceType(dType) {
    if (dType == null)
        return "None";
    switch (dType.substr(0, 2)) {
        case "an":
            return "安卓设备";
        case "ip":
            return "苹果设备";
        default:
            return "None";
    }
}

// 组建绑定信息
function GetBindType(str) {
    var formatStr = "{0}:{1}\n";
    if (str == null)
        return "";
    switch (str.bind_type) {
        case "PH":
            return formatStr.format("手机", str.contact_value);
        case "OPEN_QQ":
            return formatStr.format("腾讯QQ", str.contact_value);
        case "RE":
            return formatStr.format("人人网", str.contact_value);
        default:
            return "";
    }
}

var result = new Array();
//源文件
var source = $source;
//var source = ["C:\\XLYSFTasks\\未命名-37\\source\\data\\data\\com.xiaomi.channel\\databases\\sms.db"];
var chalib = "chalib\\Andriod_Miliao_V6.0.8\\sms.db.charactor";
var isNewDb = true;
var nSource = XLY.Sqlite.DataRecovery(source[0], chalib, "buddy,sms,wall,collectionBuddyTable");
if (nSource == source[0]) {
    isNewDb = false;
}
var baseUse = GetUserInfoById(1);
var accountFormat = "{0}({1})";
var accountStr = "{0}({1}@xiaomi.com)";
var accountStr1 = "{0}@xiaomi.com";

var allGroup = null;
ParesCore();
var res = JSON.stringify(result);
res;
