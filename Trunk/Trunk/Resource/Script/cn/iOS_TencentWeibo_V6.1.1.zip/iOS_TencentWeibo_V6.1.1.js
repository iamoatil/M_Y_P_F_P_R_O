﻿/*[config]
<plugin name="腾讯微博,6" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/TencentWBlog.png" app="com.tencent.WeiBo" version="6.1.1" description="腾讯微博" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.tencent.WeiBo</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="SearchWord"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="关键字" code="Key" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="200" format = "" ></item>
    <item name="性别" code="Gender" type="string" width="200" format=""></item>
    <item name="页标识" code="PageID" type="string" width="200" format = "" ></item>
    <item name="头像链接地址" code="ProfileHeadUrl" type="url" width="200" format=""></item>
    <item name="背景链接地址" code="BGUrl" type="url" width="200" format=""></item>
    <item name="关注" code="Following" type="string" width="200" format=""></item>
    <item name="粉丝" code="Follower" type="string" width="200" format=""></item>
    <item name="简介" code="Descrp" type="string" width="200" format=""></item>
    <item name="微博数" code="WeiboCount" type="string" width="200" format=""></item>
    <item name="最后修改用户信息时间" code="LastLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="AbstractFan" contract="DataState" datefilter="Reserve">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserID" type="string" width="200" format = "" ></item>
    <item name="昵称" code="NickName" type="string" width="200" format=""></item>
    <item name="网址" code="FacUrl" type="url" width="200" format=""></item>
    <item name="简介" code="Personal" type="string" width="200" format=""></item>
    <item name="描述" code="Reserve"  type="string" width="150" format = ""></item>
</data>
<data type="AbstractMessage" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者" code="SenderName" type="string" width="200" format=""></item>
    <item name="内容" code="Content" type="string" width="200" format=""></item>
    <item name="点赞数" code="MsgLikeCount" type="string" width="200" format = "" ></item>
    <item name="转发数" code="Remark" type="string" width="200" format = "" ></item>
    <item name="匿名发送" code="Anonymous" type="string" width="200" format=""></item>
    <item name="来源" code="Source" type="string" width="200" format=""></item>
    <item name="网址" code="LinkUrl" type="string" width="200" format = ""></item>
    <item name="经度" code="Lon" type="string" width="200" format=""></item>
    <item name="纬度" code="Lat" type="string" width="200" format=""></item>
    <item name="地理位置" code="Address" type="string" width="200" format=""></item>
    <item name="图片大小" code="PicSize" type="string" width="200" format=""></item>
    <item name="图片链接" code="PicUrl" type="url" width="200" format = ""></item>;
    <item name="时间" code="ZTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="AbstractSimpleAccount" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="VIP" code="IsVip" type="string" width="100" format="" ></item>
    <item name="用户ID" code="UserID" type="string" width="120" format = ""></item>
    <item name="网址" code="FaceUrl" type="string" width="120" format = ""></item>
    <item name="昵称" code="NickName" type="string" width="120" format = ""></item>
    <item name="简介" code="Personal" type="string" width="200" format = ""></item>
    <item name="描述" code="Reserve" type="string" width="200" format = ""></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Cache数据结构
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.Gender = "";
    this.LastLanchTime = null;
    this.PageID = "";
    this.ProfileHeadUrl = "";
    this.BGUrl = "";
    this.Following = "";
    this.Follower = "";
    this.Descrp = "";
    this.WeiboCount = "";
}
function AbstractFan(){
    this.DataState = "Normal";
    this.UserID = "";
    this.FacUrl = "";
    this.NickName = "";
    this.Personal = "";
    this.Reserve = "";
}
function AbstractMessage(){
    this.DataState = "Normal";
    this.MsgLikeCount = "";
    this.Remark = "";
    this.Anonymous = "";
    this.SenderName = "";
    this.Content = "";
    this.Source = "";
    this.LinkUrl = "";
    this.Lon = "";
    this.Lat = "";
    this.Address = "";
    this.PicSize = "";
    this.PicUrl = "";
    this.ZTime = null;
}
function AbstractSimpleAccount(){
    this.DataState = "Normal";
    this.IsVip = "";
    this.UserID = "";
    this.FaceUrl = "";
    this.NickName = "";
    this.Personal = "";
    this.Reserve = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.tencent.WeiBo\\Documents";
var cookPath = source[0]+"\\com.tencent.WeiBo\\Library\\Cookies\\Cookies.binarycookies";
//var searchPath = source[0]+"\\com.sina.weiboLibrary\\Preferences\\com.sina.weibo.plist";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-03-31-16-26-32\\source\\IosData\\2017-03-31-16-27-40\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.WeiBo\\Documents";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-03-31-16-26-32\\source\\IosData\\2017-03-31-16-27-40\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.WeiBo\\Library\\Cookies\\Cookies.binarycookies";
//var userPath = "C:\\XLYSFTasks\\任务-2017-03-30-16-43-08\\source\\IosData\\2017-03-30-16-44-26\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.WeiBo\\Library\\Preferences\\com.tencent.WeiBo.plist";
//定义特征库文件
var charactor = "chalib\\iOS_TencentWeibo_V6.1.1\\d198c300cb7826b6d4a.charactor";
//var charactor2 = "chalib\\iOS_Weibo_V6.5.1\\message_6050936393.db.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "腾讯微博";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var data = eval('('+ XLY.File.FindFileNamesWithExtension(allPath) +')');
    var reg = new RegExp("dc4b832a0492e949616088ed315916bb","i");
    var reg1 = new RegExp("recovery","i");
    for(var i in data){
        if(reg.test(data[i])){
            if(!reg1.test(data[i])){
                var aa = data[i].split("_")[0];
                var node = new TreeNode();
                node.Text = aa;
                node.Type = "News";
                
                var obj = new News();
                obj.List = node.Text;
                //root.Items.push(obj);
                
                root.TreeNodes.push(node);
                getUserChildNode(node,data[i]);
            }
        }
    }
    if(XLY.File.IsValid(cookPath)){
        var cachenode = new TreeNode();
        cachenode.Text = "Cache缓存";
        cachenode.Type = "Cache";
        getCache(cachenode);
        root.TreeNodes.push(cachenode);
    }
}
function getUserChildNode(root,id){
    var userPath1 = allPath +"\\"+id;
    var userPath = XLY.Sqlite.DataRecovery(userPath1,charactor,"ZABSTRACTMESSAGE,ZABSTRACTFAN,ZABSTRACTSIMPLEACCOUNT,ZGPSINFOFORMESSAGE,ZPICINFO",true);
    if(XLY.File.IsValid(userPath)){
        var nodeweibo = new TreeNode();
        nodeweibo.Text = "微博";
        nodeweibo.Type = "News";
        var nodecontact = new TreeNode();
        nodecontact.Text = "好友列表";
        nodecontact.Type = "News";
        var dataMessage = eval('('+ XLY.Sqlite.Find(userPath,"select * from ZABSTRACTMESSAGE") +')');
        var dataFan = eval('('+ XLY.Sqlite.Find(userPath,"select * from ZABSTRACTFAN") +')');
        var dataSimpleAccount = eval('('+ XLY.Sqlite.Find(userPath,"select * from ZABSTRACTSIMPLEACCOUNT") +')');
        var dataGPSInfo = eval('('+ XLY.Sqlite.Find(userPath,"select * from ZGPSINFOFORMESSAGE") +')');
        var dataPicInfo = eval('('+ XLY.Sqlite.Find(userPath,"select * from ZPICINFO") +')');
        if(dataMessage!=""&&dataMessage!=null){
            var node = new TreeNode();
            node.Text = "首页";
            node.Type = "AbstractMessage";
            
            //var obj = new News();
            //obj.List = node.Text;
            //aee.push(obj);
            getDataMessage(node,dataMessage,dataPicInfo,dataGPSInfo);
            nodeweibo.TreeNodes.push(node);
        }
        if(dataFan!=""&&dataFan!=null){
            var node = new TreeNode();
            node.Text = "粉丝";
            node.Type = "AbstractFan";
            //var obj1 = new News();
            //obj1.List = node.Text;
            //aee.push(obj1);
            getDataFan(node,dataFan,1);
            nodecontact.TreeNodes.push(node);
        }
        if(dataSimpleAccount!=""&&dataSimpleAccount!=null){
            var node = new TreeNode();
            node.Text = "关注";
            node.Type = "AbstractFan";
            //var obj2 = new News();
            //obj2.List = node.Text;
            //aee.push(obj2);
            getDataFan(node,dataFan,2);
            nodecontact.TreeNodes.push(node);
        }
        if(dataGPSInfo!=""&&dataGPSInfo!=null){
            var node = new TreeNode();
            node.Text = "@我的微博";
            node.Type = "AbstractMessage";
            //var obj3 = new News();
            //obj3.List = node.Text;
            //aee.push(obj3);
            getAtMeWeibo(node,dataMessage,dataPicInfo,dataGPSInfo);
            nodeweibo.TreeNodes.push(node);
        }
        if(dataPicInfo!=""&&dataPicInfo!=null){
            var node = new TreeNode();
            node.Text = "我的微博";
            node.Type = "AbstractMessage";
            //var obj4 = new News();
            //obj4.List = node.Text;
            //aee.push(obj4);
            getMyWeibo(node,dataMessage,dataPicInfo,dataGPSInfo);
            nodeweibo.TreeNodes.push(node);
        }
        root.TreeNodes.push(nodeweibo);
        root.TreeNodes.push(nodecontact);
    }
}
function getDataMessage(root,info,temp,address){
    if(info!=""&&info!=null){
        for(var i in info){
            if(info[i].ZISLIKEDBYME!=1){
                if(info[i].ZISRELATEDWITHSELF!=1){
                    var obj = new AbstractMessage();
                    obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                    obj.MsgLikeCount = info[i].ZMSGLIKECOUNT;
                    obj.Remark = info[i].ZRETWEETCOUNT;
                    if(info[i].ZANONYMOUSHEADURL!=""&&info[i].ZANONYMOUSHEADURL!=null){
                        obj.Anonymous = "是";
                    }
                    else
                    {
                        obj.Anonymous = "否";
                    }
                    obj.SenderName = info[i].ZAUTHOR;
                    obj.Content = info[i].ZCONTENT;
                    obj.Source = info[i].ZEXTSOURCENAME;
                    obj.LinkUrl = info[i].ZLINKURL;
                    
                    for(var b in address){
                        if(info[i].ZMSGID==address[b].ZMSGID){
                            obj.Lon = address[b].ZLONGITUDE;
                            obj.Lat = address[b].ZLATITUDE;
                            obj.Address = address[b].ZADDRESS;
                        }
                    }
                    for(var a in temp){
                        if(info[i].ZMSGID==temp[a].ZMSGID){
                            obj.PicUrl = temp[a].ZPICURL;
                            obj.PicSize = temp[a].ZPICHEIGHT+"*"+temp[a].ZPICWITH;
                        }
                    }
                    obj.ZTime = XLY.Convert.LinuxToDateTime(info[i].ZTIME);
                    root.Items.push(obj);
                }
                else
                {
                    if(info[i].ZAUTHOR==""||info[i].ZAUTHOR==null){
                        var obj = new AbstractMessage();
                        obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                        obj.MsgLikeCount = info[i].ZMSGLIKECOUNT;
                        obj.Remark = info[i].ZRETWEETCOUNT;
                        if(info[i].ZANONYMOUSHEADURL!=""&&info[i].ZANONYMOUSHEADURL!=null){
                            obj.Anonymous = "是";
                        }
                        else
                        {
                            obj.Anonymous = "否";
                        }
                        obj.SenderName = info[i].ZAUTHOR;
                        obj.Content = info[i].ZCONTENT;
                        obj.Source = info[i].ZEXTSOURCENAME;
                        obj.LinkUrl = info[i].ZLINKURL;
                        
                        for(var b in address){
                            if(info[i].ZMSGID==address[b].ZMSGID){
                                obj.Lon = address[b].ZLONGITUDE;
                                obj.Lat = address[b].ZLATITUDE;
                                obj.Address = address[b].ZADDRESS;
                            }
                        }
                        for(var a in temp){
                            if(info[i].ZMSGID==temp[a].ZMSGID){
                                obj.PicUrl = temp[a].ZPICURL;
                                obj.PicSize = temp[a].ZPICHEIGHT+"*"+temp[a].ZPICWITH;
                            }
                        }
                        obj.ZTime = XLY.Convert.LinuxToDateTime(info[i].ZTIME);
                        root.Items.push(obj);
                    }
                }
            }
        }
    }
}
function getDataFan(root,info,temp){
    if(info!=""&&info!= null){
        if(temp==1){
            for(var i in info){
                if(info[i].ZISFOLLOWER==1){
                    var obj = new AbstractFan();
                    obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                    obj.UserID = info[i].ZACCOUNTID;
                    obj.FacUrl = info[i].ZFACEURL;
                    obj.NickName = info[i].ZNICKNAME;
                    obj.Personal = info[i].ZPERSONAL;
                    obj.Reserve = info[i].ZRESERVES;
                    root.Items.push(obj);
                } 
            }
        }
        if(temp==2){
            for(var i in info){
                var obj = new AbstractFan();
                obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                obj.UserID = info[i].ZACCOUNTID;
                obj.FacUrl = info[i].ZFACEURL;
                obj.NickName = info[i].ZNICKNAME;
                obj.Personal = info[i].ZPERSONAL;
                obj.Reserve = info[i].ZRESERVES;
                root.Items.push(obj); 
            }
        }
        
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
function getAtMeWeibo(root,info,temp,address){
    if(info!=""&&info!=null){
        for(var i in info){
            if(info[i].ZISRELATEDWITHSELF==1){
                if(info[i].ZAUTHOR!=""&&info[i].ZAUTHOR!=null){
                    var obj = new AbstractMessage();
                    obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                    obj.MsgLikeCount = info[i].ZMSGLIKECOUNT;
                    obj.Remark = info[i].ZRETWEETCOUNT;
                    if(info[i].ZANONYMOUSHEADURL!=""&&info[i].ZANONYMOUSHEADURL!=null){
                        obj.Anonymous = "是";
                    }
                    else
                    {
                        obj.Anonymous = "否";
                    }
                    obj.SenderName = info[i].ZAUTHOR;
                    obj.Content = info[i].ZCONTENT;
                    obj.Source = info[i].ZEXTSOURCENAME;
                    obj.LinkUrl = info[i].ZLINKURL;
                    
                    for(var b in address){
                        if(info[i].ZMSGID==address[b].ZMSGID){
                            obj.Lon = address[b].ZLONGITUDE;
                            obj.Lat = address[b].ZLATITUDE;
                            obj.Address = address[b].ZADDRESS;
                        }
                    }
                    for(var a in temp){
                        if(info[i].ZMSGID==temp[a].ZMSGID){
                            obj.PicUrl = temp[a].ZPICURL;
                            obj.PicSize = temp[a].ZPICHEIGHT+"*"+temp[a].ZPICWITH;
                        }
                    }
                    obj.ZTime = XLY.Convert.LinuxToDateTime(info[i].ZTIME);
                    root.Items.push(obj);
                }
            }
        }
    }
}
function getMyWeibo(root,info,temp,address){
    if(info!=""&&info!=null){
        for(var i in info){
            if(info[i].ZISLIKEDBYME==1){
                var obj = new AbstractMessage();
                obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                obj.MsgLikeCount = info[i].ZMSGLIKECOUNT;
                obj.Remark = info[i].ZRETWEETCOUNT;
                if(info[i].ZANONYMOUSHEADURL!=""&&info[i].ZANONYMOUSHEADURL!=null){
                    obj.Anonymous = "是";
                }
                else
                {
                    obj.Anonymous = "否";
                }
                obj.SenderName = info[i].ZAUTHOR;
                obj.Content = info[i].ZCONTENT;
                obj.Source = info[i].ZEXTSOURCENAME;
                obj.LinkUrl = info[i].ZLINKURL;
                
                for(var b in address){
                    if(info[i].ZMSGID==address[b].ZMSGID){
                        obj.Lon = address[b].ZLONGITUDE;
                        obj.Lat = address[b].ZLATITUDE;
                        obj.Address = address[b].ZADDRESS;
                    }
                }
                for(var a in temp){
                    if(info[i].ZMSGID==temp[a].ZMSGID){
                        obj.PicUrl = temp[a].ZPICURL;
                        obj.PicSize = temp[a].ZPICHEIGHT+"*"+temp[a].ZPICWITH;
                    }
                }
                obj.ZTime = XLY.Convert.LinuxToDateTime(info[i].ZTIME);
                root.Items.push(obj);
            }
        }
    }
}