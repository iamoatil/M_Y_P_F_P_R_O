﻿/*[config]
<plugin name="快帆,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/IninVPN.png" app="in.invpn" version="2.1.2" description="快帆" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/in.invpn/shared_prefs#F</value>
    <value>/data/data/in.invpn/shared_prefs/databases/d8f5bbc3dbda2d8b58dcedc71c48f897</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "100"></item>
    <item name="密码" code="PassWord" type="string" width = "100"></item>
    <item name="设备信息" code="DeviceInfo" type="string" width = "100"></item>
    <item name="设备MAC" code="Mac" type="string" width="100"></item>
    <item name="成功请求次数" code="SuccessfulRequestCount" type="string" width = "80"></item>
    <item name="最后请求服务器时间" code="LastDispatch" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="首次运行时间" code="FirstRun" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="首次请求服务器" code="FirstActivateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="是否第一次安装" code="IsFirstInstall" type="string" width = "80"></item>
    <item name="是否第一次运行" code="IsFirstStart" type="string" width = "80"></item>
</data>
<data type="AppInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="App包名" code="AppName" type="string" width = "100"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PassWord = "";
    this.DeviceInfo = "";
    this.Mac = "";
    this.LastDispatch = null;
    this.FirstRun = null;
    this.FirstActivateTime = null;
    this.IsFirstInstall = "否";
    this.IsFirstStart = "否";
    this.SuccessfulRequestCount = "";
}
function AppInfo(){
    this.DataState = "Normal";
    this.AppName = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allXmlPath = source[0];
var appInfoPath = source[1];

//测试数据
//var allXmlPath = "F:\\temp\\data\\data\\in.invpn\\shared_prefs";
//var appInfoPath = "F:\\temp\\data\\data\\in.invpn\\databases\\d8f5bbc3dbda2d8b58dcedc71c48f897";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "快帆";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    var admPath = allXmlPath + "\\admob_user_agent.xml";
    if(XLY.File.IsValid(admPath)){
        var admData = eval('('+ XLY.File.ReadXML(admPath) +')');
        if(admData!=""&&admData!=null){
            var admStr = admData.map.string;
            if(admStr["#text"]!=""&&admStr["#text"]!=null){
                obj.DeviceInfo = admStr["#text"];
            }
        }
    }
    var umePath = allXmlPath + "\\umeng_socialize.xml";
    if(XLY.File.IsValid(umePath)){
        var umeData = eval('('+ XLY.File.ReadXML(umePath) +')');
        if(umeData!=""&&umeData!= null){
            var umeStrData = umeData.map.string;
            for(var a in umeStrData){
                if(umeStrData[a]["@name"]=="mac"){
                    obj.Mac = umeStrData[a]["#text"];
                }
            }
        }
    }
    var umegPath = allXmlPath + "\\umeng_general_config.xml";
    if(XLY.File.IsValid(umegPath)){
        var umegData = eval('('+ XLY.File.ReadXML(umegPath) +')');
        if(umegData!=""&&umegData!= null){
            var umegIntData = umegData.map.int;
            if(umegIntData!=""&&umegIntData!=null){
                for(var b in umegIntData){
                    if(umegIntData[b]["@name"]=="successful_request"){
                        obj.SuccessfulRequestCount = umegIntData[b]["@value"];
                    }
                }
            }
            var umegLongData = umegData.map.long;
            if(umegLongData!=""&&umegLongData!=null){
                for(var c in umegLongData){
                    if(umegLongData[c]["@name"]=="first_activate_time"){
                        obj.FirstActivateTime = XLY.Convert.LinuxToDateTime(umegLongData[c]["@value"]);
                    }
                    if(umegLongData[c]["@name"]=="last_req"){
                        obj.LastDispatch = XLY.Convert.LinuxToDateTime(umegLongData[c]["@value"]);
                    }
                }
            }
        }
    }
    var inPath = allXmlPath + "\\in.invpn_preferences.xml";
    if(XLY.File.IsValid(inPath)){
        var inData = eval('('+ XLY.File.ReadXML(inPath) +')');
        if(inData!=""&&inData!= null){
            var intStrData = inData.map.string;
            if(intStrData!=""&&intStrData!=null){
                for(var d in intStrData){
                    if(intStrData[d]["@name"]=="login_user_name"){
                        obj.UserName = intStrData[d]["#text"];
                    }
                    if(intStrData[d]["@name"]=="login_user_pass"){
                        obj.PassWord = intStrData[d]["#text"];
                    }
                }
            }
        }
    }
    var senPath = allXmlPath + "\\com.sensorsdata.analytics.android.sdk.SensorsDataAPI.xml";
    if(XLY.File.IsValid(senPath)){
        var senData = eval('('+ XLY.File.ReadXML(senPath) +')');
        if(senData!=""&&senData!= null){
            var senStrData = senData.map.string;
            if(senStrData!=""&&senStrData!= null){
                for(var e in senStrData){
                    if(senStrData[e]["@name"]=="first_start"){
                        if(senStrData[e]["#text"]=="true"){
                            obj.IsFirstStart = "是";
                        }
                    }
                    if(senStrData[e]["@name"]=="first_track_installation"){
                        if(senStrData[e]["#text"]=="true"){
                            obj.IsFirstInstall = "是";
                        }
                    }
                }
            }
        }
    }
    var gmsPath = allXmlPath + "\\com.google.android.gms.analytics.prefs.xml";
    if(XLY.File.IsValid(gmsPath)){
        var gmsData = eval('('+ XLY.File.ReadXML(gmsPath) +')');
        if(gmsData!=""&&gmsData!= null){
            var gmsLongData = gmsData.map.long;
            if(gmsLongData!=""&&gmsLongData!= null){
                for(var f in gmsLongData){
                    if(gmsLongData[f]["@name"]=="first_run"){
                        obj.FirstRun = XLY.Convert.LinuxToDateTime(gmsLongData[f]["@value"]);
                    }
                }
            }
        }
    }
    usernode.Text = obj.UserName;
    usernode.Items.push(obj);
    getUserChildNodeInfo(usernode);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}
function getUserChildNodeInfo(root){
    if(XLY.File.IsValid(appInfoPath)){
        var data = eval('('+ XLY.Sqlite.Find(appInfoPath,"select a from a") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = "设备中已安装app包名";
            node.Type = "AppInfo";
            for(var i in data){
                var obj = new AppInfo();
                //obj.DataState = XLY.Convert.ToDataState(data[a].XLY_DataType);
                obj.AppName = data[i].a;
                node.Items.push(obj);
            }
            if(node.Items!=""&&node.Items!=null){
                root.TreeNodes.push(node);
            }
        }
    }
}