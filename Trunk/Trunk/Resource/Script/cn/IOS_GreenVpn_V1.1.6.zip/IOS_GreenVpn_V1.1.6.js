﻿/*[config]
<plugin name="GreenVPN,7" group="生活旅游,6" devicetype="ios" pump="LocalData,usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/green.png" app="com.evergreen.negreenios" version="1.1.6" description="GreenVPN" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.evergreen.negreenios</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "150"></item>
    <item name="密码" code="PassWord" type="string" width="120"></item>
    <item name="邮箱" code="Emaill" type="string" width="150"></item>
    <item name="会员有效日期至" code="Expiration" type="string" width = "120"></item>
    <item name="登录时间" code="LoadingTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order="desc"></item>
    <item name="账号类型" code="UserType" type="string" width = "120"></item>
    <item name="账号积分" code="UserScore" type="string" width = "120"></item>
    <item name="今日已用流量" code="TodayReadable" type="string" width = "120"></item>
    <item name="累计已用流量" code="StatReadable" type="string" width = "120"></item>
    <item name="当前套餐" code="CurrentPackage" type="string" width = "120"></item>
    <item name="共获赠VIP" code="UserPrize" type="string" width = "120"></item>
</data>
<data type="Log" contract="DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="时间" code="Time" type="string" width="150"></item>
    <item name="内容" code="Content" type="string" width="150"></item>
</data>
<data type = "Search" contract="DataState"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width = "60"></item>  
    <item name="名称" code="Name" type="string" width = "80" ></item>
</data>
</plugin>
[config]*/
function Log(){
    this.DataState = "Normal";
    this.Time = "";
    this.Content = "";
}
function Search() {
    this.Name = "";
    this.DataState = "Normal";
}
//定义数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PassWord = "";
    this.Emaill = "";
    this.Expiration = "";
    this.LoadingTime = null;
    this.UserType = "";
    this.UserScore = "";
    this.TodayReadable = "";
    this.StatReadable = "";
    this.CurrentPackage = "";
    this.UserPrize = "";
}

function News(){
    this.DataState = "Normal";
    this.List = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var upath = source[0]+"\\com.evergreen.negreenios\\Library\\Preferences\\com.evergreen.negreenios.plist";
//测试数据
//var upath = "C:\\XLYSFTasks\\任务-2017-06-06-10-37-35\\source\\IosData\\2017-06-06-10-38-00\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.evergreen.negreenios\\Library\\Preferences\\com.evergreen.negreenios.plist";
//
//定义特征库文件
var charactor = "chalib\\Android_Chelaile_V3.24.2\\com.ygkj.chelaile.db.charactor";

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "GreenVPN";
    root.Type = "";
    getNews(root);
    
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(upath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(upath) +')');
        if(data!=""&&data!= null){
            var obj = new UserInfo();
            var node = new TreeNode();
            for(var i in data){
                if(data[i].User!=""&&data[i].User!= null){
                    var aa = data[i].User;
                    for(var j in aa){
                        obj.DataState = "Normal";
                        if(aa[j].email!=""&&aa[j].email!=null){
                            obj.Emaill = aa[j].email;
                        }
                        if(aa[j].expiration!=""&&aa[j].expiration!= null){
                            var fur = aa[j].expiration;
                            for(var r in fur){
                                if(fur[r].time_str!=""&&fur[r].time_str!=null){
                                    obj.Expiration = fur[r].time_str;
                                }
                            }
                            
                        }
                        if(aa[j].usertype!=""&&aa[j].usertype!=null){
                            obj.UserType = aa[j].usertype;
                        }
                        if(aa[j].userscore!=""&&aa[j].userscore!=null){
                            obj.UserScore = aa[j].userscore;
                        }
                        if(aa[j].traffic!=""&&aa[j].traffic!=null){
                            var ff = aa[j].traffic;
                            for(var f in ff){
                                if(ff[f].stat_readable!=""&&ff[f].stat_readable!=null){
                                    obj.TodayReadable = ff[f].stat_readable;
                                }
                                if(ff[f].today_readable!=""&&ff[f].today_readable!=null){
                                    obj.StatReadable = ff[f].today_readable;
                                }
                            }
                        }
                        if(aa[j].userprize!=""&&aa[j].userprize!=null){
                            obj.UserPrize = aa[j].userprize;
                            obj.CurrentPackage = aa[j].userprize;
                        }
                    }
                }
                if(data[i].user_pass_history!=""&&data[i].user_pass_history!= null){
                    var bb = data[i].user_pass_history[0][0];
                    for(var b in bb){
                        if(bb[b].username!=""&&bb[b].username!=null){
                            obj.UserName = bb[b].username;
                        }
                        if(bb[b].password!=""&&bb[b].password!=null){
                            obj.PassWord = bb[b].password;
                        }
                        if(bb[b].savetime!=""&&bb[b].savetime!=null){
                            obj.LoadingTime = XLY.Convert.LinuxToDateTime(bb[b].savetime);
                        }
                    }
                }
            }
            if(obj.UserName!=""&&obj.UserName!=null){
                node.Text = obj.UserName;
            }
            else
            {
                node.Text = "游客";
            }
            node.Type = "UserInfo";
            node.Items.push(obj);
            if(node.Items!=""&&node.Items!=null){
                root.TreeNodes.push(node);
            }
        }
        //root.Items.push(obj);
    }
}