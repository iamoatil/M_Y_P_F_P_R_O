﻿/*[config]
<plugin name="天猫,8" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="/icons/TianMao.png" app="com.tmall.wireless" version="4.0.0" description="天猫" data="$data,ComplexTreeDataSource"  >
<source>
<value>data/data/com.tmall.wireless/app_common/searchhistory.dat</value>
<value>data/data/com.tmall.wireless/app_common/browse_history.dat</value>
</source>

<data type="SearchHistory">
<item name="搜索关键字内容" code="key" type="string" width=""></item>
</data>

<data type="ShopHistory">
<item name="店铺编号" code="shopID" type="string" width="" ></item>
<item name="店铺名称" code="shopName" type="string" width="" format=""></item>
<item name="链接地址" code="url" type="URL" width="" format=""></item>
</data>

<data type="ItemsHistory">
<item name="宝贝编号" code="itemID" type="string" width="" format=""></item>
<item name="宝贝标题" code="itemName" type="string" width="300" ></item>
<item name="地点" code="address" type="string" width="" format=""></item>
<item name="所属店铺" code="shop" type="string" width="200" format=""></item>
<item name="价格" code="price" type="string" width="" format=""></item>
<item name="月销量" code="sellNum" type="string" width="" format=""></item>
<item name="链接地址" code="url" type="URL" width="300" format=""></item>
</data>

</plugin>
[config]*/

// js content

//定义数据结构
function SearchHistory() {
	this.key = "";  
}

function ShopHistory() {
	this.shopID = "";
	this.shopName == "";
	this.url = "";
}

function ItemsHistory() {
	this.itemName = "";
	this.itemID = "";
	this.url = "";
	this.address = "";
	this.shop = "";
	this.price = "";
	this.sellNum = "";
}
//树形结构
function TreeNode() {
	this.Text = "";//节点名称
	this.TreeNodes = new Array();//子节点数字
	this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
}

//搜索历史记录
function getSearchHistory(path)
{
	var arr = new Array();
	try{
		var data= eval('(' +XLY.File.ReadFile(path)+ ')');;
		for (var index in data) {
			var obj =new SearchHistory();
			obj.key=data[index].keyword;
			arr.push(obj)
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//店铺信息
function getShopHistory(path)
{
	var arr = new Array();
	try{
		var data= eval('(' +XLY.File.ReadFile(path)+ ')');;
		for (var index in data["1"]) {
			var obj =new ShopHistory();
			obj.shopID= data["1"][index].shopId;
			obj.shopName= data["1"][index].name;
			obj.url= data["1"][index].picUrl;
			arr.push(obj)
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//宝贝信息
function getItemsHistory(path)
{
	var arr = new Array();
	try{
		var data= eval('(' +XLY.File.ReadFile(path)+ ')');;
		for (var index in data["0"]) {
			var obj =new ItemsHistory();
			obj.itemName=data["0"][index].title;
			obj.itemID=data["0"][index].itemId;
			obj.url=data["0"][index].picUrl;
			obj.address=data["0"][index].location;
			obj.shop=data["0"][index].shopTitle;
			obj.price=data["0"][index].price;
			obj.sellNum=data["0"][index].sellCount;
			arr.push(obj)
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var PATH1 = source[0] ;
var PATH2 = source[1] ;

//节点实例化
var HistoryNode =new TreeNode();
HistoryNode.Text="浏览历史";

var ShopNode =new TreeNode();
ShopNode.Type="ShopHistory";
ShopNode.Text="商铺记录";

var ItemsNode =new TreeNode();
ItemsNode.Type="ItemsHistory";
ItemsNode.Text="宝贝记录";

var SearchNode =new TreeNode();
SearchNode.Type="SearchHistory";
SearchNode.Text="搜索历史";

//节点的数据填充
SearchNode.Items=getSearchHistory(PATH1);
ShopNode.Items=getShopHistory(PATH2);
ItemsNode.Items=getItemsHistory(PATH2);

//数据打印
HistoryNode.TreeNodes.push(ShopNode);
HistoryNode.TreeNodes.push(ItemsNode);
result.push(SearchNode);
result.push(HistoryNode);

var res = JSON.stringify(result);
res;
