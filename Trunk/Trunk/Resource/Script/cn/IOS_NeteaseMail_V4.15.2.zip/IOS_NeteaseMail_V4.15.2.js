﻿/*[config]
<plugin name="网易邮箱大师,6" group="主流邮箱,4" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Mail163.png" app="com.netease.mailmaster" version="4.15.2" description="网易邮箱大师" data="$data,ComplexTreeDataSource" >
<source>
<value>com.netease.mailmaster</value>
</source>
<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="邮箱地址" code="Address" type="string" width="" format = ""></item>
<item name="ID" code="ID" type="string" width="" format=""></item>
</data>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="Contact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="Address" type="string" width="" format = ""></item>
<item name="邮箱地址" code="Time" type="string" width="" format = ""></item>
</data>
<data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="ID" code="ID" type="string" width="150" format=""></item>
<item name="发件人" code="Send" type="string" width="150" format=""></item>
<item name="收件人" code="Receive" type="string" width="300" format=""></item>
<item name="发送时间" code="SendTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="接收时间" code="ReceiveTime" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="主题" code="Subject" type="string" width="200" format=""></item>
<item name="邮件内容" code="Content" type="string" width="200" format=""></item>
<item name="阅读状态" code="IsRead" type="string" width="150" format=""></item>
<item name="回复状态" code="IsReply" type="string" width="150" format=""></item>
<item name="红旗邮件" code="IsMark" type="string" width="150" format=""></item>
<item name="附件状态" code="IsAttach" type="string" width="150" format = ""></item>
<item name="附件信息" code="Attachments" type="string" width="150" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义Account数据结构
function Account() {
    this.Address = "";
    this.ID = "";
    this.DataState = "Normal";
}
function Info(){
    this.Acc = "";
}
function Contact() {
    this.Address = "";
    this.DataState = "Normal";
}
function Group(){
    this.GroupId = "";
    this.Name = "";
    this.DataState = "Normal";
}
//定义Message数据结构
function Message() {
    this.ID = "";
    this.Send = "";
    this.Receive = "";
    this.SendTime = null;
    this.ReceiveTime = null  ;
    this.Subject = "";
    this.IsReply = "";
    this.Content = "";
    this.IsRead = "";
    this.IsMark = "";
    this.IsAttach = "";
    this.Attachments = "";
    this.DataState = "Normal";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
//构建账户信息
function getAccountInfo(i){
    var account = new Account();
    account.ID = i.accountId;
    account.Address = i.email;
    account.DataState = XLY.Convert.ToDataState(i.XLY_DataType);
    return account;
}
function bindTree(){
    // 根节点
    var rootNode = new TreeNode();
    rootNode.Text = "网易邮箱大师";
    // 获取账户信息;
     var accountData = eval('('+ XLY.Sqlite.Find(db1,"select * from account" ) +')'); 
    for(var i in accountData){
        var account = new TreeNode();
        account.Text = accountData[i].email;
        account.Type = "Account";
        account.DataState = XLY.Convert.ToDataState(accountData[i].XLY_DataType);
         var accountInfo = getAccountInfo(accountData[i]);
         account.Items.push(accountInfo);
           // 获取账户分组节点
           getAccountGroupNode(accountInfo,account)
          rootNode.TreeNodes.push(account);
         // 获取联系人信息;
        var contact = new TreeNode();
        contact.Text = "通讯录";
        contact.Type = "Contact";
        contact.DataState = "Normal";
        contact.Items = getConatactInfo(db2, accountInfo);
        account.TreeNodes.push(contact);
        
    } 
     return rootNode;
}
 
//获取帐号通讯录信息
function getConatactInfo(db2, accountInfo) {
    var data = eval('(' + XLY.Sqlite.Find(db2, "select * from contact_view where aid ='" + accountInfo.ID + "' ") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Contact();
        obj.Address = data[index].name;
        obj.Time =  data[index].data_0; 
        info.push(obj);
    }
    return info;
}
 // 获取账户分组节点
 function getAccountGroupNode(account,parentTree){
    var groupNodes = eval('('+ XLY.Sqlite.Find(db1,"select * from mailBox where accountRawId = "+account.ID+"") +')');
    var emailData= eval('('+ XLY.Sqlite.Find(db1,"select * from mailAbstract where accountRawId = "+account.ID+"") +')');
      for(var i in groupNodes){    
        var groupTree = new TreeNode();
        var group = getGroup(groupNodes[i]);
        groupTree.Text = group.Name;
        groupTree.Type = "Message";
        groupTree.DataState = group.DataState;
        // 获取当前分组下的邮件信息;
        LoadGroupMessageNode(group,emailData,groupTree);
        parentTree.TreeNodes.push(groupTree);
      }
}
// 加载分组信息;
function getGroup(group){
    var groupInfo = new Group();
    if(group==null) return groupInfo;
    groupInfo.GroupId = group.type;
    groupInfo.Name = group.name;
    groupInfo.DataState = XLY.Convert.ToDataState(group.XLY_DataType);
    return groupInfo;
}
// 获取分组信息节点
function LoadGroupMessageNode(group,emailData,parent){
    // 获取重要联系人
        for(var i in emailData){
            if(emailData[i].mailBoxId==group.GroupId){
                var mail = CreateMail(emailData[i]);
                parent.Items.push(mail);
            }
        }    
}
// 获取邮件信息
function CreateMail(mail){
    var mailInfo = new Message();
    var sender = eval('('+ mail.mailFrom +')');
    mailInfo.Send = sender.name+"("+sender.email+")";
    var receiver = eval('('+ mail.mailTos +')'); 
    mailInfo.Receive = receiver[0].name+"("+receiver[0].email+")";
    mailInfo.Subject = mail.subject;
    mailInfo.ID = mail.messageId;
    mailInfo.ReceiveTime = XLY.Convert.LinuxToDateTime(mail.recvDate);
    mailInfo.SendTime = XLY.Convert.LinuxToDateTime(mail.sentDate);
    mailInfo.Content = mail.summary;
    if(mail.hasAttachments == 1){
        var emailAttach = eval('('+ XLY.Sqlite.Find(db1,"select * from mailAttachment where mailId = '"+mail.localId+"'") +')');
        for(var attach in emailAttach){
            var str = "附件名称:"+emailAttach[attach].name+";附件大小:"+emailAttach[attach].size/1024+" KB";
            mailInfo.Attachments = str;
        }
    }
    mailInfo.IsRead = (mail.unread == 1) ? "已读" : "未读";
    mailInfo.IsReply = (mail.isReplied == 1) ? "已回复" : "未回复";
    mailInfo.IsMark = (mail.stared == 1) ? "是" : "否";
    mailInfo.IsAttach = (mail.hasAttachments) ? "有附件" : "无附件";
    mailInfo.DataState = "Normal";
    return mailInfo;
}
//********************************************************
var source = $source;
var db = source[0]+"\\com.netease.mailmaster\\Documents\\imail.db";
var db2 = source[0]+"\\com.netease.mailmaster\\Documents\\contacts.db";
var charactor = "\\chalib\\IOS_NeteaseMail_V4.15.2\\imail.db.charactor";
//var db = "D:\\temp\\data\\data\\AppDomain-com.netease.mailmaster\\Documents\\imail.db";
//var db2 = "D:\\temp\\data\\data\\AppDomain-com.netease.mailmaster\\Documents\\contacts.db";
//var charactor = "D:\\temp\\data\\data\\AppDomain-com.netease.mailmaster\\Documents\\imail.db.charactor";
var db1 = XLY.Sqlite.DataRecovery(db,charactor,"account,mailAbstract,mailAttachment,mailBox,mailContent");
var result = new Array();
result.push(bindTree());
var res = JSON.stringify( result );
res;