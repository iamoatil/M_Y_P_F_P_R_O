﻿/*[config]
<plugin name="海豚浏览器,4" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="\icons\DolphinBrowser.png" app="com.dolphin.browser.xf" version="11.2.6" description="海豚浏览器"  data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.dolphin.browser.xf/app_webview/Cookies</value>
    <value>/data/data/com.dolphin.browser.xf/databases/browser.db</value>
    <value>/data/data/com.dolphin.browser.xf/databases/dolphin_webviewCache.db</value>
    <value>/data/data/com.dolphin.browser.xf/databases/downloads.db</value>
    <value>/data/data/com.dolphin.browser.xf/databases/launcher2.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="主键" code="Key" type="string" width = "150"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="值" code="Value" type="string" width = "200"></item>
    </data>
   <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
 <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
 <data type="Cache" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="文件路径" code="FilePath" type="string" width = "150"></item>
    <item name="修改时间" code="Modify" type="string" width = "200"></item>
    <item name="失效时间" code="Expire" type="string" width = "200"></item>
    <item name="类型" code="Type" type="string" width = "150"></item>
    <item name="内容长度" code="Length" type="string" width = "150"></item>
    
    </data>
 <data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="类型" code="Type" type="string" width = "150"></item>
     <item name="时间" code="Time" type="string" width = "150"></item>
     <item name="Cookies" code="Cookies" type="string" width = "150"></item>
     <item name="代理" code="Agent" type="string" width = "150"></item>
     <item name="总大小" code="TotalSize" type="string" width = "150"></item>
     <item name="已下载大小" code="CurrentSize" type="string" width = "150"></item>
     <item name="用户ID" code="Id" type="string" width = "150"></item>
     <item name="下载目录" code="Dir" type="string" width = "150"></item>   
    </data>
 <data type="Favorite" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    <item name="访问次数" code="Visits" type="string" width = "200"></item>
    <item name="图标" code="Icon" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
}
function Cache() {
    this.DataState = "Normal";
    this.FilePath = "";
    this.Url = "";
    this.Modify = "";
    this.Expire = "";
    this.Type = "";
    this.Length = "";
}
function Download() {
    this.DataState = "Normal";
    this.Url = "";
    this.Name = "";
    this.Type = "";
    this.Time = "";
    this.Cookies = "";
    this.Agent = "";
    this.TotalSize = "";
    this.CurrentSize = "";
    this.Id = "";
    this.Dir = "";
}
function Favorite() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
    this.Visits = "";
    this.Icon = "";
}


//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}

function bindTree() {
    newTreeNode("Cookies", "Cookies", getCookies(db5));
    newTreeNode("书签", "Bookmark", getBookmark(db6));
    newTreeNode("浏览记录", "History", getHistory(db6));
    newTreeNode("缓存", "Cache", getCache(db7));
    newTreeNode("下载文件", "Download", getDownload(db8));
    newTreeNode("收藏", "Favorite", getFavorite(db9));
}
function getNews() {
    var list = new Array();
    data = ["Cookies", "书签", "浏览记录", "缓存", "收藏", "下载"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getCookies(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies") + ')');
    for (var i in data) {
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmarks") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCache(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cache") + ')');
    for (var i in data) {
        var obj = new Cache();
        obj.FilePath = data[i].filepath;
        obj.Url = data[i].url;
        obj.Modify = data[i].lastmodify;
        obj.Expire = data[i].expiresstring;
        obj.Type = data[i].mimetype;
        obj.Length = data[i].contentlength;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from downloads") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Url = data[i].uri;
        obj.Name = data[i].hint;
        obj.Type = data[i].mimetype;
        obj.Cookies = data[i].cookiedata;
        obj.Agent = data[i].useragent;
        obj.TotalSize = data[i].total_bytes + " bytes";
        obj.CurrentSize = data[i].current_bytes + " bytes";
        obj.Id = data[i].uid;
        obj.Dir = data[i].download_dir;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].lastmod);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFavorite(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from favorites2") + ')');
    for (var i in data) {
        var obj = new Favorite();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].clicks;
        obj.Icon = data[i].iconResource;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
var db2 = source[2];
var db3 = source[3];
var db4 = source[4];

var charactor = "\\chalib\\Android_DolphinBrowser_V11.2.6\\Cookies.charactor";
var charactor1 = "\\chalib\\Android_DolphinBrowser_V11.2.6\\browser.db.charactor";
var charactor2 = "\\chalib\\Android_DolphinBrowser_V11.2.6\\dolphin_webviewCache.db.charactor";
var charactor3 = "\\chalib\\Android_DolphinBrowser_V11.2.6\\downloads.db.charactor";
var charactor4 = "\\chalib\\Android_DolphinBrowser_V11.2.6\\launcher2.db.charactor";

var db5 = XLY.Sqlite.DataRecovery(db, charactor, "cookies");
var db6 = XLY.Sqlite.DataRecovery(db1, charactor1, "bookmarks,history");
var db7 = XLY.Sqlite.DataRecovery(db2, charactor2, "cache");
var db8 = XLY.Sqlite.DataRecovery(db3, charactor3, "downloads");
var db9 = XLY.Sqlite.DataRecovery(db4, charactor4, "favorites2");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
