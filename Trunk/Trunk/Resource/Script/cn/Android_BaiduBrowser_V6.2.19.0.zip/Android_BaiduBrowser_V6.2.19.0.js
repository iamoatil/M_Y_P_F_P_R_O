﻿/*[config]
<plugin name="百度浏览器" group="Web痕迹,7" devicetype="android" icon="\icons\baidubrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.baidu.browser.apps" version="6.2.19.0" description="百度浏览器" data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.baidu.browser.apps/databases/dbbrowser.db</value>
    <value>/data/data/com.baidu.browser.apps/app_webview/Cookies</value>
    <value>/data/data/com.baidu.browser.apps/databases/flyflowdownload.db</value>
    </source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="主键" code="Key" type="string" width = "150"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="值" code="Value" type="string" width = "200"></item>
    </data>
 <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="搜索关键字" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
<data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="最后访问时间" code="Time" type="string" width = "200"></item>
    <item name="创建时间" code="Create" type="string" width = "200"></item>
    </data>
<data type="MobileBookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    <item name="最后访问时间" code="Last" type="string" width = "200"></item>
    <item name="同步时间" code="Sync" type="string" width = "200"></item>
    <item name="同步ID" code="SyncID" type="string" width = "200"></item>
    <item name="账号ID" code="AccountID" type="string" width = "200"></item>
    <item name="设备平台" code="Platform" type="string" width = "200"></item>
    </data>
<data type="PCBookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    <item name="最后访问时间" code="Last" type="string" width = "200"></item>
    <item name="同步时间" code="Sync" type="string" width = "200"></item>
    <item name="同步ID" code="SyncID" type="string" width = "200"></item>
    <item name="账号ID" code="AccountID" type="string" width = "200"></item>
    <item name="设备平台" code="Platform" type="string" width = "200"></item>
    <item name="编辑时间" code="Edit" type="string" width = "200"></item>
    </data>
<data type="HomePage" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="同步ID" code="Id" type="string" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="最后访问时间" code="Time" type="string" width = "200"></item>
    <item name="创建时间" code="Create" type="string" width = "200"></item>
    <item name="编辑时间" code="Edit" type="string" width = "200"></item>
    <item name="设备平台" code="Platform" type="string" width = "200"></item>
    <item name="账号ID" code="AccountID" type="string" width = "200"></item>   
    </data>
<data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="值" code="Key" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="存储路径" code="Path" type="string" width = "150"></item>
    <item name="文件大小" code="Size" type="string" width = "150"></item>
    <item name="开始时间" code="Time" type="string" width = "150"></item>
    <item name="结束时间" code="EndTime" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function HomePage() {
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Id = "";
    this.Visits = "";
    this.Time = "";
    this.Create = "";
    this.Edit = "";
    this.Platform = "";
    this.AccountID = "";
}
function Search() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
    this.Create = "";
}
function MobileBookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
    this.Last = "";
    this.Sync = "";
    this.SyncID = "";
    this.AccountID = "";
    this.Platform = "";
}
function PCBookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
    this.Last = "";
    this.Sync = "";
    this.SyncID = "";
    this.AccountID = "";
    this.Platform = "";
    this.Edit = "";
}
function Download() {
    this.DataState = "Normal";
    this.Key = "";
    this.Url = "";
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.Time = "";
    this.EndTime = "";
}

//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}
function bindTree() {
    newTreeNode("主页信息", "HomePage", getHomePage(db));
    newTreeNode("搜索", "Search", getSearch(db));
    newTreeNode("浏览记录", "History", getHistory(db));
    newTreeNode("手机书签", "MobileBookmark", getMobileBookmark(db));
    newTreeNode("电脑书签", "PCBookmark", getPCBookmark(db));
    newTreeNode("Cookies", "Cookies", getCookies(db1));
    newTreeNode("下载", "Download", getDownload(db2));
}
function getNews() {
    var list = new Array();
    data = ["主页信息", "搜索", "浏览记录", "手机书签", "电脑书签", "Cookies", "下载"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getCookies(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies") + ')');
    for (var i in data) {
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHomePage(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from homepage") + ')');
    for (var i in data) {
        var obj = new HomePage();
        obj.Name = data[i].title;
        obj.Url = data[i].url;
        obj.Id = data[i].sync_uuid;
        obj.Visits = data[i].visits;
        obj.AccountID = data[i].account_uid;
        obj.Platform = data[i].platform;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Create = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Edit = XLY.Convert.LinuxToDateTime(data[i].edit_time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from url_input_record") + ')');
    for (var i in data) {
        var obj = new Search();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from history") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Create = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getMobileBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmark") + ')');
    for (var i in data) {
        var obj = new MobileBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.AccountID = data[i].account_uid;
        obj.SyncID = data[i].sync_uuid;
        obj.Platform = data[i].platform;
        obj.Id = data[i].sync_uuid;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Last = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Sync = XLY.Convert.LinuxToDateTime(data[i].sync_time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getPCBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from pc_bookmark") + ')');
    for (var i in data) {
        var obj = new PCBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.AccountID = data[i].account_uid;
        obj.SyncID = data[i].sync_uuid;
        obj.Platform = data[i].platform;
        obj.Id = data[i].sync_uuid;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Last = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Sync = XLY.Convert.LinuxToDateTime(data[i].sync_time);
        obj.Edit = XLY.Convert.LinuxToDateTime(data[i].edit_time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bddownloadtable") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Key = data[i].key;
        obj.Url = data[i].url;
        obj.Name = data[i].filename;
        obj.Path = data[i].savepath;
        obj.Size = data[i].total + "bytes";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].createdtime);
        obj.EndTime = XLY.Convert.LinuxToDateTime(data[i].completetime);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
var db2 = source[2];

var charactor1 = "\\chalib\\Android_BaiduBrowser_V6.2.19.0\\dbbrowser.db.charactor";
var charactor2 = "\\chalib\\Android_BaiduBrowser_V6.2.19.0\\Cookies.charactor";
var charactor3 = "\\chalib\\Android_BaiduBrowser_V6.2.19.0\\flyflowdownload.charactor";

var db = XLY.Sqlite.DataRecovery(db, charactor1, "homepage,url_input_record,history,bookmark,pc_bookmark");
var db1 = XLY.Sqlite.DataRecovery(db1, charactor2, "cookies");
var db2 = XLY.Sqlite.DataRecovery(db2, charactor3, "bddownloadtable");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
