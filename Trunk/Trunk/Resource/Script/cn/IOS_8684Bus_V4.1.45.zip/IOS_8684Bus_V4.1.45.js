﻿/*[config]
<plugin name="公交8684,4" group="地图公交,5" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\ChinaBus.png" app="com.tiantian.-684--" version="4.1.45" description="公交8684" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tiantian.-684--</value>
</source>

<data type="Gohome">
<item name="名称" code="Name" type="string" width="100" ></item>
<item name="地址" code="Address" type="string" width="200" ></item>
<item name="经度" code="Longitude" type="string" width="200"></item>
<item name="纬度" code="Latitude" type="string" width="580" ></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Gohome() {
    this.Name = "";
    this.Address = "";
    this.Longitude = "";
    this.Latitude = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

function getGohome(path,sql){
    var data=eval('('+XLY.Sqlite.Find(path,sql)+')');
    var arr=new Array();
    for(var index in data){
        var object=new Gohome;
        object.Name=data[index].title;
        object.Address = data[index].address;
        if (data[index].lat > 90) {
            object.Longitude = data[index].lat;
            object.Latitude = data[index].lng;
        } else {
            object.Longitude = data[index].lng;
            object.Latitude = data[index].lat;
        }
        arr.push(object)
    }
    return arr;
}
var result = new Array();
//源文件
var source = $source;
var path = source[0] + "com.tiantian.-684--\\Library\\Caches\\gohome"
//var path="E:\\app data\\Iphone\\chinabusv4.1.45\\Library\\Caches\\gohome";
var gosql="select title,address,lat,lng from gohome";
var gohome = new TreeNode();
gohome.Text = "快捷设置";
gohome.Type = "Gohome";
var gohomeinfo = getGohome(path, gosql);
gohome.Items = gohomeinfo;

result.push(gohome);
var res = JSON.stringify(result);
res;
