﻿/*[config]
<plugin name="三星天气,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/weather.png" app="com.sec.android.daemonapp" version="1.1.8" description="三星天气" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.sec.android.daemonapp/databases/WeatherClock</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="AddCityInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="城市ID" code="Id" type="string" width = "80"></item>
    <item name="城市名称" code="Name" type="string" width="120"></item>
    <item name="地点" code="State" type="string" width="120"></item>
    <item name="国家" code="Country" type="string" width="120"></item>
    <item name="添加时间" code="AddTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="时区" code="TimeZone" type="string" width="80"></item>
    <item name="更新时间" code="UpdateTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="当前温度" code="CurrentTemp" type="string" width="80"></item>
    <item name="最高温度" code="HighTemp" type="string" width="80"></item>
    <item name="最低温度" code="LowTemp" type="string" width="80"></item>
    <item name="昨天最高温度" code="YesHighTemp" type="string" width="80"></item>
    <item name="昨天最低温度" code="YesLowTemp" type="string" width="80"></item>
    <item name="空气质量指数" code="WeatherAQI" type="string" width = "80"></item>
    <item name="链接" code="WeatherUrl" type="url" width = "120"></item>
    <item name="是否当前使用" code="IsCurrent" type="string" width = "80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义AddCityInfo数据结构
function AddCityInfo(){
    this.DataState = "Normal";
    this.Id = "";
    this.Name = "";
    this.State = "";
    this.Country = "";
    this.AddTime = null;
    this.TimeZone = "";
    this.UpdateTime = null;
    this.CurrentTemp = "";
    this.HighTemp = "";
    this.LowTemp = "";
    this.YesHighTemp = "";
    this.YesLowTemp = "";
    this.WeatherAQI = "";
    this.WeatherUrl = "";
    this.IsCurrent = "否";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var weatherClockPath1 = source[0];

//测试数据
//var weatherClockPath1 = "D:\\资料工作\\com.sec.android.daemonapp\\databases\\WeatherClock";
//定义特征库文件
var charactor = "\\chalib\\Android_SamsuangWeather_V1.1.8\\WeatherClock.charactor";
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
var weatherClockPath = XLY.Sqlite.DataRecovery(weatherClockPath1,charactor,"TABLE_WEATHER_INFO");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "三星天气";
    root.Type = "";
    getNews(root);
    result.push(root);
}
function getNews(root){
    if(XLY.File.IsValid(weatherClockPath)){
        var data = eval('('+ XLY.Sqlite.Find(weatherClockPath,"select XLY_DataType,COL_WEATHER_KEY,COL_WEATHER_NAME,COL_WEATHER_STATE,COL_WEATHER_COUNTRY,COL_WEATHER_LOCATION,COL_WEATHER_TIME,COL_WEATHER_TIMEZONE,COL_WEATHER_UPDATE_TIME,COL_WEATHER_CURRENT_TEMP,COL_WEATHER_HIGH_TEMP,COL_WEATHER_LOW_TEMP,COL_WEATHER_YESTERDAY_HIGH_TEMP,COL_WEATHER_YESTERDAY_LOW_TEMP,COL_WEATHER_AQI_INDEX,COL_WEATHER_URL from TABLE_WEATHER_INFO") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = "添加城市列表";
            node.Type = "AddCityInfo";
            for(var i in data){
                var obj = new AddCityInfo();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.Id = data[i].COL_WEATHER_LOCATION;
                obj.Name = data[i].COL_WEATHER_NAME;
                obj.State = data[i].COL_WEATHER_STATE;
                obj.Country = data[i].COL_WEATHER_COUNTRY;
                obj.AddTime = XLY.Convert.LinuxToDateTime(data[i].COL_WEATHER_TIME);
                obj.TimeZone = data[i].COL_WEATHER_TIMEZONE;
                obj.UpdateTime = XLY.Convert.LinuxToDateTime(data[i].COL_WEATHER_UPDATE_TIME);
                obj.CurrentTemp = data[i].COL_WEATHER_CURRENT_TEMP;
                obj.HighTemp = data[i].COL_WEATHER_HIGH_TEMP;
                obj.LowTemp = data[i].COL_WEATHER_LOW_TEMP;
                obj.YesHighTemp = data[i].COL_WEATHER_YESTERDAY_HIGH_TEMP;
                obj.YesLowTemp = data[i].COL_WEATHER_YESTERDAY_LOW_TEMP;
                obj.WeatherAQI = data[i].COL_WEATHER_AQI_INDEX;
                obj.WeatherUrl = data[i].COL_WEATHER_URL;
                if(data[i].COL_WEATHER_KEY=="cityId:current"){
                    obj.IsCurrent = "是";
                }
                node.Items.push(obj);
            }
            if(node.Items!=""&&node.Items!=null){
                root.TreeNodes.push(node);
            }
        }
    }
}