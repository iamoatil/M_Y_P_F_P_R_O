﻿/*[config]
<plugin name="美团,12" group="生活旅游,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/meituan.png" app="com.sankuai.meituan" version="5.4.1" description="美团" data="$data,ComplexTreeDataSource"  >
<source>
    <value>data/data/com.sankuai.meituan/databases/meituan.db</value>
    <value>data/data/com.sankuai.meituan/shared_prefs/loginStore.xml</value>
    <value>data/data/com.sankuai.meituan/shared_prefs/user_login_tip.xml</value>
</source>
<data  type="DealList"  contract="DataState,Map" detailfield="TERMS"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="ID" code="ID" type="String" width="100"></item>
    <item name="标题" code="Desc" type="String" width="400"></item>
    <item name="纬度" code="Latitude" type="double" format ="F6" width="100" ></item>
    <item name="经度" code="Longitude" type="double" format ="F6" width="100" ></item>
    <item name="区域" code="RANGE" type="String" width="100" ></item>
    <item name="缩略图标" code="IMGURL" type="String" width="100" show="false"></item>
    <item name="备注" code="ATTR_JSON" type="String" width="300"></item>
    <item name="注意" code="TERMS" type="String" width="300" ></item>
</data>

<data type="DealComment" datefilter="FEEDBACKTIME" contract="DataState" detailfield="COMMENT"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="用户ID" code="USERID" type="String" width="100" ></item>
    <item name="团购ID" code="DID" type="String" width="100" ></item>
    <item name="满意度" code="SCORETEXT" type="String" width="100" ></item>
    <item name="评论" code="COMMENT" type="String" width="300" ></item>
    <item name="用户名" code="USERNAME" type="String" width="100" ></item>
    <item name="反馈时间" code="FEEDBACKTIME" type="DateTime" width="100" format = "yyyy年MM月dd日 HH:mm"></item>
    <item name="回复" code="BIZREPLY" type="String" width="300" ></item>
</data>

<data type="HotelList"  contract="DataState,Map" detailfield="INTRODUCTION"> 
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="酒店名称" code="Desc" type="String" width="100" ></item>
    <item name="地址" code="ADDR" type="String" width="400" ></item>
    <item name="联系电话" code="PHONE" type="String" width="100"></item>
    <item name="单价" code="AVG_PRICE" type="String" width="100" ></item>
    <item name="纬度" code="Latitude" type="double" format ="F6" width="100" ></item>
    <item name="经度" code="Longitude" type="double" format ="F6" width="100" ></item>
    <item name="简介" code="INTRODUCTION" type="String" width="300" ></item>
    <item name="距离定位" code="POSDESCR" type="String" width="100" ></item>
    <item name="停车位" code="PARKING_INFO" type="String" width="100"></item>
</data>

<data type="MovieList" datefilter="START" contract = "DataState">   
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="名称" code="NAME" type="String" width="200" ></item>
    <item name="分数" code="SCORE" type="String" width="100" ></item>
    <item name="上映" code="START" type="DateTime" width="100" format = "yyyy年MM月dd日 HH:mm"></item>
    <item name="导演" code="DIRECTOR" type="String" width="100" ></item>
    <item name="演员" code="STARS" type="String" width="300" ></item>
    <item name="放映时间" code="LENGTH" type="String" width="100" ></item>
</data>

<data type="AllList"  contract = "DataState,Map">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="主键" code="ID" type="String" width="100"></item>
    <item name="名称" code="Desc" type="String" width="200"></item>
    <item name="电话" code="PHONE" type="String" width="100"></item>
    <item name="地址" code="ADDR" type="String" width="400"></item>
    <item name="价格" code="AVG_PRICE" type="String" width="100"></item>
    <item name="评分" code="AVG_SCORE" type="String" width="100"></item>
    <item name="区域" code="AREA_NAME" type="String" width="100"></item>
    <item name="类型" code="CATE_NAME" type="String" width ="100"></item>
    <item name="纬度" code="Latitude" type="double" format ="F6" width="100"></item>
    <item name="经度" code="Longitude" type="double" format ="F6" width="100"></item>
</data>

<data type="AllComment"  contract = "DataState" datefilter="FEEDBACKTIME" detailfield="COMMENT">   
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="用户ID" code="USERID" type="String" width="100"></item>
    <item name="团购ID" code="POIID" type="String" width="100"></item>
    <item name="满意度" code="SCORETEXT" type="String" width="100"></item>
    <item name="评论" code="COMMENT" type="String" width="100"></item>
    <item name="用户名" code="USERNAME" type="String" width="100"></item>
    <item name="反馈时间" code="FEEDBACKTIME" type="DateTime" width="100" format = "yyyy年MM月dd日 HH:mm"></item>
    <item name="回复" code="BIZREPLY" type="String" width="100"></item>
</data>

<data type="DailyNews"  contract = "DataState" detailfield="MESSAGE" datefilter="LAST_PULL_TIME">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="消息" code="MESSAGE" type="String" width="100" ></item>
    <item name="推送时间" code="LAST_PULL_TIME" type="DateTime" width="100" format = "yyyy年MM月dd日 HH:mm"></item>
</data>

<data type="UserInfo"  contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="用户名" code="UserName" type="String" width="100" ></item>
    <item name="绑定手机" code="BindMobile" type="String" width="100" ></item>
</data>

<data type="MyCode"  contract = "DataState" detailfield="TITLE">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item> 
    <item name="标题" code="TITLE" type="String" width="100"></item>
    <item name="时间" code="TIME" type="String" width="200"></item>
    <item name="抽奖号" code="CODE" type="String" width="100"></item>
</data>

<data type="MyDeal"  contract = "DataState" detailfield="DEAL">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
    <item name="下单时间" code="ORDERTIME" type="String" width="100"></item>
    <item name="订单详情" code="DEAL" type="String" width="500"></item>
    <item name="手机" code="MOBILE" type="DateTime" width="100"></item>
</data>

</plugin>
[config]*/

// js content

//定义数据结构
function DealList() {
    this.DataState = "Normal";
    this.ID = "";
    this.Desc ="";
    this.Latitude = 0;
    this.Longitude= 0;
    this.RANGE="";
    this.IMGURL="";
    this.ATTR_JSON="";
    this.TERMS="";
}
function DealComment() {
    this.DataState = "Normal";
    this.USERID="";
    this.DID="";
    this.SCORETEXT="";
    this.COMMENT="";
    this.USERNAME="";
    this.FEEDBACKTIME="";
    this.BIZREPLY="";
    this.USERID="";
    this.SCORETEXT="";
    this.COMMENT="";
    this.USERNAME="";
    this.FEEDBACKTIME="";
    this.BIZREPLY="";  
}
function HotelList() {
    this.DataState = "Normal";  
    this.Desc="";  
    this.ADDR="";  
    this.PHONE="";  
    this.AVG_PRICE="";  
    this.Latitude = 0;
    this.Longitude= 0;  
    this.INTRODUCTION="";  
    this.POSDESCR="";  
    this.PARKING_INFO="";  
}

function MovieList() {
    this.DataState = "Normal"; 
    this.NAME="";  
    this.ADDR="";  
    this.PHONE="";  
    this.AVG_PRICE="";  
    this.LAT="";  
    this.LNG="";  
    this.INTRODUCTION="";  
    this.POSDESCR="";  
    this.PARKING_INFO="";  
}
function AllList() {
    this.DataState = "Normal";
    this.ID="";
    this.Desc="";
    this.PHONE="";
    this.ADDR="";
    this.AVG_SCORE="";
    this.AREA_NAME="";
    this.CATE_NAME = "";
    this.Latitude = 0;
    this.Longitude= 0; 
}
function AllComment() {
    this.DataState = "Normal";
    this.USERID="";
    this.POIID="";
    this.SCORETEXT="";
    this.COMMENT="";
    this.USERNAME="";
    this.FEEDBACKTIME="";
    this.BIZREPLY="";
    this.USERID="";
    this.SCORETEXT="";
    this.COMMENT="";
    this.USERNAME="";
    this.FEEDBACKTIME="";
    this.BIZREPLY="";  
}
function DailyNews() {
    this.MESSAGE = "";  
    this.LAST_PULL_TIME = "";  
    this.DataState = "Normal";    
}
function UserInfo() {
    this.UserName = "";  
    this.BindMobile = ""; 
    this.DataState = "Normal";    
}
function MyCode() {
    this.TITLE = "";  
    this.TIME = "";  
    this.CODE = ""; 
    this.DataState = "Normal";    
}
function MyDeal() {
    this.ORDERTIME = "";  
    this.DEAL = "";  
    this.MOBILE = ""; 
    this.DataState = "Normal";    
}
//树形结构
function TreeNode() {
    this.Text = "";//节点名称
    this.TreeNodes = new Array();//子节点数字
    this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
    this.DataState = "Normal";  
}

////获取每日推送
function GetDailyNews(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from DailyNewDeal order by LAST_PULL_TIME desc") + ')');
for(var index in data)
{
    var obj=new DailyNews();
    obj.MESSAGE = data[index].MESSAGE;  
    obj.LAST_PULL_TIME = XLY.Convert.LinuxToDateTime(data[index].LAST_PULL_TIME);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

//获取酒店清单
function GetHotelList(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from hotel_poi order by LAST_MODIFIED desc") + ')');
for(var index in data)
{
    var obj=new HotelList();
    obj.PHONE = data[index].PHONE;  
    obj.Latitude = data[index].LAT;  
    obj.Longitude = data[index].LNG;  
    obj.ADDR = data[index].ADDR;  
    obj.Desc = data[index].NAME;  
    obj.PARKING_INFO = data[index].PARKING_INFO;  
    obj.AVG_PRICE = data[index].AVG_PRICE;  
    obj.INTRODUCTION = data[index].INTRODUCTION;  
    obj.POSDESCR = data[index].POSDESCR;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    obj.LAST_MODIFIED = XLY.Convert.LinuxToDateTime(data[index].LAST_MODIFIED);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}
//获取电影清单
function GetMovieList(path)
{
var arr = new Array();
try{
var data = eval('(' + XLY.Sqlite.Find(path, "select * from movieDetail order by START desc") + ')');
for(var index in data)
{
    var obj = new MovieList();
    obj.NAME = data[index].NAME;  
    obj.SCORE = data[index].SCORE;  
    obj.START = data[index].START;  
    obj.DIRECTOR = data[index].DIRECTOR;  
    obj.STARS = data[index].STARS;  
    obj.LENGTH = data[index].LENGTH;  
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}
//获取用户信息
function GetUserInfo(path2,path3)
{
var arr = new Array();
try{
    var data = eval('(' + XLY.File.ReadXML(path2) + ')');
    var obj=new UserInfo();
for(var index in data.map.string)
{
    if(data.map.string[index]["@name"]=="username")
    obj.UserName = data.map.string[index]["#text"]; 
}
data = eval('(' + XLY.File.ReadXML(path3) + ')');
for(var index in data.map.string)
{
    if(data.map.string[index]["@name"]=="NORMAL_USER_last_user")
    obj.BindMobile = data.map.string[index]["#text"];    
}
arr.push(obj);
return arr;
}
catch(e){
return arr;
}
}

function GetDealList(path)
{
    
try{
    var arr = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from deal ") + ')');
    
for(var index in data)
{
    var obj = new DealList();
    if(data[index].MLLS.indexOf(";") == -1)
    {
    obj.Latitude = data[index].MLLS.substr(0,data[index].MLLS.indexOf(","));
    obj.Longitude = data[index].MLLS.substr(data[index].MLLS.indexOf(",")+1,data[index].MLLS.length-data[index].MLLS.indexOf(",")-1);
    }    
    obj.ID = data[index].ID;
    obj.RANGE = data[index].RANGE;
    obj.IMGURL = data[index].IMGURL;
    obj.Desc = data[index].TITLE;
    var text = "";
    var b = "";
    var a = eval('(' +data[index].ATTR_JSON+ ')');
    for(var i in a)
    {
        if(a[i]!=null)
        {
            b+=" "+a[i].iconname;  
        }
    }
    obj.ATTR_JSON = b;
    var d = "";
    var c = eval(data[index].TERMS);
    for(var t in c)
    {
            d+=c[t].title+":"+c[t].content+"\n";  
    }    
    obj.TERMS = d;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}

function GetAllList(path)
{
var arr = new Array();
try{
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from POI ") + ')');
for(var index in data)
{
    var obj=new DealList();
    obj.ID = data[index].ID;
    obj.ADDR = data[index].ADDR;
    obj.AVG_PRICE = data[index].AVG_PRICE;
    obj.AVG_SCORE = data[index].AVG_SCORE;
    obj.Desc = data[index].NAME;
    obj.PHONE = data[index].PHONE;
    obj.AREA_NAME = data[index].AREA_NAME;
    obj.CATE_NAME = data[index].CATE_NAME;
    obj.Longitude = data[index].LNG;
    obj.Latitude = data[index].LAT;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
}


function CreateNode(type,text,dbInfo,root)
{

    var childNode =new TreeNode();
    childNode.Type=type;
    childNode.Text = text;
    if(dbInfo)
    childNode.Items = dbInfo;
    root.push(childNode);
}

function GetDealComment(path,did)
{
    
var arr = new Array();
try{
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from deal_comment where DID = "+did+" order by FEEDBACKTIME desc") + ')');
for(var index in data)
{
    var obj = new DealComment();
    obj.DID = data[index].DID;  
    obj.USERID = data[index].USERID;  
    obj.MESSAGE = data[index].MESSAGE;
    obj.SCORETEXT = data[index].SCORETEXT;
    obj.COMMENT = data[index].COMMENT;
    obj.USERNAME = data[index].USERNAME;
    obj.BIZREPLY = data[index].BIZREPLY;
    obj.FEEDBACKTIME =data[index].FEEDBACKTIME;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}
    
}

function GetAllComment(path,pid)
{
var arr = new Array();
try{
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from poi_comment where POIID = "+pid+" order by FEEDBACKTIME desc") + ')');
for(var index in data)
{
    var obj = new DealComment();
    obj.POIID = data[index].POIID; 
    obj.USERID = data[index].USERID;  
    obj.MESSAGE = data[index].MESSAGE;
    obj.SCORETEXT = data[index].SCORETEXT;
    obj.COMMENT = data[index]. COMMENT;
    obj.USERNAME = data[index].USERNAME;
    obj.BIZREPLY = data[index].BIZREPLY;
    obj.FEEDBACKTIME =data[index].FEEDBACKTIME;
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}    
}

function GetMyDeal(path)
{
var arr = new Array();
try{
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from myorder order by ORDERTIME desc") + ')');
for(var index in data)
{
    var obj=new DealComment();
    obj.DEAL = data[index].DEAL;
    obj.MOBILE = data[index].MOBILE;
    obj.ORDERTIME =  XLY.Convert.LinuxToDateTime(data[index].ORDERTIME);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}    
}

function GetMyCode(path)
{
var arr = new Array();
    try{
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from lottery order by TIME desc") + ')');
for(var index in data)
{
    var obj=new DealComment();
    obj.TITLE = data[index].TITLE;  
    obj.CODE = data[index].CODE;
    obj.TIME =  XLY.Convert.LinuxToDateTime(data[index].TIME);
    obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
    arr.push(obj);
}
return arr;
}
catch(e){
return arr;
}    
}

function CreateNodeWithChild(root,type,text,dbInfo,childType,childText,childDB)
{
    var Node =new TreeNode();
    Node.Type=type;
    Node.Text=text;
    if(dbInfo)
    Node.Items = dbInfo;
    for(var i in childType)
    {
    var childNode =new TreeNode();
    childNode.Type=childType[i];
    childNode.Text =childText[i];
    if(childDB[i])
    childNode.Items = childDB[i];
    Node.TreeNodes.push(childNode);
    }
    root.push(Node);
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0] ;
var path2 = source[1] ;
var path3 = source[2] ;


var childText = new Array(); 
var childType = new Array(); 
var childDB = new Array();

//--------------------------------------------------------------------以下为多节点构造（其他团购，相关搜索，用户信息）
var data = eval('(' + XLY.Sqlite.Find(path1, "select * from deal ") + ')');
for(var index in data)
{
    childText.push(data[index].TITLE);
    childType.push("DealComment");
    childDB.push(GetDealComment(path1,data[index].ID));
}


CreateNodeWithChild(result,"DealList","团购信息",GetDealList(path1),childType,childText,childDB);
data = eval('(' + XLY.Sqlite.Find(path1, "select * from POI ") + ')');
childText.splice(0,childText.length);  
childType.splice(0,childType.length);  
childDB.splice(0,childDB.length);  
for(var index in data)
{
    childText.push(data[index].NAME);
    childType.push("AllComment");
    childDB.push(GetAllComment(path1,data[index].ID));
}
CreateNodeWithChild(result,"AllList","相关搜索",GetAllList(path1),childType,childText,childDB);
childText.splice(0,childText.length);  
childType.splice(0,childType.length);  
childDB.splice(0,childDB.length);  
childText.push("我的订单");
childType.push("MyDeal");
childDB.push(GetMyDeal(path1));
childText.push("我的奖券");
childType.push("MyCode");
childDB.push(GetMyCode(path1));
CreateNodeWithChild(result,"UserInfo","用户信息",GetUserInfo(path2,path3),childType,childText,childDB);

//--------------------------------------------------------------------以下为单节点构造（酒店团购，电影团购，每日推送）
CreateNode("DailyNews","每日推送",GetDailyNews(path1),result);
CreateNode("HotelList","酒店团购",GetHotelList(path1),result);
CreateNode("MovieList","电影团购",GetMovieList(path1),result);

var res = JSON.stringify(result);
res;
