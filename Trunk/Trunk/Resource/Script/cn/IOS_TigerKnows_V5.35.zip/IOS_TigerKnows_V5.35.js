﻿
//descritpion:Test-复杂导航树

/*[config]
<plugin name="老虎地图,2" group="地图公交,5" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\TigerKnows.png" app="com.tigerknows.tigermap" version="5.35" description="老虎地图" data="$data,ComplexTreeDataSource">
<source>
<value>com.tigerknows.tigermap</value>
</source>

<data type="Account">
<item name="昵称" code="Nick" type="string" width="150" format="" ></item>
<item name="ID" code="ID" type="string" width="150" format="" ></item>
<item name="电话" code="Phone" type="string" width="250" format="" ></item>
<item name="所在城市" code="City" type="string" width="170" format="" ></item>
<item name="经度" code="Longitude" type="string" width="200" format="" ></item>
<item name="纬度" code="Latitude" type="string" width="200" format="" ></item>
</data>

<data type="History">
<item name="地点" code="Addr" type="string" width="" format="" ></item>
</data>

<data type="Poi">
<item name="地点" code="Addr" type="string" width="200" ></item>
<item name="经度" code="Longitude" type="string" width="200" ></item>
<item name="纬度" code="Latitude" type="string" width="400" ></item>
</data>

<data  type="Traffic">
<item name="路线" code="Line" type="string" width="400"  ></item>
<item name="类型" code="Type" type="string" width="100" ></item>
<item name="备注" code="Remark" type="string" width="200" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account() {
    this.Nick = "";
    this.ID = "";
    this.Phone = "";
    this.City = ""
    this.Longitude = "";
    this.Latitude = "";
}
function History() {
    this.Addr = "";
}

function Poi() {
    this.Addr = "";
    this.Longitude = "";
    this.Latitude = "";
}

function Traffic() {
    this.Line = "";
    this.Type = "";
    this.Remark = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//获取帐号信息
function getAccount(path) {
    var path = path + "\\tigermapNew.conf";
    var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
    var arr = new Array();
    for (var index in data) {
        var obj = data[index];
        if (obj.nick) {
            arr.push(obj.nick);
        }
        if (obj.userId) {
            arr.push(obj.userId);
        }
        if (obj.phoneNumber) {
            arr.push(obj.phoneNumber);
        }
        if (obj.searchCityName) {
            arr.push(obj.searchCityName);
        }
        if (obj.mapCenterPointLon) {
            arr.push(obj.mapCenterPointLon);
        }
        if (obj.mapCenterPointLat) {
            arr.push(obj.mapCenterPointLat);
        }
    }
    var list = new Account();
    list.Nick = arr[2];
    list.ID = arr[5];
    list.Phone = arr[3];
    list.City = arr[4];
    list.Longitude = arr[1];
    list.Latitude = arr[0];
    return list
}

//获取树信息
function getTreeInfo(tree, poipath, trapath) {
    var hispoiinfo = getPOI(poipath);
    var hispoiTree = new TreeNode();
    hispoiTree.Text = "地点";
    hispoiTree.Type = "Poi";
    hispoiTree.Items = hispoiinfo;

    var histrafficinfo = getTrafficLine(trapath);
    var histrafficTree = new TreeNode();
    histrafficTree.Text = "交通";
    histrafficTree.Type = "Traffic";
    histrafficTree.Items = histrafficinfo;

    hisinfo = getHistory(hispoiinfo, histrafficinfo);
    tree.Items = hisinfo;
    tree.TreeNodes.push(hispoiTree);
    tree.TreeNodes.push(histrafficTree);
}

//获取历史搜索地点信息
function getPOI(path) {
    var data = eval('(' + XLY.File.ReadXML(path) + ')');
    var arr = new Array();
    var info = data.bookmark.poi;
    for (var index in info) {
        if (info[index]['@isDianPing'] == 0) {
            var list = new Poi();
            if (info[index]['@name']) {
                list.Addr = info[index]['@name'];
            }
            if (info[index]['@x']) {
                list.Longitude = info[index]['@x'];
            }
            if (info[index]['@y']) {
                list.Latitude = info[index]['@y'];
            }
            arr.push(list);
        }
    }
    return arr;
}

//获取历史搜索交通信息
function getTrafficLine(path) {
    var data = eval('(' + XLY.File.ReadXML(path) + ')');
    var arr = new Array();
    var info = data.bookmark.traffic;
    log(info.length);
    if(info.length>0){
        for (var index in info) {
            var list = new Traffic();
            switch (info[index]['@busorcar']) {
                case "foot": list.Type = "步行"; break;
                case "car": list.Type = "自驾"; break;
                case "bus": list.Type = "公交"; break;
                case "busline": list.Type = "公交路线"; break;
            }
            if (info[index]['@ex']) {
                list.Line = info[index]['@sn'] + "(" + "经度:" + info[index]['@sx'] + "；纬度:" + info[index]['@sy'] + ")至" + info[index]['@en'] + "(" + "经度:" + info[index]['@ex'] + "；纬度:" + info[index]['@ey'] + ")";
            } else {
                list.Line = info[index]['@linename'];
            }
            if (info[index]['@fs']) {
                list.Remark = info[index]['@fs'];
            }
            arr.push(list);
        }
    }else{
            var list = new Traffic();
            switch (info['@busorcar']) {
                case "foot": list.Type = "步行"; break;
                case "car": list.Type = "自驾"; break;
                case "bus": list.Type = "公交"; break;
                case "busline": list.Type = "公交路线"; break;
            }
            if (info['@ex']) {
                list.Line = info['@sn'] + "(" + "经度:" + info['@sx'] + "；纬度:" + info['@sy'] + ")至" + info['@en'] + "(" + "经度:" + info['@ex'] + "；纬度:" + info['@ey'] + ")";
            } else {
                list.Line = info['@linename'];
            }
            if (info['@fs']) {
                list.Remark = info['@fs'];
            }
            arr.push(list);
    }
    return arr;
}

//合并json对象
function objConcat(a1, a2) {
    var newarr = new Array();
    var p = 0;
    for (var k1 in a1) {
        newarr[k1] = a1[k1];
        p = k1;
    }
    p = parseInt(p) + 1;
    for (var k2 in a2) {
        newarr[p + parseInt(k2)] = a2[k2];
    }
    return newarr;
}

//获取历史搜索记录
function getHistory(poi, traffic) {
    var listp = new Array();
    var listt = new Array();
    for (var i in poi) {
        listp.push(poi[i].Addr);
    }
    for (var j in traffic) {
        listp.push(traffic[j].Line);
    }
    var obj = new Array();
    var arr = new Array();
    obj = objConcat(listp, listt);
    for (var index in obj) {
        var list = new History();
        list.Addr = obj[index];
        arr.push(list);
    }
    return arr;
}

//创建历史浏览和收藏夹树结构
var result = new Array();
var source = $source;
var datapath = source[0] + "\\com.tigerknows.tigermap\\Documents";
//var datapath = "D:\\debug_files\\Documents";
var account = new TreeNode();
account.Text = "登录帐号";
account.Type = "Account";
var accinfo = getAccount(datapath);
account.Items.push(accinfo);

var history = new TreeNode();
history.Text = "历史浏览";
history.Type = "History";
var hispoipath = datapath + "\\recentbrowsepoi.xml";
var histrapath = datapath + "\\recentbrowsetraffic.xml";
getTreeInfo(history, hispoipath, histrapath);

var favorite = new TreeNode();
favorite.Text = "收藏夹";
favorite.Type = "History";
var favpoipath = datapath + "\\poibookmark.xml";
var favtrapath = datapath + "\\trafficbookmark.xml";
getTreeInfo(favorite, favpoipath, favtrapath);

result.push(account);
result.push(history);
result.push(favorite);
var res = JSON.stringify(result);
res;
