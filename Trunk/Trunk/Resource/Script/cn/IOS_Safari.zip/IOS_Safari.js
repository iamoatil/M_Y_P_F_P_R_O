﻿/*[config]
<plugin name="Safari,5" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\safari.png" app="com.apple.Safari" version="8.0" description="提取IOS设备浏览器信息" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.apple.Safari</value>
</source>
<data type="BookMark" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="书签名称" code="BookMark" type="string" width = "200" ></item>
<item name="网址" code="Url" type="string" width="200" ></item>
<item name="最后修改日期" code="Data" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="150" ></item>
</data>
</plugin>
[config]*/

function BookMark(){
    this.BookMark = "";
    this.Url = "";
    this.Data = null;
    this.DataState = "Normal"
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

var result = new Array();
var source = $source;
var searchPath = source[0];
searchPath = searchPath + "\\HomeDomain\\Library\\Safari\\Bookmarks.db";
//var searchPath = "C:\\Users\\Administrator\\Desktop\\Safari\\Bookmarks.db";
var chailb = "chalib\\IOS_Safari\\Bookmarks.db.charactor";
var path = XLY.Sqlite.DataRecovery(searchPath, chailb, "bookmarks");


function ParesCore(){
    var safariNode = new TreeNode();
    safariNode.Text = "Safari"
    var bmNode = new TreeNode();
    bmNode.Text = "书签";
    bmNode.Type = "BookMark";
    bmNode.Items = GetBookMark();
    safariNode.TreeNodes.push(bmNode);
    //var hisNode = new TreeNode();
    //hisNode.Text = "历史浏览";
    //hisNode.Type = "History";
    
    result.push(safariNode);
}

//获取书签
function GetBookMark(){
    var db = eval('(' + XLY.Sqlite.FindByName(path, "bookmarks") + ')');
    var Items = new Array();
    for(var i in db){
        var bm = new BookMark();
        bm.BookMark = db[i].title;
        bm.Url = db[i].url;
        bm.Data = XLY.Convert.LinuxToDateTime(db[i].last_modified);
        bm.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(bm);
    }
    return Items;
}

//获取历史记录

ParesCore()
var res = JSON.stringify(result);
res;
