﻿/*[config]
<plugin name="海豚浏览器,4" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="\icons\DolphinBrowser.png" app="mobi.mgeek.TunnyBrowser" version="7.6" description="海豚浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>data/data/mobi.mgeek.TunnyBrowser/#F</value>
</source>
<data type="Address"  datefilter="Time" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="200" format=""></item>
<item name="URL地址" code="Url" type="URL" width="500" format = ""></item>
<item name="创建时间" code="CreateTime" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问时间" code="Time" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Counts" type="string" width="100" format=""></item>
</data>
<data type="Speeddial" datefilter="Time" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="100" format=""></item>
<item name="URL地址" code="Url" type="URL" width="500" format = ""></item>
<item name="创建时间" code="CreateTime" type="DateTime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
<item name="访问次数" code="Clicks" type="int" width="150" format=""></item>
<item name="访问时间" code="Time" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Bookmark" datefilter="Created" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="100" format=""></item>
<item name="URL地址" code="Url" type="URL" width="500" format=""></item>
<item name="创建时间" code="Created" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="修改时间" code="Modified" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Download" datefilter="Created" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="主题" code="Title" type="string" width="100" format = ""></item>
<item name="名称" code="PckName" type="string" width="100" format = ""></item>
<item name="大小" code="TotalSize" type="string" width="100" format = ""></item>
<item name="已下载大小" code="DownloadSize" type="string" width="100" format = ""></item>
<item name="文件路径" code="Path" type="string" width="150" format = ""></item>
<item name="下载地址" code="Url" type="URL" width="500" format=""></item>
<item name="修改时间" code="Modified" type="DateTime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Address() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Counts = "";
    this.DataState = "Normal";
}

function Speeddial() {
    this.CreateTime = null;
    this.Time = null;
    this.Clicks = 0;
    this.Title = "";
    this.Url = "";
    this.DataState = "Normal";
}

function Bookmark() {
    this.Time = null;
    this.Title = "";
    this.Url = "";
    this.Created = "";
    this.Modified = "";
    this.DataState = "Normal";
}

function Download() {
    this.Title = "";
    this.PckName = "";
    this.TotalSize = "";
    this.DownloadSize = "";
    this.Path = "";
    this.Url = "";
    this.Modified = null;
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//获取历史浏览地址信息
function getAddress(path, sql) {
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
        var arr = new Array();
        for (var index in data) {
            var list = new Address();
            list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
            list.Title = data[index].title;
            list.CreateTime = XLY.Convert.LinuxToDateTime(parseInt(data[index].created));
            list.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].date));
            list.Url = XLY.Convert.UrlDecode(data[index].url);
            list.Counts = data[index].visits;
            arr.push(list);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取快速链接信息
function getSpeeddial(path, sql) {
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
        for (var index in data) {
            var list = new Speeddial();
            list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
            list.Title = data[index].title;
            list.Url = XLY.Convert.UrlDecode(data[index].url);
            list.CreateTime = XLY.Convert.LinuxToDateTime(parseInt(data[index].create_time));
            list.Clicks = data[index].clicks;
            list.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].last_click_time));
            arr.push(list);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//获取书签信息
function getBookmark(path, sql) {
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
        for (var index in data) {
            var list = new Bookmark();
            list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
            list.Title = data[index].title;
            list.Url = XLY.Convert.UrlDecode(data[index].url);
            list.Created = XLY.Convert.LinuxToDateTime(parseInt(data[index].created));
            list.Modified = XLY.Convert.LinuxToDateTime(parseInt(data[index].date));
            arr.push(list);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

// 获取下载列表
function getDownload(path, sql) {
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
        for (var index in data) {
            var list = new Download();
            list.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType);
            list.Title = data[index].title;
            list.PckName = data[index].hint;
            list.TotalSize = data[index].total_bytes.toString().ByteToMb() + "M";
            list.DownloadSize = data[index].current_bytes.toString().ByteToMb() + "M";
            list.Path = data[index]._data;
            list.Url = XLY.Convert.UrlDecode(data[index].uri);
            list.Modified = XLY.Convert.LinuxToDateTime(parseInt(data[index].lastmod));
            arr.push(list);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

String.prototype.KbToMb = function () {
    var result = (this / 1024).toFixed(2);
    return result;
};

String.prototype.ByteToKb = function () {
    var result = (this / 1024).toFixed(2);
    return result;
};

String.prototype.ByteToMb = function () {
    var kb = this / 1024;
    var mb = kb / 1024;
    return mb.toFixed(2);
};

var result = new Array();
//源文件
var source = $source
var datapath = source[0]+"databases\\browser.db";
var speedDbPath = source[0]+"databases\\launcher2.db";
var downloadDbPath = source[0]+"databases\\downloads.db";
//var datapath = "C:\\XLYSFTasks\\未命名-54\\source\\data\\data\\mobi.mgeek.TunnyBrowser\\databases\\browser.db";
//var speedDbPath = "C:\\XLYSFTasks\\未命名-54\\source\\data\\data\\mobi.mgeek.TunnyBrowser\\databases\\launcher2.db";
//var downloadDbPath = "C:\\XLYSFTasks\\未命名-54\\source\\data\\data\\mobi.mgeek.TunnyBrowser\\databases\\downloads.db";

//数据恢复库的生成
var charactor="";
datapath = XLY.Sqlite.DataRecovery(datapath,charactor,"history,bookmarks");
speedDbPath = XLY.Sqlite.DataRecovery(speedDbPath,charactor,"favorites2");
downloadDbPath = XLY.Sqlite.DataRecovery(downloadDbPath,charactor,"downloads");

//节点实例化
var hissql = "select title,url,created,date,visits,XLY_DataType from history";
var history = new TreeNode();
history.Text = "历史搜索";
history.Type = "Address";
var hisinfo = getAddress(datapath, hissql);
history.Items = hisinfo;

var spsql = "select title,url,create_time,clicks,last_click_time,XLY_DataType from favorites2";
var speeddial = new TreeNode();
speeddial.Text = "快速链接";
speeddial.Type = "Speeddial";
var spinfo = getSpeeddial(speedDbPath, spsql);
speeddial.Items = spinfo;

var bksql = "select title,url,date,created,XLY_DataType from bookmarks";
var bookmark = new TreeNode();
bookmark.Text = "书签";
bookmark.Type = "Bookmark";
var bkinfo = getBookmark(datapath, bksql);
bookmark.Items = bkinfo;

var dloadsql = "select uri,hint,_data,lastmod,total_bytes,current_bytes,title,XLY_DataType from downloads";
var download = new TreeNode();
download.Text = "下载记录";
download.Type = "Download";
var dloadInfo = getDownload(downloadDbPath, dloadsql);
download.Items = dloadInfo;

//打印数据
result.push(history);
result.push(speeddial);
result.push(bookmark);
result.push(download);
var res = JSON.stringify(result);
res;
