﻿/*[config]
<plugin name="搜狗地图,4" group="地图公交,7,5" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/SogouMap.png" app="com.sogou.map.android.maps" version="8.2.0" description="搜狗地图" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.sogou.map.android.maps/databases#F</value>
    <value>/data/data/com.sogou.map.android.maps/shared_prefs#F</value>
</source>

<data type="RootNode" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="AppName" type="string" width="120" format=""></item>
    <item name="版本" code="Version" type="string" width="120" format=""></item>
</data>
<data type="List" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账户列表" code="List" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="120" format = ""></item>
    <item name="账户名" code="UserName" type="string" width="120" format=""></item>
    <item name="账户类型" code="UserType" type="string" width="120" format = ""></item>
</data>
<data type="SearchRecord" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="120" format = ""></item>
    <item name="类型" code="SearchType" type="string" width="120" format = ""></item>
    <item name="搜索内容" code="Logicld" type="string" width="120" format = ""></item>
    <item name="搜索时间" code="SearchTime" type="string" width="120" format = ""></item>
</data>
<data type="Collection" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="120" format=""></item>
    <item name="本地id" code="LocalId" type="string" width="120" format = ""></item>
    <item name="账号" code="Account" type="string" width="120" format=""></item>
    <item name="收藏时间" code="CollecTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="同步与否" code="Synced" type="string" width="120" format=""></item>
    <item name="云id" code="CloudId" type="string" width="120" format=""></item>
    <item name="位置详情" code="CloudData" type="string" width="120" format=""></item>
</data>
<data type="MessageRecord" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="消息id" code="Msgid" type="string" width="120" format=""></item>
    <item name="标题" code="Title" type="string" width="120" format=""></item>
    <item name="消息" code="Message" type="string" width="120" format = ""></item>
    <item name="已读标记" code="IsRead" type="string" width="120" format=""></item>
    <item name="删除标记" code="IsDelete" type="string" width="120" format = ""></item>
    <item name="消息时间" code="Msgstamp" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type = "MyFootprints" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="公里数" code="Totaldistance" type="string" width="120" format=""></item>
    <item name="公里-排名" code="Rank" type="string" width="120" format=""></item>
    <item name="城市数" code="CityNum" type="string" width="120" format=""></item>
    <item name="城市-排名" code="CityRank" type="string" width="120" format=""></item>
</data>
<data type = "MySetting" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
    <item name="上班提醒是否开启" code="OnSetOpened" type="string" width="120" format=""></item>
    <item name="下班提醒是否开启" code="OffSetOpened" type="string" width="120" format=""></item>
    <item name="上班闹钟周期" code="OnRemind" type="string" width="120" format=""></item>
    <item name="下班闹钟周期" code="OffRemind" type="string" width="120" format=""></item>
    <item name="上班闹钟时间" code="OnAlarmTime" type="string" width="120" format=""></item>
    <item name="下班闹钟时间" code="OffAlarmTime" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义RootNode数据结构
function RootNode() {
    this.AppName = "";
    this.Version = "";
    this.DataState = "Normal";
}

function List(){
    this.List = "";
    this.DataState = "Normal";
}
//定义UserInfo数据结构
function UserInfo() {
    this.DataState = "Normal";
    this.ID = "";
    this.UserName = "";
    this.UserType = "";
}
//定义SearchRecord数据结构
function SearchRecord(){
    this.DataState = "Normal";
    this.ID = "";
    this.SearchType = "";
    this.Logicld = "";
    this.SearchTime = "";
}
//定义Collection数据结构
function Collection(){
    this.DataState = "Normal";
    this.ID = "";
    this.LocalId = "";
    this.Account = "";
    this.CollecTime = null;
    this.Synced = "";
    this.CloudId = "";
    this.CloudData = "";
}
//定义MessageRecord数据结构
function MessageRecord(){
    this.DataState = "Normal";
    this.Msgid = "";
    this.Title = "";
    this.Message = "";
    this.IsRead = "";
    this.IsDelete = "";
    this.Msgstamp = null;
}
//定义MyFootprints数据结构
function MyFootprints(){
    this.DataState = "Normal";
    this.Totaldistance = "";
    this.Rank = "";
    this.CityNum = "";
    this.CityRank = "";
}
//定义MySetting数据结构
function MySetting(){
    this.DataState = "Normal";
    this.OnSetOpened = "";
    this.OnRemind = "";
    this.OnAlarmTime = "";
    this.OffSetOpened = "";
    this.OffRemind = "";
    this.OffAlarmTime = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var selhispath1 = source[0]+"\\com.sogou.map.mobile.android.history_result.db";
var favpath1 = source[0]+"\\poi_favorite.db";
var linefavpath1 = source[0]+"\\line_favorite.db";
var mespath1 = source[0]+"\\com.sogou.map.mobile.android.message_result.db";
var myfootpath = source[1]+"\\contilogin_pref.xml";
var settingupath = source[1]+"\\setting_pref.xml";
var upath = source[1]+"\\login_pref.xml";

var charactor1 = "\\chalib\\Andorid_SogouMap_V8.2.0\\com.sogou.map.mobile.android.history_result.db.charactor";
var charactor2 = "\\chalib\\Andorid_SogouMap_V8.2.0\\poi_favorite.db.charactor";
var charactor3 = "\\chalib\\Andorid_SogouMap_V8.2.0\\line_favorite.db.charactor";
var charactor4 = "\\chalib\\Andorid_SogouMap_V8.2.0\\com.sogou.map.mobile.android.message_result.db.charactor";

//测试数据
//var selhispath1 = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\databases\\com.sogou.map.mobile.android.history_result.db";
//var favpath1 = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\databases\\poi_favorite.db";
//var linefavpath1 = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\databases\\line_favorite.db";
//var mespath1 = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\databases\\com.sogou.map.mobile.android.message_result.db";
//var myfootpath = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\shared_prefs\\contilogin_pref.xml";
//var settingupath = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\shared_prefs\\setting_pref.xml";
//var upath = "C:\\XLYSFTasks\\任务-2016-12-28-16-27-21  f\\source\\data\\data\\com.sogou.map.android.maps\\shared_prefs\\login_pref.xml";
//
//var charactor1 = "H:\\21-Build冯火军2号-刘涛\\21-Build冯火军2号\\21-Build\\chalib\\Andorid_SogouMap_V8.2.0\\com.sogou.map.mobile.android.history_result.db.charactor";
//var charactor2 = "H:\\21-Build冯火军2号-刘涛\\21-Build冯火军2号\\21-Build\\chalib\\Andorid_SogouMap_V8.2.0\\poi_favorite.db.charactor";
//var charactor3 = "H:\\21-Build冯火军2号-刘涛\\21-Build冯火军2号\\21-Build\\chalib\\Andorid_SogouMap_V8.2.0\\line_favorite.db.charactor";
//var charactor4 = "H:\\21-Build冯火军2号-刘涛\\21-Build冯火军2号\\21-Build\\chalib\\Andorid_SogouMap_V8.2.0\\com.sogou.map.mobile.android.message_result.db.charactor";
//
var selhispath = XLY.Sqlite.DataRecovery(selhispath1,charactor1,"history_result_table");
var favpath = XLY.Sqlite.DataRecovery(favpath1,charactor2,"poi_favorites");
var linefavpath = XLY.Sqlite.DataRecovery(linefavpath1,charactor3,"line_favorites");
var mespath = XLY.Sqlite.DataRecovery(mespath1,charactor4,"message_result_table");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "搜狗地图";
    root.Type = "RootNode";
    root.Items.push(getRoot(root,selhispath,favpath,linefavpath,mespath,myfootpath,settingupath,upath));
    result.push(root);
}
//获取APP信息
function getRoot(root,selhispath,favpath,linefavpath,mespath,myfootpath,settingupath,upath){
    var robj = new RootNode();
    robj.AppName = "搜狗地图";
    robj.Version = "8.2.0";
    
    var usernode = new TreeNode();
    usernode.Text = "账户信息";
    usernode.Type = "UserInfo";
    usernode.Items.push(getUserInfo(upath));
    
    var searnode = new TreeNode();
    searnode.Text = "搜索记录";
    searnode.Type = "SearchRecord";
    searnode.Items = getSearch(selhispath);
    
    var colnode = new TreeNode();
    colnode.Text = "收藏地址";
    colnode.Type = "Collection";
    colnode.Items = getCollection(favpath);
    
    var rnnode = new TreeNode();
    rnnode.Text = "收藏路线";
    rnnode.Type = "Collection";
    rnnode.Items = getLineCollection(linefavpath);
    
    var mesnode = new TreeNode();
    mesnode.Text = "消息记录";
    mesnode.Type = "MessageRecord";
    mesnode.Items = getMessage(mespath);
    
    var mfnode = new TreeNode();
    mfnode.Text = "我的足迹";
    mfnode.Type = "MyFootprints";
    mfnode.Items.push(getMyFootprint(myfootpath));
    
    var msnode = new TreeNode();
    msnode.Text = "我的设置";
    msnode.Type = "MySetting";
    msnode.Items.push(getMySetting(settingupath));
    
    root.TreeNodes.push(usernode);
    root.TreeNodes.push(colnode);
    root.TreeNodes.push(searnode);
    root.TreeNodes.push(mesnode);
    root.TreeNodes.push(mfnode);
    root.TreeNodes.push(msnode);
    root.TreeNodes.push(rnnode);
    return robj;
}

//获取用户信息
function getUserInfo(path){
    if(XLY.File.IsValid(path)){
        var udata = eval('('+ XLY.File.ReadXML(path) +')');
        var data = udata.map.string;
        var userobj = new UserInfo();
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i]["@name"]=="account_display_name"){
                    userobj.UserName = data[i]["#text"];
                }
                if(data[i]["@name"]=="account_uid"){
                    userobj.ID = data[i]["#text"];
                }
                if(data[i]["@name"]=="account_type"){
                    userobj.UserType = data[i]["#text"];
                }   
            }
        }
    }
    return userobj;
}
//获取搜索记录信息
function getSearch(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from history_result_table") +')');
        var arr = new Array();
        if(data!=""&&data!=null){
            for(var i in data){
                var searobj = new SearchRecord();
                searobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                searobj.ID = data[i].id;
                if(data[i].type==7){
                    searobj.SearchType = "身边";
                }
                else if(data[i].type==5){
                    searobj.SearchType = "导航";
                }
                else
                {
                    searobj.SearchType = "路线";
                }
                searobj.Logicld = data[i].logicId;
                searobj.SearchTime = data[i].tm;
                arr.push(searobj);
            }
        }
        return arr;
    }
}
//获取收藏地址信息
function getCollection(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from poi_favorites") +')');
        var arr = new Array();
        if(data!=""&&data!=null){
            for(var i in data){
                var colobj = new Collection();
                colobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                colobj.ID = data[i].xly_id;
                colobj.LocalId = data[i].local_id;
                colobj.Account = data[i].account;
                colobj.CollecTime = XLY.Convert.LinuxToDateTime(data[i].add_favorite_time);
                if(data[i].synced==1){
                    colobj.Synced = "已同步";
                }
                else
                {
                    colobj.Synced = "未同步";
                }
                colobj.CloudId = data[i].cloud_id;
                if(data[i].XLY_DataType==2){
                    var aa = analysisSogouMapFavPOIInfo(data[i].cloud_data,data[i].poi_type);
                    if(aa!=""&&aa!=null){
                        colobj.CloudData = "名称："+aa.name+"\r\n"+"地址："+aa.addr+"\r\n";
                    }
                    else
                    {
                        colobj.CloudData = "";
                    }
                }
                else
                {
                    colobj.CloudData = "";
                }
                
                arr.push(colobj);
            }
        }
        return arr;
    }
}
//获取收藏路线信息
function getLineCollection(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from line_favorites") +')');
        var arr = new Array();
        if(data!=""&&data!=null){
            for(var i in data){
                var colobj = new Collection();
                colobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                colobj.ID = data[i].xly_id;
                colobj.LocalId = data[i].local_id;
                colobj.Account = data[i].account;
                colobj.CollecTime = XLY.Convert.LinuxToDateTime(data[i].add_favorite_time);
                if(data[i].synced==1){
                    colobj.Synced = "已同步";
                }
                else
                {
                    colobj.Synced = "未同步";
                }
                colobj.CloudId = data[i].cloud_id;
                colobj.CloudData = data[i].cloud_data;
                var syncinfo = XLY.Blob.ToBytes(data[i].cloud_data,"base64");
                colobj.CloudData = analysisSogouMapLineInfo(syncinfo);
                arr.push(colobj);
            }
        }
        return arr;
    }
}
//获取消息记录
function getMessage(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from message_result_table") +')');
        var arr = new Array();
        if(data!=""&&data!=null){
            for(var i in data){
                var mesobj = new MessageRecord();
                mesobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataState);
                mesobj.Msgid = data[i].msgid;
                mesobj.Title = data[i].title;
                mesobj.Message = data[i].message;
                if(data[i].read==1){
                    mesobj.IsRead = "已读";
                }
                else
                {
                    mesobj.IsRead = "未读";
                }
                if(data[i].removed==1){
                    mesobj.IsDelete = "已删除";
                }
                else
                {
                    mesobj.IsDelete = "未删除";
                }
                mesobj.Msgstamp = XLY.Convert.LinuxToDateTime(data[i].msgstamp);
                arr.push(mesobj);
            }
        }
        return arr;
    }
}
//获取我的足迹信息
function getMyFootprint(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.File.ReadXML(path) +')');
        var ldata = data.map.long;
        var idata = data.map.int;
        var mfobj = new MyFootprints();
        if(ldata!=""&&ldata!=null){
            for(var i in ldata){
                if(ldata[i]["@name"]=="contilogin_totaldistance"){
                    mfobj.Totaldistance = ldata[i]["@value"];
                }
            }
        }
        if(idata!=""&&idata!=null){
            for(var i in idata){
                if(idata[i]["@name"]=="contilogin_rank"){
                    mfobj.Rank = idata[i]["@value"];
                }
                if(idata[i]["@name"]=="contilogin_citynum"){
                    mfobj.CityNum = idata[i]["@value"];
                }
                if(idata[i]["@name"]=="contilogin_cityrank"){
                    mfobj.CityRank = idata[i]["@value"];
                }
            }
        }
        return mfobj;
    }
}
//获取我的设置信息
function getMySetting(path){
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.File.ReadXML(path) +')');
        var sdata = data.map.string;
        var msobj = new MySetting();
        if(sdata!=""&&sdata!=null){
            for(var i in sdata){
                if(sdata[i]["@name"]=="store.key.road.remind.go.home.set.opened"){
                    if(sdata[i]["#text"]==1){
                        msobj.OffSetOpened = "是";
                    }
                    else
                    {
                        msobj.OffSetOpened = "否";
                    }
                }
                if(sdata[i]["@name"]=="store.key.road.remind.go.home.remind.way"){
                    msobj.OffRemind = sdata[i]["#text"];
                }
                if(sdata[i]["@name"]=="store.key.road.remind.on.duty.time"){
                    msobj.OffAlarmTime = sdata[i]["#text"];
                }
                if(sdata[i]["@name"]=="store.key.road.remind.off.duty.time"){
                    msobj.OnAlarmTime = sdata[i]["#text"];
                }
                if(sdata[i]["@name"]=="store.key.road.remind.to.company.set.opened"){
                    if(sdata[i]["#text"]==1){
                        msobj.OnSetOpened = "是";
                    }
                    else
                    {
                        msobj.OnSetOpened = "否";
                    }
                }
                if(sdata[i]["@name"]=="store.key.road.remind.to.company.remind.way"){
                    msobj.OnRemind = sdata[i]["#text"];
                }
            }
        }
        return msobj;
    }
}
function analysisSogouMapLineInfo(data){
    var dsize = data.length;
    var magic = [08,01,18];
    var pos = XLY.Blob.FindBytes(data,0,magic);
    var buff = "";
    if(-1!= pos){
        if(10==data[pos+3]){
            pos += 3;
            pos = XLY.Blob.FindBytes(data,pos,magic);
        }
        while(pos<dsize){
            magic[1] += 1;
            var offset = XLY.Blob.FindBytes(data,pos,magic);
            if(offset==-1) break;
            var dlen = offset -pos;
            var pbuf = XLY.Blob.GetBytes(data,pos,dlen);
            var info = getVariableIntLength(pbuf,3);
            var data1 = XLY.Blob.GetBytes(pbuf,3+info.count,info.size);
            buff+= XLY.Blob.ToString(data1)+"\r\n";
            pos = offset;
        }
    }
    return buff;
}  
// return
var res = JSON.stringify(result);
res;

function analysisSogouMapFavPOIInfo(data,type){
    var pbuf = XLY.Blob.ToBytes(data,"base64");
    //log(data);
    var psize = pbuf.length;
    var pos = 0;
    var tmp;
    while(pos<psize){
        if((10==pbuf[pos])||(66==pbuf[pos])){
            pos += 1;
            
            tmp = getVariableIntLength(pbuf,pos);
            pos += tmp.count;
            pos += tmp.size;
            continue;
            
        }
        else if(58==pbuf[pos]){
            pos += 1;
            tmp = getVariableIntLength(pbuf,pos);
            pos += tmp.count;
            var flag3Adata = XLY.Blob.GetBytes(pbuf,pos,tmp.size);
            var info = getContentInfo(flag3Adata,type);
            return info;

        }
        else if(16==pbuf[pos]){
            pos += 15;
            if(58==pbuf[pos]){
                continue;
            }
            else
            {
                pos += 10;
                continue;
            }
        }

    }
}


function getContentInfo(data,type){
    var info = {};
    if(type==0){
        var flag12info = getSubFlagInfo(data,[0x12]);
        info.name = XLY.Blob.ToString(flag12info.data);
        
        
    }
    if(type==1||type==2){
        var flag0Ainfo = getSubFlagInfo(data,[0x0A]);
        info.name = XLY.Blob.ToString(flag0Ainfo.data);
    }
    var flag32info = getSubFlagInfo(data,[0x32]);
    if(flag32info==-1){
        flag32info = getSubFlagInfo(data,[0x2A]);
    }
    if(flag32info!=-1){
        info.addr = XLY.Blob.ToString(flag32info.data);
    }
    return info;
}


//读取byte数据中包含的所有的标记+长度+内容的存储方式的结构，并获取其偏移位置(offset)、标记值(flag)、记录长度信息使用的字节数(countByte)、长度真实值(len)、数据内容(data)
function getSubFlagInfo(data,flag){
    var pos = 0;
    var flaginfo = {};
    var dsize = data.length;
    while(pos<dsize){
        flaginfo.offset = pos;
        flaginfo.flag = XLY.Blob.GetBytes(data,pos,1);
        if(XLY.Blob.ToString([0x11])==XLY.Blob.ToString(flaginfo.flag)||XLY.Blob.ToString([0x19])==XLY.Blob.ToString(flaginfo.flag)){
            pos += 18;
            continue;
        }
        pos += 1;
        var flagleninfo = getVariableIntLength(data,pos);
        flaginfo.countByte = flagleninfo.count;
        pos += flagleninfo.count;
        flaginfo.len = flagleninfo.size;
        flaginfo.data = XLY.Blob.GetBytes(data,pos,flaginfo.len);
        if(XLY.Blob.ToString(flag)==XLY.Blob.ToString(flaginfo.flag)){
            return flaginfo;
        }

        pos += flagleninfo.size;
    }
    return -1;
}


//获取可变长整数的位数(count)和转换后的值(size)
function getVariableIntLength(data,pos){
    var info = {};
    var subdata = XLY.Blob.GetBytes(data,pos,data.length-pos);
    var count = 0;

    for(var i = 0; i<4 ;i++){
        if(128==(subdata[i]&128)){
            count++;
            continue;
        }
        count++;
        break;
    }
    info.count = count;
    info.size = XLY.Bit.ToVariableInt(subdata,false);
    return info;
}