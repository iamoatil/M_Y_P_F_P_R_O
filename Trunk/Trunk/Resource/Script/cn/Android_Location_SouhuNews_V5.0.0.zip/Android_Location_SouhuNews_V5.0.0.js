﻿
/*[config]
<plugin name="地理位置,10" group="地图公交,5" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid"  icon="\icons\map.png" app="com.sohu.newsclient" description="搜狐新闻" data="$data,LocationInfoDataSource" version="5.0.0" >
<source>
    <value>data/data/com.sohu.newsclient/shared_prefs/META.xml</value>
</source>
<data type="Position" contract = "Map" >
    <item name="描述" code="Remark" type="string" width="200" format=""></item>
    <item name="经度" code="Longitude" type="double" width="" format="F6"></item>
    <item name="纬度" code="Latitude" type="double" width="" format="F6"></item>
    <item name="日期" code="StartDate" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="来源" code="Source" type="string" width="" format = ""></item>
</data>
</plugin>
[config]*/

// js content
//定义数据结构，必须与上面的配置项一致
function Position() {
    this.Longitude = 0; 
    this.Latitude = 0;
    this.Remark = "位置信息";
    this.Source = "搜狐新闻";
    this.StartDate = null;
}

function getInfo(){
    var arr=new Array();
    var data = eval('(' + XLY.File.ReadXML(path) + ')');
    var info = data.map.string
    var Items = new Array();
    var pos = new Position();
    //查询XML中的用户信息
    for (var index in info) {
        if (info[index]['@name'] == "LongitudeAndLatitude") {
            var loc = info[index]['#text'] ;
            arr = loc.split("_")
        }
    } 
    pos.Latitude = arr[0];
    pos.Longitude = arr[1];
    pos.StartDate = XLY.Convert.LinuxToDateTime(arr[3]);
    Items.push(pos);
    return Items ;
}

var result = new Array();
//源文件
var source = $source;
var path = source[0];
//var path = "C:\\Users\\Administrator\\Desktop\\com.sohu.newsclient\\shared_prefs\\META.xml";
result = getInfo();
// return
var res = JSON.stringify(result);
res;
