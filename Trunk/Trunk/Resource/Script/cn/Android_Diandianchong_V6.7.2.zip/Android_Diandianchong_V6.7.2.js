﻿/*[config]
<plugin name="点点虫,6" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\laiwang.png" app="com.alibaba.android.babylon" version="6.7.2" description="点点虫" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.alibaba.android.babylon/shared_prefs/com.alibaba.android.babylon_preferences.xml</value>
    <value>/data/data/com.alibaba.android.babylon/shared_prefs/last_know_location.xml</value>
</source>
<data type = "Account" contract = "DataState" >
    <item name="帐号" code="Acc" type="string" width = "" ></item>
    <item name="昵称" code="Name" type="string" width="100" alignment = "center" order = "desc"></item> 
    <item name="性别" code="Gender" type="string" width="150" ></item>
    <item name="手机" code="Mobile" type="string" width="200" format = ""></item>
    <item name="国家区号" code="Code" type="string" width="200" format = ""></item>
    <item name="头像" code="Avatar" type="url" width="150" ></item>
    <item name="ID" code="ID" type="string" width="200" format = ""></item>
</data> 
<data type = "Address" contract = "DataState" >
    <item name="位置" code="Location" type="string" width="100" alignment = "center" order = "desc"></item> 
    <item name="经度" code="Lng" type="string" width="150" ></item>
    <item name="维度" code="Lat" type="string" width="200" format = ""></item>
    <item name="区号" code="Code" type="string" width="200" format = ""></item>
</data> 
</plugin>
[config]*/
function Account() {
    this.Acc = "";
    this.Name = "";
    this.Gender = "";
    this.Mobile = "";
    this.Code = "";
    this.ID = "";
}
function Address() {
    this.Location = "";
    this.Lng = "";
    this.Lat = "";
    this.Code = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "点点虫";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account";
        account.Items = accountinfo; 
        news.TreeNodes.push(account)

        var address = new TreeNode() ;
        address.Text = "位置信息";
        address.Type = "Address"; 
        address.Items = getAddress(db1);
        account.TreeNodes.push(address)

    }
  result.push(news);
}       
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var obj = new Account();
    var info = data.map.string;
    for(var i in info){
        
         if(info[i]["@name"] == "userAvatar"){
             obj.Avatar = info[i]["#text"];           
         }
        if(info[i]["@name"] == "mobile"){
            obj.Mobile = info[i]["#text"];         
        }
        if(info[i]["@name"] == "moblieCode"){
            obj.Code = info[i]["#text"];          
        }
        if(info[i]["@name"] == "name"){
            obj.Name = info[i]["#text"];           
        }
        if(info[i]["@name"] == "gender"){
            var a = info[i]["#text"];
            switch(a){
                case "female": 
                obj.Gender = "女";
                case "male":
                break; 
                obj.Gender = "男";
                break;
                default:
                obj.Gender = "其他";
                break;
            }            
        }
        if(info[i]["@name"] == "loginId"){
            obj.Acc = info[i]["#text"];           
        }
        if(info[i]["@name"] == "uid"){
           obj.ID = info[i]["#text"]; 
        }          
    }
    list.push(obj);
    return list;
}
function getAddress(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var obj = new Address();
    var info = data.map.string;
    for(var i in info){
        
         if(info[i]["@name"] == "province"){
             var a = info[i]["#text"];           
         }
        if(info[i]["@name"] == "city"){
            var b = info[i]["#text"];         
        }
        if(info[i]["@name"] == "district"){
            var c = info[i]["#text"];          
        }
        obj.Location = a+b+c;
        if(info[i]["@name"] == "last_know_lng"){
            obj.Lng = info[i]["#text"];           
        }        
        if(info[i]["@name"] == "last_know_lat"){
            obj.Lat = info[i]["#text"];           
        }
        if(info[i]["@name"] == "cityCode"){
            obj.Code = info[i]["#text"]; 
        }          
    }
    list.push(obj);
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];

//var db = "D:\\temp\\data\\data\\com.alibaba.android.babylon\\shared_prefs\\com.alibaba.android.babylon_preferences.xml";
//var db1 = "D:\\temp\\data\\data\\com.alibaba.android.babylon\\shared_prefs\\last_know_location.xml";

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;


