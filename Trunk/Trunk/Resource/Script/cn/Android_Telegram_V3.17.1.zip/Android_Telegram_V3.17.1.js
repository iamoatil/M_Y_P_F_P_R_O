﻿/*[config]
<plugin name="Telegram,3" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/telegram.png" app="org.telegram.messenger" version="3.17.1" description="Telegram" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/org.telegram.messenger/files#F</value>
    <value>/data/data/org.telegram.messenger/shared_prefs#F</value>
</source>
<data type="List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="Listed" type="string" width="120" format=""></item>
</data>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="软件名称" code="AppName" type="string" width="120" format=""></item>
    <item name="版本" code="Version" type="string" width="120" format=""></item>
</data>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="120" format=""></item>
    <item name="账号" code="Account" type="string" width="120" format=""></item>
    <item name="昵称" code="NickName" type="string" width="120" format=""></item>
    <item name="姓名" code="UserName" type="string" width="120" format = ""></item>
    <item name="是否相互添加" code="IsMutual" type="string" width="120" format = ""></item>
    <item name="头像存放链接" code="HeadUrl" type="string" width="120" format = ""></item>
    <item name="大头像存放链接" code="BigHeadUrl" type="string" width="120" format = ""></item>
    <item name="最后在线时间" code="LastTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Contact" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="Id" type="string" width="120" format=""></item>
    <item name="手机号" code="Phone" type="string" width="120" format=""></item>
    <item name="姓名" code="UserName" type="string" width="120" format=""></item>
</data>
<data type="Message" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发送者账号" code="SenderID" type="string" width="120" format=""></item>
    <item name="昵称" code="SenderName" type="string" width="120" format=""></item>
    <item name="接收者账号" code="ReceiverID" type="string" width="120" format=""></item>
    <item name="接收者昵称" code="ReceiverName" type="string" width="120" format=""></item>
    <item name="内容" code="Body" type="string" width="120" format=""></item>
    <item name="消息类型" code="MessageType" type="string" width="120" format=""></item>
    <item name="时间" code="MessageTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="附件路径" code="AddPath" type="string" width="120" format=""></item>
</data>
<data type="GroupMember" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号" code="Id" type="string" width="120" format=""></item>
    <item name="昵称" code="NickName" type="string" width="120" format=""></item>
    <item name="姓名" code="UserName" type="string" width="120" format=""></item>
    <item name="手机号码" code="Phone" type="string" width="120" format=""></item>
</data>
<data type="GroupInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="类型" code="GroupType" type="string" width="120" format=""></item>
    <item name="ID" code="GroupId" type="string" width="120" format=""></item>
    <item name="名称" code="GroupName" type="string" width="120" format=""></item>
    <item name="创建者ID" code="CreaterID" type="string" width="120" format=""></item>
    <item name="创建者姓名" code="CreaterName" type="string" width="120" format=""></item>
    <item name="创建时间" code="CreateTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="群头像链接" code="GroupHeadUrl" type="string" width="120" format = ""></item>
    <item name="群大头像链接" code="GroupBigHeadUrl" type="string" width="120" format=""></item>
    <item name="群成员个数" code="GroupMemberCount" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.AppName = "";
    this.Version = "";
}
//定义List数据结构
function List(){
    this.DataState = "Normal";
    this.Listed = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.Id = "";
    this.Account = "";
    this.NickName = "";
    this.UserName = "";
    this.HeadUrl = "";
    this.BigHeadUrl = "";
    this.LastTime = null;
    this.IsMutual = "";
}

//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.Id = "";
    this.Phone = "";
    this.UserName = "";
}

//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.SenderName = "";
    this.ReceiverID = "";
    this.ReceiverName = "";
    this.Body = "";
    this.MessageType = "";
    this.MessageTime = null;
    this.AddPath = "";
}

//定义GroupMember数据结构
function GroupMember(){
    this.DataState = "Normal";
    this.Id = "";
    this.NickName = "";
    this.UserName = "";
    this.Phone = "";
}
//定义GroupInfo数据结构
function GroupInfo(){
    this.DataState = "Normal";
    this.GroupType = "";
    this.GroupId = "";
    this.GroupName = "";
    this.CreaterID = "";
    this.CreaterName = "";
    this.CreateTime = null;
    this.GroupHeadUrl = "";
    this.GroupBigHeadUrl = "";
    this.GroupMemberCount = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dpath = source[0]+"\\cache4.db";
var xpath = source[1]+"\\userconfing.xml";
var charactr = "\\chalib\\Android_Telegram_V3.16.1"
//测试数据
//var dpath = "C:\\XLYSFTasks\\任务-2017-02-28-14-30-41\\source\\data\\data\\org.telegram.messenger\\files\\cache4.db";
//var xpath = "C:\\XLYSFTasks\\任务-2017-02-28-14-30-41\\source\\data\\data\\org.telegram.messenger\\shared_prefs\\userconfing.xml";
//var charactr = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Telegram_V3.16.1";
var recdb = XLY.Sqlite.DataRecovery(dpath,charactr,"users,contacts,messages,chats,user_contacts_v6,user_phones_v6,media_v2,chat_settings_v2");
//定义特征库文件
//var charactor = "chalib\\Android_Chelaile_V3.24.2\\com.ygkj.chelaile.db.charactor";

//恢复数据库中删除的数据
//var dpath = XLY.Sqlite.DataRecovery(dpath1, charactor,"cll_query_history,cll_transit_query_history,cll_transit_scheme_history,cll_transit_scheme_detail_history");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "Telegram";
    root.Type = "News";
    root.Items.push(getNews(root));
    result.push(root);
}
//获取软件信息
function getNews(root){
    var obj = new News();
    obj.AppName = "Telegram";
    obj.Version = "3.16.1";
    CreateUserTree(root);
    return obj;
}
//创建当前用户信息树
function CreateUserTree(root){
    if(XLY.File.IsValid(xpath)){
        var data = eval('('+ XLY.File.ReadXML(xpath) +')');
        if(data!=""&&data!=null){
            var info = data.map.string;
            if(info!=""&&info!=null){
                for(var i in info){
                    if(info[i]["@name"]=="user"){
                        var user = info[i]["#text"];
                        var a = new Base64();
                        var info1 = utf16to8(a.decode(user)).toString();
                        
                        if(XLY.File.IsValid(recdb)){
                            var bb = eval('('+ XLY.Sqlite.Find(recdb,"select * from users") +')');
                            if(bb!=""&&bb!= null){
                                for(var b in bb){
                                    var node = new TreeNode();
                                    if(bb[b].XLY_DtaType==2){
                                        var cc = bb[b].name.split(";")[0].split(" ");
                                        var reg = new RegExp(""+cc[0]+"","i");
                                        if(reg.test(info1)){
                                            var reg1 = new RegExp(""+cc[1]+"","i");
                                            if(reg1.test(info1)){
                                                node.text = bb[b].uid+"_"+bb[b].name.split(";")[0];
                                                node.type = "UserInfo";
                                                var cc = XLY.Blob.ToBytes(bb[b].data,"base64");
                                                AnalysisUserData(node,bb[b].data,bb[b]);
                                                CreateUserChildTree(node,node.text);
                                                root.TreeNodes.push(node);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        var cc = bb[b].name.split(";")[0].split(" ");
                                        var reg = new RegExp(""+cc[0]+"","i");
                                        if(reg.test(info1)){
                                            var reg1 = new RegExp(""+cc[1]+"","i");
                                            if(reg1.test(info1)){
                                                node.text = bb[b].uid+"_"+bb[b].name.split(";")[0];
                                                node.type = "UserInfo";
                                                var cc = XLY.Blob.ToBytes(bb[b].data,"base64");
                                                AnalysisUserData(node,bb[b].data,bb[b]);
                                                CreateUserChildTree(node,node.text);
                                                root.TreeNodes.push(node);
                                            }
                                        }
                                    }
                                    if(node==""||node==null){
                                        node.Text = "";
                                        node.type = "UserInfo";
                                        CreateUserChildTree(node,node.text);
                                        root.TreeNodes.push(node);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return;
    }
}
function Base64() {
 
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
 
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }
 
    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }
 
    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
 
        }
        return utftext;
    }
 
    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}

function utf16to8(str) {
    var out, i, len, c;

    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
    c = str.charCodeAt(i);
    if ((c >= 0x0001) && (c <= 0x007F)) {
        out += str.charAt(i);
    } else if (c > 0x07FF) {
        out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
        out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    } else {
        out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
        out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
    }
    }
    return out;
}

function AnalysisUserData(node,info,temp){
    if(info!=""&&info!=null){
        var a = new Base64();
        var info1 = utf16to8(a.decode(info)).toString();
        var reg = new RegExp(""+86+"","i");
        var b = temp.name.toString().split(" ")[0];
        var reg1 = new RegExp(""+b+"","i");
        var obj = new UserInfo();
        if(info1.search(reg1)>0&&info1.search(reg1)<info1.length){
            info1 = info1.substr(info1.search(reg1),info1.length-info1.search(reg1));
            if(info1.search(reg)>0&&info1.search(reg)<info1.length){
                obj.Account = info1.substr(info1.search(reg),13);
            }
        }
        node.Items.push(obj);
    }
}
//创建用户树子节点
function CreateUserChildTree(root,temp){
    if(XLY.File.IsValid(recdb)){
        var fdata = eval('('+ XLY.Sqlite.Find(recdb,"select * from users") +')');
        if(fdata!=""&&fdata!=null){
            var node = new TreeNode();
            node.text = "好友";
            node.type = "UserInfo";
            getFriendMsg(node,fdata,temp);
            root.TreeNodes.push(node);
        }
        var cdata = eval('('+ XLY.Sqlite.Find(recdb,"select * from user_phones_v6") +')');
        if(cdata!=""&&cdata!=null){
            var node = new TreeNode();
            node.text = "手机联系人";
            node.type = "Contact";
            getContactMsg(node,cdata);
            root.TreeNodes.push(node);
        }
        var gidata = eval('('+ XLY.Sqlite.Find(recdb,"select * from chats") +')');
        if(gidata!=""&&gidata!= null){
            var node = new TreeNode();
            node.text = "讨论组";
            node.type = "GroupInfo";
            getGroupInfoMsg(node,gidata,temp);
            root.TreeNodes.push(node);
        }
        var gmdata = eval('('+ XLY.Sqlite.Find(recdb,"select * from chat_settings_v2 where uid>100000000 and uid<999999999") +')');
        if(gmdata!=""&&gmdata!=null){
            var node = new TreeNode();
            node.text = "群成员";
            node.type = "GroupMember";
            getGroupMemberMsg(node,gmdata);
            root.TreeNodes.push(node);
        }
        var chatdata = eval('('+ XLY.Sqlite.Find(recdb,"select distinct(uid) from messages") +')');
        if(chatdata!=""&&chatdata!= null){
            var node = new TreeNode();
            node.text = "聊天记录";
            node.type = "List";
            getGNodeMsg(node,chatdata,temp);
            root.TreeNodes.push(node);
        }
    }
}
//获取好友信息
function getFriendMsg(root,info,temp){
    for(var i in info){
        if(info[i].uid!=temp.split("_")[0]){
            var obj = new UserInfo();
            var a = new Base64();
            var info1 = utf16to8(a.decode(info[i].data)).toString();
            var reg = new RegExp(""+86+"","i");
            var b = info[i].name.toString().split(" ")[0];
            var reg1 = new RegExp(""+b+"","i");
            var obj = new UserInfo();
            if(info1.search(reg1)>0&&info1.search(reg1)<info1.length){
                info1 = info1.substr(info1.search(reg1),info1.length-info1.search(reg1));
                if(info1.search(reg)>0&&info1.search(reg)<info1.length){
                    obj.Account = info1.substr(info1.search(reg),13);
                }
            }
            obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
            obj.Id = info[i].uid;
            obj.NickName = info[i].name.split(";")[0];
            obj.UserName = info[i].name.split(";")[3];
            var info2 = eval('('+ XLY.Sqlite.Find(recdb,"select * from contacts") +')');
            if(info2!=""&&info2!=null){
                if(info2[0].mutual==1){
                    obj.IsMutual = "是";
                }
                else
                {
                    obj.IsMutual = "否";
                }
            }
            obj.HeadUrl = "";
            obj.BigHeadUrl = "";
            obj.LastTime = XLY.Convert.LinuxToDateTime(info[i].status);
            root.Items.push(obj);
        }
    }
    return;
}
//获取手机联系人信息
function getContactMsg(root,info){
    for(var i in info){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select * from user_contacts_v6 where uid = '"+info[i].uid+"'") +')');
        if(data!=""&&data!=null){
            var obj = new UserInfo();
            obj.DataState = XLY.Convert.ToDataState(data[0].XLY_DataType);
            obj.Id = data[0].uid;
            obj.Phone = info[i].phone;
            obj.UserName = data[0].fname;
            root.Items.push(obj);
        }
    }
    return;
}
//获取群信息
function getGroupInfoMsg(root,info,temp){
    for(var i in info){
        if(info[i].XLY_DataType==2){
            var data = eval('('+ XLY.Sqlite.Find(recdb,"select info from chat_settings_v2 where uid = '"+info[i].uid+"'") +')');
            if(data!=""&&data!=null){
                var firstCharactor = XLY.Blob.ToBytes(data[0].info,"base64");
                var cfirstCharactor = XLY.Blob.ToBytes(info[i].data,"base64");
                var msize =  XLY.Bit.ToInt(XLY.Blob.GetBytes(firstCharactor,0x14,0x04),"FALSE");
                
                var obj = new UserInfo();
                obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                if(info[i].uid.toString().length==9){
                    obj.GroupType = "群组";
                    if(XLY.Blob.FindBytes(cfirstCharactor,0,[0x1C,0x01,0xC1,0x37])!=-1){
                        var mtime = XLY.Bit.ToInt(XLY.Blob.GetBytes(cfirstCharactor,XLY.Blob.FindBytes(cfirstCharactor,0,[0x1C,0x01,0xC1,0x37])+0x08,0x04),"FALSE");
                    }
                    var mcreater =  XLY.Bit.ToInt(XLY.Blob.GetBytes(firstCharactor,0x20,0x04),"FALSE");
                    var mcreatername = eval('('+ XLY.Sqlite.Find(recdb,"select name from users where uid = '"+mcreater+"'") +')');
                    obj.CreaterID = mcreater;
                    obj.CreaterName = mcreatername[0].name.toString().split(";")[0];
                    obj.GroupMemberCount = msize;
                }
                if(info[i].uid.toString().length==10){
                    obj.GroupType = "广播";
                    if(XLY.Blob.FindBytes(cfirstCharactor,0,[0x1C,0x01,0xC1,0x37])!=-1){
                        var mtime = XLY.Bit.ToInt(XLY.Blob.GetBytes(cfirstCharactor,XLY.Blob.FindBytes(cfirstCharactor,0,[0x1C,0x01,0xC1,0x37])+0x04,0x04),"FALSE");
                    }
                    if(XLY.Blob.GetBytes(firstCharactor,0x04,0x01).toString()==[0x4F].toString()){
                        obj.CreaterID = temp.toString().split("_")[0];
                        obj.CreaterName = temp.toString().split("_")[1];
                        obj.GroupMemberCount = 2;//bug
                    }
                }
                obj.GroupId = info[i].uid;
                obj.GroupName = info[i].name;
                obj.CreateTime = XLY.Convert.LinuxToDateTime(mtime);
                obj.GroupHeadUrl = "";
                obj.GroupBigHeadUrl = "";
                root.Items.push(obj);
            }
        }
    }
    return;
}
//获取聊天记录节点信息
function getGNodeMsg(root,info,temp){
    var a = 0;      //非好友uid个数
    var b = 0;      //好友uid个数
    var c = new Array();        //广播id集合
    var d = new Array();        //群id集合
    var e = new Array();        //好友id集合
    for(var i in info){
        if(info[i].uid.toString()[0]=="-"){
            a+= 1;
            if(info[i].uid.toString().substr(1,info[i].uid.toString().length).length==9){
                c.push(info[i].uid.toString().substr(1,info[i].uid.toString().length));
            }
            if(info[i].uid.toString().substr(1,info[i].uid.toString().length).length==10)
            {
                d.push(info[i].uid.toString().substr(1,info[i].uid.toString().length));
            }
        }
        else
        {
            b+= 1;
            e.push(info[i].uid.toString());
        }
    }
    if(c!=""&&c!=null){
        var node = new TreeNode();
        node.Text = "群聊天记录";
        node.Type = "List";
        GroupChatLogNode(node,c);
        var obj = new List();
        obj.Listed = node.Text;
        root.Items.push(obj);
        root.TreeNodes.push(node);
    }
    if(d!=""&&d!=null){
        var node = new TreeNode();
        node.Text = "广播记录";
        node.Type = "List";
        BroadCastChatLogNode(node,d);
        var obj = new List();
        obj.Listed = node.Text;
        root.Items.push(obj);
        root.TreeNodes.push(node);
    }
    if(b){
        var node = new TreeNode();
        node.Text = "好友聊天记录";
        node.Type = "List";
        FriendChatLogNode(node,e,temp);
        var obj = new List();
        obj.Listed = node.Text;
        root.Items.push(obj);
        root.TreeNodes.push(node);
    }
}
//获取群成员信息
function getGroupMemberMsg(root,info){
    for(var i in info){
        var cdata = eval('('+ XLY.Sqlite.Find(recdb,"select name from chats where uid = '"+info[i].uid+"'") +')');
        if(cdata!=""&&cdata!=null){
            var node = new TreeNode();
            node.Text = info[i].uid+"_"+cdata[0].name;
            node.Type = "GroupMember";
            node.Items = getGroupMem(info[i].info);
            
            root.TreeNodes.push(node);
        }
    }
}
//获取群成员
function getGroupMem(info){
    var arr = new Array();
    var firstCharactor = XLY.Blob.ToBytes(info,"base64");
    var msize =  XLY.Bit.ToInt(XLY.Blob.GetBytes(firstCharactor,0x14,0x04),"FALSE");
    for(var j = 0;j<msize;j++){
        var aa = XLY.Bit.ToInt(XLY.Blob.GetBytes(firstCharactor,0x1C+j*16,0x04),"FALSE");
        var minfo = eval('('+ XLY.Sqlite.Find(recdb,"select * from users where uid = '"+aa+"'") +')');
        if(minfo!=""&&minfo!= null){
            var mfirstCharactor = XLY.Blob.ToBytes(minfo[0].data,"base64");
            var a = new Base64();
            var info1 = utf16to8(a.decode(minfo[0].data)).toString();
            var reg = new RegExp(""+86+"","i");
            var b = minfo[0].name.toString().split(";")[0].split(" ")[0];
            var reg1 = new RegExp(""+b+"","i");
            var obj = new GroupMember();
            if(info1.search(reg1)>0&&info1.search(reg1)<info1.length){
                info1 = info1.substr(info1.search(reg1),info1.length-info1.search(reg1));
                if(info1.search(reg)>0&&info1.search(reg)<info1.length){
                    obj.Phone = info1.substr(info1.search(reg),13);
                }
            }
            obj.DataState = XLY.Convert.ToDataState(minfo[0].XLY_DataType);
            obj.Id = aa;
            obj.NickName = minfo[0].name.toString().split(";")[3];
            obj.UserName = minfo[0].name.toString().split(";")[0];
            arr.push(obj);
        }
    }
    return arr;
}
//获取所有群
function GroupChatLogNode(root,info){
    for(var i in info){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select uid,name from chats where uid = '"+info[i]+"'") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = data[0].uid+"_"+data[0].name;
            node.Type = "Message";
            var obj = new List();
            obj.Listed = node.Text;
            root.Items.push(obj);
            root.TreeNodes.push(node);
            GetGroupChatLog(node,"-"+data[0].uid,node.Text);
        }
    }
}
//获取所有广播
function BroadCastChatLogNode(root,info){
    for(var i in info){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select uid,name from chats where uid = '"+info[i]+"'") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = data[0].uid+"_"+data[0].name;
            node.Type = "Message";
            
            var obj = new List();
            obj.Listed = node.Text;
            root.Items.push(obj);
            root.TreeNodes.push(node);
            GetBroadChatLog(node,"-"+data[0].uid,node.Text);
        }
    }
}
//获取所有好友
function FriendChatLogNode(root,info,temp){
    for(var i in info){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select uid,name from users where uid = '"+info[i]+"'") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = data[0].uid+"_"+data[0].name.toString().split(";")[0];
            node.Type = "Message";
            var obj = new List();
            obj.Listed = node.Text;
            root.Items.push(obj);
            root.TreeNodes.push(node);
            GetFriendChatLog(node,data[0].uid,temp);
        }
    }
}
//获取广播记录
function GetBroadChatLog(root,info,temp){
    if(XLY.File.IsValid(recdb)){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select * from messages where uid = '"+info+"'") +')');
        if(data!=""&&data!= null){
            for(var i in data){
                if(data[i].XLY_DataType==2){
                    var obj = new Message();
                    obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    var firstCharactor = XLY.Blob.ToBytes(data[i].data,"base64");
                    obj.SenderID = temp.split("_")[0];
                    obj.SenderName = temp.split("_")[1];
                    obj.ReceiverID = temp.split("_")[0];
                    obj.ReceiverName = temp.split("_")[1];
                    if(XLY.Blob.GetBytes(firstCharactor,0x05,0x01).toString()==[0x40].toString()){
                        obj.MessageType = "系统提示";
                        var bdy = XLY.Blob.GetBytes(firstCharactor,0x1D,firstCharactor[0x1C]);
                        obj.Body = "You created the broadcast："+XLY.Blob.ToString(bdy);
                    }
                    else if(XLY.Blob.GetBytes(firstCharactor,0x05,0x01).toString()==[0x44].toString()){
                        obj.MessageType = "文本";
                        var bdy = XLY.Blob.GetBytes(firstCharactor,0x19,firstCharactor[0x18]);
                        obj.Body = XLY.Blob.ToString(bdy);
                    }
                    else if(XLY.Blob.GetBytes(firstCharactor,0x05,0x01).toString()==[0x46].toString()){
                        if(XLY.Blob.GetBytes(firstCharactor,0x1C,0x04).toString()==[0x39,0x2F,0x7D,0x5E].toString()){
                            obj.MessageType = "联系人名片";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x21,firstCharactor[0x20]);
                            var bb = XLY.Blob.GetBytes(firstCharactor,0x21+firstCharactor[0x20]+2,firstCharactor[0x21+firstCharactor[0x20]+1]);
                            obj.Body = "电话号码："+XLY.Blob.ToString(aa)+"\r"+"姓名："+XLY.Blob.ToString(bb);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x24,0x01).toString()==0x00){
                            obj.MessageType = "图片";
                            obj.Body = "图片名称："+"\r"+"图片大小："+"\r"+"图片本地路径：";
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x39,firstCharactor[0x38]).toString()==[0x61,0x75,0x64,0x69,0x6F,0x2F,0x6F,0x67,0x67].toString()){
                            if(XLY.Blob.GetBytes(firstCharactor,0x6C,0x04).toString()==[0x00,0x00,0x00,0x00].toString()){
                                obj.MessageType = "音频(ogg)";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x85,firstCharactor[0x84]);
                                obj.Body = "文件名："+XLY.Blob.ToString(aa)+"\r"+"文件路径："+XLY.Blob.GetBytes(firstCharactor,0x99,firstCharactor[0x98])+"\r"+"文件类型："+XLY.Blob.GetBytes(firstCharactor,0x85,firstCharactor[0x84]);
                            }
                            else
                            {
                                obj.MessageType = "语音";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x68,0x04);
                                obj.Body = "语音长度："+XLY.Bit.ToInt(aa,"FALSE");
                            }
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x39,firstCharactor[0x38]).toString()==[0x61,0x75,0x64,0x69,0x6F,0x2F,0x61,0x61,0x63].toString()){
                            if(XLY.Blob.GetBytes(firstCharactor,0x6C,0x04).toString()==[0x00,0x00,0x00,0x00].toString()){
                                obj.MessageType = "音频(aac)";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x89,firstCharactor[0x88]);
                                obj.Body = "文件名："+XLY.Blob.ToString(aa)+"\r"+"文件路径："+XLY.Blob.GetBytes(firstCharactor,0x99,firstCharactor[0x98])+"\r"+"文件类型："+XLY.Blob.GetBytes(firstCharactor,0x85,firstCharactor[0x84]);
                            }
                            else
                            {
                                obj.MessageType = "语音";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x68,0x04);
                                obj.Body = "语音长度："+XLY.Bit.ToInt(aa,"FALSE")+"秒";
                            }
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x69,0x6D,0x61,0x67,0x65,0x2F,0x77,0x65,0x62,0x70].toString()){
                            obj.MessageType = "表情包";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0xC1,firstCharactor[0xC0]);
                            obj.Body = XLY.Blob.ToString(aa);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x39,firstCharactor[0x38]).toString()==[0x61,0x70,0x70,0x6C,0x69,0x63,0x61,0x74,0x69,0x6F,0x6E,0x2F,0x6F,0x63,0x74,0x65,0x74,0x2D,0x73,0x74,0x72,0x65,0x61,0x6D].toString()){
                            obj.MessageType = "文件";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x75,firstCharactor[0x74]);
                            obj.Body = "文件名："+XLY.Blob.ToString(aa);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x39,firstCharactor[0x38]).toString()==[0x76,0x69,0x64,0x65,0x6F,0x2F,0x6D,0x70,0x34].toString()){
                            obj.MessageType = "视频(mp4)";
                            var brr = XLY.Blob.GetBytes(firstCharactor,0x8B,0x04);
                            obj.Body = "视频长度："+XLY.Bit.ToInt(brr,"FALSE")+"\r"+"视频路径："+firstCharactor,0xA0,firstCharactor[0xA1];
                        }
                    }
                    else
                    {
                        log(data[i].uid);
                    }
                    obj.MessageTime = XLY.Convert.LinuxToDateTime(data[i].date);
                    obj.AddPath = "";
                    root.Items.push(obj);
                }
            }
        }
    }
}
//获取群组聊天记录
function GetGroupChatLog(root,info,temp){
    if(XLY.File.IsValid(recdb)){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select * from messages where uid = '"+info+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].XLY_DataType==2){
                    var obj = new Message();
                    obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    var firstCharactor = XLY.Blob.ToBytes(data[i].data,"base64");
                    var senID = XLY.Blob.GetBytes(firstCharactor,0x0C,0x04);
                    obj.SenderID = XLY.Bit.ToInt(senID,"FALSE");
                    if(obj.SenderID!=""&&obj.SenderID!=null){
                        var senName = eval('('+ XLY.Sqlite.Find(recdb,"select name from users where uid = '"+obj.SenderID+"'") +')');
                        if(senName!=""&&senName!=null){
                            obj.SenderName = senName[0].name.split(";")[0];
                        }
                    }
                    var recID = XLY.Blob.GetBytes(firstCharactor,0x14,0x04);
                    obj.ReceiverID = XLY.Bit.ToInt(recID,"FALSE");
                    obj.ReceiverName = temp.split("_")[1];
                    
                    if(XLY.Blob.GetBytes(firstCharactor,0x05,0x01).toString()==[0x01].toString()){
                        if(XLY.Blob.GetBytes(firstCharactor,0x1C,0x04).toString()==[0x9A,0x8B,0x63,0xA6].toString()){
                            obj.MessageType = "系统提示";
                            var bdy = XLY.Blob.GetBytes(firstCharactor,0x21,firstCharactor[0x20]);
                            obj.Body = "You created the group："+XLY.Blob.ToString(bdy);
                        }
                        else
                        {
                            obj.MessageType = "文本";
                            var bdy = XLY.Blob.GetBytes(firstCharactor,0x1D,firstCharactor[0x1C]);
                            obj.Body = "You created the group："+XLY.Blob.ToString(bdy);
                        }
                    }
                    else if(XLY.Blob.GetBytes(firstCharactor,0x05,0x01).toString()==[0x03].toString())
                    {
                        if(XLY.Blob.GetBytes(firstCharactor,0x20,0x04).toString()==[0x39,0x2F,0x7D,0x5E].toString()){
                            obj.MessageType = "联系人名片";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x25,firstCharactor[0x24]);
                            var bb = XLY.Blob.GetBytes(firstCharactor,0x31,firstCharactor[0x30]);
                            obj.Body = "电话号码："+XLY.Blob.ToString(aa)+"\r"+"姓名："+XLY.Blob.ToString(bb);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x28,0x01).toString()==0x00){
                            obj.MessageType = "图片";
                            obj.Body = "图片名称："+"\r"+"图片大小："+"\r"+"图片本地路径：";
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x61,0x75,0x64,0x69,0x6F,0x2F,0x6F,0x67,0x67].toString()){
                            if(XLY.Blob.GetBytes(firstCharactor,0x6C,0x04).toString()==[0x00,0x00,0x00,0x00].toString()){
                                obj.MessageType = "音频(ogg)";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x89,firstCharactor[0x88]);
                                obj.Body = "文件名："+XLY.Blob.ToString(aa);
                            }
                            else
                            {
                                obj.MessageType = "语音";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x6C,0x04);
                                obj.Body = "语音长度："+XLY.Bit.ToInt(aa,"FALSE");
                            }
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x69,0x6D,0x61,0x67,0x65,0x2F,0x77,0x65,0x62,0x70].toString()){
                            obj.MessageType = "表情包";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0xC1,firstCharactor[0xC0]);
                            obj.Body = XLY.Blob.ToString(aa);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x61,0x70,0x70,0x6C,0x69,0x63,0x61,0x74,0x69,0x6F,0x6E,0x2F,0x6F,0x63,0x74,0x65,0x74,0x2D,0x73,0x74,0x72,0x65,0x61,0x6D].toString()){
                            obj.MessageType = "文件";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x79,firstCharactor[0x78]);
                            obj.Body = "文件名："+XLY.Blob.ToString(aa);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x76,0x69,0x64,0x65,0x6F,0x2F,0x6D,0x70,0x34].toString()){
                            obj.MessageType = "视频(mp4)";
                            var brr = XLY.Blob.GetBytes(firstCharactor,0x90,0x04);
                            obj.Body = "视频长度："+XLY.Bit.ToInt(brr,"FALSE");
                        }   
                    }
                    else
                    {
                        log(data[i].uid);
                    }
                    obj.MessageTime = XLY.Convert.LinuxToDateTime(data[i].date);
                    obj.AddPath = "";
                    root.Items.push(obj);
                }
            }
        }
    }
    return;
}
//获取好友聊天记录
function GetFriendChatLog(root,info,temp){
    if(XLY.File.IsValid(recdb)){
        var data = eval('('+ XLY.Sqlite.Find(recdb,"select * from messages where uid = '"+info+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].XLY_DataType==2){
                    var obj = new Message();
                    obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                    var firstCharactor = XLY.Blob.ToBytes(data[i].data,"base64");
                    var senID = XLY.Blob.GetBytes(firstCharactor,0x0C,0x04);
                    obj.SenderID = XLY.Bit.ToInt(senID,"FALSE");
                    if(obj.SenderID!=""&&obj.SenderID!=null){
                        var senName = eval('('+ XLY.Sqlite.Find(recdb,"select name from users where uid = '"+obj.SenderID+"'") +')');
                        if(senName!=""&&senName!=null){
                            obj.SenderName = senName[0].name.split(";")[0];
                        }
                    }
                    var recID = XLY.Blob.GetBytes(firstCharactor,0x14,0x04);
                    obj.ReceiverID = XLY.Bit.ToInt(recID,"FALSE");
                    if(obj.ReceiverID!=""&&obj.ReceiverID!=null){
                        var recName = eval('('+ XLY.Sqlite.Find(recdb,"select name from users where uid = '"+obj.ReceiverID+"'") +')');
                        if(recName!=""&&recName!=null){
                            obj.ReceiverName = recName[0].name.split(";")[0];
                        }
                    }
                    //图片和音频区分
                    if((XLY.Blob.GetBytes(firstCharactor,0x1C,0x0C).toString()==[0x00,0x00,0x00,0x00,0x3D,0xE5,0x8C,0x3D,0x29,0xDD,0x88,0x92].toString())||(XLY.Blob.GetBytes(firstCharactor,0x18,0x0C).toString()==[0x00,0x00,0x00,0x00,0xA8,0x2E,0xE0,0xF3,0xC7,0x2B,0x23,0x87].toString())||(XLY.Blob.GetBytes(firstCharactor,0x18,0x0C).toString()==[0x00,0x00,0x00,0x00,0x3D,0xE5,0x8C,0x3D,0x29,0xDD,0x88,0x92].toString())){
                        //广播的图片、音频区分
                        if(XLY.Blob.GetBytes(firstCharactor,0x18,0x0C).toString()==[0x00,0x00,0x00,0x00,0x3D,0xE5,0x8C,0x3D,0x29,0xDD,0x88,0x92].toString()){
                            if(XLY.Blob.GetBytes(firstCharactor,0x24,0x01).toString()==0x00){
                                obj.MessageType = "图片";
                                obj.Body = "Photo";
                            }
                            if(XLY.Blob.GetBytes(firstCharactor,0x18,0x0C).toString()==[0x00,0x00,0x00,0x00,0xA8,0x2E,0xE0,0xF3,0xC7,0x2B,0x23,0x87].toString())
                            {
                                obj.MessageType = "音频";
                                obj.Body = "音频时长:"+XLY.Bit.ToInt(XLY.Blob.GetBytes(firstCharactor,0x68,0x04).toString());
                            }
                        }
                        else
                        {
                            //群组的图片和音频
                            if(XLY.Blob.GetBytes(firstCharactor,0x18,0x0C).toString()==[0x00,0x00,0x00,0x00,0xA8,0x2E,0xE0,0xF3,0xC7,0x2B,0x23,0x87].toString())
                            {
                                obj.MessageType = "音频";
                                var brr = XLY.Blob.GetBytes(firstCharactor,0x68,0x04);
                                obj.Body = "音频时长:"+XLY.Bit.ToInt(brr,"FALSE");
                            }
                            if(XLY.Blob.GetBytes(firstCharactor,0x1C,0x0C).toString()==[0x00,0x00,0x00,0x00,0x3D,0xE5,0x8C,0x3D,0x29,0xDD,0x88,0x92].toString()){
                                if(XLY.Blob.GetBytes(firstCharactor,0x28,0x01).toString()==0x00){
                                    obj.MessageType = "图片";
                                    obj.Body = "Photo";
                                }
                            }
                        }
                    }//文件区分
                    else if((XLY.Blob.GetBytes(firstCharactor,0x1C,0x0C).toString()==[0x00,0x00,0x00,0x00,0xA8,0x2E,0xE0,0xF3,0xC7,0x2B,0x23,0x87].toString())||(XLY.Blob.GetBytes(firstCharactor,0x18,0x0C).toString()==[0x00,0x00,0x00,0x00,0xA8,0x2E,0xE0,0xF3,0xC7,0x2B,0x23,0x87].toString())){
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x61,0x70,0x70,0x6C,0x69,0x63,0x61,0x74,0x69,0x6F,0x6E,0x2F,0x6F,0x63,0x74,0x65,0x74,0x2D,0x73,0x74,0x72,0x65,0x61,0x6D].toString()){
                            obj.MessageType = "文件";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x79,firstCharactor[0x78]);
                            obj.Body = "文件名："+XLY.Blob.ToString(aa);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x61,0x75,0x64,0x69,0x6F,0x2F,0x6F,0x67,0x67].toString()){
                            if(XLY.Blob.GetBytes(firstCharactor,0x6C,0x04).toString()==[0x00,0x00,0x00,0x00].toString()){
                                obj.MessageType = "音频(ogg)";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x89,firstCharactor[0x88]);
                                obj.Body = "文件名："+XLY.Blob.ToString(aa);
                            }
                            else
                            {
                                obj.MessageType = "语音";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x6C,0x04);
                                obj.Body = "语音长度："+XLY.Bit.ToInt(aa,"FALSE");
                            }
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x61,0x75,0x64,0x69,0x6F,0x2F,0x61,0x61,0x63].toString()){
                            obj.MessageType = "音频(aac)";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x89,firstCharactor[0x88]);
                            obj.Body = "文件名："+XLY.Blob.ToString(aa);
                        }
                        if(XLY.Blob.GetBytes(firstCharactor,0x3D,firstCharactor[0x3C]).toString()==[0x76,0x69,0x64,0x65,0x6F,0x2F,0x6D,0x70,0x34].toString()){
                            obj.MessageType = "视频(mp4)";
                            var brr = XLY.Blob.GetBytes(firstCharactor,0x90,0x04);
                            //var aa = XLY.Blob.GetBytes(firstCharactor,0x90,firstCharactor[0x88]);
                            obj.Body = "视频长度："+XLY.Bit.ToInt(brr,"FALSE");
                        }
                    }
                    else if((XLY.Blob.GetBytes(firstCharactor,0x1C,0x04).toString()==[0x9A,0x8B,0x63,0xA6].toString())||(XLY.Blob.GetBytes(firstCharactor,0x18,0x04).toString()==[0x92,0xAC,0xD2,0x95].toString())){
                        obj.MessageType = "系统提示";
                        obj.Body = "You created the group.";
                    }
                    else
                    {
                        if(firstCharactor[0x1C]==0x00){
                            obj.MessageType = "联系人名片";
                            var aa = XLY.Blob.GetBytes(firstCharactor,0x25,firstCharactor[0x24]);
                            var bb = XLY.Blob.GetBytes(firstCharactor,0x31,firstCharactor[0x30]);
                            obj.Body = "电话号码："+XLY.Blob.ToString(aa)+"\r"+"姓名："+XLY.Blob.ToString(bb);
                        }
                        else
                        {
                            if(XLY.Blob.GetBytes(firstCharactor,0x0C,0x04).toString()==[0x32,0xE5,0xDD,0xBD].toString()){
                                obj.MessageType = "普通文本";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x19,firstCharactor[0x18]);
                                obj.Body = XLY.Blob.ToString(aa);
                            }
                            else
                            {
                                obj.MessageType = "普通文本";
                                var aa = XLY.Blob.GetBytes(firstCharactor,0x1D,firstCharactor[0x1C]);
                                obj.Body = XLY.Blob.ToString(aa);
                            }
                        }
                    }
                    obj.MessageTime = XLY.Convert.LinuxToDateTime(data[i].date);
                    obj.AddPath = "暂未确定";
                    root.Items.push(obj);
                }
            }
        }
    }
    return;
}