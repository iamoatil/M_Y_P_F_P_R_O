﻿/*[config]
<plugin name="京东,6" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/JingDong.png" app="com.360buy.jdmobile" version="3.5.0" description="京东" data="$data,ComplexTreeDataSource" >
<source>
<value>com.360buy.jdmobile</value>
</source>
<data type="Search" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="历史搜索" code="Info" type="string" width="100" format=""></item>
</data>
<data type="SearchKeyword" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关键字" code="Keyword" type="string" width="100" format=""></item>
</data>
<data type="BrowseGoods" datefilter="Time" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="商品名称" code="Name" type="string" width="300" format=""></item>
<item name="商品编号(可直接查询编号)" code="ID" type="string" width="100" format=""></item>
<item name="时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss" ></item>
</data>
<data type="Stow" >
<item name="关注的商品信息" code="Info" type="string" width="100" ></item>
</data>
<data type="LastStow" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关注商品信息" code="Info" type="string" width="100" ></item>
<item name="备注" code="Remark" type="string" width="400"  ></item>
</data>
<data type="Fav" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关注帐号" code="Account" type="string" width="100" ></item>
<item name="关注商品编号" code="ID" type="string" width="400"  ></item>
</data>
</plugin>
[config]*/

//定义数据结构
function Search() {
	this.Info = "";
	this.DataState = "Normal"; 
}

function SearchKeyword() {
	this.Keyword = "";
	this.DataState = "Normal";  
}

function BrowseGoods() {
	this.Name = "";
	this.ID = "";
	this.Time = null;
	this.DataState = "Normal"; 
}

function Stow() {
	this.Info = "";
}
function LastStow() {
	this.Info = "";
	this.Remark = "";
	this.DataState = "Normal"; 
}

function Fav() {
	this.Account = "";
	this.ID = "";
	this.DataState = "Normal"; 
}
//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}

//创建历史搜索的子树节点并获取信息
function buildSearchChildNode(tree, path) {
	//创建关键字搜索子树
	var keywrod = new TreeNode();
	keywrod.Text = "关键字搜索";
	keywrod.Type = "SearchKeyword";
	var keyworddata = getSearchKeyword(path);
	keywrod.Items = keyworddata;

	//创建浏览商品子树
	var goods = new TreeNode();
	goods.Text = "历史浏览商品";
	goods.Type = "BrowseGoods";
	var goodsdata = getBrowseGoods(path);
	goods.Items = goodsdata;

	//根节点树push子树
	tree.TreeNodes.push(keywrod);
	tree.TreeNodes.push(goods);
}

//获取历史搜索信息
function getSearch(path) {
	var keydata = eval('(' + XLY.Sqlite.Find(path, "select keyword,XLY_DataType from SearchShistoryDaoTable") + ')');
	var browserdata = eval('(' + XLY.Sqlite.Find(path, "select name,XLY_DataType from BrowseHistoryDaoTable") + ')');
	var arr1 = new Array();
	var arr2 = new Array();
	var arr = new Array();
	for (var index in keydata) {
		var obj = new Search();
		obj.Info = keydata[index].keyword;
		obj.DataState = XLY.Convert.ToDataState(keydata[index].XLY_DataType); 
		arr1.push(obj)
	}
	for (var num in browserdata) {
		var obj = new Search();
		obj.Info = browserdata[num].name;
		obj.DataState = XLY.Convert.ToDataState(browserdata[num].XLY_DataType); 
		arr2.push(obj)
	}
	arr = arrayConcat(arr1, arr2);
	return arr;
}

//合并数组
function arrayConcat(a1, a2) {
	var newarr = new Array();
	var p = 0;
	for (var k1 in a1) {
		newarr[k1] = a1[k1];
		p = k1;
	}
	++p;
	for (var k2 in a2) {
		newarr[p] = a2[k2];
		p++;
	}
	return newarr;
}

//获取搜索过的关键字信息
function getSearchKeyword(path1) {
	var data = eval('(' + XLY.Sqlite.Find(path1, "select keyword,XLY_DataType from SearchShistoryDaoTable") + ')');
	var arr = new Array();
	for (var index in data) {
		var obj = new SearchKeyword();
		obj.Keyword = data[index].keyword;
		obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
		arr.push(obj);
	}
	return arr;
}

//获取浏览商品信息
function getBrowseGoods(path) {
	var data = eval('(' + XLY.Sqlite.Find(path, "select productCode,name,XLY_DataType,cast(browseTime as text) as t from BrowseHistoryDaoTable") + ')');
	var arr = new Array();
	for (var index in data) {
		var obj = new BrowseGoods();
		obj.Name = data[index].name;
		obj.ID = data[index].productCode
			obj.Time = data[index].t;
		obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
		arr.push(obj);
	}
	return arr;
}

//获取关注商品信息
function buildStowChildNode(path,accpath,tree) {
	var data = eval('(' + XLY.Sqlite.Find(path, "select * from StowProductDaoTable") + ')');
	var accdata = eval('(' + XLY.PList.ReadToJsonString(accpath) + ')');
	for (var acc in accdata) {
		if (accdata[acc].rememberedUserName) {
			var accname = accdata[acc].rememberedUserName;
		}
	}
	var arr = new Array();
	var arr1 = new Array();
	var arr2 = new Array();
	var childTree1 = new TreeNode();
	childTree1.Text = "已登录帐号关注";
	childTree1.Type = "Fav";
	var childTree2 = new TreeNode();
	childTree2.Text = "其他帐号关注";
	childTree2.Type = "LastStow";
	for (var index in data) {
		//获取最后一次登录帐号的关注商品信息

		if (data[index].stowCode.slice(0, accname.length) == accname) {
			var obj1 = new Fav();
			obj1.Account = accname;
			obj1.ID = data[index].stowCode.slice(accname.length, data[index].length);
			obj1.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType); 
			arr1.push(obj1);
			//获取其他帐号的关注商品信息
		} else {
			var obj2 = new LastStow();
			obj2.Info = data[index].stowCode;
			obj2.Remark = "关注帐号+商品ID组成";
			obj2.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr2.push(obj2);
		}
		var obj = new Stow();
		obj.Info = data[index].stowCode;
		arr.push(obj);
	}
	tree.Items = arr;
	childTree1.Items = arr1;
	childTree2.Items = arr2;
	tree.TreeNodes.push(childTree1);
	tree.TreeNodes.push(childTree2);
}

var result = new Array();

//源文件
var source = $source;
var path = source[0] + "\\com.360buy.jdmobile\\Documents\\JD4iPhone.sqlite";
var accpath = source[0] + "\\com.360buy.jdmobile\\Library\\Preferences\\com.360buy.jdmobile.plist";
//var path = "F:\\JS\\京东 IOS\\com.360buy.jdmobile\\Documents\\JD4iPhone.sqlite";
//var accpath ="F:\\JS\\京东 IOS\\com.360buy.jdmobile\\Library\\Preferences\\com.360buy.jdmobile.plist";

var charactor="chalib\\IOS_JingDong_V3.5.0\\JD4iPhone.sqlite.charactor";
var repath=XLY.Sqlite.DataRecovery( path,charactor ,"BrowseHistoryDaoTable,SearchShistoryDaoTable,StowProductDaoTable");
XLY.Debug.WriteLine( repath);

//创建历史搜索树
var search = new TreeNode();
search.Text = "历史搜索";
search.Type = "Search";
search.Items = getSearch(repath);
buildSearchChildNode(search, repath);

//创建关注树
var stow = new TreeNode();
stow.Text = "关注商品";
stow.Type = "Stow";
buildStowChildNode(repath, accpath, stow);

result.push(search);
result.push(stow);
var res = JSON.stringify(result);
res;
