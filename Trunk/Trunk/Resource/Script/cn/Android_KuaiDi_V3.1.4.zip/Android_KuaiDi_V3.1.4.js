﻿/*[config]
<plugin name="快的打车" group="地图公交,6" devicetype="android" icon="\icons\kuaidi.png" pump="USB,Mirror,Wifi,Bluetooth,chip,Raid" app="com.funcity.taxi.passenger" version="3.1.4"
     description="提取安卓快的打车" data="$data">
    <source>
      <value>/data/data/com.funcity.taxi.passenger/databases/passenger.db</value>
      <value>/data/data/com.funcity.taxi.passenger/shared_prefs/default.xml</value>
    </source>
    <data>
        <item name="用户名" code="UserName" type="string" width = "150"></item>
        <item name="我的坐标" code="MyLocation" type="string" width="200"></item>
        <item name="联系人" code="DriverName" type="string" width="150"></item>
        <item name="联系人坐标" code="DriverLocation" type="string" width="200"></item>
        <item name="车牌号" code="CarNumber" type="string" width="100"></item>
        <item name="出发地" code="FromLoc" type="string" width="200" ></item>
        <item name="目的地" code="EndLoc" type="string" width="100"></item>
        <item name="创建时间" code="CreatedTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>  
    </data>
</plugin>
[config]*/

//定义数据结构
function Item() {
    this.UserName = "";
    this.MyLocation = "";
    this.DriverName = "";
    this.DriverLocation = "";
    this.CarNumber="";
    this.FromLoc="";
    this.EndLoc = "";
    this.CreatedTime = null;
}

var result = new Array();
//源文件
var source = $source;
var db=source[0];
var xmlfile=source[1];
//var db = "D:\\temp\\data\\data\\com.funcity.taxi.passenger\\databases\\passenger.db";
//var xmlfile = "D:\\temp\\data\\data\\com.funcity.taxi.passenger\\shared_prefs\\default.xml";
var dblist = eval('(' + XLY.Sqlite.FindByName(db, 'records') + ')');
var name,usermobile;
var data = eval('(' + XLY.File.ReadXML(xmlfile) + ')');
for (var index in data.map.string) {
    if (data.map.string[index]["@name"] == "user") {
        var jsonstr = data.map.string[index]["#text"];
        var json = JSON.parse(jsonstr);
        usermobile = json.passengerInfo.mob;
        name = json.passengerInfo.name;
    }
}
for (var i in dblist) {
    var row = dblist[i];
    var obj = new Item();
    obj.DriverName = XLY.Convert.ToString(row.name)+"("+row.mobile+")";
    obj.MyLocation = "经度:"+XLY.Convert.ToDouble(row.lng)+",纬度:"+XLY.Convert.ToDouble(row.lat)+"";
    obj.CarNumber= XLY.Convert.ToString(row.car_no);
    obj.CreatedTime = XLY.Convert.LinuxToDateTime(row.created);
    obj.FromLoc= XLY.Convert.ToString(row.city)+"—"+XLY.Convert.ToString(row.from_loc);
    obj.EndLoc=XLY.Convert.ToString(row.city)+"—"+XLY.Convert.ToString(row.to_loc);
    obj.UserName = XLY.Convert.ToString(name)+"("+usermobile+")";
    obj.DriverLocation = "经度:"+XLY.Convert.ToDouble(row.driver_lng)+",纬度:"+XLY.Convert.ToDouble(row.driver_lat)+""
    result.push(obj);
}

var res = JSON.stringify(result);
res;
