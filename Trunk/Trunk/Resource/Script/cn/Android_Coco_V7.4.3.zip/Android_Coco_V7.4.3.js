﻿/*[config]
<plugin name="Coco,10" group="社交聊天,17" devicetype="android" icon="\icons\coco.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.instanza.cocovoice" version="7.4.3" description="Coco" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.instanza.cocovoice/databases#F</value>
</source>
<data type="Coco" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="Coco" code="List" type="string" width = "150"></item>
</data>
<data type="Chatmsg" contract = "DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="发送人" code="Fid" type="string" width =  "200"></item>
<item name="接收者" code="Rid" type="string" width =  "200"></item>
<item name="消息内容" code="Content" type="string" width = "200"></item>
<item name="消息类型" code="Msgtype" type="string" width = "200"></item>
<item name="创建日期" code="Msgtime" type="datetime" format="yyyy-MM-dd HH:mm:ss" width = "200"></item>
<item name="接收时间" code="Displaytime" type="datetime" format="yyyy-MM-dd HH:mm:ss" width = "200"></item>
</data>
<data type="Friend" contract = "DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="用户ID" code="Id" type="string" width = "200"></item>
<item name="用户头像" type="image" show="ture"></item>
<item name="COCOID" code="Cid" type="string" width = "200"></item>
<item name="好友昵称" code="Nickname" type="string" width = "200"></item>
<item name="个人签名" code="Note" type="string" width = "200"></item>
<item name="国籍编码" code="Country" type="string" width = "200"></item>
<item name="电子邮箱" code="Email" type="string" width = "200"></item>
<item name="出生日期" code="Birthday" type="string" width = "200"></item>
<item name="性别" code="Gender" type="string" width = "200"></item>
<item name="更新日期" code="Utime" type="string" format="yyyy-MM-dd HH:mm:ss" width = "200"></item>
</data>
<data type="Setting" contract = "DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="账号ID" code="Sid" type="string" width = "200"></item>
<item name="账号头像" code="Savatar" type="image" show="ture"></item>
<item name="COCO ID" code="Scid" type="string" width = "200"></item>
<item name="个人昵称" code="Snickname" type="string" width = "200"></item>
<item name="国籍编码" code="Scountry" type="string" width = "200"></item>
<item name="个人签名" code="Snote" type="string" width = "200"></item>
<item name="电子邮箱" code="Semail" type="string" width = "200"></item>
<item name="出生日期" code="Sbirthday" type="string" width = "200"></item>
<item name="性别" code="Sgender" type="string" width = "200"></item>
<item name="更新日期" code="Sutime" type="string" format="yyyy-MM-dd HH:mm:ss" width = "200"></item>
</data>
</plugin>
[config]*/
function Chatmsg(){
    this.DataState = "Normal";
    this.Fid = "";
    this.Rid = "";
    this.Msgtype = "";
    this.Content = "";
    this.Msgtime = "";
    this.Displaytime = "";
    this.Remaintime = "";
}
function Friend(){
    this.DataState = "Normal";
    this.Id = "";
    this.Avatar = "";
    this.Cid = "";
    this.Nickname = "";
    this.Note = "";
    this.Country = "";
    this.Email = "";
    this.Birthday = "";
    this.Gender = "";
    this.Utime = "";
}
function Setting(){
    this.DataState = "Normal";
    this.Sid = "";
    this.Savatar = "";
    this.Scid = "";
    this.Snickname = "";
    this.Scountry = "";
    this.Snote = "";
    this.Semail = "";
    this.Sbirthday = "";
    this.Sgender = "";
    this.Sutime = "";
}
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
//****************************************************************************************************************************************************

//var charactor = "D:\\temp\\o\\data\\data\\com.ooVoo\\databases\\Core.db";
var source = $source;
var userPath = source[0];
//var userPath = "D:\\temp\\data\\data\\com.instanza.cocovoice\\databases";
var result = new Array();
//var db = XLY.Sqlite.DataRecovery(db0,charactor,"groups,medialib,moment,roster,settings");

bindTree();
var res = JSON.stringify(result);
res;
//****************************************************************************************************************************************************
function bindTree(){
    var c = eval('('+ XLY.File.FindFiles(userPath) +')');
    var d = new Array();
    for(var i in c){
        if(i%2 == 0){
            d.push(c[i]);
        }
    }
    log(d);
    var userDb = new Array();
    var userId = new Array();
    for(var i in d){
        userDb[i] = d[i].substr(-17);
        log( userDb[i]);
        userId[i] = d[i].substr(-16,8);
    }
    var db = new Array();
    
    for(var i in userDb){
    
        
    db[i] = userPath + userDb[i]; 
    log(db[i]);

       
    var friend = new TreeNode();
    friend.Text = "好友信息";
    friend.Type = "Friend";
    friend.Items = getFriendInfo(db[i]);
    
    
    var friendList = eval('('+ XLY.Sqlite.Find(db[i],"select userId from FriendModel") +')');
    getFriendmsg(db[i],friend,friendList); 
 
    
    var setting = new TreeNode();
    setting.Text = userId[i];
    setting.Type = "Setting";
    setting.Items = getSettingInfo(db[i],userId[i]);
    

    setting.TreeNodes.push(friend);
    result.push(setting);
}
}
//****************************************************************************************************************************************************

function getFriendInfo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from FriendModel inner join UserModel on FriendModel.userId = UserModel.cocoNumber" ) +')');
   for(var i in data){
       var obj = new Friend();
       obj.Id = data[i].userId;
       obj.Avatar = data[i].avatarPrevUrl;
       obj.Cid = data[i].cocoId;
       obj.Nickname = data[i].nickName;
       obj.Note = data[i].note;
       obj.Country = data[i].country;
       obj.Email = data[i].email;
       obj.Birthday = (data[i].birthdayYear) +'年'+ (data[i].birthdayMonth)+'月'+ (data[i].birthdayDay) +'日';
       var a = data[i].gender;
       if(a==1)
           obj.Gender = "男";
       else if(a==2)
           obj.Gender = "女";
       else
           obj.Gender = "未知";
       //obj.Gender = data[i].gender;
       obj.Utime = XLY.Convert.LinuxToDateTime(data[i].updateTime);
       obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
       list.push(obj);
    }
    return list;
}



function getSettingInfo(path,Id){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from UserModel where cocoNumber='" + Id + "'" ) +')');
    for(var i in data){
        var obj = new Setting();
        obj.Sid = data[i].userId;
        obj.Savatar = data[i].avatarPrevUrl;
        obj.Scid = data[i].cocoId;
        obj.Snickname = data[i].nickName;
        obj.Snote = data[i].note;
        obj.Scountry = data[i].country;
        obj.Semail = data[i].email;
        obj.Sbirthday = (data[i].birthdayYear) +'年'+ (data[i].birthdayMonth)+'月'+ (data[i].birthdayDay) +'日';
        var a = data[i].gender;
       switch(a)
       {
         case "0":
           obj.Sgender = "未知";
           break;
         case "1":
           obj.Sgender = "男";
           break;
         case "2":
           obj.Sgender = "女";
           break;
       }
        obj.Sutime = XLY.Convert.LinuxToDateTime(data[i].updateTime);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFriendmsg(path,friend,friendList) {
    for(var i in friendList){
       var friendInfo = friendList[i];
       friendInfo.Id = friendList[i].userId;
       var friendTree = new TreeNode();
       friendTree.Type = "Chatmsg";
       friendTree.Text = friendInfo.Id;
       friendTree.items = getFriendmsgInfo(path);
       friendTree.DataState = XLY.Convert.ToDataState(friend.XLY_DataType);
       function getFriendmsgInfo(path){
       var list = new Array();
       var data = eval('('+ XLY.Sqlite.Find(path,"select distinct * from ChatMessageModel where touid = '" + friendInfo.Id + "' or fromuid = '" + friendInfo.Id + "'") +')');
       for(var i in data){
        var obj = new Chatmsg();
        obj.Fid = data[i].fromuid;
        obj.Rid = data[i].touid;
        obj.Content = data[i].content;
        obj.Msgtime = XLY.Convert.LinuxToDateTime(data[i].msgtime);
        obj.Displaytime = XLY.Convert.LinuxToDateTime(data[i].displaytime);
        var a = data[i].msgtype;
        switch(a)
        {
      case 0:
        obj.Msgtype = "文本";
        break;
      case 1:
        obj.Msgtype = "图片";
        break;
      case 2:
        obj.Msgtype = "语音";
        break;
      case 7:
        obj.Msgtype = "位置";
        break;
      case 14:
        obj.Msgtype = "语音";
        break;
      case 15:
        obj.Msgtype = "名片";
        break;
        }
        obj.Status = data[i].status;
        obj.Sutime = XLY.Convert.LinuxToDateTime(data[i].updateTime);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
       }
    return list;
    }
       friend.TreeNodes.push(friendTree);
    } 
}

