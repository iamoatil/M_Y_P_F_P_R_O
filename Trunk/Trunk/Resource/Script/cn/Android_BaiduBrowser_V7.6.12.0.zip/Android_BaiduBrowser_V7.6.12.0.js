﻿/*[config]
<plugin name="百度浏览器" group="Web痕迹,7" devicetype="android" icon="\icons\baidubrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.baidu.browser.apps" version="7.6.12.0" description="百度浏览器" data="$data,ComplexTreeDataSource">
    <source>
        <value>/data/data/com.baidu.browser.apps/databases#F</value>
        <value>/data/data/com.baidu.browser.apps/app_webview_baidu/Cookies</value>

    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Account" contract="DataState" datefilter = "LastPlayTime">
    <item name="账号ID" code="ID" type="string" width = "150"></item>
    </data>
    <data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="主键" code="Key" type="string" width = "150"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="值" code="Value" type="string" width = "200"></item>
    </data>
    <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="搜索关键字" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="最后访问时间" code="Time" type="string" width = "200"></item>
    <item name="创建时间" code="Create" type="string" width = "200"></item>
    </data>
    <data type="MobileBookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    <item name="最后访问时间" code="Last" type="string" width = "200"></item>
    <item name="同步时间" code="Sync" type="string" width = "200"></item>
    <item name="同步ID" code="SyncID" type="string" width = "200"></item>
    <item name="账号ID" code="ID" type="string" width = "150"></item>
    <item name="账号ID" code="AccountID" type="string" width = "200"></item>
    <item name="设备平台" code="Platform" type="string" width = "200"></item>
    </data>
<data type="PCBookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    <item name="最后访问时间" code="Last" type="string" width = "200"></item>
    <item name="同步时间" code="Sync" type="string" width = "200"></item>
    <item name="账号ID" code="ID" type="string" width = "150"></item>
    <item name="同步ID" code="SyncID" type="string" width = "200"></item>
    <item name="账号ID" code="AccountID" type="string" width = "200"></item>
    <item name="设备平台" code="Platform" type="string" width = "200"></item>
    <item name="编辑时间" code="Edit" type="string" width = "200"></item>
    </data>
<data type="HomePage" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="同步ID" code="Id" type="string" width = "150"></item>
    <item name="访问次数" code="Visits" type="string" width = "150"></item>
    <item name="最后访问时间" code="Time" type="string" width = "200"></item>
    <item name="创建时间" code="Create" type="string" width = "200"></item>
    <item name="编辑时间" code="Edit" type="string" width = "200"></item>
    <item name="账号ID" code="ID" type="string" width = "150"></item>
    <item name="设备平台" code="Platform" type="string" width = "200"></item>
    <item name="账号ID" code="AccountID" type="string" width = "200"></item>
    
    </data>
<data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="值" code="Key" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="存储路径" code="Path" type="string" width = "150"></item>
    <item name="文件大小" code="Size" type="string" width = "150"></item>
    <item name="已下载大小" code="CSize" type="string" width = "150"></item>
    <item name="开始时间" code="Time" type="string" width = "150"></item>
    <item name="结束时间" code="EndTime" type="string" width = "150"></item>
    </data>
<data type="Video" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="来源" code="Source" type="string" width = "150"></item>
    <item name="播放时间" code="Time" type="string" width = "150"></item>
    <item name="时长" code="Duration" type="string" width = "150"></item>
    <item name="是否离线" code="Offline" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account(){
    this.ID = "";
}
function Cookies(){
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function HomePage(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Id = "";
    this.Visits = "";
    this.Time = "";
    this.ID = "";
    this.Create = "";
    this.Edit = "";
    this.Platform = "";
    this.AccountID = "";
    
}
function Search(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
    this.Create = "";
}
function MobileBookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
    this.Last = "";
    this.ID = "";
    this.Sync = "";
    this.SyncID = "";
    this.AccountID = "";
    this.Platform = "";
}
function PCBookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
    this.Last = "";
    this.ID = "";
    this.Sync = "";
    this.SyncID = "";
    this.AccountID = "";
    this.Platform = "";
    this.Edit = "";
}

function Download(){
    this.DataState = "Normal";
    this.Key = "";
    this.Url = "";
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.CSize = "";
    this.Time = "";
    this.EndTime = "";
}
function Video(){
    this.DataState = "Normal";
    this.Name = "";
    this.Source = "";
    this.Time = "";
    this.Duration = "";
    this.Offline = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}


function bindTree(){
    var news = new TreeNode();
    news.Text = "百度浏览器";
    news.Type = "News";
    accountinfo = getNews();
    //news.Items = accountinfo;
    news.DataState = "Normal";
    
//    

    
//newTreeNode("账号ID","Account",getAccount(db9),news);
    var news1 = new TreeNode();
    news1.Text = "账号ID";
    news1.Type = "Account";
    accountinfo = getAccount(db9);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    
    for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].ID;
        account.Type = "Account"; 
        news1.TreeNodes.push(account)
        
    newTreeNode("主页信息","HomePage",getHomePage(db9,accountinfo[i]),account);
    newTreeNode("手机书签","MobileBookmark",getMobileBookmark(db9,accountinfo[i]),account);
    newTreeNode("电脑书签","PCBookmark",getPCBookmark(db9,accountinfo[i]),account);
     }
    
    newTreeNode("搜索","Search",getSearch(db9),news);
    newTreeNode("浏览记录","History",getHistory(db9),news);
   
    newTreeNode("Cookies","Cookies",getCookies(db10),news);
    newTreeNode("下载","Download",getDownload(db11),news);
    newTreeNode("视频播放","Video",getVideo(db12),news);
  //
    
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["账号ID","搜索","浏览记录","Cookies","视频播放","下载"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
//  function getAccountNode(){
//    var list = new Array();
//    var data = ["手机书签","电脑书签","主页信息"];
//    for(var i in data){
//        var obj = new AccountNode();
//        obj.List = data[i];
//        list.push(obj);
//    }
//    return list;
//}  

function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}

function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select account_uid FROM bookmark union select account_uid FROM homepage" ) +')');
    for(var i in data){
        var obj = new Account();
        var a = data[i].account_uid;
        log(a);
        if(a !=null && a.length>0){
           obj.ID = data[i].account_uid;
        }
        else
        {
            obj.ID = "默认账号";
        }
        
        list.push(obj);
    }
    return list;
}

function getCookies(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cookies" ) +')');
    for(var i in data){
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHomePage(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from homepage where account_uid = '"+accountinfo.ID+"'" ) +')');
    for(var i in data){
        var obj = new HomePage();
        obj.Name = data[i].title;
        obj.Url = data[i].url;
        obj.Id = data[i].sync_uuid;
        obj.Visits = data[i].visits;
        obj.AccountID = data[i].account_uid;
        obj.Platform = data[i].platform;
        obj.ID = data[i].account_uid;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Create = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Edit = XLY.Convert.LinuxToDateTime(data[i].edit_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from url_input_record" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Create = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getMobileBookmark(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from bookmark where account_uid = '"+accountinfo.ID+"'" ) +')');
    for(var i in data){
        var obj = new MobileBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.AccountID = data[i].account_uid;
        obj.SyncID = data[i].sync_uuid;
        obj.Platform = data[i].platform;
        obj.Id = data[i].sync_uuid;
        obj.ID = data[i].account_uid;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Last = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Sync = XLY.Convert.LinuxToDateTime(data[i].sync_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getPCBookmark(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from pc_bookmark where account_uid = '"+accountinfo.ID+"'" ) +')');
    for(var i in data){
        var obj = new PCBookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.AccountID = data[i].account_uid;
        obj.SyncID = data[i].sync_uuid;
        obj.Platform = data[i].platform;
        obj.Id = data[i].sync_uuid;
        obj.Visits = data[i].visits;
        obj.ID = data[i].account_uid;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.Last = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.Sync = XLY.Convert.LinuxToDateTime(data[i].sync_time);
        obj.Edit = XLY.Convert.LinuxToDateTime(data[i].edit_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from bddownloadtable" ) +')');
    for(var i in data){
        var obj = new Download();
        obj.Key = data[i].key;
        obj.Url = data[i].url;
        obj.Name = data[i].filename;
        obj.Path = data[i].savepath;
        obj.Size = data[i].total+"bytes";
        obj.CSize = data[i].current+"bytes";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].createdtime);
        obj.EndTime = XLY.Convert.LinuxToDateTime(data[i].completetime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getVideo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history" ) +')');
    for(var i in data){
        var obj = new Video();
        obj.Name = data[i].title;
        obj.Source = data[i].source_url;
        obj.Duration = data[i].duration+"秒";
        obj.Offline = (data[i].is_offline==1) ? "是" : "否";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time_stamp);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0]+"\\dbbrowser.db";   
var db1 = source[1];
var db2 = source[0]+"\\flyflowdownload.db";
var db3 = source[0]+"\\dbvideo.db";
var charactor1 = "\\chalib\\Android_BaiduBrowser_V7.6.12.0\\dbbrowser.db.charactor";
var charactor2 = "\\chalib\\Android_BaiduBrowser_V7.6.12.0\\Cookies.charactor";
var charactor3 = "\\chalib\\Android_BaiduBrowser_V7.6.12.0\\flyflowdownload.charactor";
var charactor4 = "\\chalib\\Android_BaiduBrowser_V7.6.12.0\\dbvideo.charactor";

//
//var charactor1 ="D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\dbbrowser.db.charactor";
//var charactor2 = "D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\Cookies.charactor";
//var charactor3 ="D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\flyflowdownload.db.charactor";
//var charactor4 = "D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\dbvideo.db.charactor";
//db="D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\dbbrowser.db";
//db1 = "D:\\temp\\data\\data\\com.baidu.browser.apps\\app_webview_baidu\\Cookies";
//db2 = "D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\flyflowdownload.db";
//db3 = "D:\\temp\\data\\data\\com.baidu.browser.apps\\databases\\dbvideo.db";
var db9 = XLY.Sqlite.DataRecovery(db,charactor1,"homepage,url_input_record,history,bookmark,pc_bookmark");
var db10 = XLY.Sqlite.DataRecovery(db1,charactor2,"cookies");
var db11 = XLY.Sqlite.DataRecovery(db2,charactor3,"bddownloadtable");
var db12 = XLY.Sqlite.DataRecovery(db3,charactor4,"history");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
