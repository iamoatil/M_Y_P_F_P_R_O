﻿/*[config]
<plugin name="微信电话本,10" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/weixinben.png" app="com.tencent.pb" version="2.0.1" description="微信电话本" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.tencent.pb/databases/contactsv2.db</value>
</source>
<data type="CONTACT" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="联系人" code="name" type="String" width="150"></item>    
<item name="电话" code="phone" type="String" width="150"></item>    
<item name="分组备注" code="groupNote" type="String" width="150"></item>
</data>
<data type="GROUP" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="分组备注" code="groupNote" type="String" width="150"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function CONTACT() {
	this.name = "";
	this.phone ="";  
	this.groupNote = "";
	this.DataState= "Normal";
}

function GROUP() {
	this.groupNote = "";  
	this.DataState= "Normal";
}

//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
	this.DataState = "Normal";
}

//获取手机通讯录的函数
function contanctNodeCreate(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select distinct name,phonelist,expand1,XLY_DataType from tb_contacts") + ')');
		for (var index in data) {
			if(data[index].phonelist){
				var obj = new CONTACT();
				obj.name = data[index].name;
				obj.phone = data[index].phonelist;
				obj.groupNote = data[index].expand1;
				obj.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType); 
				arr.push(obj)
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}
//获取分组数据的函数
function groupNodeCreate(path,group) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select distinct name,phonelist,expand1,XLY_DataType from tb_contacts") + ')');
		for (var index in data) {
			if(data[index].phonelist){
				if(data[index].expand1.indexOf(group)>=0){
					var obj = new CONTACT();
					obj.name = data[index].name;
					obj.phone = data[index].phonelist;
					obj.groupNote = data[index].expand1;
					obj.DataState = XLY.Convert.ToDataState( data[index].XLY_DataType); 
					arr.push(obj);
				}
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//获取群组信息的函数
function allGroupNodeCreate(groupData) {
	var arr = new Array();
	try{
		for (var index in groupData) {
			var obj = new GROUP();
			obj.groupNote=groupData[index].name;
			obj.DataState = XLY.Convert.ToDataState( groupData[index].XLY_DataType); 
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0];

var charactor="chalib\\Android_WeiXinDP_V2.0.1\\contactsv2.db.charactor";
path1=XLY.Sqlite.DataRecovery(path1,charactor ,"tb_contacts");


//父节点
var contactNode = new TreeNode();
contactNode.Text = "电话本";
contactNode.Type = "CONTACT";

var allGroupNode = new TreeNode();
allGroupNode.Text = "分组备注";
allGroupNode.Type = "GROUP";
//子节点遍历
contactNode.Items = contanctNodeCreate(path1);
var groupData = eval('(' + XLY.Sqlite.Find(path1,"select distinct name,XLY_DataType from tb_contacts where isfavorite = 2")+')');
if(groupData)
{
	allGroupNode.Items=allGroupNodeCreate(groupData);
	for(var index in groupData)
	{
		var groupNode = new TreeNode();
		groupNode.Text = groupData[index].name;
		groupNode.Type = "CONTACT";
		groupNode.DataState = XLY.Convert.ToDataState( groupData[index].XLY_DataType); 
		groupNode.Items = groupNodeCreate(path1,groupData[index].name);
		allGroupNode.TreeNodes.push(groupNode);
	}
}

//打印数据
result.push(contactNode);
result.push(allGroupNode);
var res = JSON.stringify(result);
res;
