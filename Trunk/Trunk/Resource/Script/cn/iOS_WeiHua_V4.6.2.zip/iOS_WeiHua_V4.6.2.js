﻿/*[config]
<plugin name="微话,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/iOSweihua.png" app="com.weihua.whuadev" version="4.6.2" description="微话" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.weihua.whuadev</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="微话ID" code="UID" type="string" width="120" format = "" ></item>
    <item name="登录密码" code="PassWord" type="string" width="100" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="签名" code="WordSign" type="string" width="120" format = "" ></item>
    <item name="电话号码" code="MobileNumber" type="string" width="120" format = "" ></item>
    <item name="地址" code="Address" type="string" width="120" format = "" ></item>
    <item name="是否当前登录" code="IsLoading" type="string" width="80" format = "" ></item>
</data>
<data type="FollowInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="昵称" code="NickName" type="string" width="120" format = "" ></item>
    <item name="微话ID" code="UID" type="string" width="120" format = "" ></item>
    <item name="性别" code="Sex" type="string" width="120" format = "" ></item>
    <item name="备注" code="Remark" type="string" width="120" format = "" ></item>
    <item name="头像" code="HeadUrl" type="url" width="120" format = "" ></item>
    <item name="签名" code="WordSign" type="string" width="120" format = "" ></item>
    <item name="电话号码" code="MobileNumber" type="string" width="120" format = "" ></item>
    <item name="地址" code="Address" type="string" width="120" format = "" ></item>
</data>
<data type="CallLog" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="通话人号码" code="CallPhone" type="string" width="120" format = "" ></item>
    <item name="通话人名称" code="CallName" type="string" width="120" format = "" ></item>
    <item name="类型" code="CallType" type="string" width="80" format=""></item>
    <item name="通话时长" code="CallLen" type="string" width="80" format=""></item>
    <item name="通话时间" code="CallTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Calls" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="通话人号码" code="CallPhone" type="string" width="120" format = "" ></item>
    <item name="通话次数" code="CallTimes" type="string" width="80" format = "" ></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
function Calls(){
    this.DataState = "Normal";
    this.CallPhone = "";
    this.CallTimes = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.NickName = "";
    this.UID = "";
    this.Sex = "";
    this.HeadUrl = "";
    this.WordSign = "";
    this.MobileNumber = "";
    this.Address = "";
    this.IsLoading = "否";
    this.PassWord = "";
}
//定义FollowInfo数据结构
function FollowInfo(){
    this.DataState = "Normal";
    this.NickName = "";
    this.UID = "";
    this.Sex = "";
    this.Remark = "";
    this.HeadUrl = "";
    this.WordSign = "";
    this.MobileNumber = "";
    this.Address = "";
}
//定义CallLog数据结构
function CallLog(){
    this.DataState = "Normal";
    this.CallPhone = "";
    this.CallName = "";
    this.CallType = "";
    this.CallLen = "";
    this.CallTime = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.weihua.whuadev\\Documents";
var userPath = source[0]+"\\com.weihua.whuadev\\Library\\Preferences\\com.weihua.whuadev.plist";
//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-08-18-13-42-19\\source\\IosData\\2017-08-18-13-42-42\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.weihua.whuadev\\Documents"
//var userPath = "C:\\XLYSFTasks\\任务-2017-08-18-13-42-19\\source\\IosData\\2017-08-18-13-42-42\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.weihua.whuadev\\Library\\Preferences\\com.weihua.whuadev.plist";
//定义特征库文件
var charactor = "\\chalib\\iOS_WeiHua_V6.26\\13981910547.sqlite.charactor";

//恢复数据库中删除的数据
//var baiduCache = XLY.Sqlite.DataRecovery(baiduCache1,charactor,"WebCache,bookmark,commonVisit,history,search_history,search_site_table");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "微话";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userinfo = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        if(userinfo!=""&&userinfo!= null){
            var aaaNum = "";
            var aaaPass = "";
            for(var i in userinfo){
                if(userinfo[i].username111!=""&&userinfo[i].username111!=null){
                    aaaNum = userinfo[i].username111;
                }
                if(userinfo[i].password111!=""&&userinfo[i].password111!=null){
                    aaaPass = userinfo[i].password111;
                }
            }
            if(aaaNum!=""){
                var userLoading = eval('('+ XLY.File.FindDirectories(allPath) +')');
                var reg = new RegExp("^[0-9]*$");
                if(userLoading!=""){
                    for(var i in userLoading){
                        var fur = userLoading[i].substr(allPath.length+1,userLoading[i].length);
                        if(reg.test(fur)){
                            if(fur!= "10829220927"){
                                var tempPath1 = allPath+"\\"+fur+"\\"+fur+".sqlite";
                                var tempPath = XLY.Sqlite.DataRecovery(tempPath1,charactor,"UserBaseInfo,NewFriendInfo,CALLRECTIMES,CALLREC");
                                if(XLY.File.IsValid(tempPath)){
                                    var userinfodata = eval('('+ XLY.Sqlite.Find(tempPath,"select XLY_DataType,weihuaId,phoneNum,nickname,signature,faceUrl,friendSex,province,city from UserBaseInfo where phoneNum like '"+"%"+fur+"'") +')');
                                    if(userinfodata!=""&&userinfodata!=null){
                                        var usernode = new TreeNode();
                                        
                                        usernode.Type = "UserInfo";
                                        var objUser = new UserInfo();
                                        objUser.DataState = XLY.Convert.ToDataState(userinfodata[0].XLY_DataType);
                                        objUser.NickName = userinfodata[0].nickname;
                                        objUser.UID = userinfodata[0].weihuaId;
                                        if(userinfodata[0].friendSex==1){
                                            objUser.Sex = "男";
                                        }
                                        else if(userinfodata[0].friendSex==2){
                                            objUser.Sex = "女";
                                        }
                                        else
                                        {
                                            objUser.Sex = "未指定";
                                        }
                                        
                                        objUser.HeadUrl = userinfodata[0].faceUrl;
                                        objUser.WordSign = userinfodata[0].signature;
                                        objUser.MobileNumber = userinfodata[0].phoneNum;
                                        objUser.Address = userinfodata[0].province+userinfodata[0].city;
                                        if(fur==aaaNum){
                                            objUser.IsLoading = "是";
                                            objUser.PassWord = aaaPass;
                                        }
                                        usernode.Text = fur+"_"+userinfodata[0].nickname;
                                        usernode.Items.push(objUser);
                                        getUserInfo(usernode,objUser.UID,objUser.NickName,tempPath);
                                        root.TreeNodes.push(usernode);
                                    }
                                }
                                
                            }
                        }
                    }
                }
            }
        }
    }
}
function getUserInfo(root,userid,username,path){
    getFollowInfo(root,userid,path);
    getMessageInfo(root,userid,username,path);
}
function getFollowInfo(root,userid,path){
    if(XLY.File.IsValid(path)){
        var followIdData = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,weihuaId,formatPhoneNum1,formatPhoneNum2,remark from NewFriendInfo") +')');
        if(followIdData!=""&&followIdData!=null){
            var followNode = new TreeNode();
            followNode.Text = "好友列表";
            followNode.Type = "FollowInfo";
            for(var i in followIdData){
                var objFollow = new FollowInfo();
                objFollow.DataState = XLY.Convert.ToDataState(followIdData[i].XLY_DataType);
                objFollow.Remark = followIdData[i].remark;
                objFollow.MobileNumber = followIdData[i].formatPhoneNum1+followIdData[i].formatPhoneNum2;
                
                var followData = eval('('+ XLY.Sqlite.Find(path,"select weihuaId,nickname,signature,faceUrl,friendSex,province,city from UserBaseInfo where weihuaId = '"+followIdData[i].weihuaId+"'") +')');
                if(followData!=""&&followData!=null){
                    objFollow.NickName = followData[0].nickname;
                    objFollow.UID = followData[0].weihuaId;
                    if(followData[0].friendSex==1){
                        objFollow.Sex = "男";
                    }
                    else if(followData[0].friendSex==2){
                        objFollow.Sex = "女";
                    }
                    else
                    {
                        objFollow.Sex = "未指定";
                    }
                    
                    objFollow.HeadUrl = followData[0].faceUrl;
                    objFollow.WordSign = followData[0].signature;
                    objFollow.Address = followIdData[i].province+followIdData[i].city;
                }
                followNode.Items.push(objFollow);
            }
            root.TreeNodes.push(followNode);
        }
    }
}
function getMessageInfo(root,userid,username,path){
    if(XLY.File.IsValid(path)){
        var CallUidInfo = eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,PHONE,TIMES from CALLRECTIMES") +')');
        if(CallUidInfo!=""&&CallUidInfo!= null){
            var callNode = new TreeNode();
            callNode.Text = "通话记录";
            callNode.Type = "Calls";
            for(var i in CallUidInfo){
                var clNode = new TreeNode();
                var clObj = new Calls();
                clObj.DataState = XLY.Convert.ToDataState(CallUidInfo[i].XLY_DataType);
                clObj.CallPhone = CallUidInfo[i].PHONE;
                clObj.CallTimes = CallUidInfo[i].TIMES;
                callNode.Items.push(clObj);
                clNode.Type = "CallLog";
                var callLogData =  eval('('+ XLY.Sqlite.Find(path,"select XLY_DataType,PHONE,TICK,SECONDS,CALLTYPE,NAME,MESSAGEID from CALLREC where PHONE like '"+"%"+CallUidInfo[i].PHONE+"'") +')');
                if(callLogData!=""&&callLogData!=null){
                    clNode.Text = CallUidInfo[i].PHONE+"_"+callLogData[0].NAME;
                    for(var j in callLogData){
                        var callObj = new CallLog();
                        callObj.DataState = XLY.Convert.ToDataState(callLogData[j].XLY_DataType);
                        callObj.CallPhone = callLogData[j].PHONE;
                        callObj.CallName = callLogData[j].NAME;
                        if(callLogData[j].CALLTYPE==6205){
                            callObj.CallType = "微话好友呼入";
                        }
                        else if(callLogData[j].CALLTYPE==6204){
                            callObj.CallType = "呼叫微话好友";
                        }
                        else
                        {
                            callObj.CallType = "新类型";
                        }
                        
                        callObj.CallLen = callLogData[j].SECONDS+"秒";
                        callObj.CallTime = XLY.Convert.LinuxToDateTime(callLogData[j].TICK);
                        clNode.Items.push(callObj);
                    }
                    callNode.TreeNodes.push(clNode);
                }
            }
            root.TreeNodes.push(callNode);
        }
    }
}