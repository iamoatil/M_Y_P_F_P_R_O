﻿/*[config]
<plugin name="Viber,18" group="社交聊天,8,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="/icons/viber.png" app="com.viber.voip" version="6.5.3" description="viber" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.viber.voip/databases#F</value>
    <value>/data/data/com.viber.voip/shared_prefs/com.viber.voip.ViberPrefs.xml</value>
</source>

<data type="User">

    <item name="用户昵称" code="Nick" type="string" width="120" format = ""></item>
    <item name="电话号码" code="Phone" type="string" width="120" format = ""></item>
    <item name="用户ID" code="UID" type="string" width="120" format=""></item>
    <item name="登录时间" code="Time" type="datetime" width="140" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="头像文件" code="Avatar" type="string" width="300" format= "" show = "" ></item>
</data>
<data type = "Contact" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="ID" type="string" width="120" format=""></item>
    <item name="用户昵称" code="Name" type="string" width="120" format = ""></item>
    <item name="电话号码" code="Phone" type="string" width="120" format=""></item>
    <item name="创建时间" code="Time" type="datetime" width="140" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="收藏状态" code="Stared" type="string" width="120" format = ""></item>
    <item name="Viber好友" code="Viber" type="string" width="120" format=""></item>
</data>

<data type = "Public" contract = "DataState" detailfield="Member">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="ID" type="string" width="120" format=""></item>
    <item name="用户昵称" code="Name" type="string" width="120" format = ""></item>
    <item name="位置" code="Location" type="string" width="120" format = ""></item>
    <item name="国家" code="Country" type="string" width="120" format = ""></item>
    <item name="关注人数" code="Watcher" type="string" width="120" format = ""></item>
    <item name="部分关注人" code="Member" type="string" width="120" format = ""></item>
    <item name="相关信息" code="About" type="string" width="120" format=""></item>
</data>

<data type = "pMember" contract = "DataState" detailfield="Member">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户帐号" code="ID" type="string" width="120" format=""></item>
    <item name="用户昵称" code="Name" type="string" width="120" format = ""></item>
    <item name="用户头像" code="Avatar" type="string" width="300" format = ""></item>
</data>

<data detailfield="Content" type="Message" datefilter="StartDate" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="消息发送者" code="SenderName" type="string" width="" alignment="center" ></item>
<item name="消息接收者" code="Number" type="string" width="120" ></item>
<item name="内容" code="Content" type="string" width="400" ></item>
<item name="消息发送时间" code="Date" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="类型" code="Type" type="string" format="" width = "100" ></item>
<item name="发送状态" code="SendState" type="string" width="80" show= "false"></item>
</data>


</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function User() {
    this.Nick = ""; //用户昵称
    this.Phone = "";    //电话号码
    this.UID = "";    //国家代码
    this.Time = null;   //登录时间
    this.Avatar = "";    //头像文件
}

function Contact() {
    this.DataState = "Normal";  //数据状态
    this.ID = "";   //用户ID
    this.Name = ""; //用户昵称
    this.Phone = "";    //电话号码
    this.Time = null;   //创建时间
    this.Stared = "";   //收藏状态
    this.Viber = "";    //Viber好友
}



function Public() {
    this.DataState = "Normal";  //数据状态
    this.ID = "";   //用户ID
    this.Name = ""; //用户昵称
    this.Location = ""; //位置
    this.Watcher = "";  //关注人数
    this.About = "";    //相关信息
    this.Country = "";
    this.Member = "";
}


//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dpath = source[0];
var spath = source[1];
//测试数据
//var dpath = "J:\\APP_script\\test\\com.viber.voip\\databases";
//var spath = "J:\\APP_script\\test\\com.viber.voip\\shared_prefs\\com.viber.voip.ViberPrefs.xml";

//定义特征库文件
var cch = "chalib\\Android_Viber_V6.5.3\\viber_data.charactor";
var mch = "chalib\\Android_Viber_V6.5.3\\viber_messages.charactor";

//恢复数据库中删除的数据
//var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
result.push(buildNode());
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var viber = new TreeNode();
    viber.Text = "Viber";
    
    var cpath = dpath+"\\viber_data";
    var mpath = dpath+"\\viber_messages";
    
    
    if(XLY.File.IsValid(cpath)&&XLY.File.IsValid(mpath)){
        
        var reccpath = XLY.Sqlite.DataRecovery(cpath,cch ,"phonebookcontact,phonebookdata,vibernumbers");
        var recmpath = XLY.Sqlite.DataRecovery(mpath,mch,"messages,conversations,participants,participants_info,public_accounts");
        var uinfo = getUserInfo(spath,recmpath);
        var user = new TreeNode();
        user.Text = uinfo.Nick;
        //user.Text = "用户信息";
        user.Type = "User";
        
        user.Items.push(uinfo);
        
        //读取好友信息并创建子节点
        var contact = buildContactNode(reccpath,recmpath,user);
        
        //读取聊天内容并创建子节点
        buildMessageNode(recmpath,user,contact,uinfo);
        
        
        viber.TreeNodes.push(user);
    }
    return viber;
}


//获取用户信息
function getUserInfo(spath,mpath){
    var uobj = new User();
    if(XLY.File.IsValid(spath)){
        var data = eval('('+ XLY.File.ReadXML(spath) +')');
        var uinfo = data.map.string;
        var dateinfo = data.map.long;
        if(uinfo.length>1){
            for(var i in uinfo){
                if(uinfo[i]['@name']=="display_name"){
                    uobj.Nick = uinfo[i]['#text'];
                    //log(uinfo[i]);
                }
                if(uinfo[i]['@name']=="image_uri"){
                    uobj.Avatar = uinfo[i]['#text'];
                }
                
            }
        }
        if(dateinfo.length>1){
            for(var num in dateinfo){
                if(dateinfo[num]['@name']=="last_wear_info_check"){
                    uobj.Time = XLY.Convert.LinuxToDateTime(dateinfo[num]['@value']);
                }
            }
        }
    }
    //var ccpath = fpath+"\\reg_viber_country_code";
    //var pfpath = fpath +"\\reg_viber_phone_num";
    //log(uobj);
    var con = getFileInfoforUer(mpath,uobj);
    uobj.Phone = con.Phone;
    uobj.UID = con.UID;
    return uobj;
}


function getFileInfoforUer(path,uinfo){
    if(XLY.File.IsValid(path)){
        var info = {};
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from participants_info where participant_type=0 AND XLY_DataType=2 ") +')');
        if(data.length>0&&data!= null){
            info.Phone = data[0].number;
            info.UID = data[0].member_id;
            //for(var i in data){
            //    if(data[i].display_name==uinfo.Nick){
            //        uinfo.Phone = data[i].number;
            //        uinfo.UID = data[i].member_id;
            //    }
            //}
        }
        return info;
    }
}


//创建好友信息信息节点
function buildContactNode(reccpath,recmpath,node){
    var contact = new TreeNode();
    contact.Text = "联系人";
    if(XLY.File.IsValid(reccpath)){
        var fri = new TreeNode();
        fri.Text = "好友";
        fri.Type = "Contact";
        var cdata = eval('('+ XLY.Sqlite.Find(reccpath,"select * from phonebookcontact") +')');
        if(cdata.length>0&&cdata!=null){
            for(var i in cdata){
                var cobj = new Contact();
                //log(cdata[i]);
                cobj.Name = cdata[i].display_name;
                cobj.DataState = XLY.Convert.ToDataState(cdata[i].XLY_DataType);
                cobj.Time = XLY.Convert.LinuxToDateTime(cdata[i].joined_date);
                var cpinfo = eval('('+ XLY.Sqlite.Find(reccpath,"select distinct data2 from phonebookdata where contact_id = '"+cdata[i].xly_id+"' ") +')');
                if(cpinfo.length>0&&cpinfo!=null){
                    cobj.Phone = cpinfo[0].data2;
                }
                cobj.Viber = "该用户非Viber好友";
                if(cdata[i].viber==1){
                    cobj.Viber = "该用户为Viber好友";
                    if(cobj.Phone.length>0&&cobj.Phone!=null){
                        var idinfo = eval('('+ XLY.Sqlite.Find(reccpath,"select * from vibernumbers where canonized_number = '"+cobj.Phone+"'")+')');
                        if(idinfo.length>0&&idinfo!=null){
                            cobj.ID = idinfo[0].viber_id;
                        }
                    }
                }
                (cdata[i].starred==1)?cobj.Stared="已收藏":cobj.Stared = "未收藏";
                fri.Items.push(cobj);
            }
        }
        contact.TreeNodes.push(fri);
    }
    
    if(XLY.File.IsValid(recmpath)){
        var public = new TreeNode();
        public.Text = "公众号";
        public.Type = "Public";
        var pdata = eval('('+ XLY.Sqlite.Find(recmpath,"select *,cast(group_id as char)as gd from public_accounts")+')');
        if(pdata.length>0&&pdata!=null){
            for(var i in pdata){
                var pobj = new Public();
                pobj.DataState = XLY.Convert.ToDataState(pdata[i].XLY_DataType);
                pobj.ID = pdata[i].public_account_id;
                //pobj.Name = pdata[i].group_uri;
                pobj.Location = pdata[i].location_address;
                pobj.Watcher = pdata[i].watchers_count;
                pobj.About = pdata[i].tag_line;
                pobj.Country = pdata[i].country;
                
                //获取公众号的部分成员
                //getPublicMemberInfo(recmpath,pdata[i].gd,pobj);
                if(pdata[i].XLY_DataType==2){
                    var subnode = new TreeNode();
                    subnode.Text = pdata[i].group_id+"_"+pdata[i].group_uri;
                    subnode.Type = "pMember";
                    subnode.Items = getPublicMemberInfo(recmpath,pdata[i].gd);
                    public.TreeNodes.push(subnode);
                }
                
                public.Items.push(pobj);
            }
        }
        contact.TreeNodes.push(public);
    }
    node.TreeNodes.push(contact);
    return contact;
}


//获取公众号关注着信息
function getPublicMemberInfo(path,id){
    var meminfo = eval('('+ XLY.Sqlite.Find(path,"select * from conversations where group_id = '"+id+"' ")+')');
    var memberArr = new Array();
    if(meminfo.length&&meminfo!=null){
        //pinfo.Name = meminfo[0].name;
        var memid = eval('('+ XLY.Sqlite.Find(path,"select * from participants where conversation_id = '"+meminfo[0].xly_id+"'") +')');
        if(memid.length>0&&meminfo!= null){

            for(var i in memid){

                var mem = eval('('+ XLY.Sqlite.Find(path,"select * from participants_info where _id = '"+memid[i].participant_info_id+"'") +')');

                var mobj = new pMember();
                if(mem[0].display_name.length>0&&mem[0].display_name!=null){
                    
                    mobj.ID = mem[0].number;
                    mobj.Name = mem[0].display_name; //用户昵称
                    mobj.Avatar = mem[0].viber_image;   //用户头像
                    
                }
                else
                {
                    mobj.Name = mem[0].encrypted_number;
                }
                memberArr.push(mobj);
            }
        }
    }
    return memberArr;
}


//创建聊天消息子节点
function buildMessageNode(mpath,node,contact,userinfo){
    var cmsg = new TreeNode();
    cmsg.Text = "好友聊天消息";
    var cminfo = eval('('+ XLY.Sqlite.Find(mpath,"select distinct address from messages where conversation_type=0") +')');
    if(cminfo.length>0&&cminfo!=null){
        for(var i in cminfo){
            var subnode = new TreeNode();
            subnode.Text = getName(mpath,cminfo[i].address);
            if((/^pa:/).test(cminfo[i].address)){
                subnode.Text += "("+cminfo[i].address+")";
            }
            //log(subnode.Text);
            subnode.Type = "Message";
            var cmdata = eval('('+ XLY.Sqlite.Find(mpath,"select * from messages where address = '"+cminfo[i].address+"' ") +')');
            subnode.Items = getMessageInfo(cmdata,userinfo.Nick,mpath);
            
            
            cmsg.TreeNodes.push(subnode);
        }
    }
    
    var gmsg = new TreeNode();
    gmsg.Text = "公众号聊天消息";
    var gminfo = eval('('+ XLY.Sqlite.Find(mpath,"select distinct cast(group_id as char)as gid from messages where conversation_type = 2") +')');
    if(gminfo.length>0&&gminfo!=null){
        for(var i in gminfo){
            var subnode = new TreeNode();
            subnode.Text = gminfo[i].gid+"_"+getGroupName(mpath,gminfo[i].gid);
            subnode.Type = "Message";
            var gmdata = eval('('+ XLY.Sqlite.Find(mpath,"select * from messages where group_id = '"+gminfo[i].gid+"' ") +')');
            //var msger = getName(contact,gmdata[num].address,1);
            subnode.Items = getMessageInfo(gmdata,userinfo.Nick,mpath);
            gmsg.TreeNodes.push(subnode);
        }
    }
    node.TreeNodes.push(cmsg);
    node.TreeNodes.push(gmsg);
}


function getGroupName(path,gid){
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from public_accounts where group_id = '"+gid+"'") +')');
    if(data.length>0&&data!= null){
        return data[0].group_uri;
    }
    else
    {
        return "";
    }
}


function getName(path,id){
    var data = eval('('+ XLY.Sqlite.Find(path,"select display_name from participants_info where member_id = '"+id+"'") +')');

    if(data.length>0&&data!= null){
        return data[0].display_name;
    }
    else
    {
        return id;
    }
    
}


function getMessageInfo(data,user,path){
    var arr = new Array();
    if(data.length>0&&data!= null){
        for(var i in data){
            var mobj = new Message();
            mobj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);  //数据状态
            if(data[i].type==1){
                mobj.SendState = "发送";
                mobj.SenderName = user;
                mobj.Number = getName(path,data[i].address);
            }
            else
            {
                mobj.SendState = "接收";
                mobj.SenderName = getName(path,data[i].address);
                mobj.Number = user;
            }
            mobj.Date = XLY.Convert.LinuxToDateTime(data[i].date);  //消息发送时间
            mobj.Content = data[i].body;
            getMsgTypeInfo(data[i],mobj);
            arr.push(mobj);
        }
    }
    return arr;
}


function getMsgTypeInfo(data,mobj){
    if(data.extra_mime!=null){
        if(data.extra_mime=="text"){
            mobj.Type = "文本";
        }
        if(data.extra_mime=="file"){
            mobj.Type = "文件";
            var fileinfo = eval('('+ data.msg_info +')');
            //log(fileinfo.fileInfo.FileName);
            mobj.Content = "文件存储路径:"+data.extra_uri+";文件名:"+fileinfo.fileInfo.FileName+";文件大小:"+fileinfo.fileInfo.FileSize;
        }
        if(data.extra_mime=="image"){
            mobj.Type = "图片";
            if(data.extra_duration!=0){
                mobj.Content = "图片缩略图路径:"+data.body+";图片原图路径:"+data.extra_uri+";图片大小:"+data.extra_duration;
            }
            else
            {
                mobj.Content = "图片URL地址为:"+data.body;
            }
        }
        if(data.extra_mime=="notif"){
            mobj.Type = "系统消息";
        }
        if(data.extra_mime=="share_contact"){
            mobj.Type = "共享联系人";
            var cinfo = eval('('+ data.msg_info +')');
            mobj.Content = "联系人姓名:"+cinfo.Name+";联系人电话:"+cinfo.PhoneNumber+";联系人Viber号码:"+cinfo.ViberNumber;
        }
        if(data.extra_mime=="sticker"){
            mobj.Type = "表情标签";
        }
        if(data.extra_mime=="video"){
            mobj.Type = "视频";
            var vinfo = eval('('+ data.msg_info +')');
            mobj.Content = "视频文件路径:"+data.extra_uri+";视频文件大小:"+vinfo.fileInfo.FileSize+";视频文件时长:"+vinfo.fileInfo.Duration;
        }
        if(data.extra_mime=="file_gif"){
            mobj.Type = "GIF动图";
            var ginfo = eval('('+ data.msg_info +')');
            mobj.Content = "GIF动图URL地址:"+data.extra_uri+";GIF动图名:"+ginfo.fileInfo.FileName+";GIF动图大小:"+ginfo.fileInfo.FileSize;
        }
        if(data.extra_mime=="sound"){
            mobj.Type = "音频文件";
            mobj.Content = "音频文件时长:"+data.extra_duration;
        }
        if(data.extra_mime=="url_message"){
            mobj.Type = "URL链接";
            var urlinfo = eval('('+ data.msg_info +')');
            mobj.Content = "URL信息说明:"+urlinfo.Title+";URL地址:"+urlinfo.URL+";URL链接内容长度:"+urlinfo.ContentLength;
        }
        if(data.extra_mime=="call"){
            mobj.Type = "通话";
            if(data.body=="outgoing_call"){
                mobj.Content = "拨出通话";
            }
            if(data.body=="missed_call"){
                mobj.Content = "未接电话";
            }
            if(data.body=="vo"){
                mobj.Content = "viber通话";
            }
            if(data.body=="incoming_call"){
                mobj.Content = "拨入通话";
            }
            mobj.Content+= ";通话时长为:"+data.extra_duration;
        }
        if(data.extra_mime=="empty"){
            mobj.Type = "unknown";
        }
    }
}


function pMember() {
    this.DataState = "Normal";  //数据状态
    this.ID = "";   //用户帐号
    this.Name = ""; //用户昵称
    this.Avatar = "";   //用户头像
    this.MDFString = "";    //MD5
}



function Message() {
    this.DataState = "Normal";  //数据状态
    this.SenderName = "";   //消息发送者
    this.Number = "";   //消息接收者
    this.Content = "";  //内容
    this.Date = null;   //消息发送时间
    this.Type = ""; //类型
    this.SendState = "";    //发送状态
    this.MDFString = "";    //MD5
}