﻿/*[config]
<plugin name="大众点评,2" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/DianPing.png" app="com.dianping.v1" version="6.5" description="大众点评" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.dianping.v1/shared_prefs/com.dianping.v1.xml</value>
<value>/data/data/com.dianping.v1/databases/dianping.db</value>
<value>/data/data/com.dianping.v1/databases/suggestions.db</value>
</source>
<data type="Shop" contract="DataState">  
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="商铺编号" code="shopId" type="string" width="80"></item>
</data>
<data type="LoginCity" contract="Map"> 
<item name="城市" code="cityName" type="string" width="100" ></item>
<item name="行政代码" code="cityCode" type="string" width="100"></item>
<item name="坐标" code="Desc" type="string" width="300" ></item>
<item name="经度" code="Longitude" type="double" format="F6" width="" show="false"></item>
<item name="维度" code="Latitude" type="double" format="F4"  width="" show="false"></item>
<item name="时间" code="Date" type="datetime" width="" show="false"></item>
</data>
<data type="Search" contract="DataState" datefilter="searchtime" > 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="搜索记录" code="search" type="string" width="100" ></item>
<item name="搜索时间" code="searchtime" type="datetime" width="100" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Shop() {
	this.shopId = "";
	this.DataState = "Normal";  
}

function LoginCity() {
	this.cityName = "";
	this.cityCode = "";
	this.Desc = "";
	this.Longitude = "";
	this.Latitude = "";
	this.Date = "";
}
function Search() {
	this.search = "";
	this.searchtime = "";
	this.DataState = "Normal";  
}

//树形结构
function TreeNode() {
	this.Text = ""; 
	this.TreeNodes = new Array(); 
	this.Items = new Array(); 
	this.Type = ""; 
	this.DataState = "Normal";  
}

//店铺信息
function shopNodeCreate(path) {
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from shop") + ')');
		var arr = new Array();
		for (var index in data) {
			if(data[index].ShopID/1000000 >=1&&data[index].ShopID/100000000<=1){
				var obj = new Shop();
				obj.shopId = data[index].ShopID;     
				obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
				arr.push(obj)
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//位置信息
function locationNodeCreate(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.File.ReadXML(path) + ')');
		var obj = new LoginCity();
		for (var index in data.map.string) {
			if (data.map.string[index]["@name"] == "cityName") {
				obj.cityName = data.map.string[index]["#text"];
			}
			if (data.map.string[index]["@name"] == "cityAreaCode") {
				obj.cityCode = data.map.string[index]["#text"];
			}
		}
		for (var index in data.map.float) {
			if (data.map.float[index]["@name"] == "longitude") {
				obj.Desc = data.map.float[index]["@value"];
				obj.Longitude = data.map.float[index]["@value"];

			}
			if (data.map.float[index]["@name"] == "latitude") {
				obj.Desc = "经度： " + obj.Desc + "    " + "纬度： " + data.map.float[index]["@value"];
				obj.Latitude = data.map.float[index]["@value"];
			}
		}
		arr.push(obj);
		return arr;
	}
	catch(e){
		return arr;
	}
}

//历史搜索记录
function searchNodeCreate(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from suggestions order by date desc") + ')');
		for (var index in data) {
			if (data[index]["display1"] != "清空搜索记录") {
				var obj = new Search();
				obj.search = data[index]["display1"];
				obj.searchtime = data[index]["date"];
				obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
				obj.searchtime = XLY.Convert.LinuxToDateTime(obj.searchtime);
				arr.push(obj);
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0];
var path2 = source[1];
var path3 = source[2];

//数据恢复库的生成
var charactor1="chalib\\Android_DaZhong_V6.5\\mainDB.db.charactor";
var charactor2="chalib\\Android_DaZhong_V6.5\\mainDB.db.charactor";
path2=XLY.Sqlite.DataRecovery( path2,charactor1 ,"shop");
path3=XLY.Sqlite.DataRecovery( path3,charactor2 ,"suggestions");

//以下为节点的实例化
var shopNode = new TreeNode();
shopNode.Text = "商铺"
shopNode.Type = "Shop";
var locationNode = new TreeNode();
locationNode.Text = "位置记录"
locationNode.Type = "LoginCity";
var searchNode = new TreeNode();
searchNode.Text = "搜索记录";
searchNode.Type = "Search";

//以下为节点的数据填充
shopNode.Items = shopNodeCreate(path2);
locationNode.Items = locationNodeCreate(path1);
searchNode.Items = searchNodeCreate(path3);

//打印数据
result.push(shopNode);
result.push(locationNode);
result.push(searchNode);
var res = JSON.stringify(result);
res;
