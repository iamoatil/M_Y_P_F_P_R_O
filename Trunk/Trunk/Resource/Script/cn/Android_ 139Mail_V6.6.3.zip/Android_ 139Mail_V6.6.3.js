﻿/*[config]
<plugin name="139邮箱,3" group="主流邮箱,4" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/139mail.png" app="cn.cj.pe" version="6.6.3" description="139邮箱" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/cn.cj.pe/shared_prefs#F</value>
    <value>/data/data/cn.cj.pe/databases#F</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="邮箱账号" code="Mail" type="string" width="120" format=""></item>
    <item name="通行证账号" code="AccountNumber" type="string" width="120" format = ""></item>
    <item name="别名账号" code="Alias" type="string" width="120" format=""></item>
    <item name="姓名" code="Name" type="string" width="120" format=""></item>
    <item name="邮箱签名" code="DescriptionEmail" type="string" width="120" format=""></item>
</data>
<data type="List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="Entry" type="string" width="120" format=""></item>
</data>
<data type="ActivityArrangement" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width="120" format=""></item>
    <item name="标题" code="Title" type="string" width="120" format=""></item>
    <item name="标签名称" code="LabelName" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="开始时间" code="DtStart"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="结束时间" code="DtEnd"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发件人" code="Sender" type="string" width="120" format=""></item>
    <item name="收件人" code="Receiver" type="string" width="120" format=""></item>
    <item name="抄送" code="Copy" type="string" width="120" format=""></item>
    <item name="密送" code="BCC" type="string" width="120" format=""></item>
    <item name="主题" code="Title" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="附件" code="Add" type="string" width="120" format=""></item>
    <item name="附件路径" code="AddPath" type="string" width="120" format=""></item>
    <item name="发送时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="状态" code="Status" type="string" width="120" format=""></item>
    <item name="是否为星标邮件" code="StarEmail" type="string" width="120" format=""></item>
    <item name="是否为移动账单" code="MobileBill" type="string" width="120" format=""></item>
</data>
<data type="Contact" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="120" format=""></item>
    <item name="邮箱地址" code="Email" type="string" width="120" format=""></item>
    <item name="电话号码" code="Phone" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.Mail = "";
    this.AccountNumber = "";
    this.Alias = "";
    this.Name = "";
    this.DescriptionEmail = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.Name = "";
    this.Email = "";
    this.Phone = "";
}
//定义List数据结构
function List(){
    this.DataState = "Normal";
    this.Entry = "";
}
//定义ActivityArrangement数据结构
function ActivityArrangement(){
    this.DataState = "Normal";
    this.UserId = "";
    this.Title = "";
    this.Content = "";
    this.DtStart = null;
    this.DtEnd = null;
    this.LabelName = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Copy = "";
    this.BCC = "";
    this.Title = "";
    this.Content = "";
    this.Add = "";
    this.AddPath = "";
    this.Time = null;
    this.Status = "";
    this.StarEmail = "";
    this.MobileBill = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userpathX = source[0]+"\\xrm_data.xml";
var userpathD1 = source[1]+"\\preferences_storage";
var basePath = source[1];
var contactPath1 = source[1]+"\\contact2db";
var activityArrangementPth1 = source[1]+"\\calendarsdk.db";
//测试数据
//var userpathX = "D:\\temp4\\data\\data\\cn.cj.pe\\shared_prefs\\xrm_data.xml";
//var userpathD1 = "D:\\temp4\\data\\data\\cn.cj.pe\\databases\\preferences_storage";
//var basePath = "D:\\temp4\\data\\data\\cn.cj.pe\\databases";
//var contactPath1 = "D:\\temp4\\data\\data\\cn.cj.pe\\databases\\contact2db";
//var activityArrangementPth1 = "D:\\temp4\\data\\data\\cn.cj.pe\\databases\\calendarsdk.db";
//
//定义特征库文件
//var userpathDcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var userDbPathcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_ 139Mail_V6.6.3\\123124.charactor";
//var activityArrangementPthcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";
var userDbPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\123124.charactor";
var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
var userpathD = XLY.Sqlite.DataRecovery(userpathD1,userpathDcharactor,"preferences_storage");
var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "139邮箱";
    root.Type = "List";
    //root.Items = getNews(userpathX,userpathD,root);
    root.Items = getList(userpathX,userpathD,root);
    
    
    var contactNode = new TreeNode();
    contactNode.Text = "通讯录";
    contactNode.Type = "Contact";
    contactNode.Items = getContactInfo(contactPath);
    
    root.TreeNodes.push(contactNode);
    result.push(root);
}

//获取列表
function getList(path,userpathD,root){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.File.ReadXML(path) +')').map.string;
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new List();
                obj.Entry = data[i]["@name"];
                
                var node = new TreeNode();
                node.Text = obj.Entry;
                node.Type = "News";
                node.Items = getNews(userpathD,obj.Entry,node,activityArrangementPth);
                root.TreeNodes.push(node);
                arr.push(obj);
            }
        }
        return arr;
    }
}

//获取用户信息
function getNews(path,info,root,activityArrangementPth){
    if(info!=""&&info!=null){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from preferences_storage where value = '"+info+"'") +')')[0].primkey.substr(0,36);
        var dataD = eval('('+ XLY.Sqlite.Find(path,"select * from preferences_storage where primkey like '"+data+"%"+"'") +')');
        var obj = new News();
        //obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        if(dataD!=""&&dataD!=null){
            for(var j in dataD){
                if(dataD[j].primkey==(data+"imap.passPort")){
                    obj.AccountNumber = dataD[j].value+"@139.com";
                }
                if(dataD[j].primkey==(data+"imap.alias")){
                    obj.Alias = dataD[j].value;
                }
                if(dataD[j].primkey==(data+"imap.description")){
                    obj.DescriptionEmail = dataD[j].value;
                }
                if(dataD[j].primkey==(data+"imap.email.0")){
                    obj.Mail = dataD[j].value;
                }
                if(dataD[j].primkey==(data+"imap.accountNameFromWeb")){
                    obj.Name = dataD[j].value;
                }
            }
        }
        arr.push(obj);
        
        getUserNode(root,activityArrangementPth,obj.Mail,data);
        return arr; 
    }   
}

//创建用户下的节点，通讯录，收件箱，发件箱，移动账单，草稿箱，垃圾箱，我的文档，待办任务，活动安排
function getUserNode(root,activityArrangementPth,info,temp){
    var userDbPath = XLY.Sqlite.DataRecovery(basePath+"\\"+temp+"imap.db",userDbPathcharactor,"folders,attachments,messages");
    getEmailMessageInfo(userDbPath,root);
    getActivityArrangementInfo(activityArrangementPth,info.split("@")[0],root);
    
    return;
}
//获取活动安排（日历提醒）
function getActivityArrangementInfo(path,info,root){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(path,"select * from VEvent where user_id = '"+info+"'") +')');
        if(data!=""&&data!= null){
            var activityArrangementNode = new TreeNode();
            activityArrangementNode.Text = "活动安排";
            activityArrangementNode.Type = "ActivityArrangement";
            //activityArrangementNode.Items = getActivityArrangementInfo(activityArrangementPth,info.split("@")[0]);
            for(var i in data){
                var obj = new ActivityArrangement();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.UserId = data[i].user_id;
                obj.Title = data[i].title;
                obj.Content = data[i].content;
                obj.DtStart = XLY.Convert.LinuxToDateTime(data[i].dtstart);
                obj.DtEnd = XLY.Convert.LinuxToDateTime(data[i].dtend);
                if(data[i].label_id==10){
                    obj.LabelName = "我的日历";
                }
                if(data[i].label_id==-10){
                    obj.LabelName = "日历提醒";
                }
                if(data[i].label_id==-5){
                    obj.LabelName = "待办日历";
                }
                arr.push(obj);
            }
            activityArrangementNode.Items = arr;
            root.TreeNodes.push(activityArrangementNode);
        }
        return;
    }
}

//获取邮件信息
function getEmailMessageInfo(path,root){
    if(XLY.File.IsValid(path)){
        var arr = new Array();
        var dataFolder = eval('('+ XLY.Sqlite.Find(path,"select * from folders") +')');
        if(dataFolder!=""&&dataFolder!=null){
            for(var i in dataFolder){
                var obj = new List();
                if(dataFolder[i].id==1){
                    var dataMessage = eval('('+ XLY.Sqlite.Find(path,"select * from messages where folder_id = '"+dataFolder[i].id+"'") +')');
                    if(dataMessage!=""&&dataMessage!=null){
                        var node = new TreeNode();
                        node.Text = "收件箱";
                        node.Type = "Message";
                        node.Items = getMessageInfo(path,dataMessage);
                        root.TreeNodes.push(node);
                    }
                }
                if(dataFolder[i].id==2){
                    var dataMessage = eval('('+ XLY.Sqlite.Find(path,"select * from messages where folder_id = '"+dataFolder[i].id+"'") +')');
                    if(dataMessage!=""&&dataMessage!=null){
                        var node = new TreeNode();
                        node.Text = "已删除";
                        node.Type = "Message";
                        node.Items = getMessageInfo(path,dataMessage);
                        root.TreeNodes.push(node);
                    }
                }
                if(dataFolder[i].id==3){
                    var dataMessage = eval('('+ XLY.Sqlite.Find(path,"select * from messages where folder_id = '"+dataFolder[i].id+"'") +')');
                    if(dataMessage!=""&&dataMessage!=null){
                        var node = new TreeNode();
                        node.Text = "草稿箱";
                        node.Type = "Message";
                        node.Items = getMessageInfo(path,dataMessage);
                        root.TreeNodes.push(node);
                    }
                }
                if(dataFolder[i].id==4){
                    var dataMessage = eval('('+ XLY.Sqlite.Find(path,"select * from messages where folder_id = '"+dataFolder[i].id+"'") +')');
                    if(dataMessage!=""&&dataMessage!=null){
                        var node = new TreeNode();
                        node.Text = "垃圾箱";
                        node.Type = "Message";
                        node.Items = getMessageInfo(path,dataMessage);
                        root.TreeNodes.push(node);
                    }
                }
                if(dataFolder[i].id==6){
                    var dataMessage = eval('('+ XLY.Sqlite.Find(path,"select * from messages where folder_id = '"+dataFolder[i].id+"' or folder_id = '5'") +')');
                    if(dataMessage!=""&&dataMessage!=null){
                        var node = new TreeNode();
                        node.Text = "发件箱";
                        node.Type = "Message";
                        node.Items = getMessageInfo(path,dataMessage);
                        root.TreeNodes.push(node);
                    }
                }
                obj.Entry = node.Text;
                arr.push(obj);
            }
        }
        return arr;
    }
}
//获取收件箱信息
function getMessageInfo(path,info){
    if(info!=""&&info!=null){
        var arr = new Array();
        for(var i in info){
            if(info[i].sender_list!=""&&info[i].sender_list!=null){
                var obj = new Message();
                var data = eval('('+ XLY.Sqlite.Find(path,"select * from attachments where message_id = '"+info[i].id+"'") +')');
                obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
                obj.Sender = info[i].sender_list;
                obj.Receiver = info[i].to_list;
                obj.Copy = info[i].cc_list;
                obj.BCC = info[i].bcc_list;
                obj.Title = info[i].subject;
                obj.Content = "html_content:"+info[i].hteml_content+"\r"+"text_content:"+info[i].text_content+"preview:"+info[i].preview;
                if(data!=""&&data!= null){
                    for(var j in data){
                        if(data[j].name!=null&&data[j].name!=""){
                            obj.Add+= data[j].name+" ";
                        }
                        if(data[j].content_url!=null&&data[j].content_url!=""){
                            obj.AddPath+= data[j].content_url+" ";
                        }
                    }
                }
                obj.Time = XLY.Convert.LinuxToDateTime(info[i].internal_date);
                if(info[i].read==1){
                    obj.Status = "已读";
                }
                else
                {
                    obj.Status = "未读";
                }
                if(info[i].flagged==1){
                    obj.StarEmail = "是";
                }
                else
                {
                    obj.StarEmail = "否";
                }
                if(info[i].isbill==1){
                    obj.MobileBill = "是";
                }
                else
                {
                    obj.MobileBill = "否";
                }
                arr.push(obj);
            }
        }
        return arr;
    }
}

//获取通讯录信息
function getContactInfo(path){
    if(XLY.File.IsValid(path)){
        var arr = new  Array();
        var dataRaw = eval('('+ XLY.Sqlite.Find(path,"select cast(sys_contact_id as text) as sys_contact_id,cast(name as text) as name from contacts_raw") +')');
        if(dataRaw!=""&&dataRaw!=null){
            for(var i in dataRaw){
                var data = eval('('+ XLY.Sqlite.Find(path,"select cast(sys_contact_id as text) as sys_contact_id from contacts_data where sys_contact_id = '"+dataRaw[i].sys_contact_id+"'") +')');
                var obj = new Contact();
                if(data!=""&&data!=null){
                    for(var j in data){
                        obj.DataState = XLY.Convert.ToDataState(data[j].XLY_DataType);
                        //var aa = eval('('+ XLY.Sqlite.Find(path,"select * from contacts_raw where sys_contact_id = '"+data[j].sys_contact_id+"'") +')');
                        var bb = eval('('+ XLY.Sqlite.Find(path,"select cast(type as text) as type,cast(logic_type as text) as logic_type,cast(data as text) as data from contacts_data where sys_contact_id = '"+data[j].sys_contact_id+"'") +')');
                        obj.Name = dataRaw[i].name;
                        if(bb!=""&&bb!=null){
                            for(var m in bb){
                                if(bb[m].logic_type==3&&bb[m].type=="phone"){
                                    obj.Phone = bb[m].data;
                                }
                                if(bb[m].logic_type==3&&bb[m].type=="email"){
                                    obj.Email = bb[m].data;
                                }
                                if((bb[m].logic_type==""||bb[m].logic_type==null)&&bb[m].type=="email"){
                                    obj.Email = bb[m].data;
                                }
                                if((bb[m].logic_type==""||bb[m].logic_type==null)&&bb[m].type=="phone"){
                                    obj.Phone = bb[m].data;
                                }
                            }
                        }
                    }
                }
                arr.push(obj);
            }
        }
        return arr;
    }
}