﻿/*[config]
<plugin name="百度云盘,9" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="icons/baidunetdisk.png" app="com.baidu.netdisk" version="7.11.4" description="百度云盘" data="$data,ComplexTreeDataSource"  >
    <source>
        <value>/data/data/com.baidu.netdisk/databases/#F</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
        <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="账户名称" code="Name" type="string" width="180" format = ""></item>
        <item name="昵称" code="NickName" type="string" width="180" format = ""></item>
        <item name="账户ID" code="ID" type="string" width="180" format = ""></item>
        <item name="邮箱" code="Email" type="string" width="180" format = ""></item>
        <item name="头像" code="Icon" type="string" width="180" format = ""></item>
        <item name="电话" code="Phone" type="string" width="180" format = ""></item> 
    </data>
    <data type="Image" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
        <item name="图片名" code="Name" type="string" width="120" format = ""></item>
        <item name="拍摄所在城市" code="City" type="string" width="260" format = ""></item>
        <item name="拍摄所在国家" code="Country" type="string" width="400" format = ""></item>
        <item name="拍摄所在地区" code="District" type="string" width="120" format = ""></item>
        <item name="拍摄所在省" code="Province" type="string" width="120" format = ""></item>
        <item name="拍摄所在街道" code="Street" type="string" width="120" format = ""></item>
        <item name="拍摄所在纬度" code="Latitude" type="string" width="260" format = ""></item>
        <item name="拍摄所在经度" code="Longitude" type="string" width="400" format = ""></item>
        <item name="拍摄时间" code="TakeTime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="文件路径" code="Path" type="string" width="400" format = ""></item>
        <item name="文件MD5" code="MD5" type="string" width="120" format = ""></item>
        <item name="上传时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="大小" code="Size" type="string" width="400" format = ""></item>
        <item name="文件ID" code="Id" type="string" width="400" format = ""></item>
    </data>
        <data type="Blacklist" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="ID" code="UK" type="string" width="260" format = ""></item>
        <item name="姓名" code="Name" type="string" width="260" format = ""></item>
        <item name="图标" code="Icon" type="string" width="260" format = ""></item>
        </data>
     <data type="Contact" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="姓名" code="Name" type="string" width="260" format = ""></item>
        <item name="ID" code="Id" type="string" width="260" format = ""></item>
        <item name="电话" code="Phone" type="string" width="260" format = ""></item>
        <item name="百度用户" code="Baidu" type="string" width="400" format = ""></item>
        <item name="百度云用户" code="Yun" type="string" width="120" format = ""></item>
        <item name="头像" code="Icon" type="string" width="260" format = ""></item> 
    </data>
        <data type="People" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="ID" code="UK" type="string" width="260" format = ""></item>
        <item name="姓名" code="Name" type="string" width="260" format = ""></item>
        <item name="图标" code="Icon" type="string" width="260" format = ""></item>
        </data>
    <data type="Group" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
        <item name="群ID" code="Id" type="string"  width="260" format = ""></item>
        <item name="群成员" code="Mem" type="string" width="260" format = ""></item>
        <item name="群名" code="Name" type="string" width="260" format = ""></item>
        <item name="人数上限" code="Limit" type="string" width="260" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="头像" code="Icon" type="string" width="260" format = ""></item>  
    </data>
    <data type="GroupMessage" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
        <item name="发送人" code="Sender" type="string" width="260" format = ""></item>
        <item name="接收人" code="Receiver" type="string" width="260" format = ""></item>
        <item name="内容" code="Content" type="string" width="260" format = ""></item>       
        <item name="头像" code="Icon" type="string" width="260" format = ""></item>
        <item name="发送状态" code="State" type="string" width="260" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="120" format = ""></item>
        <item name="保存时间" code="STime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="文件MD5" code="MD5" type="string" width="260" format = ""></item>
          <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="PeopleMessage" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
        <item name="发送人" code="Sender" type="string" width="260" format = ""></item>
        <item name="接收人" code="Receiver" type="string" width="260" format = ""></item>
        <item name="内容" code="Content" type="string" width="260" format = ""></item>
        <item name="消息ID" code="MsgId" type="string" width="260" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="头像" code="Icon" type="string" width="260" format = ""></item>
        <item name="文件ID" code="FileId" type="string" width="120" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="120" format = ""></item>
        <item name="保存时间" code="STime" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="文件MD5" code="MD5" type="string" width="260" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="CacheFiles" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
        <item name="文件ID" code="Id" type="string" width="260" format = ""></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件MD5" code="MD5" type="string" width="260" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="400" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="Download" detailfield="Uri" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件MD5" code="MD5" type="string" width="260" format = ""></item>
        <item name="本地路径" code="LocalPath" type="string" width="400" format = ""></item>
        <item name="网盘路径" code="RemotePath" type="string" width="400" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
  </plugin>
[config]*/
function News(){
    this.List = "";
}
function Account() {
    this.Name = "";
    this.Email = "";
    this.ID = "";
    this.Phone = "";
    this.Icon = "";
    this.NickName = "";
    this.DataState = "Normal";
}
function Image() {
    this.City = "";
    this.Country= "";
    this.District = "";
    this.Province = "";
    this.Street = "";
    this.Latitude = "";
    this.Longitude = "";
    this.TakeTime = "";
    this.Path = "";
    this.MD5 = "";
    this.Name = "";
    this.Time= "";
    this.Size = "";
    this.Id = "";
    this.DataState = "Normal";
}
function Blacklist() {
    this.UK = "";
    this.Name = "";
    this.Icon = "";  
    this.DataState = "Normal";
}
function People() {
    this.UK = "";
    this.Name = "";
    this.Icon = "";  
    this.DataState = "Normal";
}
function Contact() {
    this.Name = "";
    this.Id = "";
    this.Phone = "";
    this.Baidu= "";
    this.Yun = "";
    this.Icon = "";
    this.DataState = "Normal";
}
function Group() {
    this.Id = "";
    this.Name = "";
    this.Limit= "";
    this.Time = "";
    this.Icon = "";
    this.Mem = "";
    this.DataState = "Normal";
}
function GroupMessage() {
    this.Content = "";
    this.Sender = "";
    this.Receiver = "";
    this.Icon = "";
    this.State = "";
    this.Time = "";
    this.Size = "";
    this.FileId = "";
    this.Path = "";
    this.STime = "";
    this.MD5 = "";
    this.DataState = "Normal";
}
function GroupMessagefiles() {
    this.MsgId = "";
    this.Content = "";
    this.Sender = "";
    this.Receiver = ""
    this.FileId = "";
    this.Path = "";
    this.Size = "";
    this.File = "";
    this.STime = "";
    this.MD5 = "";
    this.CTime = "";
    this.DataState = "Normal";
}
function PeopleMessage() {
    this.MsgId = "";
    this.Icon = "";
    this.Content = "";
    this.Sender = "";
    this.Receiver = ""
    this.Time = "";
    this.Size = "";
    this.FileId = "";
    this.Path = "";
    this.STime = "";
    this.MD5 = "";
    this.DataState = "Normal";
}
function CacheFiles() {
    this.Id = "";
    this.Name = "";
    this.MD5 = "";
    this.Path = "";
    this.Size = "";
    this.DataState = "Normal";
}
function Download() {
    this.MD5 = "";
    this.LocalPath = "";
    this.RemotePath = "";
    this.Size = "";
    this.Time = null;
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "百度云";
    news.Type = "Account"; 
    accountinfo = getAccount(db0 + "\\account.db");
    news.Items = accountinfo;
    news.DataState = "Normal";
      
    for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Name;
        account.Type = "Account"; 
        news.TreeNodes.push(account)
       
        var image = new TreeNode() ;
        image.Text = "图片文件";
        image.Type = "Image"; 
        var dbacc = XLY.Sqlite.DataRecovery(db0+"\\"+accountinfo[i].ID+"cloud_image.db",charactor1,"cloud_image_files");
        image.Items = getImage(dbacc) ;
        account.TreeNodes.push(image);

        var file = new TreeNode() ;
        file.Text = "百度云文件";
        file.Type = "CacheFiles"; 
        var dba = XLY.Sqlite.DataRecovery(db0+"\\"+accountinfo[i].ID+"filelist.db",charactor2,"cachefilelist,download_tasks");   
        file.Items = getCacheFiles(dba) ;
  
        account.TreeNodes.push(file);
        
        var download = new TreeNode() ;
        download.Text = "下载文件";
        download.Type = "Download";      
        download.Items = getDownload(dba) ;
        account.TreeNodes.push(download);
        
        var contact = new TreeNode() ;
        contact.Text = "手机联系人";
        contact.Type = "Contact"; 
        var abc = db0+"\\"+accountinfo[i].ID+"cloudp2p.db";
                    
        contact.Items = getContact(abc) ;
        account.TreeNodes.push(contact);
        
        var people = new TreeNode() ;
        people.Text = "好友";
        people.Type = "People";
        var peopleinfo=getPeople(abc); 
        people.Items = peopleinfo;
        account.TreeNodes.push(people);
             
        for(var i in peopleinfo){  
            var message = new TreeNode();
            if(peopleinfo[i].Name!=null){
                message.Text = peopleinfo[i].Name;
            }
            else{
                message.Text = peopleinfo[i].UK;     
            }
            message.Type = "PeopleMessage";
            message.Items = getPeopleMessage(abc,peopleinfo[i],accountinfo);
            message.DataState = "Normal";    
            people.TreeNodes.push(message);
        }
    
        var black = new TreeNode() ;
        black.Text = "黑名单";
        black.Type = "Blacklist"; 
        black.Items = getBlacklist(abc) ;
        account.TreeNodes.push(black);
        
        var group = new TreeNode() ;
        group.Text = "群组";
        group.Type = "Group"; 
        var groupinfo = getGroup(abc) ;
        group.Items = groupinfo;    
        account.TreeNodes.push(group);
        
        for(var i in groupinfo){
            var person = new TreeNode();
            person.Text = groupinfo[i].Name;
            person.Type = "GroupMessage";
            person.Items = getGroupMessage(abc,accountinfo,groupinfo[i]);
            person.DataState = "Normal";
            group.TreeNodes.push(person); 
          }             
   }
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["好友","群组"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from info" ) +')');
    for(var i in data){
        var obj = new Account();
        obj.Name = data[i].account_name;
        obj.Email = data[i].account_email;
        obj.ID = data[i].account_uid;
        obj.Phone = data[i].account_phone;
        obj.Icon = data[i].avatar_url;
        obj.NickName = data[i].nick_name;        
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getImage(path){
    var list = new Array();
    var data = eval(XLY.Sqlite.Find(path,"select * from cloud_image_files"));
    for(var i in data){
        var obj = new Image();
        obj.City = data[i].city;
        obj.Country = data[i].country;
        obj.District = data[i].district;
        obj.Province = data[i].province;
        obj.Street = data[i].street;
        obj.Latitude = data[i].latitude;
        obj.Longitude = data[i].longitude;
        obj.Path = data[i].server_path;
        obj.MD5 = data[i].file_md5;
        obj.Name = data[i].file_name;
        obj.Id = data[i].fs_id;
        obj.Size = data[i].file_size+" Bytes";
        obj.TakeTime = XLY.Convert.LinuxToDateTime(data[i].date_taken);
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].server_ctime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    } 
    return list;

}
function getBlacklist(path){
    var list = new Array();
    var data = eval(XLY.Sqlite.Find(path,"select * from v_blacklist" ));
    for(var i in data){
        var obj = new Blacklist();
        obj.UK = data[i].uk;
        obj.Name = data[i].name;
        obj.Icon = data[i].avatar_url;     
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getPeople(path){
    var list = new Array();
    var data = eval(XLY.Sqlite.Find(path,"select * from people" ));
    for(var i in data){
        var obj = new People();
        obj.UK = data[i].uk;
        obj.Name = data[i].uname;
        obj.Icon = data[i].avatar_url;        
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getContact(path){
    var list = new Array(); 
    var data = eval(XLY.Sqlite.Find(path,"select * from contacts"));
    for(var i in data){
        var obj = new Contact();
        obj.Name = data[i].contact_name;
        obj.Id = data[i].uk;
        obj.Phone = data[i].phone;
        if(data[i].is_baidu_member == true){
            obj.Baidu = "是";
        }
        else{obj.Baidu = "否";
        }
         if(data[i].is_baiduyun_member == true){
            obj.Yun = "是";
        }
        else{obj.Yun = "否";
        }
        obj.Icon = data[i].avatar_url;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path){
    var list = new Array();
    var data = eval( XLY.Sqlite.Find(path,"select cast(group_id as text)as a,* from groups"));
    for(var i in data){
        var obj = new Group();
        obj.Id = data[i].a;
        var minfo=eval(XLY.Sqlite.Find(path,"select * from (select * from groups_people left join remarks where groups_people.[uk]=remarks.[uk])as a where group_id='"+data[i].a+"'  " ));
        var mem = "";
        if(minfo!=[]){
            for(var j in minfo){
                if(minfo[j].remark!=null){
                     mem = mem+"、"+minfo[j].remark;
                }
            mem = mem+"、"+minfo[j].uk;
            }
        } 
        obj.Mem=mem.substring(1);
        obj.Name = data[i].name;
        obj.Limit = data[i].people_limit;
        obj.Icon = data[i].avatar_part1_url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ctime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroupMessage(path,accountinfo,groupinfo){
    var list = new Array();
    var data = eval(XLY.Sqlite.Find(path,"select * from groups_messages where group_id = '"+groupinfo.Id+"' " ));
    for(var i in data){
        var obj = new GroupMessage();
        obj.Sender = data[i].uname;
        obj.State =  (data[i].send_state == 1) ? "失败" : "成功";
        obj.Receiver =groupinfo.Name;
        obj.Icon = data[i].avatar_url;
        if(data[i].files_count==1){
           var fileinfo= eval(XLY.Sqlite.Find(path,"select * from groups_messages_files where fsid = '"+data[i].min_server_ctime_fsid+"' " )); 
           obj.Content = fileinfo[0].server_filename;
           obj.Size = fileinfo[0].size+" bytes";
            obj.FileId = fileinfo[0].fsid;
            obj.MD5 = fileinfo[0].md5;
            obj.Path = fileinfo[0].path;
            obj.STime = XLY.Convert.LinuxToDateTime(fileinfo[0].server_ctime);
        }else{
            obj.Content = data[i].msg_content;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ctime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getPeopleMessage(path,peopleinfo,accountinfo){
    var list = new Array();
    var data = eval(XLY.Sqlite.Find(path,"select * from people_messages where conversation_uk = '"+peopleinfo.UK+"' " ));
    for(var i in data){
        var obj = new PeopleMessage();
        obj.MsgId = data[i].msg_id;
        obj.Icon = data[i].avatar_url;
        obj.Content = data[i].msg_content;
        if(data[i].conversation_uk == data[i].uk){
            obj.Sender = data[i].uname;            
            obj.Receiver = accountinfo[0].NickName;            
        }
        else{         
            obj.Sender = accountinfo[0].NickName;   
            obj.Receiver = data[i].uname;    
        }
        if(data[i].files_count==1){
            var fileinfo= eval(XLY.Sqlite.Find(path,"select * from people_messages_files where fsid = '"+data[i].min_server_ctime_fsid+"' " ));
            obj.Content = fileinfo[0].server_filename;
            obj.Size = fileinfo[0].size+" bytes";
            obj.FileId = fileinfo[0].fsid;
            obj.MD5 = fileinfo[0].md5;
            obj.Path = fileinfo[0].path;
            obj.STime = XLY.Convert.LinuxToDateTime(fileinfo[0].server_ctime);
        }else{
            obj.Content = data[i].msg_content;
        }        
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ctime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);       
        list.push(obj);
    }
    return list;
}
var lst = new Array();
function getCacheFiles(path){
    var list = new Array();
    var node = "";
    XLY.Sqlite.BigFindInit(path,"select * from cachefilelist");
    while(true)
    {
        
        var temp = XLY.Sqlite.BigFind();
        if(node=="")
        {
            node = "["+temp;
        }
        else
        {
            node = node+","+ temp;
        }

        if((temp=="")||(temp == null)) 
        {
            node = node+"]";
            break;
        }
        //var data = eval(XLY.Sqlite.BigFind());
        //if(data==null) break;
        //
        //for(var i in data){
        //    if(i<data.length)
        //    {
        //        var obj = new CacheFiles();
        //        obj.Id = data[i].fid;
        //        obj.Name = data[i].file_name;
        //        obj.MD5 = data[i].file_md5;
        //        obj.Path = data[i].server_path;
        //        obj.Size = data[i].file_size + " bytes";
        //        obj.Time = XLY.Convert.LinuxToDateTime(data[i].server_ctime);
        //        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        //        list.push(obj);
        //    }
        //}
    }
    lst.push(node);
    
    return list;
}
function getDownload(path){
    var list = new Array();
    var data = eval(XLY.Sqlite.Find(path,"select * from download_tasks" ));
    for(var i in data){
        var obj = new Download();
        obj.MD5 = data[i].file_md5;
        obj.LocalPath = data[i].local_url;
        obj.RemotePath = data[i].remote_url;
        obj.Size = data[i].size + " bytes";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db0 = source[0];
//
//var source ="d:\\data\\data\\com.baidu.netdisk\\databases"
var charactor =  "\\chalib\\Android_baidu.netdisk_V7.11.4\\account.db.charactor";
var charactor1 =  "\\chalib\\Android_baidu.netdisk_V7.11.4\\image.db.charactor";
var charactor2 =  "\\chalib\\Android_baidu.netdisk_V7.11.4\\filelist.db.charactor";
var charactor3 =  "\\chalib\\Android_baidu.netdisk_V7.11.4\\cloudp2p.db.charactor";

var result = new Array();
bindTree();
//XLY.Debug.WriteLine("result:"+result.length);

var res = JSON.stringify(result);
for(var i in lst)
{
    res = res.replace("\"百度云文件\",\"TreeNodes\":[],\"Items\":[]","\"百度云文件\",\"TreeNodes\":[],\"Items\":"+lst[i]);
    XLY.Debug.WriteLine(lst[i]);
}
//XLY.Debug.WriteLine("res:"+res);
res;
