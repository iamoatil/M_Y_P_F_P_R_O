﻿//descritpion:Test-复杂导航树

/*[config]
<plugin name="老虎地图,4" group="地图公交,7" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\TigerKnows.png" app="com.tigerknows" version="5.8.2" description="老虎地图" data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/com.tigerknows/databases/#F</value>
</source>
<data type="History">
<item name="地点" code="Addr" type="string" width="" format="" ></item>
</data>

<data type="Poi">
<item name="地点" code="Addr" type="string" width="200" ></item>
<item name="经度" code="Longitude" type="string" width="200" ></item>
<item name="纬度" code="Latitude" type="string" width="180" ></item>
<item name="时间" code="Time" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>

<data  detailfield="Line" type="Traffic">
<item name="交通路线" code="Line" type="string" width="500"  ></item>
<item name="类型" code="Type" type="string" width="100" ></item>
<item name="行程距离(米)" code="Distacne" type="string" width="150" ></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function History() {
    this.Addr = "";
}

function Poi() {
    this.Addr = "";
    this.Longitude = "";
    this.Latitude = "";
    this.Time = "";
}

function Traffic() {
    this.Line = "";
    this.Type = "";
    this.Distance = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

//获取树信息
function getTreeInfo(tree, num, datapath) {
    var hispath = datapath + "\\tigerknows.db";
    var hispoisql = "select poi_name,poi_x,poi_y,_datetime as time from poi where store_type='" + num + "'";
    var hispoiinfo = getPOI(hispath, hispoisql);
    var hispoiTree = new TreeNode();
    hispoiTree.Text = "地点";
    hispoiTree.Type = "Poi";
    hispoiTree.Items = hispoiinfo;

    var histrafficsql = "select _type as type,total_length,start,end from transitplan where store_type='" + num + "'";
    var hisbuslinesql = "select busline_name,total_length from busline where store_type='" + num + "'";
    var histralineinfo = getTrafficLine(hispath, histrafficsql);
    var hisbuslineinfo = getBusline(hispath, hisbuslinesql);
    var histrafficinfo = objConcat(histralineinfo, hisbuslineinfo);
    var histrafficTree = new TreeNode();
    histrafficTree.Text = "交通";
    histrafficTree.Type = "Traffic";
    histrafficTree.Items = histrafficinfo;

    hisinfo = getHistory(hispoiinfo, histrafficinfo);
    tree.Items = hisinfo;
    tree.TreeNodes.push(hispoiTree);
    tree.TreeNodes.push(histrafficTree);
}

//获取历史搜索地点信息
function getPOI(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var list = new Poi();
        list.Addr = data[index].poi_name;
        list.Latitude = data[index].poi_y;
        list.Longitude = data[index].poi_x;
        list.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].time));
        arr.push(list);
    }
    return arr;
}

//获取历史搜索交通信息
function getTrafficLine(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var list = new Traffic();
        switch (data[index].type) {
            case 1: list.Type = "步行"; break;
            case 2: list.Type = "公交"; break;
            case 3: list.Type = "自驾"; break;
        }
        list.Distacne = data[index].total_length;
        var startinfo = getPointName(path,data[index].start);
        var desinfo = getPointName(path,data[index].end);
        list.Line = startinfo.poi_name + "(" + "经度:" + startinfo.poi_x + "；纬度:" + startinfo.poi_y + ")至" + desinfo.poi_name + "(" + "经度:" + desinfo.poi_x + "；纬度:" + desinfo.poi_y + ")";
        arr.push(list);
    }
    return arr;
}

//获取公交路线信息
function getBusline(path, sql) {
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    var arr = new Array();
    for (var index in data) {
        var list = new Traffic();
        list.Line = data[index].busline_name;
        list.Distacne = data[index].total_length;
        list.Type = "公交路线";
        arr.push(list);
    }
    return arr;
}

//获取trafficline的点位信息
function getPointName(path,id) {
    var sql = "select _id as id,poi_name,poi_x,poi_y,_datetime as time from poi";
    var data = eval('(' + XLY.Sqlite.Find(path, sql) + ')');
    for (var index in data) {
        if (data[index].id == id) {
            return data[index];        
        }
    }
}

//合并json对象
function objConcat(a1, a2) {
    var newarr = new Array();
    var p = 0;
    for (var k1 in a1) {
        newarr[k1] = a1[k1];
        p = k1;
    }
    ++p;
    for (var k2 in a2) {
        newarr[p] = a2[k2];
        p++;
    }
    return newarr;
}

//获取历史搜索记录
function getHistory(poi, traffic) {
    var listp = new Array();
    var listt = new Array();
    for (var i in poi) {
        listp.push(poi[i].Addr);
    }
    for (var j in traffic) {
        listp.push(traffic[j].Line);
    }
    var obj = new Array();
    var arr = new Array();
    obj = objConcat(listp, listt);
    for (var index in obj) {
        var list = new History();
        list.Addr = obj[index];
        arr.push(list);
    }
    return arr;
}

//创建历史浏览和收藏夹树结构
var result = new Array();
var source = $source;
var datapath = source[0];
//var datapath = "E:\\app data\\Android\\com.tigerknows\\databases";
var history = new TreeNode();
history.Text = "历史浏览";
history.Type = "History";
getTreeInfo(history, 3, datapath);
var favorite = new TreeNode();
favorite.Text = "收藏夹";
favorite.Type = "History";
getTreeInfo(favorite, 1, datapath);

result.push(history);
result.push(favorite);
var res = JSON.stringify(result);
res;
