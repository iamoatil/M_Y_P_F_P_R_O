﻿/*[config]
<plugin name="139邮箱,3" group="主流邮箱,4" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/139mail.png" app="139邮箱" version="2.8.7" description="139邮箱" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.leadtone.mig.139pe.iPhone</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="120" format=""></item>
    <item name="通行证账号" code="AccountNumber" type="string" width="120" format = ""></item>
    <item name="别名" code="Alias" type="string" width="120" format=""></item>
    <item name="姓名" code="Name" type="string" width="120" format=""></item>
    <item name="提醒" code="Note" type="string" width="120" format=""></item>
    <item name="密码" code="Pwd" type="string" width="120" format=""></item>
</data>
<data type="List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="Entry" type="string" width="120" format=""></item>
</data>
<data type="ActivityArrangement" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width="120" format=""></item>
    <item name="标题" code="Title" type="string" width="120" format=""></item>
    <item name="标签名称" code="LabelName" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="开始时间" code="DtStart"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="结束时间" code="DtEnd"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract = "DataState" detailfield="Add">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发件人" code="Sender" type="string" width="220" format=""></item>
    <item name="收件人" code="Receiver" type="string" width="120" format=""></item>
    <item name="抄送" code="Copy" type="string" width="120" format=""></item>
    <item name="密送" code="BCC" type="string" width="120" format=""></item>
    <item name="主题" code="Title" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="是否是星标邮件" code="IsStarFlag" type="string" width="120" format=""></item>
    <item name="是否是移动账单" code="IsMoveBill" type="string" width="120" format=""></item>
    <item name="是否已读" code="SeenFlags" type="string" width="100" format = ""></item>
    <item name="附件" code="Add" type="string" width="120" format=""></item>
    <item name="本地地址" code="AddPath" type="URL" width="120" format=""></item>
    <item name="发送时间" code="Time" type="string" width="150" format = ""></item>
</data>
<data type="Contact" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="120" format=""></item>
    <item name="账号" code="Account" type="string" width="120" format=""></item>
    <item name="邮箱地址" code="Email" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.UserName = "";
    this.AccountNumber = "";
    this.Alias = "";
    this.Name = "";
    this.Note = "";
    this.Pwd = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.Name = "";
    this.Email = "";
    this.Account = "";
}
//定义List数据结构
function List(){
    this.DataState = "Normal";
    this.Entry = "";
}
//定义ActivityArrangement数据结构
function ActivityArrangement(){
    this.DataState = "Normal";
    this.UserId = "";
    this.Title = "";
    this.Content = "";
    this.DtStart = null;
    this.DtEnd = null;
    this.LabelName = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.Copy = "";
    this.BCC = "";
    this.Title = "";
    this.Content = "";
    this.Add = "";
    this.AddPath = "";
    this.IsStarFlag = "";
    this.IsMoveBill = "";
    this.SeenFlags = "";
    this.Time = null;
    this.Status = "";
    this.StarEmail = "";
    this.MobileBill = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var dpath = source[0]+"\\com.leadtone.mig.139pe.iPhone\\Documents\\db";
var rpath = source[0]+"\\com.leadtone.mig.139pe.iPhone\\Documents\\dbdata\\PMMailHead";

var rr1 = XLY.File.FindFileNamesWithExtension(dpath);
if(rr1!=""&&rr1!=null){
    var rr = eval('('+ rr1 +')');
    if(rr!=""&&rr!=null){
        for(var r in rr){
            if(rr[r].split("@")[1]=="139.com.db"){
                dpath = dpath+"\\"+rr[r];
            }
        }
    }
    var charactor = "\\chalib\\Ios_ 139Mail_V2.8.7\\15982158929@139.com.db.charactor";
    dpath = XLY.Sqlite.DataRecovery(dpath,charactor,"Attchments,Contact,Folders,MailHead,Userinfo");
}

//var dpath = "C:\\XLYSFTasks\\任务-2017-02-16-11-33-06\\source\\IosData\\2017-02-16-11-34-29\\f8a3b28cb9cbaa97bcde10e89b2dd5cceb3a617d\\com.leadtone.mig.139pe.iPhone\\Documents\\db";
//var rpath = "C:\\XLYSFTasks\\任务-2017-02-16-11-33-06\\source\\IosData\\2017-02-16-11-34-29\\f8a3b28cb9cbaa97bcde10e89b2dd5cceb3a617d\\com.leadtone.mig.139pe.iPhone\\Documents\\dbdata\\PMMailHead";
//var rr1 = XLY.File.FindFileNamesWithExtension(dpath);
//var rr = eval('('+ rr1 +')');
//if(rr!=""&&rr!=null){
//    for(var r in rr){
//        if(rr[r].split("@")[1]=="139.com.db"){
//            dpath = dpath+"\\"+rr[r];
//        }
//    }
//}
//var charactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\IOS_ 139Mail_V2.8.7\\15982158929@139.com.db.charactor";
//dpath = XLY.Sqlite.DataRecovery(dpath,charactor,"Attchments,Contact,Folders,MailHead,Userinfo");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "139邮箱";
    root.Type = "List";
    root.Items = getList(root);
    
    var contactNode = new TreeNode();
    contactNode.Text = "通讯录";
    contactNode.Type = "Contact";
    contactNode.Items = getContactInfo();
    root.TreeNodes.push(contactNode);
    result.push(root);
}

//获取列表
function getList(root){
    if(XLY.File.IsValid(dpath)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(dpath,"select * from Userinfo") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new List();
                obj.Entry = data[i].account;
                var node = new TreeNode();
                node.Text = obj.Entry;
                node.Type = "News";
                node.Items.push(getNews(data[i],node));
                root.TreeNodes.push(node);
                arr.push(obj);
            }
        }
        return arr;
    }
}

//获取用户信息
function getNews(info,root){
    if(info!=""&&info!=null){
        var obj = new News();
        obj.AccountNumber = info.account;
        obj.Alias = info.UserAlias;
        obj.Note = info.note;
        obj.UserName = info.userName;
        obj.Name = info.nickname;
        obj.Pwd = info.pwd;
        getUserNode(root,info.account);
        return obj; 
    }   
}

//创建用户下的节点，通讯录，收件箱，发件箱，移动账单，草稿箱，垃圾箱，我的文档，待办任务，活动安排
function getUserNode(root,temp){
    if(XLY.File.IsValid(dpath)){
        //var data = eval('('+ XLY.Sqlite.Find(dpath,"select distinct(folder) from MailHead where account = '"+temp+"'") +')');
        var data = eval('('+ XLY.Sqlite.Find(dpath,"select * from Folders where account = '"+temp+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                if(data[i].fname!=""&&data[i].fname!=null){
                    var node = new TreeNode();
                    //var aa = eval('('+ XLY.Sqlite.Find(dpath,"select fname from Folders where folderId = '"+data[i].folder+"'") +')');
                    //if(aa!=""&&aa!=null){
                    //    node.Text = aa[0].fname;
                    //}
                    node.Text = data[i].fname;
                    if(node.Text=="INBOX"){
                        node.Text = "收件箱";
                    }
                    node.Type = "Message";
                    node.Items = getMessage(data[i].folderId);
                    root.TreeNodes.push(node);
                }
            }
        }
        return root;
    }
}
//获取邮件信息
function getMessage(info){
    if(XLY.File.IsValid(dpath)){
        var data = eval('('+ XLY.Sqlite.Find(dpath,"select * from MailHead where folder = '"+info+"'") +')');
        if(data!=""&&data!= null){
            var arr = new Array();
            for(var i in data){
                var obj = new Message();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                var bb = data[i].Mform.split("(*$#*)");
                if(bb[0]!=""&&bb[0]!="(null)"){
                    if(bb[1]!=""&&bb[1]!= null){
                        obj.Sender = bb[0]+"<"+bb[1]+">";
                    }
                    else
                    {
                        obj.Sender = bb[0];
                    }
                }
                else
                {
                    if(bb[1]!=""&&bb[1]!=null){
                        obj.Sender = bb[1];
                    }
                }
                if(data[i].Mto!='[]'&&data[i].Mto[0]=='['){
                    var cc = eval('('+ data[i].Mto +')')[0].split("(*$#*)");
                    if(cc!=""&&cc!=null){
                        if(cc[0]!=""&&cc[0]!="(null)"){
                            if(cc[1]!=""&&cc[1]!= null){
                                obj.Receiver = cc[0]+"<"+cc[1]+">";
                            }
                            else
                            {
                                obj.Receiver = cc[0];
                            }
                        }
                        else
                        {
                            if(cc[1]!=""&&cc[1]!=null){
                                obj.Receiver = cc[1];
                            }
                        }
                    }
                }
                var aa = rpath+"\\"+data[i].bodyHtmlStr;
                obj.Content = XLY.File.ReadFile(aa);
                obj.Content = data[i].bodyplainText;
                if(data[i].isMoveBill==0){
                    obj.IsMoveBill = "否";
                }
                else
                {
                    obj.IsMoveBill = "是";
                }
                if(data[i].starflags==0){
                    obj.IsStarFlag = "否";
                }
                else
                {
                    obj.IsStarFlag = "是";
                }
                obj.Copy = "";
                if(data[i].bcc!='[]'&&data[i].bcc[0]=='['){
                    var dd = eval('('+ data[i].bcc +')')[0].split("(*$#*)");
                    if(dd!=""&&dd!=null){
                        if(dd[0]!=""&&dd[0]!="(null)"){
                            if(dd[1]!=""&&dd[1]!= null){
                                obj.BCC = dd[0]+"<"+dd[1]+">";
                            }
                            else
                            {
                                obj.BCC = dd[0];
                            }
                        }
                        else
                        {
                            if(dd[1]!=""&&dd[1]!=null){
                                obj.BCC = dd[1];
                            }
                        }
                    }
                }
                
                var ee = eval('('+ XLY.Sqlite.Find(dpath,"select * from Attchments where uid = '"+data[i].uid+"'") +')');
                if(ee!=""&&ee!=null){
                    obj.Add = "附件名："+ee[0].filename+"\r"+"类型:"+ee[0].mimeType+"\r"+"日期："+ee[0].lastUpdateTime+"大小："+ee[0].bsize+"Bytes";
                }
                obj.Title = data[i].subject;
                obj.AddPath = aa;
                if(data[i].seenflags==0){
                    obj.SeenFlags = "否";
                }
                else
                {
                    obj.SeenFlags = "是";
                }
                
                obj.Time = data[i].date;
                obj.StarEmail = "";
                obj.MobileBill = "";
                arr.push(obj);
            } 
        }
        return arr;
    }
}
//获取通讯录
function getContactInfo(){
    if(XLY.File.IsValid(dpath)){
        //var data = eval('('+ XLY.Sqlite.Find(dpath,"select distinct(name) from Contact") +')');
        var data = eval('('+ XLY.Sqlite.Find(dpath,"select distinct(email) from Contact") +')');
        var arr = new Array();
        if(data!=""&&data!=null){
            for(var i in data){
                //var info = eval('('+ XLY.Sqlite.Find(dpath,"select * from Contact where name = '"+data[i].name+"'") +')');
                //var obj = new Contact();
                ////obj.DataState = XLY.Convert.ToDataState(info[0].XLY_DataType);
                //obj.Name = info[0].name;
                //obj.Email = eval('('+ info[0].email +')')[0];
                //obj.Account = info[0].simple_sort_key;
                //arr.push(obj);
                var info = eval('('+ XLY.Sqlite.Find(dpath,"select * from Contact where email = '"+data[i].email+"'") +')');
                var obj = new Contact();
                obj.DataState = XLY.Convert.ToDataState(info[0].XLY_DataType);
                obj.Name = info[0].name;
                obj.Email = eval('('+ info[0].email +')')[0];
                obj.Account = info[0].simple_sort_key;
                arr.push(obj);
            }
        }
        return arr;
    }
}
