﻿/*[config]
<plugin name="快牙" group="生活旅游,5" devicetype="ios" icon="\icons\kuaiya.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.dewmobile.zapya" version="2.7.0" description="快牙" data="$data,ComplexTreeDataSource">
    <source>
    <value>com.dewmobile.zapya</value>
    </source>
    <data type="Kuaiya" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="User" contract="DataState" datefilter = "LastPlayTime">
    <item name="用户ID" code="ID" type="string" width = "150"></item>
    </data>
    <data type="Friend" contract="DataState" datefilter = "LastPlayTime">
    <item name="好友设备名称" code="Name" type="string" width = "150"></item>
    <item name="设备ID" code="ID" type="string" width = "150"></item>
    </data>
    <data type="TransferInfo" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="文件名" code="Name" type="string" width = "150"></item>
    <item name="文件路径" code="Path" type="string" width = "150"></item>
    <item name="文件大小" code="Size" type="string" width = "150"></item>
    <item name="发送时间" code="Time" type="string" width = "150"></item>
    <item name="文件类型" code="Type" type="string" width = "150"></item>
    <item name="收发标志" code="Flag" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/

function User(){
    this.DataState = "Normal";
    this.ID = "";
}
function Kuaiya(){
    this.DataState = "Normal";
    this.List = "";
}
function Friend(){
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
}
function TransferInfo(){
    this.DataState = "Normal";
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.Time = "";
    this.Type = "";
    this.Flag = "";
}    
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
function bindTree(){
    var kuaiya = new TreeNode();
    kuaiya.Text = "快牙";
    kuaiya.Type = "Kuaiya";
    kuaiya.Items = getKuaiya();
    kuaiya.DataState = "Normal";
    newTreeNode("用户信息","User",getUser(db0),kuaiya);
    var friend = getFriend(db);
    transfer=newTreeNode("好友信息","Friend",friend,kuaiya);
    for(var i in friend){
        newTreeNode(friend[i].Name,"TransferInfo",getTransferInfo(db,friend[i].Name),transfer);
    }
    result.push(kuaiya);
}  
function getKuaiya(){
    var list = new Array();
    data = ["用户信息","好友信息"];
    for(var i in data){
        var obj = new Kuaiya();
        obj.List = data[i];
        list.push(obj);  
    }
    return list;
}
function getUser(path){
    var list = new Array();
    var data = eval('('+ XLY.PList.ReadToJsonString(path) +')');
    var obj = new User();
    for(var i in data){
        var a =JSON.stringify(data[i]);
        var reg = /user_id/;
        if(reg.test(a)){
            obj.ID = data[i].user_id;
        }
    }   
    list.push(obj);
    return list;
}
function getFriend(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct ZDEVICE,ZNICK from ZTRANSFER" ) +')');
    if(data.length>0){
        for(var i in data){
        if(data[i].ZDEVICE!=""){
            var obj = new Friend();
            obj.Name = data[i].ZNICK;
            obj.ID = data[i].ZDEVICE;
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            list.push(obj);
        }
    }
    }
    return list;
}
function getTransferInfo(path,name){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ZTRANSFER where ZNICK='"+name+"'" ) +')');
    for(var i in data){
        var obj = new TransferInfo();
        obj.Name = data[i].ZTITLE;
        obj.Path = data[i].ZKEY;
        obj.Size = data[i].ZTOTALBYTES/1024/1024+" MB";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ZCREATETIME);
        obj.Type = data[i].ZCATEGORY;
        if(data[i].ZSHARECOUNT==0){
            obj.Flag = "好友传来";
        }else{
            obj.Flag = "用户发出";
        }
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}

//********************************************************
var source = $source;
var db1 = source[0]+"\\com.dewmobile.zapya\\Documents\\kuaiya.sqlite";
var db0 = source[0]+"\\com.dewmobile.zapya\\Documents\\settings.plist";
//var db0 = "C:\\Users\\Administrator\\Desktop\\kuaiyashuju\\Documents\\settings.plist";
//var db1 = "C:\\Users\\Administrator\\Desktop\\kuaiyashuju\\Documents\\kuaiya.sqlite";
//var charactor = "C:\\Users\\Administrator\\Desktop\\KUAIYA\\Documents\\kuaiya.sqlite.charactor";
var charactor = "chalib\\IOS_KuaiYa_V2.7.0\\Documents\\kuaiya.sqlite.charactor";
var db = XLY.Sqlite.DataRecovery(db1,charactor,"ZTRANSFER");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
