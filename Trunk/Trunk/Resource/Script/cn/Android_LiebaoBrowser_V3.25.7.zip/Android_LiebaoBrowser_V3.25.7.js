﻿/*[config]
<plugin name="猎豹浏览器,4" group="Web痕迹,3" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="\icons\LiebaoBrowser.png" app="com.ijinshan.browser_fast" version="3.25.7" description="猎豹浏览器"  data="$data,ComplexTreeDataSource">
    <source>
    <value>/data/data/com.ijinshan.browser_fast/app_webview/Cookies</value>
    <value>/data/data/com.ijinshan.browser_fast/databases/_video_history_manager_.db</value>
    <value>/data/data/com.ijinshan.browser_fast/databases/browser.db</value>
    <value>/data/data/com.ijinshan.browser_fast/databases/downloads.db</value>
    <value>/data/data/com.ijinshan.browser_fast/databases/video.db</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="主键" code="Key" type="string" width = "150"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="值" code="Value" type="string" width = "200"></item>
   </data>
    <data type="VideoHistory" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="ID" code="ID" type="url" width = "150"></item>
    <item name="更新时间" code="Time" type="string" width = "200"></item>
    </data>
   <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="url" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
   <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Visits" type="url" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
<data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
 <data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="网址" code="Url" type="url" width = "200"></item>
    <item name="名字" code="Name" type="string" width = "200"></item>
    <item name="类型" code="Type" type="string" width = "150"></item>
    <item name="路径" code="Path" type="string" width = "150"></item>
    <item name="来源网站" code="Referer" type="string" width = "150"></item>
    <item name="代理" code="Agent" type="string" width = "150"></item>
    <item name="开始时间" code="Time" type="string" width = "150"></item>
    <item name="结束时间" code="FTime" type="string" width = "150"></item>
    <item name="是否是视频" code="Video" type="string" width = "150"></item>
     <item name="Cookies" code="Cookies" type="string" width = "150"></item>     
     <item name="总大小" code="TotalSize" type="string" width = "150"></item>
     <item name="已下载大小" code="CurrentSize" type="string" width = "150"></item>
    </data>
 <data type="Video" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="更新集数" code="Pstate" type="string" width = "150"></item>
    <item name="上次播放集数" code="Play" type="string" width = "150"></item>
    <item name="总集数" code="Total" type="string" width = "150"></item>
    <item name="图片网址" code="Url" type="url" width = "150"></item>
    <item name="详情" code="Detail" type="string" width = "150"></item>
    <item name="更新时间" code="Time" type="string" width = "200"></item>
    <item name="是否同步" code="Sync" type="string" width = "200"></item>
    </data>
</plugin>
[config]*/
function News() {
    this.List = "";
}
function Cookies() {
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Value = "";
}
function VideoHistory() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.ID = "";
    this.Visits = "";
    this.Time = "";
}
function Bookmark() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
}
function History() {
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Visits = "";
    this.Time = "";
}
function Search() {
    this.DataState = "Normal";
    this.Title = "";
    this.Time = "";
}
function Download() {
    this.DataState = "Normal";
    this.Url = "";
    this.Name = "";
    this.Type = "";
    this.Time = "";
    this.Referer = "";
    this.Video = "";
    this.Cookies = "";
    this.Agent = "";
    this.TotalSize = "";
    this.CurrentSize = "";
    this.Path = "";
    this.FTime = "";
}
function Video() {
    this.DataState = "Normal";
    this.Title = "";
    this.Pstate = "";
    this.Play = "";
    this.Total = "";
    this.Url = "";
    this.Detail = "";
    this.Time = "";
    this.Sync = "";
}
//定义树数据结构
function TreeNode() {
    this.TreeNodes = new Array();
}
function bindTree() {
    newTreeNode("Cookies", "Cookies", getCookies(db5));
    newTreeNode("书签", "Bookmark", getBookmark(db7));
    newTreeNode("浏览记录", "History", getHistory(db7));
    newTreeNode("搜索", "Search", getSearch(db7));
    newTreeNode("下载文件", "Download", getDownload(db8));
    newTreeNode("视频播放记录", "VideoHistory", getVideoHistory(db6));
    newTreeNode("收藏视频", "Video", getVideo(db9));
}
function getNews() {
    var list = new Array();
    data = ["Cookies", "书签", "浏览记录", "缓存", "收藏视频", "下载", "视频播放记录"];
    for (var i in data) {
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text, type, items) {
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);
}
function getCookies(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from cookies") + ')');
    for (var i in data) {
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getVideoHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from videoitems") + ')');
    for (var i in data) {
        var obj = new VideoHistory();
        obj.Title = data[i].name;
        obj.ID = data[i].id;
        obj.Url = data[i].videosource;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].last_update);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmarks") + ')');
    for (var i in data) {
        var obj = new History();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from bookmarks where bookmark =1") + ')');
    for (var i in data) {
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Visits = data[i].visits;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select cast(time_stamp as double)as time,* from search_history") + ')');
    for (var i in data) {
        var obj = new Search();
        obj.Title = data[i].title;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from downloads") + ')');
    for (var i in data) {
        var obj = new Download();
        obj.Url = data[i].url;
        obj.Name = data[i].filename;
        obj.Type = data[i].mimetype;
        obj.Cookies = data[i].cookies;
        obj.Agent = data[i].useragent;
        obj.TotalSize = data[i].totalbytes + " bytes";
        obj.CurrentSize = data[i].downloadedbytes + " bytes";
        obj.Referer = data[i].referer;
        obj.Video = (data[i].isvideo == 1) ? "是" : "否";
        obj.Path = data[i].pathname;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].createDate);
        obj.FTime = XLY.Convert.LinuxToDateTime(data[i].finishDate);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getVideo(path) {
    var list = new Array();
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from subscribe") + ')');
    for (var i in data) {
        var obj = new Video();
        obj.Title = data[i].videoName;
        obj.Url = data[i].picurl;
        obj.Pstate = data[i].pstate;
        obj.Play = data[i].lastPlayChapter;
        obj.Total = data[i].total;
        obj.Detail = data[i].detailurl;
        obj.Sync = (data[i].sync == 1) ? "是" : "否";
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].updateTime);
        obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[1];
var db2 = source[2];
var db3 = source[3];
var db4 = source[4];

var charactor = "\\chalib\\Android_LiebaoBrowser_V3.25.7\\Cookies.charactor";
var charactor1 = "\\chalib\\Android_LiebaoBrowser_V3.25.7\\_video_history_manager_.db.charactor";
var charactor2 = "\\chalib\\Android_LiebaoBrowser_V3.25.7\\browser.db.charactor";
var charactor3 = "\\chalib\\Android_LiebaoBrowser_V3.25.7\\downloads.db.charactor";
var charactor4 = "\\chalib\\Android_LiebaoBrowser_V3.25.7\\video.db.charactor";

var db5 = XLY.Sqlite.DataRecovery(db, charactor, "cookies");
var db6 = XLY.Sqlite.DataRecovery(db1, charactor1, "videoitems");
var db7 = XLY.Sqlite.DataRecovery(db2, charactor2, "bookmarks,search_history");
var db8 = XLY.Sqlite.DataRecovery(db3, charactor3, "downloads");
var db9 = XLY.Sqlite.DataRecovery(db4, charactor4, "subscribe");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
