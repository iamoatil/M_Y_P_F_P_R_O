﻿/*[config]
<plugin name="Weico,16" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/Weico.png" app="com.eico.weico" version="4.6.4" description="Weico" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.eico.weico#F</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号类型" code="VerifiedReason" type="string" width="200" format=""></item>
    <item name="id" code="Id" type="string" width="200" format=""></item>
    <item name="头像" code="Avatar_hd" type="string" width="200" format=""></item>
    <item name="个人描述" code="PersonalDescription" type="string" width="200" format = ""></item>
    <item name="个性域名" code="Domain" type="string" width="200" format=""></item>
    <item name="账号昵称" code="ScreenName" type="string" width="200" format=""></item>
    <item name="微号" code="Weihao" type="string" width="200" format=""></item>
    <item name="性别" code="Gender" type="string" width="200" format=""></item>
    <item name="地址" code="Location" type="string" width="200" format=""></item>
    <item name="关注数" code="FriendsCount" type="string" width="200" format=""></item>
    <item name="粉丝数" code="FollowersCount" type="string" width="200" format=""></item>
    <item name="收藏数" code="FavouritesCount" type="string" width="200" format=""></item>
    <item name="省份编码" code="Province" type="string" width="200" format=""></item>
    <item name="城市编码" code="City" type="string" width="200" format=""></item>
    <item name="微博数" code="StatusesCount" type="string" width="200" format=""></item>
    <item name="是否加V" code="IsVerified" type="string" width="200" format=""></item>
    <item name="互粉数" code="BiFollowerCount" type="string" width="200" format=""></item>
    <item name="创建时间" code="CreatedAt" type="string" width="200" format=""></item>
</data>
<data type="FollowM" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号类型" code="VerifiedReason" type="string" width="200" format=""></item>
    <item name="id" code="Id" type="string" width="200" format=""></item>
    <item name="头像" code="Avatar_hd" type="string" width="200" format=""></item>
    <item name="个人描述" code="PersonalDescription" type="string" width="200" format = ""></item>
    <item name="个性域名" code="Domain" type="string" width="200" format=""></item>
    <item name="账号昵称" code="ScreenName" type="string" width="200" format=""></item>
    <item name="备注" code="Remark" type="string" width="200" format=""></item>
    <item name="微号" code="Weihao" type="string" width="200" format=""></item>
    <item name="性别" code="Gender" type="string" width="200" format=""></item>
    <item name="地址" code="Location" type="string" width="200" format=""></item>
    <item name="关注数" code="FriendsCount" type="string" width="200" format=""></item>
    <item name="粉丝数" code="FollowersCount" type="string" width="200" format=""></item>
    <item name="收藏数" code="FavouritesCount" type="string" width="200" format=""></item>
    <item name="省份编码" code="Province" type="string" width="200" format=""></item>
    <item name="城市编码" code="City" type="string" width="200" format=""></item>
    <item name="微博数" code="StatusesCount" type="string" width="200" format=""></item>
    <item name="是否加V" code="IsVerified" type="string" width="200" format=""></item>
    <item name="互粉数" code="BiFollowerCount" type="string" width="200" format=""></item>
    <item name="创建时间" code="CreatedAt" type="string" width="200" format=""></item>
    <item name="最近发的一条微博内容" code="Statu" type="string" width="200" format=""></item>
    <item name="最近发的一条微博时间" code="StatuTime" type="string" width="200" format=""></item>
</data>
<data type="PrivateLetter" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="私信id" code="Id" type="string" width="200" format=""></item>
    <item name="接收者" code="Receiver" type="string" width="200" format=""></item>
    <item name="发送者" code="Sender" type="string" width="200" format=""></item>
    <item name="私信内容" code="Text" type="string" width="200" format=""></item>
    <item name="时间" code="CreateAt" type="string" width="200" format=""></item>
</data>
<data type="Search" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="搜索关键字" code="KeyWord" type="string" width="200" format=""></item>
    <item name="最后修改时间" code="LastModified" type="datetime" width="200" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************

//定义UserInfo数据结构
function UserInfo() {
    this.DataState = "Normal";
    this.VerifiedReason = "";
    this.Id = "";
    this.Avatar_hd = "";
    this.PersonalDescription = "";
    this.Domain = "";
    this.ScreenName = "";
    this.Weihao = "";
    this.Gender = "";
    this.Location = "";
    this.FriendsCount = "";
    this.FollowersCount = "";
    this.FavouritesCount = "";
    this.Province = "";
    this.City = "";
    this.StatusesCount = "";
    this.IsVerified = "";
    this.BiFollowerCount = "";
    this.CreatedAt = "";
}
//定义FollowM数据结构
function FollowM() {
    this.DataState = "Normal";
    this.VerifiedReason = "";
    this.Id = "";
    this.Avatar_hd = "";
    this.PersonalDescription = "";
    this.Domain = "";
    this.ScreenName = "";
    this.Remark = "";
    this.Weihao = "";
    this.Gender = "";
    this.Location = "";
    this.FriendsCount = "";
    this.FollowersCount = "";
    this.FavouritesCount = "";
    this.Province = "";
    this.City = "";
    this.StatusesCount = "";
    this.IsVerified = "";
    this.BiFollowerCount = "";
    this.CreatedAt = "";
    this.Statu = "";
    this.StatuTime = "";
}
//定义私信数据结构
function PrivateLetter(){
    this.DataState = "Normal";
    this.Receiver = "";
    this.Sender = "";
    this.Text = "";
    this.CreateAt = "";
}
//定义搜索数据结构
function Search(){
    this.DataState = "Normal";
    this.KeyWord = "";
    this.LastModified = null;
}
//定义功能列表数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var uidpath = source[0]+"\\files\\dataCache";
var searchpath = source[0]+"\\shared_prefs\\com.eico.weico.xml";
var pathtest=source[0]+"\\files";
//测试数据
//var uidpath = "C:\\XLYSFTasks\\任务-2016-12-12-15-45-55\\source\\data\\data\\com.eico.weico\\files\\dataCache";
//var searchpath = "C:\\XLYSFTasks\\任务-2016-12-12-15-45-55\\source\\data\\data\\com.eico.weico\\shared_prefs\\com.eico.weico.xml";
//var pathtest = "C:\\XLYSFTasks\\任务-2016-12-12-15-45-55\\source\\data\\data\\com.eico.weico\\files";
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    //解析的内容包括用户信息，关注/粉丝信息，私信，发送的博文，看过并评论的博文，涉及到我的博文，搜索过的用户
    var treeroot = new TreeNode();
    treeroot.Text = "Weico";
    treeroot.Type = "News";
    
    var searchnode = new TreeNode();
    searchnode.Text = "搜索";
    searchnode.Type = "Search";
    searchnode.Items = getSearch();
    treeroot.TreeNodes.push(searchnode);
    
    treeroot.Items = getTreeRootMes(uidpath,treeroot,pathtest);
    result.push(treeroot);
}
//获取用户信息
function getTreeRootMes(path,root,patht){
    var data = eval('('+ XLY.File.FindDirectories(patht) +')');
    for(var i in data){
        if(data[i]==path){
            var list = new Array();
            var folder = eval('('+ XLY.File.FindDirectories(data[i]) +')');
            if(folder !="" && folder != null){
                for(var i in folder){
                    var obj = new News();
                    obj.List = XLY.File.GetFileName(folder[i]);
                    list.push(obj);
                    
                    var uidnode = new TreeNode();
                    uidnode.Text = XLY.File.GetFileName(folder[i]);
                    uidnode.Type = "UserInfo";
                    uidnode.Items = getUserMes(folder[i],uidnode);
                    root.TreeNodes.push(uidnode);
                }
                return list;
            }
        }
    }
}
//获取文件信息
function getFile(info,path1,str){
    var temp = eval('('+ XLY.File.FindFileNames(info) +')');
    for(var i in temp){
        if(temp[i]==path1){
            var path = info+"\\"+path1;
            var data = XLY.File.ReadFile(path);
            var info = data.substr(data.indexOf(str),data.length-data.indexOf(str)+1);
            var udata = eval('('+ info +')');
            return udata;
        }
    }
}
//获取用户信息
function getUserMes(info,root){
    var list = new Array();
    var udata = getFile(info,"KEY_DATA_GROUPS","[");
    var fodata = getFile(info,"KEY_DATA_FOLLOWERS","{");
    var frdata = getFile(info,"KEY_DATA_FRIENDS","{");
    if(udata!=""&&udata != null){
        var obj = new UserInfo();
        obj.DataState = XLY.Convert.ToDataState(udata[0].XLY_DataType);
        switch(udata[0].user.verified_type){
          case -1: 
                obj.VerifiedReason = "普通用户";
            break;
          case 0: 
            obj.VerifiedReason = "名人";
            break;
          case 1: 
            obj.VerifiedReason = "政府";
            break;
          case 2: 
            obj.VerifiedReason = "企业";
            break;
          case 3: 
            obj.VerifiedReason = "媒体";
            break;
          case 4: 
            obj.VerifiedReason = "校园";
            break;
          case 5: 
            obj.VerifiedReason = "网站";
            break;
          case 6: 
            obj.VerifiedReason = "应用";
            break;
          case 7: 
            obj.VerifiedReason = "团体(机构)";
            break;
          case 8: 
            obj.VerifiedReason = "待审企业";
            break;
          case 200: 
            obj.VerifiedReason = "初级达人";
            break;
          case 220: 
            obj.VerifiedReason = "中高级达人";
            break;
          case 400: 
                obj.VerifiedReason = "已故V用户";
            break;
        }
        obj.Id = udata[0].user.idstr;
        obj.Avatar_hd = udata[0].user.avatar_hd;
        obj.PersonalDescription = udata[0].user.description;
        obj.Domain = udata[0].user.domain;
        obj.ScreenName = udata[0].user.screen_name;
        obj.Weihao = udata[0].user.weihao;
        if(udata[0].user.gender=='m'){
            obj.Gender = "男";
        }
        else
        {
            obj.Gender = "女";  
        }
        obj.Location = udata[0].user.location;
        obj.FriendsCount = udata[0].user.friends_count;
        obj.FollowersCount = udata[0].user.followers_count;
        obj.FavouritesCount = udata[0].user.favourites_count;
        obj.Province = udata[0].user.province;
        obj.City = udata[0].user.city;
        obj.StatusesCount = udata[0].user.statuses_count;
        obj.IsVerified = udata[0].user.verified_type;
        obj.BiFollowerCount = udata[0].user.bi_followers_count;
        obj.CreatedAt = udata[0].created_at;
        list.push(obj);
    }
    
    var friendnode = new TreeNode();
    friendnode.Text = "关注/粉丝";
    friendnode.Type = "News";
    if(fodata != "" && fodata != null && frdata != "" && frdata != null){
        friendnode.Items = getFriendMess(friendnode,fodata,frdata);
    }
    
    var privateletternode = new TreeNode();
    privateletternode.Text = "私信";
    privateletternode.Type = "PrivateLetter";
    privateletternode.Items = getPrivateLetter(info);
    
    var blognode = new TreeNode();
    blognode.Text = "博文";
    blognode.Type = "News";
    blognode.Items = getBlog(blognode,info);
    
    root.TreeNodes.push(friendnode);
    root.TreeNodes.push(privateletternode);
    root.TreeNodes.push(blognode);
    return list;
}
//获取关注/粉丝信息
function getFriendMess(root,followdata,frienddata){
    var list = new Array();
    list.push(getFriendAll(followdata,root,"粉丝"));
    list.push(getFriendAll(frienddata,root,"关注"));
    return list;
}
//创建粉丝/关注节点
function getFriendAll(data,root,info){
    var node = new TreeNode();
    node.Text = info;
    node.Type = "FollowM";
    node.Items = getFollowM(data);
    root.TreeNodes.push(node);
    
    var list = new Array();
    var foobj = new News();
    foobj.List = info;
    return foobj;
}
//获取粉丝和关注具体信息
function getInfo(info,i){
    var obj = new FollowM();
    obj.DataState = XLY.Convert.ToDataState(info[i].XLY_DataType);
    switch(info[i].verified_type){
      case -1: 
            obj.VerifiedReason = "普通用户";
        break;
      case 0: 
        obj.VerifiedReason = "名人";
        break;
      case 1: 
        obj.VerifiedReason = "政府";
        break;
      case 2: 
        obj.VerifiedReason = "企业";
        break;
      case 3: 
        obj.VerifiedReason = "媒体";
        break;
      case 4: 
        obj.VerifiedReason = "校园";
        break;
      case 5: 
        obj.VerifiedReason = "网站";
        break;
      case 6: 
        obj.VerifiedReason = "应用";
        break;
      case 7: 
        obj.VerifiedReason = "团体(机构)";
        break;
      case 8: 
        obj.VerifiedReason = "待审企业";
        break;
      case 200: 
        obj.VerifiedReason = "初级达人";
        break;
      case 220: 
        obj.VerifiedReason = "中高级达人";
        break;
      case 400: 
            obj.VerifiedReason = "已故V用户";
        break;
    }
    obj.Id = info[i].idstr;
    obj.Avatar_hd = info[i].avatar_hd;
    obj.PersonalDescription = info[i].description;
    obj.Domain = info[i].domain;
    obj.ScreenName = info[i].screen_name;
    obj.Remark = info[i].remark;
    obj.Weihao = info[i].weihao;
    if(info[i].gender=='m'){
        obj.Gender = "男";
    }
    else
    {
        obj.Gender = "女";  
    }
    obj.Location = info[i].location;
    obj.FriendsCount = info[i].friends_count;
    obj.FollowersCount = info[i].followers_count;
    obj.FavouritesCount = info[i].favourites_count;
    obj.Province = info[i].province;
    obj.City = info[i].city;
    obj.StatusesCount = info[i].statuses_count;
    obj.IsVerified = info[i].verified_type;
    obj.BiFollowerCount = info[i].bi_followers_count;
    obj.CreatedAt = info[i].created_at;
    if(info[i].status==""||info[i].status==null){
        obj.Statu = "";
        obj.StatuTime = "";
    }
    else
    {
        obj.Statu = info[i].status.text;
        obj.StatuTime = info[i].status.created_at;
    }
    return obj;
}
//获取粉丝信息
function getFollowM(info){
    var list = new Array();
    if(info.users !=""&& info.users!=null){
        for(var i in info.users){
           list.push(getInfo(info.users,i)); 
        }
    }
    return list;
}
//获取私信信息
function getPrivateLetter(info){
    var list = new Array();
    var data = getFile(info,"KEY_DATA_MESSAGE_USER_LIST","{");
    if(data!=""&&data!=null){
        for(var i in data.user_list){
            var obj = new PrivateLetter();
            obj.DataState = XLY.Convert.ToDataState(data.user_list[i].XLY_DataType);
            obj.Id = data.user_list[i].direct_message.idstr;
            obj.Receiver = data.user_list[i].direct_message.recipient.screen_name;
            obj.Sender = data.user_list[i].direct_message.sender.screen_name;
            obj.Text = data.user_list[i].direct_message.text;
            obj.CreateAt = data.user_list[i].direct_message.created_at;
            list.push(obj);
        }
    }
    return list;
}
//获取博文
function getBlogMes(info,text){
    var list = new Array();
    var datapath = info+"\\"+text;
    var data = XLY.File.ReadFile(datapath);
    var info = data.substr(data.indexOf("["),data.length-1);
    return list;
}
//创建博文节点
function createBlogNode(root,text,info){
    var node = new TreeNode();
    node.Text = text;
    node.Type = "News";
    if(text=="用户发过的博文"){
        text1 = "KEY_DATA_USER_TIME_LINE";
        text2 = info+"\\"+text1;
        if(XLY.File.IsValid(text2)){
            node.Items = getBlogMes(info,text1);
        }
    }
    if(text=="@用户的博文"){
        text1 = "KEY_DATA_TIME_LINE_MENTIONS";
        text2 = info+"\\"+text1;
        if(XLY.File.IsValid(text2)){
            node.Items = getBlogMes(info,text1);
        }
    }
    root.TreeNodes.push(node);
    var list = new Array();
    var obj = new News();
    obj.List = text;
    list.push(obj);
    return list;
}
//获取博文节点
function getBlog(root,info){
    var userblogtext = "用户发过的博文";
    var touserblogtext = "@用户的博文";
    createBlogNode(root,userblogtext,info);
    createBlogNode(root,touserblogtext,info);
}
//获取搜索记录
function getSearch(){
    var list = new Array();
    if(XLY.File.IsValid(searchpath)){
        var data = eval('('+ XLY.File.ReadXML(searchpath) +')');
        var searchword = data.map.string;
        for(var i in searchword){
            if(searchword[i]["@name"]=="KEY_SEARCH_HISTORY"){
                var swdata = eval('('+ searchword[i]["#text"] +')');
                for(var i in swdata){
                    var obj = new Search();
                    obj.DataState = XLY.Convert.ToDataState(swdata[i].XLY_DataType);
                    obj.KeyWord = swdata[i].keywords;
                    obj.LastModified = XLY.Convert.LinuxToDateTime(swdata[i].lastModified);
                    list.push(obj);
                }
            }
        }
        return list;
    }
}
