﻿/*[config]
<plugin name="腾讯微博,10" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid,LocalData" icon="\icons\tencentweibo.png" app="com.tencent.WBlog" version="6.1.2" description="腾讯微博" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.tencent.WBlog/databases#F</value>
</source>
<data type="Account" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="NickName" type="string" width="120" ></item>
<item name="账号ID" code="ID" type="string" width = "120" ></item>
<item name="性别" code="Gender" type="string" width="120" ></item>
<item name="简介" code="Summary" type="string" width = "150" ></item>
<item name="生日" code="Birthday" type="string" width="120" ></item>
<item name="注册时间" code="RegTime" type="string" width = "150" ></item>
<item name="所在地" code="CurLoc" type="string" width="120" ></item>
<item name="家乡" code="Home" type="string" width="120" ></item>
<item name="工作时间" code="JobTime" type="string" width = "150" ></item>
<item name="公司" code="Company" type="string" width="120" ></item>
<item name="入学时间" code="SchoolYear" type="string" width = "150" ></item>
<item name="学校" code="School" type="string" width = "150" ></item>
</data>
<data type="Info"  contract="DataState" datefilter = "LastPlayTime">
<item name="账号" code="Acc" type="string" width = "150"></item>
</data>
<data type="Drafts"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="用户ID" code="ID" type="string" width="100" ></item>
<item name="内容" code="Content" type="string" width="120" ></item>
<item name="创建时间" code="CTime" type="string" width = "400" ></item>
<item name="修改时间" code="MTime" type="string" width = "120" ></item>
<item name="原文作者ID" code="RID" type="string" width="120" ></item>
<item name="原文作者" code="Author" type="string" width = "400" ></item>
<item name="原文内容" code="RContent" type="string" width="120" ></item>
</data>
<data type="Focus"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="string" width="100" ></item>
<item name="好友昵称" code="Name" type="string" width="120" ></item>
<item name="是否会员" code="VIP" type="string" width = "400" ></item>
<item name="会员等级" code="Level" type="string" width = "120" ></item>
<item name="关注时间" code="Time" type="string" width="120" ></item>
</data>
<data type="Fans"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="string" width="100" ></item>
<item name="好友昵称" code="Name" type="string" width="120" ></item>
<item name="是否会员" code="VIP" type="string" width = "400" ></item>
<item name="会员等级" code="Level" type="string" width = "120" ></item>
<item name="关注时间" code="Time" type="string" width="120" ></item>
</data>
<data type="Search"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="关键字" code="KeyWord" type="string" width="100" ></item>
<item name="搜索账号ID" code="ID" type="string" width="120" ></item>
<item name="时间" code="Time" type="string" width="120" ></item>
</data>
<data type="HomeMsg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="微博ID" code="ID" type="string" width="100" ></item>
<item name="内容" code="Content" type="string" width="120" ></item>
<item name="账号" code="Author" type="string" width = "120" ></item>
<item name="头像" code="Icon" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="原文作者" code="RAuthor" type="string" width = "120" ></item>
<item name="原文链接" code="Url" type="string" width="120" ></item>
</data>
<data type="Mention"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="微博ID" code="ID" type="string" width="100" ></item>
<item name="内容" code="Content" type="string" width="120" ></item>
<item name="账号" code="Author" type="string" width = "120" ></item>
<item name="头像" code="Icon" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width = "120" ></item>
<item name="原文作者" code="RAuthor" type="string" width = "120" ></item>
<item name="原文链接" code="Url" type="string" width="120" ></item>
</data>
<data type="Contact"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="string" width="100" ></item>
<item name="好友昵称" code="Name" type="string" width="120" ></item>
<item name="是否会员" code="VIP" type="string" width = "120" ></item>
<item name="会员等级" code="Level" type="string" width = "120" ></item>
<item name="性别" code="Gender" type="string" width="120" ></item>
</data>
<data type="Msg"  contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="消息ID" code="ID" type="string" width="100" ></item>
<item name="发送者" code="Sender" type="string" width="120" ></item>
<item name="接收者" code="Receiver" type="string" width = "120" ></item>
<item name="内容" code="Content" type="string" width = "120" ></item>
<item name="时间" code="Time" type="string" width="120" ></item>
</data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account() {
    this.NickName = "";
    this.ID = "";
    this.Summary = "";
    this.Gender = "";
    this.Birthday = "";
    this.RegTime = "";
    this.CurLoc = "";
    this.Home = "";
    this.JobTime = "";
    this.Company = "";
    this.SchoolYear = "";
    this.School = "";
    this.DataState = "Normal";
}

function Drafts() {
    this.ID = "";
    this.Content = "";
    this.CTime = "";
    this.MTime = "";
    this.RID = "";
    this.Author = "";
    this.RContent = "";
    this.DataState = "Normal";
}
function Info(){
    this.Acc = "";
}
function Focus() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
    this.VIP = "";
    this.Level = "";
    this.Time = "";
}
function Fans() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
    this.VIP = "";
    this.Level = "";
    this.Time = "";
}
function Search() {
    this.DataState = "Normal";
    this.KeyWord = "";
    this.ID = "";
    this.Time = "";
}
function HomeMsg() {
    this.DataState = "Normal";
    this.Content = "";
    this.ID = "";
    this.Author = "";
    this.Icon = "";
    this.Time = "";
    this.Url = "";
    this.RAuthor = "";
}
function Mention() {
    this.DataState = "Normal";
    this.Content = "";
    this.ID = "";
    this.Author = "";
    this.Icon = "";
    this.Time = "";
    this.Url = "";
    this.RAuthor = "";
}
function Contact() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
    this.VIP = "";
    this.Level = "";
    this.Gender = "";
}
function Msg() {
    this.DataState = "Normal";
    this.Sender = "";
    this.ID = "";
    this.Receiver = "";
    this.Time = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "腾讯微博";
    news.Type = "Info"; 
    //accountinfo = getAccount(db1);
    //news.Items = accountinfo;
    news.DataState = "Normal";
    
    var acc = new TreeNode();
    acc.Text = "账号信息";
    acc.Type = "Account";
    acc.Items =  getAccount(db1);
    acc.DataState = "Normal";
    news.TreeNodes.push(acc);
    
    var news1 = new TreeNode();
    news1.Text = "微博内容";
    news1.Type = "Info";
    accountinfo = getInfo(db);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    
       for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Acc;
        account.Type = "Info"; 
        news1.TreeNodes.push(account);
        
        var drafts = new TreeNode();
        drafts.Text = "草稿箱";
        drafts.Type = "Drafts";      
        drafts.Items = getDrafts(db1,accountinfo[i]);
        account.TreeNodes.push(drafts);
        
            
        var focus = new TreeNode();
        focus.Text = "关注";
        focus.Type = "Focus";      
        focus.Items = getFocus(db1,accountinfo[i]);
        account.TreeNodes.push(focus);
        
        var fans = new TreeNode();
        fans.Text = "粉丝";
        fans.Type = "Focus";      
        fans.Items = getFans(db1,accountinfo[i]);
        account.TreeNodes.push(fans);
        
        var search = new TreeNode();
        search.Text = "搜索";
        search.Type = "Search";      
        search.Items = getSearch(db1,accountinfo[i]);
        account.TreeNodes.push(search);
        
        var homemsg = new TreeNode();
        homemsg.Text = "首页";
        homemsg.Type = "HomeMsg";    
        //var abc = db+"\\"+accountinfo[i].Acc+"_msglist.db"; 
        var abc = XLY.Sqlite.DataRecovery(db+"\\"+accountinfo[i].Acc+"_msglist.db",charactor2,"home_msglist,metion_all_msglist,sessionpage__private_msg_ref_account,sessionpage__prviate_msg_msglist"); 
        homemsg.Items = getHomeMsg(abc);
        account.TreeNodes.push(homemsg);
        
        var mention = new TreeNode();
        mention.Text = "提到我的";
        mention.Type = "Mention";      
        mention.Items = getMention(abc);
        account.TreeNodes.push(mention);
        
        var contact = new TreeNode();
        contact.Text = "私信人";
        contact.Type = "Contact";
        var contactinfo = getContact(abc);       
        contact.Items = contactinfo;
        account.TreeNodes.push(contact);
        
        for(var j in contactinfo){  
            var message = new TreeNode();
            message.Text = contactinfo[j].ID;     
            message.Type = "Msg";
            message.Items = getMsg(abc,contactinfo[j],accountinfo);
            message.DataState = "Normal";    
            contact.TreeNodes.push(message);
        }
      }
result.push(news);
              
   
    
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from user_info_detail" ) +')');    
    for(var i in data){
        var obj = new Account();
        obj.NickName = data[i].nickname;
        obj.ID = data[i].wid;
        obj.Summary = data[i].summary;
         var a = data[i].gender;
  
        if(a==0){
            obj.Gender='未知';
        }
        else if(a==1){
            obj.Gender='男';
        }
        else
        {
            obj.Gender='女';
        }
        
        obj.Birthday = data[i].birthday_year+"年"+data[i].birthday_month+"月"+data[i].birthday_day+"日";
        obj.RegTime = XLY.Convert.LinuxToDateTime(data[i].regTime);
        obj.CurLoc = data[i].curLoc_country;
        obj.Home = data[i].home_country+"  "+data[i].home_city;
        obj.JobTime = data[i].company_year;
        obj.Company = data[i].companyName;
        obj.SchoolYear = data[i].schoolStartYear;
        obj.School = data[i].schoolName;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDrafts(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from drafts  where uin = '"+accountinfo.Acc+"'" ) +')');      
    for(var i in data){
        var obj = new Drafts();
        obj.ID = data[i].uin;
        obj.Content = data[i].content;
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.MTime = XLY.Convert.LinuxToDateTime(data[i].modifyed);
        obj.RID = data[i].relAccountId;
        obj.Author = data[i].subNick;
        obj.RContent = data[i].subContent;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFocus(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from light_account where uin = '"+accountinfo.Acc+"' and  type ='1'" ) +')');      
    for(var i in data){
        var obj = new Focus();
        obj.ID = data[i].name;
        obj.Name = data[i].nick;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.VIP = data[i].is_vip;
        obj.Level = data[i].member_vip_level;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFans(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from light_account where uin = '"+accountinfo.Acc+"' and  type ='3'" ) +')');      
    for(var i in data){
        var obj = new Fans();
        obj.ID = data[i].name;
        obj.Name = data[i].nick;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.VIP = data[i].is_vip;
        obj.Level = data[i].member_vip_level;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearch(path,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from search_keyword where uin = '"+accountinfo.Acc+"'" ) +')');  
    for(var i in data){
        var obj = new Search();
        obj.ID = data[i].uin;
        obj.KeyWord = data[i].keyword;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHomeMsg(path){
    var list = new Array();
    
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from home_msglist" ) +')');    
    for(var i in data){
        var obj = new HomeMsg();
        obj.ID = data[i].msg_id;
        obj.Author = data[i].author;
        obj.Icon = data[i].image_urls;
        obj.Content = data[i].content;
        obj.RAuthor = data[i].root_author;
        obj.Url = data[i].copy_link;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getMention(path){
    var list = new Array();
    var info1 = eval('('+ XLY.Sqlite.Find(path,"select * from  sqlite_master where tbl_name like '%metion_all_msglist%' " ) +')');
  if(info1 != null&&info1!=""){
 var data = eval('('+ XLY.Sqlite.Find(path,"select * from metion_all_msglist" ) +')');    
    for(var i in data){
        var obj = new Mention();
        obj.ID = data[i].msg_id;
        obj.Author = data[i].author;
        obj.Icon = data[i].image_urls;
        obj.Content = data[i].content;
        obj.RAuthor = data[i].root_author;
        obj.Url = data[i].copy_link;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
  } 
}  
   
function getContact(path){
    var list = new Array();
    var info1 = eval('('+ XLY.Sqlite.Find(path,"select * from  sqlite_master where tbl_name like '%ssionpage__private_msg_ref_accoun%' " ) +')');  
    
   if(info1 != null&&info1!=""){
      var data = eval('('+ XLY.Sqlite.Find(path,"select roomId,nickName,isVIP, member_vip_level,gender from sessionpage__private_msg_ref_account group by roomId" ) +')'); 
   
      for(var i in data){
        var obj = new Contact();
        obj.ID = data[i].roomId;
        obj.Name = data[i].nickName;
        obj.VIP = data[i].isVIP; 
        obj.Level = data[i].member_vip_level;
        var a = data[i].gender;
  
        if(a==0){
            obj.Gender='未知';
        }
        else if(a==1){
            obj.Gender='男';
        }
        else
        {
            obj.Gender='女';
        }
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
      }
    return list;
   }
}

function getMsg(path,contactinfo,accountinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from sessionpage__prviate_msg_msglist where roomId = '"+contactinfo.ID+"' " ) +')');
    for(var i in data){
     if(accountinfo[i] !=null && accountinfo[i] !=""){   
        var obj = new Msg();
        obj.ID = data[i].msg_id;
        obj.Sender = data[i].author;
        if(data[i].author==data[i].roomId){
            obj.Receiver = accountinfo[i].Acc;
        }
        else
        {
            obj.Receiver = data[i].roomId;
        }
        obj.Content = data[i].content;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
     }
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db2 = source[0]+"\\weibo";

var charactor1 = "\\chalib\\Android_TencentWeibo_V6.1.2\\weibo.charactor";
var charactor2 = "\\chalib\\Android_TencentWeibo_V6.1.2\\913.charactor";

var db1 = XLY.Sqlite.DataRecovery(db2,charactor1,"drafts,user_info_detail,light_account,search_keyword");
//var db9 = XLY.Sqlite.DataRecovery(db,charactor1,"homepage,url_input_record,history,bookmark,pc_bookmark");


function getInfo(db){
    var list = new Array();
    var filenames = eval('('+ XLY.File.FindFiles(db) +')');
    //log(filenames);
    var info = new Array();
    for(var index in filenames){
        
         
        var data = XLY.File.GetFileName(filenames[index]);
        
        if((/^[0-9]+\_msglist.db$/).test(data)) info.push(data.substring(0,data.indexOf("_")));
    }
    //log(info);
 
    for(var i in info){
        var obj = new Info();
         obj.Acc = info[i];
          list.push(obj);  
    }
    
     
      return list;
    
}



var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;

