﻿/*[config]
<plugin name="携程旅行,2" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/XieCheng.png" app="ctrip.com" version="5.4" description="携程旅行" data="$data,ComplexTreeDataSource" >
<source>
<value>ctrip.com</value>
</source>
<data type="User" contract="DataState" datefilter="time" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="城市" code="city" type="string" width="100" ></item>
<item name="联系电话" code="mobile" type="string" width="100" ></item>
<item name="登录时间" code="time" type="datetime" width="200" order="desc" ></item>
</data>
<data type="Attention" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="航班编号" code="id" type="string" width="100" ></item>
<item name="用户" code="user" type="string" width="100"></item>
<item name="出发地" code="departAddress" type="string" width="200"></item>
<item name="目的地" code="arriveAddress" type="string" width="200" ></item>
<item name="手机" code="mobile" type="string" width="100" ></item>
<item name="价格" code="price" type="string" width="100" ></item>
<item name="折扣" code="discount" type="string" width="100" ></item>
</data>
<data type="History" contract="DataState" datefilter="time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="城市" code="city" type="string" width="100" ></item>
<item name="时间" code="time" type="datetime" width="150" order="desc" ></item>
</data>
</plugin>
[config]*/

//定义数据结构
function User() {
    this.city = "";
    this.mobile = "";
    this.time = "";
    this.DataState ="Normal";
}

function Attention() {
    this.id = "";
    this.user = "";
    this.departAddress = "";
    this.arriveAddress = "";
    this.mobile = "";
    this.price = "";
    this.discount = "";
    this.DataState ="Normal";
}

function History() {
    this.city = "";
    this.time = "";
    this.DataState ="Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState ="Normal";
}

//用户信息
function userNodeCreate(path) {
    var obj = new User();
    var arr = new Array();
    try{
        var data = eval('(' + XLY.Sqlite.Find(path, "select item_key,item_value,XLY_DataType from user_info  ") + ')');
        for (var index in data) {

            if (data[index].item_key == "defaultContactMobile") {
                obj.mobile = data[index].item_value;
                obj.DataState=XLY.Convert.ToDataState(data[index].XLY_DataType); 
            }
            if (data[index].item_key == "cityName") {
                obj.city = data[index].item_value;
            }
            if (data[index].item_key == "checkInDate") {
                obj.time = XLY.Convert.ToDateTime(data[index].item_value, "yyyyMMdd");
            } 

        }
        arr.push(obj);

        return arr;
    }
    catch(e){
        return arr;
    }
}

//关注信息
function attNodeCreate(path) {
    var arr = new Array();
    try{
        var info = eval('(' + XLY.Sqlite.Find(path, "select taskId,userId,departCityName,arriveCityName,mobilephone,XLY_DataType from attention_airLine  ") + ')');
        for (var index in info) {
            var obj = new Attention();
            obj.id = info[index].taskId;
            obj.user = info[index].userId;
            obj.departAddress = info[index].departCityName;
            obj.arriveAddress = info[index].arriveCityName;
            obj.mobile = info[index].mobilephone;
            obj.DataState=XLY.Convert.ToDataState(info[index].XLY_DataType); 
            var data = eval('(' + XLY.Sqlite.Find(path, "select discoundRate,price from attention_airLine_detail where taskId=" + obj.id + " ") + ')');
            if(data[0]){
                obj.price =data[0].price;
                obj.discount = data[0].discoundRate;


            }
            arr.push(obj);

        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

//历史记录
function hisNodeCreate(path) {
    var arr = new Array();
    try{
        data = eval('(' + XLY.Sqlite.Find(path, "select cityName,cast(date as TEXT)as date,XLY_DataType from  city_query_history where date !='0' ") + ')');
        for (var index in data) {
            var obj = new History();
            obj.city = data[index].cityName;
            if(data[index].date/10000000000000 >=2){
                obj.time = XLY.Convert.ToDateTime(data[index].date,"yyyyMMddHHmmss");
            }
            else
            {
                obj.time ="";
            }
            obj.DataState=XLY.Convert.ToDataState(data[index].XLY_DataType); 
            arr.push(obj);
        }
        return arr;
    }
    catch(e){
        return arr;
    }
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0] + "\\ctrip.com\\Documents\\ctrip_userinfo.db";
//var path1 = "C:\\XLYSFTasks\\任务-2016-04-21-12-09-14\\source\\IosData\\2016-04-21-12-09-46\\8c5fdfb12d1dc920fa571712932cf5e5727dfca7\\ctrip.com\\Documents\\ctrip_userinfo.db";
//数据恢复库的生成
var charactor="chalib\\IOS_XieCheng_V5.4\\ctrip_userinfo.db.charactor";
path1=XLY.Sqlite.DataRecovery( path1,charactor ,"attention_airLine,attention_airLine_detail,city_query_history,user_info");

//节点实例化
var userNode = new TreeNode();
userNode.Text = "用户基本信息";
userNode.Type = "User";
var attNode = new TreeNode();
attNode.Text = "机票低价订阅"
    attNode.Type = "Attention";
var hisNode = new TreeNode();
hisNode.Text = "城市查询记录";
hisNode.Type = "History";

//填充树
userNode.Items = userNodeCreate(path1);
attNode.Items = attNodeCreate(path1);
hisNode.Items = hisNodeCreate(path1);

//打印数据
result.push(userNode);
result.push(attNode);
result.push(hisNode);
var res = JSON.stringify(result);
res;
