﻿/*[config]
<plugin name="有信,3" group="社交聊天,6" devicetype="android" icon="\icons\YX.png" pump="LocalData,USB,Mirror,Wifi,Bluetooth,chip" app="com.yx" version="6.3.0" description="有信" data="$data,ComplexTreeDataSource">
<source>
    <value>/data/data/com.yx/databases#F</value>
    <value>/data/data/com.yx/shared_prefs#F</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="列表" code="Account" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="有信ID" code="UID" type="string"  width = "100"></item>
    <item name="昵称" code="NickName" type="string" width = "100"></item>
    <item name="性别" code="Sex" type="string" width = "80"></item>
    <item name="是否当前登录" code="IsLoading" type="string" width = "80"></item>
    <item name="出生日期" code="Birthday" type="string" width = "120"></item>
    <item name="个性签名" code="Signature" type="string" width = "150"></item>
    <item name="手机号码" code="MobileNumber" type="string" width = "120"></item>
    <item name="邮箱" code="Email" type="string" width = "120"></item>
    <item name="头像" code="HeadUrl" type="url" width = "120"></item>
</data>
<data type="FollowInfo" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="有信ID" code="UID" type="string"  width = "100"></item>
    <item name="昵称" code="NickName" type="string" width = "100"></item>
    <item name="性别" code="Sex" type="string" width = "80"></item>
    <item name="出生日期" code="Birthday" type="string" width = "120"></item>
    <item name="个性签名" code="Signature" type="string" width = "150"></item>
    <item name="手机号码" code="MobileNumber" type="string" width = "120"></item>
    <item name="邮箱" code="Email" type="string" width = "120"></item>
    <item name="头像" code="HeadUrl" type="url" width = "120"></item>
    <item name="最后登录时间" code="LastUpdate" type="string" width = "120"></item>
</data>
<data type="CallLog" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="有信ID" code="Uid" type="string"  width = "100"></item>
    <item name="电话号码" code="PhoneNumber" type="string"  width = "120"></item>
    <item name="名称" code="Name" type="string" width = "120"></item>
    <item name="地点" code="Location" type="string" width = "120"></item>
    <item name="通话时长" code="CallLenth" type="string" width = "80"></item>
    <item name="通话类型" code="CallType" type="string" width = "80"></item>
    <item name="通话时间" code="CallTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Contact" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="有信ID" code="UID" type="string"  width = "100"></item>
    <item name="电话号码" code="PhoneNumber" type="string" width = "120"></item>
    <item name="名称" code="CallName" type="string" width = "120"></item>
    <item name="地点" code="Location" type="string" width = "120"></item>
</data>
<data type="Message" contract = "DataState" detailfield = "Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="发送者ID" code="SenderID" type="string" width = "150"></item>
    <item name="发送者" code="Sender" type="string" width = "150"></item>
    <item name="接收者ID" code="ReceiverID" type="string" width = "200"></item>
    <item name="接收者" code="Receiver" type="string" width = "200"></item>
    <item name="内容" code="Content" type="string" width = "150"></item>
    <item name="创建时间" code="CreateTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="类型" code="Type" type="string"  width = "150"></item>
</data>
</plugin>
[config]*/
//定义News数据结构
function News(){
    this.Account = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UID = "";
    this.NickName = "";
    this.Sex = "未知";
    this.Birthday = "";
    this.Signature = "";
    this.MobileNumber = "";
    this.Email = "";
    this.HeadUrl = "";
    this.IsLoading = "否";
}
//定义FollowInfo数据结构
function FollowInfo(){
    this.DataState = "Normal";
    this.UID = "";
    this.NickName = "";
    this.Sex = "未知";
    this.Birthday = "";
    this.Signature = "";
    this.MobileNumber = "";
    this.Email = "";
    this.HeadUrl = "";
    this.LastUpdate = "";
}
//定义CallLog数据结构
function CallLog(){
    this.DataState = "Normal";
    this.Uid = "";
    this.PhoneNumber = "";
    this.Name = "";
    this.Location = "";
    this.CallLenth = "";
    this.CallType = "";
    this.CallTime = null;
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.UID = "";
    this.PhoneNumber = "";
    this.CallName = "";
    this.Location = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.Sender = "";
    this.ReceiverID = "";
    this.Receiver = "";
    this.Content = "";
    this.CreateTime = null;
    this.Type = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allDatabasePath = source[0];
var allXmlPath = source[1];
//测试数据
//var allDatabasePath = "C:\\XLYSFTasks\\任务-2017-08-31-16-33-37\\source\\data\\data\\com.yx\\databases";
//var allXmlPath = "C:\\XLYSFTasks\\任务-2017-08-31-16-33-37\\source\\data\\data\\com.yx\\shared_prefs";
//var messagePath = "";
//定义特征库文件
//var naverLinePathcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Line_V7.1.1\\naver_line.charactor";
//var e2eePathcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Line_V7.1.1\\e2ee.charactor";

var charactor1 = "\\chalib\\Android_YouXin_V6.3.0\\youxin_db_227213423.charactor";

var charactor2 = "\\chalib\\Android_YouXin_V6.3.0\\yx_new_messages.charactor";
//恢复数据库中删除的数据
//var naverLinePath = XLY.Sqlite.DataRecovery(charactor1,naverLinePathcharactor,"chat_history,contacts,groups,membership");
//var e2eePath = XLY.Sqlite.DataRecovery(e2eePath1,e2eePathcharactor,"keystore");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "有信";
    root.Type = "News";
    getList(root);
    result.push(root);
}
//获取当前用户
function getList(root){
    var userid = eval('('+ XLY.File.FindFileNamesWithExtension(allXmlPath) +')');
    if(userid!=""&&userid!=null){
        var reg = new RegExp("SPNAME.xml");
        var arrUserId = new Array();
        for(var i in userid){
            if(reg.test(userid[i])){
                if(userid[i].length>10){
                    var id = userid[i].substr(0,userid[i].length-10)
                    var idDatabasePath = allDatabasePath+"\\youxin_db_"+id;
                    //var idDatabasePath = XLY.Sqlite.DataRecovery(idDatabasePath1,charactor1,"MY_NAME_CARD,FRIEND_TABLE,contact,call_log");
                    if(XLY.File.IsValid(idDatabasePath)){
                        var dataUser = eval('('+ XLY.Sqlite.Find(idDatabasePath,"select NAME,GENDER,SIGNATURE,USERID,MOBILE_NUMBER,EMAIL,BIRTHDAY,PHOTO_LOCATION from MY_NAME_CARD") +')');
                        if(dataUser!=""&&dataUser!=null){
                            var userNode = new TreeNode();
                            userNode.Text = dataUser[0].USERID+"_"+dataUser[0].NAME;
                            userNode.Type = "UserInfo";
                            var objUser = new UserInfo();
                            //objUser.DataState = XLY.Convert.ToDataState(dataUser[0].XLY_DataType);
                            objUser.UID = dataUser[0].USERID;
                            objUser.NickName = dataUser[0].NAME;
                            if(dataUser[0].GENDER!=""&&dataUser[0].GENDER!=null){
                                objUser.Sex = dataUser[0].GENDER;
                            }
                            var dataUserID = eval('('+ XLY.Sqlite.Find(idDatabasePath,"select UID from PROFILE_TABLE where UID = '"+dataUser[0].USERID+"'") +')');
                            if(dataUserID!=""&&dataUserID!=null){
                                objUser.IsLoading = "是";
                            }
                            objUser.Birthday = dataUser[0].BIRTHDAY;
                            objUser.Signature = dataUser[0].SIGNATURE;
                            objUser.MobileNumber = dataUser[0].MOBILE_NUMBER;
                            objUser.Email = dataUser[0].EMAIL;
                            objUser.HeadUrl = dataUser[0].PHOTO_LOCATION;
                            userNode.Items.push(objUser);
                            arrUserId.push(dataUser[0].USERID)
                            getUserChildInfo(userNode,idDatabasePath,dataUser[0].USERID,dataUser[0].NAME);
                            root.TreeNodes.push(userNode);
                        }
                    }
                }
            }
        }
        //if(arrUserId!=""&&arrUserId!= null){
        //    var tableArr = "";
        //    for(var i in arrUserId){
        //        if(i<arrUserId.length-1){
        //            tableArr+= "messages"+arrUserId[i]+",";
        //        }
        //        else
        //        {
        //            tableArr+= "messages"+arrUserId[i];
        //        }
        //    }
        //    var messagePath1 = allDatabasePath+"\\yx_new_messages";
        //    messagePath = XLY.Sqlite.DataRecovery(messagePath1,charactor2,tableArr);
        //}
    }
}
function getUserChildInfo(root,path,userid,username){
    var contactData = eval('('+ XLY.Sqlite.Find(path,"select UID,NUMBER,NAME,LOCATION from contact") +')');
    if(contactData!=""&&contactData!=null){
        var contactNode = new TreeNode();
        contactNode.Text = "联系人";
        contactNode.Type = "Contact";
        for(var i in contactData){
            var objContact = new Contact();
            //objContact.DataState = XLY.Convert.ToDataState(contactData[i].XLY_DataType);
            objContact.UID = contactData[i].UID;
            objContact.PhoneNumber = contactData[i].NUMBER;
            objContact.CallName = contactData[i].NAME;
            objContact.Location = contactData[i].LOCATION;
            contactNode.Items.push(objContact);
        }
        root.TreeNodes.push(contactNode);
    }
    var CallLogData = eval('('+ XLY.Sqlite.Find(path,"select UID,NUMBER,NAME,LOCATION,DATE,TYPE,DURATION from call_log") +')');
    if(CallLogData!=""&&CallLogData!=null){
        var callLogNode = new TreeNode();
        callLogNode.Text = "通话记录";
        callLogNode.Type = "CallLog";
        for(var i in CallLogData){
            var objCallLog = new CallLog();
            //objCallLog.DataState = XLY.Convert.ToDataState(CallLogData[i].XLY_DataType);
            objCallLog.Uid = CallLogData[i].UID;
            objCallLog.PhoneNumber = CallLogData[i].NUMBER;
            objCallLog.Name = CallLogData[i].DATE;
            objCallLog.Location = CallLogData[i].LOCATION;
            objCallLog.CallLenth = CallLogData[i].DATE;
            if(CallLogData[i].TYPE==1){
                objCallLog.CallType = "拨打";
            }
            else if(CallLogData[i].TYPE==2){
                objCallLog.CallType = "接听";
            }
            else if(CallLogData[i].TYPE==3){
                objCallLog.CallType = "未接";
            }
            
            objCallLog.CallTime = XLY.Convert.LinuxToDateTime(CallLogData[i].DATE);
            callLogNode.Items.push(objCallLog);
        }
        root.TreeNodes.push(callLogNode);
    }
    var followData = eval('('+ XLY.Sqlite.Find(path,"select UID,MOBILE_NUMBER,NAME,SEX,SIGNATURE,EMAIL,BIRTHDAY,LASTUPDATE,PICTURE from PROFILE_TABLE where UID<>'"+userid+"'") +')');
    if(followData!=""&&followData!= null){
        var followNode = new TreeNode();
        followNode.Text = "粉丝";
        followNode.Type = "FollowInfo";
        for(var i in followData){
            var objFollow = new FollowInfo();
            //objFollow.DataState = XLY.Convert.ToDataState(followData[i].XLY_DataType);
            objFollow.UID = followData[i].UID;
            objFollow.NickName = followData[i].NAME;
            if(followData[i].SEX!=""&&followData[i].SEX!=null){
                objFollow.Sex = followData[i].SEX;
            }
            objFollow.Birthday = followData[i].BIRTHDAY;
            objFollow.Signature = followData[i].SIGNATURE;
            objFollow.MobileNumber = followData[i].MOBILE_NUMBER;
            objFollow.Email = followData[i].EMAIL;
            objFollow.HeadUrl = followData[i].PICTURE;
            objFollow.LastUpdate = followData[i].LASTUPDATE;
            followNode.Items.push(objFollow);
        }
        root.TreeNodes.push(followNode);
    }
    var table = "messages"+userid;
    var messagePath1 = allDatabasePath+"\\yx_new_messages";
    var messagePath = XLY.Sqlite.DataRecovery(messagePath1,charactor2,table,true);
    if(XLY.File.IsValid(messagePath)){
        var messageTableData = eval('('+ XLY.Sqlite.Find(messagePath,"select tbl_name from sqlite_master") +')');
        if(messageTableData!=""&&messageTableData!=null){
            for(var i in messageTableData){
                if(messageTableData[i].tbl_name=="messages"+userid){
                    var messageNode = new TreeNode();
                    messageNode.Text = "好友聊天记录";
                    messageNode.Type = "Message";
                    var threadId = eval('('+ XLY.Sqlite.Find(messagePath,"select distinct(thread_id) from '"+messageTableData[i].tbl_name+"'") +')');
                    if(threadId!=""&&threadId!=null){
                        for(var j in threadId){
                            var threadIdData = eval('('+ XLY.Sqlite.Find(messagePath,"select XLY_DataType,date,read,type,body,extra_uri,uid from '"+messageTableData[i].tbl_name+"' where thread_id='"+threadId[j].thread_id+"'") +')');
                            if(threadIdData!=""&&threadIdData!=null){
                                var messageThreadNode = new TreeNode();
                                var uname = eval('('+ XLY.Sqlite.Find(path,"select NAME from PROFILE_TABLE where UID = '"+threadIdData[0].uid+"'") +')');
                                if(threadIdData[0].uid=="8000"){
                                    messageThreadNode.Text = "有信团队";
                                }
                                else
                                {
                                    if(uname!=""&&uname!=null){
                                        messageThreadNode.Text = uname[0].NAME+"_"+threadIdData[0].uid;
                                    }
                                    else
                                    {
                                        messageThreadNode.Text = threadIdData[0].uid;
                                    }
                                }
                                messageThreadNode.Type = "Message";
                                for(var a in threadIdData){
                                    var objMessageThread = new Message();
                                    objMessageThread.DataState = XLY.Convert.ToDataState(threadIdData[a].XLY_DataType);
                                    if(threadIdData[a].type==0){
                                        objMessageThread.SenderID = threadIdData[a].uid;
                                        if(threadIdData[a].uid=="8000"){
                                            objMessageThread.Sender = "有信团队";
                                        }
                                        else
                                        {
                                            if(uname!=""&&uname!=null){
                                                objMessageThread.Sender = uname[0].NAME;
                                            }
                                        }
                                        objMessageThread.ReceiverID = userid;
                                        objMessageThread.Receiver = username;
                                    }
                                    if(threadIdData[a].type==1){
                                        objMessageThread.SenderID = userid;
                                        objMessageThread.Sender = username;
                                        if(uname!=""&&uname!=null){
                                            objMessageThread.Receiver = uname[0].NAME;
                                        }
                                        objMessageThread.ReceiverID = threadIdData[a].uid;
                                    }
                                    objMessageThread.Content = threadIdData[a].body;
                                    objMessageThread.CreateTime = XLY.Convert.LinuxToDateTime(threadIdData[a].date);
                                    //objMessageThread.Type = threadIdData[a].XLY_DataType;
                                    messageThreadNode.Items.push(objMessageThread);
                                }
                                messageNode.TreeNodes.push(messageThreadNode);
                            }
                        }
                    }
                    root.TreeNodes.push(messageNode);
                }
            }
        }
    }
}