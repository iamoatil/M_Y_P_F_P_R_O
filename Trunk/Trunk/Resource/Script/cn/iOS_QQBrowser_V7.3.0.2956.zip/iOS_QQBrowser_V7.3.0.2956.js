﻿/*[config]
<plugin name="QQ浏览器,6" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/qqbrowser.png" app="com.tencent.mttlite" version="7.3.0.2956" description="QQ浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.tencent.mttlite</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width="200" format = "" ></item>
    <item name="用户昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="头像链接地址" code="UserHeadUrl" type="url" width="200" format=""></item>
    <item name="首次登录时间" code="FirstLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="最后登录时间" code="LastLanchTime"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="在线时间" code="TotalUpTime" type="string" width="200" format = "" ></item>
    <item name="退出是否删除数据" code="ExitClearHistory" type="string" width="100" format="" ></item>
</data>
<data type="History" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="300" format = ""></item>
    <item name="历史浏览地址" code="Url" type="url" width="200" format = ""></item>
    <item name="浏览时间" code="Created" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="浏览次数" code="VisitCount" type="string" width="200" format = ""></item>
</data>
<data type="Bookmark" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="主题" code="Title" type="string" width="300" format = ""></item>
    <item name="网址" code="Url" type="url" width="500" format=""></item>
    <item name="创建时间" code="Created" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Download" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="文件名" code="fileName" type="string" width="100" format = ""></item>
    <item name="下载链接" code="Url" type="url" width="400" format=""></item>
    <item name="存储路径" code="SavePath" type="string" width="200" format = ""></item>
    <item name="开始时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="总大小(byte)" code="TotalBytes" type="string" width="100" format=""></item>
    <item name="实际下载大小(byte)" code="ActualBytes" type="string" width="100" format=""></item>
    <item name="状态" code="fileStatus" type="string" width="200" format = ""></item>
</data>
<data type="SearchWords" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="搜索关键字" code="SearchWord" type="string" width="200" format = ""></item>
    <item name="搜索时间" code="EndTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.UserNickName = "";
    this.LastLanchTime = null;
    this.FirstLanchTime = null;
    this.TotalUpTime = "";
    this.ExitClearHistory = "";
    this.UserHeadUrl = "";
}
//定义History数据结构
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Created = null;
    this.VisitCount = "";
}
//定义Bookmark数据结构
function Bookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Created = null;
}
//定义Download数据结构
function Download(){
    this.DataState = "Normal";
    this.Url = "";
    this.SavePath = "";
    this.StartTime = null;
    this.TotalBytes = "";
    this.ActualBytes = "";
    this.fileName = "";
    this.fileStatus = "";
}
//定义SearchWords数据结构
function SearchWords(){
    this.DataState = "Normal";
    this.SearchWord = "";
    this.EndTime = null;
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0]+"\\com.tencent.mttlite\\Documents\\.mttlite";
var cookPath = source[0]+"\\com.tencent.mttlite\\Library\\Cookies\\Cookies.binarycookies";

//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-03-29-14-03-01\\source\\IosData\\2017-03-29-14-04-10\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.mttlite\\Documents\\.mttlite";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-03-29-14-03-01\\source\\IosData\\2017-03-29-14-04-10\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.tencent.mttlite\\Library\\Cookies\\Cookies.binarycookies";
//定义特征库文件
var charactor1 = "chalib\\iOS_QQBrowser_V7.3.0.2956\\commonDatabase.db.charactor";
var charactor2 = "chalib\\iOS_QQBrowser_V7.3.0.2956\\mttData2959741893.db.charactor";
//恢复数据库中删除的数据
//var recoverypath1 = XLY.Sqlite.DataRecovery(path1, charactor, "favorites");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "QQ浏览器";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var commonPath = eval('('+ XLY.File.FindFileNamesWithExtension(allPath) +')');
    var data = ["历史记录","Cache缓存","下载记录","经常访问"];
    var aa = "commonDatabase.db";
    var accountPath1 = allPath+"\\"+aa;
    //var accountPath = XLY.Sqlite.DataRecovery(accountPath1,charactor1,"history,FrequentVisit,downloads_New");
    var accountPath = XLY.Sqlite.DataRecovery(accountPath1,charactor1,"history,FrequentVisit,downloads_New",true);
    var reg = new RegExp("mttData","i");
    var regrec  = new RegExp("recovery","i");
    for(var i in commonPath){
        if(reg.test(commonPath[i])){
            if(regrec.test(commonPath[i])){
                //该判断用于过滤掉所有的账号中带有_recovery的账号数据库，如mttData_recovery.db
            }
            else
            {
                if(commonPath[i].length==10){
                    var obj = new News();
                    obj.List = "默认账户";
                    root.Items.push(obj);
                    var node = new TreeNode();
                    node.Text = obj.List;
                    node.Type = "News";
                    getAccount(node,commonPath[i]);
                    root.TreeNodes.push(node);
                }
                else
                {
                    var obj = new News();
                    obj.List = commonPath[i].substr(7,commonPath[i].length).split(".")[0];
                    root.Items.push(obj);
                    var node = new TreeNode();
                    node.Text = obj.List;
                    node.Type = "News";
                    getAccount(node,commonPath[i]);
                    root.TreeNodes.push(node);
                }
            }
        }
    }
    for(var j in data){
        var obj = new News();
        obj.List = data[j];
        root.Items.push(obj);
        var node = new TreeNode();
        node.Text = data[j];
        if(data[j]=="历史记录"){
            node.Type = "History";
            getHistory(node,accountPath);
        }
        if(data[j]=="下载记录"){
            node.Type = "Download";
            getDownload(node,accountPath);
        }
        if(data[j]=="经常访问"){
            node.Type = "History";
            getFrequentVisit(node,accountPath);
        }
        if(data[j]=="Cache缓存"){
            node.Type = "Cache";
            getCache(node);
        }
        root.TreeNodes.push(node);
    }
}
function getAccount(root,info){
    var accountPath1 = allPath+"\\"+info;
    var accountPath = XLY.Sqlite.DataRecovery(accountPath1,charactor2,"bookmarks,quicklinks,searchInputs,searchInputAction");
    if(XLY.File.IsValid(accountPath)){
        var data = eval('('+ XLY.Sqlite.Find(accountPath,"select * from bookmarks") +')');
        if(data!=""&&data!=null){
            var node = new TreeNode();
            node.Text = "书签";
            node.Type = "Bookmark";
            var childdata1 = eval('('+ XLY.Sqlite.Find(accountPath,"select * from quicklinks") +')');
            if(childdata1!=""&&childdata1!=null){
                for(var b in childdata1){
                    var obj3 = new Bookmark();
                    obj3.DataState = XLY.Convert.ToDataState(childdata1[b].XLY_DataType);
                    obj3.Title = childdata1[b].name;
                    obj3.Url = childdata1[b].url;
                    obj3.Created = XLY.Convert.LinuxToDateTime(childdata1[b].insert_date);
                    node.Items.push(obj3);
                }
            }
            
            var obj2 = new News();
            obj2.List = node.Text;
            root.Items.push(obj2);
            var ccccccc = 0;
            for(var j in data){
                if(data[j].parent==0){
                    getBookMarkNode(accountPath,node,data[j]);
                }
            }
            root.TreeNodes.push(node);
        }
        var dataSearch = eval('('+ XLY.Sqlite.Find(accountPath,"select * from searchInputs")+')');
        if(dataSearch!=""&&dataSearch!=null){
            var node = new TreeNode();
            node.Text = "搜索关键字";
            node.Type = "SearchWords"
            for(var i in dataSearch){
                var obj = new SearchWords();
                obj.DataState = XLY.Convert.ToDataState(dataSearch[i].XLY_DataType);;
                obj.SearchWord = dataSearch[i].content;
                obj.EndTime = XLY.Convert.LinuxToDateTime(dataSearch[i].operationTime);
                node.Items.push(obj);
            }
            var obj2 = new News();
            obj2.List = node.Text;
            root.Items.push(obj2);
            root.TreeNodes.push(node);
        }
    }
}
function getHistory(root,accountPath){
    //var accountPath1 = allPath+"\\"+info;
    //var accountPath = XLY.Sqlite.DataRecovery(accountPath1,charactor1,"history,FrequentVisit,downloads_New");
    if(XLY.File.IsValid(accountPath)){
        var data = eval('('+ XLY.Sqlite.Find(accountPath,"select * from history") +')');
        for(var i in data){
            var obj = new History();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.Title = data[i].content;
            var aa = data[i].visited_date+978307200;
            obj.Created = XLY.Convert.LinuxToDateTime(aa);
            //var aa = obj.Created.substr(0,4)+31;
            obj.Title = data[i].title;
            obj.Url = data[i].url;
            obj.VisitCount = data[i].visited_count;
            root.Items.push(obj);
        }
    }
}
function getFrequentVisit(root,accountPath){
    //var accountPath1 = allPath+"\\"+info;
    //var accountPath = XLY.Sqlite.DataRecovery(accountPath1,charactor1,"history,FrequentVisit,downloads_New");
    if(XLY.File.IsValid(accountPath)){
        var data = eval('('+ XLY.Sqlite.Find(accountPath,"select * from FrequentVisit") +')');
        for(var i in data){
            var obj = new History();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.Title = data[i].content;
            var aa = data[i].visited_date+978307200;
            obj.Created = XLY.Convert.LinuxToDateTime(aa);
            obj.Title = data[i].title;
            obj.Url = data[i].url;
            obj.VisitCount = data[i].visited_count;
            root.Items.push(obj);
        }
    }
}
function getDownload(root,accountPath){
    //var accountPath1 = allPath+"\\"+info;
    //var accountPath = XLY.Sqlite.DataRecovery(accountPath1,charactor1,"history,FrequentVisit,downloads_New");
    if(XLY.File.IsValid(accountPath)){
        var data = eval('('+ XLY.Sqlite.Find(accountPath,"select * from downloads_New") +')');
        for(var i in data){
            var obj = new Download();
            obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
            obj.Url = data[i].url;
            obj.SavePath = data[i].path;
            obj.StartTime = XLY.Convert.LinuxToDateTime(data[i].time);
            obj.TotalBytes = data[i].total;
            obj.ActualBytes = data[i].downsize;
            obj.fileName = data[i].filename;
            if(data[i].status==11){
                obj.fileStatus = "下载完成";
            }
            else if(data[i].status==5){
                obj.fileStatus = "下载中断";
            }
            else
            {
                obj.fileStatus = "下载异常";
            }
            root.Items.push(obj);
        }
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
function getBookMarkNode(accountPath,root,info){
    if(info!=""&&info!= null){
        if(info.parent==0){
            var childdata = eval('('+ XLY.Sqlite.Find(accountPath,"select * from bookmarks where parent = '"+info.id+"'") +')');
            if(childdata!=""&&childdata!=null){
                for(var a in childdata){
                    if(childdata[a].type==0){
                        var obj = new Bookmark();
                        obj.DataState = XLY.Convert.ToDataState(childdata[a].XLY_DataType);
                        obj.Title = childdata[a].title;
                        obj.Url = childdata[a].url;
                        obj.Created = XLY.Convert.LinuxToDateTime(childdata[a].insert_date);
                        root.Items.push(obj);
                    }
                    else
                    {
                        var child = new TreeNode();
                        child.Text = childdata[a].title;
                        child.Type = "Bookmark";
                        child.DataState = XLY.Convert.ToDataState(childdata[a].XLY_DataType);
                        getBookMarkNode(accountPath,child,childdata[a]);
                        root.TreeNodes.push(child);
                    }
                }
            }
        }
        else
        {
            var childdata = eval('('+ XLY.Sqlite.Find(accountPath,"select * from bookmarks where parent = '"+info.id+"'") +')');
            if(childdata!=""&&childdata!=null){
                for(var a in childdata){
                    if(childdata[a].type==0){
                        var obj = new Bookmark();
                        obj.DataState = XLY.Convert.ToDataState(childdata[a].XLY_DataType);
                        obj.Title = childdata[a].title;
                        obj.Url = childdata[a].url;
                        obj.Created = XLY.Convert.LinuxToDateTime(childdata[a].insert_date);
                        root.Items.push(obj);
                    }
                    else
                    {
                        var child = new TreeNode();
                        child.Text = childdata[a].title;
                        child.Type = "Bookmark"; 
                        child.DataState = XLY.Convert.ToDataState(childdata[a].XLY_DataType);
                        getBookMarkNode(accountPath,child,childdata[a]);
                        root.TreeNodes.push(child);
                    }
                }
            }
        }
    }
}