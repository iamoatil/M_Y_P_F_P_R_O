﻿/*[config]
<plugin name="YY语音,11" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,LocalData" icon="\icons\YY.png" app="com.duowan.mobile" version="5.12.2" description="YY语音" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.duowan.mobile/databases</value>
<value>/data/data/com.duowan.mobile/shared_prefs/LatestAccessPref.xml</value>
</source>
<data type="News" contract="DataState" datefilter = "LastPlayTime">
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="用户ID" code="ID" type="string" width="120" format=""></item>
<item name="用户名称" code="Name" type="string" width="150" format=""></item>
<item name="昵称" code="NickName" type="string" width="120" format=""></item>
<item name="签名" code="Signature" type="string" width="200" format=""></item>
<item name="性别" code="Gender" type="string" width="100" format = ""></item>
<item name="个人简介" code="Description" type="string" width="100" format=""></item>
<item name="生日" code="Birthday" type="string" width="150" format=""></item>
<item name="最后登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc" ></item>
</data>
<data type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群组名" code="Name" type="string" width="" format = ""></item>
<item name="组ID" code="ID" type="string" width="120" format = ""></item>
<item name="头像" code="Icon" type="string" width = "140" ></item>
<item name="群ID" code="GID" type="string" width="120" format = ""></item>
<item name="组ID MD5" code="MD5" type="string" width = "140" ></item>
<item name="公告" code="Bulletin" type="string" width = "140" ></item>
<item name="群简介" code="Desc" type="string" width = "140" ></item>
<item name="创建时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Friend" detailfield="HeadImage" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="string" width = "140" ></item>
<item name="备注" code="Reserve" type="string" width = "140" ></item>
<item name="头像" code="Icon" type="string" width = "140" ></item>
<item name="好友ID MD5" code="MD5" type="string" width="140" ></item>
<item name="昵称" code="Name" type="string" width="150" format=""></item>
<item name="签名" code="Sign" type="string" width="150" format=""></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="头像地址" code="HeadImage" type="string" width="100" format=""></item>
<item name="最后登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="生日" code="Birthday" type="string" width="100" format=""></item>
</data>
<data type="FMessage" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送者" code="SenderName" type="string" width="120" ></item>
<item name="接收者" code="ReceiveName" type="string" width="120" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="时间" code="Time" type="string" width="300" ></item>
</data>
<data type="GMessage" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="发送者ID" code="SenderId" type="string" width="120" ></item>
<item name="发送者" code="SenderName" type="string" width="120" ></item>
<item name="接收者" code="ReceiverName" type="string" width="120" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="时间" code="Time" type="string" width="300" ></item>
</data>
<data type="Channel" detailfield="Icon" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="频道ID" code="ChannelID" type="int" width="140" ></item>
<item name="频道名称" code="ChannelName" type="string" width="200" format = ""></item>
<item name="头像" code="Icon" type="string" width = "140" ></item>
</data>
</plugin>
[config]*/

//*******************************************定义数据结构********************************************
function News(){
    this.List = "";
    this.DataState = "Normal";
}
function Account() {
    this.DataState = "Normal";
    this.ID = "";
    this.Name = "";
    this.Time = null;
    this.Gender = "";
    this.NickName = "";
    this.Description="";
    this.Signature="";
    this.Birthday="";
}
function Group() {
    this.DataState = "Normal";
    this.Name = "";
    this.DName = "";
    this.ID = "";
    this.GID = "";
    this.MD5 = "";
    this.Icon = "";
    this.Bulletin = "";
    this.Desc = "";
    this.Time = "";                                             
}
function Friend() {
    this.DataState = "Normal";
    this.Name = "";
    this.Time = null;
    this.Sign = "";
    this.ID = "";
    this.MD5 = "";
    this.Icon = "";
    this.Reserve = "";
    this.Gender = "";
    this.HeadImage = "";
    this.Birthday = "";
}
function FMessage() {
    this.SenderName = "";
    this.ReceiveName = "";
    this.Content = "";
    this.Time = "";
    this.DataState = "Normal";
}
function GMessage() {
    this.SenderName = "";
    this.SenderId = "";
    this.ReceiverName = "";
    this.Content = "";
    this.Time =  "";
    this.DataState = "Normal";
}
//定义Channel数据结构
function Channel() {
    this.DataState = "Normal";
    this.ChannelID = "";
    this.ChannelName = "";
    this.Icon = "";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
} 
function bindTree(){
    var news = new TreeNode();
    news.Text = "YY语音";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
          
    var userinfo = getAccount(db);
    var userNode = newTreeNode("用户信息","Account",userinfo,news);
    var channelinfo = getChannel(db2);
    var channelNode = newTreeNode("访问的频道","Channel",channelinfo,news);
    for(var i in userinfo){
        var accNode = newTreeNode(userinfo[i].NickName,"Account",userinfo,userNode);
        var db1 = db3+"\\"+userinfo[i].ID+".db";
        var friendinfo = getFriend(db1,userinfo[i]);
        var friendNode = newTreeNode("好友","Friend",friendinfo,accNode);
         for(var i in friendinfo){
             var msginfo = getFMessage(db1,friendinfo[i],userinfo);
             var msgNode = newTreeNode(friendinfo[i].Name,"FMessage",msginfo,friendNode);
         }
        var groupinfo = getGroup(db1,userinfo[i]);
        var groupNode = newTreeNode("群组","Group",groupinfo,accNode);
        
         for(var i in groupinfo){
             var gmsginfo = getGMessage(db1,groupinfo[i],userinfo[i]);
             var gmsgNode = newTreeNode(groupinfo[i].Name,"GMessage",gmsginfo,groupNode);
         }        
    }  
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["好友消息","群消息"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
    return name;
}
function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from User_UserInfo u left join Auth_AccountInfo a where u.userId = a.userId" ) +')');
    for(var i in data){
        var obj = new Account();
        obj.Name = data[i].name;
        obj.ID = data[i].userId;
        obj.NickName = data[i].nickName;
        obj.Birthday = data[i].birthday;
        obj.Description = data[i].description;
        obj.Signature = data[i].signature;
        obj.Gender = data[i].gender;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].loginTime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFriend(path,userinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from im_friend_list" ) +')');
    for(var i in data){
        var obj = new Account();
        obj.Name = data[i].nickName;
        obj.ID = data[i].id;
        obj.MD5 = XLY.Encrypt.MD5(data[i].id,'utf-8');
        obj.Birthday = data[i].birthday;
        obj.Signature = data[i].sign;
        obj.Gender = data[i].sex;
        obj.Icon = data[i].headPhotoUrl;
        obj.Reserve = data[i].reserve1;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].loginTime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getGroup(path,userinfo){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from im_group_list" ) +')');
    for(var i in data){
        var obj = new Group();
        if(data[i].groupName != null){
            obj.Name = data[i].groupName;
        }
        else
        {
           obj.Name = data[i].folderName;
        }      
        obj.ID = data[i].folderId;
        obj.GID = data[i].groupId;
        obj.MD5 = XLY.Encrypt.MD5(data[i].folderId,'utf-8');
        obj.Bulletin = data[i].groupBulletin;
        obj.Desc = data[i].groupDesc;
        obj.Icon = data[i].logoUrl;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].createTime);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFMessage(path,friendinfo,userinfo){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select distinct tbl_name from sqlite_master where tbl_name like 'im_1v1_msg_%' ") +')');     
        for(var i in info){            
        if(info[i].tbl_name == "im_1v1_msg_" + friendinfo.MD5 ){
            var data = eval('('+ XLY.Sqlite.Find(path,"select *  from '"+info[i].tbl_name+"' ") +')');
            for(var j in data){
                var obj = new FMessage();
                    if(data[j].isSend == '1'){
                        obj.SenderName = userinfo[0].NickName;
                        obj.ReceiveName = friendinfo.Name;
                    }
                    else
                    {
                       obj.SenderName = friendinfo.Name;
                        obj.ReceiveName = userinfo[0].NickName;                       
                    }
             obj.Content = data[j].msgText;
             obj.Time = XLY.Convert.LinuxToDateTime(data[j].msg_send_timestamp);
                list.push(obj);
            }
        }         
        }
    return list;
}
function getGMessage(path,groupinfo,userinfo){
    var list = new Array();
    var info = eval('('+ XLY.Sqlite.Find(path,"select distinct tbl_name from sqlite_master where tbl_name like 'im_group_msg_%' ") +')');
    if(info.length>0&& info != null){
        for(var i in info){
            if(info[i].tbl_name.length>40){           
                if(info[i].tbl_name == "im_group_msg_" + groupinfo.MD5 ){
                       var data = eval('('+ XLY.Sqlite.Find(path,"select *  from '"+info[i].tbl_name+"' ") +')'); 
                        for(var j in data){
                            var obj = new GMessage();
                            obj.SenderId= data[j].send_uid;
                            obj.SenderName = data[j].nickName;
                            obj.ReceiverName = groupinfo.Name;
                            obj.Content = data[j].msgText;
                            obj.Time = XLY.Convert.LinuxToDateTime(data[j].sendTime);
                            list.push(obj);
                        }
                }
            }
        }
    return list;
    }  
}
function getChannel(path){
    var list = new Array();
     var data = eval('('+ XLY.File.ReadXML(path) +')'); 
     var info = data.map.string ;
     var info1 = eval('('+ info["#text"] +')');
     for(var i = 0; i<info1.length; i++ ){
       var obj = new Channel();
       obj.ChannelName = info1[i].channelName;
       obj.ChannelID = info1[i].topAsid;
       obj.Icon = info1[i].channelLogo;
        list.push(obj);
     }

    return list;
}
//********************************************************
var source = $source;
var db = source[0]+"\\core.db";
var db3 = source[0];
var db2 = source[1];
//var db = "D:\\temp\\data\\data\\com.duowan.mobile\\databases\\core.db";
//var db3 = "D:\\temp\\data\\data\\com.duowan.mobile\\databases";
//var db2 = "D:\\temp\\data\\data\\com.duowan.mobile\\shared_prefs\\LatestAccessPref.xml";

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
