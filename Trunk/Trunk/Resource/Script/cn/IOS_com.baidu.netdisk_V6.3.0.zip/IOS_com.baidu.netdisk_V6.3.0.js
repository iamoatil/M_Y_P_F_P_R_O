﻿/*[config]
<plugin name="百度云盘,9" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\baidunetdisk.png" app="com.baidu.netdisk" version="6.3.0" description="百度云盘" data="$data,ComplexTreeDataSource"  >
    <source>
        <value>com.baidu.netdisk</value>
    </source>
    <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="账户名称" code="Name" type="string" width="180" format = ""></item>
    </data>
    <data type="CacheFiles" detailfield="Path" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="400" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    </data>
    <data type="Share" detailfield="Uri" datefilter="Time" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="文件名" code="Name" type="string" width="260" format = ""></item>
        <item name="文件路径" code="Path" type="string" width="400" format = ""></item>
        <item name="文件大小" code="Size" type="string" width="120" format = ""></item>
        <item name="文件分享者" code="Shared" type="string" width="180" format = ""></item>
        <item name="时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
        <item name="下载地址" code="Uri" type="url" width="400" format = ""></item>
    </data>
</plugin>
[config]*/

function Account() {
    this.Name = "";
    this.DataState = "Normal";
}

function CacheFiles() {
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.Time = null;
    this.DataState = "Normal";
}

function Share() {
    this.Name = "";
    this.Path = "";
    this.Size = "";
    this.Shared = "";
    this.Time = null;
    this.Uri = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var result = new Array();
//源文件
var source = $source;
var folder = source[0] + "\\com.baidu.netdisk\\Documents";

var files = eval('(' + XLY.File.FindDirectories(folder) + ')');
var paths = new Array();
var ch = "\\chalib\\IOS_com.baidu.netdisk_V6.3.0\\netdisk.sqlite.charactor";
for(var index in files){
    var str = files[index];
    var i = str.lastIndexOf("\\");
    var director = str.slice(i+1,str.length-1);
    var strExp=/^[A-Za-z0-9]+$/;
    if(strExp.test(director)&&director.length>25){
        str = XLY.Sqlite.DataRecovery(str+"\\netdisk.sqlite",ch,"feed_userlist,cachefilelist,Mbox_file_share,Mbox_groupfile_share");
        paths.push(str);
    }
}

//主界面函数
function ParesCore(){
    //定义网盘节点
    var diskNode = BuildNode("百度云盘","",[],"Normal");
    //定义账户节点
    for(var i in paths){
        var accName = "账户"+i;
        var accNode = BuildNode(accName,"Account",getAccount(paths[i]),"Normal");
        //定义网盘文件节点
        var fileNode = BuildNode("网盘文件","CacheFiles",getFile(paths[i]),"Normal");
        accNode.TreeNodes.push(fileNode);
        //定义分享文件节点
        var shareNode = BuildNode("分享文件","Share",getShare(paths[i]),"Normal");
        accNode.TreeNodes.push(shareNode);
        diskNode.TreeNodes.push(accNode);
    }
    result.push(diskNode);
}

//创建节点
function BuildNode(text,type,items,dataState){
    var node = new TreeNode();
    node.Text = text;
    node.Type = type;
    node.Items = items;
    node.DataState = dataState;
    return node;
}

//获取账户信息
function getAccount(path){
    var db = eval('('+ XLY.Sqlite.FindByName(path,"feed_userlist") +')');
    var Items = new Array();
    for(var i in db){
        var acc = new Account();
        acc.Name = db[i].user_name;
        acc.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(acc);
    }
    return Items;
}

//获取网盘文件
function getFile(path){
    var db = eval('('+ XLY.Sqlite.Find(path,"select *,cast(ctime as text)as ctime from cachefilelist") +')');
    var Items = new Array();
    for(var i in db){
        var file = new CacheFiles();
        file.Name = db[i].file_name;
        file.Path = db[i].server_path;
        file.Size = db[i].file_size+"/byte";
        file.Time = XLY.Convert.LinuxToDateTime(db[i].ctime);
        file.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(file);
    }
    return Items;
}

//获取分享文件
function getShare(path){
    var db1 = eval('('+ XLY.Sqlite.Find(path,"select *,cast(server_ctime as text)as server_ctime from Mbox_file_share") +')');
    var db2 = eval('('+ XLY.Sqlite.Find(path,"select *,cast(server_ctime as text)as server_ctime from Mbox_groupfile_share") +')');
    var Items = new Array();
    for(var i in db1){
        var share = new Share();
        share.Name = db1[i].server_filename;
        share.Path = db1[i].server_fullpath;
        share.Size = db1[i].size+"/byte";
        share.Time = XLY.Convert.LinuxToDateTime(db1[i].server_ctime);
        share.Uri = db1[i].dlink;
        share.Shared = db1[i].uname;
        share.DataState = XLY.Convert.ToDataState(db1[i].XLY_DataType);
        Items.push(share);
    }
    for(var j in db2){
        var share = new Share();
        share.Name = db2[j].server_filename;
        share.Path = db2[j].server_fullpath;
        share.Size = db2[j].size+"/byte";
        share.Time = XLY.Convert.LinuxToDateTime(db2[j].server_ctime);
        share.Shared = db2[j].uname;
        share.Uri = db2[j].dlink;
        share.DataState = XLY.Convert.ToDataState(db2[j].XLY_DataType);
        Items.push(share);
    }
    return Items;
}

ParesCore();
var res = JSON.stringify(result);
res;


