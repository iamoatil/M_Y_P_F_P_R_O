﻿/*[config]
<plugin name="QQ浏览器" group="Web痕迹,7" devicetype="android" icon="\icons\qqbrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.tencent.mtt" version="7.1.0.2830" description="QQ浏览器" data="$data,ComplexTreeDataSource">
    <source>
        <value>/data/data/com.tencent.mtt/databases/#F</value>
        <value>/data/data/com.tencent.mtt/app_webview/Cookies</value>
    </source>
    <data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
<data type="Account"  contract="DataState" datefilter = "LastPlayTime">
    <item name="账号" code="Acc" type="string" width = "150"></item>
    </data>
 <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="ID" code="Id" type="string" width = "150"></item>
    <item name="创建时间" code="Time" type="string" width = "200"></item>
    </data>
 <data type="Snapshot" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="分类" code="Group" type="string" width = "150"></item>
    </data>
    <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="类型" code="Title" type="string" width = "150"></item>
    <item name="搜索关键字" code="Url" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
<data type="Download" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="路径" code="Path" type="string" width = "150"></item>
    <item name="开始时间" code="CreatedTime" type="string" width = "200"></item>
    <item name="结束时间" code="DoneTime" type="string" width = "200"></item>
    <item name="大小" code="Size" type="string" width = "150"></item>
    </data>
<data type="Cookies" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Name" type="string" width = "150"></item>
    <item name="创建时间" code="CTime" type="url" width = "150"></item>
    <item name="值" code="Key" type="string" width = "150"></item>
    <item name="失效时间" code="Expires" type="string" width = "200"></item>    
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Account(){
    this.Acc = "";
}
function Bookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Id = "";
    this.Time = "";
}
function Snapshot(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Group = "";
}
function Search(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function Download(){
    this.DataState = "Normal";
    this.Name = "";
    this.Url = "";
    this.Path = "";
    this.CreatedTime = "";
    this.DoneTime = "";
    this.Size = "";
}
function Cookies(){
    this.DataState = "Normal";
    this.Key = "";
    this.Name = "";
    this.Expires = "";
    this.CTime = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "QQ浏览器";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    
    var news1 = new TreeNode();
    news1.Text = "账号ID";
    news1.Type = "Account";
    accountinfo = getAccount(db);
    news1.Items = accountinfo;
    news1.DataState = "Normal";
    news.TreeNodes.push(news1);
    
     for(var i in accountinfo){
        var account = new TreeNode() ;
        account.Text = accountinfo[i].Acc;
        account.Type = "Account"; 
        news1.TreeNodes.push(account);
        
        var bookmark = new TreeNode() ;
        bookmark.Text = "书签";
        bookmark.Type = "Bookmark"; 
        //var abc = db+"\\"+accountinfo[i].Acc+".db";
        var abc = XLY.Sqlite.DataRecovery(db+"\\"+accountinfo[i].Acc+".db",charactor1,"mtt_bookmarks,snapshot,search_history");
        bookmark.Items = getBookmark(abc) ;
        account.TreeNodes.push(bookmark);
        
        var snapshot = new TreeNode() ;
        snapshot.Text = "主页";
        snapshot.Type = "Snapshot"; 
        snapshot.Items = getSnapshot(abc) ;
        account.TreeNodes.push(snapshot);
        
        var search = new TreeNode() ;
        search.Text = "搜索";
        search.Type = "Search"; 
        search.Items = getSearch(abc) ;
        account.TreeNodes.push(search);

     }
    
    newTreeNode("浏览记录","History",getHistory(db6),news);
    newTreeNode("下载","Download",getDownload(db7),news);
    newTreeNode("Cookies","Cookies",getCookies(db8),news);
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["书签","搜索","浏览记录","下载","Cookies","缓存","Navi"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}
function getBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from mtt_bookmarks" ) +')');
    for(var i in data){
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Id = data[i].uuid;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].created);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

function getSnapshot(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from snapshot" ) +')');
    for(var i in data){
        var obj = new Snapshot();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Group = data[i].group_name;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getDownload(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from download" ) +')');
    for(var i in data){
        var obj = new Download();
        obj.Name = data[i].filename;
        obj.Url = data[i].url;
        obj.Path = data[i].filefolderpath;
        obj.Size = data[i].totalsize+" bytes";
        obj.CreatedTime = XLY.Convert.LinuxToDateTime(data[i].createdate);
        obj.DoneTime = XLY.Convert.LinuxToDateTime(data[i].donedate);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
} 
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from search_history" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Title = data[i].NAME;
        obj.Url = data[i].URL;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].DATETIME);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].NAME;
        obj.Url = data[i].URL;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].DATETIME);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getCookies(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from cookies" ) +')');
    for(var i in data){
        var obj = new Cookies();
        obj.Name = data[i].name;
        obj.Key = data[i].host_key;
        obj.Value = data[i].value;
        obj.CTime = XLY.Convert.LinuxToDateTime(data[i].creation_utc);
        obj.Expires = XLY.Convert.LinuxToDateTime(data[i].expires_utc);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0];
var db1 = source[0]+"\\database";
var db2 = source[0]+"\\download_database";
var db3 = source[1];

var charactor1 = "\\chalib\\Android_QQBrowser_V7.1.0.2830\\913.charactor";
var charactor2 = "\\chalib\\Android_QQBrowser_V7.1.0.2830\\database.charactor";
var charactor3 = "\\chalib\\Android_QQBrowser_V7.1.0.2830\\download_database.charactor";
var charactor4 = "\\chalib\\Android_QQBrowser_V7.1.0.2830\\Cookies.charactor";

function getAccount(db){
    var list = new Array();
    var filenames = eval('('+ XLY.File.FindFiles(db) +')');
    //log(filenames);
    var info = new Array();
    for(var index in filenames){        
        var data = XLY.File.GetFileName(filenames[index]);
        if((/^[0-9]+\.db$/).test(data)) info.push(data.substring(0,data.indexOf(".")));
    }  
    info.push("default_user"); 
 
    for(var i in info){
         var obj = new Account();
         obj.Acc = info[i];
          list.push(obj);  
    }   
    return list;    
}

var db6 = XLY.Sqlite.DataRecovery(db1,charactor2,"history");
var db7 = XLY.Sqlite.DataRecovery(db2,charactor3,"download");
var db8 = XLY.Sqlite.DataRecovery(db3,charactor4,"cookies");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
