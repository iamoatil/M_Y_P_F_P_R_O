﻿/*[config]
<plugin name="腾讯地图,3" group="地图公交,5" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\tencentMap.png" app="com.tencent.mttlite" version="4.1.1" description="腾讯地图" data="$data,ComplexTreeDataSource" >
<source>
<value>com.tencent.sosomap</value>
</source>
<data type="Search">
<item name="名称" code="Name" type="string" width="100" ></item>
<item name="详细地址" code="Addr" type="string" width="150" format=""></item>
<item name="经度" code="Longitude" type="string" width="80" format="F6" ></item>
<item name="纬度" code="Latitude" type="string" width="80" format="F6"></item>    
</data>
    
<data  type="Favorite">
<item name="地名" code="Name" type="string" width="100" ></item>
<item name="详细地址" code="Addr" type="string" width="150" format=""></item>
<item name="经度" code="Longitude" type="string" width="80" format="F6"></item>
<item name="纬度" code="Latitude" type="string" width="80" format="F6"></item>
<item name="电话" code="Phone" type="string" width="80" format=""></item>    
<item name="距离(米)" code="Distance" type="string" width="50" format=""></item> 
</data>

<data type="Route">
<item name="街名" code="Roadname" type="string" width="100" ></item>
<item name="转向" code="Action" type="string" width="50" format=""></item>
<item name="路径" code="Textinfo" type="string" width="300" format=""></item>
<item name="经度" code="Longitude" type="string" width="80" format="F6" ></item>
<item name="纬度" code="Latitude" type="string" width="80" format="F6"></item>    
</data>

<data  type="Navigate">
<item name="导航起点" code="Start" type="string" width="150" ></item>
<item name="导航终点" code="Dest" type="string" width="150" format=""></item>
<item name="时间" code="Time" type="datetime" width="80" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>

<data  type="Busline">
<item name="导航起点" code="Start" type="string" width="150" ></item>
<item name="导航终点" code="Dest" type="string" width="150" format=""></item>
<item name="公交路线" code="Line" type="string" width="200" format=""></item>
<item name="时间" code="Time" type="datetime" width="80" format="yyyy-MM-dd HH:mm:ss" order="asc"></item>
</data>

</plugin>
[config]*/

//定义数据结构

function Navigate() {
    this.Start = "";
    this.Dest = "";
    this.Time = null;
}

function Busline() {
    this.Start = "";
    this.Dest = "";
    this.Line = "";
    this.Time = null;
}

function Search() {
    this.Name = "";
    this.Addr = "";
    this.Longitude = "";
    this.Latitude = "";
}

function Route() {
    this.Roadname = "";
    this.Action = "";
    this.Textinfo = "";
    this.Longitude = "";
    this.Latitude = "";
}

function Favorite() {
    this.Name = "";
    this.Addr = null;
    this.Longitude = "";
    this.Latitude = "";
    this.Phone = "";
    this.Distance = "";
}

function GetNavigate(start, dest, time) {
    var list = new Navigate();
    if (start.cname != null) {
        list.Start = start.cname + start.query + "(" + "经度" + start.pointx / 100000 + ";" + "纬度" + start.pointy / 100000 + ")";
    } else {
        list.Start = start.query + "(" + "经度" + start.pointx / 100000 + ";" + "纬度" + start.pointy / 100000 + ")";
    }
    if (dest.cname != null) {
        list.Dest = dest.cname + dest.query + "(" + "经度" + dest.pointx / 100000 + ";" + "纬度" + dest.pointy / 100000 + ")";
    } else {
        list.Dest = dest.query + "(" + "经度" + dest.pointx / 100000 + ";" + "纬度" + dest.pointy / 100000 + ")";
    }
    list.Time = XLY.Convert.LinuxToDateTime(time);
    return list;
}

function GetBusline(start, dest, time, infos) {
    var list = new Busline();
    if (start.cname != null) {
        list.Start = start.cname + start.query + "(" + "经度" + start.pointx / 100000 + ";" + "纬度" + start.pointy / 100000 + ")";
    } else {
        list.Start = start.query + "(" + "经度" + start.pointx / 100000 + ";" + "纬度" + start.pointy / 100000 + ")";
    }
    if (dest.cname != null) {
        list.Dest = dest.cname + dest.query + "(" + "经度" + dest.pointx / 100000 + ";" + "纬度" + dest.pointy / 100000 + ")";
    } else {
        list.Dest = dest.query + "(" + "经度" + dest.pointx / 100000 + ";" + "纬度" + dest.pointy / 100000 + ")";
    }

    var line = new Array();
    for (var index in infos) {
        if (infos[index][0].from != null) {
            line[index] = infos[index][0].name + "(" + infos[index][0].from + "-" + infos[index][0].to + ")";
        } else {
            line[index] = infos[index][0].name + "(" + "开往" + infos[index][0].to + ")";
        }
    }
    list.Line = line.join(" 转乘 ");
    list.Time = XLY.Convert.LinuxToDateTime(time);
    return list;
}

function GetSearch(infos) {
    var list = new Search();
    list.Name = infos.name;
    list.Addr = infos.addr;
    list.Longitude = infos.pointy / 1000000;
    list.Latitude = infos.pointx / 10000000;
    return list
}

function GetRoute(infos) {
    var list = new Route();
    list.Roadname = infos.roadName;
    list.Action = infos.action;
    list.Textinfo = infos.textInfo;
    if (infos.xpinfo != null) {
        list.Longitude = infos.xpinfo.x / 100000;
        list.Latitude = infos.xpinfo.y / 100000;
    }
    return list;
}

function GetFavorite(infos) {
    var list = new Favorite();
    var content = infos.content
    list.Name = content.name
    list.Addr = content.addr
    list.Longitude = content.pointx / 100000;
    list.Latitude = content.pointy / 100000;
    list.Phone = content.phone
    list.Distance = content.dis
    return list
}

function BuildSimpleTree(treeinfos, treename, method) {
    for (var index in treeinfos) {
        var list = treeinfos[index];
        var treeinfo = method(list);
        treename.Items.push(treeinfo);
    }
}

function ExecReadFile(path) {
    var infos = eval('(' + XLY.File.ReadFile(path) + ')');
    return infos;
}

function search(str) {
    var reg = /\w+.r+$/gi;
    var target = reg.test(str);
    if (target) {
        return str;
    }
}

function CutString(str) {
    var start = str.indexOf("{");
    var newstr = str.substr(start, str.length - start);
    return newstr;
}

function GetString(str) {
    var start = str.indexOf(".");
    var newstr = str.slice(0, start);
    return newstr;
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
}

var result = new Array();
//源文件
var source = $source;
var dataRoot = source[0] + "\\com.tencent.sosomap\\Documents\\user";
//var dataRoot = "C:\\Users\\Administrator\\Desktop\\user11";

//创建历史搜索树
var searchpath = dataRoot + "\\routesearchistory.dat";
var searchdata = ExecReadFile(searchpath);
var searchinfos = searchdata.routesearchistory;
var searchTree = new TreeNode();
searchTree.Text = "历史搜索";
searchTree.Type = "Search";
BuildSimpleTree(searchinfos, searchTree, GetSearch);

//创建收藏树
var favpath = dataRoot + "\\favorite.dat";
var favdata = ExecReadFile(favpath);
var favinfos = favdata.fav_list
var favoriteTree = new TreeNode();
favoriteTree.Text = "收藏夹";
favoriteTree.Type = "Favorite";
BuildSimpleTree(favinfos, favoriteTree, GetFavorite);


//创建导航信息树
var files = eval('(' + XLY.File.FindFiles(dataRoot) + ')');
var navigateTree = new TreeNode();
navigateTree.Text = "导航信息";
navigateTree.Type = "Navigate";

var zijiaTree = new TreeNode();
zijiaTree.Type = "Navigate";
zijiaTree.Text = "自驾";
var gongjiaoTree = new TreeNode();
gongjiaoTree.Type = "Busline";
gongjiaoTree.Text = "公交";
var buxingTree = new TreeNode();
buxingTree.Type = "Navigate";
buxingTree.Text = "步行";
for (var findex in files) {
    var filename = XLY.File.GetFileName(files[findex]);
    var t_file = search(filename);
    if (t_file != null) {
        var navipath = dataRoot + "\\" + t_file;
        var navidata = XLY.File.ReadFile(navipath);
        var navi = CutString(navidata);
        var naviinfo = eval('(' + navi + ')')
        var navigates = naviinfo.content;
        var dest = navigates.info.dest;
        var start = navigates.info.start;
        var time = GetString(t_file);
        var routeinfo = GetNavigate(start, dest, time);
        navigateTree.Items.push(routeinfo);
        if (navigates.segmentList != null) {
            var zjinfo = GetNavigate(start, dest, time);
            zijiaTree.Items.push(zjinfo);
            var lineTree = new TreeNode();
            lineTree.Type = "Route"
            lineTree.Text = dest.cname + dest.query;
            BuildSimpleTree(navigates.segmentList, lineTree, GetRoute);
            zijiaTree.TreeNodes.push(lineTree);
        }
        if (navigates.detail != null) {
            var gjline = navigates.detail.intervals;
            if (gjline) {
                var gjinfos = GetBusline(start, dest, time, gjline)
                gongjiaoTree.Items.push(gjinfos);
            } else {
                var buxingline = navigates.detail.route;
                var buxinginfos = GetNavigate(start, dest, time);
                buxingTree.Items.push(buxinginfos);
                for (var index in buxingline) {
                    var walklines = buxingline[index].segmentList;
                    var walkTree = new TreeNode();
                    walkTree.Text = dest.cname + dest.query;
                    walkTree.Type = "Route";
                    BuildSimpleTree(walklines, walkTree, GetRoute)
                }
                buxingTree.TreeNodes.push(walkTree);
            }
        }


    }
}
navigateTree.TreeNodes.push(zijiaTree);
navigateTree.TreeNodes.push(gongjiaoTree);
navigateTree.TreeNodes.push(buxingTree);

result.push(searchTree);
result.push(favoriteTree);
result.push(navigateTree);

// return
var res = JSON.stringify(result);
res;
