﻿/*[config]
<plugin name="UC浏览器" group="Web痕迹,7" devicetype="android" icon="\icons\Uc_icon.png" pump="USB,Mirror,Wifi,Bluetooth,chip,LocalData" app="com.UCMobile" version="10.10.1.812" description="UC浏览器" data="$data,ComplexTreeDataSource">
    <source>
        <value>/data/data/com.UCMobile/databases#F</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Favorite" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="来源" code="Source" type="string" width = "200"></item>
    <item name="图标" code="Icon" type="string" width = "200"></item>
    <item name="收藏时间" code="Time" type="string" width = "200"></item>
    </data>
   <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问时间" code="Time" type="string" width = "200"></item>
    <item name="访问次数" code="Count" type="string" width = "150"></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Bookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
function Favorite(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Source = "";
    this.Icon = "";
    this.Time = "";
}

function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
    this.Count = "";
}
//定义树数据结构
function TreeNode(){
    this.TreeNodes = new Array();
}
 
function bindTree(){
    newTreeNode("书签","Bookmark",getBookmark(db3));
    newTreeNode("收藏","Favorite",getFavorite(db4));
    newTreeNode("浏览记录","History",getHistory(db5));
}
function getNews(){
    var list = new Array();
    data = ["书签","收藏","浏览记录"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    name.TreeNodes = new Array();
    result.push(name);

}
function getBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from bookmark" ) +')');
    for(var i in data){
        var obj = new Bookmark();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getFavorite(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from favorite_common_table" ) +')');
    for(var i in data){
        var obj = new Favorite();
        obj.Title = data[i].title;
        obj.Url = data[i].url;
        obj.Source = data[i].source;
        obj.Icon = data[i].icon_url;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].add_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from history" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].name;
        obj.Url = data[i].url;
        obj.Count = data[i].visited_count;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].visited_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
//********************************************************
var source = $source;
var db = source[0]+"\\bookmark.db";
var db1 = source[0]+"\\favorite_database";
var db2 = source[0]+"\\history";

var charactor1="\\chalib\\Android_com.UCMobile_V10.10.1.812\\bookmark.db.charactor";
var charactor2="\\chalib\\Android_com.UCMobile_V10.10.1.812\\favorite_database.charactor";
var charactor3="\\chalib\\Android_com.UCMobile_V10.10.1.812\\history.charactor";

var db3 = XLY.Sqlite.DataRecovery(db,charactor1,"bookmark");
var db4 = XLY.Sqlite.DataRecovery(db1,charactor2,"favorite_common_table");
var db5 = XLY.Sqlite.DataRecovery(db2,charactor3,"history");
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
