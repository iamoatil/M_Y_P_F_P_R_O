﻿/*[config]
<plugin name="ChatON,12" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\ChatON.png" app="com.samsung.msc.chaton" version="3.0.2" description="ChatON" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.samsung.msc.chaton</value>
</source>

<data type="Account" detailfield="Signature，sendmessage" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="用户名" code="Name" type="string" width=""></item>
<item name="个人签名" code="Signature" type="string" width="200" ></item>
<item name="邮箱" code="Email" type="string" width = "200"></item>
<item name="生日" code="Birth" type="string" width="200"></item>
<item name="电话" code="Phone" type="string" width="120" ></item>
</data>

<data type="Friend" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友姓名" code="Name" type="string" width= ""></item>
<item name="电话号码" code="Number" type="string" width="150" alignment="center"></item>
<item name="邮箱" code="Email" type="string" width="200" alignment="center"></item>
</data>

<data type="Message" datefilter="Date" detailfield="Content" contract="DataState,Conversion">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width="80" format=""></item>
<item name="接收人" code="Target" type="string" width="80" format=""></item>
<item name="会话内容" code="Content" type="string" width="300" format=""></item>
<item name="时间" code="Date" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss" order = "asc"></item>
<item name="消息类型" code="MesType" type="Enum" format="EnumColumnType" width="80"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="50" show="false" ></item>
<item name="发送状态" code="SendState" type="Enum" format="EnumSendState"  show="false"></item>
</data>

<data type="Group" datefilter="Date" detailfield="Member" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="群组名" code="GroupName" type="string" width="120" ></item>
<item name="群成员" code="Member" type="string" width="300" ></item>
</data>

</plugin>
[config]*/

function Account() {
    this.Name = "";
    this.Signature = "";
    this.Email ="";
    this.Phone = "";
    this.Birth = "";
}

function Friend() {
    this.Name = "";
    this.Number= "";
    this.Email = "";
    this.DataState = "Normal";
}

function Message() {
    this.Sender = "";
    this.Target = "";
    this.MesType = "";
    this.Content = "";
    this.Date = null;
    this.Type = "";
    this.SendState = "";
    this.DataState = "Normal";
}

function Group() {
    this.GroupName = "";
    this.Member = "";
    this.DataState = "Normal";
}
//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var result = new Array();
//源文件
var source = $source;
var db = source[0]+"\\com.samsung.msc.chaton\\Library\\Application Support\\ChatOnClientApp.sqlite";
//测试数据
//var db =  "C:\\Users\\Administrator\\Desktop\\com.sec.chaton\\Library\\Application Support\\ChatOnClientApp.sqlite";
//特征库
var charactor = "\\chalib\\IOS_ChatON_V3.0.2\\ChatOnClientApp.sqlite.charactor";
var recoverydb = XLY.Sqlite.DataRecovery( db,charactor,"ZBUDDY,ZGROUP,ZINBOX,ZONMESSAGE,ZMYPROFILE,ZPRIMARYDATA");
var path = recoverydb;

//主界面函数
function ParesCore(){
    //定义用户节点
    var userNode = new TreeNode();
    var account = GetAccount();
    userNode.Text = account.Name;
    userNode.Type = "Account";
    //提取个人信息
    userNode.Items.push(account);
    //定义好友信息节点
    var friendNode = new TreeNode();
    friendNode.Text = "好友信息";
    friendNode.Type = "Friend";
    //提取好友信息
    var friend = GetFriend();
    friendNode.Items = friend;
    //获取好友聊天记录
    for (var i in friend){
        //定义聊天内容节点
        var messageNode = new TreeNode();
        messageNode.Text = friend[i].Name;
        messageNode.Type = "Message";
        //提取好友聊记录天
        messageNode.DataState = friend[i].DataState;
        messageNode.Items = GetMessage(friend[i].Name,account.Name,"好友信息");
        friendNode.TreeNodes.push(messageNode);
    }
    userNode.TreeNodes.push(friendNode);
    //定义群组节点
    var groupNode = new TreeNode();
    groupNode.Text = "群组";
    groupNode.Type = "Group";
    //提取群组信息
    var group = GetGroup();
    groupNode.Items = group; 
    //提取群组聊天记录
    if(group!=null&&group.length>0){
        for(var i in group){
            //定义群组聊天消息节点
            var memberNode = new TreeNode();
            memberNode.Text = group[i].GroupName;
            memberNode.Type = "Message";
            //提取群组聊天消息
            memberNode.DataState = group[i].DataState;
            memberNode.Items = GetMessage(group[i].Member,account.Name,"群组",group[i].GroupName);
            groupNode.TreeNodes.push(memberNode);
        }
    }
    userNode.TreeNodes.push(groupNode);   
       
    result.push(userNode);
    
    
}        

//获取用户信息,只可能有一个账户
function GetAccount(){
    var arr=new Array();
    var accdb = eval('(' + XLY.Sqlite.FindByName(path, "ZMYPROFILE") + ')');
    var db = eval('(' + XLY.Sqlite.FindByName(path, "ZPRIMARYDATA") + ')');
    var acc = new Account();
    if(accdb!=null&&accdb.length> 0){  
        acc.Name = accdb[0].ZNICKNAME;
        acc.Signature = accdb[0].ZSTATUS_MSG;
        acc.Email = accdb[0].ZSAMSUNG_EMAIL;
        acc.Phone = db[0].ZPHONENUMBER;
        acc.Birth = accdb[0].ZDATEOFBIRTH;
        acc.DataState =XLY.Convert.ToDataState(accdb[0].XLY_DataType); 
    }
    return acc ;
}

//获取好友信息
function GetFriend(){
    var db1 = eval('(' + XLY.Sqlite.FindByName(path, "ZBUDDY") + ')');
    var Items = new Array();
    for (var i in db1) {
        var row = db1[i];
        var fri = new Friend();
        fri.Name = row.ZDISPLAY_NAME;
        //fri.ID = row.Z_PK;
        if(row.ZORG_NUMBER!= null)
            fri.Number = row.ZORG_NUMBER;
        if(row.ZORG_NUMBER_LIST!= null)
            fri.Number = row.ZORG_NUMBER_LIST;
        fri.Email = row.ZSAMSUNGEMAIL;
        fri.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        Items.push(fri);
    }
   return Items; 
}

//提取表message聊天信息
function GetMessage(Name,userName,nodeName,groName){
    var db1 = eval('(' + XLY.Sqlite.FindByName(path, "ZONMESSAGE") + ')');
    var db2 = eval('('+ XLY.Sqlite.Find(path,"select * from ZINBOX where ZINBOX_TITLE = '"+Name+"'") +')');
    var Items = new Array();
    for (var i in db1){
        var row = db1[i];
        if(db2!=null&&db2.length>0){
            if(db2[0].Z_PK == row.ZINBOX){
                var mes = new Message();
                mes.Content = row.ZMESSAGE_CONTENT;
                switch(row.ZMESSAGE_TYPE){
                    case 0 : mes.Type = "String"; mes.MesType = "文本";break;
                    case 1 : mes.Type = "Image"; mes.MesType = "非文本";break;
                    case 2 : mes.Type = "String"; mes.MesType = "系统消息";break;
                    default : mes.Type = "String"; mes.MesType = "";
                }
                
                mes.Date = XLY.Convert.LinuxToDateTime(row.ZMESSAGE_TIME);                 
                if(row.ZSENDER =="0"){
                    mes.SendState = "Send";
                    mes.Sender = userName;
                    if(nodeName=="群组"){
                        mes.Target = groName;
                    }
                    else
                    {
                        mes.Target = Name;
                    }      
                }
                else {
                    //查询发送者好友姓名
                    var table = eval('('+ XLY.Sqlite.Find(path,"select * from ZBUDDY where Z_PK = '"+row.ZSENDER+"'") +')'); 
                    mes.SendState = "Receive";
                    if(table!=null&&table.length>0)
                        mes.Sender = table[0].ZORG_NAME;
                    if(nodeName=="群组"){
                        mes.Target = groName;
                    }
                    else
                    {
                       mes.Target = userName;
                    }
                }
                mes.DataState = XLY.Convert.ToDataState(row.XLY_DataType); 
                Items.push(mes);
            }
        }
    }    
    return Items;
}

//获取群组信息
function GetGroup(){
    var db1 = eval('('+ XLY.Sqlite.Find(path,"select * from ZINBOX where ZINBOX_CHAT_TYPE = '1'") +')');    
    var Items = new Array();
    if(db1!=null&&db1.length>0){
        for (var i in db1){
            var gro = new Group();
            var row = db1[i];
            var db2 = eval('('+ XLY.Sqlite.Find(path,"select * from ZGROUP where ZGROUPID = '"+row.ZINBOX_BUDDYGROUPID+"'") +')');
            if(db2!=null&&db2.length>0){
                gro.GroupName = db2[0].ZNAME;
            }
            else{
                gro.GroupName = row.ZINBOX_TITLE;
            }
            
            gro.Member = row.ZINBOX_TITLE;
            //gro.ID = row.Z_PK;
            gro.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
            Items.push(gro);
        }
    }
    return Items;
}

ParesCore();
var res = JSON.stringify(result);
res;
