﻿/*[config]
<plugin name="百度浏览器" group="Web痕迹,7" devicetype="IOS" icon="\icons\baidubrowser.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.baidu.browser.apps" version="2.8.0.63" description="百度浏览器" data="$data,ComplexTreeDataSource">
    <source>
    <value>com.baidu.BDPhoneBrowser</value>
    </source>
    <data type="News" contract="DataState" datefilter = "LastPlayTime">
    <item name="分类" code="List" type="string" width = "150"></item>
    </data>
    <data type="Search" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="搜索关键字" code="Title" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="History" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="访问次数" code="Count" type="string" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
    <data type="Bookmark" contract = "DataState" >
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
    <item name="名称" code="Title" type="string" width = "150"></item>
    <item name="网址" code="Url" type="url" width = "150"></item>
    <item name="时间" code="Time" type="string" width = "200"></item>
    </data>
</plugin>
[config]*/
function News(){
    this.List = "";
}
function Search(){
    this.DataState = "Normal";
    this.Word = "";
    this.Time = "";
}
//select * from ZBDWEBPAGEDATA where ZURL='' 
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
    this.Count = "";
}
//select * from ZBDWEBPAGEDATA where ZPARENTDIR1 = 1
function Bookmark(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Time = "";
}
//select * from ZBDWEBPAGEDATA where ZFILETYPE='1' 

//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var news = new TreeNode();
    news.Text = "百度浏览器";
    news.Type = "News";
    news.Items = getNews();
    news.DataState = "Normal";
    newTreeNode("搜索","Search",getSearch(db),news);
    newTreeNode("浏览记录","History",getHistory(db),news);
    newTreeNode("书签","Bookmark",getBookmark(db),news);
    result.push(news);
}
function getNews(){
    var list = new Array();
    data = ["搜索","浏览记录","书签"];
    for(var i in data){
        var obj = new News();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}
function getSearch(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ZBDWEBPAGEDATA where ZURL=''" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.Word = data[i].ZTITLE;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ZCREATEDATE);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getHistory(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ZBDWEBPAGEDATA where ZPARENTDIR1=1" ) +')');
    for(var i in data){
        var obj = new History();
        obj.Title = data[i].ZTITLE;
        obj.Url = data[i].ZURL;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ZCREATEDATE);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getBookmark(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from ZBDWEBPAGEDATA where ZFILETYPE=1" ) +')');
    for(var i in data){
        var obj = new Bookmark();
        obj.Title = data[i].ZTITLE;
        obj.Url = data[i].ZURL;
        obj.Count = data[i].ZVISITCOUNT;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].ZCREATEDATE);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db = source[0]+"\\com.baidu.BDPhoneBrowser\\Documents\\BDPhoneBrowser\\BDCoreData.sqlite";
//db="D:\\temp\\data\\data\\IOS.com.baidu.BDPhoneBrowse\\Documents\\BDPhoneBrowser\\BDCoreData.sqlite";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
