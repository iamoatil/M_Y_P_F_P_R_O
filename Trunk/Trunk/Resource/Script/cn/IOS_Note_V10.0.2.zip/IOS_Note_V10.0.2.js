﻿/*[config]
<plugin name="备忘录,8" group="基本信息,1" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\note.png" app="AppDomainGroup-group.com.apple.notes" version="10.0.2" description="提取IOS设备备忘录信息" data="$data,ComplexTreeDataSource" >
<source>
<value>AppDomainGroup-group.com.apple.notes</value>
</source>
<data type="News"  contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="NoteMsg" contract = "DataState" detailfield="AttachmentPath">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="120" ></item>
    <item name="内容" code="Content" type="string" width="120" ></item>
    <item name="附件名" code="AttachmentName" type="string" width="120" ></item>
    <item name="附件路径" code="AttachmentPath" type="string" width="120" ></item>
    <item name="创建日期" code="CreateDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width="150" ></item>
    <item name="最后修改日期" code="LastEditDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" width = "150" ></item>
</data>
</plugin>
[config]*/
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义NoteMsg数据结构
function NoteMsg() {
    this.DataState = "Normal";
    this.Title = "";
    this.Content = "";
    this.AttachmentName = "";
    this.AttachmentPath = "";
    this.LastEditDate = null;
    this.CreateDate = null;
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allMediaPath = source[0]+"\\AppDomainGroup-group.com.apple.notes\\Media";
var allPath1 = source[0]+"\\AppDomainGroup-group.com.apple.notes\\NoteStore.sqlite";
//测试数据
//var allMediaPath = "C:\\XLYSFTasks\\任务-2017-05-02-11-16-52\\source\\IosData\\2017-05-02-11-18-14\\aeb86051f46399722e23cfcfef43feba2be70d61\\AppDomainGroup-group.com.apple.notes\\Media";
//var allPath1 = "C:\\XLYSFTasks\\任务-2017-05-02-11-16-52\\source\\IosData\\2017-05-02-11-18-14\\aeb86051f46399722e23cfcfef43feba2be70d61\\AppDomainGroup-group.com.apple.notes\\NoteStore.sqlite";
//定义特征库文件
var charactor1 = "\\chalib\\iOS_Note_V10.0.2\\NoteStore.sqlite.charactor";

//恢复数据库中删除的数据
var allPath = XLY.Sqlite.DataRecovery(allPath1,charactor1,"Z_11NOTES,ZICCLOUDSYNCINGOBJECT");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "备忘录";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    var node = new TreeNode();
    node.Text = "My Iphone";
    node.Type = "News";
    if(XLY.File.IsValid(allPath)){
        var dataNodeType = eval('('+ XLY.Sqlite.Find(allPath,"select distinct(Z_11FOLDERS) from Z_11NOTES") +')');
        if(dataNodeType!=""&&dataNodeType!=null){
            for(var i in dataNodeType){
                if(dataNodeType[i].Z_11FOLDERS==3){
                    var noteNode = new TreeNode();
                    noteNode.Text = "备忘录";
                    noteNode.Type = "NoteMsg";
                    getNoteNodeMsg(noteNode,allPath,3);
                    node.TreeNodes.push(noteNode);
                }
                if(dataNodeType[i].Z_11FOLDERS==4){
                    var deleteNode = new TreeNode();
                    deleteNode.Text = "最近删除";
                    deleteNode.Type = "NoteMsg";
                    getNoteNodeMsg(deleteNode,allPath,4);
                    node.TreeNodes.push(deleteNode);
                }
            }  
        }
    }
    
    root.TreeNodes.push(node);
}
function getNoteNodeMsg(root,path,temp){
    if(temp==3){
        var dataNote = eval('('+ XLY.Sqlite.Find(path,"select * from Z_11NOTES where Z_11FOLDERS='"+temp+"'") +')');
    }
    if(temp==4)
    {
        var dataNote = eval('('+ XLY.Sqlite.Find(path,"select * from Z_11NOTES where Z_11FOLDERS='"+temp+"'") +')');
    }
    
    if(dataNote!=""&&dataNote!=null){
        for(var i in dataNote){
            var dataTitle = eval('('+ XLY.Sqlite.Find(path,"select cast(ZCREATIONDATE1 as int) as createtime,cast(ZMODIFICATIONDATE1 as int) as modifytime,ZSNIPPET,ZTITLE1,XLY_DataType from ZICCLOUDSYNCINGOBJECT where Z_PK = '"+dataNote[i].Z_8NOTES+"'") +')');
            if(dataTitle!=""&&dataTitle!=null){
                var bb = "";
                var cc = "";
                var obj = new NoteMsg();
                obj.DataState = XLY.Convert.ToDataState(dataNote[i].XLY_DataType);
                obj.Title = dataTitle[0].ZTITLE1;
                if(dataTitle[0].modifytime!=""&&dataTitle[0].modifytime!=null){
                    obj.LastEditDate = XLY.Convert.ToDateTime(2001, 1, 1, dataTitle[0].modifytime);
                }
                if(dataTitle[0].createtime!=""&&dataTitle[0].createtime!=null){
                    obj.CreateDate = XLY.Convert.ToDateTime(2001, 1, 1, dataTitle[0].createtime);
                }
                var dataAttachmentConectTitle = eval('('+ XLY.Sqlite.Find(path,"select ZMEDIA from ZICCLOUDSYNCINGOBJECT where ZNOTE = '"+dataNote[i].Z_8NOTES+"'") +')');
                if(dataAttachmentConectTitle!=""&&dataAttachmentConectTitle!= null){
                    for(var j in dataAttachmentConectTitle){
                        var aa = "";
                        var dataAttachment = eval('('+ XLY.Sqlite.Find(path,"select ZIDENTIFIER,ZFILENAME from ZICCLOUDSYNCINGOBJECT where Z_PK = '"+dataAttachmentConectTitle[j].ZMEDIA+"'") +')');
                        if(dataAttachment!=""&&dataAttachment!=""){
                            if(dataAttachment[0].ZIDENTIFIER!=""&&dataAttachment[0].ZIDENTIFIER!=null){
                                aa+= allMediaPath+"\\"+dataAttachment[0].ZIDENTIFIER;
                            }
                            if(dataAttachment[0].ZFILENAME!=""&&dataAttachment[0].ZFILENAME!= null){
                                aa+= "\\"+dataAttachment[0].ZFILENAME;
                                cc+= dataAttachment[0].ZFILENAME+"\r";
                            }
                            bb += aa+"\r";
                            
                        }    
                    }
                    if(dataTitle[0].ZSNIPPET!=""&&dataTitle[0].ZSNIPPET!=null){
                        obj.Content = dataTitle[0].ZSNIPPET;
                    }
                    else
                    {
                        obj.Content = dataAttachmentConectTitle.length+"个附加文件";
                    }
                    obj.AttachmentPath = bb;
                    obj.AttachmentName = cc;
                }
                else
                {
                    if(dataTitle[0].ZSNIPPET!=""&&dataTitle[0].ZSNIPPET!=null){
                        obj.Content = dataTitle[0].ZSNIPPET;
                    }
                    else
                    {
                        obj.Content = "无附加文件";
                    }
                }
                root.Items.push(obj);
            }
        }
    }
}