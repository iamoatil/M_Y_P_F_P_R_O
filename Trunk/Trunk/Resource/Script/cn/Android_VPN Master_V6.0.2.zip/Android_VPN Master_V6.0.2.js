﻿/*[config]
<plugin name="VPN Master,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/vpn_master.png" app="free.vpn.unblock.proxy.vpnmaster" version="6.0.2" description="VPN Master" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/free.vpn.unblock.proxy.vpnmaster/shared_prefs#F</value>
    <value>/data/data/free.vpn.unblock.proxy.vpnmaster/files#F</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="设备信息" code="DeviceInfo" type="string" width = "100"></item>
    <item name="是否自动获取位置" code="AutoCollectLocation" type="string" width="100"></item>
    <item name="设备AndroidID" code="DeviceAndroidID" type="string" width = "100"></item>
    <item name="设备序列号" code="DeviceXLY" type="string" width = "100"></item>
    <item name="设备MAC地址" code="DeviceMAC" type="string" width = "100"></item>
    <item name="首次激活时间" code="FirstActivateTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后请求服务器时间" code="LastReq" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后登录时间" code="LastLunchTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="最后成功连接服务器时间" code="LastConnTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="成功请求次数" code="SuccessfulCount" type="string" width = "80"></item>
    <item name="失败请求次数" code="FailedCount" type="string" width = "80"></item>
    <item name="开机时自动连接" code="IsConnectedWhenOpen" type="string" width = "80"></item>
    <item name="WIFI信息" code="WifiInfo" type="string" width = "100"></item>
</data>
<data type="LastConnInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="协议" code="Proto" type="string" width = "100"></item>
    <item name="端口" code="Port" type="string" width="100"></item>
    <item name="服务器IP" code="LastIp" type="string" width = "100"></item>
    <item name="键值" code="LastKey" type="string" width = "100"></item>
</data>
<data type="ServerList" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width = "100"></item>
    <item name="国家" code="Country" type="string" width="100"></item>
    <item name="id" code="Id" type="string" width = "100"></item>
    <item name="Ip" code="Ip" type="string" width = "100"></item>
</data>
<data type="LogInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="时间" code="LogTime" type="string" width = "100"></item>
    <item name="操作" code="LogLog" type="string" width="100"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function LogInfo(){
    this.DataState = "Normal";
    this.LogTime = "";
    this.LogLog = "";
}
function ServerList(){
    this.DataState = "Normal";
    this.Name = "";
    this.Country = "";
    this.Id = "";
    this.Ip = "";
}
function LastConnInfo(){
    this.DataState = "Normal";
    this.Proto = "";
    this.Port = "";
    this.LastIp = "";
    this.LastKey = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.DeviceInfo = "";
    this.AutoCollectLocation = "否";
    this.FirstActivateTime = null;
    this.LastReq = null;
    this.LastLunchTime = null;
    this.LastConnTime = null;
    this.SuccessfulCount = "";
    this.FailedCount = "0";
    this.WifiInfo = "";
    this.IsConnectedWhenOpen = "否";
    this.DeviceAndroidID = "";
    this.DeviceXLY = "";
    this.DeviceMAC = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var allPath = source[0];
var filePath = source[1];

//测试数据
//var allPath = "C:\\XLYSFTasks\\任务-2017-07-21-17-45-14\\source\\data\\free.vpn.unblock.proxy.vpnmaster\\shared_prefs";
//var filePath = "C:\\XLYSFTasks\\任务-2017-07-21-17-45-14\\source\\data\\free.vpn.unblock.proxy.vpnmaster\\files";
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "VPN Master";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    var usernode = new TreeNode();
    usernode.Text = "用户信息";
    usernode.Type = "UserInfo";
    var obj = new UserInfo();
    getInfo(usernode);
    var wifiFilePath = filePath+"\\trusted_wifi.json";
    if(XLY.File.IsValid(wifiFilePath)){
        var wifiData = XLY.File.ReadFile(wifiFilePath);
        if(wifiData!=""&&wifiData!=null){
            var len = wifiData.split(":")[0].length;
            obj.WifiInfo = wifiData.split(":")[0].substr(4,len-7);
        }
    }
    var masPath = allPath + "\\master_sharepreference.xml";
    if(XLY.File.IsValid(masPath)){
        var masData = eval('('+ XLY.File.ReadXML(masPath) +')');
        if(masData!=""&&masData!=null){
            var masBoolData = masData.map.boolean;
            if(masBoolData!=""&&masBoolData!=null){
                for(var a in masBoolData){
                    if(masBoolData[a]["@name"]=="connect_when_mobile_starts"){
                        if(masBoolData[a]["@value"]=="true"){
                            obj.IsConnectedWhenOpen = "是";
                        }
                    }
                }
            }
            var masLongData = masData.map.long;
            if(masLongData!=""&&masLongData!=null){
                for(var b in masLongData){
                    if(masLongData[b]["@name"]=="launch_vpn_master"){
                        obj.LastLunchTime = XLY.Convert.LinuxToDateTime(masLongData[b]["@value"]);
                    }
                    if(masLongData[b]["@name"]=="conn_vpn_success"){
                        obj.LastConnTime = XLY.Convert.LinuxToDateTime(masLongData[b]["@value"]);
                    }
                }
            }
        }
    }
    var admPath = allPath + "\\admob_user_agent.xml";
    if(XLY.File.IsValid(admPath)){
        var admData = eval('('+ XLY.File.ReadXML(admPath) +')');
        if(admData!=""&&admData!=null){
            var admStrData = admData.map.string;
            if(admStrData["#text"]!=""&&admStrData["#text"]!= null){
                obj.DeviceInfo = admStrData["#text"];
            }
        }
    }
    var adm1Path = allPath + "\\admob.xml";
    if(XLY.File.IsValid(adm1Path)){
        var adm1Data = eval('('+ XLY.File.ReadXML(adm1Path) +')');
        if(adm1Data!=""&&adm1Data!= null){
            var adm1BoolData = adm1Data.map.boolean;
            if(adm1BoolData!=""&&adm1BoolData!=null){
                for(var b in adm1BoolData){
                    if(adm1BoolData[b]["@name"]=="auto_collect_location"){
                        if(adm1BoolData[b]["@value"]=="true"){
                            obj.AutoCollectLocation = "是";
                        }
                    }
                }
            }
        }
    }
    var umePath = allPath + "\\umeng_general_config.xml";
    if(XLY.File.IsValid(umePath)){
        var umeData = eval('('+ XLY.File.ReadXML(umePath) +')');
        if(umeData!=""&&umeData!= null){
            var umeIntData = umeData.map.int;
            if(umeIntData!=""&&umeIntData!= null){
                for(var c in umeIntData){
                    if(umeIntData[c]["@name"]=="failed_requests"){
                        obj.FailedCount = umeIntData[c]["@value"];
                    }
                    if(umeIntData[c]["@name"]=="successful_request"){
                        obj.SuccessfulCount = umeIntData[c]["@value"];
                    }
                }
            }
            var umeLongData = umeData.map.long;
            if(umeLongData!=""&&umeLongData!= null){
                for(var d in umeLongData){
                    if(umeLongData[d]["@name"]=="last_request_time"){
                        obj.FirstActivateTime = XLY.Convert.LinuxToDateTime(umeLongData[d]["@value"]);
                    }
                    if(umeLongData[d]["@name"]=="first_activate_time"){
                        obj.LastReq = XLY.Convert.LinuxToDateTime(umeLongData[d]["@value"]);
                    }
                }
            }
        }
    }
    macFilePath = filePath+"\\umeng_it.cache";
    if(XLY.File.IsValid(macFilePath)){
        var arr = getFileInfo(usernode,macFilePath);
        obj.DeviceMAC = arr.mac;
        obj.DeviceXLY = arr.serial;
        obj.DeviceAndroidID = arr.android_id;
    }
    getUserChildNode(usernode);
    usernode.Items.push(obj);
    if(usernode.Items!=""&&usernode.Items!=null){
        root.TreeNodes.push(usernode);
    }
}
function getFileInfo(root,path){
    var handle = XLY.Blob.GetFileHandle(path);
    var aa = [0x73,0x65,0x72,0x69,0x61,0x6C];
    var bb = [0x61,0x6E,0x64,0x72,0x6F,0x69,0x64,0x5F,0x69,0x64];
    var cc = [0x6D,0x61,0x63];
    var a = XLY.Blob.FindBytesFromHandle(handle,0,aa);
    var b = XLY.Blob.FindBytesFromHandle(handle,0,bb);
    var c = XLY.Blob.FindBytesFromHandle(handle,0,cc);
    var arr = {};
    if(a!=-1){
        var aaa = XLY.Blob.GetBytesFromHandle(handle,a+8,XLY.Blob.GetBytesFromHandle(handle,a+7,1)[0]);
        arr.serial = XLY.Blob.ToString(aaa);
    }
    if(b!=-1){
        var bbb = XLY.Blob.GetBytesFromHandle(handle,b+0x0C,XLY.Blob.GetBytesFromHandle(handle,b+0x0B,1)[0]);
        arr.android_id = XLY.Blob.ToString(bbb);
    }
    if(c!=-1){
        var ccc = XLY.Blob.GetBytesFromHandle(handle,c+5,XLY.Blob.GetBytesFromHandle(handle,c+4,1)[0]);
        arr.mac = XLY.Blob.ToString(ccc);
    }
    XLY.Blob.CloseFileHandle(handle);
    return arr;
}
function getUserChildNode(root){
    var serverlistPath = filePath+"\\server_list_opt.json";
    if(XLY.File.IsValid(serverlistPath)){
        var data = eval('('+ XLY.File.ReadFile(serverlistPath) +')');
        if(data!=""&&data!=null){
            if(data.DEFAULT!=""&&data.DEFAULT!=null){
                var serverListNode = new TreeNode();
                serverListNode.Text = "服务器列表";
                serverListNode.Type = "";
                if(data.DEFAULT.servers!=""&&data.DEFAULT.servers!=null){
                    var freeNode = new TreeNode();
                    freeNode.Text = "免费服务器列表";
                    freeNode.Type = "ServerList";
                    var aa = data.DEFAULT.servers;
                    for(var a in aa){
                        var freeobj = new ServerList();
                        freeobj.Name = aa[a].city;
                        freeobj.Country = aa[a].country;
                        freeobj.Id = aa[a].load;
                        freeobj.Ip = aa[a].host;
                        freeNode.Items.push(freeobj);
                    }
                    serverListNode.TreeNodes.push(freeNode);
                }
                if(data.DEFAULT.vip_servers!=""&&data.DEFAULT.vip_servers!=null){
                    var vipNode = new TreeNode();
                    vipNode.Text = "VIP服务器列表";
                    vipNode.Type = "ServerList";
                    var bb = data.DEFAULT.vip_servers;
                    for(var b in bb){
                        var vipobj = new ServerList();
                        vipobj.Name = bb[b].city;
                        vipobj.Country = bb[b].country;
                        vipobj.Id = bb[b].load;
                        vipobj.Ip = bb[b].host;
                        vipNode.Items.push(vipobj);
                    }
                    serverListNode.TreeNodes.push(vipNode);
                }
                root.TreeNodes.push(serverListNode);
            }
            
        }
    }
    var logPath = filePath +"\\logs";
    var logFileName = eval('('+ XLY.File.FindFileNamesWithExtension(logPath) +')');
    if(logFileName!=""&&logFileName!= null){
        var LogLogNode = new TreeNode();
        LogLogNode.Text = "日志信息";
        LogLogNode.Type = "";
        for(var c in logFileName){
            var logNPath = logPath+"\\"+logFileName[c];
            if(XLY.File.IsValid(logNPath)){
                var logData = eval('('+ XLY.File.ReadFile(logNPath) +')');
                if(logData!=""&&logData!=null){
                    var aaa = logData.text.split("\n");
                    var reg1 = new RegExp(">:");
                    var logNode = new TreeNode();
                    logNode.Text = XLY.Convert.LinuxToDateTime(logFileName[c].split(".")[0]);
                    logNode.Type = "LogInfo";
                    for(var i in aaa){
                        if(aaa[i]!=""&&aaa[i]!= null){
                            var logobj = new LogInfo();
                            if(reg1.test(aaa[i])){
                                logobj.LogTime = aaa[i].split("\n")[0].split(">:")[0];
                                logobj.LogLog = aaa[i].split("\n")[0].split(">:")[1];
                            }
                            else
                            {
                                logobj.LogTime = aaa[i].split("\n")[0].split("<:")[0];
                                logobj.LogLog = aaa[i].split("\n")[0].split("<:")[1];
                            }
                            logNode.Items.push(logobj);
                        }
                    }
                    LogLogNode.TreeNodes.push(logNode);
                }
            }
        }
        root.TreeNodes.push(LogLogNode);
    }
}
function getInfo(root){
    var path = allPath +"\\vpn.prefs.xml";
    if(XLY.File.IsValid(path)){
        var data = eval('('+ XLY.File.ReadXML(path) +')');
        if(data!=""&&data!=null){
            var dataStr = data.map.string;
            var node = new TreeNode();
            node.Text = "最后访问服务器信息";
            node.Type = "LastConnInfo";
            var obj = new LastConnInfo();
            if(dataStr!=""&&dataStr!=null){
                for(var i in dataStr){
                    if(dataStr[i]["@name"]=="last_proto"){
                        obj.Proto = dataStr[i]["#text"];
                        
                        
                        
                    }
                    if(dataStr[i]["@name"]=="last_ip"){
                        obj.LastIp = dataStr[i]["#text"];
                    }
                    if(dataStr[i]["@name"]=="last_key"){
                        obj.LastKey = dataStr[i]["#text"];
                    }
                }
            }
            var dataInt = data.map.int;
            if(dataInt!=""&&dataInt!= null){
                if(dataInt["@value"]!=""&&dataInt["@value"]!=null){
                    obj.Port = dataInt["@value"];
                }
            }
            node.Items.push(obj);
            root.TreeNodes.push(node);
        }
    }
}