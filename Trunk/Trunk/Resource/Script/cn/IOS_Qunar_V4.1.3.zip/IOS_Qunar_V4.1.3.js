﻿/*[config]
<plugin name="去哪儿网,1" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\Qunar.png" app="com.qunar.iphoneclient8" version="4.1.3" description="去哪儿旅行" data="$data,ComplexTreeDataSource" >
<source>
<value>com.qunar.iphoneclient8</value>
</source>
<data type="User">
<item name="账号" code="accunt" type="string" width="100" ></item>
<item name="电话" code="mobile" type="string" width="100" ></item>
<item name="邮箱" code="email" type="string" width="100" ></item>
</data>
<data type="Attention" datefilter="flytime">
<item name="航班号" code="airnum" type="string" width="100" ></item>
<item name="航空公司" code="aircom" type="string" width="100"></item>
<item name="起飞时间" code="flytime" type="datetime" width="200"></item>
<item name="降落时间" code="downtime" type="datetime" width="200"></item>
<item name="航班状态" code="airmode" type="string" width="100" ></item>
<item name="起飞城市" code="departCity" type="string" width="100" ></item>
<item name="起飞机场" code="departAirport" type="string" width="100" ></item>
<item name="起飞通道" code="departRoute" type="string" width="100" ></item>
<item name="降落城市" code="arriveCity" type="string" width="100" ></item>
<item name="降落机场" code="arriveAirport" type="string" width="100" ></item>
<item name="降落通道" code="arriveRoute" type="string" width="100" ></item>
</data>
<data type="Favorate">
<item name="收藏内容" code="collection" type="string" width="100" ></item> 
<item name="相关链接" code="collectionUrl" type="URL" width="100" ></item> 
</data>
</plugin>
[config]*/

//定义数据结构

function User() {
	this.accunt = "";
	this.mobile = "";
	this.email = "";
}

function Attention() {
	this.airnum = "";
	this.aircom = "";
	this.flytime = "";
	this.downtime = "";
	this.airmode = "";

	this.departCity = "";
	this.departAirport = "";
	this.departRoute = "";
	this.arriveCity = "";
	this.arriveAirport = "";
	this.arriveRoute = "";
}

function Favorate() {
	this.collection = "";
	this.collectionUrl = "";
}

//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
}

//用户信息
function userNodeCreate(path) {
	var arr = new Array();
	try{
		var data = eval('(' + XLY.PList.ReadToJsonString(path) + ')');
		var obj = new User();
		for (var index in data) {
			if (data[index].UserName != null) {
				obj.accunt = data[index].UserName;
			}

			if (data[index].PhoneNumber != null) {
				obj.mobile = data[index].PhoneNumber;
			}

			if (data[index].Email != null) {
				obj.email = data[index].Email;
			}

		}
		arr.push(obj);
		return arr;
	}
	catch(e){
		return arr;
	}
}

//关注信息
function attentionNodeCreate(path) {
	var arr = new Array();
	try{
		var info = eval('(' + XLY.File.ReadXML(path) + ')');
		if(info.plist.array.dict.length==null)
		{
			var obj = new Attention();
			var data = eval(info.plist.array.dict);      
			for (var index2 in data.key) {

				if (data.key[index2] == "FlightNumber") {
					obj.airnum = data.string[index2 - 1];
				}
				if (data.key[index2] == "Airline") {
					obj.aircom = data.string[index2];
				}
				if (data.key[index2] == "DPlanTime") {
					obj.flytime = data.string[index2 - 1];
				}
				if (data.key[index2] == "APlanTime") {
					obj.downtime = data.string[index2];
				}
				if (data.key[index2] == "AirlineStatus") {
					obj.airmode = data.string[index2];
				}
				if (data.key[index2] == "DCity") {
					obj.departCity = data.string[index2 - 1];
				}
				if (data.key[index2] == "DAirport") {
					obj.departAirport = data.string[index2 - 1];
				}
				if (data.key[index2] == "DTerminal") {
					obj.departRoute = data.string[index2 - 1];
				}
				if (data.key[index2] == "ACity") {
					obj.arriveCity = data.string[index2];
				}
				if (data.key[index2] == "AAirport") {
					obj.arriveAirport = data.string[index2]
				}
				if (data.key[index2] == "ATerminal") {
					obj.arriveRoute = data.string[index2];
				}
			}
			arr.push(obj);
		}
		else{
			for (var index1 in info.plist.array.dict) {
				var obj = new Attention();
				var data = eval(info.plist.array.dict[index1]);

				for (var index2 in data.key) {

					if (data.key[index2] == "FlightNumber") {
						obj.airnum = data.string[index2 - 1];
					}
					if (data.key[index2] == "Airline") {
						obj.aircom = data.string[index2];
					}
					if (data.key[index2] == "DPlanTime") {
						obj.flytime = data.string[index2 - 1];
					}
					if (data.key[index2] == "APlanTime") {
						obj.downtime = data.string[index2];
					}
					if (data.key[index2] == "AirlineStatus") {
						obj.airmode = data.string[index2];
					}
					if (data.key[index2] == "DCity") {
						obj.departCity = data.string[index2 - 1];
					}
					if (data.key[index2] == "DAirport") {
						obj.departAirport = data.string[index2 - 1];
					}
					if (data.key[index2] == "DTerminal") {
						obj.departRoute = data.string[index2 - 1];
					}
					if (data.key[index2] == "ACity") {
						obj.arriveCity = data.string[index2];
					}
					if (data.key[index2] == "AAirport") {
						obj.arriveAirport = data.string[index2]
					}
					if (data.key[index2] == "ATerminal") {
						obj.arriveRoute = data.string[index2];
					}
				}
				arr.push(obj);
			}
		}

		return arr;
	}
	catch(e){
		return arr;
	}
}

//收藏信息
function favNodeCreate(path) {
	var arr = new Array();
	try{
		var info = eval('(' + XLY.File.ReadXML(path) + ')');
		if(info.plist.array.dict.length==null)
		{
			var data = eval(info.plist.array.dict);
			var obj = new Favorate();             
			for (var index2 in data.key) {
				if (data.key[index2] == "OPFavName") {
					obj.collection = data.string[index2];
				}
				if (data.key[index2] == "OPFavURL") {
					obj.collectionUrl = data.string[index2];
				}
			}
			arr.push(obj);
		}
		else{   
			for (var index1 in info.plist.array.dict) {
				var obj = new Favorate();        
				var data = eval(info.plist.array.dict[index1]);       
				for (var index2 in data.key) {
					if (data.key[index2] == "OPFavName") {
						obj.collection = data.string[index2];
					}
					if (data.key[index2] == "OPFavURL") {
						obj.collectionUrl = data.string[index2];
					}
				}
				arr.push(obj);
			}
		}

		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0] + "\\com.qunar.iphoneclient8\\Documents\\PCUser.dat";
var path2 = source[0] + "\\com.qunar.iphoneclient8\\Documents\\Attention.dat";
var path3 = source[0] + "\\com.qunar.iphoneclient8\\Documents\\OPFav.dat";

//节点实例化
var userNode = new TreeNode();
userNode.Text = "最后登录用户信息"
	userNode.Type = "User";

var attNode = new TreeNode();
attNode.Text = "关注航班信息";
attNode.Type = "Attention";

var favNode = new TreeNode();
favNode.Text = "收藏信息";
favNode.Type = "Favorate";

//节点填充
userNode.Items = userNodeCreate(path1);
attNode.Items = attentionNodeCreate(path2);
favNode.Items = favNodeCreate(path3);

//打印数据
result.push(userNode);
result.push(attNode);
result.push(favNode);
var res = JSON.stringify(result);
res;
