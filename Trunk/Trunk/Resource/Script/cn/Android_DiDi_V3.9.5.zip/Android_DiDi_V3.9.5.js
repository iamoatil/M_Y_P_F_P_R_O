﻿/*[config]
<plugin name="滴滴打车" group="地图公交,7" devicetype="android" icon="\icons\didi.png" pump="USB,Mirror,Wifi,Bluetooth,chip" app="com.sdu.didi.psnger" version="3.9.5" description="滴滴打车" data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/com.sdu.didi.psnger/databases/didi.db</value>
<value>/data/data/com.sdu.didi.psnger/databases/didi_im.db</value>
</source>
<data type="DD" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="分类" code="List" type="string" width = "150"></item>
</data>
<data type="User" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="用户名" code="UserName" type="string" width = "150"></item>
<item name="用户ID" code="UserID" type="string" width="200"></item>
<item name="头像" code="Url" type="url" width="200"></item>
</data>
<data type="Search" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="搜索内容" code="LocName" type="string" width = "150"></item>
<item name="具体地址" code="LocAddr" type="string" width="200"></item>
<item name="城市" code="LocCity" type="string" width="150"></item>
<item name="经度" code="LocLng" type="string" width="200"></item>
<item name="纬度" code="LocLat" type="string" width="100"></item>
</data>
<data type="Chat" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="会话ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Conversation" contract="DataState" datefilter = "LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="发送者" code="Sender" type="string" width="200"></item>
<item name="内容" code="Content" type="string" width="150"></item>
<item name="语音时长" code="VoiceTime" type="string" width = "200"></item>
<item name="发送时间" code="Time" type="string" width = "200"></item>
</data>
</plugin>
[config]*/
function DD(){
    this.List = "";
}
//定义搜索数据结构
function Search(){
    this.DataState = "Normal";
    this.LocName = "";
    this.LocAddr = "";
    this.LocCity = "";
    this.LocLng = "";
    this.LocLat = "";
}
//定义用户数据结构
function User(){
    this.DataState = "Normal";
    this.UserName = "";
    this.UserID = "";
    this.Url = "";
}
//定义会话成员数据结构
function Chat(){
    this.ID = "";
}
//定义会话聊天数据结构
function Conversation(){
    this.DataState = "Normal";
    this.Sender = "";
    this.Content = "";
    this.VoiceTime = "";
    this.Time = "";
}
//定义树数据结构
function TreeNode(){
    this.Text = "";
    this.TreeNodes = new Array();
    this.Items = new Array();
    this.Type = "";
    this.DataState = "Normal";
}
 
function bindTree(){
    var didi = new TreeNode();
    didi.Text = "滴滴打车";
    didi.Type = "DD";
    didi.Items = getDD();
    didi.DataState = "Normal";
    var user = new TreeNode();
    user.Text = "用户";
    user.Type = "User";
    user.Items = getUserInfo(db_didi_im);
    didi.TreeNodes.push(user);
    var search = new TreeNode();
    search.Text = "搜索";
    search.Type = "Search";
    search.Items = getSearchInfo(db_didi);
    didi.TreeNodes.push(search);
    var chat = new TreeNode();
    chat.Text = "会话";
    chat.Type = "Chat";
    var chatinfo = getChat(db_didi_im);
    chat.Items = chatinfo;
    didi.TreeNodes.push(chat);
    for(var i in chatinfo){
        var conversation = new TreeNode();
        conversation.Text = chatinfo[i].ID;        
        conversation.Type = "Conversation";
        conversation.Items = getConversationInfo(db_didi_im,chatinfo[i].ID);
        chat.TreeNodes.push(conversation);
    }
    result.push(didi);
}
function getDD(){
    var list = new Array();
    data = ["用户","搜索","会话"];
    for(var i in data){
        var obj = new DD();
        obj.List = data[i];
        list.push(obj);
    }
    return list;
}
function getUserInfo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct uid,avatar_url,uname from users" ) +')');
    for(var i in data){
        var obj = new User();
        obj.UserName = data[i].uname;
        obj.UserID = data[i].uid;
        obj.Url = data[i].avatar_url;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getSearchInfo(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from suggestion where loc_type=0" ) +')');
    for(var i in data){
        var obj = new Search();
        obj.LocName = data[i].loc_name;
        obj.LocAddr = data[i].loc_addr;
        obj.LocCity = data[i].loc_city;
        obj.LocLng = data[i].loc_lng;
        obj.LocLat = data[i].loc_lat;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getChat(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select distinct sid from users") +')');
    for(var i in data){
        var obj = new Chat();
        obj.ID = data[i].sid;
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}
function getConversationInfo(path,id){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from chat_record where sid = '"+id+"'" ) +')');
    for(var i in data){
        var obj = new Conversation();
        var name = eval('('+ XLY.Sqlite.Find(path,"select uname from users where uid='"+data[i].uid+"'") +')');
        obj.Sender = name[0].uname;
        obj.Content = data[i].content;
        if(data[i].voice_time>0){
            obj.VoiceTime = data[i].voice_time/1000+'s';
        }else{
            obj.VoiceTime = null;
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].create_time);
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
    return list;
}

//********************************************************
var source = $source;
var db1 = source[0];
var db2 =source[1];
//db1="D:\\temp\\data\\data\\com.sdu.didi.psnger\\databases\\didi.db";
//db2="D:\\temp\\data\\data\\com.sdu.didi.psnger\\databases\\didi_im.db";
var charactor1 = "\\chalib\\Android_DiDi_V3.9.5\\didi.db.charactor";
var charactor2 = "\\chalib\\Android_DiDi_V3.9.5\\didi_im.db.charactor";
db_didi=XLY.Sqlite.DataRecovery(db1,charactor1,"suggestion");
db_didi_im=XLY.Sqlite.DataRecovery(db2,charactor2,"chat_record,users");


//var charactor = "\\chalib\\IOS_WeiZhang_V4.2.5\\weizhang.db.charactor";
var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
