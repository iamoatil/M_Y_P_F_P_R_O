﻿/*[config]
<plugin name="新浪微博,10" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\sinaweibo.png" app="com.sina.weibo" version="4.6.1" description="新浪-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>com.sina.weibo</value>
</source>

<data type="Account" contract = "DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="昵称" code="NickName" type="string" width="120" ></item>
<item name="账号ID" code="ID" type="string" width="120" ></item>
</data>

<data  type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友分组名" code="Name" type="string" width = "100" ></item>
<item name="分组ID" code="ID" type="string" width="200"></item>
</data>


<data type="Friend" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="string" width="100" ></item>
<item name="好友昵称" code="Name" type="string" width="120" ></item>
<item name="更新时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
</data>

<data detailfield="Contentinfo" type="Weiboinfo" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="微博发布者" code="Name" type="string" width="120" ></item>
<item name="微博发布者ID" code="ID" type="string" width="100" ></item>
<item name="微博动态" code="Contentinfo" type="string" width="400" ></item>
<item name="时间" code="Time" type="string" width="140" ></item>
</data>

<data type="GroupTalk" contract="DataState" datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群组名" code="Name" type="string" width = "220" ></item>
<item name="发起人" code="StartName" type="string" width = "100" ></item>
<item name="群成员" code="Member" type="string" width = "300" ></item>
<item name="更新时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
<item name="群组ID" code="ID" type="string" width="150"></item>
</data>

<data detailfield="Content" type="Message" contract="DataState,Conversion"  datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width="100"></item>
<item name="接收人" code="Receiver" type="string" width="100"></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width = "150"></item>
<item name="消息类型" code="MsgType" type="Enum" format="EnumColumnType" width="80"  ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

</plugin>
[config]*/

function Account() {
    this.NickName = "";
    this.ID = "";
    this.DataState = "Normal";
}

function Group() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
}

function Friend() {
    this.Name = "";
    this.Time= null;
    this.ID = "";
    this.DataState = "Normal";
}

function Weiboinfo() {
    this.Name = "";
    this.ID = "";
    this.Time = null;
    this.Contentinfo = "";
    this.DataState = "Normal";
}

function GroupTalk() {
    this.DataState = "Normal";
    this.Name = "";
    this.Member = "";
    this.ID = "";
    this.Time = null;
}

function Message() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Content = "";
    this.MsgType = "";
    this.Type = "";
    this.SendState = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState="Normal";
}

var result = new Array();

//源文件
var source = $source;
var folder = source[0] + "\\com.sina.weibo";
//测试数据
//var folder = "C:\\XLYSFTasks\\任务-2016-04-21-12-09-14\\source\\IosData\\2016-04-21-12-09-46\\8c5fdfb12d1dc920fa571712932cf5e5727dfca7\\com.sina.weibo";
var accPath = folder + "\\Library\\Preferences\\com.sina.weibo.plist";
var dataPath = eval('('+XLY.File.FindFileNames(folder+"\\Documents")+')');

//获取群聊群组ID
function GetGroTalkId(userId){
    var table = "t_buddy,t_group,t_group_member,t_message,";
    var path2 = folder+"\\Documents\\message_"+userId+".db";
    var db = eval('('+ XLY.Sqlite.FindByName( path2, "t_group") +')');
    if(db!=null&&db.length!=0){
        for(var i in db){
            if(i==db.length-1){
                table+="t_message_g_"+db[i].id;
            }
            else
            {
                table+="t_message_g_"+db[i].id+",";
            }
        } 
        var charactor2 = "\\chalib\\IOS_SinaWeibo_V4.6.1\\message.db.charactor";
        var msgDB = XLY.Sqlite.DataRecovery( path2,charactor2,table);
    }
    return msgDB; 
    
}

//主界面函数
function ParesCore(){
    //定义主节点
    var sinaNode = new TreeNode();
    sinaNode.Text = "新浪微博";
    sinaNode.Type = "Account";
    var account = GetAccount();
    sinaNode.Items = account;
    for(var i in account){
        var path1 = "";
        for(var k in dataPath){
            if(dataPath[k].indexOf("db_")>=0&&dataPath[k].indexOf(account[i].ID)>=0){
                path1 = dataPath[k]+".dat";
                break;
             }
        }
        var charactor1 = "\\chalib\\IOS_SinaWeibo_V4.6.1\\db_46100.dat.charactor";
        var weiboPath = XLY.Sqlite.DataRecovery( folder+"\\Documents\\"+path1, charactor1, "contact_groups,contact_x_group,contacts,weibos");
        //定义账户节点
        var accNode = new TreeNode();
        accNode.Text = account[i].NickName;
        //定义好友分组节点
        var groNode = new TreeNode();
        groNode.Text = "好友分组";
        groNode.Type = "Group";
        var group = GetGroup(weiboPath);
        groNode.Items = group;
        //定义未分组节点
        var ungroNode = new TreeNode();
        ungroNode.Text = "未分组好友";
        ungroNode.Type = "Friend";
        var ungroup = GetUnGroFri(weiboPath);
        ungroNode.Items = ungroup;
        groNode.TreeNodes.push(CreateNode(weiboPath,ungroup,ungroNode));
        //查询分组好友信息
        for(var j in group){
            //定义分组信息节点
            var friNode = new TreeNode();
            friNode.Text = group[j].Name;
            friNode.Type = "Friend";
            var friend = GetFriend(weiboPath,group[j].ID);
            friNode.Items = friend;
            friNode.DataState = group[j].DataState;
            groNode.TreeNodes.push(CreateNode(weiboPath,friend,friNode));
        }
        accNode.TreeNodes.push(groNode);
        //定义群聊节点
        var groTalkNode = new TreeNode();
        groTalkNode.Text = "群聊";
        groTalkNode.Type = "GroupTalk";
        var groTalk = GetGroTalk(account[i].ID);
        groTalkNode.Items = groTalk;
        //定义群聊天信息节点
        for(var m in groTalk){
            var groMsgNode = new TreeNode();
            groMsgNode.Text = groTalk[m].Name;
            groMsgNode.Type = "Message";
            groMsgNode.Items = GetMessage(account[i].ID,account[i].NickName,"群组",groTalk[m].ID);
            groMsgNode.DataState = groTalk[m].DataState;
            groTalkNode.TreeNodes.push(groMsgNode);
        }
        accNode.TreeNodes.push(groTalkNode);
        //定义私信节点
        var priMsgNode = new TreeNode();
        priMsgNode.Text = "私信";
        priMsgNode.Type = "Message";
        priMsgNode.Items = GetMessage(account[i].ID,account[i].NickName,"私信");
        accNode.TreeNodes.push(priMsgNode);
        sinaNode.TreeNodes.push(accNode);
    }
    result.push(sinaNode);
}

//创建好友微博消息节点
function CreateNode(path,data,dataNode){
    for(var m in data){
        //定义好友微博节点
        var weiboNode = new TreeNode();
        weiboNode.Text = data[m].Name;
        weiboNode.Type = "Weiboinfo";
        var weibo = GetWeibo(path,data[m].ID);
        weiboNode.Items = weibo;
        weiboNode.DataState = data[m].DataState;
        dataNode.TreeNodes.push(weiboNode);
    }
    return dataNode;
}

//提取账户信息
function GetAccount(){
    var user = eval('('+ XLY.PList.ReadToJsonString(accPath) +')');
    var Items = new Array();
    for(var i in user){
        var acc = user[i]["WBAccounts"];
        if(acc!=null){
            for(var m in acc[0]){
                var account = new Account();
                account.NickName = acc[0][m][5]["screenName"];
                account.ID = acc[0][m][7]["userID"];
                Items.push(account);
            }   
        }
    }
    return Items;
}

//提取好友分组信息
function GetGroup(path){
    var db = eval('('+ XLY.Sqlite.FindByName( path, "contact_groups") +')');
    var Items = new Array();
    for(var i in db){
        var gro = new Group();
        gro.Name = db[i].name;
        gro.ID = db[i].groupID;
        gro.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(gro);
    }
    return Items;
}

//提取分组好友信息
function GetFriend(path,groID){
    var db = eval('('+ XLY.Sqlite.Find( path, "select * from contact_x_group where groupID = '"+groID+"'") +')');
    var Items = new Array();
    if(db!=null&&db.length>0){
        for(var i in db){
            var db2 = eval('('+ XLY.Sqlite.Find( path, "select screenName,userID,cast(lastMessageTime as text ) as lastTime from contacts where userID = '"+db[i].userID+"'") +')');
            if(db2.length>0){
                for(var j in db2){
                    var fri = new Friend();
                    fri.Name = db2[j].screenName;
                    fri.ID = db2[j].userID;
                    fri.Time = XLY.Convert.LinuxToDateTime(parseInt(db2[j].lastTime));
                    Items.push(fri);
                }
            }
        }
    }
    return Items;
}

//获取未分组好友信息
function GetUnGroFri(path){
    var db = eval('('+ XLY.Sqlite.Find( path, "select screenName,userID,cast(lastMessageTime as text ) as lastTime from contacts ") +')');
    var Items = new Array();
    if(db!=null&&db.length>0){
        for(var i in db){
            var db2 = eval('('+ XLY.Sqlite.Find( path,"select * from contact_x_group where userID = '"+db[i].userID+"'") +')');
            //log(db2);
            if(db2.length<=0){
                var fri = new Friend();
                fri.Name = db[i].screenName;
                fri.ID = db[i].userID;
                fri.Time = XLY.Convert.LinuxToDateTime(parseInt(db[i].lastTime));
                Items.push(fri);
            }
        }
    }
    return Items;
}

//提取好友微博信息
function GetWeibo(path,friendId){
    var db = eval('('+ XLY.Sqlite.Find( path, "select * from weibos where uid = '" + friendId + "'") +')');
    var Items = new Array();
    if(db!=null&&db.length>0){
        for(var i in db){
            var weibo = new Weiboinfo();
            weibo.Name = db[i].nick;
            weibo.ID = db[i].uid;
            weibo.Time = XLY.Convert.LinuxToDateTime(db[i].dateline);
            weibo.Contentinfo = db[i].content+ "................纬度" + db[i].latitude + "，经度" + db[i].longitude;
            weibo.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
            Items.push(weibo);
        }
    }
    return Items;
}

//获取群聊天信息
function GetGroTalk(userId){
    var Items = new Array();
    var msgDB = GetGroTalkId(userId);
    
    var db1 = eval('('+ XLY.Sqlite.Find( msgDB, "select * from t_group") +')');
    var db2 = eval('('+ XLY.Sqlite.Find( msgDB, "select * from t_buddy") +')');
    if(db1!=null&&db1.length>0){
        for(var j in db1){
            var groTalk = new GroupTalk();
            groTalk.Name = db1[j].name;
            groTalk.Time = XLY.Convert.LinuxToDateTime(db1[j].modified_time);
            groTalk.ID = db1[j].id;
            if(db2!=null&&db2.length>0){
                for(var m in db2){
                    if(db1[j].owner==db2[m].id)
                        groTalk.StartName = db2[m].name;
                }
            }
            var db3 = eval('('+ XLY.Sqlite.Find(msgDB,"select * from t_group_member where id = '" + db1[j].id + "'")+')');
            var memberArr = [];
            if(db3!=null&&db3.length>0){
                for(var n in db3){
                    for(var x in db2){
                        if(db3[n].uid==db2[x].id)
                            memberArr.push(db2[x].name);
                    }
                }
            }
            groTalk.Member = memberArr.join(",") ;
            groTalk.DataState = XLY.Convert.ToDataState(db1[j].XLY_DataType);
            Items.push(groTalk);
        }
    }
    return Items;
}

//提取好友聊天信息
function GetMessage(userId,userName,msgType,groTalkId){
    var Items = new Array();
    var msgDB = GetGroTalkId(userId);
    var db1 = null;
    if(msgType=="群组"&&groTalkId!=null){
        db1 = eval('('+ XLY.Sqlite.Find( msgDB,"select * from '"+"t_message_g_"+groTalkId+"'") +')');
    }
    else
    {
       db1 = eval('('+ XLY.Sqlite.Find(msgDB,"select * from t_message") +')');
    }  
   if(db1!=null&&db1.length>0){
        for(var m in db1){
            var msg = new Message();
            msg.Time = XLY.Convert.LinuxToDateTime(db1[m].time);
            msg.Content = db1[m].content+"................纬度" + db1[m].latitude + "，经度" + db1[m].longitude;
            switch(db1[m].type){
                case 0 : msg.Type = "String"; msg.MsgType = "文本";break;
                case 1 : msg.Type = "Image"; msg.MsgType = "图片";break;
                //case 2 : msg.Type = "Video"; msg.MsgType = "视频";break;
                //case 4 : msg.Type = "Audio"; msg.MsgType = "音频";break;
                default : msg.Type = "String"; msg.MsgType = "系统消息";
            }
            var db2 = null;
            if(msgType=="群组"){
                var db2 = eval('('+ XLY.Sqlite.Find(msgDB,"select * from t_buddy where id = '" + db1[m].sender_uid + "'") +')');
            }
            else
            {
                var db2 = eval('('+ XLY.Sqlite.Find(msgDB,"select * from t_buddy where id = '" + db1[m].uid + "'") +')');
            }
            
            if(db2!=null&&db2.length!=0){
                msg.Sender = db2[0].name;
            }
            
            if(db1[m].sender_uid==userId||db1[m].uid==userId){
                msg.SendState = "Send";
                if(msgType=="群组"){
                    msg.Receiver = "群组";
                }
                else
                {
                    var db3 = eval('('+ XLY.Sqlite.Find(msgDB,"select * from t_buddy where id = '" + db1[m].chat_id + "'") +')');
                    if(db3!=null&&db3.length!=0){
                        msg.Receiver = db3[0].name;
                    }
                }   
            }
            else
            {
                msg.SendState = "Receive";
                msg.Receiver = userName;
            }
            msg.DataState = XLY.Convert.ToDataState(db1[m].XLY_DataType);
            Items.push(msg);
        }
   }
    return Items ;    
}

ParesCore();
var res = JSON.stringify(result);
res;
