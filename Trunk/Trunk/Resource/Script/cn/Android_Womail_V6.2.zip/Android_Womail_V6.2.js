﻿/*[config]
<plugin name="沃邮箱,6" group="主流邮箱,4" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\womail_icon.png" app="com.asiainfo.android" version="6.2" description="沃邮箱" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.asiainfo.android/databases/#F</value>
<value>/data/data/com.asiainfo.android/shared_prefs/womail.xml</value>
</source>
<data type="Contact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="邮箱账号" code="Account" type="string" width="" format=""></item>
</data>
<data type="List" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format = "EnumDataState" ></item>
<item name="邮箱账号" code="Account" type="string" width="" format = ""></item>
<item name="邮箱账号" code="ID" show="false" type="string" width="" format=""></item>
</data>
<data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="文件ID" code="Folder_id" show="false" type="string" width="150" format = ""></item>
<item name="主题" code="Subject" type="string" width="200" format = ""></item>
<item name="发送时间" code="Date" type="datetime" width="200" format= ""></item>
<item name="发件人地址" code="SenderList" type="string" width="300" format = ""></item>
<item name="收件人地址" code="ToList" type="string" width="300" format = ""></item>
<item name="邮件正文" code="Content" type="string" width="300" format = ""></item>
<item name="查看状态" code="Read" type="string" width="300" format = ""></item>
<item name="删除状态" code="Deleted" type="string" width="150" format = ""></item>
<item name="邮件附件" code="Attachment" type="string" width="300" format = ""></item>
<item name="回复" code="Answered" type="string" width="300" format = ""></item>
<item name="标记" code="Flagged" type="string" width="300" format = ""></item>
<item name="抄送" code="CC" type="string" width="300" format = ""></item>
<item name="密送" code="BCC" type="string" width="300" format = ""></item>
</data>
</plugin>
[config]*/
//********************************************* 定义数据结构*********************************************

function Contact(){
    this.DataState = "Normal";
    this.Account = "";
    this.ID = "";
}
function List(){
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
}
function Message() {
    this.Deleted = "";
    this.Folder_id = "";
    this.Subject = "";
    this.Date = "";
    this.SenderList = "";
    this.ToList = "";
    this.Content = "";
    this.Read = "";
    this.Attachment = "";
    this.Answered = "";
    this.Flagged = "";
    this.CC = "";
    this.BCC = "";
    this.DataState = "Normal";
}

function TreeNode() {
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState = "Normal";
}


//********************************************* 处理APP数据*********************************************
//源文件
var source = $source;
var db1 = source[0];
var db2 = source[1];
//var db1 = "D:\\temp\\data\\data\\com.asiainfo.android\\databases";
//var db2 = "D:\\temp\\data\\data\\com.asiainfo.android\\shared_prefs\\womail.xml";

function main(){
    var account = new TreeNode();
    account.Text = "Womail";
    account.Type = "Contact";
    account.DataState = "Normal";
    var accountinfo=getAccount(db2); 
    account.Items = accountinfo; 
    var paccount = db1+"\\"+accountinfo[0].ID+".db";
    var minfo = getMail(paccount);
    for(var i in minfo){
        newTreeNode(minfo[i].Name,"Message",getMessageInfoForChildNodes(paccount,minfo[i].ID),account);
    }
    result.push(account);
    
}

function newTreeNode(text,type,items,root){
    name = new TreeNode();
    name.Text = text;
    name.Type = type;
    name.Items = items;
    root.TreeNodes.push(name);
}

function getAccount(path){
    var list = new Array();
    var data = eval('('+ XLY.File.ReadXML(path) +')');
    var c = data.map.string;
    var obj = new Contact();
    for(var i in c){
        if(c[i]['@name']=="account_cur_mail"){
            obj.Account=c[i]['#text'];
        }
        if(c[i]['@name']=="account_cur_uuid"){
            obj.ID=c[i]['#text'];;
        }
    }
    list.push(obj);
    return list;
}

function getMail(path){
    var list = new Array();
    var data = eval('('+ XLY.Sqlite.Find(path,"select * from folders") +')');
    for(var i in  data){
        var obj = new List();
        obj.Name = data[i].name;
        obj.ID = data[i].id;
        list.push(obj);
    }
    return list;
}

var result = new Array();
main();
var res = JSON.stringify(result);
res;











//**************************************** 定义处理APP数据的方法****************************************

//获取邮件信息
function getMessageInfoForChildNodes(path,id) {
    var data = eval('(' + XLY.Sqlite.Find(path, "select * from messages where folder_id='"+id+"' ") + ')');
    var info = new Array();
    for (var index in data) {
    var obj = new Message();
    obj.Deleted = (data[index].deleted == 1) ? "已删" : "未删";
            var a = data[index].folder_id;
            switch(a){
              case 1:
                obj.Folder_id = "收件箱";
                break;
              case 2:
                obj.Folder_id = "已删除";
                break;
              case 3:
                obj.Folder_id = "草稿箱";
                break;
              case 4:
                obj.Folder_id = "待发送";
                break;
              case 5:
                obj.Folder_id = "已发送";
                break;
              case 6:
                obj.Folder_id = "星标邮件";
                break;
            }
            obj.Subject = data[index].subject;
            obj.Date = XLY.Convert.LinuxToDateTime(data[index].date);
            obj.SenderList = data[index].sender_list;
            obj.ToList = data[index].to_list;
            obj.Content = data[index].text_content;
            obj.Read = (data[index].read == 1) ? "已读" : "未读";
            obj.Attachment = data[index].Attachment;
            obj.Answered = (data[index].answered == 1) ? "已回复" : "未回复";
            obj.Flagged = (data[index].flagged == 1) ? "已标记" : "未标记";
            obj.CC = data[index].cc_list;
            obj.BCC = data[index].bcc_list;
            obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
            
            info.push(obj);
    }
    return info;
}


