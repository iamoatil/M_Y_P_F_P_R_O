﻿/*[config]
<plugin name="新浪微博,2" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\sinaweibo.png" app="com.sina.weibo" version="4.0.1" description="新浪-导航树" data="$data,ComplexTreeDataSource" >
<source>
<value>com.sina.weibo</value>
</source>

<data type="Account">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="名称" code="Name" type="string" width="100" ></item>
<item name="账号ID" code="Id" type="string" width="50" ></item>
<item name="最近登录时间" code="Lasttime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>

<data detailfield="Contentinfo" type="Weiboinfo" contract="DataState" datefilter="Stime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="微博发布者" code="FName" type="string" width="150" ></item>
<item name="微博发布者ID" code="Fid" type="string" width="100" ></item>
<item name="微博动态" code="Contentinfo" type="string" width="300" ></item>
<item name="时间" code="Stime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="微博参与者" code="Rname" type="string" width="150" ></item>
</data> 

<data detailfield="Contentinfo" type="AtMe" contract="DataState" datefilter="Stime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="@我的好友" code="FName" type="string" width="200" ></item>
<item name="好友ID" code="Fid" type="string" width="100" format=""></item>
<item name="微博动态" code="Contentinfo" type="string" width="400" format=""></item>
<item name="时间" code="Stime" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data> 

<data detailfield="Userinfo" type="User" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="名称" code="Name" type="string" width="150" ></item>
<item name="账号ID" code="Id" type="string" width="150" ></item>
<item name="用户名称详细信息" code="Userinfo" type="string" width="200" ></item>
<item name="头像" code="Headimage" type="image" width="50" ></item>
<item name="备注签名" code="Remark" type="string" width="350" ></item>
</data>

<data detailfield="Content" type="Message" contract="DataState,Conversion"  datefilter="Time">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送人" code="Sender" type="string" width="150"></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="接收人" code="Receiver" type="string" width="150"></item>
<item name="内容" code="Content" type="string" width="200" ></item>
<item name="时间" code="Time" type="datetime" order="desc" format="yyyy-MM-dd HH:mm:ss" width="200"></item>
<item name="附件" code="Attachment" type="url" width="350" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

<data  type="Contact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="微博ID" code="ID" type="string" width="100" ></item>
<item name="微博昵称" code="Name" type="string" width="200"></item>
</data>

<data  type="Group" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友分组名" code="Name" type="string" width="100" ></item>
<item name="分组ID" code="ID" type="string" width="200"></item>
</data>

<data type="RecentContact" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="联系人ID" code="ID" type="string" width="100" ></item>
<item name="联系人昵称" code="Name" type="string" width="50" ></item>
<item name="联系人头像" code="profileImage" type="image" width="50" ></item>
</data>
</plugin>
[config]*/

//****************************************定义数据结构****************************************
//定义Account对象
function Account() {
    this.Name = "";
    this.Id = "";
    this.Lasttime = null;
    this.DataState = "Normal";
}

//定义Weiboinfo对象
function Weiboinfo() {
    this.FName = "";
    this.Fid = "";
    this.Rname = "";
    this.Stime = null;
    this.Contentinfo = "";
    this.DataState = "Normal";
}

//定义AtMe对象
function AtMe() {
    this.FName = "";
    this.Fid = "";
    this.Rname = "";
    this.Stime = null;
    this.Contentinfo = "";
    this.DataState = "Normal";
}

//定义User对象
function User() {
    this.Name = "";
    this.Id = "";
    this.Userinfo = "";
    this.Headimage = "";
    this.Remark = "";
    this.DataState = "Normal";
}

//定义Message对象
function Message() {
    this.Sender = "";
    this.Receiver = "";
    this.Time = null;
    this.Content = "";
    this.SenderImage = "";
    this.Attachment = "";
    this.Type = "";
    this.SendState = "";
    this.DataState = "Normal";
}

//定义Contact对象
function Contact() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
}

//定义Group对象
function Group() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
}

//定义RecentContact对象
function RecentContact() {
    this.DataState = "Normal";
    this.Name = "";
    this.ID = "";
    this.profileImage = "";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
    this.Tag = "";
}

//****************************************定义处理APP数据的方法****************************************
//获取联系人信息
function GetContact(contacts) {
    var coninfo = new Contact();
    coninfo.ID = contacts.id
    coninfo.Name = contacts.name
    coninfo.DataState = XLY.Convert.ToDataState(contacts.XLY_DataType);
    return coninfo;
}

//获取帐号信息
function Account(data) {
    this.Name = XLY.Convert.ToString(data.screenName);
    this.Id = XLY.Convert.ToString(data.userID);
    this.Lasttime = XLY.Convert.LinuxToDateTime(parseInt(data.lastTime));
    this.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return this;
}

//获取关注人的详细信息
function getUser(data) {
    var info = new Array();
    for (var index in data) {
        var obj = new User();
        obj.Name = XLY.Convert.ToString(data[index].screenName);
        obj.Id = XLY.Convert.ToString(data[index].userID);
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        obj.Headimage = XLY.Convert.ToString(data[index].profileImageURL);
        obj.Userinfo = XLY.Convert.ToString(data[index].searchText);
        obj.Remark = XLY.Convert.ToString(data[index].remark);
        info.push(obj);
    }
    return info;
}

//获取@我的信息
function AtMe(weiboinfo) {
    this.FName = XLY.Convert.ToString(weiboinfo.nick);
    this.Fid = XLY.Convert.ToString(weiboinfo.uid);
    this.Stime = XLY.Convert.LinuxToDateTime(parseInt(weiboinfo.dateline));
    this.Contentinfo = XLY.Convert.ToString(weiboinfo.rtreason) + XLY.Convert.ToString(weiboinfo.rtrootnick) + XLY.Convert.ToString(weiboinfo.content);
    this.DataState = XLY.Convert.ToDataState(weiboinfo.XLY_DataType);
    return this;
}

//获取微博信主页信息
function Weibo(info) {
    AtMe.call(this, info);
    this.Rname = XLY.Convert.ToString(info.rtrootnick);
    return this;
}

//获取最近联系人信息
function getRecentContactInfo(path, data) {
    var obj = new RecentContact();
    obj.ID = data.uid;
    obj.Date = XLY.Convert.LinuxToDateTime(parseInt(data.time));
    var contactInfos = ExecSql(path, "select * from contacts where userID='" + data.uid + "'");
    if (contactInfos.length > 0) {
        obj.Name = contactInfos[0].screenName;
        obj.profileImage = contactInfos[0].profileImageURL;
    } else {
        obj.Name = "未关注人";
    }
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    return obj;
}

//获取私信的消息内容
function getMessageInfo(path,uinfo,sx) {
    var sql = "select * from pm_messages where talkToUserId='" + sx.ID + "'";
    var message = ExecSql(path, sql);
    var info = new Array();
    for (var i in message) {
        var sxm = message[i];
        var sxmessage = new Message();
        if (sxm.sendByMe == 1) {
            sxmessage.Sender = XLY.Convert.ToString(uinfo.screenName);
            sxmessage.Receiver = XLY.Convert.ToString(sx.Name);
        } else {
            sxmessage.Receiver = XLY.Convert.ToString(uinfo.screenName);
            sxmessage.Sender = XLY.Convert.ToString(sx.Name);
            sxmessage.SenderImage = sx.profileImage;
        }
        sxmessage.SendState = (sxm.sendByMe == 1) ? "Send" : "Receive";
        var attach = ExecSql(path, "select * from pm_attachments where _msg_id='" + sxm.xly_id + "'");
        if (attach.length != 0) {
            sxmessage.Attachment = attach[0].s3_url;
        }
        sxmessage.Time = XLY.Convert.LinuxToDateTime(sxm.serverTime);
        sxmessage.Content = XLY.Convert.ToString(sxm.content);
        if (sxm.latitude != 0) {
            sxmessage.Content = sxmessage.Content + ",纬度" + sxm.latitude + "，经度" + sxm.longitude;
        }
        sxmessage.DataState = XLY.Convert.ToDataState(sxm.XLY_DataType);
        info.push(sxmessage);
    }
    var consql = "select * from pm_conversations where userId='" + sx.ID + "'";
    var data = ExecSql(path, consql);
    var info = new Array();
    for (var i in data) {
        var row = data[i];
        var obj = new Message();
        obj.Receiver = XLY.Convert.ToString(uinfo.screenName);
        obj.Sender = XLY.Convert.ToString(sx.Name);
        obj.SenderImage = row.portrait;
        obj.SendState = "Receive";
        obj.Time = XLY.Convert.LinuxToDateTime(row.messageTime);
        obj.Content = XLY.Convert.ToString(row.messageContent);
        obj.DataState = XLY.Convert.ToDataState(row.XLY_DataType);
        info.push(obj);
    }
    return info;
}

//处理数据库查询
function ExecSql(path, sql) {
    var info = XLY.Sqlite.Find(path, sql);
    if (info.length > 0) {
        var data = eval('(' + info + ')');
        return data;
    }
}

//匹配特定的字符串
function search(str) {
    var reg = /db_40101_+[0-9]+.dat+$/gi;
    var target = reg.test(str);
    if (target) {
        return str;
    }
}

//截取字符串
function cut(str) {
    var end = str.lastIndexOf(".");
    var resource = str.slice(9, end);
    if (resource != null) {
        return resource;
    }
}

function BuildGuanZhuTreeNodes(path,node) {
    var data = ExecSql(path, "select * from contact_groups ");
    var info = new Array();
    for (var index in data) {
        //获取关注分组的数据信息
        var gzinfo = new Group();
        gzinfo.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
        gzinfo.Name = data[index].name;
        gzinfo.ID = data[index].groupID;
        info.push(gzinfo);

        //创建关注树的子节点
        var childNode = new TreeNode();
        childNode.Text = data[index].name;
        childNode.Type = "User";
        childNode.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        var buddy = ExecSql(path, "select * from (select c.*,g.name,g.groupID,cast(lastUsedTime as text )as lastTime from contacts c  left join (select cxg.*,cg.[name] from contact_x_group cxg left join contact_groups cg on cg.[groupID]=cxg.[groupID])as g on g.[userID]=c.[userID]) where groupID='" + data[index].groupID + "'");
        childNode.Items = getUser(buddy);
        node.TreeNodes.push(childNode);
    }
    //创建未分组关注人节点
    var noGroup = new TreeNode();
    noGroup.Text = "未分组关注";
    noGroup.Type = "User";
    var noGroupInfo = ExecSql(path, "select * from (select c.*,g.name,g.groupID,cast(lastUsedTime as text )as lastTime from contacts c  left join (select cxg.*,cg.[name] from contact_x_group cxg left join contact_groups cg on cg.[groupID]=cxg.[groupID])as g on g.[userID]=c.[userID]) where groupID is null ");
    noGroup.Items = getUser(noGroupInfo);
    node.TreeNodes.push(noGroup);

    //创建好友节点
    var noGroup = new TreeNode();
    noGroup.Text = "好友";
    noGroup.Type = "User";
    var noGroupInfo = ExecSql(path, "select * from (select c.*,g.name,g.groupID,cast(lastUsedTime as text )as lastTime from contacts c  left join (select cxg.*,cg.[name] from contact_x_group cxg left join contact_groups cg on cg.[groupID]=cxg.[groupID])as g on g.[userID]=c.[userID]) where relationship=3 ");
    noGroup.Items = getUser(noGroupInfo);
    node.TreeNodes.push(noGroup);

    node.Items = info;
}

function BuildChildNodesForAccount(accinfo,data,user) {
    //关注
    var guanzhuTree = new TreeNode();
    guanzhuTree.Text = "关注列表";
    guanzhuTree.Type = "Group";
    //提取关注数据
    BuildGuanZhuTreeNodes(data,guanzhuTree);

    //@我 
    var atwoTree = new TreeNode();
    atwoTree.Text = "与我相关";
    atwoTree.Type = "AtMe";
    //提取@我数据
    var atsql = "select * from weibos as w where rtrootuid='" + user.userID + "'";
    var atifnos = ExecSql(data, atsql);
    for (var index in atifnos) {
        var atweibo = atifnos[index];
        var atwoinfo = new AtMe(atweibo);
        atwoTree.Items.push(atwoinfo);
    }

    //微博首页
    var weibosourcesTree = new TreeNode();
    weibosourcesTree.Text = "微博首页";
    weibosourcesTree.Type = "Contact";
    //提取微博首页数据
    var wbsql = "select distinct * from(select w.[nick] as name,w.[uid] as id from weibos as w where rtrootuid<>'" + user.userID + "' OR rtrootuid is null)";
    var weiboinfos = ExecSql(data, wbsql);
    for (var index in weiboinfos) {
        var wb = weiboinfos[index];
        var weiboinfo = GetContact(wb);
        weibosourcesTree.Items.push(weiboinfo);
        var weiboinfosTree = new TreeNode();
        weiboinfosTree.Text = wb.name + "(" + wb.id + ")";
        weiboinfosTree.Type = "Weiboinfo";
        weiboinfosTree.Tag = XLY.Convert.ToString(parseInt(wb.id));
        var wbdatasql = "select * from weibos as w where uid='" + weiboinfosTree.Tag + "' ";
        var wbdata = ExecSql(data, wbdatasql);
        for (var i in wbdata) {
            var wbd = wbdata[i];
            var wbmessage = new Weibo(wbd);
            weiboinfosTree.Items.push(wbmessage);
        }
        weibosourcesTree.TreeNodes.push(weiboinfosTree);
    }

    //私信
    var sixinTree = new TreeNode();
    sixinTree.Text = "私信";
    sixinTree.Type = "RecentContact";
    var sixinsql = "select distinct uid,XLY_DataType from(select co.[userId]as uid,co.[XLY_DataType] from pm_conversations co  union all select m.[talkToUserId] as uid,m.[XLY_DataType] from pm_messages m )"
    // 读取私信信息
    var sixininfos = ExecSql(data, sixinsql);
    for (var index in sixininfos) {
        var sx = sixininfos[index];
        if (sx.uid.length > 2) {
            var sxinfo = getRecentContactInfo(data, sx);
            sixinTree.Items.push(sxinfo);
            var sxmessagesTree = new TreeNode();
            sxmessagesTree.Text = sxinfo.Name + "(" + sxinfo.ID + ")";
            sxmessagesTree.Type = "Message";
            sxmessagesTree.DataState = XLY.Convert.ToDataState(sx.XLY_DataType);
            sxmessagesTree.Items = getMessageInfo(data, uinfo, sxinfo);
            sixinTree.TreeNodes.push(sxmessagesTree);
        }
    }
    //把各个分支书节点装载入当前帐号树结构中
    accinfo.TreeNodes.push(guanzhuTree);
    accinfo.TreeNodes.push(atwoTree);
    accinfo.TreeNodes.push(weibosourcesTree);
    accinfo.TreeNodes.push(sixinTree);
}

function getAccountInfo(path) {
    var files = eval('(' + XLY.File.FindFiles(path) + ')');
    var info = new Array();
    for (var findex in files) {
        var filename = XLY.File.GetFileName(files[findex]);
        var t_file = search(filename);
        if (t_file != null) {
            var accountid = cut(t_file);
            info.push(accountid);
        }
    }
    return info;
}
//****************************************处理APP数据****************************************
var result = new Array();
//源文件
var source = $source;
var dataRoot = source[0] + "\\com.sina.weibo\\Documents";
//var dataRoot="C:\\XLYSFTasks\\任务-2016-04-21-12-09-14\\source\\IosData\\2016-04-21-12-09-46\\8c5fdfb12d1dc920fa571712932cf5e5727dfca7\\com.sina.weibo\\Documents";

//定义特征库文件
var charactor = "chalib\\IOS_SinaWeibo_V4.0.1\\db_40101_dymatic.dat.charactor";
var accid = getAccountInfo(dataRoot);
for (var index in accid) {
    var accdata = dataRoot + "\\db_40101_" + accid[index] + ".dat";
    var dataPath = XLY.Sqlite.DataRecovery(accdata, charactor, "profileusers,contacts,pm_conversations,pm_messages,weibos,pm_attachments,contact_groups,contact_x_group");
    //账户
    var usersql = "select *,cast(lastUpdateUserInfoTime as text)as lastTime from profileusers where userID='" + accid[index] + "'";
    var user = ExecSql(dataPath, usersql);
    var accinfo = new TreeNode();
    for (var u in user) {
        var uinfo = user[u];
        accinfo.Text = uinfo.screenName + "(" + uinfo.userID + ")";
        accinfo.Type = "Account";
        var accountInfo =new Account(uinfo);
        accinfo.Items.push(accountInfo);
        BuildChildNodesForAccount(accinfo, dataPath,uinfo) 
        result.push(accinfo);
    }
}
var res = JSON.stringify(result);
res;
