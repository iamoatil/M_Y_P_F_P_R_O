﻿/*[config]
<plugin name="搜狗浏览器,6" group="Web痕迹,3" devicetype="ios" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/SogouBrowser.png" app="com.sogou.SogouExplorerMobile" version="5.6.0" description="搜狗浏览器" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.sogou.SogouExplorerMobile</value>
</source>
<data type="News"  contract="DataState" datefilter = "LastPlayTime">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width = "150"></item>
</data>
<data type="UserInfo" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="ID" code="ID" type="string" width="200" format=""></item>
    <item name="昵称" code="UserNickName" type="string" width="200" format = "" ></item>
    <item name="头像地址" code="HeadPath" type="url" width="100" format="" ></item>
</data>
<data type="History" contract="DataState" datefilter="Url">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="标题" code="Title" type="string" width="120" format = ""></item>
    <item name="历史浏览地址" code="Url" type="url" width="200" format = ""></item>
    <item name="添加时间" code="StartTime" order="asc" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="访问时间" code="VisitTime" type="string" width="120" format = ""></item>
    <item name="能否删除" code="IsDelete" type="string" width="120" format = ""></item>
</data>
<data type="Bookmark" contract="DataState" datefilter="Created">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="书签id" code="UUID" type="string" width="100" format="" ></item>
    <item name="主题" code="Title" type="string" width="300" format = ""></item>
    <item name="网址" code="Url" type="url" width="500" format = ""></item>
</data>
<data type="Download" contract="DataState" datefilter="Title">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="文件名" code="fileName" type="string" width="100" format = ""></item>
    <item name="下载链接" code="Url" type="url" width="400" format=""></item>
    <item name="存储路径" code="SavePath" type="string" width="200" format = ""></item>
    <item name="开始时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
    <item name="总大小(byte)" code="TotalBytes" type="string" width="100" format=""></item>
    <item name="实际下载大小(byte)" code="ActualBytes" type="string" width="100" format=""></item>
    <item name="状态" code="fileStatus" type="string" width="200" format = ""></item>
</data>
<data type="SearchWords" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="搜索关键字" code="KeyWord" type="string" width="200" format = ""></item>
    <item name="搜索时间" code="StartTime" order="asc" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Folder" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="200" format = ""></item>
    <item name="序号" code="CID" type="string" width="200" format = ""></item>
    <item name="创建时间" code="CreateTime"  type="string" width="150" format = ""></item>
</data>
<data type="Cache" contract="DataState" datefilter="Time">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="网站" code="Url" type="string" width="200" format = ""></item>
    <item name="类型" code="CacheType" type="string" width="200" format = ""></item>
    <item name="键值" code="Key"  type="string" width="150" format = ""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义Cache数据结构
function Cache(){
    this.DataState = "Normal";
    this.Url = "";
    this.CacheType = "";
    this.Key = "";
}
function Folder(){
    this.DataState = "Normal";
    this.Name = "";
    this.CID = "";
    this.CreateTime = "";
}
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserNickName = "";
    this.ID = "";
    this.HeadPath = "";
}
//定义History数据结构
function History(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.StartTime = null;
    this.VisitTime = "";
    this.IsDelete = "";
}
//定义Bookmark数据结构
function Bookmark(){
    this.DataState = "Normal";
    this.UUID = "";
    this.Title = "";
    this.Url = "";
}
//定义Download数据结构
function Download(){
    this.DataState = "Normal";
    this.Url = "";
    this.SavePath = "";
    this.StartTime = null;
    this.TotalBytes = "";
    this.ActualBytes = "";
    this.fileName = "";
    this.fileStatus = "";
}
//定义SearchWords数据结构
function SearchWords(){
    this.DataState = "Normal";
    this.KeyWord = "";
    this.StartTime = null;
}
//定义SearchSt数据结构
function SearchSt(){
    this.DataState = "Normal";
    this.Title = "";
    this.Url = "";
    this.Host = "";
    this.STime = null;
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath = source[0]+"\\com.sogou.SogouExplorerMobile\\Library\\Preferences\\com.sogou.SogouExplorerMobile.plist";
var infoPath1 = source[0]+"\\com.sogou.SogouExplorerMobile\\Library\\SeMob.sqlite";
//测试数据
//var userPath = "C:\\XLYSFTasks\\任务-2017-04-11-17-33-42\\source\\IosData\\2017-04-11-17-34-45\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sogou.SogouExplorerMobile\\Library\\Preferences\\com.sogou.SogouExplorerMobile.plist";
//var infoPath1 = "C:\\XLYSFTasks\\任务-2017-04-11-17-33-42\\source\\IosData\\2017-04-11-17-34-45\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.sogou.SogouExplorerMobile\\Library\\SeMob.sqlite";
//var cookPath = "C:\\XLYSFTasks\\任务-2017-03-24-13-56-08\\source\\IosData\\2017-03-24-13-57-08\\aeb86051f46399722e23cfcfef43feba2be70d61\\com.RuiChuang.RCWebBrowser\\Library\\Cookies\\Cookies.binarycookies";
//定义特征库文件
var charactor = "\\chalib\\iOS_SougouBrowser_V5.6.0\\SeMob.sqlite.charactor";

//恢复数据库中删除的数据
var infoPath = XLY.Sqlite.DataRecovery(infoPath1,charactor,"ZSEMOBSEARCHHISTORY,ZSEMOBFAVORITEOBJECT,ZWEBHISTORYOBJECT,ZFREQVISIT");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var news = new TreeNode();
    news.Text = "搜狗浏览器";
    news.Type = "News";
    getNews(news);
    result.push(news);
}
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var data = eval('('+ XLY.PList.ReadToJsonString(userPath) +')');
        if(data!=""&&data!=null){
            var obj = new UserInfo();
            for(var i in data){
                if(data[i].DEFAULTS_NICK_NAME!=""&&data[i].DEFAULTS_NICK_NAME!=null){
                    obj.UserNickName = data[i].DEFAULTS_NICK_NAME;
                }
                if(data[i].DEFAULTS_UDID!=""&&data[i].DEFAULTS_UDID!=null){
                    obj.ID = data[i].DEFAULTS_UDID;
                }
                if(data[i].DEFAULTS_USER_HEAD_LARGE_IMAGE!=""&&data[i].DEFAULTS_USER_HEAD_LARGE_IMAGE!=null){
                    obj.HeadPath = data[i].DEFAULTS_USER_HEAD_LARGE_IMAGE;
                }
            }
            var objr = new News();
            var node = new TreeNode();
            if(obj!=""&&obj!=null){
                objr.List = obj.UserNickName;
                
                root.Items.push(objr);
                node.Text = objr.List;
                node.Type = "UserInfo";
                node.Items.push(obj);
            }
            else
            {
                objr.List = "默认账号";
                root.Items.push(objr);
                node.Text = objr.List;
                node.Type = "UserInfo";
                node.Items.push(obj);
            }
            root.TreeNodes.push(node);
            getChildNode(node);
        }
    }
}
function getChildNode(root){
    if(XLY.File.IsValid(infoPath)){
        var dataSC = eval('('+ XLY.Sqlite.Find(infoPath,"select * from ZSEMOBSEARCHHISTORY") +')');
        if(dataSC!=""&&dataSC!=null){
            var node = new TreeNode();
            node.Text = "搜索记录";
            node.Type = "SearchWords";
            for(var i in dataSC){
                var obj = new SearchWords();
                obj.DataState = XLY.Convert.ToDataState(dataSC[i].XLY_DataType);
                obj.KeyWord = dataSC[i].ZKEYWORD;
                obj.StartTime = XLY.Convert.LinuxToDateTime(dataSC[i].ZDATE);
                node.Items.push(obj);
            }
            root.TreeNodes.push(node);
        }
        
        var dataBK = eval('('+ XLY.Sqlite.Find(infoPath,"select * from ZSEMOBFAVORITEOBJECT where ZISBASEDB=='1'") +')');
        if(dataBK!=""&&dataBK!=null){
            var node = new TreeNode();
            node.Text = "书签";
            node.Type = "Bookmark";
            for(var j in dataBK){
                if(dataBK[j].ZFOLDER=="1"&&dataBK[j].ZPARENT==null){
                    var  nodeChild = new TreeNode();
                    nodeChild.Text = dataBK[j].ZTITLE;
                    nodeChild.Type = "Bookmark";
                    nodeChild.DataState = XLY.Convert.ToDataState(dataBK[j].XLY_DataType);
                    getBookMark(nodeChild,dataBK[j],infoPath);
                    node.TreeNodes.push(nodeChild);
                }
                else if(dataBK[j].ZFOLDER=="0"&&dataBK[j].ZPARENT==null)
                {
                    var obj = new Bookmark();
                    obj.DataState = XLY.Convert.ToDataState(dataBK[j].XLY_DataType);
                    obj.UUID = dataBK[j].ZSERVER_ID;
                    obj.Title = dataBK[j].ZTITLE;
                    obj.Url = dataBK[j].ZURL;
                    node.Items.push(obj);
                }
            }
            
            root.TreeNodes.push(node);
        }
        var dataH = eval('('+ XLY.Sqlite.Find(infoPath,"select cast(ZHISTORYADDDATE as int) as addtime,ZHISTORYTITLE,ZHISTORYURL,ZVISITDATE,ZCANDELETE,XLY_DataType from ZWEBHISTORYOBJECT") +')');
        if(dataH!=""&&dataH!=null){
            var node = new TreeNode();
            node.Text = "历史记录";
            node.Type = "History";
            for(var i in dataH){
                var obj = new History();
                obj.DataState = XLY.Convert.ToDataState(dataH[i].XLY_DataType);
                obj.Title = dataH[i].ZHISTORYTITLE;
                obj.Url = dataH[i].ZHISTORYURL;
                obj.Lasted = dataH[i].ZHISTORYADDDATE;
                if(dataH[i].ZCANDELETE=="1"){
                    obj.IsDelete = "是";
                }
                else
                {
                    obj.IsDelete = "否";
                }
                obj.StartTime = XLY.Convert.LinuxToDateTime(dataH[i].ZHISTORYADDDATE);
                obj.VisitTime = dataH[i].ZVISITDATE;
                node.Items.push(obj);
            }
            root.TreeNodes.push(node);
        }
    }
}
function getCache(root){
    if(XLY.File.IsValid(cookPath)){
        var hcache = XLY.Blob.GetFileHandle(cookPath);
        var size = XLY.Blob.GetFileSizeFromHandle(hcache);
        var data = XLY.Blob.GetBytesFromHandle(hcache,0,size);
        XLY.Blob.CloseFileHandle(hcache);
        var aa = getCookieInfo(data,size);
        if(aa!=""&&aa!=null){
            for(var i in aa){
                var obj = new Cache();
                obj.Url = aa[i].url;
                obj.CacheType = aa[i].type;
                obj.Key = aa[i].key;
                root.Items.push(obj);
            }
        }
    }
    
}
function getCookieInfo(info,size){
    var i = 0;
    var arr = new Array();
    while(i<size){
        if((XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]))!= -1){
            var aa = {};
            i= 0x28+XLY.Blob.FindBytes(info,i,[0x38,0x00,0x00,0x00]);
            
            if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                var name1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                aa.url = XLY.Blob.ToString(name1);
                i = XLY.Blob.FindBytes(info,i,[0x00]);
                
                if((XLY.Blob.FindBytes(info,i,[0x00,0x2F]))!= -1){
                    var key1 = XLY.Blob.GetBytes(info,i+1,XLY.Blob.FindBytes(info,i,[0x00,0x2F])-i);
                    aa.type = XLY.Blob.ToString(key1);
                    i = XLY.Blob.FindBytes(info,i,[0x00,0x2F])+2;
                    var temp = XLY.Blob.GetBytes(info,i,1);
                    if(temp==0x00){
                        ++i;
                    }
                    if((XLY.Blob.FindBytes(info,i,[0x00]))!= -1){
                        var url1 = XLY.Blob.GetBytes(info,i,XLY.Blob.FindBytes(info,i,[0x00])-i);
                        aa.key = XLY.Blob.ToString(url1);
                        i = XLY.Blob.FindBytes(info,i,[0x00]);
                    }
                }
            }
            arr.push(aa);
            continue;
        }
        i = size;
        continue;
    }
    return arr;
}
function getBookMark(root,info,path){
    if(info!=""&&info!= null){
        if(info.ZPARENT==null){
            var childdata = eval('('+ XLY.Sqlite.Find(path,"select * from ZSEMOBFAVORITEOBJECT where ZPARENT = '"+info.Z_PK+"'") +')');
            if(childdata!=""&&childdata!=null){
                for(var a in childdata){
                    if(childdata[a].ZFOLDER==0){
                        var obj = new Bookmark();
                        //obj.DataState = XLY.Convert.ToDataState(childdata[a].XLY_DataType);
                        obj.UUID = childdata[a].ZSERVER_ID;
                        obj.Title = childdata[a].ZTITLE;
                        obj.Url = childdata[a].ZURL;
                        root.Items.push(obj);
                    }
                    else
                    {
                        var child = new TreeNode();
                        child.Text = childdata[a].ZTITLE;
                        child.Type = "Bookmark";
                        getBookMark(child,childdata[a],path);
                        root.TreeNodes.push(child);
                    }
                }
            }
        }
        else
        {
            var childdata = eval('('+ XLY.Sqlite.Find(path,"select * from ZSEMOBFAVORITEOBJECT where ZPARENT = '"+info.Z_PK+"'") +')');
            if(childdata!=""&&childdata!=null){
                for(var a in childdata){
                    if(childdata[a].ZFOLDER==0){
                        var obj = new Bookmark();
                        //obj.DataState = XLY.Convert.ToDataState(childdata[a].XLY_DataType);
                        obj.UUID = childdata[a].ZSERVER_ID;
                        obj.Title = childdata[a].ZTITLE;
                        obj.Url = childdata[a].ZURL;
                        root.Items.push(obj);
                    }
                    else
                    {
                        var child = new TreeNode();
                        child.Text = childdata[a].ZTITLE;
                        child.Type = "Bookmark"; 
                        getBookMark(child,childdata[a],path);
                        root.TreeNodes.push(child);
                    }
                }
            }
        }
    }
}