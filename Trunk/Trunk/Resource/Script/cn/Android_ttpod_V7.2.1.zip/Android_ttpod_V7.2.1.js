﻿/*[config]
<plugin name="天天动听" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid"  icon="/icons/ttpod.png"  app="com.sds.android.ttpod" description="天天动听"  data="$data,ComplexTreeDataSource" version="7.2.1">
<source>
<value>/data/data/com.sds.android.ttpod/databases/media.db</value>
<value>/data/data/com.sds.android.ttpod/databases/ttpod.db</value>
</source>
<data type="Ttpod" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="列表信息" code="Name" type="string" width="600" format="" ></item>
<item name="表名" code="TableName" type="string" width="100" format="" show="false"></item>
</data>
<data type="Song" contract="DataState" datefilter="LastPlayTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="歌名" code="Title" type="string" width="200" format=""></item>
<item name="歌手" code="Singer" type="string" width="120" format=""></item>
<item name="专辑" code="Album" type="string" width="120" format=""></item>
<item name="添加时间" code="AddedTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="最近播放时间" code="LastPlayTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="ID" code="Id" type="string" width="300" format="" show="false"></item>
<item name="本地存放路径" code="LocalDataSource" type="string" width="600" format=""></item>
</data>
<data type="Download" contract="DataState" datefilter="AddTime">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="歌名" code="Title" type="string" width="140" format=""></item>
<item name="添加时间" code="AddTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="保存路径" code="SavePath" type="string" width="500" format=""></item>
<item name="来源网址" code="SourceUrl" type="string" width="600" format=""></item>

</data>
</plugin>
[config]*/
function Ttpod(){
    this.Name="";
    this.DataState="Normal";
    this.TableName="";
}

//定义歌曲的数据结构
function Song() {
    this.Title ="";
    this.Singer =""
    this.Album ="";
    this.AddedTime =null;
    this.LastPlayTime =null;
    this.Id ="";
    this.LocalDataSource ="";
    this.DataState="Normal";
}
function Download() {
    this.Title ="";
    this.AddTime =null;
    this.SavePath ="";
    this.SourceUrl ="";
    this.DataState="Normal";

}

//定义树结构
function TreeNode() {
    this.Text = ""; 
    this.TreeNodes = new Array(); 
    this.Items = new Array(); 
    this.Type = ""; 
    this.DataState="Normal";
}

//获取子节点信息
function getTtpod(data){
    var list=new Array();
    for(var index in data){
    var obj=new Ttpod();
    switch (data[index].name){
        case "all_local":
            obj.Name="本地文件";
            obj.TableName=data[index].map_table_name; 
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        case "fav_local":
            obj.Name="我的收藏";
            obj.TableName=data[index].map_table_name;
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        case "recently_add"||"recently_add2":
            obj.Name="最近添加";
            obj.TableName=data[index].map_table_name;
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        case "recently_play"||"recently_play2":
            obj.Name="最近播放";
            obj.TableName=data[index].map_table_name;
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        case "downloaded_song":
            obj.Name="下载列表";
            obj.TableName=data[index].map_table_name;
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        case "fav_online":
            obj.Name=data[index].map_table_name.substring(data[index].map_table_name.indexOf("fav"));
            obj.TableName=data[index].map_table_name;
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        case "effect_local":
            break
        case "effect_online":
            break
        default:
            obj.Name=data[index].name;
            obj.TableName=data[index].map_table_name;
            obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
            break
        }
        list.push(obj);
    }
    return list;
}

//获取子节点内容
function getChileNodeInfo(path,table){
var flag=eval('('+ XLY.Sqlite.Find( path,"select tbl_name from sqlite_master where tbl_name in ('"+table+"')" )+')');
if(flag.length>0){
        var songId=eval('('+ XLY.Sqlite.FindByName(path ,flag[0].tbl_name ) +')');
        var info=new Array();
                for(var index in songId){
                        if((/^[0-9a-zA-Z]+$/gi).test(songId[index].xly_id)){
                            var data=eval('('+ XLY.Sqlite.Find( path,"select * from media_local where _id='"+songId[index].xly_id+"'" ) +')');
                                if(data.length>0){
                                    var obj=new Song();
                                    obj.Title =data[0].title;
                                    obj.Singer =data[0].artist;
                                    obj.Album =data[0].album;
                                    obj.AddedTime =XLY.Convert.LinuxToDateTime(data[0].added_time);
                                    obj.LastPlayTime =XLY.Convert.LinuxToDateTime(data[0].last_play_time);
                                    obj.Id =data[0].xly_id;
                                    obj.LocalDataSource =data[0].local_data_source;
                                    obj.DataState=XLY.Convert.ToDataState( songId[index].XLY_DataType);
                                    info.push(obj);
                                }else{
                                    var obj=new Song();
                                    obj.Title=songId[index].xly_id
                                    obj.DataState=XLY.Convert.ToDataState( songId[index].XLY_DataType);
                                    info.push(obj);
                                }
                        }else  {
                                    if((songId[index].xly_id).length>0){
                                    var obj=new Song();
                                    obj.Title=songId[index].xly_id
                                    obj.DataState=XLY.Convert.ToDataState( songId[index].XLY_DataType);
                                    info.push(obj);
                                }
                        }
                    }
        }
    return info;
}

//获取下载信息
function getDownload(data){
    var list=new Array();
for(var index in data){
    if(data.length>0){
        
    var obj=new Song();
    obj.Title =data[index].FileName;
    obj.AddTime =XLY.Convert.LinuxToDateTime(data[index].addtime);
    obj.SavePath =data[index].SavePath;
    obj.SourceUrl =data[index].SourceUrl;
    obj.DataState=XLY.Convert.ToDataState( data[index].XLY_DataType );
    list.push(obj);
        }
    }
    return list;
}

//定义列表信息获取方法
function getTableNames(data,path){
    
           var tablename="";
           for(var index in data){
                    if(data[index].TableName.length==0)continue; 
                    tablename+="'"+data[index].TableName+"',";
           }
           tablename=tablename.substring(0,tablename.length-1);

          var tableinfo=eval('('+ XLY.Sqlite.Find( path,"select tbl_name from sqlite_master where tbl_name in ("+tablename+")" ) +')');     
          var result="";
          for(var index in tableinfo){
       
                       if(data[index] .TableName.length==0)continue;
                       result+=data[index].TableName+",";
          }
          return result.substring(0,result.length-1);
}

var result = new Array();
var source = $source;
var db1 = source[0];
var db2 = source[1];
//var db1 = "D:\\temp\\data\\data\\com.sds.android.ttpod\\databases\\media.db";
//var db2 = "D:\\temp\\data\\data\\com.sds.android.ttpod\\databases\\ttpod.db";

//定义特征库文件
var charactor1="\\chalib\\Android_ttpod_V7.2.1\\media.db.charactor";
var charactor2="\\chalib\\Android_ttpod_V7.2.1\\ttpod.db.charactor";

 //恢复数据库
var recoverydb1=XLY.Sqlite.DataRecovery( db1,charactor1,"group_,media_local");
var recoverydb2=XLY.Sqlite.DataRecovery(db2, charactor2 , "DownloadTaskInfo" );
var dblist = eval('(' + XLY.Sqlite.FindByName(recoverydb1, 'group_') + ')');

        //创建天天动听树节点
        var ttpod=new TreeNode();
        ttpod.Text="天天动听";
        ttpod.Type="Ttpod";
        var ttpodInfo=getTtpod(dblist);
            for(var index in ttpodInfo){
                if(ttpodInfo[index].Name!=""){
                ttpod.Items.push(ttpodInfo[index]);
                }
            }

         //处理动态表名
        var tablenames=getTableNames(ttpodInfo,db1);
        var recoverydb3=XLY.Sqlite.DataRecovery( db1,charactor1,tablenames); 

        for(var index in ttpodInfo){
            var songlist=new TreeNode(); 
            songlist.Text=ttpodInfo[index].Name;;
            songlist.Type="Song";
            songlist.Items=getChileNodeInfo(recoverydb3,ttpodInfo[index].TableName);
            songlist.DataState=ttpodInfo[index].DataState;
                if(songlist.Text.length>0){
                ttpod.TreeNodes.push(songlist);
                }
        }
        result.push(ttpod);
          //创建下载列表树
            var downloadInfo=new TreeNode();
            downloadInfo.Text="本机下载";
            downloadInfo.Type="Download";
            var dblist1 = eval('(' + XLY.Sqlite.Find(recoverydb2, 'select *,cast(AddTime as varchar)as addtime from DownloadTaskInfo ') + ')'); //
            var download=getDownload(dblist1);
            downloadInfo.Items=download;
            result.push(downloadInfo);
        var res = JSON.stringify(result);
        res;
