﻿/*[config]
<plugin name="360安全卫士,10" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\360.png" app="com.qihoo360.mobilesafe" version="7.5.0.1020" description="360安全卫士" data="$data,ComplexTreeDataSource" >
<source>
 <value>/data/data/com.qihoo360.mobilesafe/#F</value>
</source>
<data type="Account" contract="DataState" datefilter = "LastPlayTime">
<item name="昵称" code="Nick" type="string" width = "150"></item>
<item name="登录名" code="Name" type="string" width = "150"></item>
<item name="ID" code="ID" type="string" width = "150"></item>
</data>
<data type="Blacklist" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="姓名" code="Name" type="string" width = "150"></item>
<item name="号码" code="Number" type="string" width = "200"></item>
<item name="类型" code="Type" type="string" width = "200"></item>
</data>
<data type="Call" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="号码" code="Number" type="string" width = "150"></item>
<item name="SIM卡号" code="ID" type="string" width = "150"></item>
<item name="姓名" code="Name" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
<item name="持续时间" code="Duration" type="string" width = "200"></item>
</data>
<data type="Msg" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="号码" code="Number" type="string" width = "150"></item>
<item name="内容" code="Content" type="string" width = "150"></item>
<item name="时间" code="Time" type="string" width = "200"></item>
<item name="是否已读" code="Read" type="string" width = "200"></item>
<item name="SIM卡号" code="ID" type="string" width = "150"></item>
</data>
<data type="Clean" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="最近清理垃圾总大小" code="All" type="string" width = "150"></item>
<item name="深度清理APK大小" code="APK" type="string" width = "150"></item>
<item name="深度清理文件大小" code="File" type="string" width = "200"></item>
<item name="深度清理图片大小" code="Picture" type="string" width = "200"></item>
<item name="深度清理垃圾的大小" code="Trash" type="string" width = "200"></item>
</data>
<data type="CleanChat" contract = "DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" width="60"></item>
<item name="QQ清理垃圾大小" code="QQ" type="string" width = "150"></item>
<item name="QQ清理时间" code="QTime" type="string" width = "150"></item>
<item name="微信清理垃圾大小" code="Wechat" type="string" width = "200"></item>
<item name="微信清理时间" code="Wtime" type="string" width = "200"></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Account() {
    this.Nick = "";
    this.Name = "";
    this.ID = "";
}
function Blacklist() {
    this.Name = "";
    this.Number = "";
    this.Type = "";
    this.DataState="Normal";
}
function Call() {
    this.Number = "";
    this.ID = "";
    this.Time = "";
    this.Name = "";
    this.Duration = "";
    this.DataState="Normal";
}
function Msg() {
    this.Number = "";
    this.Content = "";
    this.Time = "";
    this.Name = "";
    this.Read = "";
    this.ID = "";
    this.DataState="Normal";
}
function Clean() {
    this.All = "";
    this.APK = "";
    this.File = "";
    this.Picture = "";
    this.Trash = "";
    this.DataState="Normal";
}
function CleanChat() {
    this.QQ = "";
    this.QTime = "";
    this.Wechat = "";
    this.Wtime = "";
    this.DataState="Normal";
}
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}
function bindTree(){
    var news = new TreeNode();
    news.Text = "360安全卫士";
    news.Type = "Account";
    accountinfo = getAccount(db);
    news.Items = accountinfo;
    news.DataState = "Normal";
    
    for(var i in accountinfo){
        var account = new TreeNode();
        account.Text = accountinfo[i].Nick;
        account.Type = "Account";
        account.Items = accountinfo; 
        news.TreeNodes.push(account);
        
        var blacklist = new TreeNode() ;
        blacklist.Text = "黑名单";
        blacklist.Type = "Blacklist"; 
        var blackinfo = getBlacklist(db1);
        blacklist.Items = blackinfo;
        account.TreeNodes.push(blacklist);
        
        var call = new TreeNode();
        call.Text = "拦截通话记录";
        call.Type = "Call"; 
        call.Items = getCall(db1);
        account.TreeNodes.push(call);
        
        var msg = new TreeNode();
        msg.Text = "拦截短信";
        msg.Type = "Msg"; 
        msg.Items = getMsg(db1);
        account.TreeNodes.push(msg);
        
        var clean = new TreeNode();
        clean.Text = "最近一次垃圾清理";
        clean.Type = "Clean"; 
        clean.Items = getClean(db2);
        account.TreeNodes.push(clean);
        
        var cleanchat = new TreeNode();
        cleanchat.Text = "QQ微信垃圾清理";
        cleanchat.Type = "CleanChat"; 
        cleanchat.Items = getCleanChat(db3);
        account.TreeNodes.push(cleanchat);
    }
     result.push(news);
} 

 function getAccount (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');
     var obj = new Account();
     var info = data.map.string;
     for(var i in info){
          if(info[i]["@name"] == "LOGON_USER_NICKNAME"){
              obj.Nick = info[i]["#text"];          
          }
          if(info[i]["@name"] == "LOGON_USER_NAME"){
              obj.Name = info[i]["#text"];          
          }
          if(info[i]["@name"] == "LOGON_USER_QID"){
              obj.ID = info[i]["#text"];          
          }
     }
    list.push(obj);
    return list;
 }
function getBlacklist(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from blacklist" ) +')');
    for(var i in data){
        var obj = new Blacklist();
        obj.Name = data[i].contact_name;
        obj.Number = data[i].phone_number;
        if(data[i].blocked_type=="1"){
           obj.Type = "系统自带";
        }
        else{
            obj.Type = "个人设置";
        }
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getCall(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from call_stat c left join blacklist b on c.origin_number = b.phone_number" ) +')');
    for(var i in data){
        var obj = new Call();
        obj.Number = data[i].real_number;
        obj.Name = data[i].contact_name;
        if(data[i].sim_id==1){
            obj.ID = "卡1";
        }
        else if(data[i].sim_id==2){
            obj.ID = "卡2";
        }
        else
        {
            obj.ID = "未知";
        }
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].timestamp);
        obj.Duration = data[i].ringing_duration+" 毫秒";
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
function getMsg(path){
    var list = new Array();

    var data = eval('('+ XLY.Sqlite.Find(path,"select * from msg_history" ) +')');
    for(var i in data){
        var obj = new Msg();
        obj.Number = data[i].address;
        obj.Content = data[i].body;
        obj.Time = XLY.Convert.LinuxToDateTime(data[i].date);
        if(data[i].read==1){
            obj.Read = "已读";
        }
        else
        {
            obj.Read = "未读";
        }
        if(data[i].sim_id==1){
            obj.ID = "卡1";
        }
        else if(data[i].sim_id==2){
            obj.ID = "卡2";
        }
        else
        {
            obj.ID = "未知";
        }
        obj.DataState = XLY.Convert.ToDataState( data[i].XLY_DataType);
        list.push(obj);
    }
   
    return list;
}
 function getClean (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');
     var obj = new Clean();
     var info = data.map.string;
     for(var i in info){
          if(info[i]["@name"] == "clean_trash_size"){
              obj.All = info[i]["#text"];          
          }
          if(info[i]["@name"] == "deep_clean_finish_apk"){
              obj.APK = info[i]["#text"];          
          }
          if(info[i]["@name"] == "deep_clean_finish_file_size"){
              obj.File = info[i]["#text"];          
          }
          if(info[i]["@name"] == "deep_clean_finish_picture"){
              obj.Picture = info[i]["#text"];          
          }
          if(info[i]["@name"] == "deep_clean_trash_size"){
              obj.Trash = info[i]["#text"];          
          }
     }
    list.push(obj);
    return list;
 }
 function getCleanChat (path){
     var list = new Array;
     var data = eval('('+ XLY.File.ReadXML(path) +')');
     var obj = new CleanChat();
     var info = data.map.string;
     var info1 = data.map.long;
     for(var i in info){
          if(info[i]["@name"] == "sn_qq_trash_size_apull"){
              obj.QQ = info[i]["#text"];          
          }
        
          if(info[i]["@name"] == "sn_weixin_trash_size_apull"){
              obj.Wechat = info[i]["#text"];          
          }
     }
      for(var i in info1){
          if(info1[i]["@name"] == "sn_timestamp_last_check_qq"){
              obj.QTime = XLY.Convert.LinuxToDateTime(info1[i]["@value"]);          
           }
           if(info1[i]["@name"] == "sn_timestamp_last_check_weixin"){
               obj.Wtime = XLY.Convert.LinuxToDateTime(info1[i]["@value"]);          
           }
      }
    list.push(obj);
    return list;
 }
 //********************************************************
var source = $source;
var db = source[0]+"\\shared_prefs\\com.qihoo360.mobilesafe_preferences.xml";
var db4 = source[0]+"\\databases\\mobilesafeguard.db";
var db2 = source[0]+"\\shared_prefs\\apull_clean_scan_result.xml";
var db3 = source[0]+"\\shared_prefs\\clean.xml";

var charactor = "\\chalib\\Android_360Mobilesafe_V7.5.0.1020\\mobilesafeguard.db.charactor";

var db1 = XLY.Sqlite.DataRecovery(db4,charactor,"blacklist,call_stat,msg_history");

var result = new Array();
bindTree();
var res = JSON.stringify(result);
res;
