﻿
//descritpion:Sqlite提取模板

/*[config]
<plugin name="航旅纵横" group="生活旅游,13" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/Umetrip.png" app="com.travelsky.umetrip" version="4.2.3" description="航旅纵横" data="$data,ComplexTreeDataSource" >
<source>
    <value>com.travelsky.umetrip</value>
</source>
<data type="News" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="List" type="string" width="200" format=""></item>
</data>
<data type="UserInfo" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState"></item>
    <item name="用户Id" code="UserId" type="string" width="200" format=""></item>
    <item name="登录名" code="LogName" type="string" width="200" format=""></item>
    <item name="用户姓名" code="UserName" type="string" width="200" format = ""></item>
    <item name="用户昵称" code="NickName" type="string" width="200" format = ""></item>
    <item name="手机号码" code="PhoneNumber" type="string" width="200" format=""></item>
    <item name="证件号码" code="CertNumber" type="string" width="200" format = ""></item>
    <item name="最近登录时间" code="LogTime" type="datetime" width="200" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Journey" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format = "EnumDataState"></item>
    <item name="机票状态" code="TicketState" type="string" width="200" format = ""></item>
    <item name="航班编号" code="FlightCode" type="string" width="200" format=""></item>
    <item name="航线" code="AirLine" type="string" width="200" format=""></item> 
    <item name="出发地" code="Origin" type="string" width="200" format = ""></item>
    <item name="出发地航站楼" code="Stn" type="string" width="200" format = ""></item>
    <item name="目的地" code="Destination" type="string" width="200" format = ""></item>
    <item name="目的地航站楼" code="Den" type="string" width="200" format = ""></item>
    <item name="机票编码" code="TktNumber" type="string" width="200" format = ""></item>
    <item name="出发时间" code="STime" type="string" width="200" format = ""></item>
    <item name="到达时间" code="ETime" type="string" width="200" format = ""></item>
    <item name="航程" code="Voyage" type="string" format = ""></item>
</data>
<data type="PhoneContact" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="姓名" code="Name" type="string" width="200" format = ""></item>
    <item name="电话" code="PhoneNumber" type="string" width="200" format=""></item>
</data>
<data type="SearchByPleace" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="出发城市" code="Scity" type="string" width="200" format = ""></item>
    <item name="出发机场" code="Sair" type="string" width="200" format = ""></item>
    <item name="目的城市" code="Ecity" type="string" width="200" format = ""></item>
    <item name="目的机场" code="Eair" type="string" width="200" format=""></item>
</data>
<data type="SearchByCode" contract="DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="搜索航班号" code="FlightCode" type="string" width="200" format = ""></item>
</data>
</plugin>
[config]*/

//定义并初始化News数据结构
function News(){
    this.DataState = "Normal";
    this.List = "";
}
//定义并初始化UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.LogName = "";
    this.UserName = "";
    this.NickName = "";
    this.PhoneNumber = "";
    this.CertNumber = "";
    this.LogTime = "";
}
//定义并初始化Journey数据结构
function Journey(){
    this.DataState = "Normal";
    this.TicketState = "";
    this.FlightCode = "";
    this.AirLine = "";
    this.Origin = "";
    this.Stn = "";
    this.Destination = "";
    this.Den = "";
    this.TktNumber = "";
    this.STime = "";
    this.ETime = "";
    this.Voyage = "";
}
//定义并初始化PhoneContact数据结构
function PhoneContact(){
    this.DataState = "Normal";
    this.Name = "";
    this.PhoneNumber = "";
}
//定义并初始化SearchByPleace数据结构
function SearchByPleace(){
    this.DataState = "Normal";
    this.Scity = "";
    this.Sair = "";
    this.Ecity = "";
    this.Eair = "";
}
//定义并初始化SearchByCode数据结构
function SearchByCode(){
    this.DataState = "Normal";
    this.FlightCode = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}


var result = new Array();
//源文件
var source = $source;
var Path = source[0] + "\\com.travelsky.umetrip\\Documents";
var charactor1 = "\\chalib\\com.travelsky.umetrip\\CacheDB.sqlite.charactor";
var charactor2 = "\\chalib\\com.travelsky.umetrip\\MyJourneyDB.sqlite.charactor";
//var  Path = "E:\\xlyspf\\任务-2017-04-06-11-15-44\\source\\IosData\\2017-04-06-11-16-55\\5a1be6e17a241458edb38355865ba02594765a6a\\com.travelsky.umetrip\\Documents";
var  PathSon = ["CacheDB.sqlite","MyJourneyDB.sqlite","contact.txt","searchFlightByPlace.txt","searchFlightByCode.txt"];
BuildNode();
function ExecSql(Path,SqlString) {
    return eval('(' + XLY.Sqlite.Find(Path,SqlString) + ')');
}
//根节点结构函数
function BuildNode(){
    var RootNode = new TreeNode();
    RootNode.Text = "航旅纵横";
    RootNode.Type = "News";
    RootNode.Items = GetRootInfo(RootNode);
    result.push(RootNode);
}
//根节点内容函数
function GetRootInfo(Node){
    var temp1 = new Array();
    var pathneed1 = Path + "\\" + PathSon[0];
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"UME_USERINFO");
    var temp2 = ExecSql(pathneed,"select * from UME_USERINFO");
    var temp3 = new News();
    var UserNode = new TreeNode();
    temp3.List = temp2[0].Uid + "_" + temp2[0].UserName;
    temp1.push(temp3);
    UserNode.Text = temp2[0].Uid + "_" + temp2[0].UserName;
    UserNode.Type = "News";
    UserNode.Items = GetUserAll(UserNode);
    Node.TreeNodes.push(UserNode);
    return temp1;
}
//获取当前用户的所有信息
function GetUserAll(Node){
    var temp = ["用户信息","行程","手机通讯录","通过城市名查询的航班","通过航班号查询的航班"];
    var temp1 = new Array();
    for(var i in temp){
        var InfoList = new News();
        InfoList.List = temp[i];
        temp1.push(InfoList);
    }
    //用户个人信息节点
    var UserInfoNode = new TreeNode();
    UserInfoNode.Text = temp[0];
    UserInfoNode.Type = "UserInfo";
    UserInfoNode.Items = GetUserInfo(Node,UserInfoNode);
    //用户所有行程节点
    var JourneyNode = new TreeNode();
    JourneyNode.Text = temp[1];
    JourneyNode.Type = "Journey";
    JourneyNode.Items = GetJourney(Node,JourneyNode);
    //用户通讯录节点
    var PhoneContactNode = new TreeNode();
    PhoneContactNode.Text = temp[2];
    PhoneContactNode.Type = "PhoneContact";
    PhoneContactNode.Items = GetPhoneContact(Node,PhoneContactNode);
    //城市名查询节点
    var SearchByPleaceNode = new TreeNode();
    SearchByPleaceNode.Text = temp[3];
    SearchByPleaceNode.Type = "SearchByPleace";
    SearchByPleaceNode.Items = GetSearchByPleace(Node,SearchByPleaceNode);
    //航班号查询节点
    var SearchByCodeNode = new TreeNode();
    SearchByCodeNode.Text = temp[4];
    SearchByCodeNode.Type = "SearchByCode";
    SearchByCodeNode.Items = GetSearchByCode(Node,SearchByCodeNode);
    return temp1;
}
//用户个人信息节点
function GetUserInfo(Node,UserInfoNode){
    var temp1 = new Array();
    var pathneed1 = Path + "\\" + PathSon[0];
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor1,"UME_USERINFO");
    var temp2 = ExecSql(pathneed,"select * from UME_USERINFO");
    var temp4 = eval('('+ XLY.PList.ConvertArchiverPlistBufferToJson(temp2[0].Cont_data) +')');
    var temp3 = new UserInfo();
    if(temp2.length != 0 && temp2 != null){
        temp3.UserId = temp2[0].Uid;
        temp3.LogName = temp2[0].UserName;
        temp3.UserName = temp4.prealname;
        temp3.NickName = temp4.pnickname2;
        temp3.PhoneNumber = temp4.pmob;
        temp3.CertNumber = temp4.pcertid;
        temp3.LogTime = XLY.Convert.LinuxToDateTime(temp2[0].LoginTime.toString());
    }
    temp1.push(temp3);
    Node.TreeNodes.push(UserInfoNode);
    return temp1;
}
//用户所有行程节点
function GetJourney(Node,JourneyNode){
    var temp1 = new Array();
    var pathneed1 = Path + "\\" + PathSon[1];
    var pathneed = XLY.Sqlite.DataRecovery(pathneed1,charactor2,"UME_MYJOURNEY");
    var temp2 = ExecSql(pathneed,"select * from UME_MYJOURNEY");
    if(temp2.length != 0 && temp2 != null){
        for(var i in temp2){
            var temp3 = new Journey();
            temp3.TicketState = temp2[i].tktStatusDesc;
            temp3.FlightCode = temp2[i].flightNo;
            temp3.AirLine = temp2[i].airlineCode;
            temp3.Origin = temp2[i].deptCityName;
            temp3.Stn = temp2[i].deptTerminal;
            temp3.Destination = temp2[i].destCityName;
            temp3.Den = temp2[i].destTerminal;
            temp3.TktNumber = temp2[i].tktNo; 
            temp3.STime = temp2[i].deptDateTz + "_" + temp2[i].deptTimeTz;
            temp3.ETime = temp2[i].destDateTz + "_" +  temp2[i].destTimeTz;
            temp3.Voyage = temp2[i].flyKilo;
            temp1.push(temp3);
        }
    }
    Node.TreeNodes.push(JourneyNode);
    return temp1;
}
//用户通讯录节点
function GetPhoneContact(Node,PhoneContactNode){
    var temp1 = new Array();
    var pathneed = Path + "\\" + PathSon[2];
    if(XLY.File.IsValid(pathneed)){
        var temp2 = eval('('+ XLY.PList.ReadToJsonString(pathneed) +')');
        for(var i in temp2[1].$objects[0].NSMutableDictionary[0].contactList.NSMutableArray){
            var temp3 = new PhoneContact();
            temp3.Name = temp2[1].$objects[0].NSMutableDictionary[0].contactList.NSMutableArray[i].ContactStub[1].name;
            temp3.PhoneNumber = temp2[1].$objects[0].NSMutableDictionary[0].contactList.NSMutableArray[i].ContactStub[0].mobile;
            temp1.push(temp3);
        }
    }
    Node.TreeNodes.push(PhoneContactNode);
    return temp1;
}
//城市名查询节点
function GetSearchByPleace(Node,SearchByPleaceNode){
    var temp1 = new Array();
    var pathneed = Path + "\\" + PathSon[3];
    var temp2 = eval('('+ XLY.PList.MacReadToJsonString(pathneed) +')');
    for(var i in temp2){
        var temp3 = new SearchByPleace();
        temp3.Scity = temp2[i].startCity;
        temp3.Sair = temp2[i].statrtCnbabla;
        temp3.Ecity = temp2[i].endCity;
        temp3.Eair = temp2[i].endCnbabla;
        temp1.push(temp3);
    }
    Node.TreeNodes.push(SearchByPleaceNode);
    return temp1;
}
//航班号查询节点
function GetSearchByCode(Node,SearchByCodeNode){
    var temp1 = new Array();
    var pathneed = Path + "\\" + PathSon[4];
    var temp2 = eval('('+ XLY.PList.MacReadToJsonString(pathneed) +')');
    for(var i in temp2){
        var temp3 = new SearchByPleace();
        temp3.FlightCode = temp2[i].flightNo;
        temp1.push(temp3);
    }
    Node.TreeNodes.push(SearchByCodeNode);
    return temp1;
}
// return
var res = JSON.stringify(result);
res;
