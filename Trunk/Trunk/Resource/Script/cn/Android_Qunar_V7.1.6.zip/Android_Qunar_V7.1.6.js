﻿/*[config]
<plugin name="去哪儿网,1" group="生活旅游,6" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="\icons\Qunar.png" app="com.Qunar" version="7.1.6" description="去哪儿网" data="$data,ComplexTreeDataSource">
<source>
<value>/data/data/com.Qunar/databases/qunar.db</value>
<value>/data/data/com.Qunar/databases/gxdbapp.db</value>
<value>/data/data/com.Qunar/shared_prefs/QunarPreferences.xml</value>
</source>
<data type="Account" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="注册手机号" code="Phone" type="string" width="200"></item>
<item name="用户定位信息" code="Position" type="string" width="300" ></item>
</data>
<data type="History" datefilter="Time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="主题" code="Title" type="string" width="100" format=""></item>
<item name="URL地址" code="URL" type="URL" width="300" format=""></item>
<item name="时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>
<data  type="Note" datefilter="Time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="设置时间" code="Time" type="string" width="100"></item>
<item name="提醒内容" code="Content" type="string" width="300" format=""></item>
</data>

</plugin>
[config]*/

//定义数据结构
function Account() {
	this.Phone = "";
	this.Position = "";
	this.DataState = "Normal";  
}

function History() {
	this.URL = "";
	this.Time = null;
	this.Title = "";
	this.DataState = "Normal";  
}

function Note() {
	this.Time = "";
	this.Content = "";
	this.DataState = "Normal";  
}

//树形结构
function TreeNode() {
	this.Text = ""; //节点名称
	this.TreeNodes = new Array(); //子节点数字
	this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
	this.Type = ""; //节点[Items]的数据类型
}

//获取登录帐号信息
function getAccount(path) {
	if(path=="")
{
	return;
}
else
{
	var arr = new Array();
	var list = new Account();
	try{
		var data = eval('(' + XLY.File.ReadXML(path) + ')');
		var accinfo = data.map.string;
		for (var index in accinfo) {
			if (accinfo[index]['@name'] == "phone") {
				arr.push(accinfo[index]['#text']);
			}
			if (accinfo[index]['@name'] == "GPS_ADDRESS") {
				var addr = eval('(' + accinfo[index]['#text'] + ')');
				arr.push(addr.cityName + addr.street);
			}
		}   
		list.Phone = arr[0];
		list.Position = arr[1];
		return list;
	}
	catch(e){
		return list;
	}
}
}

//获取历史搜索信息
function getHistory(path, sql) {
	var arr = new Array();
	try{
		var flag = XLY.Sqlite.Find(path, sql);
		if (flag.length > 0) {
			var data = eval('(' + flag + ')');
			for (var index in data) {
				var list = new History();
				list.Title = data[index].title;
				list.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
				list.Time = XLY.Convert.LinuxToDateTime(parseInt(data[index].time));
				list.URL = XLY.Convert.UrlDecode(data[index].url);
				arr.push(list);
			}
			return arr;
		}
	}
	catch(e){
		return arr;
	}
}

//获取消息提醒
function getNote(path, sql) {
	var arr = new Array();
	try{
		var flag = XLY.Sqlite.Find(path, sql);
		if (flag.length > 0) {
			var data = eval('(' + flag + ')');
			for (var index in data) {
				if (data[index].content != "") {
					var list = new Note();
					list.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
					list.Time = XLY.Convert.ToDateTime(data[index].time, 'yyyyMMdd');
					var con = eval('(' + data[index].content + ')');
					list.Content = con.title + con.content;
					arr.push(list);
				}
			}
			return arr;
		}
	}
	catch(e){
		return arr;
	}
}

var result = new Array();
//源文件
var source = $source;
var accpath = source[2];
var hispath=source[0];
var notepath=source[1]

//数据恢复库的生成
var charactor1="chalib\\Android_Qunar_V7.1.6\\qunar.db.charactor";
var charactor2="chalib\\Android_Qunar_V7.1.6\\gxdbapp.db.charactor";
hispath=XLY.Sqlite.DataRecovery( hispath,charactor1 ,"history,favorites");
notepath=XLY.Sqlite.DataRecovery( notepath,charactor2 ,"table_message2");

//创建登陆过的帐号信息树
var accountinfo = getAccount(accpath);
var accountTree = new TreeNode();
accountTree.Text = "登录用户信息";
accountTree.Type = "Account";
accountTree.Items.push(accountinfo);

//创建历史搜索树
var hissql = "select url,time,title,XLY_DataType from history";
var historyinfo = getHistory(hispath, hissql);
var historyTree = new TreeNode();
historyTree.Text = "历史搜索";
historyTree.Type = "History";
historyTree.Items = historyinfo;

//创建收藏树
var favsql = "select url,time,title,XLY_DataType from favorites"
var favoriteinfo = getHistory(hispath, favsql);
var favoriteTree = new TreeNode();
favoriteTree.Text = "收藏夹";
favoriteTree.Type = "History";
favoriteTree.Items = favoriteinfo;

//创建消息提醒树
var notesql = "select XLY_DataType,createtime as time,cast(msgextra as text) as content from table_message2 ";
var notedata = getNote(notepath, notesql);
var noteTree = new TreeNode();
noteTree.Text = "低价提醒";
noteTree.Type = "Note";
noteTree.Items = notedata;

//打印数据
result.push(accountTree);
result.push(historyTree);
result.push(favoriteTree);
result.push(noteTree);
var res = JSON.stringify(result);
res;
