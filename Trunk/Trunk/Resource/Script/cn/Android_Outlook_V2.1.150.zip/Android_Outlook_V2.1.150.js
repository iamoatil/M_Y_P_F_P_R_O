﻿/*[config]
<plugin name="Outlook,3" group="主流邮箱,4" devicetype="android" pump="usb,wifi,mirror,bluetooth" icon="/icons/outlook.png" app="com.microsoft.office.outlook" version="2.1.150" description="Outlook" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.microsoft.office.outlook/databases#F</value>
</source>
<data type="News" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="账号ID" code="AccountID" type="string" width="120" format=""></item>
    <item name="邮箱" code="Email" type="string" width="120" format = ""></item>
    <item name="描述" code="DescriptionW" type="string" width="120" format=""></item>
    <item name="显示姓名" code="DisplayName" type="string" width="120" format=""></item>
</data>
<data type="List" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="列表" code="Entry" type="string" width="120" format=""></item>
    <item name="类型" code="EntryType" type="string" width="120" format=""></item>
</data>
<data type="ActivityArrangement" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width="120" format=""></item>
    <item name="标题" code="Title" type="string" width="120" format=""></item>
    <item name="标签名称" code="LabelName" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="开始时间" code="DtStart"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="结束时间" code="DtEnd"  type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
</data>
<data type="Message" contract = "DataState" datefilter = "Content">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="发件人email" code="SenderID" type="string" width="120" format=""></item>
    <item name="发件人" code="Sender" type="string" width="120" format=""></item>
    <item name="收件人email" code="ReceiverID" type="string" width="120" format=""></item>
    <item name="收件人" code="Receiver" type="string" width="120" format=""></item>
    <item name="抄送" code="Copy" type="string" width="120" format=""></item>
    <item name="密送" code="BCC" type="string" width="120" format=""></item>
    <item name="主题" code="Title" type="string" width="120" format=""></item>
    <item name="内容" code="Content" type="string" width="120" format=""></item>
    <item name="发送时间" code="Time" type="datetime" width="150" format = "yyyy-MM-dd HH:mm:ss"></item>
    <item name="附件" code="Add" type="string" width="120" format=""></item>
    <item name="附件路径" code="AddPath" type="string" width="120" format=""></item>
    <item name="已读" code="IsRead" type="string" width="120" format=""></item>
    <item name="已标记" code="IsSign" type="string" width="120" format=""></item>
</data>
<data type="Contact" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="名称" code="Name" type="string" width="120" format=""></item>
    <item name="邮箱地址" code="Email" type="string" width="120" format=""></item>
</data>
<data type="Meet" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="假日名称" code="Name" type="string" width="120" format=""></item>
    <item name="日期" code="DayIndex" type="string" width="120" format=""></item>
    <item name="安排" code="Body" type="string" width="120" format=""></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
function Meet(){
    this.DataState = "Normal";
    this.Name = "";
    this.DayIndex = "";
    this.Body = "";
}
//定义News数据结构
function News(){
    this.DataState = "Normal";
    this.AccountID = "";
    this.Email = "";
    this.DescriptionW = "";
    this.DisplayName = "";
}
//定义Contact数据结构
function Contact(){
    this.DataState = "Normal";
    this.Name = "";
    this.Email = "";
}
//定义List数据结构
function List(){
    this.DataState = "Normal";
    this.Entry = "";
    this.EntryType = "";
}
//定义ActivityArrangement数据结构
function ActivityArrangement(){
    this.DataState = "Normal";
    this.UserId = "";
    this.Title = "";
    this.Content = "";
    this.DtStart = null;
    this.DtEnd = null;
    this.LabelName = "";
}
//定义Message数据结构
function Message(){
    this.DataState = "Normal";
    this.SenderID = "";
    this.Sender = "";
    this.ReceiverID = "";
    this.Receiver = "";
    this.Copy = "";
    this.BCC = "";
    this.Title = "";
    this.Content = "";
    this.Add = "";
    this.AddPath = "";
    this.Time = null;
    this.IsRead = "";
    this.IsSign = "";
}
//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var acompli1 = source[0]+"\\acompli.db";
var acompliAcct1 = source[0]+"\\acompliAcct.db";
//测试数据
//var acompli1 = "D:\\temp1356\\data\\data\\com.microsoft.office.outlook\\databases\\acompli.db";
//var acompliAcct1 = "D:\\temp1356\\data\\data\\com.microsoft.office.outlook\\databases\\acompliAcct.db";

//定义特征库文件
//var acomplicharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Outlook_V2.1.150\\acompli.db.charactor";
//var acompliAcctcharactor = "F:\\21-Build冯火军2号\\21-Build\\chalib\\Android_Outlook_V2.1.150\\acompliAcct.db.charactor";

var acomplicharactor = "\\chalib\\Android_Outlook_V2.1.150\\acompli.db.charactor";
var acompliAcctcharactor = "\\chalib\\Android_Outlook_V2.1.150\\acompliAcct.db.charactor";

//恢复数据库中删除的数据
var acompli = XLY.Sqlite.DataRecovery(acompli1,acomplicharactor,"attachments,contacts_search_content,folders,meetings,messages,messagesInFolders");
var acompliAcct = XLY.Sqlite.DataRecovery(acompliAcct1,acompliAcctcharactor,"mailAccounts");
//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "Outlook";
    root.Type = "List";
    //root.Items = getNews(userpathX,userpathD,root);
    root.Items = getList(root);
    result.push(root);
}

//获取列表
function getList(root){
    if(XLY.File.IsValid(acompliAcct)){
        var arr = new Array();
        var data = eval('('+ XLY.Sqlite.Find(acompliAcct,"select * from mailAccounts") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var obj = new List();
                obj.Entry = data[i].email;
                if(data[i].authType==21){
                    obj.EntryType = "电子邮件账户";
                }
                else
                {
                    obj.EntryType = "存储账户";
                }
                var node = new TreeNode();
                node.Text = data[i].email+"_"+data[i].displayName;
                node.Type = "News";
                getNews(node,data[i]);
                root.TreeNodes.push(node);
                arr.push(obj);
            }
        }
        return arr;
    }
}

//获取用户信息
function getNews(root,info){
    if(info!=""&&info!=null){
        var obj = new News();
        //obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
        obj.AccountID = info.accountID;
        obj.Email = info.email;
        obj.DescriptionW = info.description;
        obj.DisplayName = info.displayName;
        root.Items.push(obj);
        getUserNode(root,obj.AccountID);
    }   
}

//创建用户下的节点，通讯录，收件箱，发件箱，草稿箱，垃圾箱
function getUserNode(root,info){
    if(XLY.File.IsValid(acompli)){
        var data = eval('('+ XLY.Sqlite.Find(acompli,"select * from folders where accountID = '"+info+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var node = new TreeNode();
                if(data[i].name==""||data[i].name==null){
                    node.Text = "未命名";
                }
                else
                {
                    node.Text = data[i].name;
                }
                getNodeInfo(node,data[i]);
                root.TreeNodes.push(node);
            }
        }
    }
}
//获取每个节点的信息
function getNodeInfo(node,info){
    if(node.Text=="联系人"){
        node.Type = "Contact";
        var data = eval('('+ XLY.Sqlite.Find(acompli,"select * from contacts_search_content where accountID = '"+info.accountID+"'") +')');
        if(data!=""&&data!= null){
            for(var i in data){
                var obj = new Contact();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.Name = data[i].contactName;
                obj.Email = data[i].contactEmail;
                node.Items.push(obj);
            }
        }
    }
    else if(node.Text=="中国 节假日"){
        node.Type = "Meet";
        var data = eval('('+ XLY.Sqlite.Find(acompli,"select * from meetings where accountID = '"+info.accountID+"'") +')');
        if(data!=""&&data!= null){
            for(var i in data){
                var obj = new Meet();
                obj.DataState = XLY.Convert.ToDataState(data[i].XLY_DataType);
                obj.Name = data[i].subject;
                obj.DayIndex = data[i].dayIndex;
                obj.Body = data[i].body;
                node.Items.push(obj);
            }
        }
    }
    else
    {      
        node.Type = "Message";
        var data = eval('('+ XLY.Sqlite.Find(acompli,"select messageID from messagesInFolders where folderID='"+info.folderId+"'") +')');
        if(data!=""&&data!=null){
            for(var i in data){
                var temp = eval('('+ XLY.Sqlite.Find(acompli,"select * from messages where _id = '"+data[i].messageID+"'") +')');
                if(temp!=""&&temp!=null){
                    var obj = new Message();
                    obj.DataState = XLY.Convert.ToDataState(temp[0].XLY_DataType);
                    obj.SenderID = temp[0].fromContactEmail;
                    var aa = eval('('+ XLY.Sqlite.Find(acompli,"select c1contactName from contacts_search_content where c2contactEmail = '"+obj.SenderID+"'") +')');
                    obj.Sender = aa[0].c1contactName;
                    obj.ReceiverID = temp[0].firstToContactEmail;
                    obj.Receiver = temp[0].firstToContactName;
                    if(temp[0].hasCC){
                        obj.Copy = "是";
                    }
                    else
                    {
                        obj.Copy = "否";
                    }
                    if(temp[0].hasBCC){
                        obj.BCC = "是";
                    }
                    else
                    {
                        obj.BCC = "否";
                    }
                    obj.Title = temp[0].subject;
                    obj.Content = temp[0].snippetBody;
                    var bb = eval('('+ XLY.Sqlite.Find(acompli,"select * from attachments where messageID='"+data[i].messageID+"'") +')');
                    if(bb!=""&&bb!= null){
                        for(var j in bb){
                            obj.Add = "文件名："+bb[j].filename+"\r"+"文件类型："+bb[j].contentType+"\r"+"文件ID："+bb[j].contentID+"文件大小："+bb[j].size+"\r";
                            obj.AddPath = bb[j].filePath;
                        }
                    }
                    obj.Time = XLY.Convert.LinuxToDateTime(temp[0].sentTimestamp);
                    if(temp[0].isRead){
                        obj.IsRead = "已读";
                    }
                    else
                    {
                        obj.IsRead = "未读";
                    }
                    if(temp[0].isFlagged){
                        obj.IsSign = "已标记";
                    }
                    else
                    {
                        obj.IsSign = "未标记";
                    }
                    node.Items.push(obj);
                }
            }
        }
    }
}