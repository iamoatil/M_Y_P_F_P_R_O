﻿/*[config]
<plugin name="Android邮箱,3" group="主流邮箱,4"  devicetype="android" pump="USB,Mirror,Wifi,Bluetooth,chip,Raid" app="com.android.email" icon = "\icons\Android_Email.jpg" description="提取内置邮箱信息" data="$data,ComplexTreeDataSource">
   <source>
       <value>/data/data/com.android.email/databases/EmailProvider.db</value>
   </source>
   <data type="Account" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="邮箱地址" code="Address" type="string" width="150" format=""></item>
        <item name="邮箱所属人名称" code="Name" type="string" width="150" format = ""></item>
        <item name="昵称" code="NickName" type="string" width="150" format = ""></item>
   </data>

   <data type="Message" detailfield="Content" datefilter="SendTime" contract="DataState">
        <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
        <item name="发件人" code="Sender" type="string" width="300" format=""></item>
        <item name="收件人" code="Receiver" type="string" width="300" format=""></item>
        <item name="发送时间" code="SendTime" type="datetime" width="150" format="yyyy-MM-dd HH:mm:ss"></item>
        <item name="主题" code="Subject" type="string" width="300" format=""></item>
        <item name="邮件内容" code="Content" type="string" width="350" format = ""></item>
        <item name="附件" code="Attach" type="string" width="200" format = ""></item>
        <item name="阅读状态" code="IsRead" type="string" width="60" format=""></item>
   </data>
</plugin>
[config]*/

//定义Account数据结构
function Account() {
    this.Address = "";
    this.Name = "";
    this.NickName = "";
    this.DataState = "Normal";
}

//定义Message数据结构
function Message() {
    this.DataState = "Normal";
    this.Sender = "";
    this.Receiver = "";
    this.SendTime = null;
    this.Subject = "";
    this.Content = "";
    this.Attach = "";
    this.IsRead = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}


var result = new Array();

//源文件
var source = $source;
var db1 = source[0];

//测试数据
//var db1 =  "C:\\Users\\Administrator\\Desktop\\com.android.email\\databases\\EmailProvider.db";
var ch = "\\chalib\\Android_Email\\EmailProvider.db.charactor";
var path = XLY.Sqlite.DataRecovery( db1,ch,"Account,Message");

//主界面函数
function ParesCore(){
    //定义主节点
    var emailNode = new TreeNode();
    emailNode.Text = "内置邮箱";
    emailNode.Type = "Account";
    var acc = GetAccount();
    emailNode.Items = acc;
    for(var i in acc){
        //定义账户节点
        var accNode = new TreeNode();
        accNode.Text = acc[i].NickName;
        accNode.Type = "Message";
        accNode.DataState = acc[i].DataState;
        accNode.Items = GetMessage(acc[i].Address);
        emailNode.TreeNodes.push(accNode);
    }   
    result.push(emailNode);
}

//提取账户信息
function GetAccount(){
    var db = eval('(' + XLY.Sqlite.FindByName(path, "Account") + ')');
    var Items = new Array();
    for(var i in db){
        var acc = new Account();
        acc.Name = db[i].displayName;
        acc.Address = db[i].emailAddress;
        acc.NickName = db[i].senderName;
        acc.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(acc);
    }
    return Items;
}

//提取邮件信息
function GetMessage(email){
    var db = eval('('+ XLY.Sqlite.Find(path,"select * from Message where fromList like '%"+email+"%' or toList like '%"+email+"%'") +')');
    var Items = new Array();
    for(var i in db){
        var msg = new Message();
        msg.Sender = db[i].fromList;
        msg.Receiver = db[i].toList;
        msg.SendTime = XLY.Convert.LinuxToDateTime(db[i].timeStamp);
        msg.Subject = db[i].subject;
        msg.Content = db[i].snippet;
        msg.IsRead = (db[i].flagRead == 1) ? "已阅" : "未读";
        msg.Attach = db[i].attachInfo;
        msg.DataState = XLY.Convert.ToDataState(db[i].XLY_DataType);
        Items.push(msg);
    }
    return Items;
}


ParesCore();
var res = JSON.stringify(result);
res;
