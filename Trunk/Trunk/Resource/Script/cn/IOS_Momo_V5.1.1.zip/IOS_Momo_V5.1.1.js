﻿/*[config]
<plugin name="陌陌,6" group="社交聊天,2" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="\icons\icon_momo.png" app="com.wemomo.momoappdemo1" version="5.1.1" description="陌陌" data="$data,ComplexTreeDataSource" >
<source>
<value>com.wemomo.momoappdemo1</value>
</source>

<data type="Group">
<item name="账号ID" code="Momoid" type="string" width="" format="" order="desc" alignment="center"></item>
<item name="姓名" code="Name" type="string" width="" format=""></item>
<item name="头像" code="Head" type="string" width="" format=""></item>
<item name="星座" code="Constellation" type="string" width="" format=""></item>
</data>

<data type="Friends">
<item name="好友ID" code="Fid" type="string" width="" format=""></item>
<item name="好友姓名" code="Fname" type="string" width="" format=""></item>
<item name="星座" code="Constell" type="string" width="" format=""></item>
<item name="头像" code="Headname" type="" width="" format=""  alignment="center"></item>
<item name="个性签名" code="Sign" type="string" width="" format=""></item>
<item name="年龄" code="Age" type="string" width="" format=""></item>
<item name="职业" code="Job" type="string" width="" format=""></item>
<item name="近期登录时间" code="Logintime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>

<data type="Strangers">
<item name="陌生人ID" code="Sid" type="string" width="" format=""></item>
<item name="陌生人姓名" code="Sname" type="string" width="" format=""></item>
<item name="星座" code="Sconstell" type="string" width="" format=""></item>
<item name="头像" code="Sheadname" type="" width="" format=""  alignment="center"></item>
<item name="个性签名" code="Ssign" type="string" width="" format=""></item>
<item name="年龄" code="Sage" type="string" width="" format=""></item>
<item name="职业" code="Sjob" type="string" width="" format=""></item>
<item name="近期登录时间" code="Slogintime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
</data>

<data detailfield="Content" type="Message">
<item name="消息发送者" code="Fname" type="string" width="" alignment="center" format=""></item>
<item name="消息接收者" code="Tname" type="string" width="" format=""></item>
<item name="聊天内容" code="Content" type="string" width="" format=""></item>
<item name="聊天内容类型" code="Type" type="string" width="" format=""></item>
<item name="日期" code="Htime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="与聊天对象的距离" code="Distance" type="string" width="" format=""></item>
</data>

<data detailfield="Gmcontent" type="Groupmessage">
<item name="消息发送者" code="Gmfname" type="string" width="" alignment="center" format=""></item>
<item name="消息接收者" code="Gmtname" type="string" width="" alignment="center" format=""></item>
<item name="内容" code="Gmcontent" type="string" width="" alignment="center" format=""></item>
<item name="内容类型" code="Gmtype" type="string" width="" alignment="center" format=""></item>
<item name="消息发送时间" code="Gmtime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>

<data detailfield="Gmember" type="Groupinfo">
<item name="群组ID" code="Gid" type="string" width="" alignment="center" format=""></item>
<item name="群组姓名" code="Gname" type="string" width="" alignment="center" format=""></item>
<item name="群组签名" code="Gsign" type="string" width="" alignment="center" format=""></item>
<item name="群组成员" code="Gmember" type="string" width="" alignment="center" format=""></item>
<item name="群组创建时间" code="Gtime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="群组创建者" code="Gower" type="string" width="" alignment="center" format=""></item>
<item name="群组当前人数" code="Gmcount" type="int" width="" alignment="center" format=""></item>
<item name="群组关联的地址" code="Gsitename" type="string" width="" alignment="center" format=""></item>
</data>

<data detailfield="Dscontent" type="Discussmessage">
<item name="消息发送者" code="Dsfname" type="string" width="" alignment="center" format=""></item>
<item name="消息接收者" code="Dstname" type="string" width="" alignment="center" format=""></item>
<item name="内容" code="Dscontent" type="string" width="" alignment="center" format=""></item>
<item name="内容类型" code="Dstype" type="string" width="" alignment="center" format=""></item>
<item name="消息发送时间" code="Dstime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
</data>

<data detailfield="Dsmember" type="Discussinfo">
<item name="讨论组ID" code="Dsid" type="string" width="" alignment="center" format=""></item>
<item name="讨论组名称" code="Dsname" type="string" width="" alignment="center" format=""></item>
<item name="讨论组成员" code="Dsmember" type="string" width="" alignment="center" format=""></item>
<item name="讨论组创建时间" code="Dstime" type="datetime" width="" format="yyyy-MM-dd HH:mm:ss" order="desc" alignment="center"></item>
<item name="讨论组创建者" code="Dsower" type="string" width="" alignment="center" format=""></item>
<item name="讨论组当前人数" code="Dscount" type="int" width="" alignment="center" format=""></item>
</data>
</plugin>
[config]*/

// js content

//定义数据结构
function Discussmessage() {
    this.Dsfname = "";
    this.Dstname = "";
    this.Dscontent = "";
    this.Dstype = "";
    this.Dstime = null;
}


function Discussinfo() {
    this.Dsid = "";
    this.Dsname = "";
    this.Dsmember = "";
    this.Dstime = null;
    this.Dsower = "";
    this.Dscount = "";
}

function Groupmessage() {
    this.Gmfname = "";
    this.Gmtname = "";
    this.Gmcontent = "";
    this.Gmtype = "";
    this.Gmtime = null;
}

function Groupinfo() {
    this.Gid = "";
    this.Gname = "";
    this.Gsign = "";
    this.Gmember = "";
    this.Gtime = null;
    this.Gower = "";
    this.Gmcount = "";
    this.Gsitename = ""
}

function Message() {
    this.Fname = "";
    this.Tname = "";
    this.Htime = null;
    this.Content = "";
    this.Type = "";
    this.Distance = "";
}

function Friends() {
    this.Fid = "";
    this.Fname = "";
    this.Constell = "";
    this.Headname = "";
    this.Sign = "";
    this.Age = "";
    this.Job = "";
    this.Logintime = null;
}

function Strangers() {
    this.Sid = "";
    this.Sname = "";
    this.Sconstell = "";
    this.Sheadname = "";
    this.Ssign = "";
    this.Sage = "";
    this.Sjob = "";
    this.Slogintime = null;
}

function Group() {
    this.Momoid = "";
    this.Name = "";
    this.Head = "";
    this.Constellation = "";
}

//截取字符串中逗号之间的字符子串
function cut(str) {
    var b = str.indexOf(".");
    var c = str.lastIndexOf(".");
    var d = str.slice(b + 1, c);
    if (d) {
        return d;
    }
}

//匹配目录下的目标文件
function search(str) {
    var reg = /u.+[0-9]+.sqlite+$/gi;
    var s = reg.test(str);
    if (s) {
        return str;
    }
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.Tag = "";
}

function GetName(member, momoId) {
    for (var index in member) {
        if (member[index].momoid == momoId)
            return member[index].name;
    }

    return "";
}

function getTableName(path,key){
    var info = eval('(' + XLY.Sqlite.Find(path, "select tbl_name from sqlite_master where type = 'table'") + ')');
    for(var i in info){
        if(new RegExp(""+key+"[0-9]+$","i").test(info[i].tbl_name))
        return info[i].tbl_name;
    }
}

function GetHeadUrl(url)
{
    return url.substring(1,url.length-1).split(",")[0]
}

function GetType(type) {
    switch (type) {
        case "1":
            value = "文本";
            break

        case "2":
            value = "相机图片";
            break

        case "3":
            value = "地理位置信息";
            break

        case "4":
            value = "语音";
            break

        case "6":
            value = "系统消息";
            break


        case "8":
            value = "来自系统的消息";
            break

        case "9":
            value = "图片";
            break

        case "10":
            value = "官方团队消息";
            break

        default:
            value = "陌陌系统消息";
    }
    return value;
}



var result = new Array();
//源文件
var source = $source;
var db = source[0] + "\\com.wemomo.momoappdemo1\\Documents";

//测试数据
//var db = "C:\\Documents";
var dblist = eval('(' + XLY.File.FindFiles(db) + ')');
//define root directory   
for (var i in dblist) {
    var dbf = XLY.File.GetFileName(dblist[i]);
    var tt = search(dbf);
    if (tt != null) {
        var st = cut(tt);
        var mmuser = db + "\\" + tt;
        var usertbl = getTableName(mmuser,"md_user_tmp");
        var grouptbl = getTableName(mmuser,"md_group_");
        //账户
        var len1 = eval('(' + XLY.Sqlite.Find(mmuser, "select * from "+usertbl+" where u_momoid = '" + st + "' ") + ')');
        for (var i in len1) {
            var n1 = new TreeNode();
            n1.Text = len1[i].u_name + "(" + len1[i].u_momoid + ")";
            n1.Type = "Group";
            n1.Tag = st;
            var len2 = eval('(' + XLY.Sqlite.Find(mmuser, "select * from "+usertbl+" where u_momoid='" + n1.Tag + "' ") + ')');
            for (var m in len2) {
                var row = len2[m];
                var group = new Group();
                group.Momoid = XLY.Convert.ToString(row.u_momoid);
                group.Name = XLY.Convert.ToString(row.u_name);
                group.Head = XLY.Convert.ToString(row.u_photos);
                group.Constellation = XLY.Convert.ToString(row.u_constellation);
                n1.Items.push(group);
                //好友
                var n2_1 = new TreeNode();
                n2_1.Text = "好友";
                n2_1.Type = "Friends";
                //提取好友数据
                var len21 = eval('(' + XLY.Sqlite.Find(mmuser, "select cast(u_updatetime AS varchar) as time,* from "+usertbl+" where u_relation=4") + ')');
                for (var x in len21) {
                    var n2_1_1 = new TreeNode();
                    var sow = len21[x];
                    var f = new Friends();
                    f.Fid = XLY.Convert.ToString(sow.f_momoid);
                    f.Fname = XLY.Convert.ToString(sow.u_name);
                    f.Constell = XLY.Convert.ToString(sow.u_constellation);
                    f.Headname = XLY.Convert.ToString(sow.u_photos);
                    f.Sign = XLY.Convert.ToString(sow.u_sign);
                    f.Age = XLY.Convert.ToString(sow.u_age);
                    f.Job = XLY.Convert.ToString(sow.u_job);
                    f.Logintime = XLY.Convert.LinuxToDateTime(parseInt(sow.time));
                    n2_1.Items.push(f);
                    n2_1_1.Text = sow.u_name + "(" + sow.u_momoid + ")";
                    n2_1_1.Type = "Message";
                    n2_1.Tag = sow.u_momoid;                    
                    //提取好友聊天记录
                    var len = eval('(' + XLY.Sqlite.Find(mmuser, "select u_name,cast(s_time AS varchar)as time,mm.* from md_messages_1 as mm left join "+usertbl+" as ft on ft.[u_momoid]=mm.[s_remoteid] where s_remoteid='" + n2_1.Tag + "' ") + ')');                   
                    for (var y in len) {
                        var tow = len[y];
                        var ms = new Message();
                        var sf = XLY.Convert.ToInt(tow.s_type);
                        if (sf == 1) {
                            ms.Fname = XLY.Convert.ToString(row.u_name);
                            ms.Tname = XLY.Convert.ToString(tow.u_name);
                        } else if (sf == 2) {
                            ms.Fname = XLY.Convert.ToString(tow.u_name);
                            ms.Tname = XLY.Convert.ToString(row.u_name);
                        }
                        ms.Htime = XLY.Convert.LinuxToDateTime(parseInt(tow.time));
                        ms.Content = XLY.Convert.ToString(tow.s_text);
                        var mst = XLY.Convert.ToInt(tow.s_contenttype);
                        ms.Type = GetType(mst);
                        ms.Distance = XLY.Convert.ToString(tow.s_distance) + "米";
                        n2_1_1.Items.push(ms);
                    }
                    n2_1.TreeNodes.push(n2_1_1);
                }

                //陌生人
                var n2_4 = new TreeNode();
                n2_4.Text = "陌生人";
                n2_4.Type = "Strangers";
                //提取陌生人数据
                var len24 = eval('(' + XLY.Sqlite.Find(mmuser, "select cast(u_updatetime AS varchar) as time,* from "+usertbl+" where u_relation<>4") + ')');
                for (var x in len24) {
                    var n2_4_1 = new TreeNode();
                    var kow = len24[x];
                    var stranger = new Strangers();
                    stranger.Sid = XLY.Convert.ToString(kow.u_momoid);
                    stranger.Sname = XLY.Convert.ToString(kow.u_name);
                    stranger.Sconstell = XLY.Convert.ToString(kow.u_constellation);
                    stranger.Sheadname = GetHeadUrl(XLY.Convert.ToString(kow.u_photos));
                    stranger.Ssign = XLY.Convert.ToString(kow.u_sign);
                    stranger.Sage = XLY.Convert.ToString(kow.u_age);
                    stranger.Sjob = XLY.Convert.ToString(kow.u_job);
                    stranger.Slogintime = XLY.Convert.LinuxToDateTime(parseInt(kow.time));
                    n2_4.Items.push(stranger);
                    n2_4_1.Text = kow.u_name + "(" + kow.u_momoid + ")";
                    n2_4_1.Type = "Message";
                    n2_4.Tag = kow.u_momoid;

                    //提取陌生人聊天记录
                    var len = eval('(' + XLY.Sqlite.Find(mmuser, "select u_name,cast(s_time AS varchar)as time,mm.* from md_messages_1 mm left join "+usertbl+" ft on ft.[u_momoid]=mm.[s_remoteid] where s_remoteid='" + n2_4.Tag + "' ") + ')');
                    for (var y in len) {
                        var tow = len[y];
                        var ss = new Message();
                        var sf = XLY.Convert.ToInt(tow.s_type);
                        if (sf == 1) {
                            ss.Fname = XLY.Convert.ToString(row.u_name);
                            ss.Tname = XLY.Convert.ToString(tow.u_name);
                        } else if (sf == 2) {
                            ss.Fname = XLY.Convert.ToString(tow.u_name);
                            ss.Tname = XLY.Convert.ToString(row.u_name);
                        }
                        ss.Htime = XLY.Convert.LinuxToDateTime(parseInt(tow.time));
                        ss.Content = XLY.Convert.ToString(tow.s_text);
                        var mst = XLY.Convert.ToInt(tow.s_contenttype);
                        ss.Type = GetType(mst);
                        ss.Distance = XLY.Convert.ToString(tow.s_distance) + "米";
                        n2_4_1.Items.push(ss);
                    }
                    n2_4.TreeNodes.push(n2_4_1);
                }

                //群组
                var n2_2 = new TreeNode();
                n2_2.Text = "群组";
                n2_2.Type = "Groupinfo";
                //读取群组信息
                var len22 = eval('(' + XLY.Sqlite.Find(mmuser, "select cast(g_createTime AS varchar)as createtime,* from "+grouptbl+" where g_relationType='3' OR g_relationType='1' ") + ')');
                for (var u in len22) {
                    var gow = len22[u];
                    var ginfo = new Groupinfo();
                    ginfo.Gid = XLY.Convert.ToString(gow.g_groupid);
                    ginfo.Gname = XLY.Convert.ToString(gow.g_name);
                    ginfo.Gsign = XLY.Convert.ToString(gow.g_introduce);
                    //读取群组成员
                    var gmember = gow.g_members;
                    var member = eval('(' + gmember + ')');
                    for (var w in member) {
                        ginfo.Gmember += "姓名:" + member[w].name + ";" + "ID:" + member[w].momoid + ";" + "登录时间:" + XLY.Convert.LinuxToDateTime(parseInt(member[w].loc_timesec)); //+"\n"; //+"\n";
                    }
                    ginfo.Gtime = XLY.Convert.LinuxToDateTime(parseInt(gow.createtime));
                    ginfo.Gower = XLY.Convert.ToString(gow.g_owner);
                    ginfo.Gmcount = XLY.Convert.ToString(gow.g_memberCount);
                    ginfo.Gsitename = XLY.Convert.ToString(gow.g_siteName);
                    n2_2.Items.push(ginfo);
                    var n2_2_1 = new TreeNode();
                    n2_2_1.Text = gow.g_name + "(" + gow.g_groupid + ")";
                    n2_2_1.Type = "Groupmessage";
                    n2_2.Tag = gow.g_groupid;
                    //读取群组聊天记录
                    var len = eval('(' + XLY.Sqlite.Find(mmuser, "select cast(gm_time AS varchar)as stime,* from md_group_messages_1 gms left join "+grouptbl+" gr on gr.[g_groupid]=gms.[gm_groupid] where gm_groupid='" + n2_2.Tag + "' ") + ')');
                    for (var y in len) {
                        var gsow = len[y];
                        var gs = new Groupmessage();
                        if (gsow.gm_remoteid == "") {
                            gs.Gmfname = "系统消息";
                        } else {
                            gs.Gmfname = GetName(member, gsow.gm_remoteid) + "(" + gsow.gm_remoteid + ")";
                        }
                        gs.Gmtname = XLY.Convert.ToString(gsow.g_name);
                        gs.Gmcontent = XLY.Convert.ToString(gsow.gm_text);
                        var gst = XLY.Convert.ToInt(gsow.gm_contentType);
                        gs.Gmtype = GetType(gst);
                        gs.Gmtime = XLY.Convert.LinuxToDateTime(parseInt(gsow.stime));
                        n2_2_1.Items.push(gs);
                    }
                    n2_2.TreeNodes.push(n2_2_1);
                }

                //讨论组
                var n2_3 = new TreeNode();
                n2_3.Text = "讨论组";
                n2_3.Type = "Discussinfo";
                var useinfo = XLY.Sqlite.Find(mmuser,"select * from sqlite_master where tbl_name = 'md_discussProfile_3'");
                if(useinfo.length>2){   
                    //读取讨论组信息                
                    var len23 = eval('(' + XLY.Sqlite.Find(mmuser, "select cast(d_createTime AS varchar)as ctime,* from md_discussProfile_3 ") + ')');
                    for (var u in len23) {
                        var dsow = len23[u];
                        var dsinfo = new Discussinfo();
                        dsinfo.Dsid = XLY.Convert.ToString(dsow.d_discussid);
                        dsinfo.Dsname = XLY.Convert.ToString(dsow.d_name);
                        //读取讨论组成员
                        var dsmember = dsow.d_members;
                        var member = eval('(' + dsmember + ')');
                        for (var w in member) {
                            dsinfo.Dsmember += "姓名:" + member[w].name + ";" + "ID:" + member[w].momoid + "\n";
                        }
                        dsinfo.Dstime = XLY.Convert.LinuxToDateTime(dsow.ctime);
                        dsinfo.Dsower = XLY.Convert.ToString(dsow.d_owner);
                        dsinfo.Dscount = XLY.Convert.ToString(dsow.d_memberCount);

                        n2_3.Items.push(dsinfo);
                        var n2_3_1 = new TreeNode();
                        n2_3_1.Text = dsow.d_name + "(" + dsow.d_discussid + ")";
                        n2_3_1.Type = "Discussmessage";
                        n2_3.Tag = dsow.d_discussid;
                        //读取讨论组聊天记录
                        var len = eval('(' + XLY.Sqlite.Find(mmuser, "select cast(mm_time AS varchar)as stime,* from md_multi_messages_1 dsm left join md_discussProfile_3 ds on ds.[d_discussid]=dsm.[mm_groupid] where mm_groupid='" + n2_3.Tag + "' ") + ')');
                        for (var y in len) {
                            var dsmow = len[y];
                            var ds = new Discussmessage();
                            if (dsmow.mm_remoteid == "") {
                                ds.Dsfname = "系统消息";
                            } else {
                                ds.Dsfname = XLY.Convert.ToString(dsmow.mm_remoteid);
                            }
                            ds.Dstname = XLY.Convert.ToString(dsmow.mm_groupid);
                            ds.Dscontent = XLY.Convert.ToString(dsmow.mm_text);
                            var dst = XLY.Convert.ToInt(dsmow.mm_contentType);
                            ds.Dstype = GetType(dst)

                            ds.Dstime = XLY.Convert.LinuxToDateTime(parseInt(dsmow.stime));
                            n2_3_1.Items.push(ds);
                        }
                        n2_3.TreeNodes.push(n2_3_1);
                    }
                }
                n1.TreeNodes.push(n2_1);
                n1.TreeNodes.push(n2_4);

                n1.TreeNodes.push(n2_2);
                n1.TreeNodes.push(n2_3);
            }

            result.push(n1);
        }
    }
}

var res = JSON.stringify(result);
res;
