﻿/*[config]
<plugin name="赤兔加速器,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/chitu.png" app="net.chitu.chitujsq" version="1.0.11" description="赤兔加速器" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/net.chitu.chitujsq/shared_prefs#F</value>
    <value>/data/data/net.chitu.chitujsq/cache#F</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户ID" code="UserId" type="string" width = "100"></item>
    <item name="用户名" code="AccountId" type="string" width = "100"></item>
    <item name="登录密码" code="PassWord" type="string" width = "80"></item>
    <item name="账号类型" code="AccountType" type="string" width = "80"></item>
    <item name="会员等级" code="SrvName" type="string" width = "80"></item>
    <item name="会员过期时间" code="SrvEndTime" type="string" width = "100"></item>
    <item name="头像链接" code="HeadUrl" type="url" width = "100"></item>
    <item name="信用度" code="Credit" type="string" width="80"></item>
    <item name="是否首次登陆" code="IsFirstRun" type="string" width="80"></item>
    <item name="当前链接服务器ip" code="ServeIP" type="string" width = "100"></item>
    <item name="当前链接服务器id" code="ServeId" type="string" width = "100"></item>
    <item name="当前链接服务器类型" code="ServeType" type="string" width="80"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserId = "";
    this.AccountId = "";
    this.PassWord = "";
    this.AccountType = "";
    this.SrvName = "";
    this.SrvEndTime = "";
    this.HeadUrl = "";
    this.Credit = "";
    this.ServeIP = "";
    this.ServeType = "";
    this.ServeId = "";
    this.IsFirstRun = "否";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userAllPath = source[0];
var cacheAllPath = source[1];

var userPath = userAllPath+"\\Allprofile.xml";
var userPathAdd = userAllPath+"\\ENCRYPT_CODE.xml";
var vpnPath = cacheAllPath+"\\android.conf";
var setPath = userAllPath+"\\settings.xml";

//测试数据
//var userPath = "D:\\temp\\data\\data\\net.chitu.chitujsq\\shared_prefs\\Allprofile.xml";
//var userPathAdd = "D:\\temp\\data\\data\\net.chitu.chitujsq\\shared_prefs\\ENCRYPT_CODE.xml";
//var vpnPath = "D:\\temp\\data\\data\\net.chitu.chitujsq\\cache\\android.conf";
//var setPath = "D:\\temp\\data\\data\\net.chitu.chitujsq\\shared_prefs\\settings.xml";
//定义特征库文件
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "赤兔加速器";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userdata = eval('('+ XLY.File.ReadXML(userPath) +')');
        if(userdata!=""&&userdata!=null){
            var aa = userdata.map.string;
            if(aa!=""&&aa!=null){
                if(aa["#text"]!=""&&aa["#text"]!=null){
                    var bb = eval('('+ aa["#text"] +')');
                    var obj = new UserInfo();
                    obj.UserId = bb.uid;
                    
                    obj.SrvName = bb.srvname;
                    obj.SrvEndTime = bb.srvendtime;
                    obj.HeadUrl = bb.avatar;
                    obj.Credit = bb.credit;
                    if(XLY.File.IsValid(userPathAdd)){
                        var userinfodata = eval('('+ XLY.File.ReadXML(userPathAdd) +')');
                        if(userinfodata!=""&&userinfodata!=null){
                            var cc = userinfodata.map.string;
                            if(cc!=""&&cc!=null){
                                if(cc["#text"]!=""&&cc["#text"]!=null){
                                    var sign = XLY.Blob.ToBytes(cc["#text"],"base64");
                                    var arr = getBinaryUserInfo(sign);
                                    if(arr.length==11){
                                        obj.AccountId = arr[10];
                                        obj.PassWord = arr[5];
                                        obj.AccountType = arr[8];
                                    }
                                }
                            }
                        }
                    }
                    if(XLY.File.IsValid(vpnPath)){
                        var fur = XLY.File.ReadFile(vpnPath);
                        if(fur!=""&&fur!=null){
                            var ff = fur.split("\n");
                            var reg = new RegExp("^remote");
                            for(var f in ff){
                                if(reg.test(ff[f])){
                                    var gg = ff[f].split(" ");
                                    obj.ServeIP = gg[1];
                                    obj.ServeType = gg[3];
                                    obj.ServeId = gg[2];
                                }
                            }
                        }
                    }
                    if(XLY.File.IsValid(setPath)){
                        var setdata = eval('('+ XLY.File.ReadXML(setPath) +')');
                        if(setdata!=""&&setdata!=null){
                            var ss = setdata.map.boolean;
                            if(ss["@value"]=="true"){
                               obj.IsFirstRun = "是"; 
                            }
                        }
                    }
                    var node = new TreeNode();
                    node.Text = obj.AccountId;
                    node.Type = "UserInfo";
                    node.Items.push(obj);
                    if(node.Items!=""&&node.Items!=null){
                        root.TreeNodes.push(node);
                    }
                }
            }
        }
    }
}
function getBinaryUserInfo(data){
    if(data!=""&&data!=null){
        var a = 0;
        var b = 0;
        var size = data.length;
        var arr = new Array();
        while(a<size){
            var aa = XLY.Blob.FindBytes(data,a,[0x74,0x00]);
            if(aa!=-1){
                a = aa;
                a += 2;
                b = a;
                a += 1;
                var bb = XLY.Blob.GetBytes(data,a,data[b]);
                if(bb!=""&&bb!=null){
                    arr.push(XLY.Blob.ToString(bb));
                    a += data[b];
                }
            }
            else
            {
                break;
            }
        }
        return arr;
    }
}