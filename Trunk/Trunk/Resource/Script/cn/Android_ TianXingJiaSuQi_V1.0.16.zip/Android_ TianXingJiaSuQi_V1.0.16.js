﻿/*[config]
<plugin name="天行加速器,3" group="生活旅游,4" devicetype="android" pump="LocalData,usb,wifi,mirror,bluetooth" icon="/icons/tianxingjiasuqi.png" app="com.vpn.tianxing" version="1.0.16" description="天行加速器" data="$data,ComplexTreeDataSource" >
<source>
    <value>/data/data/com.vpn.tianxing/shared_prefs/shared_doujia_data.xml</value>
    <value>/data/data/com.vpn.tianxing/databases/profile.db</value>
</source>
<data type="UserInfo" contract = "DataState">
    <item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
    <item name="用户名" code="UserName" type="string" width = "100"></item>
    <item name="密码" code="PassWord" type="string" width = "100"></item>
    <item name="剩余时长" code="LeftTime" type="string" width="100"></item>
    <item name="当前选择服务器名称" code="CurrentSelectServeName" type="string" width = "120"></item>
    <item name="当前选择服务器IP" code="CurrentSelectServeIp" type="string" width = "120"></item>
    <item name="当前选择服务器链接时间" code="LinkTime" type="datetime" width="100" format = "yyyy-MM-dd HH:mm:ss" order = "desc"></item>
    <item name="登录时间" code="LoadTime" type="string" width = "120"></item>
    <item name="传送流量" code="Tx" type="string" width = "100"></item>
    <item name="接收流量" code="Rx" type="string" width="100"></item>
    <item name="远程端口" code="RemotePort" type="string" width="100"></item>
    <item name="本地端口" code="LocalPort" type="string" width="100"></item>
</data>
</plugin>
[config]*/

//********************************************* 定义数据结构*********************************************
//定义UserInfo数据结构
function UserInfo(){
    this.DataState = "Normal";
    this.UserName = "";
    this.PassWord = "";
    this.LeftTime = "";
    this.CurrentSelectServeName = "";
    this.CurrentSelectServeIp = "";
    this.LinkTime = null;
    this.LoadTime = "";
    this.Tx = "";
    this.Rx = "";
    this.RemotePort = "";
    this.LocalPort = "";
}

//定义树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//********************************************* 处理APP数据*********************************************
var result = new Array();
//源文件
var source = $source;
var userPath = source[0];
var userPathAdd = source[1];

//测试数据
//var userPath = "D:\\temp\\data\\data\\com.vpn.tianxing\\shared_prefs\\shared_doujia_data.xml";
//var userPathAdd = "D:\\temp\\data\\data\\com.vpn.tianxing\\databases\\profile.db";
//定义特征库文件
//var userpathDcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\preferences_storage.charactor";
//var contactPathcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\contact2db.charactor";
//var activityArrangementPthcharactor = "\\chalib\\Android_ 139Mail_V6.6.3\\calendarsdk.db.charactor";

//恢复数据库中删除的数据
//var profilePath = XLY.Sqlite.DataRecovery(profilePath1,charactor,"profile");
//var contactPath = XLY.Sqlite.DataRecovery(contactPath1,contactPathcharactor,"contacts_raw,contacts_data");
//var activityArrangementPth = XLY.Sqlite.DataRecovery(activityArrangementPth1,activityArrangementPthcharactor,"VEvent");

//创建帐号树结构
buildNode();
var res = JSON.stringify(result);
res;

//**************************************** 定义处理APP数据的方法****************************************
function buildNode(){
    var root = new TreeNode();
    root.Text = "天行加速器";
    root.Type = "";
    getNews(root);
    result.push(root);
}
//获取用户信息
function getNews(root){
    if(XLY.File.IsValid(userPath)){
        var userdata = eval('('+ XLY.File.ReadXML(userPath) +')');
        if(userdata!=""&&userdata!=null){
            var aa = userdata.map.string;
            var bb = userdata.map.int;
            var cc = userdata.map.long;
            var fur = 0;
            var obj = new UserInfo();
            obj.UserName = "";
            obj.PassWord = "";
            obj.LeftTime = "";
            obj.CurrentSelectServeName = "";
            obj.CurrentSelectServeIp = "";
            obj.LinkTime = null;
            obj.Tx = "";
            obj.Rx = "";
            obj.RemotePort = "";
            
            if(aa!=""&&aa!= null){
                for(var i in aa){
                    if(aa[i]["@name"]=="share_key_account"){
                        obj.UserName = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_password"){
                        obj.PassWord = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_expiretime"){
                        obj.LeftTime = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_servername"){
                        obj.CurrentSelectServeName = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_ip"){
                        obj.CurrentSelectServeIp = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_remoteport"){
                        obj.RemotePort = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_userid"){
                        fur = aa[i]["#text"];
                    }
                    if(aa[i]["@name"]=="share_key_userid"){
                        fur = aa[i]["#text"];
                    }
                }
            }
            if(bb!=""&&bb!=null){
                for(var j in bb){
                    if(bb[j]["@name"]=="share_key_remoteport"){
                        obj.RemotePort = bb[j]["@value"]
                    }
                }
            }
            if(XLY.File.IsValid(userPathAdd)){
                var userData = eval('('+ XLY.Sqlite.Find(userPathAdd,"select id,date,localPort,tx,rx from profile where uid = '"+fur+"'") +')');
                if(userData!=""&&userData!=null){
                    obj.LoadTime = userData[0].date;
                    obj.Tx = userData[0].tx;
                    obj.Rx = userData[0].rx;
                    obj.LocalPort = userData[0].localPort;
                }
            }
            if(cc!=""&&cc!=null){
                for(var c in cc){
                    if(cc[c]["@name"]=="share_key_initime"){
                        obj.LoadTime = cc[c]["@value"];
                    }
                }
            }
            var userNode = new TreeNode();
            userNode.Text = obj.UserName;
            userNode.Type = "UserInfo";
            userNode.Items.push(obj);
            if(userNode.Items!=""&&userNode.Items!=null){
                root.TreeNodes.push(userNode);
            }
        }
    }
}