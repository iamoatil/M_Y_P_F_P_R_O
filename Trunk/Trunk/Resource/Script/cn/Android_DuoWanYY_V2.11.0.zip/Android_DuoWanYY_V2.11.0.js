﻿/*[config]
<plugin name="YY语音,8" group="社交聊天,2" devicetype="android" pump="usb,wifi,mirror,bluetooth,chip,Raid" icon="/icons/YY.png" app="com.duowan.mobile" version="2.11.0" description="YY语音" data="$data,ComplexTreeDataSource" >
<source>
<value>/data/data/com.duowan.mobile/databases#F</value>
</source>

<data type="Account" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="ID号" code="ID" type="int" width="150" format=""></item>
<item name="用户名" code="Name" type="string" width="150" format=""></item>
<item name="帐号" code="Passport" type="string" width="150" format=""></item>
<item name="昵称" code="NickName" type="string" width="150" format=""></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="签名" code="Sign" type="string" width="150" format=""></item>
<item name="登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="生日" code="Birthday" type="string" width="150" format=""></item>
</data>

<data type="BuddyGroup" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="组名" code="Name" type="string" width="" format=""></item>
</data>

<data type="User" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="好友ID" code="ID" type="int" width="140" ></item>
<item name="昵称" code="Name" type="string" width="150" format=""></item>
<item name="签名" code="Sign" type="string" width="150" format=""></item>
<item name="最后登录时间" code="Time" type="datetime" width="140" format="yyyy-MM-dd HH:mm:ss"></item>
<item name="性别" code="Gender" type="string" width="100" format=""></item>
<item name="头像地址" code="HeadImage" type="string" width="100" format=""></item>
<item name="生日" code="Birthday" type="string" width="100" format=""></item>
</data>

<data type="Message" datefilter="Date" detailfield="Content" contract="DataState,Conversion" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="发送用户" code="SenderName" type="string" width="120" ></item>
<item name="接收用户" code="ReceiveName" type="string" width="120" ></item>
<item name="头像" code="SenderImage" type="image"  show="false" ></item>
<item name="内容" code="Content" type="string" width="300" ></item>
<item name="类型" code="Type" type="Enum" format="EnumColumnType" width="60" show="false" ></item>
<item name="时间" code="Date" type="datetime" width="120" format="yyyy-MM-dd HH:mm:ss" order="desc"></item>
<item name="发送状态" code="SendState" type="enum" format="EnumSendState"  show="false"></item>
</data>

<data type="Forum" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item>
<item name="群组名称" code="Name" type="string" width="150" format=""></item>
<item name="群组ID" code="ForumID" type="int" width="140" ></item>
<item name="创建者ID" code="ParentID" type="string" width="150" format=""></item>
<item name="群组图标地址" code="Logo " type="string" width="100" format=""></item>
</data>
</plugin>
[config]*/

//****************************************以下是定义数据结构****************************************
//定义Account数据结构
function Account() {
    this.DataState = "Normal";
    this.Name = "";
    this.NickName = "";
    this.Sign = "";
    this.Time = null;
    this.Passport = "";
    this.ID = 0;
    this.Gender = "";
    this.Birthday = "";
}

//定义BuddyGroup数据结构
function BuddyGroup() {
    this.DataState = "Normal";
    this.Name = "";
}

//定义User数据结构
function User() {
    this.DataState = "Normal";
    this.Name = "";
    this.Time = null;
    this.Sign = "";
    this.ID = 0;
    this.Gender = "";
    this.HeadImage = "";
    this.Birthday = "";
}

//定义Message数据结构
function Message() {
    this.SenderName = "";
    this.ReceiveName = "";
    this.SenderImage = "";
    this.Content = "";
    this.Type = "";
    this.Date = null;
    this.SendState = "";
    this.DataState = "Normal";
}

//定义Forum数据结构
function Forum() {
    this.Name = "";
    this.ForumID = "";
    this.ParentID = "";
    this.Logo = "";
    this.DataState = "Normal";
}

//树形结构
function TreeNode() {
    this.Text = ""; //节点名称
    this.TreeNodes = new Array(); //子节点数字
    this.Items = new Array(); //该节点的数据项，即前面定义的Item对象数组。
    this.Type = ""; //节点[Items]的数据类型
    this.DataState = "Normal";
}

//****************************************以下是处理APP数据****************************************
var result = new Array();
//源文件
var source = $source;
var path = source[0];
//var path = "E:\\app_data\\Android\\com.duowan.mobile\\databases";

//特征库文件
var charactor1 = "chalib\\Android_DuoWanYY_V2.11.0\\accounts.charactor";
var charactor2 = "chalib\\Android_DuoWanYY_V2.11.0\\forumDbdymatic.charactor";
var charactor3 = "chalib\\Android_DuoWanYY_V2.11.0\\friendInfoDb_dymatic.charactor";
var charactor4 = "chalib\\Android_DuoWanYY_V2.11.0\\user_msg_db_dymatic.charactor";
var charactor5 = "chalib\\Android_DuoWanYY_V2.11.0\\userInfoDb.charactor";

//创建账号树结构
var accPath = path + "\\accounts";
var recoveryAccPth = XLY.Sqlite.DataRecovery(accPath, charactor1, "AccountDBHelper$AccountInfo");
var accountData = eval('(' + XLY.Sqlite.FindByName(recoveryAccPth, "AccountDBHelper$AccountInfo") + ')');
for (var index in accountData) {
    var account = new TreeNode();
    account.Text = accountData[index].username;
    account.Type = "Account";
    account.DataState = accountData[index].XLY_DataType
    var accInfo = getAccountInfo(accountData[index], path)
    account.Items.push(accInfo);
    buildChildNodesForAccount(account, path, accInfo)
    result.push(account);
}

var res = JSON.stringify(result);
res;

//****************************************以下是处理APP数据的方法****************************************
//获取账号信息
function getAccountInfo(data,path) {
    var obj = new Account();
    obj.Name = data.username;
    obj.Time = XLY.Convert.LinuxToDateTime(data.timeStamp);
    obj.ID = data.uid;
    obj.Passport = data.passport;
    obj.Gender = (data.gender == 2) ? "男" : "女";
    obj.DataState = XLY.Convert.ToDataState(data.XLY_DataType);
    var userPath = path + "\\userInfoDb";
    var info = eval('(' + XLY.Sqlite.Find(userPath, "select * from UserInfo where uid='" + data.uid + "'") + ')');
    if (info.length != 0) {
        obj.NickName = info[0].nickname;
        obj.Sign = info[0].signature;
        obj.Birthday = XLY.Convert.ToDateTime(info[0].birthday,"yyyyMMdd");
    }
    return obj;
}

//获取账号子节点信息
function buildChildNodesForAccount(tree, path, acc) {
    //创建账号好友子节点
    var buddyGroup = new TreeNode();
    buddyGroup.Text = "好友分组"
    buddyGroup.Type = "BuddyGroup";
    buddyGroup.DataState = "Normal";
    var buddyGroupPath = path + "\\friendInfoDb_" + acc.ID;
    var recoveryBuddyGroupPath = XLY.Sqlite.DataRecovery(buddyGroupPath, charactor3, "GroupInfo,FriendInfo");
    var buddyGroupData = eval('(' + XLY.Sqlite.FindByName(recoveryBuddyGroupPath, "GroupInfo") + ')');
    for (var index in buddyGroupData) {
        var obj = new BuddyGroup();
        obj.Name = buddyGroupData[index].remark;
        obj.DataState = XLY.Convert.ToDataState(buddyGroupData[index].XLY_DataType);
        buddyGroup.Items.push(obj);

        //创建好友分组的各节点
        var friendGroup = new TreeNode();
        friendGroup.Text = buddyGroupData[index].remark;
        friendGroup.Type = "User";
        friendGroup.DataState = buddyGroupData[index].XLY_DataType;
        var friendGroupInfo = getUserInfo(path, recoveryBuddyGroupPath, buddyGroupData[index].folderID);
        friendGroup.Items = friendGroupInfo;
        buddyGroup.TreeNodes.push(friendGroup);

        //创建好友聊天信息节点
        for (var num in friendGroupInfo) {
            var friendMessage = new TreeNode();
            friendMessage.Text = friendGroupInfo[num].Name;
            friendMessage.Type = "Message";
            friendMessage.DataState = friendGroupInfo[num].DataState;
            friendMessage.Items = getFriendMessageInfo(path, acc, friendGroupInfo[num]);
            friendGroup.TreeNodes.push(friendMessage);
        }
    }

    //创建账号群组子节点
    var forum = new TreeNode();
    forum.Text = "群组";
    forum.Type = "Forum";
    var forumInfo = getForumInfo(path, acc);
    forum.Items = forumInfo;
    for (var number in forumInfo) {
        var forumMessage = new TreeNode();
        forumMessage.Text = forumInfo[number].Name;
        forumMessage.Type = "Message";
        forumMessage.DataState = forumInfo[number].DataState;
        forumMessage.Items = getForumMessageInfo(path, acc, forumInfo[number]);
        forum.TreeNodes.push(forumMessage);
    }
    tree.TreeNodes.push(buddyGroup);
    tree.TreeNodes.push(forum);
}

//获取帐号子节点之好友分组中好友信息
function getUserInfo(upath, fpath, id) {
    var data = eval('(' + XLY.Sqlite.Find(fpath, "select * from FriendInfo where gid='" + id + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var userPath = upath + "\\userInfoDb";
        var recoveryUserPath = XLY.Sqlite.DataRecovery(userPath, charactor5, "UserInfo");
        var userData = eval('(' + XLY.Sqlite.Find(recoveryUserPath, "select * from UserInfo where uid='" + data[index].uid + "'") + ')');
        for (var num in userData) {
            var obj = new User();
            obj.Name = userData[num].nickname;
            obj.ID = userData[num].uid;
            obj.Time = XLY.Convert.LinuxToDateTime(userData[num].lastLogoutTime);
            obj.Gender = (userData[num].gender == 1) ? "男" : "女";
            obj.HeadImage = userData[num].portraitUrl;
            obj.Sign = userData[num].signature;
            if (userData[num].birthday != "") {
                obj.Birthday = XLY.Convert.ToDateTime(userData[num].birthday, "yyyyMMdd");
            }
            obj.DataState = XLY.Convert.ToDataState(userData[num].XLY_DataType);
            info.push(obj);
        }
    }
    return info;
}

//获取好友聊天信息
function getFriendMessageInfo(path, acc, id) {
    var mpath = path + "\\user_msg_db_" + acc.ID;
    var recoverymPath = XLY.Sqlite.DataRecovery(mpath, charactor4, "MessageInfo");
    var data = eval('(' + XLY.Sqlite.Find(recoverymPath, "select * from MessageInfo where toUid='" + id.ID + "' OR fromUid='" + id.ID + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        if (data[index].fromUid == acc.ID) {
            obj.SenderName = acc.NickName;
            obj.ReceiveName = id.Name;
        } else {
            obj.SenderName = id.Name;
            obj.ReceiveName = acc.NickName;
        }
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].timeStamp);
        obj.Content = data[index].text;
        obj.SendState = (data[index].inComingState == 0) ? "Send" : "Receive";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取群组信息
function getForumInfo(path, acc) {
    var forumPath = path + "\\forumDb" + acc.ID;
    var recoveryForumPath = XLY.Sqlite.DataRecovery(forumPath, charactor2, "ForumInfo");
    var data = eval('(' + XLY.Sqlite.Find(recoveryForumPath, "select * from ForumInfo") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Forum();
        obj.Name = data[index].forumName;
        obj.ForumID = data[index].forumId;
        obj.ParentID = data[index].parentForumId;
        obj.Logo = data[index].logoUrl;
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}

//获取群组聊天消息
function getForumMessageInfo(path, acc, forum) {
    var forumPath = path + "\\forumDb" + acc.ID;
    var recoveryForumPath = XLY.Sqlite.DataRecovery(forumPath, charactor2, "ForumMessage");
    var data = eval('(' + XLY.Sqlite.Find(recoveryForumPath, "select * from ForumMessage where forumId='" + forum.ForumID + "'") + ')');
    var info = new Array();
    for (var index in data) {
        var obj = new Message();
        obj.SenderName = data[index].nickName + "(" + data[index].uid + ")";
        obj.ReceiveName = forum.Name + "(" + forum.ForumID + ")";
        obj.Content = data[index].msg;
        obj.Date = XLY.Convert.LinuxToDateTime(data[index].timeStamp);
        obj.SendState = (data[index].uid == acc.ID) ? "Send" : "Receive";
        obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
        info.push(obj);
    }
    return info;
}
