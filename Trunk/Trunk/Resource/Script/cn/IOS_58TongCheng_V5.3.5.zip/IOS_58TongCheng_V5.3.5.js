﻿/*[config]
<plugin name="58同城,9" group="生活旅游,6" devicetype="ios" pump="usb,wifi,mirror,bluetooth" icon="/icons/58.png" app="com.taofang.iphone" version="5.3.5" description="58同城" data="$data,ComplexTreeDataSource"  >
<source>
<value>com.taofang.iphone</value>
</source>
<data type="SearchHistory" contract="DataState" >
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="关键字" code="keyword" type="string" width="100"></item>
</data>
<data type="FootHistory" contract="DataState">
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="内容" code="title" type="string" width="200"></item>
<item name="快速链接" code="webUrl" type="Url" width="400"></item>
</data>
<data type="DialHistory" datefilter="time" contract="DataState">   
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="标题" code="title" type="string" width="300"></item>
<item name="分类" code="cateName" type="string" width="150"></item>
<item name="地址" code="location" type="string" width="150"></item>
<item name="手机" code="phone" type="string" width="150" ></item>
<item name="链接" code="Url" type="Url" width="400" ></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>
<data type="BrowseHistory" datefilter="time" contract="DataState"> 
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="标题" code="title" type="string" width="300"></item>
<item name="分类" code="cateName" type="string" width="150"></item>
<item name="地址" code="location" type="string" width="150"></item>
<item name="链接" code="Url" type="Url" width="400" ></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>

<data type="SiftHistory" datefilter="time" contract="DataState">  
<item name="数据状态" code="DataState" type="Enum" format="EnumDataState" ></item> 
<item name="类别" code="cateName" type="string" width="150"></item>
<item name="位置" code="location" type="string" width="150"></item>
<item name="标题" code="title" type="string" width="300"></item>
<item name="快速链接" code="webUrl" type="Url" width="400"></item>
<item name="时间" code="time" type="DateTime" width="200"></item>
</data>
<data type="LastGpsCity">
<item name="地址" code="location" type="string" width="150"></item>

</data>

</plugin>
[config]*/

// js content

//定义数据结构
function SearchHistory() {
	this.keyword = "";  
	this.DataState = "Normal";  
}

function FootHistory() {
	this.title = "";  
	this.webUrl = "";  
	this.DataState = "Normal";  
}

function DialHistory() {
	this.Url = "";  
	this.title = "";  
	this.cateName = "";  
	this.location = "";  
	this.phone = "";  
	this.time = "";  
	this.DataState = "Normal";  
}

function BrowseHistory() {
	this.Url = "";  
	this.title = "";  
	this.cateName = "";  
	this.location = "";  
	this.time = "";  
	this.DataState = "Normal";  
}

function SiftHistory() {
	this.cateName = "";  
	this.location = "";  
	this.title = "";  
	this.webUrl = "";  
	this.time = "";  
	this.DataState = "Normal";  
}

function LastGpsCity() {
	this.location = "";  
}

//树形结构
function TreeNode() {
	this.Text = "";//节点名称
	this.TreeNodes = new Array();//子节点数字
	this.Items = new Array();//该节点的数据项，即前面定义的Item对象数组。
	this.DataState = "Normal";  
}

//搜索历史记录
function getSearchHistory(path)
{
	try{
		var arr = new Array();
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from Search ") + ')');
		for(var index in data)
		{
			if(data[index].wordKey)
			{
				var obj=new SearchHistory();
				obj.keyword = data[index].wordKey;  
				obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
				arr.push(obj);
			}
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//足迹
function getFootHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from IntegrateTable ") + ')');
		for(var index in data)
		{
			var obj=new FootHistory();
			obj.title = data[index].showname;  
			obj.webUrl = data[index].url;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//拨打记录
function getDialHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from DialHistory order by updatetime desc") + ')');
		for(var index in data)
		{
			var obj=new SiftHistory();
			obj.Url = data[index].url;  
			obj.title = data[index].title;  
			obj.cateName = data[index].catename;  
			obj.location = data[index].localname;  
			obj.phone = data[index].phoneNumber;  
			obj.time = data[index].updatetime;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//浏览记录
function getBrowseHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from DetailHistory order by updatetime desc") + ')');
		for(var index in data)
		{
			var obj=new SiftHistory();
			obj.Url = data[index].url;  
			obj.title = data[index].title;  
			obj.cateName = data[index].catename;  
			obj.location = data[index].localname;  
			obj.time = data[index].updatetime;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//筛选记录
function getShiftHistory(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.Sqlite.Find(path, "select * from FilterHistory order by updatetime desc") + ')');
		for(var index in data)
		{
			var obj=new SiftHistory();
			obj.cateName = data[index].categoryName;  
			obj.location = data[index].localname;  
			obj.title = data[index].title;  
			obj.webUrl = data[index].url;      
			obj.time = data[index].updatetime;  
			obj.DataState = XLY.Convert.ToDataState(data[index].XLY_DataType);
			arr.push(obj);
		}
		return arr;
	}
	catch(e){
		return arr;
	}
}

//最后定位
function getLastGpsCity(path)
{
	var arr = new Array();
	try{
		var data = eval('(' + XLY.PList.ReadToJsonString(path)+ ')');
		var obj=new LastGpsCity();
		if( data[1].$objects[0].WBCityModel[3].name)
		{
			obj.location = data[1].$objects[0].WBCityModel[3].name;  
		}
		arr.push(obj);
		return arr;
	}
	catch(e){
		return arr;
	}
}

var result = new Array();

//源文件
var source = $source;
var path1 = source[0]+"com.taofang.iphone/Documents/mainDB.db";
var path2 = source[0]+"com.taofang.iphone/Documents/LastGpsCity";

//数据恢复库的生成
var charactor="chalib\\IOS_58TongCheng_V5.3.5\\mainDB.db.charactor";
path1=XLY.Sqlite.DataRecovery( path1,charactor ,"Search,IntegrateTable,DialHistory,DetailHistory,FilterHistory");

//节点实例化
var SearchNode =new TreeNode();
SearchNode.Type="SearchHistory";
SearchNode.Text="浏览记录";

var FootNode =new TreeNode();
FootNode.Type="FootHistory";
FootNode.Text="首页足迹";

var DialNode =new TreeNode();
DialNode.Type="DialHistory";
DialNode.Text="拨打历史";

var BrowseNode =new TreeNode();
BrowseNode.Type="BrowseHistory";
BrowseNode.Text="浏览历史";

var HistoryNode =new TreeNode();
HistoryNode.Text="历史记录";

var SiftNode =new TreeNode();
SiftNode.Type="SiftHistory";
SiftNode.Text="筛选历史";

var GpsNode =new TreeNode();
GpsNode.Type="LastGpsCity";
GpsNode.Text="最后定位城市";

//节点填充
SearchNode.Items=getSearchHistory(path1);
FootNode.Items=getFootHistory(path1);
DialNode.Items=getDialHistory(path1);
BrowseNode.Items=getBrowseHistory(path1);
SiftNode.Items=getShiftHistory(path1);
GpsNode.Items=getLastGpsCity(path2);

//打印数据
HistoryNode.TreeNodes.push(DialNode);
HistoryNode.TreeNodes.push(BrowseNode);
HistoryNode.TreeNodes.push(SiftNode);
result.push(SearchNode);
result.push(FootNode);
result.push(HistoryNode);
result.push(GpsNode);
var res = JSON.stringify(result);
res;
